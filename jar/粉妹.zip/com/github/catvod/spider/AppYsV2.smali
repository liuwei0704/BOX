.class public Lcom/github/catvod/spider/AppYsV2;
.super Lcom/github/catvod/crawler/Spider;
.source "SourceFile"


# static fields
.field private static final c:Ljava/util/regex/Pattern;

.field private static final d:Ljava/util/regex/Pattern;

.field private static final e:Ljava/util/regex/Pattern;

.field protected static final f:[Ljava/util/regex/Pattern;


# instance fields
.field protected final a:Ljava/util/HashMap;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/HashMap<",
            "Ljava/lang/String;",
            "Ljava/util/ArrayList<",
            "Ljava/lang/String;",
            ">;>;"
        }
    .end annotation
.end field

.field private b:[Ljava/lang/String;


# direct methods
.method static constructor <clinit>()V
    .registers 6

    const/16 v0, 0x10

    new-array v0, v0, [B

    fill-array-data v0, :array_10c

    const/16 v1, 0x8

    new-array v2, v1, [B

    fill-array-data v2, :array_118

    invoke-static {v0, v2}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    move-result-object v0

    sput-object v0, Lcom/github/catvod/spider/AppYsV2;->c:Ljava/util/regex/Pattern;

    const/16 v0, 0x11

    new-array v0, v0, [B

    fill-array-data v0, :array_120

    new-array v2, v1, [B

    fill-array-data v2, :array_12e

    invoke-static {v0, v2}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    new-array v0, v1, [B

    fill-array-data v0, :array_136

    new-array v2, v1, [B

    fill-array-data v2, :array_13e

    invoke-static {v0, v2}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    const/16 v0, 0x16

    new-array v2, v0, [B

    fill-array-data v2, :array_146

    new-array v3, v1, [B

    fill-array-data v3, :array_156

    invoke-static {v2, v3}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    move-result-object v2

    sput-object v2, Lcom/github/catvod/spider/AppYsV2;->d:Ljava/util/regex/Pattern;

    const/16 v2, 0xe

    new-array v3, v2, [B

    fill-array-data v3, :array_15e

    new-array v4, v1, [B

    fill-array-data v4, :array_16a

    invoke-static {v3, v4}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v3

    invoke-static {v3}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    move-result-object v3

    sput-object v3, Lcom/github/catvod/spider/AppYsV2;->e:Ljava/util/regex/Pattern;

    const/4 v3, 0x7

    new-array v3, v3, [Ljava/util/regex/Pattern;

    const/16 v4, 0xa

    new-array v4, v4, [B

    fill-array-data v4, :array_172

    new-array v5, v1, [B

    fill-array-data v5, :array_17c

    invoke-static {v4, v5}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-static {v4}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    move-result-object v4

    const/4 v5, 0x0

    aput-object v4, v3, v5

    const/16 v4, 0xf

    new-array v4, v4, [B

    fill-array-data v4, :array_184

    new-array v5, v1, [B

    fill-array-data v5, :array_190

    invoke-static {v4, v5}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-static {v4}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    move-result-object v4

    const/4 v5, 0x1

    aput-object v4, v3, v5

    new-array v0, v0, [B

    fill-array-data v0, :array_198

    new-array v4, v1, [B

    fill-array-data v4, :array_1a8

    invoke-static {v0, v4}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    move-result-object v0

    const/4 v4, 0x2

    aput-object v0, v3, v4

    new-array v0, v2, [B

    fill-array-data v0, :array_1b0

    new-array v2, v1, [B

    fill-array-data v2, :array_1bc

    invoke-static {v0, v2}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    move-result-object v0

    const/4 v2, 0x3

    aput-object v0, v3, v2

    const/16 v0, 0xd

    new-array v0, v0, [B

    fill-array-data v0, :array_1c4

    new-array v2, v1, [B

    fill-array-data v2, :array_1d0

    invoke-static {v0, v2}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    move-result-object v0

    const/4 v2, 0x4

    aput-object v0, v3, v2

    const/16 v0, 0x1b

    new-array v0, v0, [B

    fill-array-data v0, :array_1d8

    new-array v2, v1, [B

    fill-array-data v2, :array_1ea

    invoke-static {v0, v2}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    move-result-object v0

    const/4 v2, 0x5

    aput-object v0, v3, v2

    const/16 v0, 0x1a

    new-array v0, v0, [B

    fill-array-data v0, :array_1f2

    new-array v1, v1, [B

    fill-array-data v1, :array_204

    invoke-static {v0, v1}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    move-result-object v0

    const/4 v1, 0x6

    aput-object v0, v3, v1

    sput-object v3, Lcom/github/catvod/spider/AppYsV2;->f:[Ljava/util/regex/Pattern;

    return-void

    nop

    :array_10c
    .array-data 1
        -0x62t
        0x4dt
        0x32t
        0x68t
        0xat
        -0x1dt
        -0x29t
        0x8t
        -0x30t
        0x13t
        0x71t
        0xbt
        0xbt
        -0x1bt
        -0x30t
        0x1ct
    .end array-data

    :array_118
    .array-data 1
        -0x1t
        0x3dt
        0x5bt
        0x34t
        0x24t
        -0x6dt
        -0x41t
        0x78t
    .end array-data

    :array_120
    .array-data 1
        -0x5t
        0x64t
        0x74t
        0x59t
        0x26t
        -0x2ft
        0x55t
        0x23t
        -0x4bt
        0x3at
        0x36t
        0x3at
        0x54t
        -0x71t
        0x4bt
        0x3ct
        -0x2t
    .end array-data

    nop

    :array_12e
    .array-data 1
        -0x66t
        0x14t
        0x1dt
        0x5t
        0x8t
        -0x5ft
        0x3dt
        0x53t
    .end array-data

    :array_136
    .array-data 1
        -0x54t
        -0x78t
        0x6dt
        0x20t
        0x4ct
        0x39t
        -0x2bt
        0x32t
    .end array-data

    :array_13e
    .array-data 1
        -0x7dt
        -0x5at
        0x46t
        0x7ct
        0x73t
        0x17t
        -0x2t
        0xft
    .end array-data

    :array_146
    .array-data 1
        0x5et
        0x3at
        0x6ct
        0x7bt
        -0x78t
        0x2dt
        -0x64t
        -0x4bt
        0xct
        0x66t
        0x2dt
        0x6at
        -0x7at
        0x31t
        -0x78t
        -0x4dt
        0x2ct
        0x2ft
        0x2dt
        0x6at
        -0x2dt
        0x7ct
    .end array-data

    nop

    :array_156
    .array-data 1
        0x70t
        0x10t
        0x44t
        0xet
        -0x6t
        0x41t
        -0x20t
        -0x3dt
    .end array-data

    :array_15e
    .array-data 1
        -0x3dt
        0x4at
        -0x5t
        0x7et
        0x38t
        0xdt
        -0xet
        -0xft
        -0x7ct
        0x65t
        -0x2ft
        0x21t
        0x16t
        0x18t
    .end array-data

    nop

    :array_16a
    .array-data 1
        -0x55t
        0x3et
        -0x71t
        0xet
        0x4bt
        0x32t
        -0x38t
        -0x22t
    .end array-data

    :array_172
    .array-data 1
        -0x68t
        -0x3et
        0x19t
        -0x76t
        0x40t
        -0x21t
        0x5et
        -0x6et
        -0x73t
        -0x27t
    .end array-data

    nop

    :array_17c
    .array-data 1
        -0x18t
        -0x52t
        0x78t
        -0xdt
        0x25t
        -0x53t
        0x63t
        -0x4t
    .end array-data

    :array_184
    .array-data 1
        0x26t
        -0x76t
        -0x1ct
        -0x7et
        0x7bt
        -0x3ct
        -0x6ct
        -0x5t
        0x38t
        -0x68t
        -0x1ct
        -0x70t
        0x3et
        -0x3et
        -0x2et
    .end array-data

    :array_190
    .array-data 1
        0x1at
        -0x12t
        -0x73t
        -0xct
        0x5bt
        -0x53t
        -0x10t
        -0x3at
    .end array-data

    :array_198
    .array-data 1
        -0x5ft
        0xft
        -0x57t
        0x3at
        -0x1bt
        -0x5bt
        -0x20t
        0x48t
        -0x41t
        0x30t
        -0x62t
        0x6et
        -0x68t
        -0x1at
        -0x45t
        0x5t
        -0xft
        0xat
        -0x47t
        0x29t
        -0x49t
        -0x12t
    .end array-data

    nop

    :array_1a8
    .array-data 1
        -0x63t
        0x6bt
        -0x40t
        0x4ct
        -0x3bt
        -0x34t
        -0x7ct
        0x75t
    .end array-data

    :array_1b0
    .array-data 1
        0x1t
        -0x17t
        0x43t
        -0x2dt
        0x0t
        0x71t
        -0x69t
        0x3ct
        -0x39t
        0x55t
        0x15t
        -0x6et
        0x8t
        0x3dt
    .end array-data

    nop

    :array_1bc
    .array-data 1
        0x2et
        -0x3at
        -0x55t
        0x74t
        -0x7at
        -0x68t
        0x35t
        -0x53t
    .end array-data

    :array_1c4
    .array-data 1
        0x4t
        -0x79t
        -0x5t
        0x5ft
        -0x72t
        0x3ft
        0xdt
        -0x33t
        0x35t
        -0x72t
        -0x6t
        0x49t
        -0x2bt
    .end array-data

    nop

    :array_1d0
    .array-data 1
        0x4ct
        -0x15t
        -0x78t
        0x15t
        -0x3t
        0x6ft
        0x61t
        -0x54t
    .end array-data

    :array_1d8
    .array-data 1
        -0x7ct
        0x4t
        0x13t
        0x18t
        0x6at
        0x17t
        -0x57t
        0x3et
        -0x1ct
        0x1et
        0x29t
        0x39t
        0x56t
        0x50t
        -0xdt
        0x16t
        -0x36t
        0xet
        0x48t
        0x48t
        0x50t
        0x24t
        -0x12t
        0x38t
        -0x6dt
        0x52t
        0x57t
    .end array-data

    :array_1ea
    .array-data 1
        -0x48t
        0x6dt
        0x75t
        0x6at
        0xbt
        0x7at
        -0x34t
        0x65t
    .end array-data

    :array_1f2
    .array-data 1
        -0x76t
        -0x1t
        -0x4dt
        0x66t
        0x27t
        -0x1bt
        -0x71t
        0x39t
        -0x3bt
        -0x2bt
        -0x77t
        0x5ft
        0x68t
        -0x4bt
        -0x59t
        0x17t
        -0x2bt
        -0x4ct
        -0x8t
        0x59t
        0x1ct
        -0x58t
        -0x77t
        0x4et
        -0x77t
        -0x55t
    .end array-data

    nop

    :array_204
    .array-data 1
        -0x4at
        -0x77t
        -0x26t
        0x2t
        0x42t
        -0x76t
        -0x2ct
        0x65t
    .end array-data
.end method

.method public constructor <init>()V
    .registers 2

    invoke-direct {p0}, Lcom/github/catvod/crawler/Spider;-><init>()V

    new-instance v0, Ljava/util/HashMap;

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    iput-object v0, p0, Lcom/github/catvod/spider/AppYsV2;->a:Ljava/util/HashMap;

    const/4 v0, 0x0

    iput-object v0, p0, Lcom/github/catvod/spider/AppYsV2;->b:[Ljava/lang/String;

    return-void
.end method

.method private a(Lorg/json/JSONObject;Ljava/lang/String;Ljava/util/ArrayList;)V
    .registers 8
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lorg/json/JSONObject;",
            "Ljava/lang/String;",
            "Ljava/util/ArrayList<",
            "Lorg/json/JSONArray;",
            ">;)V"
        }
    .end annotation

    invoke-virtual {p1}, Lorg/json/JSONObject;->keys()Ljava/util/Iterator;

    move-result-object v0

    :cond_4
    :goto_4
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_4a

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    :try_start_10
    invoke-virtual {p1, v1}, Lorg/json/JSONObject;->get(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v2

    invoke-virtual {v1, p2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_24

    instance-of v1, v2, Lorg/json/JSONArray;

    if-eqz v1, :cond_24

    move-object v1, v2

    check-cast v1, Lorg/json/JSONArray;

    invoke-virtual {p3, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_24
    instance-of v1, v2, Lorg/json/JSONObject;

    if-eqz v1, :cond_2e

    check-cast v2, Lorg/json/JSONObject;

    invoke-direct {p0, v2, p2, p3}, Lcom/github/catvod/spider/AppYsV2;->a(Lorg/json/JSONObject;Ljava/lang/String;Ljava/util/ArrayList;)V

    goto :goto_4

    :cond_2e
    instance-of v1, v2, Lorg/json/JSONArray;

    if-eqz v1, :cond_4

    check-cast v2, Lorg/json/JSONArray;

    const/4 v1, 0x0

    :goto_35
    invoke-virtual {v2}, Lorg/json/JSONArray;->length()I

    move-result v3

    if-ge v1, v3, :cond_4

    invoke-virtual {v2, v1}, Lorg/json/JSONArray;->getJSONObject(I)Lorg/json/JSONObject;

    move-result-object v3

    invoke-direct {p0, v3, p2, p3}, Lcom/github/catvod/spider/AppYsV2;->a(Lorg/json/JSONObject;Ljava/lang/String;Ljava/util/ArrayList;)V
    :try_end_42
    .catch Lorg/json/JSONException; {:try_start_10 .. :try_end_42} :catch_45

    add-int/lit8 v1, v1, 0x1

    goto :goto_35

    :catch_45
    move-exception v1

    invoke-static {v1}, Lcom/github/catvod/crawler/SpiderDebug;->log(Ljava/lang/Throwable;)V

    goto :goto_4

    :cond_4a
    return-void
.end method

.method private b(Ljava/lang/String;Lorg/json/JSONObject;Lorg/json/JSONObject;Ljava/lang/String;)V
    .registers 30

    move-object/from16 v1, p0

    move-object/from16 v2, p1

    move-object/from16 v0, p2

    move-object/from16 v3, p3

    move-object/from16 v4, p4

    new-instance v5, Ljava/util/ArrayList;

    invoke-direct {v5}, Ljava/util/ArrayList;-><init>()V

    new-instance v6, Ljava/util/ArrayList;

    invoke-direct {v6}, Ljava/util/ArrayList;-><init>()V

    const/16 v7, 0xc

    new-array v8, v7, [B

    fill-array-data v8, :array_caa

    const/16 v9, 0x8

    new-array v10, v9, [B

    fill-array-data v10, :array_cb4

    invoke-static {v8, v10}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v2, v8}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v8

    const/16 v10, 0xb

    const/16 v11, 0x9

    const/4 v12, 0x6

    const/4 v13, 0x7

    const/4 v14, 0x4

    if-eqz v8, :cond_202

    new-array v2, v14, [B

    fill-array-data v2, :array_cbc

    new-array v8, v9, [B

    fill-array-data v8, :array_cc2

    invoke-static {v2, v8}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Lorg/json/JSONObject;->getJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v0

    new-array v2, v12, [B

    fill-array-data v2, :array_cca

    new-array v8, v9, [B

    fill-array-data v8, :array_cd2

    invoke-static {v2, v8}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v2

    new-array v8, v12, [B

    fill-array-data v8, :array_cda

    new-array v12, v9, [B

    fill-array-data v12, :array_ce2

    invoke-static {v8, v12}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v0, v8, v4}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v2, v4}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    new-array v2, v9, [B

    fill-array-data v2, :array_cea

    new-array v4, v9, [B

    fill-array-data v4, :array_cf2

    invoke-static {v2, v4}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v2

    new-array v4, v9, [B

    fill-array-data v4, :array_cfa

    new-array v8, v9, [B

    fill-array-data v8, :array_d02

    .line 1
    invoke-static {v4, v8, v0, v3, v2}, Lcom/github/catvod/spider/appysv2/o/a;->a([B[BLorg/json/JSONObject;Lorg/json/JSONObject;Ljava/lang/String;)V

    new-array v2, v13, [B

    .line 2
    fill-array-data v2, :array_d0a

    new-array v4, v9, [B

    fill-array-data v4, :array_d12

    invoke-static {v2, v4}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v2

    new-array v4, v13, [B

    fill-array-data v4, :array_d1a

    new-array v8, v9, [B

    fill-array-data v8, :array_d22

    .line 3
    invoke-static {v4, v8, v0, v3, v2}, Lcom/github/catvod/spider/appysv2/o/a;->a([B[BLorg/json/JSONObject;Lorg/json/JSONObject;Ljava/lang/String;)V

    new-array v2, v11, [B

    .line 4
    fill-array-data v2, :array_d2a

    new-array v4, v9, [B

    fill-array-data v4, :array_d34

    invoke-static {v2, v4}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v2

    new-array v4, v11, [B

    fill-array-data v4, :array_d3c

    new-array v8, v9, [B

    fill-array-data v8, :array_d46

    .line 5
    invoke-static {v4, v8, v0, v3, v2}, Lcom/github/catvod/spider/appysv2/b/y;->c([B[BLorg/json/JSONObject;Lorg/json/JSONObject;Ljava/lang/String;)V

    new-array v2, v9, [B

    .line 6
    fill-array-data v2, :array_d4e

    new-array v4, v9, [B

    fill-array-data v4, :array_d56

    invoke-static {v2, v4}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v2

    new-array v4, v9, [B

    fill-array-data v4, :array_d5e

    new-array v8, v9, [B

    fill-array-data v8, :array_d66

    .line 7
    invoke-static {v4, v8, v0, v3, v2}, Lcom/github/catvod/spider/appysv2/b/y;->c([B[BLorg/json/JSONObject;Lorg/json/JSONObject;Ljava/lang/String;)V

    new-array v2, v9, [B

    .line 8
    fill-array-data v2, :array_d6e

    new-array v4, v9, [B

    fill-array-data v4, :array_d76

    invoke-static {v2, v4}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v2

    new-array v4, v9, [B

    fill-array-data v4, :array_d7e

    new-array v8, v9, [B

    fill-array-data v8, :array_d86

    .line 9
    invoke-static {v4, v8, v0, v3, v2}, Lcom/github/catvod/spider/appysv2/b/y;->c([B[BLorg/json/JSONObject;Lorg/json/JSONObject;Ljava/lang/String;)V

    new-array v2, v10, [B

    .line 10
    fill-array-data v2, :array_d8e

    new-array v4, v9, [B

    fill-array-data v4, :array_d98

    invoke-static {v2, v4}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v2

    new-array v4, v10, [B

    fill-array-data v4, :array_da0

    new-array v8, v9, [B

    fill-array-data v8, :array_daa

    .line 11
    invoke-static {v4, v8, v0, v3, v2}, Lcom/github/catvod/spider/appysv2/b/y;->c([B[BLorg/json/JSONObject;Lorg/json/JSONObject;Ljava/lang/String;)V

    new-array v2, v11, [B

    .line 12
    fill-array-data v2, :array_db2

    new-array v4, v9, [B

    fill-array-data v4, :array_dbc

    invoke-static {v2, v4}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v2

    new-array v4, v11, [B

    fill-array-data v4, :array_dc4

    new-array v8, v9, [B

    fill-array-data v8, :array_dce

    .line 13
    invoke-static {v4, v8, v0, v3, v2}, Lcom/github/catvod/spider/appysv2/b/y;->c([B[BLorg/json/JSONObject;Lorg/json/JSONObject;Ljava/lang/String;)V

    new-array v2, v7, [B

    .line 14
    fill-array-data v2, :array_dd6

    new-array v4, v9, [B

    fill-array-data v4, :array_de0

    invoke-static {v2, v4}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v2

    new-array v4, v7, [B

    fill-array-data v4, :array_de8

    new-array v7, v9, [B

    fill-array-data v7, :array_df2

    .line 15
    invoke-static {v4, v7, v0, v3, v2}, Lcom/github/catvod/spider/appysv2/b/y;->c([B[BLorg/json/JSONObject;Lorg/json/JSONObject;Ljava/lang/String;)V

    new-array v2, v10, [B

    .line 16
    fill-array-data v2, :array_dfa

    new-array v4, v9, [B

    fill-array-data v4, :array_e04

    invoke-static {v2, v4}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v2

    new-array v4, v10, [B

    fill-array-data v4, :array_e0c

    new-array v7, v9, [B

    fill-array-data v7, :array_e16

    .line 17
    invoke-static {v4, v7, v0, v3, v2}, Lcom/github/catvod/spider/appysv2/b/y;->c([B[BLorg/json/JSONObject;Lorg/json/JSONObject;Ljava/lang/String;)V

    const/16 v2, 0x13

    new-array v2, v2, [B

    .line 18
    fill-array-data v2, :array_e1e

    new-array v4, v9, [B

    fill-array-data v4, :array_e2c

    invoke-static {v2, v4}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Lorg/json/JSONObject;->getJSONArray(Ljava/lang/String;)Lorg/json/JSONArray;

    move-result-object v0

    const/4 v2, 0x0

    :goto_170
    invoke-virtual {v0}, Lorg/json/JSONArray;->length()I

    move-result v4

    if-ge v2, v4, :cond_99e

    invoke-virtual {v0, v2}, Lorg/json/JSONArray;->getJSONObject(I)Lorg/json/JSONObject;

    move-result-object v4

    new-array v7, v14, [B

    fill-array-data v7, :array_e34

    new-array v8, v9, [B

    fill-array-data v8, :array_e3a

    invoke-static {v7, v8}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v4, v7}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v7}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v7}, Ljava/lang/String;->isEmpty()Z

    move-result v8

    if-eqz v8, :cond_1ac

    new-array v7, v14, [B

    fill-array-data v7, :array_e42

    new-array v8, v9, [B

    fill-array-data v8, :array_e48

    invoke-static {v7, v8}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v4, v7}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v7}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v7

    :cond_1ac
    invoke-virtual {v6, v7}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    const/4 v8, 0x3

    new-array v8, v8, [B

    fill-array-data v8, :array_e50

    new-array v10, v9, [B

    fill-array-data v10, :array_e56

    invoke-static {v8, v10}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v4, v8}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v5, v8}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    new-array v8, v11, [B

    fill-array-data v8, :array_e5e

    new-array v10, v9, [B

    fill-array-data v10, :array_e68

    invoke-static {v8, v10}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v4, v8}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v4

    iget-object v8, v1, Lcom/github/catvod/spider/AppYsV2;->a:Ljava/util/HashMap;

    invoke-virtual {v8, v7}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v8

    check-cast v8, Ljava/util/ArrayList;

    if-nez v8, :cond_1ef

    new-instance v8, Ljava/util/ArrayList;

    invoke-direct {v8}, Ljava/util/ArrayList;-><init>()V

    iget-object v10, v1, Lcom/github/catvod/spider/AppYsV2;->a:Ljava/util/HashMap;

    invoke-virtual {v10, v7, v8}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_1ef
    invoke-virtual {v4}, Ljava/lang/String;->isEmpty()Z

    move-result v7

    if-nez v7, :cond_1fe

    invoke-virtual {v8, v4}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result v7

    if-nez v7, :cond_1fe

    invoke-virtual {v8, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_1fe
    add-int/lit8 v2, v2, 0x1

    goto/16 :goto_170

    :cond_202
    const/4 v8, 0x5

    new-array v8, v8, [B

    fill-array-data v8, :array_e70

    new-array v15, v9, [B

    fill-array-data v15, :array_e78

    invoke-static {v8, v15}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v2, v8}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v8

    if-eqz v8, :cond_3f8

    new-array v2, v14, [B

    fill-array-data v2, :array_e80

    new-array v8, v9, [B

    fill-array-data v8, :array_e86

    invoke-static {v2, v8}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Lorg/json/JSONObject;->getJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v0

    new-array v2, v9, [B

    fill-array-data v2, :array_e8e

    new-array v8, v9, [B

    fill-array-data v8, :array_e96

    invoke-static {v2, v8}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Lorg/json/JSONObject;->getJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v0

    new-array v2, v12, [B

    fill-array-data v2, :array_e9e

    new-array v8, v9, [B

    fill-array-data v8, :array_ea6

    invoke-static {v2, v8}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v2

    new-array v8, v12, [B

    fill-array-data v8, :array_eae

    new-array v12, v9, [B

    fill-array-data v12, :array_eb6

    invoke-static {v8, v12}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v0, v8, v4}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v2, v4}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    new-array v2, v9, [B

    fill-array-data v2, :array_ebe

    new-array v4, v9, [B

    fill-array-data v4, :array_ec6

    invoke-static {v2, v4}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v2

    new-array v4, v9, [B

    fill-array-data v4, :array_ece

    new-array v8, v9, [B

    fill-array-data v8, :array_ed6

    .line 19
    invoke-static {v4, v8, v0, v3, v2}, Lcom/github/catvod/spider/appysv2/o/a;->a([B[BLorg/json/JSONObject;Lorg/json/JSONObject;Ljava/lang/String;)V

    new-array v2, v13, [B

    .line 20
    fill-array-data v2, :array_ede

    new-array v4, v9, [B

    fill-array-data v4, :array_ee6

    invoke-static {v2, v4}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v2

    new-array v4, v13, [B

    fill-array-data v4, :array_eee

    new-array v8, v9, [B

    fill-array-data v8, :array_ef6

    .line 21
    invoke-static {v4, v8, v0, v3, v2}, Lcom/github/catvod/spider/appysv2/o/a;->a([B[BLorg/json/JSONObject;Lorg/json/JSONObject;Ljava/lang/String;)V

    new-array v2, v11, [B

    .line 22
    fill-array-data v2, :array_efe

    new-array v4, v9, [B

    fill-array-data v4, :array_f08

    invoke-static {v2, v4}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v2

    new-array v4, v11, [B

    fill-array-data v4, :array_f10

    new-array v8, v9, [B

    fill-array-data v8, :array_f1a

    .line 23
    invoke-static {v4, v8, v0, v3, v2}, Lcom/github/catvod/spider/appysv2/b/y;->c([B[BLorg/json/JSONObject;Lorg/json/JSONObject;Ljava/lang/String;)V

    new-array v2, v9, [B

    .line 24
    fill-array-data v2, :array_f22

    new-array v4, v9, [B

    fill-array-data v4, :array_f2a

    invoke-static {v2, v4}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v2

    new-array v4, v9, [B

    fill-array-data v4, :array_f32

    new-array v8, v9, [B

    fill-array-data v8, :array_f3a

    .line 25
    invoke-static {v4, v8, v0, v3, v2}, Lcom/github/catvod/spider/appysv2/b/y;->c([B[BLorg/json/JSONObject;Lorg/json/JSONObject;Ljava/lang/String;)V

    new-array v2, v9, [B

    .line 26
    fill-array-data v2, :array_f42

    new-array v4, v9, [B

    fill-array-data v4, :array_f4a

    invoke-static {v2, v4}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v2

    new-array v4, v9, [B

    fill-array-data v4, :array_f52

    new-array v8, v9, [B

    fill-array-data v8, :array_f5a

    .line 27
    invoke-static {v4, v8, v0, v3, v2}, Lcom/github/catvod/spider/appysv2/b/y;->c([B[BLorg/json/JSONObject;Lorg/json/JSONObject;Ljava/lang/String;)V

    new-array v2, v10, [B

    .line 28
    fill-array-data v2, :array_f62

    new-array v4, v9, [B

    fill-array-data v4, :array_f6c

    invoke-static {v2, v4}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v2

    new-array v4, v10, [B

    fill-array-data v4, :array_f74

    new-array v8, v9, [B

    fill-array-data v8, :array_f7e

    .line 29
    invoke-static {v4, v8, v0, v3, v2}, Lcom/github/catvod/spider/appysv2/b/y;->c([B[BLorg/json/JSONObject;Lorg/json/JSONObject;Ljava/lang/String;)V

    new-array v2, v11, [B

    .line 30
    fill-array-data v2, :array_f86

    new-array v4, v9, [B

    fill-array-data v4, :array_f90

    invoke-static {v2, v4}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v2

    new-array v4, v11, [B

    fill-array-data v4, :array_f98

    new-array v8, v9, [B

    fill-array-data v8, :array_fa2

    .line 31
    invoke-static {v4, v8, v0, v3, v2}, Lcom/github/catvod/spider/appysv2/b/y;->c([B[BLorg/json/JSONObject;Lorg/json/JSONObject;Ljava/lang/String;)V

    new-array v2, v7, [B

    .line 32
    fill-array-data v2, :array_faa

    new-array v4, v9, [B

    fill-array-data v4, :array_fb4

    invoke-static {v2, v4}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v2

    new-array v4, v7, [B

    fill-array-data v4, :array_fbc

    new-array v7, v9, [B

    fill-array-data v7, :array_fc6

    .line 33
    invoke-static {v4, v7, v0, v3, v2}, Lcom/github/catvod/spider/appysv2/b/y;->c([B[BLorg/json/JSONObject;Lorg/json/JSONObject;Ljava/lang/String;)V

    new-array v2, v10, [B

    .line 34
    fill-array-data v2, :array_fce

    new-array v4, v9, [B

    fill-array-data v4, :array_fd8

    invoke-static {v2, v4}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v2

    new-array v4, v10, [B

    fill-array-data v4, :array_fe0

    new-array v7, v9, [B

    fill-array-data v7, :array_fea

    .line 35
    invoke-static {v4, v7, v0, v3, v2}, Lcom/github/catvod/spider/appysv2/b/y;->c([B[BLorg/json/JSONObject;Lorg/json/JSONObject;Ljava/lang/String;)V

    const/16 v2, 0x13

    new-array v2, v2, [B

    .line 36
    fill-array-data v2, :array_ff2

    new-array v4, v9, [B

    fill-array-data v4, :array_1000

    invoke-static {v2, v4}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Lorg/json/JSONObject;->getJSONArray(Ljava/lang/String;)Lorg/json/JSONArray;

    move-result-object v0

    const/4 v2, 0x0

    :goto_366
    invoke-virtual {v0}, Lorg/json/JSONArray;->length()I

    move-result v4

    if-ge v2, v4, :cond_99e

    invoke-virtual {v0, v2}, Lorg/json/JSONArray;->getJSONObject(I)Lorg/json/JSONObject;

    move-result-object v4

    new-array v7, v14, [B

    fill-array-data v7, :array_1008

    new-array v8, v9, [B

    fill-array-data v8, :array_100e

    invoke-static {v7, v8}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v4, v7}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v7}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v7}, Ljava/lang/String;->isEmpty()Z

    move-result v8

    if-eqz v8, :cond_3a2

    new-array v7, v14, [B

    fill-array-data v7, :array_1016

    new-array v8, v9, [B

    fill-array-data v8, :array_101c

    invoke-static {v7, v8}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v4, v7}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v7}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v7

    :cond_3a2
    invoke-virtual {v6, v7}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    const/4 v8, 0x3

    new-array v8, v8, [B

    fill-array-data v8, :array_1024

    new-array v10, v9, [B

    fill-array-data v10, :array_102a

    invoke-static {v8, v10}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v4, v8}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v5, v8}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    new-array v8, v11, [B

    fill-array-data v8, :array_1032

    new-array v10, v9, [B

    fill-array-data v10, :array_103c

    invoke-static {v8, v10}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v4, v8}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v4

    iget-object v8, v1, Lcom/github/catvod/spider/AppYsV2;->a:Ljava/util/HashMap;

    invoke-virtual {v8, v7}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v8

    check-cast v8, Ljava/util/ArrayList;

    if-nez v8, :cond_3e5

    new-instance v8, Ljava/util/ArrayList;

    invoke-direct {v8}, Ljava/util/ArrayList;-><init>()V

    iget-object v10, v1, Lcom/github/catvod/spider/AppYsV2;->a:Ljava/util/HashMap;

    invoke-virtual {v10, v7, v8}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_3e5
    invoke-virtual {v4}, Ljava/lang/String;->isEmpty()Z

    move-result v7

    if-nez v7, :cond_3f4

    invoke-virtual {v8, v4}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result v7

    if-nez v7, :cond_3f4

    invoke-virtual {v8, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_3f4
    add-int/lit8 v2, v2, 0x1

    goto/16 :goto_366

    :cond_3f8
    new-array v8, v14, [B

    fill-array-data v8, :array_1044

    new-array v15, v9, [B

    fill-array-data v15, :array_104a

    invoke-static {v8, v15}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v2, v8}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v8

    if-eqz v8, :cond_9a4

    new-array v8, v14, [B

    fill-array-data v8, :array_1052

    new-array v15, v9, [B

    fill-array-data v15, :array_1058

    invoke-static {v8, v15}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v0, v8}, Lorg/json/JSONObject;->getJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v0

    new-array v8, v12, [B

    fill-array-data v8, :array_1060

    new-array v15, v9, [B

    fill-array-data v15, :array_1068

    invoke-static {v8, v15}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v8

    new-array v12, v12, [B

    fill-array-data v12, :array_1070

    new-array v15, v9, [B

    fill-array-data v15, :array_1078

    invoke-static {v12, v15}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v12

    invoke-virtual {v0, v12, v4}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v8, v4}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    new-array v4, v9, [B

    fill-array-data v4, :array_1080

    new-array v8, v9, [B

    fill-array-data v8, :array_1088

    invoke-static {v4, v8}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v4

    new-array v8, v9, [B

    fill-array-data v8, :array_1090

    new-array v12, v9, [B

    fill-array-data v12, :array_1098

    .line 37
    invoke-static {v8, v12, v0, v3, v4}, Lcom/github/catvod/spider/appysv2/o/a;->a([B[BLorg/json/JSONObject;Lorg/json/JSONObject;Ljava/lang/String;)V

    new-array v4, v13, [B

    .line 38
    fill-array-data v4, :array_10a0

    new-array v8, v9, [B

    fill-array-data v8, :array_10a8

    invoke-static {v4, v8}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v4

    new-array v8, v13, [B

    fill-array-data v8, :array_10b0

    new-array v12, v9, [B

    fill-array-data v12, :array_10b8

    .line 39
    invoke-static {v8, v12, v0, v3, v4}, Lcom/github/catvod/spider/appysv2/o/a;->a([B[BLorg/json/JSONObject;Lorg/json/JSONObject;Ljava/lang/String;)V

    new-array v4, v11, [B

    .line 40
    fill-array-data v4, :array_10c0

    new-array v8, v9, [B

    fill-array-data v8, :array_10ca

    invoke-static {v4, v8}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v4

    new-array v8, v11, [B

    fill-array-data v8, :array_10d2

    new-array v12, v9, [B

    fill-array-data v12, :array_10dc

    .line 41
    invoke-static {v8, v12, v0, v3, v4}, Lcom/github/catvod/spider/appysv2/b/y;->c([B[BLorg/json/JSONObject;Lorg/json/JSONObject;Ljava/lang/String;)V

    new-array v4, v9, [B

    .line 42
    fill-array-data v4, :array_10e4

    new-array v8, v9, [B

    fill-array-data v8, :array_10ec

    invoke-static {v4, v8}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v4

    new-array v8, v9, [B

    fill-array-data v8, :array_10f4

    new-array v12, v9, [B

    fill-array-data v12, :array_10fc

    .line 43
    invoke-static {v8, v12, v0, v3, v4}, Lcom/github/catvod/spider/appysv2/b/y;->c([B[BLorg/json/JSONObject;Lorg/json/JSONObject;Ljava/lang/String;)V

    new-array v4, v9, [B

    .line 44
    fill-array-data v4, :array_1104

    new-array v8, v9, [B

    fill-array-data v8, :array_110c

    invoke-static {v4, v8}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v4

    new-array v8, v9, [B

    fill-array-data v8, :array_1114

    new-array v12, v9, [B

    fill-array-data v12, :array_111c

    .line 45
    invoke-static {v8, v12, v0, v3, v4}, Lcom/github/catvod/spider/appysv2/b/y;->c([B[BLorg/json/JSONObject;Lorg/json/JSONObject;Ljava/lang/String;)V

    new-array v4, v10, [B

    .line 46
    fill-array-data v4, :array_1124

    new-array v8, v9, [B

    fill-array-data v8, :array_112e

    invoke-static {v4, v8}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v4

    new-array v8, v10, [B

    fill-array-data v8, :array_1136

    new-array v12, v9, [B

    fill-array-data v12, :array_1140

    .line 47
    invoke-static {v8, v12, v0, v3, v4}, Lcom/github/catvod/spider/appysv2/b/y;->c([B[BLorg/json/JSONObject;Lorg/json/JSONObject;Ljava/lang/String;)V

    new-array v4, v11, [B

    .line 48
    fill-array-data v4, :array_1148

    new-array v8, v9, [B

    fill-array-data v8, :array_1152

    invoke-static {v4, v8}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v4

    new-array v8, v11, [B

    fill-array-data v8, :array_115a

    new-array v12, v9, [B

    fill-array-data v12, :array_1164

    .line 49
    invoke-static {v8, v12, v0, v3, v4}, Lcom/github/catvod/spider/appysv2/b/y;->c([B[BLorg/json/JSONObject;Lorg/json/JSONObject;Ljava/lang/String;)V

    new-array v4, v7, [B

    .line 50
    fill-array-data v4, :array_116c

    new-array v8, v9, [B

    fill-array-data v8, :array_1176

    invoke-static {v4, v8}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v4

    new-array v7, v7, [B

    fill-array-data v7, :array_117e

    new-array v8, v9, [B

    fill-array-data v8, :array_1188

    .line 51
    invoke-static {v7, v8, v0, v3, v4}, Lcom/github/catvod/spider/appysv2/b/y;->c([B[BLorg/json/JSONObject;Lorg/json/JSONObject;Ljava/lang/String;)V

    new-array v4, v10, [B

    .line 52
    fill-array-data v4, :array_1190

    new-array v7, v9, [B

    fill-array-data v7, :array_119a

    invoke-static {v4, v7}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v4

    new-array v7, v10, [B

    fill-array-data v7, :array_11a2

    new-array v8, v9, [B

    fill-array-data v8, :array_11ac

    .line 53
    invoke-static {v7, v8, v0, v3, v4}, Lcom/github/catvod/spider/appysv2/b/y;->c([B[BLorg/json/JSONObject;Lorg/json/JSONObject;Ljava/lang/String;)V

    const/16 v4, 0xd

    new-array v4, v4, [B

    .line 54
    fill-array-data v4, :array_11b4

    new-array v7, v9, [B

    fill-array-data v7, :array_11c0

    invoke-static {v4, v7}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v0, v4}, Lorg/json/JSONObject;->getJSONArray(Ljava/lang/String;)Lorg/json/JSONArray;

    move-result-object v4

    const/4 v0, 0x0

    const/4 v7, 0x0

    :goto_54a
    invoke-virtual {v4}, Lorg/json/JSONArray;->length()I

    move-result v0

    if-ge v7, v0, :cond_99e

    invoke-virtual {v4, v7}, Lorg/json/JSONArray;->getJSONObject(I)Lorg/json/JSONObject;

    move-result-object v0

    new-array v8, v10, [B

    fill-array-data v8, :array_11c8

    new-array v12, v9, [B

    fill-array-data v12, :array_11d2

    invoke-static {v8, v12}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v0, v8}, Lorg/json/JSONObject;->getJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v8

    new-array v12, v14, [B

    fill-array-data v12, :array_11da

    new-array v15, v9, [B

    fill-array-data v15, :array_11e0

    invoke-static {v12, v15}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v12

    invoke-virtual {v8, v12}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v8}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v8}, Ljava/lang/String;->isEmpty()Z

    move-result v12

    if-eqz v12, :cond_5aa

    new-array v8, v10, [B

    fill-array-data v8, :array_11e8

    new-array v12, v9, [B

    fill-array-data v12, :array_11f2

    invoke-static {v8, v12}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v0, v8}, Lorg/json/JSONObject;->getJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v8

    new-array v12, v14, [B

    fill-array-data v12, :array_11fa

    new-array v15, v9, [B

    fill-array-data v15, :array_1200

    invoke-static {v12, v15}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v12

    invoke-virtual {v8, v12}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v8}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v8

    :cond_5aa
    invoke-virtual {v6, v8}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    const/4 v12, 0x3

    new-array v12, v12, [B

    fill-array-data v12, :array_1208

    new-array v15, v9, [B

    fill-array-data v15, :array_120e

    invoke-static {v12, v15}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v12

    invoke-virtual {v0, v12}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v12

    invoke-virtual {v5, v12}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :try_start_5c3
    new-instance v12, Ljava/util/ArrayList;

    invoke-direct {v12}, Ljava/util/ArrayList;-><init>()V

    new-array v10, v10, [B

    const/16 v15, -0x1c

    const/16 v16, 0x0

    aput-byte v15, v10, v16

    const/16 v15, -0x44

    const/16 v16, 0x1

    aput-byte v15, v10, v16

    const/4 v15, 0x2

    aput-byte v13, v10, v15

    const/16 v16, -0x56

    const/16 v17, 0x3

    aput-byte v16, v10, v17

    const/16 v16, -0x47

    aput-byte v16, v10, v14

    const/16 v16, -0x8

    const/16 v17, 0x5

    aput-byte v16, v10, v17

    const/16 v16, 0x50

    const/16 v17, 0x6

    aput-byte v16, v10, v17

    const/16 v16, 0x2c

    aput-byte v16, v10, v13

    const/16 v16, -0x6

    aput-byte v16, v10, v9

    const/16 v16, -0x4a

    aput-byte v16, v10, v11

    const/16 v16, 0xa

    aput-byte v11, v10, v16

    new-array v11, v9, [B

    const/16 v17, -0x6c

    const/16 v18, 0x0

    aput-byte v17, v11, v18

    const/16 v18, -0x30

    const/16 v19, 0x1

    aput-byte v18, v11, v19

    const/16 v18, 0x66

    aput-byte v18, v11, v15

    const/16 v18, -0x2d

    const/16 v19, 0x3

    aput-byte v18, v11, v19

    const/16 v18, -0x24

    aput-byte v18, v11, v14

    const/16 v18, -0x76

    const/16 v19, 0x5

    aput-byte v18, v11, v19

    const/16 v18, 0xf

    const/16 v19, 0x6

    aput-byte v18, v11, v19

    const/16 v18, 0x45

    aput-byte v18, v11, v13

    invoke-static {v10, v11}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v0, v10}, Lorg/json/JSONObject;->getJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v10

    const/4 v11, 0x5

    new-array v11, v11, [B

    const/16 v13, -0xf

    const/16 v19, 0x0

    aput-byte v13, v11, v19

    const/16 v13, -0x10

    const/16 v19, 0x1

    aput-byte v13, v11, v19

    const/16 v13, 0x75

    aput-byte v13, v11, v15

    const/16 v13, 0x58

    const/16 v19, 0x3

    aput-byte v13, v11, v19

    const/16 v19, -0x21

    aput-byte v19, v11, v14

    new-array v13, v9, [B

    const/16 v20, -0x7f

    const/16 v21, 0x0

    aput-byte v20, v13, v21

    const/16 v21, -0x6f

    const/16 v22, 0x1

    aput-byte v21, v13, v22

    const/16 v21, 0x7

    aput-byte v21, v13, v15

    const/16 v21, 0x2b

    const/16 v22, 0x3

    aput-byte v21, v13, v22

    const/16 v21, -0x46

    aput-byte v21, v13, v14

    const/4 v14, 0x5

    aput-byte v14, v13, v14

    const/16 v14, -0x6e

    const/16 v22, 0x6

    aput-byte v14, v13, v22

    const/4 v14, 0x7

    aput-byte v21, v13, v14

    invoke-static {v11, v13}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v11

    invoke-virtual {v10, v11}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    const/4 v11, 0x1

    new-array v13, v11, [B

    const/16 v14, 0xd

    const/16 v22, 0x0

    aput-byte v14, v13, v22

    new-array v14, v9, [B

    const/16 v23, 0x21

    aput-byte v23, v14, v22

    const/16 v22, -0x37

    aput-byte v22, v14, v11

    const/16 v11, 0x61

    aput-byte v11, v14, v15

    const/16 v22, -0x63

    const/16 v23, 0x3

    aput-byte v22, v14, v23

    const/16 v22, -0x12

    const/16 v23, 0x4

    aput-byte v22, v14, v23

    const/16 v22, -0x34

    const/16 v23, 0x5

    aput-byte v22, v14, v23

    const/16 v22, -0x55

    const/16 v23, 0x6

    aput-byte v22, v14, v23

    const/16 v22, -0x39

    const/16 v23, 0x7

    aput-byte v22, v14, v23

    invoke-static {v13, v14}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v13

    invoke-virtual {v10, v13}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v10

    const/16 v13, 0xb

    new-array v13, v13, [B

    const/4 v14, 0x0

    aput-byte v19, v13, v14

    const/16 v14, 0x54

    const/16 v22, 0x1

    aput-byte v14, v13, v22

    const/16 v22, 0x14

    aput-byte v22, v13, v15

    const/16 v22, 0x3

    aput-byte v11, v13, v22

    const/16 v11, 0x30

    const/16 v22, 0x4

    aput-byte v11, v13, v22

    const/16 v11, 0x7e

    const/16 v22, 0x5

    aput-byte v11, v13, v22

    const/16 v22, 0x3a

    const/16 v23, 0x6

    aput-byte v22, v13, v23

    const/16 v22, 0x19

    const/16 v23, 0x7

    aput-byte v22, v13, v23

    const/16 v23, -0x3f

    aput-byte v23, v13, v9

    const/16 v23, 0x5e

    const/16 v24, 0x9

    aput-byte v23, v13, v24

    const/16 v23, 0x1a

    aput-byte v23, v13, v16

    new-array v9, v9, [B

    const/16 v16, -0x51

    const/16 v23, 0x0

    aput-byte v16, v9, v23

    const/16 v16, 0x38

    const/16 v23, 0x1

    aput-byte v16, v9, v23

    const/16 v16, 0x75

    aput-byte v16, v9, v15

    const/16 v16, 0x18

    const/16 v23, 0x3

    aput-byte v16, v9, v23

    const/16 v16, 0x55

    const/16 v23, 0x4

    aput-byte v16, v9, v23

    const/16 v16, 0xc

    const/16 v23, 0x5

    aput-byte v16, v9, v23

    const/16 v16, 0x65

    const/4 v11, 0x6

    aput-byte v16, v9, v11

    const/16 v16, 0x70

    const/16 v23, 0x7

    aput-byte v16, v9, v23

    invoke-static {v13, v9}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v0, v9}, Lorg/json/JSONObject;->getJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v0

    new-array v9, v11, [B

    const/16 v11, 0x72

    const/4 v13, 0x0

    aput-byte v11, v9, v13

    const/16 v11, 0x26

    const/4 v13, 0x1

    aput-byte v11, v9, v13

    aput-byte v14, v9, v15

    const/16 v11, -0x54

    const/4 v13, 0x3

    aput-byte v11, v9, v13

    const/4 v11, 0x4

    aput-byte v18, v9, v11

    const/16 v11, 0x59

    const/4 v13, 0x5

    aput-byte v11, v9, v13

    const/16 v11, 0x8

    new-array v11, v11, [B

    const/4 v13, 0x0

    aput-byte v15, v11, v13

    const/16 v13, 0x47

    const/4 v14, 0x1

    aput-byte v13, v11, v14

    const/16 v13, 0x26

    aput-byte v13, v11, v15

    const/4 v13, 0x3

    aput-byte v19, v11, v13

    const/16 v13, 0x20

    const/4 v14, 0x4

    aput-byte v13, v11, v14

    const/16 v13, 0x6b

    const/4 v14, 0x5

    aput-byte v13, v11, v14

    const/16 v13, 0x71

    const/4 v14, 0x6

    aput-byte v13, v11, v14

    const/4 v13, 0x7

    aput-byte v18, v11, v13

    invoke-static {v9, v11}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v0, v9}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v9, 0x1

    new-array v11, v9, [B

    const/16 v13, -0x61

    const/4 v14, 0x0

    aput-byte v13, v11, v14

    const/16 v13, 0x8

    new-array v13, v13, [B

    const/16 v15, -0x4d

    aput-byte v15, v13, v14

    const/16 v14, 0x23

    aput-byte v14, v13, v9

    const/4 v9, 0x2

    const/16 v14, 0x7e

    aput-byte v14, v13, v9

    const/16 v9, -0x70

    const/4 v14, 0x3

    aput-byte v9, v13, v14

    const/16 v9, 0x4a

    const/4 v14, 0x4

    aput-byte v9, v13, v14

    const/16 v9, -0x5b

    const/4 v14, 0x5

    aput-byte v9, v13, v14

    const/16 v9, 0x1e

    const/4 v14, 0x6

    aput-byte v9, v13, v14

    const/16 v9, -0x4d

    const/4 v14, 0x7

    aput-byte v9, v13, v14

    invoke-static {v11, v13}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v0, v9}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v0

    invoke-static {v10}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v9

    invoke-virtual {v12, v9}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    invoke-static {v0}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v0

    invoke-virtual {v12, v0}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    iget-object v0, v1, Lcom/github/catvod/spider/AppYsV2;->a:Ljava/util/HashMap;

    invoke-virtual {v0, v8}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/util/ArrayList;

    if-nez v0, :cond_7d3

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iget-object v9, v1, Lcom/github/catvod/spider/AppYsV2;->a:Ljava/util/HashMap;

    invoke-virtual {v9, v8, v0}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_7d3
    invoke-virtual {v12}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v8

    :cond_7d7
    :goto_7d7
    invoke-interface {v8}, Ljava/util/Iterator;->hasNext()Z

    move-result v9

    if-eqz v9, :cond_992

    invoke-interface {v8}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v9

    check-cast v9, Ljava/lang/String;

    const/4 v10, 0x4

    new-array v10, v10, [B

    const/16 v11, 0x30

    const/4 v12, 0x0

    aput-byte v11, v10, v12

    const/16 v11, 0x8

    const/4 v12, 0x1

    aput-byte v11, v10, v12

    const/16 v12, -0x50

    const/4 v13, 0x2

    aput-byte v12, v10, v13

    const/16 v12, 0x6d

    const/4 v13, 0x3

    aput-byte v12, v10, v13

    new-array v11, v11, [B

    const/4 v12, 0x0

    const/16 v13, 0x58

    aput-byte v13, v11, v12

    const/16 v12, 0x7c

    const/4 v14, 0x1

    aput-byte v12, v11, v14

    const/16 v12, -0x3c

    const/4 v14, 0x2

    aput-byte v12, v11, v14

    const/16 v12, 0x1d

    const/4 v14, 0x3

    aput-byte v12, v11, v14

    const/16 v12, -0x75

    const/4 v14, 0x4

    aput-byte v12, v11, v14

    const/16 v12, 0x37

    const/4 v14, 0x5

    aput-byte v12, v11, v14

    const/16 v12, 0x27

    const/4 v14, 0x6

    aput-byte v12, v11, v14

    const/16 v12, 0x1e

    const/4 v14, 0x7

    aput-byte v12, v11, v14

    invoke-static {v10, v11}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v9, v10}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v10

    if-eqz v10, :cond_841

    sget-object v10, Lcom/github/catvod/spider/AppYsV2;->d:Ljava/util/regex/Pattern;

    invoke-virtual {v10, v9}, Ljava/util/regex/Pattern;->matcher(Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;

    move-result-object v10

    invoke-virtual {v10}, Ljava/util/regex/Matcher;->find()Z

    move-result v11

    if-eqz v11, :cond_908

    const/4 v9, 0x0

    invoke-virtual {v10, v9}, Ljava/util/regex/Matcher;->group(I)Ljava/lang/String;

    move-result-object v9

    goto/16 :goto_908

    :cond_841
    const/4 v10, 0x2

    new-array v10, v10, [B

    const/4 v11, 0x0

    aput-byte v17, v10, v11

    const/16 v12, 0x36

    const/4 v14, 0x1

    aput-byte v12, v10, v14

    const/16 v12, 0x8

    new-array v12, v12, [B

    const/16 v15, -0x45

    aput-byte v15, v12, v11

    aput-byte v22, v12, v14

    const/16 v11, -0xe

    const/4 v14, 0x2

    aput-byte v11, v12, v14

    const/16 v11, -0x2c

    const/4 v14, 0x3

    aput-byte v11, v12, v14

    const/16 v11, 0x42

    const/4 v14, 0x4

    aput-byte v11, v12, v14

    const/16 v11, 0x4b

    const/4 v14, 0x5

    aput-byte v11, v12, v14

    const/16 v11, -0x58

    const/4 v14, 0x6

    aput-byte v11, v12, v14

    const/16 v11, 0x5b

    const/4 v14, 0x7

    aput-byte v11, v12, v14

    invoke-static {v10, v12}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v9, v10}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v10

    if-eqz v10, :cond_8d8

    sget-object v10, Lcom/github/catvod/spider/AppYsV2;->d:Ljava/util/regex/Pattern;

    invoke-virtual {v10, v9}, Ljava/util/regex/Pattern;->matcher(Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;

    move-result-object v10

    invoke-virtual {v10}, Ljava/util/regex/Matcher;->find()Z

    move-result v11

    if-eqz v11, :cond_908

    new-instance v9, Ljava/lang/StringBuilder;

    invoke-direct {v9}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v11, 0x5

    new-array v12, v11, [B

    const/4 v14, -0x4

    const/4 v15, 0x0

    aput-byte v14, v12, v15

    const/16 v14, -0x57

    const/4 v15, 0x1

    aput-byte v14, v12, v15

    const/4 v14, 0x2

    aput-byte v11, v12, v14

    const/4 v11, 0x3

    aput-byte v14, v12, v11

    const/4 v11, 0x4

    aput-byte v15, v12, v11

    const/16 v11, 0x8

    new-array v11, v11, [B

    const/4 v14, 0x0

    aput-byte v17, v11, v14

    const/16 v14, -0x23

    aput-byte v14, v11, v15

    const/16 v14, 0x71

    const/4 v15, 0x2

    aput-byte v14, v11, v15

    const/16 v14, 0x72

    const/4 v15, 0x3

    aput-byte v14, v11, v15

    const/16 v14, 0x3b

    const/4 v15, 0x4

    aput-byte v14, v11, v15

    const/16 v14, -0x3d

    const/4 v15, 0x5

    aput-byte v14, v11, v15

    const/4 v14, 0x6

    aput-byte v21, v11, v14

    const/16 v14, 0x4c

    const/4 v15, 0x7

    aput-byte v14, v11, v15

    invoke-static {v12, v11}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v11

    invoke-virtual {v9, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v11, 0x0

    invoke-virtual {v10, v11}, Ljava/util/regex/Matcher;->group(I)Ljava/lang/String;

    move-result-object v10

    goto :goto_901

    :cond_8d8
    sget-object v10, Lcom/github/catvod/spider/AppYsV2;->e:Ljava/util/regex/Pattern;

    invoke-virtual {v10, v2}, Ljava/util/regex/Pattern;->matcher(Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;

    move-result-object v10

    invoke-virtual {v10}, Ljava/util/regex/Matcher;->find()Z

    move-result v11

    if-eqz v11, :cond_908

    sget-object v11, Lcom/github/catvod/spider/AppYsV2;->d:Ljava/util/regex/Pattern;

    invoke-virtual {v11, v2}, Ljava/util/regex/Pattern;->matcher(Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;

    move-result-object v11

    invoke-virtual {v11}, Ljava/util/regex/Matcher;->find()Z

    move-result v12

    if-eqz v12, :cond_908

    new-instance v9, Ljava/lang/StringBuilder;

    invoke-direct {v9}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v12, 0x0

    invoke-virtual {v10, v12}, Ljava/util/regex/Matcher;->group(I)Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v9, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v11, v12}, Ljava/util/regex/Matcher;->group(I)Ljava/lang/String;

    move-result-object v10

    :goto_901
    invoke-virtual {v9, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v9}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v9

    :cond_908
    :goto_908
    const/4 v10, 0x2

    new-array v10, v10, [B

    const/16 v11, 0x67

    const/4 v12, 0x0

    aput-byte v11, v10, v12

    const/16 v11, -0x5e

    const/4 v14, 0x1

    aput-byte v11, v10, v14

    const/16 v11, 0x8

    new-array v11, v11, [B

    const/16 v15, 0x49

    aput-byte v15, v11, v12

    const/16 v12, -0x74

    aput-byte v12, v11, v14

    const/16 v12, -0x1d

    const/4 v14, 0x2

    aput-byte v12, v11, v14

    const/16 v12, 0x28

    const/4 v14, 0x3

    aput-byte v12, v11, v14

    const/16 v12, 0x48

    const/4 v14, 0x4

    aput-byte v12, v11, v14

    const/16 v12, 0x25

    const/4 v14, 0x5

    aput-byte v12, v11, v14

    const/4 v12, 0x6

    aput-byte v20, v11, v12

    const/16 v12, 0x7d

    const/4 v14, 0x7

    aput-byte v12, v11, v14

    invoke-static {v10, v11}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v10

    const/4 v11, 0x1

    new-array v12, v11, [B

    const/16 v14, 0x2f

    const/4 v15, 0x0

    aput-byte v14, v12, v15

    const/16 v14, 0x8

    new-array v14, v14, [B

    aput-byte v11, v14, v15

    const/16 v15, -0x5e

    aput-byte v15, v14, v11

    const/16 v11, 0xd

    const/4 v15, 0x2

    aput-byte v11, v14, v15

    const/16 v11, 0x43

    const/4 v15, 0x3

    aput-byte v11, v14, v15

    const/16 v11, -0x19

    const/4 v15, 0x4

    aput-byte v11, v14, v15

    const/16 v11, 0x43

    const/4 v15, 0x5

    aput-byte v11, v14, v15

    const/16 v11, 0x56

    const/4 v15, 0x6

    aput-byte v11, v14, v15

    const/16 v11, -0x3b

    const/4 v15, 0x7

    aput-byte v11, v14, v15

    invoke-static {v12, v14}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v11

    invoke-virtual {v9, v10, v11}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v9}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v9}, Ljava/lang/String;->isEmpty()Z

    move-result v10

    if-nez v10, :cond_7d7

    invoke-virtual {v0, v9}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result v10

    if-nez v10, :cond_7d7

    invoke-virtual {v0, v9}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    :try_end_98c
    .catch Ljava/lang/Exception; {:try_start_5c3 .. :try_end_98c} :catch_98e

    goto/16 :goto_7d7

    :catch_98e
    move-exception v0

    invoke-static {v0}, Lcom/github/catvod/crawler/SpiderDebug;->log(Ljava/lang/Throwable;)V

    :cond_992
    add-int/lit8 v7, v7, 0x1

    const/16 v9, 0x8

    const/4 v14, 0x4

    const/16 v10, 0xb

    const/16 v11, 0x9

    const/4 v13, 0x7

    goto/16 :goto_54a

    :cond_99e
    const/16 v0, 0xd

    const/16 v2, 0x8

    goto/16 :goto_c5f

    :cond_9a4
    sget-object v7, Lcom/github/catvod/spider/AppYsV2;->c:Ljava/util/regex/Pattern;

    invoke-virtual {v7, v2}, Ljava/util/regex/Pattern;->matcher(Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;

    move-result-object v2

    invoke-virtual {v2}, Ljava/util/regex/Matcher;->find()Z

    move-result v2

    if-eqz v2, :cond_c5b

    const/4 v2, 0x6

    new-array v7, v2, [B

    fill-array-data v7, :array_1216

    const/16 v8, 0x8

    new-array v9, v8, [B

    fill-array-data v9, :array_121e

    invoke-static {v7, v9}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v7

    new-array v2, v2, [B

    fill-array-data v2, :array_1226

    new-array v9, v8, [B

    fill-array-data v9, :array_122e

    invoke-static {v2, v9}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2, v4}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v3, v7, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    new-array v2, v8, [B

    fill-array-data v2, :array_1236

    new-array v4, v8, [B

    fill-array-data v4, :array_123e

    invoke-static {v2, v4}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v2

    const/4 v4, 0x5

    new-array v4, v4, [B

    fill-array-data v4, :array_1246

    new-array v7, v8, [B

    fill-array-data v7, :array_124e

    .line 55
    invoke-static {v4, v7, v0, v3, v2}, Lcom/github/catvod/spider/appysv2/o/a;->a([B[BLorg/json/JSONObject;Lorg/json/JSONObject;Ljava/lang/String;)V

    const/4 v2, 0x7

    new-array v4, v2, [B

    .line 56
    fill-array-data v4, :array_1256

    new-array v7, v8, [B

    fill-array-data v7, :array_125e

    invoke-static {v4, v7}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v4

    new-array v2, v2, [B

    fill-array-data v2, :array_1266

    new-array v7, v8, [B

    fill-array-data v7, :array_126e

    .line 57
    invoke-static {v2, v7, v0, v3, v4}, Lcom/github/catvod/spider/appysv2/o/a;->a([B[BLorg/json/JSONObject;Lorg/json/JSONObject;Ljava/lang/String;)V

    const/16 v2, 0x9

    new-array v2, v2, [B

    .line 58
    fill-array-data v2, :array_1276

    new-array v4, v8, [B

    fill-array-data v4, :array_1280

    invoke-static {v2, v4}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v2

    const/4 v4, 0x4

    new-array v4, v4, [B

    fill-array-data v4, :array_1288

    new-array v7, v8, [B

    fill-array-data v7, :array_128e

    invoke-static {v4, v7}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v0, v4}, Lorg/json/JSONObject;->optJSONArray(Ljava/lang/String;)Lorg/json/JSONArray;

    move-result-object v4

    invoke-direct {v1, v4}, Lcom/github/catvod/spider/AppYsV2;->j(Lorg/json/JSONArray;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v2, v4}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    new-array v2, v8, [B

    fill-array-data v2, :array_1296

    new-array v4, v8, [B

    fill-array-data v4, :array_129e

    invoke-static {v2, v4}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v2

    const/4 v4, 0x7

    new-array v4, v4, [B

    fill-array-data v4, :array_12a6

    new-array v7, v8, [B

    fill-array-data v7, :array_12ae

    .line 59
    invoke-static {v4, v7, v0, v3, v2}, Lcom/github/catvod/spider/appysv2/b/y;->c([B[BLorg/json/JSONObject;Lorg/json/JSONObject;Ljava/lang/String;)V

    new-array v2, v8, [B

    .line 60
    fill-array-data v2, :array_12b6

    new-array v4, v8, [B

    fill-array-data v4, :array_12be

    invoke-static {v2, v4}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v2

    const/4 v4, 0x4

    new-array v4, v4, [B

    fill-array-data v4, :array_12c6

    new-array v7, v8, [B

    fill-array-data v7, :array_12cc

    invoke-static {v4, v7}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v0, v4}, Lorg/json/JSONObject;->optJSONArray(Ljava/lang/String;)Lorg/json/JSONArray;

    move-result-object v4

    invoke-direct {v1, v4}, Lcom/github/catvod/spider/AppYsV2;->j(Lorg/json/JSONArray;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v2, v4}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/16 v2, 0xb

    new-array v2, v2, [B

    fill-array-data v2, :array_12d4

    new-array v4, v8, [B

    fill-array-data v4, :array_12de

    invoke-static {v2, v4}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v2

    const/4 v4, 0x5

    new-array v4, v4, [B

    fill-array-data v4, :array_12e6

    new-array v7, v8, [B

    fill-array-data v7, :array_12ee

    .line 61
    invoke-static {v4, v7, v0, v3, v2}, Lcom/github/catvod/spider/appysv2/b/y;->c([B[BLorg/json/JSONObject;Lorg/json/JSONObject;Ljava/lang/String;)V

    const/16 v2, 0x9

    new-array v2, v2, [B

    .line 62
    fill-array-data v2, :array_12f6

    new-array v4, v8, [B

    fill-array-data v4, :array_1300

    invoke-static {v2, v4}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v2

    const/4 v4, 0x5

    new-array v4, v4, [B

    fill-array-data v4, :array_1308

    new-array v7, v8, [B

    fill-array-data v7, :array_1310

    invoke-static {v4, v7}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v0, v4}, Lorg/json/JSONObject;->optJSONArray(Ljava/lang/String;)Lorg/json/JSONArray;

    move-result-object v4

    invoke-direct {v1, v4}, Lcom/github/catvod/spider/AppYsV2;->j(Lorg/json/JSONArray;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v2, v4}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/16 v2, 0xc

    new-array v2, v2, [B

    fill-array-data v2, :array_1318

    new-array v4, v8, [B

    fill-array-data v4, :array_1322

    invoke-static {v2, v4}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v2

    new-array v4, v8, [B

    fill-array-data v4, :array_132a

    new-array v7, v8, [B

    fill-array-data v7, :array_1332

    invoke-static {v4, v7}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v0, v4}, Lorg/json/JSONObject;->optJSONArray(Ljava/lang/String;)Lorg/json/JSONArray;

    move-result-object v4

    invoke-direct {v1, v4}, Lcom/github/catvod/spider/AppYsV2;->j(Lorg/json/JSONArray;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v2, v4}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/16 v2, 0xb

    new-array v2, v2, [B

    fill-array-data v2, :array_133a

    new-array v4, v8, [B

    fill-array-data v4, :array_1344

    invoke-static {v2, v4}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v2

    const/4 v4, 0x5

    new-array v4, v4, [B

    fill-array-data v4, :array_134c

    new-array v7, v8, [B

    fill-array-data v7, :array_1354

    .line 63
    invoke-static {v4, v7, v0, v3, v2}, Lcom/github/catvod/spider/appysv2/b/y;->c([B[BLorg/json/JSONObject;Lorg/json/JSONObject;Ljava/lang/String;)V

    const/16 v2, 0x9

    new-array v2, v2, [B

    .line 64
    fill-array-data v2, :array_135c

    new-array v4, v8, [B

    fill-array-data v4, :array_1366

    invoke-static {v2, v4}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Lorg/json/JSONObject;->getJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v0

    invoke-virtual {v0}, Lorg/json/JSONObject;->keys()Ljava/util/Iterator;

    move-result-object v2

    :goto_b23
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    if-eqz v4, :cond_c5b

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/lang/String;

    iget-object v7, v1, Lcom/github/catvod/spider/AppYsV2;->a:Ljava/util/HashMap;

    invoke-virtual {v7, v4}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Ljava/util/ArrayList;

    if-nez v7, :cond_b43

    new-instance v7, Ljava/util/ArrayList;

    invoke-direct {v7}, Ljava/util/ArrayList;-><init>()V

    iget-object v8, v1, Lcom/github/catvod/spider/AppYsV2;->a:Ljava/util/HashMap;

    invoke-virtual {v8, v4, v7}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_b43
    invoke-virtual {v0, v4}, Lorg/json/JSONObject;->getJSONArray(Ljava/lang/String;)Lorg/json/JSONArray;

    move-result-object v8

    new-instance v9, Ljava/util/ArrayList;

    invoke-direct {v9}, Ljava/util/ArrayList;-><init>()V

    const/4 v10, 0x0

    :goto_b4d
    invoke-virtual {v8}, Lorg/json/JSONArray;->length()I

    move-result v11

    if-ge v10, v11, :cond_c36

    invoke-virtual {v8, v10}, Lorg/json/JSONArray;->getJSONObject(I)Lorg/json/JSONObject;

    move-result-object v11

    const/4 v12, 0x3

    new-array v12, v12, [B

    fill-array-data v12, :array_136e

    const/16 v13, 0x8

    new-array v14, v13, [B

    fill-array-data v14, :array_1374

    invoke-static {v12, v14}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v12

    invoke-virtual {v11, v12}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v12

    const/4 v14, 0x4

    new-array v14, v14, [B

    fill-array-data v14, :array_137c

    new-array v15, v13, [B

    fill-array-data v15, :array_1382

    invoke-static {v14, v15}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v14

    invoke-virtual {v12, v14}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v14

    if-eqz v14, :cond_bf1

    const/4 v14, 0x4

    new-array v14, v14, [B

    fill-array-data v14, :array_138a

    new-array v13, v13, [B

    fill-array-data v13, :array_1390

    invoke-static {v14, v13}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v13

    invoke-virtual {v12, v13}, Ljava/lang/String;->indexOf(Ljava/lang/String;)I

    move-result v13

    add-int/lit8 v13, v13, 0x4

    const/4 v14, 0x0

    invoke-virtual {v12, v14, v13}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v14

    invoke-virtual {v14}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v14

    invoke-virtual {v14}, Ljava/lang/String;->isEmpty()Z

    move-result v15

    if-nez v15, :cond_bae

    invoke-virtual {v7, v14}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result v15

    if-nez v15, :cond_bae

    invoke-virtual {v7, v14}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_bae
    new-instance v14, Ljava/lang/StringBuilder;

    invoke-direct {v14}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v15, 0x5

    new-array v15, v15, [B

    fill-array-data v15, :array_1398

    move-object/from16 p1, v0

    const/16 v0, 0x8

    new-array v1, v0, [B

    fill-array-data v1, :array_13a0

    invoke-static {v15, v1}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v11, v1}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v14, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v1, 0x1

    new-array v1, v1, [B

    const/16 v11, 0x1d

    const/4 v15, 0x0

    aput-byte v11, v1, v15

    new-array v0, v0, [B

    fill-array-data v0, :array_13a8

    invoke-static {v1, v0}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v14, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v12, v13}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v14, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v14}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    goto :goto_c2b

    :cond_bf1
    move-object/from16 p1, v0

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v1, 0x5

    new-array v1, v1, [B

    fill-array-data v1, :array_13b0

    const/16 v13, 0x8

    new-array v14, v13, [B

    fill-array-data v14, :array_13b8

    invoke-static {v1, v14}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v11, v1}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v1, 0x1

    new-array v1, v1, [B

    const/16 v11, -0x15

    const/4 v14, 0x0

    aput-byte v11, v1, v14

    new-array v11, v13, [B

    fill-array-data v11, :array_13c0

    invoke-static {v1, v11}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    :goto_c2b
    invoke-virtual {v9, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/lit8 v10, v10, 0x1

    move-object/from16 v1, p0

    move-object/from16 v0, p1

    goto/16 :goto_b4d

    :cond_c36
    move-object/from16 p1, v0

    invoke-virtual {v6, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    const/4 v0, 0x1

    new-array v0, v0, [B

    const/16 v1, -0x48

    const/4 v4, 0x0

    aput-byte v1, v0, v4

    const/16 v1, 0x8

    new-array v1, v1, [B

    fill-array-data v1, :array_13c8

    invoke-static {v0, v1}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0, v9}, Landroid/text/TextUtils;->join(Ljava/lang/CharSequence;Ljava/lang/Iterable;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v5, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    move-object/from16 v1, p0

    move-object/from16 v0, p1

    goto/16 :goto_b23

    :cond_c5b
    const/16 v2, 0x8

    const/16 v0, 0xd

    :goto_c5f
    new-array v0, v0, [B

    fill-array-data v0, :array_13d0

    new-array v1, v2, [B

    fill-array-data v1, :array_13dc

    invoke-static {v0, v1}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v0

    const/4 v1, 0x3

    new-array v1, v1, [B

    fill-array-data v1, :array_13e4

    new-array v4, v2, [B

    fill-array-data v4, :array_13ea

    invoke-static {v1, v4}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-static {v1, v6}, Landroid/text/TextUtils;->join(Ljava/lang/CharSequence;Ljava/lang/Iterable;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v3, v0, v1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/16 v0, 0xc

    new-array v0, v0, [B

    fill-array-data v0, :array_13f2

    new-array v1, v2, [B

    fill-array-data v1, :array_13fc

    invoke-static {v0, v1}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v0

    const/4 v1, 0x3

    new-array v1, v1, [B

    fill-array-data v1, :array_1404

    new-array v2, v2, [B

    fill-array-data v2, :array_140a

    invoke-static {v1, v2}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-static {v1, v5}, Landroid/text/TextUtils;->join(Ljava/lang/CharSequence;Ljava/lang/Iterable;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v3, v0, v1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    return-void

    :array_caa
    .array-data 1
        -0x19t
        -0x11t
        -0xat
        -0x2t
        0x33t
        0x77t
        0x52t
        -0x59t
        -0x19t
        -0x11t
        -0x11t
        -0x1t
    .end array-data

    :array_cb4
    .array-data 1
        -0x7at
        -0x61t
        -0x61t
        -0x30t
        0x43t
        0x1ft
        0x22t
        -0x78t
    .end array-data

    :array_cbc
    .array-data 1
        -0x1bt
        0x25t
        -0x38t
        -0x5dt
    .end array-data

    :array_cc2
    .array-data 1
        -0x7ft
        0x44t
        -0x44t
        -0x3et
        0x28t
        0x1at
        0x2bt
        0x77t
    .end array-data

    :array_cca
    .array-data 1
        0x56t
        -0x34t
        0x6bt
        0x6ct
        0x5ft
        0x3bt
    .end array-data

    nop

    :array_cd2
    .array-data 1
        0x20t
        -0x5dt
        0xft
        0x33t
        0x36t
        0x5ft
        0x5dt
        0x34t
    .end array-data

    :array_cda
    .array-data 1
        -0x4t
        0x4ct
        -0x7dt
        -0x74t
        -0x79t
        -0x47t
    .end array-data

    nop

    :array_ce2
    .array-data 1
        -0x76t
        0x23t
        -0x19t
        -0x2dt
        -0x12t
        -0x23t
        0x32t
        -0x56t
    .end array-data

    :array_cea
    .array-data 1
        -0x64t
        0x79t
        0x1bt
        -0x64t
        0x10t
        -0x42t
        -0x1bt
        -0x7bt
    .end array-data

    :array_cf2
    .array-data 1
        -0x16t
        0x16t
        0x7ft
        -0x3dt
        0x7et
        -0x21t
        -0x78t
        -0x20t
    .end array-data

    :array_cfa
    .array-data 1
        0x62t
        0x71t
        -0x48t
        0x27t
        -0x6dt
        -0x76t
        0x62t
        -0x25t
    .end array-data

    :array_d02
    .array-data 1
        0x14t
        0x1et
        -0x24t
        0x78t
        -0x3t
        -0x15t
        0xft
        -0x42t
    .end array-data

    :array_d0a
    .array-data 1
        0x2at
        0x32t
        -0x20t
        0x7t
        0x60t
        0x3at
        -0x5t
    .end array-data

    :array_d12
    .array-data 1
        0x5ct
        0x5dt
        -0x7ct
        0x58t
        0x10t
        0x53t
        -0x68t
        0x66t
    .end array-data

    :array_d1a
    .array-data 1
        -0x2at
        -0x52t
        -0x20t
        0x7et
        -0x1et
        -0x1dt
        -0x5at
    .end array-data

    :array_d22
    .array-data 1
        -0x60t
        -0x3ft
        -0x7ct
        0x21t
        -0x6et
        -0x76t
        -0x3bt
        0x6ft
    .end array-data

    :array_d2a
    .array-data 1
        -0x3bt
        -0x7at
        -0x6dt
        -0x3ct
        -0x63t
        0x51t
        0x23t
        -0x41t
        -0x2ct
    .end array-data

    nop

    :array_d34
    .array-data 1
        -0x4ft
        -0x1t
        -0x1dt
        -0x5ft
        -0x3et
        0x3ft
        0x42t
        -0x2et
    .end array-data

    :array_d3c
    .array-data 1
        -0x30t
        -0x71t
        0x17t
        0x1ft
        0x77t
        0x13t
        -0x25t
        -0x27t
        -0x2bt
    .end array-data

    nop

    :array_d46
    .array-data 1
        -0x5at
        -0x20t
        0x73t
        0x40t
        0x14t
        0x7ft
        -0x46t
        -0x56t
    .end array-data

    :array_d4e
    .array-data 1
        -0x24t
        0x63t
        -0x61t
        0x36t
        -0x2t
        -0x11t
        0x22t
        -0x22t
    .end array-data

    :array_d56
    .array-data 1
        -0x56t
        0xct
        -0x5t
        0x69t
        -0x79t
        -0x76t
        0x43t
        -0x54t
    .end array-data

    :array_d5e
    .array-data 1
        0x4ct
        -0x1ct
        0x6t
        -0x2at
        0x1t
        -0x3ct
        -0x79t
        0x2at
    .end array-data

    :array_d66
    .array-data 1
        0x3at
        -0x75t
        0x62t
        -0x77t
        0x78t
        -0x5ft
        -0x1at
        0x58t
    .end array-data

    :array_d6e
    .array-data 1
        0x55t
        -0x7et
        -0x50t
        -0x7at
        0x3t
        -0x15t
        0x5et
        -0x65t
    .end array-data

    :array_d76
    .array-data 1
        0x23t
        -0x13t
        -0x2ct
        -0x27t
        0x62t
        -0x67t
        0x3bt
        -0x6t
    .end array-data

    :array_d7e
    .array-data 1
        0x3dt
        0x53t
        -0x25t
        0x43t
        0x48t
        -0x8t
        -0x7ft
        0x7dt
    .end array-data

    :array_d86
    .array-data 1
        0x4bt
        0x3ct
        -0x41t
        0x1ct
        0x29t
        -0x76t
        -0x1ct
        0x1ct
    .end array-data

    :array_d8e
    .array-data 1
        -0x69t
        -0x7ct
        0x3ct
        -0x6ct
        -0x12t
        0x33t
        0x38t
        -0x7ct
        -0x6dt
        -0x80t
        0x2bt
    .end array-data

    :array_d98
    .array-data 1
        -0x1ft
        -0x15t
        0x58t
        -0x35t
        -0x64t
        0x56t
        0x55t
        -0x1bt
    .end array-data

    :array_da0
    .array-data 1
        0x46t
        -0x1at
        0x46t
        0x2t
        -0x11t
        0x2t
        0x62t
        0x5ct
        0x42t
        -0x1et
        0x51t
    .end array-data

    :array_daa
    .array-data 1
        0x30t
        -0x77t
        0x22t
        0x5dt
        -0x63t
        0x67t
        0xft
        0x3dt
    .end array-data

    :array_db2
    .array-data 1
        -0x77t
        0x49t
        0x6ct
        -0x23t
        -0x42t
        -0x53t
        -0x55t
        -0x56t
        -0x73t
    .end array-data

    nop

    :array_dbc
    .array-data 1
        -0x1t
        0x26t
        0x8t
        -0x7et
        -0x21t
        -0x32t
        -0x21t
        -0x3bt
    .end array-data

    :array_dc4
    .array-data 1
        0x2et
        -0x57t
        0x14t
        0x47t
        0x44t
        0x4ft
        0x54t
        0x70t
        0x2at
    .end array-data

    nop

    :array_dce
    .array-data 1
        0x58t
        -0x3at
        0x70t
        0x18t
        0x25t
        0x2ct
        0x20t
        0x1ft
    .end array-data

    :array_dd6
    .array-data 1
        -0x37t
        -0x75t
        0x1at
        -0x1bt
        0x27t
        0x6dt
        -0x54t
        0x14t
        -0x24t
        -0x70t
        0x11t
        -0x38t
    .end array-data

    :array_de0
    .array-data 1
        -0x41t
        -0x1ct
        0x7et
        -0x46t
        0x43t
        0x4t
        -0x22t
        0x71t
    .end array-data

    :array_de8
    .array-data 1
        -0x4ct
        0x4bt
        0x4t
        -0x75t
        -0x43t
        0x8t
        0x0t
        0x49t
        -0x5ft
        0x50t
        0xft
        -0x5at
    .end array-data

    :array_df2
    .array-data 1
        -0x3et
        0x24t
        0x60t
        -0x2ct
        -0x27t
        0x61t
        0x72t
        0x2ct
    .end array-data

    :array_dfa
    .array-data 1
        -0x5at
        -0x3dt
        -0x59t
        0x48t
        -0x75t
        -0x39t
        0x21t
        0x1bt
        -0x4bt
        -0x3et
        -0x49t
    .end array-data

    :array_e04
    .array-data 1
        -0x30t
        -0x54t
        -0x3dt
        0x17t
        -0x18t
        -0x58t
        0x4ft
        0x6ft
    .end array-data

    :array_e0c
    .array-data 1
        0x6ct
        0x69t
        -0x78t
        0x64t
        0x3et
        -0x7ct
        0x16t
        -0x3ft
        0x7ft
        0x68t
        -0x68t
    .end array-data

    :array_e16
    .array-data 1
        0x1at
        0x6t
        -0x14t
        0x3bt
        0x5dt
        -0x15t
        0x78t
        -0x4bt
    .end array-data

    :array_e1e
    .array-data 1
        0x38t
        -0xat
        0x2et
        0x1ct
        -0x10t
        0x38t
        0x50t
        0x66t
        0x39t
        -0x10t
        0x3et
        0x2bt
        -0x26t
        0x3at
        0x50t
        0x58t
        0x37t
        -0x4t
        0x38t
    .end array-data

    :array_e2c
    .array-data 1
        0x4et
        -0x67t
        0x4at
        0x43t
        -0x7bt
        0x4at
        0x3ct
        0x39t
    .end array-data

    :array_e34
    .array-data 1
        -0x3dt
        -0x3dt
        0x5at
        -0x15t
    .end array-data

    :array_e3a
    .array-data 1
        -0x60t
        -0x54t
        0x3et
        -0x72t
        -0x6dt
        -0x7t
        -0xct
        0x4dt
    .end array-data

    :array_e42
    .array-data 1
        -0x67t
        -0x7ft
        0x5ft
        0x6ft
    .end array-data

    :array_e48
    .array-data 1
        -0x9t
        -0x20t
        0x32t
        0xat
        0x3at
        0x37t
        0x3ct
        -0x35t
    .end array-data

    :array_e50
    .array-data 1
        0x42t
        0x37t
        0x58t
    .end array-data

    :array_e56
    .array-data 1
        0x37t
        0x45t
        0x34t
        0x70t
        0x20t
        0x7at
        0x6dt
        0x61t
    .end array-data

    :array_e5e
    .array-data 1
        0x75t
        0x48t
        -0x5dt
        0xbt
        0x2bt
        -0x43t
        0xct
        0x65t
        0x6ct
    .end array-data

    nop

    :array_e68
    .array-data 1
        0x5t
        0x29t
        -0x2ft
        0x78t
        0x4et
        -0x1et
        0x6dt
        0x15t
    .end array-data

    :array_e70
    .array-data 1
        -0x70t
        0x66t
        0x5et
        -0x7et
        -0x66t
    .end array-data

    nop

    :array_e78
    .array-data 1
        -0x18t
        0x1t
        0x3ft
        -0xet
        -0x16t
        0x9t
        -0x6dt
        0x52t
    .end array-data

    :array_e80
    .array-data 1
        0x21t
        0x2ct
        0x28t
        0x28t
    .end array-data

    :array_e86
    .array-data 1
        0x45t
        0x4dt
        0x5ct
        0x49t
        0x6dt
        0x25t
        0x55t
        -0x73t
    .end array-data

    :array_e8e
    .array-data 1
        0x21t
        -0x35t
        0x47t
        0x47t
        -0x6et
        -0x1t
        -0x4at
        -0x2at
    .end array-data

    :array_e96
    .array-data 1
        0x57t
        -0x5ct
        0x23t
        0x18t
        -0x5t
        -0x6ft
        -0x30t
        -0x47t
    .end array-data

    :array_e9e
    .array-data 1
        0x60t
        -0x24t
        0x1t
        0x47t
        0x7ft
        -0x23t
    .end array-data

    nop

    :array_ea6
    .array-data 1
        0x16t
        -0x4dt
        0x65t
        0x18t
        0x16t
        -0x47t
        0x1at
        -0x3ft
    .end array-data

    :array_eae
    .array-data 1
        -0x63t
        0x78t
        -0x22t
        0x1at
        -0x2ct
        -0x46t
    .end array-data

    nop

    :array_eb6
    .array-data 1
        -0x15t
        0x17t
        -0x46t
        0x45t
        -0x43t
        -0x22t
        -0x5ct
        0x31t
    .end array-data

    :array_ebe
    .array-data 1
        0x5ct
        -0x3at
        -0x4dt
        -0x2dt
        -0x3at
        0x60t
        -0x58t
        0x18t
    .end array-data

    :array_ec6
    .array-data 1
        0x2at
        -0x57t
        -0x29t
        -0x74t
        -0x58t
        0x1t
        -0x3bt
        0x7dt
    .end array-data

    :array_ece
    .array-data 1
        0x1t
        -0x80t
        -0x37t
        -0x35t
        0x32t
        0x6dt
        0x4ft
        0x67t
    .end array-data

    :array_ed6
    .array-data 1
        0x77t
        -0x11t
        -0x53t
        -0x6ct
        0x5ct
        0xct
        0x22t
        0x2t
    .end array-data

    :array_ede
    .array-data 1
        -0x4ct
        -0x72t
        0x45t
        0x1t
        0x21t
        -0x43t
        0x77t
    .end array-data

    :array_ee6
    .array-data 1
        -0x3et
        -0x1ft
        0x21t
        0x5et
        0x51t
        -0x2ct
        0x14t
        0x28t
    .end array-data

    :array_eee
    .array-data 1
        -0x63t
        0x49t
        0x7dt
        0x2bt
        0x1t
        0x4ft
        0x7at
    .end array-data

    :array_ef6
    .array-data 1
        -0x15t
        0x26t
        0x19t
        0x74t
        0x71t
        0x26t
        0x19t
        -0x30t
    .end array-data

    :array_efe
    .array-data 1
        -0x6at
        -0x19t
        -0x18t
        0x3ct
        -0x40t
        -0x7et
        0x66t
        0x7dt
        -0x79t
    .end array-data

    nop

    :array_f08
    .array-data 1
        -0x1et
        -0x62t
        -0x68t
        0x59t
        -0x61t
        -0x14t
        0x7t
        0x10t
    .end array-data

    :array_f10
    .array-data 1
        0x1ct
        -0x2et
        -0x31t
        -0x64t
        0x40t
        0x7ft
        -0x3dt
        0x16t
        0x19t
    .end array-data

    nop

    :array_f1a
    .array-data 1
        0x6at
        -0x43t
        -0x55t
        -0x3dt
        0x23t
        0x13t
        -0x5et
        0x65t
    .end array-data

    :array_f22
    .array-data 1
        -0x5ct
        -0x3t
        0x13t
        -0x13t
        -0x1dt
        -0x2at
        0x2et
        0x40t
    .end array-data

    :array_f2a
    .array-data 1
        -0x2et
        -0x6et
        0x77t
        -0x4et
        -0x66t
        -0x4dt
        0x4ft
        0x32t
    .end array-data

    :array_f32
    .array-data 1
        0x15t
        0x7ft
        0x1et
        -0x64t
        -0x23t
        0x7t
        0x1at
        0x5ct
    .end array-data

    :array_f3a
    .array-data 1
        0x63t
        0x10t
        0x7at
        -0x3dt
        -0x5ct
        0x62t
        0x7bt
        0x2et
    .end array-data

    :array_f42
    .array-data 1
        0x3bt
        -0x5bt
        0x30t
        -0x2t
        -0x45t
        -0x75t
        -0x10t
        0x64t
    .end array-data

    :array_f4a
    .array-data 1
        0x4dt
        -0x36t
        0x54t
        -0x5ft
        -0x26t
        -0x7t
        -0x6bt
        0x5t
    .end array-data

    :array_f52
    .array-data 1
        -0x77t
        -0x1ct
        0x5ct
        -0x44t
        0x47t
        -0x35t
        0x6et
        0x4dt
    .end array-data

    :array_f5a
    .array-data 1
        -0x1t
        -0x75t
        0x38t
        -0x1dt
        0x26t
        -0x47t
        0xbt
        0x2ct
    .end array-data

    :array_f62
    .array-data 1
        0x7ct
        0x2ct
        0x3dt
        0x16t
        0xbt
        0x45t
        -0x3ct
        -0x2ct
        0x78t
        0x28t
        0x2at
    .end array-data

    :array_f6c
    .array-data 1
        0xat
        0x43t
        0x59t
        0x49t
        0x79t
        0x20t
        -0x57t
        -0x4bt
    .end array-data

    :array_f74
    .array-data 1
        0x28t
        0x59t
        -0x11t
        -0x38t
        0x10t
        -0x71t
        0x1dt
        0x23t
        0x2ct
        0x5dt
        -0x8t
    .end array-data

    :array_f7e
    .array-data 1
        0x5et
        0x36t
        -0x75t
        -0x69t
        0x62t
        -0x16t
        0x70t
        0x42t
    .end array-data

    :array_f86
    .array-data 1
        -0x6ct
        0x27t
        -0x74t
        0x5ct
        -0x5bt
        -0x59t
        -0x35t
        -0x7dt
        -0x70t
    .end array-data

    nop

    :array_f90
    .array-data 1
        -0x1et
        0x48t
        -0x18t
        0x3t
        -0x3ct
        -0x3ct
        -0x41t
        -0x14t
    .end array-data

    :array_f98
    .array-data 1
        0x6t
        -0x47t
        -0xdt
        0x78t
        0x6bt
        0x9t
        0x13t
        -0x40t
        0x2t
    .end array-data

    nop

    :array_fa2
    .array-data 1
        0x70t
        -0x2at
        -0x69t
        0x27t
        0xat
        0x6at
        0x67t
        -0x51t
    .end array-data

    :array_faa
    .array-data 1
        -0x60t
        -0xft
        -0x1ct
        0x7at
        0xdt
        0x19t
        -0xdt
        -0x39t
        -0x4bt
        -0x16t
        -0x11t
        0x57t
    .end array-data

    :array_fb4
    .array-data 1
        -0x2at
        -0x62t
        -0x80t
        0x25t
        0x69t
        0x70t
        -0x7ft
        -0x5et
    .end array-data

    :array_fbc
    .array-data 1
        0x1ct
        0x29t
        -0x3et
        -0x47t
        -0x51t
        0xdt
        -0x11t
        0x24t
        0x9t
        0x32t
        -0x37t
        -0x6ct
    .end array-data

    :array_fc6
    .array-data 1
        0x6at
        0x46t
        -0x5at
        -0x1at
        -0x35t
        0x64t
        -0x63t
        0x41t
    .end array-data

    :array_fce
    .array-data 1
        -0x64t
        -0x65t
        0x29t
        -0x64t
        0x2dt
        0x6t
        0x42t
        -0x74t
        -0x71t
        -0x66t
        0x39t
    .end array-data

    :array_fd8
    .array-data 1
        -0x16t
        -0xct
        0x4dt
        -0x3dt
        0x4et
        0x69t
        0x2ct
        -0x8t
    .end array-data

    :array_fe0
    .array-data 1
        -0x2ft
        -0x1bt
        -0x14t
        -0x52t
        -0x34t
        0x52t
        -0x4dt
        -0x19t
        -0x3et
        -0x1ct
        -0x4t
    .end array-data

    :array_fea
    .array-data 1
        -0x59t
        -0x76t
        -0x78t
        -0xft
        -0x51t
        0x3dt
        -0x23t
        -0x6dt
    .end array-data

    :array_ff2
    .array-data 1
        0x12t
        -0x2et
        -0x22t
        -0x78t
        0x5dt
        -0x5dt
        -0x4ct
        0x7bt
        0x13t
        -0x2ct
        -0x32t
        -0x41t
        0x77t
        -0x5ft
        -0x4ct
        0x45t
        0x1dt
        -0x28t
        -0x38t
    .end array-data

    :array_1000
    .array-data 1
        0x64t
        -0x43t
        -0x46t
        -0x29t
        0x28t
        -0x2ft
        -0x28t
        0x24t
    .end array-data

    :array_1008
    .array-data 1
        -0x9t
        0x2et
        0x58t
        -0x4ft
    .end array-data

    :array_100e
    .array-data 1
        -0x6ct
        0x41t
        0x3ct
        -0x2ct
        0x3et
        0x68t
        0x29t
        0x4ct
    .end array-data

    :array_1016
    .array-data 1
        -0x5t
        0x1ft
        -0x20t
        0x5ft
    .end array-data

    :array_101c
    .array-data 1
        -0x6bt
        0x7et
        -0x73t
        0x3at
        -0x2et
        -0x20t
        -0x73t
        0x23t
    .end array-data

    :array_1024
    .array-data 1
        0x4dt
        0x12t
        -0x56t
    .end array-data

    :array_102a
    .array-data 1
        0x38t
        0x60t
        -0x3at
        -0x19t
        0x75t
        0x42t
        -0x67t
        0x58t
    .end array-data

    :array_1032
    .array-data 1
        0x1et
        0x5et
        -0x70t
        0x7ct
        -0x43t
        -0x6at
        -0x46t
        0x7bt
        0x7t
    .end array-data

    nop

    :array_103c
    .array-data 1
        0x6et
        0x3ft
        -0x1et
        0xft
        -0x28t
        -0x37t
        -0x25t
        0xbt
    .end array-data

    :array_1044
    .array-data 1
        -0x67t
        0x35t
        0x50t
        0x72t
    .end array-data

    :array_104a
    .array-data 1
        -0x49t
        0x43t
        0x3ft
        0x16t
        -0x22t
        -0x71t
        0x2et
        0xdt
    .end array-data

    :array_1052
    .array-data 1
        0x59t
        -0x30t
        0x2dt
        -0x5ct
    .end array-data

    :array_1058
    .array-data 1
        0x3dt
        -0x4ft
        0x59t
        -0x3bt
        0x4bt
        0x2at
        0x7dt
        -0x4et
    .end array-data

    :array_1060
    .array-data 1
        0x31t
        -0x3at
        0x4et
        -0x1et
        -0x3dt
        0xat
    .end array-data

    nop

    :array_1068
    .array-data 1
        0x47t
        -0x57t
        0x2at
        -0x43t
        -0x56t
        0x6et
        -0x58t
        0x4t
    .end array-data

    :array_1070
    .array-data 1
        -0x2at
        0x30t
        -0x2dt
        0x3et
        0x55t
        -0x36t
    .end array-data

    nop

    :array_1078
    .array-data 1
        -0x60t
        0x5ft
        -0x49t
        0x61t
        0x3ct
        -0x52t
        0x79t
        0x13t
    .end array-data

    :array_1080
    .array-data 1
        -0x5et
        0x13t
        0x6at
        0x15t
        -0xct
        0x7et
        0x45t
        0x58t
    .end array-data

    :array_1088
    .array-data 1
        -0x2ct
        0x7ct
        0xet
        0x4at
        -0x66t
        0x1ft
        0x28t
        0x3dt
    .end array-data

    :array_1090
    .array-data 1
        -0x50t
        0x2et
        0x4dt
        0x43t
        -0x1ct
        0x1ft
        -0x1t
        0x23t
    .end array-data

    :array_1098
    .array-data 1
        -0x3at
        0x41t
        0x29t
        0x1ct
        -0x76t
        0x7et
        -0x6et
        0x46t
    .end array-data

    :array_10a0
    .array-data 1
        -0x2at
        -0x5dt
        -0x65t
        -0x7ct
        -0x5at
        -0x63t
        0xct
    .end array-data

    :array_10a8
    .array-data 1
        -0x60t
        -0x34t
        -0x1t
        -0x25t
        -0x2at
        -0xct
        0x6ft
        -0x43t
    .end array-data

    :array_10b0
    .array-data 1
        -0x52t
        -0x40t
        -0x13t
        0x32t
        0xft
        0x37t
        0x5et
    .end array-data

    :array_10b8
    .array-data 1
        -0x28t
        -0x51t
        -0x77t
        0x6dt
        0x7ft
        0x5et
        0x3dt
        0x5ft
    .end array-data

    :array_10c0
    .array-data 1
        0x8t
        -0x67t
        -0x6at
        -0x29t
        0x7et
        0x62t
        -0x6ct
        0x7bt
        0x19t
    .end array-data

    nop

    :array_10ca
    .array-data 1
        0x7ct
        -0x20t
        -0x1at
        -0x4et
        0x21t
        0xct
        -0xbt
        0x16t
    .end array-data

    :array_10d2
    .array-data 1
        0x66t
        0x8t
        -0x37t
        -0x36t
        -0x33t
        0x41t
        -0x48t
        0x12t
        0x63t
    .end array-data

    nop

    :array_10dc
    .array-data 1
        0x10t
        0x67t
        -0x53t
        -0x6bt
        -0x52t
        0x2dt
        -0x27t
        0x61t
    .end array-data

    :array_10e4
    .array-data 1
        0x60t
        0x19t
        -0x27t
        -0x45t
        -0x59t
        -0x48t
        -0x1dt
        -0x6t
    .end array-data

    :array_10ec
    .array-data 1
        0x16t
        0x76t
        -0x43t
        -0x1ct
        -0x22t
        -0x23t
        -0x7et
        -0x78t
    .end array-data

    :array_10f4
    .array-data 1
        -0xct
        0x78t
        0x22t
        -0x6bt
        -0x3et
        0x43t
        0x50t
        0x61t
    .end array-data

    :array_10fc
    .array-data 1
        -0x7et
        0x17t
        0x46t
        -0x36t
        -0x45t
        0x26t
        0x31t
        0x13t
    .end array-data

    :array_1104
    .array-data 1
        0x39t
        -0x1ct
        -0x20t
        -0x7bt
        0xft
        0x52t
        0x50t
        -0x5t
    .end array-data

    :array_110c
    .array-data 1
        0x4ft
        -0x75t
        -0x7ct
        -0x26t
        0x6et
        0x20t
        0x35t
        -0x66t
    .end array-data

    :array_1114
    .array-data 1
        0x45t
        0x60t
        -0x6et
        -0x3et
        0x72t
        -0x45t
        0x1t
        0x59t
    .end array-data

    :array_111c
    .array-data 1
        0x33t
        0xft
        -0xat
        -0x63t
        0x13t
        -0x37t
        0x64t
        0x38t
    .end array-data

    :array_1124
    .array-data 1
        0x24t
        0x58t
        0x6et
        -0x75t
        0x2at
        0xft
        -0x70t
        0x42t
        0x20t
        0x5ct
        0x79t
    .end array-data

    :array_112e
    .array-data 1
        0x52t
        0x37t
        0xat
        -0x2ct
        0x58t
        0x6at
        -0x3t
        0x23t
    .end array-data

    :array_1136
    .array-data 1
        -0xct
        0x7ct
        0x29t
        0x1ct
        0x3at
        -0x1ft
        0x31t
        -0x23t
        -0x10t
        0x78t
        0x3et
    .end array-data

    :array_1140
    .array-data 1
        -0x7et
        0x13t
        0x4dt
        0x43t
        0x48t
        -0x7ct
        0x5ct
        -0x44t
    .end array-data

    :array_1148
    .array-data 1
        -0x6et
        0x39t
        0x1bt
        -0x3et
        -0x3ft
        0x53t
        0x4ft
        0x4at
        -0x6at
    .end array-data

    nop

    :array_1152
    .array-data 1
        -0x1ct
        0x56t
        0x7ft
        -0x63t
        -0x60t
        0x30t
        0x3bt
        0x25t
    .end array-data

    :array_115a
    .array-data 1
        -0x75t
        -0x6bt
        -0x5ct
        0xct
        -0x1at
        -0x37t
        -0x5dt
        -0x35t
        -0x71t
    .end array-data

    nop

    :array_1164
    .array-data 1
        -0x3t
        -0x6t
        -0x40t
        0x53t
        -0x79t
        -0x56t
        -0x29t
        -0x5ct
    .end array-data

    :array_116c
    .array-data 1
        0x64t
        -0x34t
        0x3et
        -0x2ft
        0x29t
        0x54t
        -0x22t
        0x4ct
        0x71t
        -0x29t
        0x35t
        -0x4t
    .end array-data

    :array_1176
    .array-data 1
        0x12t
        -0x5dt
        0x5at
        -0x72t
        0x4dt
        0x3dt
        -0x54t
        0x29t
    .end array-data

    :array_117e
    .array-data 1
        0x14t
        0x28t
        -0x38t
        -0x55t
        0x56t
        -0x2ft
        0x1at
        0x26t
        0x1t
        0x33t
        -0x3dt
        -0x7at
    .end array-data

    :array_1188
    .array-data 1
        0x62t
        0x47t
        -0x54t
        -0xct
        0x32t
        -0x48t
        0x68t
        0x43t
    .end array-data

    :array_1190
    .array-data 1
        -0x5bt
        0x3et
        0x53t
        0x28t
        0x60t
        0x4ct
        -0x58t
        -0x71t
        -0x4at
        0x3ft
        0x43t
    .end array-data

    :array_119a
    .array-data 1
        -0x2dt
        0x51t
        0x37t
        0x77t
        0x3t
        0x23t
        -0x3at
        -0x5t
    .end array-data

    :array_11a2
    .array-data 1
        -0x5ft
        0x61t
        -0x3bt
        -0x53t
        0x10t
        -0x45t
        0x11t
        0x7at
        -0x4et
        0x60t
        -0x2bt
    .end array-data

    :array_11ac
    .array-data 1
        -0x29t
        0xet
        -0x5ft
        -0xet
        0x73t
        -0x2ct
        0x7ft
        0xet
    .end array-data

    :array_11b4
    .array-data 1
        -0x5bt
        0x9t
        0x5bt
        0x43t
        -0x1bt
        0x78t
        0x24t
        -0x7t
        -0x74t
        0xat
        0x56t
        0x6ft
        -0x1ft
    .end array-data

    nop

    :array_11c0
    .array-data 1
        -0x2dt
        0x66t
        0x3ft
        0x1ct
        -0x6bt
        0x14t
        0x45t
        -0x80t
    .end array-data

    :array_11c8
    .array-data 1
        -0x2ct
        -0x53t
        0x60t
        -0xbt
        -0x19t
        -0x5dt
        -0x13t
        -0x55t
        -0x36t
        -0x59t
        0x6et
    .end array-data

    :array_11d2
    .array-data 1
        -0x5ct
        -0x3ft
        0x1t
        -0x74t
        -0x7et
        -0x2ft
        -0x4et
        -0x3et
    .end array-data

    :array_11da
    .array-data 1
        0x3dt
        0x43t
        0x52t
        -0x4dt
    .end array-data

    :array_11e0
    .array-data 1
        0x5bt
        0x31t
        0x3dt
        -0x22t
        -0x5bt
        -0x11t
        -0x5bt
        0x6bt
    .end array-data

    :array_11e8
    .array-data 1
        0x25t
        -0xdt
        0x26t
        0x23t
        0x70t
        0x3ct
        0x6ft
        0x31t
        0x3bt
        -0x7t
        0x28t
    .end array-data

    :array_11f2
    .array-data 1
        0x55t
        -0x61t
        0x47t
        0x5at
        0x15t
        0x4et
        0x30t
        0x58t
    .end array-data

    :array_11fa
    .array-data 1
        0x73t
        -0x36t
        -0x25t
        0x28t
    .end array-data

    :array_1200
    .array-data 1
        0x0t
        -0x5et
        -0x4ct
        0x5ft
        0x7bt
        -0xat
        -0x48t
        0x36t
    .end array-data

    :array_1208
    .array-data 1
        -0x73t
        -0x30t
        0x52t
    .end array-data

    :array_120e
    .array-data 1
        -0x8t
        -0x5et
        0x3et
        -0x35t
        -0x4dt
        0x28t
        -0x29t
        -0x77t
    .end array-data

    :array_1216
    .array-data 1
        0x7ft
        0x2t
        0x5ft
        0x5at
        -0x19t
        0x5et
    .end array-data

    nop

    :array_121e
    .array-data 1
        0x9t
        0x6dt
        0x3bt
        0x5t
        -0x72t
        0x3at
        -0x7dt
        0x75t
    .end array-data

    :array_1226
    .array-data 1
        0x58t
        0x6et
        -0xct
        0x39t
        -0x5et
        0x74t
    .end array-data

    nop

    :array_122e
    .array-data 1
        0x2et
        0x1t
        -0x70t
        0x66t
        -0x35t
        0x10t
        -0x80t
        -0x70t
    .end array-data

    :array_1236
    .array-data 1
        0x74t
        0x41t
        -0x34t
        -0xct
        -0x24t
        -0x75t
        -0x45t
        -0x69t
    .end array-data

    :array_123e
    .array-data 1
        0x2t
        0x2et
        -0x58t
        -0x55t
        -0x4et
        -0x16t
        -0x2at
        -0xet
    .end array-data

    :array_1246
    .array-data 1
        0x5et
        -0x6ft
        0x5bt
        -0x60t
        0x3bt
    .end array-data

    nop

    :array_124e
    .array-data 1
        0x2at
        -0x8t
        0x2ft
        -0x34t
        0x5et
        -0x51t
        -0x5ft
        0x8t
    .end array-data

    :array_1256
    .array-data 1
        0x19t
        -0x1t
        -0x3ft
        -0x78t
        0x63t
        0x44t
        -0x7dt
    .end array-data

    :array_125e
    .array-data 1
        0x6ft
        -0x70t
        -0x5bt
        -0x29t
        0x13t
        0x2dt
        -0x20t
        0x61t
    .end array-data

    :array_1266
    .array-data 1
        0x7ft
        -0x5dt
        -0x6ct
        0x32t
        -0xat
        -0x26t
        0x4t
    .end array-data

    :array_126e
    .array-data 1
        0x16t
        -0x32t
        -0xdt
        0x6dt
        -0x7dt
        -0x58t
        0x68t
        -0x6ct
    .end array-data

    :array_1276
    .array-data 1
        0x1bt
        0x62t
        0x77t
        0x3ft
        -0x43t
        -0x70t
        0x7bt
        -0x2t
        0xat
    .end array-data

    nop

    :array_1280
    .array-data 1
        0x6ft
        0x1bt
        0x7t
        0x5at
        -0x1et
        -0x2t
        0x1at
        -0x6dt
    .end array-data

    :array_1288
    .array-data 1
        -0x75t
        0x55t
        0x0t
        0x31t
    .end array-data

    :array_128e
    .array-data 1
        -0x1t
        0x2ct
        0x70t
        0x54t
        0x2t
        0x48t
        0x2et
        0x77t
    .end array-data

    :array_1296
    .array-data 1
        -0x68t
        0x19t
        -0x77t
        -0x76t
        0x77t
        0x0t
        -0x79t
        -0xft
    .end array-data

    :array_129e
    .array-data 1
        -0x12t
        0x76t
        -0x13t
        -0x2bt
        0xet
        0x65t
        -0x1at
        -0x7dt
    .end array-data

    :array_12a6
    .array-data 1
        -0xft
        -0x1ft
        0x60t
        -0x41t
        -0x23t
        -0x12t
        0x0t
    .end array-data

    :array_12ae
    .array-data 1
        -0x7ft
        -0x6ct
        0x2t
        -0x35t
        -0x4ct
        -0x7dt
        0x65t
        0x6bt
    .end array-data

    :array_12b6
    .array-data 1
        0x2dt
        -0xct
        0x55t
        -0x6t
        -0x57t
        -0x6at
        -0x80t
        -0x22t
    .end array-data

    :array_12be
    .array-data 1
        0x5bt
        -0x65t
        0x31t
        -0x5bt
        -0x38t
        -0x1ct
        -0x1bt
        -0x41t
    .end array-data

    :array_12c6
    .array-data 1
        -0x6bt
        -0x3t
        0x7t
        -0x36t
    .end array-data

    :array_12cc
    .array-data 1
        -0xct
        -0x71t
        0x62t
        -0x55t
        0x31t
        -0x59t
        0xct
        0x7bt
    .end array-data

    :array_12d4
    .array-data 1
        -0x56t
        -0x2et
        0x67t
        0x76t
        -0x35t
        0x7ft
        0x23t
        0x52t
        -0x52t
        -0x2at
        0x70t
    .end array-data

    :array_12de
    .array-data 1
        -0x24t
        -0x43t
        0x3t
        0x29t
        -0x47t
        0x1at
        0x4et
        0x33t
    .end array-data

    :array_12e6
    .array-data 1
        -0x2bt
        0x1at
        -0x6bt
        0x76t
        -0x36t
    .end array-data

    nop

    :array_12ee
    .array-data 1
        -0x5ft
        0x68t
        -0x20t
        0x18t
        -0x5ft
        0x1ft
        0x36t
        -0xdt
    .end array-data

    :array_12f6
    .array-data 1
        -0x33t
        0x71t
        -0x80t
        -0x5at
        0x0t
        -0x7bt
        0x14t
        0x6at
        -0x37t
    .end array-data

    nop

    :array_1300
    .array-data 1
        -0x45t
        0x1et
        -0x1ct
        -0x7t
        0x61t
        -0x1at
        0x60t
        0x5t
    .end array-data

    :array_1308
    .array-data 1
        -0x5dt
        0x16t
        -0x67t
        0xet
        -0x3ft
    .end array-data

    nop

    :array_1310
    .array-data 1
        -0x3et
        0x75t
        -0x13t
        0x61t
        -0x4dt
        -0x12t
        0x7at
        0x72t
    .end array-data

    :array_1318
    .array-data 1
        0x7at
        0x53t
        -0x37t
        0x4dt
        -0x1t
        -0xbt
        -0x43t
        0x68t
        0x6ft
        0x48t
        -0x3et
        0x60t
    .end array-data

    :array_1322
    .array-data 1
        0xct
        0x3ct
        -0x53t
        0x12t
        -0x65t
        -0x64t
        -0x31t
        0xdt
    .end array-data

    :array_132a
    .array-data 1
        -0x26t
        -0x1ct
        -0x29t
        -0x7et
        -0x7bt
        -0x7ct
        0x79t
        -0x1ct
    .end array-data

    :array_1332
    .array-data 1
        -0x42t
        -0x73t
        -0x5bt
        -0x19t
        -0x1at
        -0x10t
        0x16t
        -0x6at
    .end array-data

    :array_133a
    .array-data 1
        -0x16t
        -0x31t
        -0x38t
        0x7dt
        0x47t
        0x64t
        -0x25t
        -0x4at
        -0x7t
        -0x32t
        -0x28t
    .end array-data

    :array_1344
    .array-data 1
        -0x64t
        -0x60t
        -0x54t
        0x22t
        0x24t
        0xbt
        -0x4bt
        -0x3et
    .end array-data

    :array_134c
    .array-data 1
        -0x31t
        -0x19t
        0x76t
        0x44t
        0x0t
    .end array-data

    nop

    :array_1354
    .array-data 1
        -0x5at
        -0x77t
        0x2t
        0x36t
        0x6ft
        -0x6et
        0x4ft
        0x25t
    .end array-data

    :array_135c
    .array-data 1
        0x44t
        0x39t
        0x44t
        -0x53t
        -0x48t
        -0x68t
        0x1at
        -0x6et
        0x46t
    .end array-data

    nop

    :array_1366
    .array-data 1
        0x32t
        0x50t
        0x20t
        -0x38t
        -0x29t
        -0xct
        0x73t
        -0x1ft
    .end array-data

    :array_136e
    .array-data 1
        0x4dt
        -0x60t
        -0x3ft
    .end array-data

    :array_1374
    .array-data 1
        0x38t
        -0x2et
        -0x53t
        -0x25t
        0x3ct
        -0x73t
        0x51t
        -0x62t
    .end array-data

    :array_137c
    .array-data 1
        -0x24t
        -0x68t
        0x36t
        -0x56t
    .end array-data

    :array_1382
    .array-data 1
        -0x57t
        -0x16t
        0x5at
        -0x69t
        0x1at
        -0x69t
        0x3dt
        0x63t
    .end array-data

    :array_138a
    .array-data 1
        0x1et
        0x46t
        0x6at
        0x38t
    .end array-data

    :array_1390
    .array-data 1
        0x6bt
        0x34t
        0x6t
        0x5t
        0x4ct
        0x14t
        0x56t
        -0x1t
    .end array-data

    :array_1398
    .array-data 1
        0x68t
        -0xdt
        0x35t
        0x3et
        -0x1ft
    .end array-data

    nop

    :array_13a0
    .array-data 1
        0x1ct
        -0x66t
        0x41t
        0x52t
        -0x7ct
        0x0t
        0x21t
        0x37t
    .end array-data

    :array_13a8
    .array-data 1
        0x39t
        -0x3dt
        -0x5et
        -0x69t
        -0x7dt
        0xct
        0x5t
        -0x45t
    .end array-data

    :array_13b0
    .array-data 1
        -0x61t
        0x46t
        0x38t
        0x78t
        -0x54t
    .end array-data

    nop

    :array_13b8
    .array-data 1
        -0x15t
        0x2ft
        0x4ct
        0x14t
        -0x37t
        0x6dt
        -0x13t
        -0x5at
    .end array-data

    :array_13c0
    .array-data 1
        -0x31t
        -0x3t
        0x4bt
        -0x13t
        -0x46t
        -0x11t
        -0x78t
        -0x17t
    .end array-data

    :array_13c8
    .array-data 1
        -0x65t
        0x51t
        -0x5bt
        0xat
        0x11t
        0x74t
        0x67t
        0x60t
    .end array-data

    :array_13d0
    .array-data 1
        -0x10t
        0x51t
        -0x5ft
        0x77t
        -0x6ft
        -0x66t
        0x8t
        -0x4bt
        -0x27t
        0x58t
        -0x49t
        0x47t
        -0x74t
    .end array-data

    nop

    :array_13dc
    .array-data 1
        -0x7at
        0x3et
        -0x3bt
        0x28t
        -0x1ft
        -0xat
        0x69t
        -0x34t
    .end array-data

    :array_13e4
    .array-data 1
        -0x45t
        0x3et
        -0x25t
    .end array-data

    :array_13ea
    .array-data 1
        -0x61t
        0x1at
        -0x1t
        -0x16t
        0x49t
        -0x5et
        0x67t
        0x17t
    .end array-data

    :array_13f2
    .array-data 1
        -0x5at
        -0x7ct
        0x34t
        0x8t
        0xdt
        -0x20t
        0x47t
        -0x34t
        -0x71t
        -0x62t
        0x22t
        0x3bt
    .end array-data

    :array_13fc
    .array-data 1
        -0x30t
        -0x15t
        0x50t
        0x57t
        0x7dt
        -0x74t
        0x26t
        -0x4bt
    .end array-data

    :array_1404
    .array-data 1
        0x41t
        0x2bt
        0x41t
    .end array-data

    :array_140a
    .array-data 1
        0x65t
        0xft
        0x65t
        0x6bt
        0x45t
        -0x38t
        -0x55t
        0x1dt
    .end array-data
.end method

.method private c()Ljava/lang/String;
    .registers 4

    iget-object v0, p0, Lcom/github/catvod/spider/AppYsV2;->b:[Ljava/lang/String;

    if-eqz v0, :cond_11

    array-length v1, v0

    const/4 v2, 0x1

    if-ge v1, v2, :cond_9

    goto :goto_11

    :cond_9
    const/4 v1, 0x0

    aget-object v0, v0, v1

    invoke-virtual {v0}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v0

    return-object v0

    :cond_11
    :goto_11
    const-string v0, ""

    return-object v0
.end method

.method public static fixJsonVodHeader(Lorg/json/JSONObject;Ljava/lang/String;Ljava/lang/String;)Lorg/json/JSONObject;
    .registers 10

    if-nez p0, :cond_7

    new-instance p0, Lorg/json/JSONObject;

    invoke-direct {p0}, Lorg/json/JSONObject;-><init>()V

    :cond_7
    const/16 v0, 0xc

    new-array v1, v0, [B

    fill-array-data v1, :array_f2

    const/16 v2, 0x8

    new-array v3, v2, [B

    fill-array-data v3, :array_fc

    invoke-static {v1, v3}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {p1, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    const-string v3, "67"

    invoke-static {v3}, Lcom/github/catvod/spider/appysv2/KKB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    const/4 v4, 0x7

    const/16 v5, 0xa

    if-eqz v1, :cond_5a

    new-array p1, v4, [B

    fill-array-data p1, :array_104

    new-array p2, v2, [B

    fill-array-data p2, :array_10c

    invoke-static {p1, p2}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p0, p1, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    new-array p1, v5, [B

    fill-array-data p1, :array_114

    new-array p2, v2, [B

    fill-array-data p2, :array_11e

    invoke-static {p1, p2}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object p1

    new-array p2, v0, [B

    fill-array-data p2, :array_126

    new-array v0, v2, [B

    fill-array-data v0, :array_130

    invoke-static {p2, v0}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object p2

    :goto_55
    invoke-virtual {p0, p1, p2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    goto/16 :goto_f1

    :cond_5a
    new-array v1, v5, [B

    fill-array-data v1, :array_138

    new-array v6, v2, [B

    fill-array-data v6, :array_142

    invoke-static {v1, v6}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {p2, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result p2

    if-eqz p2, :cond_9c

    new-array p1, v4, [B

    fill-array-data p1, :array_14a

    new-array p2, v2, [B

    fill-array-data p2, :array_152

    invoke-static {p1, p2}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p0, p1, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    new-array p1, v5, [B

    fill-array-data p1, :array_15a

    new-array p2, v2, [B

    fill-array-data p2, :array_164

    invoke-static {p1, p2}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object p1

    new-array p2, v0, [B

    fill-array-data p2, :array_16c

    new-array v0, v2, [B

    fill-array-data v0, :array_176

    invoke-static {p2, v0}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object p2

    goto :goto_55

    :cond_9c
    new-array p2, v2, [B

    fill-array-data p2, :array_17e

    new-array v0, v2, [B

    fill-array-data v0, :array_186

    invoke-static {p2, v0}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object p2

    invoke-virtual {p1, p2}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result p1

    if-eqz p1, :cond_f1

    new-array p1, v4, [B

    fill-array-data p1, :array_18e

    new-array p2, v2, [B

    fill-array-data p2, :array_196

    invoke-static {p1, p2}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object p1

    const/16 p2, 0x1a

    new-array p2, p2, [B

    fill-array-data p2, :array_19e

    new-array v0, v2, [B

    fill-array-data v0, :array_1b0

    invoke-static {p2, v0}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object p2

    invoke-virtual {p0, p1, p2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    new-array p1, v5, [B

    fill-array-data p1, :array_1b8

    new-array p2, v2, [B

    fill-array-data p2, :array_1c2

    invoke-static {p1, p2}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object p1

    const/16 p2, 0x70

    new-array p2, p2, [B

    fill-array-data p2, :array_1ca

    new-array v0, v2, [B

    fill-array-data v0, :array_206

    invoke-static {p2, v0}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object p2

    goto/16 :goto_55

    :cond_f1
    :goto_f1
    return-object p0

    :array_f2
    .array-data 1
        -0x6ft
        0x6ct
        -0x1et
        -0x79t
        -0x28t
        0x32t
        0x7ct
        -0x59t
        -0x38t
        0x78t
        -0x6t
        -0x3ct
    .end array-data

    :array_fc
    .array-data 1
        -0x1at
        0x1bt
        -0x6bt
        -0x57t
        -0x4bt
        0x55t
        0x8t
        -0x2ft
    .end array-data

    :array_104
    .array-data 1
        -0x5t
        0x2bt
        0x47t
        -0x15t
        -0x6et
        0x5ft
        -0xct
    .end array-data

    :array_10c
    .array-data 1
        -0x57t
        0x4et
        0x21t
        -0x72t
        -0x20t
        0x3at
        -0x7at
        0x3et
    .end array-data

    :array_114
    .array-data 1
        0x71t
        -0x6ct
        0x41t
        -0x68t
        0x15t
        -0x24t
        0x60t
        0x2et
        0x4at
        -0x6dt
    .end array-data

    nop

    :array_11e
    .array-data 1
        0x24t
        -0x19t
        0x24t
        -0x16t
        0x38t
        -0x63t
        0x7t
        0x4bt
    .end array-data

    :array_126
    .array-data 1
        -0x43t
        0x5t
        0x67t
        0x47t
        -0x6at
        0x1ft
        -0x4ct
        -0x67t
        -0x4et
        0x7dt
        0x26t
        0xdt
    .end array-data

    :array_130
    .array-data 1
        -0x63t
        0x48t
        0x8t
        0x3dt
        -0x1t
        0x73t
        -0x28t
        -0x8t
    .end array-data

    :array_138
    .array-data 1
        0x65t
        -0x7at
        -0x61t
        0x4bt
        -0x49t
        0x6et
        0x56t
        0x3bt
        0x65t
        -0x67t
    .end array-data

    nop

    :array_142
    .array-data 1
        0x11t
        -0x11t
        -0x15t
        0x2at
        -0x27t
        0x40t
        0x3bt
        0x5ct
    .end array-data

    :array_14a
    .array-data 1
        -0x69t
        -0x40t
        -0x10t
        -0x38t
        0x71t
        0x4dt
        0x79t
    .end array-data

    :array_152
    .array-data 1
        -0x3bt
        -0x5bt
        -0x6at
        -0x53t
        0x3t
        0x28t
        0xbt
        -0x11t
    .end array-data

    :array_15a
    .array-data 1
        0x2et
        0x63t
        0x15t
        0x14t
        -0x2ct
        -0x12t
        -0x6ft
        0x1bt
        0x15t
        0x64t
    .end array-data

    nop

    :array_164
    .array-data 1
        0x7bt
        0x10t
        0x70t
        0x66t
        -0x7t
        -0x51t
        -0xat
        0x7et
    .end array-data

    :array_16c
    .array-data 1
        -0x17t
        -0x52t
        -0x61t
        0x59t
        -0x12t
        0x52t
        -0x8t
        0x31t
        -0x1at
        -0x2at
        -0x22t
        0x13t
    .end array-data

    :array_176
    .array-data 1
        -0x37t
        -0x1dt
        -0x10t
        0x23t
        -0x79t
        0x3et
        -0x6ct
        0x50t
    .end array-data

    :array_17e
    .array-data 1
        0xet
        -0x10t
        0x14t
        -0x34t
        -0x20t
        -0x6at
        -0x78t
        0x55t
    .end array-data

    :array_186
    .array-data 1
        0x6ct
        -0x67t
        0x78t
        -0x5bt
        -0x7et
        -0x1t
        -0x1ct
        0x3ct
    .end array-data

    :array_18e
    .array-data 1
        -0x4dt
        0x1et
        -0x68t
        0x72t
        0x12t
        -0x40t
        -0x10t
    .end array-data

    :array_196
    .array-data 1
        -0x1ft
        0x7bt
        -0x2t
        0x17t
        0x60t
        -0x5bt
        -0x7et
        -0x2ct
    .end array-data

    :array_19e
    .array-data 1
        -0x18t
        -0x20t
        -0x7ft
        -0x2ft
        -0x43t
        0x65t
        -0xct
        0x1ct
        -0x19t
        -0x1t
        -0x7et
        -0x2et
        -0x1dt
        0x74t
        -0x59t
        0x5ft
        -0x5ft
        -0x16t
        -0x64t
        -0x37t
        -0x5ct
        0x38t
        -0x53t
        0x5ct
        -0x5bt
        -0x59t
    .end array-data

    nop

    :array_1b0
    .array-data 1
        -0x38t
        -0x78t
        -0xbt
        -0x5bt
        -0x33t
        0x16t
        -0x32t
        0x33t
    .end array-data

    :array_1b8
    .array-data 1
        0x2at
        0x43t
        0x62t
        0x40t
        -0x28t
        0x0t
        0xft
        -0x14t
        0x11t
        0x44t
    .end array-data

    nop

    :array_1c2
    .array-data 1
        0x7ft
        0x30t
        0x7t
        0x32t
        -0xbt
        0x41t
        0x68t
        -0x77t
    .end array-data

    :array_1ca
    .array-data 1
        0x55t
        -0x64t
        0x5dt
        0x69t
        -0x1et
        -0x3dt
        -0x2et
        0x9t
        0x5at
        -0x1ct
        0x1ct
        0x23t
        -0x55t
        -0x79t
        -0x17t
        0x1t
        0x1bt
        -0x4bt
        0x5dt
        0x64t
        -0x8t
        -0x71t
        -0x10t
        0x3ct
        0x55t
        -0x20t
        0x2t
        0x3dt
        -0x45t
        -0x6ct
        -0x62t
        0x3ft
        0x1ct
        -0x41t
        0x4t
        0x27t
        -0x50t
        -0x71t
        -0x3at
        0x5et
        0x41t
        -0x8t
        0x12t
        0x52t
        -0x5t
        -0x21t
        -0x2et
        0xdt
        0x22t
        -0x4ct
        0x50t
        0x58t
        -0x1et
        -0x25t
        -0x6ft
        0x5dt
        0x46t
        -0x1at
        0x1ct
        0x20t
        -0x43t
        -0x71t
        -0x6at
        0x23t
        0x3dt
        -0x7bt
        0x7ft
        0x5ft
        -0x59t
        -0x71t
        -0x2et
        0x1t
        0x1et
        -0x4ct
        0x12t
        0x54t
        -0x12t
        -0x34t
        -0x2bt
        0x7t
        0x5ct
        -0xft
        0x71t
        0x7bt
        -0x7t
        -0x40t
        -0x2dt
        0xdt
        0x5at
        -0x20t
        0x3t
        0x24t
        -0x5bt
        -0x61t
        -0x70t
        0x58t
        0x5bt
        -0x1ft
        0x12t
        0x40t
        -0x16t
        -0x37t
        -0x21t
        0x1at
        0x1ct
        -0x2t
        0x7t
        0x20t
        -0x44t
        -0x7ft
        -0x73t
        0x5et
    .end array-data

    :array_206
    .array-data 1
        0x75t
        -0x2ft
        0x32t
        0x13t
        -0x75t
        -0x51t
        -0x42t
        0x68t
    .end array-data
.end method

.method private h(Ljava/lang/String;)Ljava/util/HashMap;
    .registers 10
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            ")",
            "Ljava/util/HashMap<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    new-instance v0, Ljava/util/HashMap;

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    const/16 v1, 0xa

    new-array v1, v1, [B

    fill-array-data v1, :array_17a

    const/16 v2, 0x8

    new-array v3, v2, [B

    fill-array-data v3, :array_184

    invoke-static {v1, v3}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v1

    const/16 v3, 0xc

    new-array v4, v3, [B

    .line 1
    fill-array-data v4, :array_18c

    new-array v5, v2, [B

    fill-array-data v5, :array_196

    invoke-static {v4, v5}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {p1, v4}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v4

    if-eqz v4, :cond_3f

    const/16 p1, 0x83

    new-array p1, p1, [B

    fill-array-data p1, :array_19e

    new-array v2, v2, [B

    fill-array-data v2, :array_1e4

    invoke-static {p1, v2}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object p1

    goto/16 :goto_175

    :cond_3f
    const/16 v4, 0xb

    new-array v4, v4, [B

    fill-array-data v4, :array_1ec

    new-array v5, v2, [B

    fill-array-data v5, :array_1f6

    invoke-static {v4, v5}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {p1, v4}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v4

    const/16 v5, 0x13

    if-nez v4, :cond_167

    const/4 v4, 0x5

    new-array v4, v4, [B

    fill-array-data v4, :array_1fe

    new-array v6, v2, [B

    fill-array-data v6, :array_206

    invoke-static {v4, v6}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {p1, v4}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v4

    if-nez v4, :cond_167

    const/4 v4, 0x7

    new-array v4, v4, [B

    fill-array-data v4, :array_20e

    new-array v6, v2, [B

    fill-array-data v6, :array_216

    invoke-static {v4, v6}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {p1, v4}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v4

    if-eqz v4, :cond_83

    goto/16 :goto_167

    :cond_83
    const/4 v4, 0x3

    new-array v4, v4, [B

    fill-array-data v4, :array_21e

    new-array v6, v2, [B

    fill-array-data v6, :array_224

    invoke-static {v4, v6}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {p1, v4}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v4

    if-nez v4, :cond_158

    const/4 v4, 0x4

    new-array v6, v4, [B

    fill-array-data v6, :array_22c

    new-array v7, v2, [B

    fill-array-data v7, :array_232

    invoke-static {v6, v7}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {p1, v6}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v6

    if-nez v6, :cond_158

    new-array v6, v4, [B

    fill-array-data v6, :array_23a

    new-array v7, v2, [B

    fill-array-data v7, :array_240

    invoke-static {v6, v7}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {p1, v6}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v6

    if-nez v6, :cond_158

    new-array v6, v4, [B

    fill-array-data v6, :array_248

    new-array v7, v2, [B

    fill-array-data v7, :array_24e

    invoke-static {v6, v7}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {p1, v6}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v6

    if-nez v6, :cond_158

    new-array v6, v4, [B

    fill-array-data v6, :array_256

    new-array v7, v2, [B

    fill-array-data v7, :array_25c

    invoke-static {v6, v7}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {p1, v6}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v6

    if-nez v6, :cond_158

    new-array v6, v4, [B

    fill-array-data v6, :array_264

    new-array v7, v2, [B

    fill-array-data v7, :array_26a

    invoke-static {v6, v7}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {p1, v6}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v6

    if-nez v6, :cond_158

    new-array v6, v4, [B

    fill-array-data v6, :array_272

    new-array v7, v2, [B

    fill-array-data v7, :array_278

    invoke-static {v6, v7}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {p1, v6}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v6

    if-nez v6, :cond_158

    new-array v6, v4, [B

    fill-array-data v6, :array_280

    new-array v7, v2, [B

    fill-array-data v7, :array_286

    invoke-static {v6, v7}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {p1, v6}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v6

    if-eqz v6, :cond_126

    goto :goto_158

    :cond_126
    new-array v4, v4, [B

    fill-array-data v4, :array_28e

    new-array v5, v2, [B

    fill-array-data v5, :array_294

    invoke-static {v4, v5}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {p1, v4}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result p1

    if-eqz p1, :cond_149

    new-array p1, v3, [B

    fill-array-data p1, :array_29c

    new-array v2, v2, [B

    fill-array-data v2, :array_2a6

    invoke-static {p1, v2}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object p1

    goto :goto_175

    :cond_149
    new-array p1, v3, [B

    fill-array-data p1, :array_2ae

    new-array v2, v2, [B

    fill-array-data v2, :array_2b8

    invoke-static {p1, v2}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object p1

    goto :goto_175

    :cond_158
    :goto_158
    new-array p1, v5, [B

    fill-array-data p1, :array_2c0

    new-array v2, v2, [B

    fill-array-data v2, :array_2ce

    invoke-static {p1, v2}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object p1

    goto :goto_175

    :cond_167
    :goto_167
    new-array p1, v5, [B

    fill-array-data p1, :array_2d6

    new-array v2, v2, [B

    fill-array-data v2, :array_2e4

    invoke-static {p1, v2}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object p1

    .line 2
    :goto_175
    invoke-virtual {v0, v1, p1}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    return-object v0

    nop

    :array_17a
    .array-data 1
        -0x41t
        -0x7ct
        0x77t
        -0x70t
        -0x29t
        0x14t
        -0x53t
        -0x40t
        -0x7ct
        -0x7dt
    .end array-data

    nop

    :array_184
    .array-data 1
        -0x16t
        -0x9t
        0x12t
        -0x1et
        -0x6t
        0x55t
        -0x36t
        -0x5bt
    .end array-data

    :array_18c
    .array-data 1
        0x59t
        -0x47t
        0x7et
        -0x69t
        0x77t
        -0x3ct
        -0x2dt
        -0x80t
        0x1t
        -0x4bt
        0x75t
        -0x2ct
    .end array-data

    :array_196
    .array-data 1
        0x2ft
        -0x2at
        0x1at
        -0x47t
        0x4et
        -0x5ft
        -0x1dt
        -0x4dt
    .end array-data

    :array_19e
    .array-data 1
        -0x33t
        -0x53t
        0x7dt
        -0x6bt
        0x59t
        -0x49t
        -0x65t
        -0x24t
        -0x4bt
        -0x14t
        0x37t
        -0x24t
        0x1dt
        -0x69t
        -0x6dt
        -0x63t
        -0xbt
        -0x46t
        0x3ct
        -0x24t
        0x74t
        -0x4bt
        -0x62t
        -0x7ft
        -0x11t
        -0x55t
        0x63t
        -0x24t
        0x3t
        -0xbt
        -0x36t
        -0x38t
        -0x60t
        -0x74t
        0x62t
        -0x7ct
        0x40t
        -0x58t
        -0x26t
        -0x3at
        -0x60t
        -0x80t
        0x72t
        -0x6bt
        0x59t
        -0x41t
        -0x2bt
        -0x42t
        -0x2et
        -0x7dt
        0x32t
        -0x3ct
        0x7bt
        -0xet
        -0x26t
        -0x4et
        -0x10t
        -0x4et
        0x6bt
        -0x67t
        0x62t
        -0x42t
        -0x68t
        -0x48t
        -0x17t
        -0x4at
        0x28t
        -0x37t
        0x6t
        -0x14t
        -0x2ct
        -0x40t
        -0x4at
        -0x1et
        0x2ft
        -0x49t
        0x7dt
        -0x71t
        -0x49t
        -0x41t
        -0x54t
        -0x1et
        0x6bt
        -0x6bt
        0x5et
        -0x42t
        -0x26t
        -0x4ct
        -0x1bt
        -0x5ft
        0x6ct
        -0x6dt
        0x1ct
        -0x5t
        -0x47t
        -0x65t
        -0xet
        -0x53t
        0x6at
        -0x67t
        0x1at
        -0x16t
        -0x36t
        -0x40t
        -0x52t
        -0xet
        0x29t
        -0x34t
        0x1bt
        -0x15t
        -0x26t
        -0x42t
        -0x11t
        -0x60t
        0x6et
        -0x70t
        0x50t
        -0x5t
        -0x57t
        -0x6et
        -0x1at
        -0x5dt
        0x75t
        -0x6bt
        0x1at
        -0x12t
        -0x37t
        -0x3ct
        -0x52t
        -0xft
        0x31t
    .end array-data

    :array_1e4
    .array-data 1
        -0x80t
        -0x3et
        0x7t
        -0x4t
        0x35t
        -0x25t
        -0x6t
        -0xdt
    .end array-data

    :array_1ec
    .array-data 1
        0x47t
        -0x5ft
        0x6et
        -0x48t
        -0x10t
        0x16t
        0x5bt
        0x32t
        0x47t
        -0x5ft
        0x77t
    .end array-data

    :array_1f6
    .array-data 1
        0x26t
        -0x2ft
        0x7t
        -0x6at
        -0x80t
        0x7et
        0x2bt
        0x1dt
    .end array-data

    :array_1fe
    .array-data 1
        -0x62t
        -0xft
        -0x20t
        0x8t
        0x55t
    .end array-data

    nop

    :array_206
    .array-data 1
        -0x1at
        -0x6at
        -0x7ft
        0x78t
        0x25t
        0xet
        0x79t
        0x34t
    .end array-data

    :array_20e
    .array-data 1
        0xdt
        -0x42t
        -0x8t
        -0x4et
        -0x7ft
        -0x68t
        -0x43t
    .end array-data

    :array_216
    .array-data 1
        0x6bt
        -0x34t
        -0x63t
        -0x29t
        -0x16t
        -0x7t
        -0x2dt
        -0x74t
    .end array-data

    :array_21e
    .array-data 1
        0x13t
        0x0t
        0xft
    .end array-data

    :array_224
    .array-data 1
        0x69t
        0x73t
        0x6dt
        -0x7ft
        -0xdt
        0x69t
        0x60t
        0x36t
    .end array-data

    :array_22c
    .array-data 1
        0x3et
        -0x2t
        0x78t
        -0x26t
    .end array-data

    :array_232
    .array-data 1
        0x58t
        -0x6bt
        0x0t
        -0x57t
        -0x80t
        0x32t
        0x72t
        0xbt
    .end array-data

    :array_23a
    .array-data 1
        -0x67t
        -0x59t
        0x5dt
        -0x1t
    .end array-data

    :array_240
    .array-data 1
        -0x1ft
        -0x3at
        0x24t
        -0x74t
        0x14t
        0x1t
        0x0t
        0x5bt
    .end array-data

    :array_248
    .array-data 1
        -0x5ct
        0x10t
        0x6dt
        -0x8t
    .end array-data

    :array_24e
    .array-data 1
        -0x24t
        0x73t
        0x14t
        -0x75t
        0x21t
        0x51t
        0x1t
        -0x49t
    .end array-data

    :array_256
    .array-data 1
        0x32t
        -0x64t
        0x73t
        -0x1bt
    .end array-data

    :array_25c
    .array-data 1
        0x41t
        -0x1at
        0xat
        -0x6at
        0x44t
        0x41t
        0x13t
        0x50t
    .end array-data

    :array_264
    .array-data 1
        0x28t
        0x72t
        0x6dt
        -0x45t
    .end array-data

    :array_26a
    .array-data 1
        0x4ct
        0xat
        0x14t
        -0x38t
        0x1at
        -0x6at
        -0x3t
        0x10t
    .end array-data

    :array_272
    .array-data 1
        -0x54t
        -0x2at
        0x5dt
        -0x4ct
    .end array-data

    :array_278
    .array-data 1
        -0x2bt
        -0x5et
        0x24t
        -0x39t
        0x40t
        0x2et
        0x49t
        -0x54t
    .end array-data

    :array_280
    .array-data 1
        0x45t
        0x38t
        -0x46t
        -0x7ft
    .end array-data

    :array_286
    .array-data 1
        0x34t
        0x56t
        -0x3dt
        -0xet
        0x54t
        -0x60t
        0x66t
        0x56t
    .end array-data

    :array_28e
    .array-data 1
        -0x66t
        -0x29t
        0x2et
        -0x61t
    .end array-data

    :array_294
    .array-data 1
        -0x4ct
        -0x5ft
        0x41t
        -0x5t
        0x53t
        -0x17t
        -0x45t
        0x30t
    .end array-data

    :array_29c
    .array-data 1
        -0x57t
        -0x47t
        -0x46t
        0x20t
        -0x15t
        0x50t
        0x1ft
        0xdt
        -0x18t
        -0x1dt
        -0x4t
        0x64t
    .end array-data

    :array_2a6
    .array-data 1
        -0x3at
        -0x2et
        -0x2et
        0x54t
        -0x61t
        0x20t
        0x30t
        0x39t
    .end array-data

    :array_2ae
    .array-data 1
        -0x79t
        -0x65t
        -0x1bt
        0x29t
        0x5at
        -0x73t
        0x33t
        0x7at
        -0x13t
        -0x35t
        -0x59t
        0x6ft
    .end array-data

    :array_2b8
    .array-data 1
        -0x3dt
        -0x6t
        -0x77t
        0x5ft
        0x33t
        -0x1at
        0x1ct
        0x48t
    .end array-data

    :array_2c0
    .array-data 1
        -0x7et
        0x6ct
        -0x24t
        0x16t
        -0x54t
        0x5et
        0x32t
        0x68t
        -0xdt
        0x2dt
        -0x7at
        0x6t
        -0x1et
        0x1et
        0x68t
        0x63t
        -0x51t
        0x62t
        -0x79t
    .end array-data

    :array_2ce
    .array-data 1
        -0x3at
        0xdt
        -0x52t
        0x62t
        -0x7dt
        0x6ct
        0x1ct
        0x59t
    .end array-data

    :array_2d6
    .array-data 1
        0x49t
        0x55t
        0x4at
        -0x6ct
        -0x48t
        -0x42t
        -0x6et
        -0x5dt
        0x39t
        0x14t
        0x10t
        -0x7ct
        -0xat
        -0x2t
        -0x38t
        -0x58t
        0x64t
        0x5bt
        0x11t
    .end array-data

    :array_2e4
    .array-data 1
        0xdt
        0x34t
        0x38t
        -0x20t
        -0x69t
        -0x74t
        -0x44t
        -0x6et
    .end array-data
.end method

.method private i(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    .registers 12

    const/4 v0, 0x4

    new-array v1, v0, [B

    fill-array-data v1, :array_318

    const/16 v2, 0x8

    new-array v3, v2, [B

    fill-array-data v3, :array_31e

    invoke-static {v1, v3}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {p1, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    const/16 v3, 0xc

    const/16 v4, 0x9

    const/4 v5, 0x6

    if-eqz v1, :cond_70

    new-array v1, v3, [B

    fill-array-data v1, :array_326

    new-array v3, v2, [B

    fill-array-data v3, :array_330

    invoke-static {v1, v3}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {p1, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-eqz v1, :cond_50

    .line 1
    invoke-static {p1}, Lcom/github/catvod/spider/appysv2/b/t;->b(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p1

    new-array v0, v4, [B

    .line 2
    fill-array-data v0, :array_338

    new-array v1, v2, [B

    fill-array-data v1, :array_342

    .line 3
    invoke-static {v0, v1, p1, p2}, Lcom/github/catvod/spider/appysv2/b/v;->c([B[BLjava/lang/StringBuilder;Ljava/lang/String;)V

    new-array p2, v5, [B

    .line 4
    fill-array-data p2, :array_34a

    new-array v0, v2, [B

    fill-array-data v0, :array_352

    .line 5
    invoke-static {p2, v0, p1}, Lcom/github/catvod/spider/appysv2/b/t;->a([B[BLjava/lang/StringBuilder;)Ljava/lang/String;

    move-result-object p1

    return-object p1

    .line 6
    :cond_50
    invoke-static {p1}, Lcom/github/catvod/spider/appysv2/b/t;->b(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p1

    new-array v0, v0, [B

    .line 7
    fill-array-data v0, :array_35a

    new-array v1, v2, [B

    fill-array-data v1, :array_360

    .line 8
    invoke-static {v0, v1, p1, p2}, Lcom/github/catvod/spider/appysv2/b/v;->c([B[BLjava/lang/StringBuilder;Ljava/lang/String;)V

    new-array p2, v5, [B

    .line 9
    fill-array-data p2, :array_368

    new-array v0, v2, [B

    fill-array-data v0, :array_370

    .line 10
    invoke-static {p2, v0, p1}, Lcom/github/catvod/spider/appysv2/b/t;->a([B[BLjava/lang/StringBuilder;)Ljava/lang/String;

    move-result-object p1

    return-object p1

    :cond_70
    const/16 v1, 0xb

    new-array v6, v1, [B

    .line 11
    fill-array-data v6, :array_378

    new-array v7, v2, [B

    fill-array-data v7, :array_382

    invoke-static {v6, v7}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {p1, v6}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v6

    if-nez v6, :cond_2f7

    const/4 v6, 0x5

    new-array v7, v6, [B

    fill-array-data v7, :array_38a

    new-array v8, v2, [B

    fill-array-data v8, :array_392

    invoke-static {v7, v8}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {p1, v7}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v7

    if-eqz v7, :cond_9d

    goto/16 :goto_2f7

    :cond_9d
    sget-object v7, Lcom/github/catvod/spider/AppYsV2;->c:Ljava/util/regex/Pattern;

    invoke-virtual {v7, p1}, Ljava/util/regex/Pattern;->matcher(Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;

    move-result-object v7

    invoke-virtual {v7}, Ljava/util/regex/Matcher;->find()Z

    move-result v7

    if-eqz v7, :cond_2f4

    new-array v7, v4, [B

    fill-array-data v7, :array_39a

    new-array v8, v2, [B

    fill-array-data v8, :array_3a4

    invoke-static {v7, v8}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {p1, v7}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v7

    if-nez v7, :cond_2d4

    new-array v1, v1, [B

    fill-array-data v1, :array_3ac

    new-array v7, v2, [B

    fill-array-data v7, :array_3b6

    invoke-static {v1, v7}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {p1, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_2d4

    new-array v1, v0, [B

    fill-array-data v1, :array_3be

    new-array v7, v2, [B

    fill-array-data v7, :array_3c4

    invoke-static {v1, v7}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {p1, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_2d4

    const/4 v1, 0x3

    new-array v1, v1, [B

    fill-array-data v1, :array_3cc

    new-array v7, v2, [B

    fill-array-data v7, :array_3d2

    invoke-static {v1, v7}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {p1, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_2d4

    new-array v1, v0, [B

    fill-array-data v1, :array_3da

    new-array v7, v2, [B

    fill-array-data v7, :array_3e0

    invoke-static {v1, v7}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {p1, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_2d4

    new-array v1, v4, [B

    fill-array-data v1, :array_3e8

    new-array v7, v2, [B

    fill-array-data v7, :array_3f2

    invoke-static {v1, v7}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {p1, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_2d4

    new-array v1, v4, [B

    fill-array-data v1, :array_3fa

    new-array v7, v2, [B

    fill-array-data v7, :array_404

    invoke-static {v1, v7}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {p1, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_2d4

    new-array v1, v6, [B

    fill-array-data v1, :array_40c

    new-array v7, v2, [B

    fill-array-data v7, :array_414

    invoke-static {v1, v7}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {p1, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_2d4

    new-array v1, v2, [B

    fill-array-data v1, :array_41c

    new-array v7, v2, [B

    fill-array-data v7, :array_424

    invoke-static {v1, v7}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {p1, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_2d4

    new-array v1, v2, [B

    fill-array-data v1, :array_42c

    new-array v7, v2, [B

    fill-array-data v7, :array_434

    invoke-static {v1, v7}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {p1, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_2d4

    new-array v1, v0, [B

    fill-array-data v1, :array_43c

    new-array v7, v2, [B

    fill-array-data v7, :array_442

    invoke-static {v1, v7}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {p1, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_2d4

    const/4 v1, 0x7

    new-array v7, v1, [B

    fill-array-data v7, :array_44a

    new-array v8, v2, [B

    fill-array-data v8, :array_452

    invoke-static {v7, v8}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {p1, v7}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v7

    if-nez v7, :cond_2d4

    new-array v7, v0, [B

    fill-array-data v7, :array_45a

    new-array v8, v2, [B

    fill-array-data v8, :array_460

    invoke-static {v7, v8}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {p1, v7}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v7

    if-nez v7, :cond_2d4

    new-array v7, v6, [B

    fill-array-data v7, :array_468

    new-array v8, v2, [B

    fill-array-data v8, :array_470

    invoke-static {v7, v8}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {p1, v7}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v7

    if-nez v7, :cond_2d4

    new-array v7, v6, [B

    fill-array-data v7, :array_478

    new-array v8, v2, [B

    fill-array-data v8, :array_480

    invoke-static {v7, v8}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {p1, v7}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v7

    if-nez v7, :cond_2d4

    new-array v7, v5, [B

    fill-array-data v7, :array_488

    new-array v8, v2, [B

    fill-array-data v8, :array_490

    invoke-static {v7, v8}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {p1, v7}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v7

    if-nez v7, :cond_2d4

    new-array v7, v5, [B

    fill-array-data v7, :array_498

    new-array v8, v2, [B

    fill-array-data v8, :array_4a0

    invoke-static {v7, v8}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {p1, v7}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v7

    if-nez v7, :cond_2d4

    new-array v7, v1, [B

    fill-array-data v7, :array_4a8

    new-array v8, v2, [B

    fill-array-data v8, :array_4b0

    invoke-static {v7, v8}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {p1, v7}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v7

    if-nez v7, :cond_2d4

    new-array v7, v6, [B

    fill-array-data v7, :array_4b8

    new-array v8, v2, [B

    fill-array-data v8, :array_4c0

    invoke-static {v7, v8}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {p1, v7}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v7

    if-nez v7, :cond_2d4

    new-array v4, v4, [B

    fill-array-data v4, :array_4c8

    new-array v7, v2, [B

    fill-array-data v7, :array_4d2

    invoke-static {v4, v7}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {p1, v4}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v4

    if-nez v4, :cond_2d4

    new-array v4, v6, [B

    fill-array-data v4, :array_4da

    new-array v7, v2, [B

    fill-array-data v7, :array_4e2

    invoke-static {v4, v7}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {p1, v4}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v4

    if-nez v4, :cond_2d4

    new-array v4, v5, [B

    fill-array-data v4, :array_4ea

    new-array v7, v2, [B

    fill-array-data v7, :array_4f2

    invoke-static {v4, v7}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {p1, v4}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v4

    if-nez v4, :cond_2d4

    new-array v1, v1, [B

    fill-array-data v1, :array_4fa

    new-array v4, v2, [B

    fill-array-data v4, :array_502

    invoke-static {v1, v4}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {p1, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_2d4

    new-array v1, v6, [B

    fill-array-data v1, :array_50a

    new-array v4, v2, [B

    fill-array-data v4, :array_512

    invoke-static {v1, v4}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {p1, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_2d4

    new-array v0, v0, [B

    fill-array-data v0, :array_51a

    new-array v1, v2, [B

    fill-array-data v1, :array_520

    invoke-static {v0, v1}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    if-nez v0, :cond_2d4

    new-array v0, v6, [B

    fill-array-data v0, :array_528

    new-array v1, v2, [B

    fill-array-data v1, :array_530

    invoke-static {v0, v1}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    if-eqz v0, :cond_2b4

    goto :goto_2d4

    .line 12
    :cond_2b4
    invoke-static {p1}, Lcom/github/catvod/spider/appysv2/b/t;->b(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p1

    new-array v0, v3, [B

    .line 13
    fill-array-data v0, :array_538

    new-array v1, v2, [B

    fill-array-data v1, :array_542

    .line 14
    invoke-static {v0, v1, p1, p2}, Lcom/github/catvod/spider/appysv2/b/v;->c([B[BLjava/lang/StringBuilder;Ljava/lang/String;)V

    new-array p2, v5, [B

    .line 15
    fill-array-data p2, :array_54a

    new-array v0, v2, [B

    fill-array-data v0, :array_552

    .line 16
    invoke-static {p2, v0, p1}, Lcom/github/catvod/spider/appysv2/b/t;->a([B[BLjava/lang/StringBuilder;)Ljava/lang/String;

    move-result-object p1

    return-object p1

    .line 17
    :cond_2d4
    :goto_2d4
    invoke-static {p1}, Lcom/github/catvod/spider/appysv2/b/t;->b(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p1

    new-array v0, v3, [B

    .line 18
    fill-array-data v0, :array_55a

    new-array v1, v2, [B

    fill-array-data v1, :array_564

    .line 19
    invoke-static {v0, v1, p1, p2}, Lcom/github/catvod/spider/appysv2/b/v;->c([B[BLjava/lang/StringBuilder;Ljava/lang/String;)V

    new-array p2, v5, [B

    .line 20
    fill-array-data p2, :array_56c

    new-array v0, v2, [B

    fill-array-data v0, :array_574

    .line 21
    invoke-static {p2, v0, p1}, Lcom/github/catvod/spider/appysv2/b/t;->a([B[BLjava/lang/StringBuilder;)Ljava/lang/String;

    move-result-object p1

    return-object p1

    :cond_2f4
    const-string p1, ""

    return-object p1

    .line 22
    :cond_2f7
    :goto_2f7
    invoke-static {p1}, Lcom/github/catvod/spider/appysv2/b/t;->b(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p1

    new-array v1, v3, [B

    .line 23
    fill-array-data v1, :array_57c

    new-array v3, v2, [B

    fill-array-data v3, :array_586

    .line 24
    invoke-static {v1, v3, p1, p2}, Lcom/github/catvod/spider/appysv2/b/v;->c([B[BLjava/lang/StringBuilder;Ljava/lang/String;)V

    new-array p2, v0, [B

    .line 25
    fill-array-data p2, :array_58e

    new-array v0, v2, [B

    fill-array-data v0, :array_594

    .line 26
    invoke-static {p2, v0, p1}, Lcom/github/catvod/spider/appysv2/b/t;->a([B[BLjava/lang/StringBuilder;)Ljava/lang/String;

    move-result-object p1

    return-object p1

    nop

    :array_318
    .array-data 1
        0x28t
        0x4ft
        -0x5t
        0x65t
    .end array-data

    :array_31e
    .array-data 1
        0x6t
        0x39t
        -0x6ct
        0x1t
        -0x60t
        0x3at
        0x7et
        -0x30t
    .end array-data

    :array_326
    .array-data 1
        0x37t
        0x2dt
        0x51t
        0x2t
        0x59t
        -0x49t
        0x17t
        0x30t
        0x70t
        0x21t
        0x4et
        0xat
    .end array-data

    :array_330
    .array-data 1
        0x5et
        0x42t
        0x21t
        0x67t
        0x37t
        -0x32t
        0x62t
        0x5et
    .end array-data

    :array_338
    .array-data 1
        -0x36t
        0x4ct
        0x6ft
        0x2ft
        -0x17t
        -0x21t
        -0x67t
        0x1dt
        -0x28t
    .end array-data

    nop

    :array_342
    .array-data 1
        -0x1bt
        0x20t
        0x6t
        0x5ct
        -0x63t
        -0x20t
        -0x12t
        0x79t
    .end array-data

    :array_34a
    .array-data 1
        -0x63t
        0x54t
        -0x15t
        0x7ct
        0x46t
        -0x2et
    .end array-data

    nop

    :array_352
    .array-data 1
        -0x45t
        0x24t
        -0x76t
        0x1bt
        0x23t
        -0x11t
        0x6et
        0x27t
    .end array-data

    :array_35a
    .array-data 1
        -0x37t
        -0x5bt
        -0x41t
        -0x70t
    .end array-data

    :array_360
    .array-data 1
        -0xat
        -0x2et
        -0x25t
        -0x53t
        0x16t
        0x1at
        0x65t
        0x3t
    .end array-data

    :array_368
    .array-data 1
        0x73t
        -0x29t
        0x7et
        -0x5t
        0x57t
        0x3t
    .end array-data

    nop

    :array_370
    .array-data 1
        0x55t
        -0x59t
        0x1ft
        -0x64t
        0x32t
        0x3et
        0x1t
        0x16t
    .end array-data

    :array_378
    .array-data 1
        -0x35t
        0x3dt
        0x75t
        0x49t
        -0x67t
        -0x37t
        -0x5t
        0x43t
        -0x35t
        0x3dt
        0x6ct
    .end array-data

    :array_382
    .array-data 1
        -0x56t
        0x4dt
        0x1ct
        0x67t
        -0x17t
        -0x5ft
        -0x75t
        0x6ct
    .end array-data

    :array_38a
    .array-data 1
        0x6et
        -0x28t
        0x6dt
        -0x49t
        0x7et
    .end array-data

    nop

    :array_392
    .array-data 1
        0x16t
        -0x41t
        0xct
        -0x39t
        0xet
        -0x1t
        0x6et
        0x3et
    .end array-data

    :array_39a
    .array-data 1
        -0x4et
        -0x18t
        0x70t
        0x50t
        -0x37t
        0x38t
        -0x47t
        -0x26t
        -0x48t
    .end array-data

    nop

    :array_3a4
    .array-data 1
        -0x29t
        -0x65t
        0x15t
        0x3ct
        -0x5bt
        0x59t
        -0x34t
        -0x52t
    .end array-data

    :array_3ac
    .array-data 1
        -0x47t
        -0x2at
        -0x34t
        -0x39t
        0x18t
        -0x7dt
        0x2ft
        0x35t
        -0x47t
        -0x38t
        -0x34t
    .end array-data

    :array_3b6
    .array-data 1
        -0x78t
        -0x8t
        -0x3t
        -0xdt
        0x36t
        -0x4bt
        0x1ct
        0x1bt
    .end array-data

    :array_3be
    .array-data 1
        -0x31t
        -0x23t
        -0x3at
        -0x31t
    .end array-data

    :array_3c4
    .array-data 1
        -0x4bt
        -0x49t
        -0x41t
        -0x44t
        -0x79t
        0x77t
        -0x5ct
        0x4t
    .end array-data

    :array_3cc
    .array-data 1
        0x33t
        -0x7ft
        -0x2et
    .end array-data

    :array_3d2
    .array-data 1
        0x57t
        -0x1et
        -0x4at
        -0x4dt
        -0x40t
        0x5et
        -0x4dt
        0x5ft
    .end array-data

    :array_3da
    .array-data 1
        0x31t
        -0x77t
        0x3bt
        -0x6ft
    .end array-data

    :array_3e0
    .array-data 1
        0x5dt
        -0xft
        0x4et
        -0xct
        -0x51t
        0x79t
        0x50t
        -0x52t
    .end array-data

    :array_3e8
    .array-data 1
        0x5at
        -0x2at
        -0x3at
        0xet
        0x38t
        -0x6dt
        0x64t
        0x66t
        0x43t
    .end array-data

    nop

    :array_3f2
    .array-data 1
        0x2dt
        -0x4dt
        -0x5dt
        0x7at
        0x59t
        -0x6t
        0x4at
        0x5t
    .end array-data

    :array_3fa
    .array-data 1
        -0x7dt
        0x2bt
        0x33t
        -0x1bt
        -0x33t
        0x5ft
        0x6at
        0x33t
        -0x26t
    .end array-data

    nop

    :array_404
    .array-data 1
        -0x15t
        0x4at
        0x5ct
        -0x72t
        -0x54t
        0x31t
        0x0t
        0x46t
    .end array-data

    :array_40c
    .array-data 1
        0x42t
        0x63t
        -0x3bt
        -0x1ct
        0x1bt
    .end array-data

    nop

    :array_414
    .array-data 1
        0x24t
        0xat
        -0x4ft
        -0x22t
        0x23t
        0x42t
        -0x5t
        0x6ct
    .end array-data

    :array_41c
    .array-data 1
        -0x71t
        0x6ct
        -0x2ct
        0x6t
        0x7ft
        0x14t
        -0x2et
        -0x3et
    .end array-data

    :array_424
    .array-data 1
        -0xbt
        0x6t
        -0x42t
        0x28t
        0x13t
        0x7dt
        -0x4ct
        -0x59t
    .end array-data

    :array_42c
    .array-data 1
        0x16t
        -0x7et
        -0x22t
        -0x2et
        -0x1t
        0x27t
        -0x4dt
        0x7et
    .end array-data

    :array_434
    .array-data 1
        0x7at
        -0x13t
        -0x58t
        -0x49t
        -0x3at
        0x1et
        -0x75t
        0x47t
    .end array-data

    :array_43c
    .array-data 1
        0x2et
        -0x30t
        -0x69t
        0x35t
    .end array-data

    :array_442
    .array-data 1
        0x16t
        -0x4ct
        -0x51t
        0x44t
        0x6et
        -0x67t
        -0x21t
        0x9t
    .end array-data

    :array_44a
    .array-data 1
        -0x2t
        -0x42t
        0x4bt
        -0x7t
        0x13t
        0x45t
        -0xet
    .end array-data

    :array_452
    .array-data 1
        -0x6et
        -0x2bt
        0x65t
        -0x77t
        0x6bt
        0x30t
        -0x64t
        0x4dt
    .end array-data

    :array_45a
    .array-data 1
        -0x36t
        0x28t
        0x6dt
        0x68t
    .end array-data

    :array_460
    .array-data 1
        -0x5et
        0x4ft
        0x14t
        0x10t
        0x18t
        -0x36t
        0x9t
        -0xdt
    .end array-data

    :array_468
    .array-data 1
        -0x10t
        -0x5ft
        -0x25t
        -0x3ct
        -0x21t
    .end array-data

    nop

    :array_470
    .array-data 1
        -0x3bt
        -0x6dt
        -0x16t
        -0x44t
        -0x16t
        -0x7ct
        0x15t
        0x16t
    .end array-data

    :array_478
    .array-data 1
        -0x4dt
        0x46t
        -0x25t
        -0x56t
        -0x35t
    .end array-data

    nop

    :array_480
    .array-data 1
        -0x21t
        0x3et
        -0x5et
        -0x2dt
        -0x4et
        0x2t
        0x71t
        -0x78t
    .end array-data

    :array_488
    .array-data 1
        -0x2ft
        0x65t
        -0x41t
        0xat
        0x71t
        -0xat
    .end array-data

    nop

    :array_490
    .array-data 1
        -0x1ft
        0x5dt
        -0x72t
        0x32t
        0x5t
        -0x80t
        0xct
        -0x68t
    .end array-data

    :array_498
    .array-data 1
        0x10t
        0xet
        0x48t
        0x74t
        -0x5ft
        -0x50t
    .end array-data

    nop

    :array_4a0
    .array-data 1
        0x74t
        0x67t
        0x31t
        0x1bt
        -0x2ct
        -0x27t
        -0x79t
        0x3at
    .end array-data

    :array_4a8
    .array-data 1
        0x3ft
        -0x30t
        0x29t
        -0x79t
        0x33t
        0x44t
        -0x68t
    .end array-data

    :array_4b0
    .array-data 1
        0x5bt
        -0x47t
        0x45t
        -0x12t
        0x58t
        0x30t
        -0x12t
        -0x59t
    .end array-data

    :array_4b8
    .array-data 1
        -0x15t
        -0x68t
        -0x4dt
        -0x1dt
        0x73t
    .end array-data

    nop

    :array_4c0
    .array-data 1
        -0x65t
        -0x18t
        -0x37t
        -0x75t
        0x6t
        -0x14t
        0x3et
        -0x77t
    .end array-data

    :array_4c8
    .array-data 1
        0x47t
        0x54t
        0xet
        0x53t
        -0x37t
        -0x51t
        0x14t
        -0x47t
        0x4ft
    .end array-data

    nop

    :array_4d2
    .array-data 1
        0x26t
        0x3dt
        0x7at
        0x36t
        -0x46t
        -0x26t
        0x77t
        -0x28t
    .end array-data

    :array_4da
    .array-data 1
        -0x5t
        -0x29t
        -0x14t
        -0x73t
        0x25t
    .end array-data

    nop

    :array_4e2
    .array-data 1
        -0x7ft
        -0x53t
        -0x3et
        -0x12t
        0x4ct
        -0x5ct
        0x4ct
        0x4ft
    .end array-data

    :array_4ea
    .array-data 1
        -0x57t
        0x26t
        0x3bt
        0x23t
        0x60t
        -0x5ft
    .end array-data

    nop

    :array_4f2
    .array-data 1
        -0x36t
        0x4et
        0x43t
        0x49t
        0xft
        -0x31t
        0x38t
        -0x64t
    .end array-data

    :array_4fa
    .array-data 1
        -0xet
        0x22t
        0x8t
        -0x6ct
        -0x7ft
        0x71t
        -0x6ct
    .end array-data

    :array_502
    .array-data 1
        -0x7bt
        0x43t
        0x7ct
        -0x9t
        -0x17t
        0x1ct
        -0x3t
        -0x65t
    .end array-data

    :array_50a
    .array-data 1
        -0x1t
        0x75t
        0x59t
        -0x3ct
        0x4et
    .end array-data

    nop

    :array_512
    .array-data 1
        -0x77t
        0x1ct
        0x29t
        -0x5at
        0x3et
        -0x40t
        0xft
        0x59t
    .end array-data

    :array_51a
    .array-data 1
        0x4et
        -0x1ct
        -0x2bt
        -0x16t
    .end array-data

    :array_520
    .array-data 1
        0x2ct
        -0x74t
        -0x5ft
        -0x64t
        -0x6t
        0xbt
        -0xat
        -0x68t
    .end array-data

    :array_528
    .array-data 1
        0x32t
        0x3et
        0x7dt
        -0x55t
        -0x3ct
    .end array-data

    nop

    :array_530
    .array-data 1
        0x4at
        0x58t
        0x4t
        -0x40t
        -0x58t
        -0x78t
        -0xet
        -0x61t
    .end array-data

    :array_538
    .array-data 1
        0x70t
        -0x4bt
        -0xat
        -0x70t
        -0x80t
        0x7dt
        0x6at
        -0x62t
        0x69t
        -0x52t
        -0x8t
        -0x70t
    .end array-data

    :array_542
    .array-data 1
        0x4ft
        -0x2ct
        -0x6bt
        -0x53t
        -0x14t
        0x14t
        0x19t
        -0x16t
    .end array-data

    :array_54a
    .array-data 1
        -0x40t
        -0x7ct
        0x61t
        -0x5et
        -0x78t
        0x1et
    .end array-data

    nop

    :array_552
    .array-data 1
        -0x1at
        -0xct
        0x0t
        -0x3bt
        -0x13t
        0x23t
        0x40t
        -0x6ft
    .end array-data

    :array_55a
    .array-data 1
        -0x73t
        -0xet
        -0x76t
        0x63t
        0x11t
        -0x10t
        -0x78t
        -0x5bt
        -0x6ct
        -0x1ct
        -0x73t
        0x63t
    .end array-data

    :array_564
    .array-data 1
        -0x4et
        -0x6dt
        -0x17t
        0x5et
        0x7dt
        -0x67t
        -0x5t
        -0x2ft
    .end array-data

    :array_56c
    .array-data 1
        -0x5dt
        0x12t
        0x20t
        0x51t
        0x35t
        0x56t
    .end array-data

    nop

    :array_574
    .array-data 1
        -0x7bt
        0x62t
        0x41t
        0x36t
        0x50t
        0x6bt
        -0x49t
        0x26t
    .end array-data

    :array_57c
    .array-data 1
        -0x77t
        -0x7bt
        -0x2et
        0xbt
        -0x15t
        -0x57t
        0x33t
        -0x70t
        -0x61t
        -0x68t
        -0x39t
        0x44t
    .end array-data

    :array_586
    .array-data 1
        -0x6t
        -0x20t
        -0x4dt
        0x79t
        -0x78t
        -0x3ft
        0xct
        -0x1ct
    .end array-data

    :array_58e
    .array-data 1
        -0x6at
        -0x44t
        0x76t
        -0x53t
    .end array-data

    :array_594
    .array-data 1
        -0x50t
        -0x34t
        0x11t
        -0x70t
        0x46t
        0x17t
        0x25t
        0x4dt
    .end array-data
.end method

.method private j(Lorg/json/JSONArray;)Ljava/lang/String;
    .registers 7

    :try_start_0
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    const/4 v1, 0x0

    const/4 v2, 0x0

    :goto_7
    invoke-virtual {p1}, Lorg/json/JSONArray;->length()I

    move-result v3

    if-ge v2, v3, :cond_17

    invoke-virtual {p1, v2}, Lorg/json/JSONArray;->getString(I)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v0, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/lit8 v2, v2, 0x1

    goto :goto_7

    :cond_17
    const/4 p1, 0x1

    new-array v2, p1, [B

    const/16 v3, -0x7a

    aput-byte v3, v2, v1

    const/16 v3, 0x8

    new-array v3, v3, [B

    const/16 v4, -0x56

    aput-byte v4, v3, v1

    const/16 v1, -0x53

    aput-byte v1, v3, p1

    const/4 p1, 0x2

    const/4 v1, -0x3

    aput-byte v1, v3, p1

    const/4 p1, 0x3

    const/16 v1, 0x79

    aput-byte v1, v3, p1

    const/4 p1, 0x4

    const/16 v1, -0x62

    aput-byte v1, v3, p1

    const/4 p1, 0x5

    const/16 v1, -0x73

    aput-byte v1, v3, p1

    const/4 p1, 0x6

    const/4 v1, -0x4

    aput-byte v1, v3, p1

    const/4 p1, 0x7

    const/16 v1, -0x20

    aput-byte v1, v3, p1

    invoke-static {v2, v3}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object p1

    invoke-static {p1, v0}, Landroid/text/TextUtils;->join(Ljava/lang/CharSequence;Ljava/lang/Iterable;)Ljava/lang/String;

    move-result-object p1
    :try_end_4e
    .catch Lorg/json/JSONException; {:try_start_0 .. :try_end_4e} :catch_4f

    return-object p1

    :catch_4f
    const-string p1, ""

    return-object p1
.end method

.method public static jsonParse(Ljava/lang/String;Ljava/lang/String;)Lorg/json/JSONObject;
    .registers 13

    new-instance v0, Lorg/json/JSONObject;

    invoke-direct {v0, p1}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    const/4 p1, 0x4

    new-array v1, p1, [B

    fill-array-data v1, :array_29e

    const/16 v2, 0x8

    new-array v3, v2, [B

    fill-array-data v3, :array_2a4

    invoke-static {v1, v3}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Lorg/json/JSONObject;->has(Ljava/lang/String;)Z

    move-result v1

    const/4 v3, 0x3

    if-eqz v1, :cond_59

    new-array v1, p1, [B

    fill-array-data v1, :array_2ac

    new-array v4, v2, [B

    fill-array-data v4, :array_2b2

    invoke-static {v1, v4}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Lorg/json/JSONObject;->get(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v1

    instance-of v1, v1, Lorg/json/JSONObject;

    if-eqz v1, :cond_59

    new-array v1, v3, [B

    fill-array-data v1, :array_2ba

    new-array v4, v2, [B

    fill-array-data v4, :array_2c0

    invoke-static {v1, v4}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Lorg/json/JSONObject;->has(Ljava/lang/String;)Z

    move-result v1

    if-nez v1, :cond_59

    new-array v1, p1, [B

    fill-array-data v1, :array_2c8

    new-array v4, v2, [B

    fill-array-data v4, :array_2ce

    invoke-static {v1, v4}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Lorg/json/JSONObject;->getJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v0

    :cond_59
    new-array v1, v3, [B

    fill-array-data v1, :array_2d6

    new-array v4, v2, [B

    fill-array-data v4, :array_2dc

    invoke-static {v1, v4}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x2

    new-array v4, v4, [B

    fill-array-data v4, :array_2e4

    new-array v5, v2, [B

    fill-array-data v5, :array_2ea

    invoke-static {v4, v5}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v1, v4}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v4

    const/4 v5, 0x6

    if-eqz v4, :cond_94

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    new-array v6, v5, [B

    fill-array-data v6, :array_2f2

    new-array v7, v2, [B

    fill-array-data v7, :array_2fa

    .line 1
    invoke-static {v6, v7, v4, v1}, Lcom/github/catvod/spider/appysv2/b/u;->a([B[BLjava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    .line 2
    :cond_94
    invoke-virtual {v1}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v4

    new-array p1, p1, [B

    fill-array-data p1, :array_302

    new-array v6, v2, [B

    fill-array-data v6, :array_308

    invoke-static {p1, v6}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v4, p1}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result p1

    const/4 v4, 0x0

    if-nez p1, :cond_ae

    return-object v4

    :cond_ae
    invoke-virtual {v1, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_c1

    invoke-static {v1}, Lcom/github/catvod/spider/appysv2/p/C;->p(Ljava/lang/String;)Z

    move-result p1

    if-nez p1, :cond_c0

    invoke-static {v1}, Lcom/github/catvod/spider/appysv2/p/C;->o(Ljava/lang/String;)Z

    move-result p1

    if-nez p1, :cond_c1

    :cond_c0
    return-object v4

    :cond_c1
    invoke-static {v1}, Lcom/github/catvod/spider/appysv2/p/C;->l(Ljava/lang/String;)Z

    move-result p1

    if-eqz p1, :cond_c8

    return-object v4

    :cond_c8
    new-instance p1, Lorg/json/JSONObject;

    invoke-direct {p1}, Lorg/json/JSONObject;-><init>()V

    new-array v4, v5, [B

    fill-array-data v4, :array_310

    new-array v6, v2, [B

    fill-array-data v6, :array_318

    invoke-static {v4, v6}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v0, v4}, Lorg/json/JSONObject;->has(Ljava/lang/String;)Z

    move-result v4

    const/4 v6, 0x7

    if-eqz v4, :cond_f1

    new-array p1, v5, [B

    fill-array-data p1, :array_320

    new-array v4, v2, [B

    fill-array-data v4, :array_328

    invoke-static {p1, v4}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object p1

    goto :goto_159

    :cond_f1
    new-array v4, v5, [B

    fill-array-data v4, :array_330

    new-array v7, v2, [B

    fill-array-data v7, :array_338

    invoke-static {v4, v7}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v0, v4}, Lorg/json/JSONObject;->has(Ljava/lang/String;)Z

    move-result v4

    if-eqz v4, :cond_114

    new-array p1, v5, [B

    fill-array-data p1, :array_340

    new-array v4, v2, [B

    fill-array-data v4, :array_348

    invoke-static {p1, v4}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object p1

    goto :goto_159

    :cond_114
    new-array v4, v6, [B

    fill-array-data v4, :array_350

    new-array v7, v2, [B

    fill-array-data v7, :array_358

    invoke-static {v4, v7}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v0, v4}, Lorg/json/JSONObject;->has(Ljava/lang/String;)Z

    move-result v4

    if-eqz v4, :cond_137

    new-array p1, v6, [B

    fill-array-data p1, :array_360

    new-array v4, v2, [B

    fill-array-data v4, :array_368

    invoke-static {p1, v4}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object p1

    goto :goto_159

    :cond_137
    new-array v4, v6, [B

    fill-array-data v4, :array_370

    new-array v7, v2, [B

    fill-array-data v7, :array_378

    invoke-static {v4, v7}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v0, v4}, Lorg/json/JSONObject;->has(Ljava/lang/String;)Z

    move-result v4

    if-eqz v4, :cond_15d

    new-array p1, v6, [B

    fill-array-data p1, :array_380

    new-array v4, v2, [B

    fill-array-data v4, :array_388

    invoke-static {p1, v4}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object p1

    :goto_159
    invoke-virtual {v0, p1}, Lorg/json/JSONObject;->optJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object p1

    :cond_15d
    const/16 v4, 0xa

    new-array v7, v4, [B

    fill-array-data v7, :array_390

    new-array v8, v2, [B

    fill-array-data v8, :array_39a

    invoke-static {v7, v8}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v0, v7}, Lorg/json/JSONObject;->has(Ljava/lang/String;)Z

    move-result v7

    const-string v8, ""

    if-eqz v7, :cond_184

    new-array v7, v4, [B

    fill-array-data v7, :array_3a2

    new-array v9, v2, [B

    fill-array-data v9, :array_3ac

    invoke-static {v7, v9}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v7

    goto :goto_1a6

    :cond_184
    new-array v7, v4, [B

    fill-array-data v7, :array_3b4

    new-array v9, v2, [B

    fill-array-data v9, :array_3be

    invoke-static {v7, v9}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v0, v7}, Lorg/json/JSONObject;->has(Ljava/lang/String;)Z

    move-result v7

    if-eqz v7, :cond_1ab

    new-array v7, v4, [B

    fill-array-data v7, :array_3c6

    new-array v9, v2, [B

    fill-array-data v9, :array_3d0

    invoke-static {v7, v9}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v7

    :goto_1a6
    invoke-virtual {v0, v7, v8}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    goto :goto_1ac

    :cond_1ab
    move-object v7, v8

    :goto_1ac
    invoke-virtual {v7}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v9}, Ljava/lang/String;->length()I

    move-result v9

    const-string v10, "67"

    invoke-static {v10}, Lcom/github/catvod/spider/appysv2/KKB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    if-lez v9, :cond_1dc

    new-array v4, v4, [B

    fill-array-data v4, :array_3d8

    new-array v9, v2, [B

    fill-array-data v9, :array_3e2

    invoke-static {v4, v9}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v4

    new-instance v9, Ljava/lang/StringBuilder;

    invoke-direct {v9}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v9, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v9, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v9}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v7

    invoke-virtual {p1, v4, v7}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    :cond_1dc
    new-array v4, v6, [B

    fill-array-data v4, :array_3ea

    new-array v7, v2, [B

    fill-array-data v7, :array_3f2

    invoke-static {v4, v7}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v0, v4}, Lorg/json/JSONObject;->has(Ljava/lang/String;)Z

    move-result v4

    if-eqz v4, :cond_1ff

    new-array v4, v6, [B

    fill-array-data v4, :array_3fa

    new-array v7, v2, [B

    fill-array-data v7, :array_402

    invoke-static {v4, v7}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v4

    goto :goto_221

    :cond_1ff
    new-array v4, v6, [B

    fill-array-data v4, :array_40a

    new-array v7, v2, [B

    fill-array-data v7, :array_412

    invoke-static {v4, v7}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v0, v4}, Lorg/json/JSONObject;->has(Ljava/lang/String;)Z

    move-result v4

    if-eqz v4, :cond_225

    new-array v4, v6, [B

    fill-array-data v4, :array_41a

    new-array v7, v2, [B

    fill-array-data v7, :array_422

    invoke-static {v4, v7}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v4

    :goto_221
    invoke-virtual {v0, v4, v8}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    :cond_225
    invoke-virtual {v8}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v0

    if-lez v0, :cond_24f

    new-array v0, v6, [B

    fill-array-data v0, :array_42a

    new-array v4, v2, [B

    fill-array-data v4, :array_432

    invoke-static {v0, v4}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v0

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v4, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {p1, v0, v4}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    :cond_24f
    invoke-static {p1, p0, v1}, Lcom/github/catvod/spider/AppYsV2;->fixJsonVodHeader(Lorg/json/JSONObject;Ljava/lang/String;Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object p0

    new-instance p1, Lorg/json/JSONObject;

    invoke-direct {p1}, Lorg/json/JSONObject;-><init>()V

    new-array v0, v5, [B

    fill-array-data v0, :array_43a

    new-array v4, v2, [B

    fill-array-data v4, :array_442

    invoke-static {v0, v4}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0, p0}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    new-array p0, v3, [B

    fill-array-data p0, :array_44a

    new-array v0, v2, [B

    fill-array-data v0, :array_450

    invoke-static {p0, v0}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object p0

    invoke-virtual {p1, p0, v1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 p0, 0x5

    new-array p0, p0, [B

    fill-array-data p0, :array_458

    new-array v0, v2, [B

    fill-array-data v0, :array_460

    invoke-static {p0, v0}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object p0

    const/4 v0, 0x1

    new-array v0, v0, [B

    const/4 v1, 0x0

    const/16 v3, -0x1a

    aput-byte v3, v0, v1

    new-array v1, v2, [B

    fill-array-data v1, :array_468

    invoke-static {v0, v1}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, p0, v0}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    return-object p1

    :array_29e
    .array-data 1
        0xct
        -0x63t
        -0x38t
        -0x40t
    .end array-data

    :array_2a4
    .array-data 1
        0x68t
        -0x4t
        -0x44t
        -0x5ft
        -0x2t
        0x7t
        0x13t
        -0x39t
    .end array-data

    :array_2ac
    .array-data 1
        -0x18t
        -0x2at
        -0x1t
        0x6at
    .end array-data

    :array_2b2
    .array-data 1
        -0x74t
        -0x49t
        -0x75t
        0xbt
        0x1t
        -0x1ct
        0x67t
        -0x4at
    .end array-data

    :array_2ba
    .array-data 1
        -0x34t
        -0x1bt
        -0x13t
    .end array-data

    :array_2c0
    .array-data 1
        -0x47t
        -0x69t
        -0x7ft
        -0x3ft
        -0x6at
        -0x38t
        -0x52t
        -0x3ft
    .end array-data

    :array_2c8
    .array-data 1
        0x19t
        -0x79t
        0x3bt
        0x16t
    .end array-data

    :array_2ce
    .array-data 1
        0x7dt
        -0x1at
        0x4ft
        0x77t
        0x63t
        -0x41t
        -0x51t
        0x42t
    .end array-data

    :array_2d6
    .array-data 1
        -0x4t
        -0x1t
        0x33t
    .end array-data

    :array_2dc
    .array-data 1
        -0x77t
        -0x73t
        0x5ft
        -0xdt
        0x55t
        -0x1et
        -0x40t
        0x74t
    .end array-data

    :array_2e4
    .array-data 1
        0x78t
        0x9t
    .end array-data

    nop

    :array_2ea
    .array-data 1
        0x57t
        0x26t
        -0x44t
        -0x3t
        0x33t
        -0x3et
        0x55t
        -0x2et
    .end array-data

    :array_2f2
    .array-data 1
        -0x80t
        -0x42t
        0x62t
        0x43t
        -0x4ct
        0x4at
    .end array-data

    nop

    :array_2fa
    .array-data 1
        -0x18t
        -0x36t
        0x16t
        0x33t
        -0x39t
        0x70t
        -0x2t
        -0x3t
    .end array-data

    :array_302
    .array-data 1
        0x2ct
        0x35t
        0x48t
        0x61t
    .end array-data

    :array_308
    .array-data 1
        0x44t
        0x41t
        0x3ct
        0x11t
        0x7bt
        -0x3bt
        -0x32t
        -0x4bt
    .end array-data

    :array_310
    .array-data 1
        -0x6bt
        -0x52t
        0x26t
        -0x6ct
        0x5at
        -0x58t
    .end array-data

    nop

    :array_318
    .array-data 1
        -0x3t
        -0x35t
        0x47t
        -0x10t
        0x3ft
        -0x26t
        0x1et
        0x29t
    .end array-data

    :array_320
    .array-data 1
        0x20t
        -0x7t
        0x71t
        -0x40t
        -0x35t
        0xct
    .end array-data

    nop

    :array_328
    .array-data 1
        0x48t
        -0x64t
        0x10t
        -0x5ct
        -0x52t
        0x7et
        0x15t
        -0x56t
    .end array-data

    :array_330
    .array-data 1
        -0x39t
        -0x51t
        0x30t
        0x54t
        -0x7bt
        0x5bt
    .end array-data

    nop

    :array_338
    .array-data 1
        -0x71t
        -0x36t
        0x51t
        0x30t
        -0x20t
        0x29t
        -0x7bt
        -0x26t
    .end array-data

    :array_340
    .array-data 1
        -0x13t
        -0x5at
        -0x72t
        -0x6dt
        -0x21t
        0x51t
    .end array-data

    nop

    :array_348
    .array-data 1
        -0x5bt
        -0x3dt
        -0x11t
        -0x9t
        -0x46t
        0x23t
        0x70t
        -0x5t
    .end array-data

    :array_350
    .array-data 1
        0x39t
        -0x60t
        0x16t
        -0x3et
        0x13t
        -0x5ct
        0x25t
    .end array-data

    :array_358
    .array-data 1
        0x51t
        -0x3bt
        0x77t
        -0x5at
        0x76t
        -0x2at
        0x56t
        -0x6t
    .end array-data

    :array_360
    .array-data 1
        -0x3ct
        0x72t
        -0x1bt
        -0x67t
        0x4t
        -0x2ft
        0x5t
    .end array-data

    :array_368
    .array-data 1
        -0x54t
        0x17t
        -0x7ct
        -0x3t
        0x61t
        -0x5dt
        0x76t
        -0x3ct
    .end array-data

    :array_370
    .array-data 1
        -0x7et
        -0x53t
        -0x7t
        -0x7bt
        0xbt
        -0x69t
        -0x5et
    .end array-data

    :array_378
    .array-data 1
        -0x36t
        -0x38t
        -0x68t
        -0x1ft
        0x6et
        -0x1bt
        -0x2ft
        0x53t
    .end array-data

    :array_380
    .array-data 1
        0x76t
        0x2t
        -0x39t
        -0x56t
        -0x2et
        -0x5dt
        -0x2dt
    .end array-data

    :array_388
    .array-data 1
        0x3et
        0x67t
        -0x5at
        -0x32t
        -0x49t
        -0x2ft
        -0x60t
        -0x21t
    .end array-data

    :array_390
    .array-data 1
        0x35t
        -0x17t
        -0x6at
        -0x7at
        0x33t
        0x12t
        0x1bt
        -0xft
        0x2et
        -0x12t
    .end array-data

    nop

    :array_39a
    .array-data 1
        0x40t
        -0x66t
        -0xdt
        -0xct
        0x1et
        0x73t
        0x7ct
        -0x6ct
    .end array-data

    :array_3a2
    .array-data 1
        0x40t
        -0x3et
        0x4t
        -0x6t
        -0x7t
        0xft
        -0x24t
        0x7at
        0x5bt
        -0x3bt
    .end array-data

    nop

    :array_3ac
    .array-data 1
        0x35t
        -0x4ft
        0x61t
        -0x78t
        -0x2ct
        0x6et
        -0x45t
        0x1ft
    .end array-data

    :array_3b4
    .array-data 1
        0x50t
        -0x22t
        -0x50t
        -0x2ft
        0x25t
        0x69t
        0x31t
        0x6dt
        0x6bt
        -0x27t
    .end array-data

    nop

    :array_3be
    .array-data 1
        0x5t
        -0x53t
        -0x2bt
        -0x5dt
        0x8t
        0x28t
        0x56t
        0x8t
    .end array-data

    :array_3c6
    .array-data 1
        0xct
        -0x9t
        -0x6ft
        -0x56t
        0x1ct
        0x67t
        0x74t
        0x6at
        0x37t
        -0x10t
    .end array-data

    nop

    :array_3d0
    .array-data 1
        0x59t
        -0x7ct
        -0xct
        -0x28t
        0x31t
        0x26t
        0x13t
        0xft
    .end array-data

    :array_3d8
    .array-data 1
        -0x44t
        -0x79t
        -0xct
        -0x67t
        0x6dt
        -0x7et
        -0x3bt
        0x41t
        -0x79t
        -0x80t
    .end array-data

    nop

    :array_3e2
    .array-data 1
        -0x17t
        -0xct
        -0x6ft
        -0x15t
        0x40t
        -0x3dt
        -0x5et
        0x24t
    .end array-data

    :array_3ea
    .array-data 1
        -0x5et
        -0x7t
        0x16t
        -0x6et
        0x24t
        0x64t
        -0x6ft
    .end array-data

    :array_3f2
    .array-data 1
        -0x30t
        -0x64t
        0x70t
        -0x9t
        0x56t
        0x1t
        -0x1dt
        0x14t
    .end array-data

    :array_3fa
    .array-data 1
        -0x3at
        -0x3dt
        -0x6et
        0x5ft
        -0x6ct
        -0x4dt
        0x5ft
    .end array-data

    :array_402
    .array-data 1
        -0x4ct
        -0x5at
        -0xct
        0x3at
        -0x1at
        -0x2at
        0x2dt
        -0x16t
    .end array-data

    :array_40a
    .array-data 1
        0x71t
        -0x40t
        0x47t
        -0x4dt
        -0x7bt
        0x34t
        0x3ft
    .end array-data

    :array_412
    .array-data 1
        0x23t
        -0x5bt
        0x21t
        -0x2at
        -0x9t
        0x51t
        0x4dt
        0x4dt
    .end array-data

    :array_41a
    .array-data 1
        -0x78t
        -0x36t
        -0x43t
        0x47t
        -0xft
        0x1dt
        -0x63t
    .end array-data

    :array_422
    .array-data 1
        -0x26t
        -0x51t
        -0x25t
        0x22t
        -0x7dt
        0x78t
        -0x11t
        -0x4bt
    .end array-data

    :array_42a
    .array-data 1
        -0xet
        -0x72t
        0x1at
        0x17t
        -0x49t
        -0x5ft
        0x5bt
    .end array-data

    :array_432
    .array-data 1
        -0x60t
        -0x15t
        0x7ct
        0x72t
        -0x3bt
        -0x3ct
        0x29t
        -0x77t
    .end array-data

    :array_43a
    .array-data 1
        0x21t
        0x60t
        0x5ft
        -0x1bt
        -0x4et
        0x16t
    .end array-data

    nop

    :array_442
    .array-data 1
        0x49t
        0x5t
        0x3et
        -0x7ft
        -0x29t
        0x64t
        -0x1t
        0x5dt
    .end array-data

    :array_44a
    .array-data 1
        0x31t
        0xbt
        -0x2bt
    .end array-data

    :array_450
    .array-data 1
        0x44t
        0x79t
        -0x47t
        0x49t
        -0x1et
        0x56t
        -0x5ct
        0x12t
    .end array-data

    :array_458
    .array-data 1
        0x16t
        -0x7at
        0x14t
        -0xdt
        -0x5at
    .end array-data

    nop

    :array_460
    .array-data 1
        0x66t
        -0x19t
        0x66t
        -0x80t
        -0x3dt
        -0x4et
        0x42t
        0x1ft
    .end array-data

    :array_468
    .array-data 1
        -0x2at
        0x2ct
        0x72t
        -0x27t
        -0x30t
        -0x7ft
        0x10t
        -0x1dt
    .end array-data
.end method


# virtual methods
.method public categoryContent(Ljava/lang/String;Ljava/lang/String;ZLjava/util/HashMap;)Ljava/lang/String;
    .registers 25
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Z",
            "Ljava/util/HashMap<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;)",
            "Ljava/lang/String;"
        }
    .end annotation

    move-object/from16 v1, p0

    move-object/from16 v2, p2

    move-object/from16 v0, p4

    invoke-direct/range {p0 .. p0}, Lcom/github/catvod/spider/AppYsV2;->c()Ljava/lang/String;

    move-result-object v3

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v1, v3}, Lcom/github/catvod/spider/AppYsV2;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-object/from16 v5, p1

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v3}, Lcom/github/catvod/spider/AppYsV2;->e(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    const/4 v4, 0x4

    new-array v5, v4, [B

    fill-array-data v5, :array_950

    const/16 v6, 0x8

    new-array v7, v6, [B

    fill-array-data v7, :array_956

    invoke-static {v5, v7}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v3, v5, v2}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object v3

    const/16 v5, 0xb

    new-array v7, v5, [B

    fill-array-data v7, :array_95e

    new-array v8, v6, [B

    fill-array-data v8, :array_968

    invoke-static {v7, v8}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v7

    const-string v8, ""

    const/4 v9, 0x5

    if-eqz v0, :cond_79

    new-array v10, v9, [B

    fill-array-data v10, :array_970

    new-array v11, v6, [B

    fill-array-data v11, :array_978

    invoke-static {v10, v11}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v0, v10}, Ljava/util/HashMap;->containsKey(Ljava/lang/Object;)Z

    move-result v10

    if-eqz v10, :cond_79

    new-array v10, v9, [B

    fill-array-data v10, :array_980

    new-array v11, v6, [B

    fill-array-data v11, :array_988

    invoke-static {v10, v11}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v0, v10}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v10

    check-cast v10, Ljava/lang/CharSequence;

    goto :goto_7a

    :cond_79
    move-object v10, v8

    :goto_7a
    invoke-virtual {v3, v7, v10}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object v3

    const/16 v7, 0xa

    new-array v10, v7, [B

    fill-array-data v10, :array_990

    new-array v11, v6, [B

    fill-array-data v11, :array_99a

    invoke-static {v10, v11}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v10

    if-eqz v0, :cond_b9

    new-array v11, v4, [B

    fill-array-data v11, :array_9a2

    new-array v12, v6, [B

    fill-array-data v12, :array_9a8

    invoke-static {v11, v12}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v11

    invoke-virtual {v0, v11}, Ljava/util/HashMap;->containsKey(Ljava/lang/Object;)Z

    move-result v11

    if-eqz v11, :cond_b9

    new-array v11, v4, [B

    fill-array-data v11, :array_9b0

    new-array v12, v6, [B

    fill-array-data v12, :array_9b6

    invoke-static {v11, v12}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v11

    invoke-virtual {v0, v11}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v11

    check-cast v11, Ljava/lang/CharSequence;

    goto :goto_ba

    :cond_b9
    move-object v11, v8

    :goto_ba
    invoke-virtual {v3, v10, v11}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object v3

    new-array v10, v7, [B

    fill-array-data v10, :array_9be

    new-array v11, v6, [B

    fill-array-data v11, :array_9c8

    invoke-static {v10, v11}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v10

    if-eqz v0, :cond_f7

    new-array v11, v4, [B

    fill-array-data v11, :array_9d0

    new-array v12, v6, [B

    fill-array-data v12, :array_9d6

    invoke-static {v11, v12}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v11

    invoke-virtual {v0, v11}, Ljava/util/HashMap;->containsKey(Ljava/lang/Object;)Z

    move-result v11

    if-eqz v11, :cond_f7

    new-array v11, v4, [B

    fill-array-data v11, :array_9de

    new-array v12, v6, [B

    fill-array-data v12, :array_9e4

    invoke-static {v11, v12}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v11

    invoke-virtual {v0, v11}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v11

    check-cast v11, Ljava/lang/CharSequence;

    goto :goto_f8

    :cond_f7
    move-object v11, v8

    :goto_f8
    invoke-virtual {v3, v10, v11}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object v3

    new-array v7, v7, [B

    fill-array-data v7, :array_9ec

    new-array v10, v6, [B

    fill-array-data v10, :array_9f6

    invoke-static {v7, v10}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v7

    if-eqz v0, :cond_135

    new-array v10, v4, [B

    fill-array-data v10, :array_9fe

    new-array v11, v6, [B

    fill-array-data v11, :array_a04

    invoke-static {v10, v11}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v0, v10}, Ljava/util/HashMap;->containsKey(Ljava/lang/Object;)Z

    move-result v10

    if-eqz v10, :cond_135

    new-array v10, v4, [B

    fill-array-data v10, :array_a0c

    new-array v11, v6, [B

    fill-array-data v11, :array_a12

    invoke-static {v10, v11}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v0, v10}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v10

    check-cast v10, Ljava/lang/CharSequence;

    goto :goto_136

    :cond_135
    move-object v10, v8

    :goto_136
    invoke-virtual {v3, v7, v10}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object v3

    const/4 v7, 0x6

    new-array v10, v7, [B

    fill-array-data v10, :array_a1a

    new-array v11, v6, [B

    fill-array-data v11, :array_a22

    invoke-static {v10, v11}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v10

    if-eqz v0, :cond_174

    new-array v11, v7, [B

    fill-array-data v11, :array_a2a

    new-array v12, v6, [B

    fill-array-data v12, :array_a32

    invoke-static {v11, v12}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v11

    invoke-virtual {v0, v11}, Ljava/util/HashMap;->containsKey(Ljava/lang/Object;)Z

    move-result v11

    if-eqz v11, :cond_174

    new-array v8, v7, [B

    fill-array-data v8, :array_a3a

    new-array v11, v6, [B

    fill-array-data v11, :array_a42

    invoke-static {v8, v11}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v0, v8}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    move-object v8, v0

    check-cast v8, Ljava/lang/CharSequence;

    :cond_174
    invoke-virtual {v3, v10, v8}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lcom/github/catvod/crawler/SpiderDebug;->log(Ljava/lang/String;)V

    invoke-direct {v1, v0}, Lcom/github/catvod/spider/AppYsV2;->h(Ljava/lang/String;)Ljava/util/HashMap;

    move-result-object v3

    invoke-static {v0, v3}, Lcom/github/catvod/spider/appysv2/n/c;->m(Ljava/lang/String;Ljava/util/Map;)Ljava/lang/String;

    move-result-object v0

    new-instance v3, Lorg/json/JSONObject;

    invoke-direct {v3, v0}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    const/16 v0, 0x9

    const/4 v8, 0x7

    const/4 v10, 0x3

    const/4 v11, 0x0

    :try_start_18d
    new-array v12, v0, [B

    const/16 v13, 0x37

    aput-byte v13, v12, v11

    const/16 v13, -0x60

    const/4 v14, 0x1

    aput-byte v13, v12, v14

    const/16 v15, -0x10

    const/16 v16, 0x2

    aput-byte v15, v12, v16

    const/16 v15, -0x5a

    aput-byte v15, v12, v10

    const/16 v15, 0x68

    aput-byte v15, v12, v4

    const/16 v17, 0x40

    aput-byte v17, v12, v9

    const/16 v17, 0x17

    aput-byte v17, v12, v7

    const/16 v17, 0x71

    aput-byte v17, v12, v8

    const/16 v17, 0x26

    aput-byte v17, v12, v6

    new-array v5, v6, [B

    const/16 v18, 0x43

    aput-byte v18, v5, v11

    const/16 v18, -0x31

    aput-byte v18, v5, v14

    const/16 v18, -0x7c

    aput-byte v18, v5, v16

    const/16 v19, -0x39

    aput-byte v19, v5, v10

    aput-byte v4, v5, v4

    const/16 v19, 0x30

    aput-byte v19, v5, v9

    const/16 v19, 0x76

    aput-byte v19, v5, v7

    const/16 v19, 0x16

    aput-byte v19, v5, v8

    invoke-static {v12, v5}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v3, v5}, Lorg/json/JSONObject;->has(Ljava/lang/String;)Z

    move-result v5

    if-eqz v5, :cond_27b

    new-array v5, v0, [B

    const/16 v12, 0x2b

    aput-byte v12, v5, v11

    const/16 v12, -0x6f

    aput-byte v12, v5, v14

    aput-byte v13, v5, v16

    aput-byte v18, v5, v10

    const/16 v12, 0x48

    aput-byte v12, v5, v4

    const/16 v12, 0x18

    aput-byte v12, v5, v9

    const/16 v12, 0x3e

    aput-byte v12, v5, v7

    const/16 v12, 0x25

    aput-byte v12, v5, v8

    const/16 v12, 0x3a

    aput-byte v12, v5, v6

    new-array v12, v6, [B

    const/16 v13, 0x5f

    aput-byte v13, v12, v11

    const/4 v13, -0x2

    aput-byte v13, v12, v14

    const/16 v13, -0x2c

    aput-byte v13, v12, v16

    const/16 v13, -0x1b

    aput-byte v13, v12, v10

    const/16 v13, 0x24

    aput-byte v13, v12, v4

    aput-byte v15, v12, v9

    const/16 v13, 0x5f

    aput-byte v13, v12, v7

    const/16 v13, 0x42

    aput-byte v13, v12, v8

    invoke-static {v5, v12}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v3, v5}, Lorg/json/JSONObject;->get(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v5

    instance-of v5, v5, Ljava/lang/Integer;

    if-eqz v5, :cond_27b

    new-array v0, v0, [B

    const/16 v5, 0x45

    aput-byte v5, v0, v11

    const/16 v5, -0x5d

    aput-byte v5, v0, v14

    const/16 v5, -0x25

    aput-byte v5, v0, v16

    const/16 v5, -0xe

    aput-byte v5, v0, v10

    const/16 v5, -0x55

    aput-byte v5, v0, v4

    const/16 v5, 0x1f

    aput-byte v5, v0, v9

    const/16 v5, -0xb

    aput-byte v5, v0, v7

    const/16 v5, -0x16

    aput-byte v5, v0, v8

    const/16 v5, 0x54

    aput-byte v5, v0, v6

    new-array v5, v6, [B

    const/16 v12, 0x31

    aput-byte v12, v5, v11

    const/16 v12, -0x34

    aput-byte v12, v5, v14

    const/16 v12, -0x51

    aput-byte v12, v5, v16

    const/16 v12, -0x6d

    aput-byte v12, v5, v10

    const/16 v12, -0x39

    aput-byte v12, v5, v4

    const/16 v12, 0x6f

    aput-byte v12, v5, v9

    const/16 v12, -0x6c

    aput-byte v12, v5, v7

    const/16 v12, -0x73

    aput-byte v12, v5, v8

    invoke-static {v0, v5}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v0

    goto/16 :goto_35f

    :cond_27b
    new-array v5, v0, [B

    const/16 v12, -0x20

    aput-byte v12, v5, v11

    const/16 v12, -0x7f

    aput-byte v12, v5, v14

    const/16 v12, -0x5b

    aput-byte v12, v5, v16

    const/16 v12, -0x2d

    aput-byte v12, v5, v10

    aput-byte v17, v5, v4

    const/16 v12, 0x79

    aput-byte v12, v5, v9

    const/16 v13, -0x70

    aput-byte v13, v5, v7

    const/16 v19, 0x58

    aput-byte v19, v5, v8

    const/16 v19, -0x1c

    aput-byte v19, v5, v6

    new-array v15, v6, [B

    aput-byte v13, v15, v11

    const/16 v19, -0x20

    aput-byte v19, v15, v14

    const/16 v19, -0x3e

    aput-byte v19, v15, v16

    const/16 v19, -0x4a

    aput-byte v19, v15, v10

    const/16 v19, 0x45

    aput-byte v19, v15, v4

    const/16 v19, 0x16

    aput-byte v19, v15, v9

    const/16 v19, -0x1b

    aput-byte v19, v15, v7

    const/16 v19, 0x36

    aput-byte v19, v15, v8

    invoke-static {v5, v15}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v3, v5}, Lorg/json/JSONObject;->has(Ljava/lang/String;)Z

    move-result v5

    if-eqz v5, :cond_365

    new-array v5, v0, [B

    const/16 v15, 0x6e

    aput-byte v15, v5, v11

    const/16 v15, -0x32

    aput-byte v15, v5, v14

    const/16 v15, -0x9

    aput-byte v15, v5, v16

    const/16 v15, -0x53

    aput-byte v15, v5, v10

    const/16 v15, 0x2f

    aput-byte v15, v5, v4

    const/16 v15, -0x2e

    aput-byte v15, v5, v9

    const/16 v15, 0x28

    aput-byte v15, v5, v7

    const/16 v15, -0x4a

    aput-byte v15, v5, v8

    const/16 v15, 0x6a

    aput-byte v15, v5, v6

    new-array v15, v6, [B

    const/16 v19, 0x1e

    aput-byte v19, v15, v11

    const/16 v19, -0x51

    aput-byte v19, v15, v14

    aput-byte v13, v15, v16

    const/16 v19, -0x38

    aput-byte v19, v15, v10

    const/16 v19, 0x4c

    aput-byte v19, v15, v4

    const/16 v19, -0x43

    aput-byte v19, v15, v9

    const/16 v19, 0x5d

    aput-byte v19, v15, v7

    const/16 v19, -0x28

    aput-byte v19, v15, v8

    invoke-static {v5, v15}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v3, v5}, Lorg/json/JSONObject;->get(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v5

    instance-of v5, v5, Ljava/lang/Integer;

    if-eqz v5, :cond_365

    new-array v5, v0, [B

    aput-byte v0, v5, v11

    const/16 v0, 0x74

    aput-byte v0, v5, v14

    aput-byte v12, v5, v16

    const/16 v0, 0x47

    aput-byte v0, v5, v10

    const/16 v0, 0x29

    aput-byte v0, v5, v4

    const/16 v0, 0x1d

    aput-byte v0, v5, v9

    const/16 v0, -0x45

    aput-byte v0, v5, v7

    aput-byte v12, v5, v8

    const/16 v0, 0xd

    aput-byte v0, v5, v6

    new-array v0, v6, [B

    aput-byte v12, v0, v11

    const/16 v12, 0x15

    aput-byte v12, v0, v14

    const/16 v12, 0x1e

    aput-byte v12, v0, v16

    const/16 v12, 0x22

    aput-byte v12, v0, v10

    const/16 v12, 0x4a

    aput-byte v12, v0, v4

    const/16 v12, 0x72

    aput-byte v12, v0, v9

    const/16 v12, -0x32

    aput-byte v12, v0, v7

    const/16 v12, 0x17

    aput-byte v12, v0, v8

    invoke-static {v5, v0}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v0

    :goto_35f
    invoke-virtual {v3, v0}, Lorg/json/JSONObject;->getInt(Ljava/lang/String;)I

    move-result v0

    goto/16 :goto_6b3

    :cond_365
    new-array v5, v4, [B

    const/16 v12, 0x52

    aput-byte v12, v5, v11

    const/16 v12, 0x6a

    aput-byte v12, v5, v14

    aput-byte v13, v5, v16

    const/16 v12, 0x78

    aput-byte v12, v5, v10

    new-array v12, v6, [B

    const/16 v13, 0x36

    aput-byte v13, v12, v11

    const/16 v13, 0xb

    aput-byte v13, v12, v14

    const/16 v13, -0x1c

    aput-byte v13, v12, v16

    const/16 v13, 0x19

    aput-byte v13, v12, v10

    const/16 v13, -0x77

    aput-byte v13, v12, v4

    const/16 v13, 0x11

    aput-byte v13, v12, v9

    const/16 v13, 0x3b

    aput-byte v13, v12, v7

    aput-byte v0, v12, v8

    invoke-static {v5, v12}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v3, v5}, Lorg/json/JSONObject;->has(Ljava/lang/String;)Z

    move-result v5

    if-eqz v5, :cond_6b0

    new-array v5, v4, [B

    const/16 v12, 0x2b

    aput-byte v12, v5, v11

    const/16 v12, 0x2a

    aput-byte v12, v5, v14

    const/16 v12, 0x16

    aput-byte v12, v5, v16

    const/16 v12, -0x19

    aput-byte v12, v5, v10

    new-array v12, v6, [B

    const/16 v13, 0x4f

    aput-byte v13, v12, v11

    const/16 v13, 0x4b

    aput-byte v13, v12, v14

    const/16 v13, 0x62

    aput-byte v13, v12, v16

    const/16 v13, -0x7a

    aput-byte v13, v12, v10

    const/16 v13, -0x4d

    aput-byte v13, v12, v4

    const/16 v13, 0xc

    aput-byte v13, v12, v9

    const/16 v13, 0x7c

    aput-byte v13, v12, v7

    aput-byte v8, v12, v8

    invoke-static {v5, v12}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v3, v5}, Lorg/json/JSONObject;->get(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v5

    instance-of v5, v5, Lorg/json/JSONObject;

    if-eqz v5, :cond_6b0

    new-array v5, v4, [B

    const/16 v12, 0xc

    aput-byte v12, v5, v11

    const/16 v12, 0x6d

    aput-byte v12, v5, v14

    const/16 v12, -0x76

    aput-byte v12, v5, v16

    const/16 v12, -0x15

    aput-byte v12, v5, v10

    new-array v12, v6, [B

    const/16 v13, 0x68

    aput-byte v13, v12, v11

    const/16 v13, 0xc

    aput-byte v13, v12, v14

    const/4 v13, -0x2

    aput-byte v13, v12, v16

    const/16 v13, -0x76

    aput-byte v13, v12, v10

    const/16 v13, 0x47

    aput-byte v13, v12, v4

    const/16 v13, -0x17

    aput-byte v13, v12, v9

    const/16 v13, -0x5e

    aput-byte v13, v12, v7

    const/16 v13, 0x4b

    aput-byte v13, v12, v8

    invoke-static {v5, v12}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v3, v5}, Lorg/json/JSONObject;->getJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v5

    new-array v12, v9, [B

    const/16 v13, -0x15

    aput-byte v13, v12, v11

    const/16 v13, 0x70

    aput-byte v13, v12, v14

    const/16 v13, 0x52

    aput-byte v13, v12, v16

    const/16 v13, -0x72

    aput-byte v13, v12, v10

    const/16 v13, 0x75

    aput-byte v13, v12, v4

    new-array v13, v6, [B

    const/16 v15, -0x61

    aput-byte v15, v13, v11

    const/16 v15, 0x1f

    aput-byte v15, v13, v14

    aput-byte v17, v13, v16

    const/16 v15, -0x11

    aput-byte v15, v13, v10

    const/16 v15, 0x19

    aput-byte v15, v13, v4

    const/16 v15, -0x54

    aput-byte v15, v13, v9

    const/16 v15, -0x61

    aput-byte v15, v13, v7

    const/16 v15, -0x5c

    aput-byte v15, v13, v8

    invoke-static {v12, v13}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v12

    invoke-virtual {v5, v12}, Lorg/json/JSONObject;->has(Ljava/lang/String;)Z

    move-result v5

    if-eqz v5, :cond_6b0

    new-array v5, v4, [B

    const/16 v12, -0x27

    aput-byte v12, v5, v11

    const/16 v12, 0x69

    aput-byte v12, v5, v14

    const/16 v12, 0x1f

    aput-byte v12, v5, v16

    const/16 v12, -0x60

    aput-byte v12, v5, v10

    new-array v12, v6, [B

    const/16 v13, -0x43

    aput-byte v13, v12, v11

    aput-byte v6, v12, v14

    const/16 v13, 0x6b

    aput-byte v13, v12, v16

    const/16 v13, -0x3f

    aput-byte v13, v12, v10

    const/16 v13, -0x6d

    aput-byte v13, v12, v4

    const/16 v13, -0x61

    aput-byte v13, v12, v9

    const/16 v13, 0x7d

    aput-byte v13, v12, v7

    const/16 v13, 0x77

    aput-byte v13, v12, v8

    invoke-static {v5, v12}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v3, v5}, Lorg/json/JSONObject;->getJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v5

    new-array v12, v9, [B

    const/16 v13, -0x48

    aput-byte v13, v12, v11

    const/16 v13, -0x78

    aput-byte v13, v12, v14

    const/16 v13, -0x69

    aput-byte v13, v12, v16

    const/16 v13, 0x32

    aput-byte v13, v12, v10

    aput-byte v6, v12, v4

    new-array v13, v6, [B

    const/16 v15, -0x34

    aput-byte v15, v13, v11

    const/16 v15, -0x19

    aput-byte v15, v13, v14

    const/16 v15, -0x1d

    aput-byte v15, v13, v16

    const/16 v15, 0x53

    aput-byte v15, v13, v10

    const/16 v17, 0x64

    aput-byte v17, v13, v4

    const/16 v19, 0x3c

    aput-byte v19, v13, v9

    const/16 v19, -0x4b

    aput-byte v19, v13, v7

    const/16 v19, 0x1a

    aput-byte v19, v13, v8

    invoke-static {v12, v13}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v12

    invoke-virtual {v5, v12}, Lorg/json/JSONObject;->get(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v5

    instance-of v5, v5, Ljava/lang/Integer;

    if-eqz v5, :cond_6b0

    new-array v5, v4, [B

    const/16 v12, -0x20

    aput-byte v12, v5, v11

    const/16 v12, -0x45

    aput-byte v12, v5, v14

    const/16 v12, -0x54

    aput-byte v12, v5, v16

    const/16 v12, 0x4d

    aput-byte v12, v5, v10

    new-array v12, v6, [B

    aput-byte v18, v12, v11

    const/16 v13, -0x26

    aput-byte v13, v12, v14

    const/16 v18, -0x28

    aput-byte v18, v12, v16

    const/16 v18, 0x2c

    aput-byte v18, v12, v10

    const/16 v18, 0x23

    aput-byte v18, v12, v4

    const/16 v18, 0x4b

    aput-byte v18, v12, v9

    const/16 v18, -0x5a

    aput-byte v18, v12, v7

    aput-byte v15, v12, v8

    invoke-static {v5, v12}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v3, v5}, Lorg/json/JSONObject;->getJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v5

    new-array v12, v9, [B

    aput-byte v16, v12, v11

    const/16 v18, -0x4d

    aput-byte v18, v12, v14

    aput-byte v9, v12, v16

    const/16 v18, -0xb

    aput-byte v18, v12, v10

    const/16 v18, -0x44

    aput-byte v18, v12, v4

    new-array v0, v6, [B

    const/16 v18, 0x6e

    aput-byte v18, v0, v11

    aput-byte v13, v0, v14

    const/16 v18, 0x68

    aput-byte v18, v0, v16

    const/16 v18, -0x64

    aput-byte v18, v0, v10

    const/16 v18, -0x38

    aput-byte v18, v0, v4

    aput-byte v15, v0, v9

    const/16 v18, -0x60

    aput-byte v18, v0, v7

    const/16 v18, 0x39

    aput-byte v18, v0, v8

    invoke-static {v12, v0}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v5, v0}, Lorg/json/JSONObject;->has(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_6b0

    new-array v0, v4, [B

    const/16 v5, 0x7d

    aput-byte v5, v0, v11

    aput-byte v17, v0, v14

    const/16 v5, 0x30

    aput-byte v5, v0, v16

    const/16 v5, -0x80

    aput-byte v5, v0, v10

    new-array v5, v6, [B

    const/16 v12, 0x19

    aput-byte v12, v5, v11

    aput-byte v9, v5, v14

    const/16 v12, 0x44

    aput-byte v12, v5, v16

    const/16 v12, -0x1f

    aput-byte v12, v5, v10

    const/16 v12, 0x6c

    aput-byte v12, v5, v4

    const/16 v12, 0x78

    aput-byte v12, v5, v9

    const/16 v12, -0x62

    aput-byte v12, v5, v7

    const/16 v12, -0x64

    aput-byte v12, v5, v8

    invoke-static {v0, v5}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v3, v0}, Lorg/json/JSONObject;->getJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v0

    new-array v5, v9, [B

    aput-byte v11, v5, v11

    const/16 v12, 0x5c

    aput-byte v12, v5, v14

    const/4 v12, -0x1

    aput-byte v12, v5, v16

    const/16 v12, -0x4a

    aput-byte v12, v5, v10

    const/16 v12, 0x7c

    aput-byte v12, v5, v4

    new-array v12, v6, [B

    const/16 v18, 0x6c

    aput-byte v18, v12, v11

    const/16 v18, 0x35

    aput-byte v18, v12, v14

    const/16 v18, -0x6e

    aput-byte v18, v12, v16

    const/16 v18, -0x21

    aput-byte v18, v12, v10

    aput-byte v6, v12, v4

    const/16 v18, 0x3a

    aput-byte v18, v12, v9

    const/16 v18, -0x5e

    aput-byte v18, v12, v7

    const/16 v18, 0x54

    aput-byte v18, v12, v8

    invoke-static {v5, v12}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v0, v5}, Lorg/json/JSONObject;->get(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    instance-of v0, v0, Ljava/lang/Integer;

    if-eqz v0, :cond_6b0

    new-array v0, v4, [B

    const/16 v5, -0x62

    aput-byte v5, v0, v11

    const/16 v5, 0x36

    aput-byte v5, v0, v14

    const/16 v5, -0x7f

    aput-byte v5, v0, v16

    const/16 v5, -0x11

    aput-byte v5, v0, v10

    new-array v5, v6, [B

    const/4 v12, -0x6

    aput-byte v12, v5, v11

    const/16 v12, 0x57

    aput-byte v12, v5, v14

    const/16 v12, -0xb

    aput-byte v12, v5, v16

    const/16 v12, -0x72

    aput-byte v12, v5, v10

    const/16 v12, 0x6e

    aput-byte v12, v5, v4

    const/16 v12, -0x60

    aput-byte v12, v5, v9

    const/16 v12, -0x74

    aput-byte v12, v5, v7

    aput-byte v13, v5, v8

    invoke-static {v0, v5}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v3, v0}, Lorg/json/JSONObject;->getJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v0

    new-array v5, v9, [B

    aput-byte v6, v5, v11

    aput-byte v15, v5, v14

    const/16 v12, 0x9

    aput-byte v12, v5, v16

    aput-byte v4, v5, v10

    aput-byte v12, v5, v4

    new-array v12, v6, [B

    aput-byte v17, v12, v11

    const/16 v15, 0x3a

    aput-byte v15, v12, v14

    aput-byte v17, v12, v16

    const/16 v15, 0x6d

    aput-byte v15, v12, v10

    const/16 v15, 0x7d

    aput-byte v15, v12, v4

    const/16 v15, 0x21

    aput-byte v15, v12, v9

    const/16 v15, -0x80

    aput-byte v15, v12, v7

    const/16 v15, -0x49

    aput-byte v15, v12, v8

    invoke-static {v5, v12}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v0, v5}, Lorg/json/JSONObject;->getInt(Ljava/lang/String;)I

    move-result v0

    new-array v5, v4, [B

    const/16 v12, -0x11

    aput-byte v12, v5, v11

    const/16 v12, -0x16

    aput-byte v12, v5, v14

    const/16 v12, 0x48

    aput-byte v12, v5, v16

    const/16 v12, 0x30

    aput-byte v12, v5, v10

    new-array v12, v6, [B

    const/16 v15, -0x75

    aput-byte v15, v12, v11

    const/16 v15, -0x75

    aput-byte v15, v12, v14

    const/16 v15, 0x3c

    aput-byte v15, v12, v16

    const/16 v15, 0x51

    aput-byte v15, v12, v10

    const/16 v15, 0x6d

    aput-byte v15, v12, v4

    const/16 v15, 0x33

    aput-byte v15, v12, v9

    const/16 v15, -0x59

    aput-byte v15, v12, v7

    aput-byte v13, v12, v8

    invoke-static {v5, v12}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v3, v5}, Lorg/json/JSONObject;->getJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v5

    new-array v12, v9, [B

    const/16 v13, -0x79

    aput-byte v13, v12, v11

    const/16 v13, -0x76

    aput-byte v13, v12, v14

    const/16 v13, 0x73

    aput-byte v13, v12, v16

    const/16 v13, 0x3e

    aput-byte v13, v12, v10

    const/16 v13, -0x3d

    aput-byte v13, v12, v4

    new-array v13, v6, [B

    const/16 v15, -0xd

    aput-byte v15, v13, v11

    const/16 v15, -0x1b

    aput-byte v15, v13, v14

    aput-byte v8, v13, v16

    const/16 v15, 0x5f

    aput-byte v15, v13, v10

    const/16 v15, -0x51

    aput-byte v15, v13, v4

    const/16 v15, 0x35

    aput-byte v15, v13, v9

    const/16 v15, -0x1c

    aput-byte v15, v13, v7

    const/16 v15, -0x7a

    aput-byte v15, v13, v8

    invoke-static {v12, v13}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v12

    invoke-virtual {v5, v12}, Lorg/json/JSONObject;->getInt(Ljava/lang/String;)I

    move-result v5

    rem-int v12, v5, v0

    if-nez v12, :cond_6a8

    div-int/2addr v5, v0

    goto :goto_6aa

    :cond_6a8
    div-int/2addr v5, v0
    :try_end_6a9
    .catch Ljava/lang/Exception; {:try_start_18d .. :try_end_6a9} :catch_6ac

    add-int/2addr v5, v14

    :goto_6aa
    move v0, v5

    goto :goto_6b3

    :catch_6ac
    move-exception v0

    invoke-static {v0}, Lcom/github/catvod/crawler/SpiderDebug;->log(Ljava/lang/Throwable;)V

    :cond_6b0
    const v0, 0x7fffffff

    :goto_6b3
    new-instance v5, Lorg/json/JSONArray;

    invoke-direct {v5}, Lorg/json/JSONArray;-><init>()V

    new-array v12, v4, [B

    fill-array-data v12, :array_a4a

    new-array v13, v6, [B

    fill-array-data v13, :array_a50

    invoke-static {v12, v13}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v12

    invoke-virtual {v3, v12}, Lorg/json/JSONObject;->has(Ljava/lang/String;)Z

    move-result v12

    if-eqz v12, :cond_6f2

    new-array v12, v4, [B

    fill-array-data v12, :array_a58

    new-array v13, v6, [B

    fill-array-data v13, :array_a5e

    invoke-static {v12, v13}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v12

    invoke-virtual {v3, v12}, Lorg/json/JSONObject;->get(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v12

    instance-of v12, v12, Lorg/json/JSONArray;

    if-eqz v12, :cond_6f2

    new-array v4, v4, [B

    fill-array-data v4, :array_a66

    new-array v12, v6, [B

    fill-array-data v12, :array_a6c

    invoke-static {v4, v12}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v4

    goto/16 :goto_7c3

    :cond_6f2
    new-array v12, v4, [B

    fill-array-data v12, :array_a74

    new-array v13, v6, [B

    fill-array-data v13, :array_a7a

    invoke-static {v12, v13}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v12

    invoke-virtual {v3, v12}, Lorg/json/JSONObject;->has(Ljava/lang/String;)Z

    move-result v12

    if-eqz v12, :cond_78b

    new-array v12, v4, [B

    fill-array-data v12, :array_a82

    new-array v13, v6, [B

    fill-array-data v13, :array_a88

    invoke-static {v12, v13}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v12

    invoke-virtual {v3, v12}, Lorg/json/JSONObject;->get(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v12

    instance-of v12, v12, Lorg/json/JSONObject;

    if-eqz v12, :cond_78b

    new-array v12, v4, [B

    fill-array-data v12, :array_a90

    new-array v13, v6, [B

    fill-array-data v13, :array_a96

    invoke-static {v12, v13}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v12

    invoke-virtual {v3, v12}, Lorg/json/JSONObject;->getJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v12

    new-array v13, v4, [B

    fill-array-data v13, :array_a9e

    new-array v14, v6, [B

    fill-array-data v14, :array_aa4

    invoke-static {v13, v14}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v13

    invoke-virtual {v12, v13}, Lorg/json/JSONObject;->has(Ljava/lang/String;)Z

    move-result v12

    if-eqz v12, :cond_78b

    new-array v12, v4, [B

    fill-array-data v12, :array_aac

    new-array v13, v6, [B

    fill-array-data v13, :array_ab2

    invoke-static {v12, v13}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v12

    invoke-virtual {v3, v12}, Lorg/json/JSONObject;->getJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v12

    new-array v13, v4, [B

    fill-array-data v13, :array_aba

    new-array v14, v6, [B

    fill-array-data v14, :array_ac0

    invoke-static {v13, v14}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v13

    invoke-virtual {v12, v13}, Lorg/json/JSONObject;->get(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v12

    instance-of v12, v12, Lorg/json/JSONArray;

    if-eqz v12, :cond_78b

    new-array v12, v4, [B

    fill-array-data v12, :array_ac8

    new-array v13, v6, [B

    fill-array-data v13, :array_ace

    invoke-static {v12, v13}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v12

    invoke-virtual {v3, v12}, Lorg/json/JSONObject;->getJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v3

    new-array v4, v4, [B

    fill-array-data v4, :array_ad6

    new-array v12, v6, [B

    fill-array-data v12, :array_adc

    invoke-static {v4, v12}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v4

    goto :goto_7c3

    :cond_78b
    new-array v12, v4, [B

    fill-array-data v12, :array_ae4

    new-array v13, v6, [B

    fill-array-data v13, :array_aea

    invoke-static {v12, v13}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v12

    invoke-virtual {v3, v12}, Lorg/json/JSONObject;->has(Ljava/lang/String;)Z

    move-result v12

    if-eqz v12, :cond_7c8

    new-array v12, v4, [B

    fill-array-data v12, :array_af2

    new-array v13, v6, [B

    fill-array-data v13, :array_af8

    invoke-static {v12, v13}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v12

    invoke-virtual {v3, v12}, Lorg/json/JSONObject;->get(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v12

    instance-of v12, v12, Lorg/json/JSONArray;

    if-eqz v12, :cond_7c8

    new-array v4, v4, [B

    fill-array-data v4, :array_b00

    new-array v12, v6, [B

    fill-array-data v12, :array_b06

    invoke-static {v4, v12}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v4

    :goto_7c3
    invoke-virtual {v3, v4}, Lorg/json/JSONObject;->getJSONArray(Ljava/lang/String;)Lorg/json/JSONArray;

    move-result-object v3

    goto :goto_7c9

    :cond_7c8
    const/4 v3, 0x0

    :goto_7c9
    if-eqz v3, :cond_8e8

    :goto_7cb
    invoke-virtual {v3}, Lorg/json/JSONArray;->length()I

    move-result v4

    if-ge v11, v4, :cond_8e8

    invoke-virtual {v3, v11}, Lorg/json/JSONArray;->getJSONObject(I)Lorg/json/JSONObject;

    move-result-object v4

    new-array v12, v7, [B

    fill-array-data v12, :array_b0e

    new-array v13, v6, [B

    fill-array-data v13, :array_b16

    invoke-static {v12, v13}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v12

    invoke-virtual {v4, v12}, Lorg/json/JSONObject;->has(Ljava/lang/String;)Z

    move-result v12

    if-eqz v12, :cond_865

    new-instance v12, Lorg/json/JSONObject;

    invoke-direct {v12}, Lorg/json/JSONObject;-><init>()V

    new-array v13, v7, [B

    fill-array-data v13, :array_b1e

    new-array v14, v6, [B

    fill-array-data v14, :array_b26

    invoke-static {v13, v14}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v13

    new-array v7, v7, [B

    fill-array-data v7, :array_b2e

    new-array v14, v6, [B

    fill-array-data v14, :array_b36

    .line 1
    invoke-static {v7, v14, v4, v12, v13}, Lcom/github/catvod/spider/appysv2/o/a;->a([B[BLorg/json/JSONObject;Lorg/json/JSONObject;Ljava/lang/String;)V

    new-array v7, v6, [B

    .line 2
    fill-array-data v7, :array_b3e

    new-array v13, v6, [B

    fill-array-data v13, :array_b46

    invoke-static {v7, v13}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v7

    new-array v13, v6, [B

    fill-array-data v13, :array_b4e

    new-array v14, v6, [B

    fill-array-data v14, :array_b56

    .line 3
    invoke-static {v13, v14, v4, v12, v7}, Lcom/github/catvod/spider/appysv2/o/a;->a([B[BLorg/json/JSONObject;Lorg/json/JSONObject;Ljava/lang/String;)V

    new-array v7, v8, [B

    .line 4
    fill-array-data v7, :array_b5e

    new-array v13, v6, [B

    fill-array-data v13, :array_b66

    invoke-static {v7, v13}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v7

    new-array v13, v8, [B

    fill-array-data v13, :array_b6e

    new-array v14, v6, [B

    fill-array-data v14, :array_b76

    .line 5
    invoke-static {v13, v14, v4, v12, v7}, Lcom/github/catvod/spider/appysv2/o/a;->a([B[BLorg/json/JSONObject;Lorg/json/JSONObject;Ljava/lang/String;)V

    const/16 v7, 0xb

    new-array v13, v7, [B

    .line 6
    fill-array-data v13, :array_b7e

    new-array v14, v6, [B

    fill-array-data v14, :array_b88

    invoke-static {v13, v14}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v13

    new-array v7, v7, [B

    fill-array-data v7, :array_b90

    new-array v14, v6, [B

    fill-array-data v14, :array_b9a

    invoke-static {v7, v14}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v4, v7}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v12, v13, v4}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    goto :goto_8e0

    :cond_865
    new-instance v12, Lorg/json/JSONObject;

    invoke-direct {v12}, Lorg/json/JSONObject;-><init>()V

    new-array v7, v7, [B

    fill-array-data v7, :array_ba2

    new-array v13, v6, [B

    fill-array-data v13, :array_baa

    invoke-static {v7, v13}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v7

    new-array v13, v6, [B

    fill-array-data v13, :array_bb2

    new-array v14, v6, [B

    fill-array-data v14, :array_bba

    .line 7
    invoke-static {v13, v14, v4, v12, v7}, Lcom/github/catvod/spider/appysv2/o/a;->a([B[BLorg/json/JSONObject;Lorg/json/JSONObject;Ljava/lang/String;)V

    new-array v7, v6, [B

    .line 8
    fill-array-data v7, :array_bc2

    new-array v13, v6, [B

    fill-array-data v13, :array_bca

    invoke-static {v7, v13}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v7

    new-array v13, v9, [B

    fill-array-data v13, :array_bd2

    new-array v14, v6, [B

    fill-array-data v14, :array_bda

    .line 9
    invoke-static {v13, v14, v4, v12, v7}, Lcom/github/catvod/spider/appysv2/o/a;->a([B[BLorg/json/JSONObject;Lorg/json/JSONObject;Ljava/lang/String;)V

    new-array v7, v8, [B

    .line 10
    fill-array-data v7, :array_be2

    new-array v13, v6, [B

    fill-array-data v13, :array_bea

    invoke-static {v7, v13}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v7

    new-array v13, v10, [B

    fill-array-data v13, :array_bf2

    new-array v14, v6, [B

    fill-array-data v14, :array_bf8

    .line 11
    invoke-static {v13, v14, v4, v12, v7}, Lcom/github/catvod/spider/appysv2/o/a;->a([B[BLorg/json/JSONObject;Lorg/json/JSONObject;Ljava/lang/String;)V

    const/16 v7, 0xb

    new-array v7, v7, [B

    .line 12
    fill-array-data v7, :array_c00

    new-array v13, v6, [B

    fill-array-data v13, :array_c0a

    invoke-static {v7, v13}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v7

    new-array v13, v9, [B

    fill-array-data v13, :array_c12

    new-array v14, v6, [B

    fill-array-data v14, :array_c1a

    invoke-static {v13, v14}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v13

    invoke-virtual {v4, v13}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v12, v7, v4}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    :goto_8e0
    invoke-virtual {v5, v12}, Lorg/json/JSONArray;->put(Ljava/lang/Object;)Lorg/json/JSONArray;

    add-int/lit8 v11, v11, 0x1

    const/4 v7, 0x6

    goto/16 :goto_7cb

    :cond_8e8
    new-instance v3, Lorg/json/JSONObject;

    invoke-direct {v3}, Lorg/json/JSONObject;-><init>()V

    const/4 v4, 0x4

    new-array v4, v4, [B

    fill-array-data v4, :array_c22

    new-array v7, v6, [B

    fill-array-data v7, :array_c28

    invoke-static {v4, v7}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/16 v2, 0x9

    new-array v2, v2, [B

    fill-array-data v2, :array_c30

    new-array v4, v6, [B

    fill-array-data v4, :array_c3a

    invoke-static {v2, v4}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v3, v2, v0}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    new-array v0, v9, [B

    fill-array-data v0, :array_c42

    new-array v2, v6, [B

    fill-array-data v2, :array_c4a

    invoke-static {v0, v2}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v0

    const/16 v2, 0x5a

    invoke-virtual {v3, v0, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    new-array v0, v9, [B

    fill-array-data v0, :array_c52

    new-array v2, v6, [B

    fill-array-data v2, :array_c5a

    invoke-static {v0, v2}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v0

    const v2, 0x7fffffff

    invoke-virtual {v3, v0, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    const/4 v0, 0x4

    new-array v0, v0, [B

    fill-array-data v0, :array_c62

    new-array v2, v6, [B

    fill-array-data v2, :array_c68

    invoke-static {v0, v2}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v3, v0, v5}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    invoke-virtual {v3}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0

    :array_950
    .array-data 1
        0x4at
        0x10t
        0x34t
        0x76t
    .end array-data

    :array_956
    .array-data 1
        0x69t
        0x40t
        0x7at
        0x55t
        -0x62t
        -0x2dt
        -0x22t
        -0x78t
    .end array-data

    :array_95e
    .array-data 1
        0x41t
        0x5bt
        0x6ct
        -0xdt
        0x5bt
        -0x43t
        -0x2et
        0x14t
        -0x39t
        -0x7bt
        -0x7ct
    .end array-data

    :array_968
    .array-data 1
        -0x5at
        -0xat
        -0x9t
        0x1at
        -0x25t
        0x34t
        -0x4ft
        0x78t
    .end array-data

    :array_970
    .array-data 1
        -0x56t
        0x1ft
        0x69t
        0x50t
        0x20t
    .end array-data

    nop

    :array_978
    .array-data 1
        -0x37t
        0x73t
        0x8t
        0x23t
        0x53t
        -0x59t
        -0x7ft
        -0x1t
    .end array-data

    :array_980
    .array-data 1
        0x52t
        0x53t
        -0x17t
        -0x3t
        0x30t
    .end array-data

    nop

    :array_988
    .array-data 1
        0x31t
        0x3ft
        -0x78t
        -0x72t
        0x43t
        -0x3t
        0x6bt
        -0x2dt
    .end array-data

    :array_990
    .array-data 1
        -0xft
        0x56t
        0x68t
        0x68t
        0x14t
        0x1et
        0x40t
        0x3et
        0x73t
        -0x66t
    .end array-data

    nop

    :array_99a
    .array-data 1
        0x16t
        -0x5t
        -0xdt
        -0x7ft
        -0x6ct
        -0x69t
        0x21t
        0x4ct
    .end array-data

    :array_9a2
    .array-data 1
        0x72t
        0x7ft
        0x4bt
        0x15t
    .end array-data

    :array_9a8
    .array-data 1
        0x13t
        0xdt
        0x2et
        0x74t
        -0x20t
        0x34t
        -0x54t
        -0x5t
    .end array-data

    :array_9b0
    .array-data 1
        -0x48t
        -0x32t
        -0x6dt
        -0x72t
    .end array-data

    :array_9b6
    .array-data 1
        -0x27t
        -0x44t
        -0xat
        -0x11t
        0x1ct
        0x2ft
        -0x23t
        -0x53t
    .end array-data

    :array_9be
    .array-data 1
        -0x14t
        0x7ct
        -0x27t
        0x68t
        0xft
        -0x44t
        0x70t
        -0x35t
        0x65t
        -0x4at
    .end array-data

    nop

    :array_9c8
    .array-data 1
        0xbt
        -0x2ft
        0x42t
        -0x7ft
        -0x71t
        0x35t
        0x1ct
        -0x56t
    .end array-data

    :array_9d0
    .array-data 1
        0x12t
        0x5ct
        0x1t
        -0x7ct
    .end array-data

    :array_9d6
    .array-data 1
        0x7et
        0x3dt
        0x6ft
        -0x1dt
        0x1ct
        -0xet
        -0x53t
        -0x45t
    .end array-data

    :array_9de
    .array-data 1
        -0x5ct
        -0x8t
        -0x7et
        0x4dt
    .end array-data

    :array_9e4
    .array-data 1
        -0x38t
        -0x67t
        -0x14t
        0x2at
        0xbt
        -0x55t
        -0x32t
        0x5at
    .end array-data

    :array_9ec
    .array-data 1
        -0x1bt
        -0x5ct
        0x11t
        -0x7dt
        -0x1at
        0x60t
        0x1at
        0x5ft
        0x63t
        0x7bt
    .end array-data

    nop

    :array_9f6
    .array-data 1
        0x2t
        0x9t
        -0x76t
        0x6at
        0x66t
        -0x17t
        0x63t
        0x3at
    .end array-data

    :array_9fe
    .array-data 1
        0x24t
        -0x7dt
        -0x1bt
        -0x36t
    .end array-data

    :array_a04
    .array-data 1
        0x5dt
        -0x1at
        -0x7ct
        -0x48t
        0x4t
        -0x1ct
        0x72t
        0x7dt
    .end array-data

    :array_a0c
    .array-data 1
        -0x57t
        0x12t
        0x19t
        0x10t
    .end array-data

    :array_a12
    .array-data 1
        -0x30t
        0x77t
        0x78t
        0x62t
        0x6dt
        -0x31t
        0x77t
        0x3t
    .end array-data

    :array_a1a
    .array-data 1
        0x17t
        -0x37t
        -0x6bt
        -0x1et
        -0x7ct
        -0x13t
    .end array-data

    nop

    :array_a22
    .array-data 1
        -0xft
        0x47t
        0x7t
        0x7t
        0x3et
        0x62t
        0x6ct
        -0x65t
    .end array-data

    :array_a2a
    .array-data 1
        -0x68t
        -0x55t
        0x2bt
        0x32t
        0x32t
        -0x7et
    .end array-data

    nop

    :array_a32
    .array-data 1
        0x7et
        0x25t
        -0x47t
        -0x29t
        -0x78t
        0xdt
        -0x43t
        -0x5dt
    .end array-data

    :array_a3a
    .array-data 1
        -0x64t
        0x1dt
        -0x28t
        -0x55t
        0x68t
        -0x34t
    .end array-data

    nop

    :array_a42
    .array-data 1
        0x7at
        -0x6dt
        0x4at
        0x4et
        -0x2et
        0x43t
        0x0t
        -0x57t
    .end array-data

    :array_a4a
    .array-data 1
        0x29t
        0x52t
        -0x1ft
        -0x2bt
    .end array-data

    :array_a50
    .array-data 1
        0x45t
        0x3bt
        -0x6et
        -0x5ft
        0x7at
        -0x51t
        0x2t
        0x55t
    .end array-data

    :array_a58
    .array-data 1
        -0x7at
        -0x7ft
        -0x18t
        0x2ft
    .end array-data

    :array_a5e
    .array-data 1
        -0x16t
        -0x18t
        -0x65t
        0x5bt
        0x62t
        -0x41t
        0x61t
        -0x2ct
    .end array-data

    :array_a66
    .array-data 1
        -0x6t
        -0x7t
        -0x4ft
        0x48t
    .end array-data

    :array_a6c
    .array-data 1
        -0x6at
        -0x70t
        -0x3et
        0x3ct
        0x38t
        0x67t
        0x1dt
        0x1dt
    .end array-data

    :array_a74
    .array-data 1
        0x6ct
        -0x17t
        -0x2ct
        0x76t
    .end array-data

    :array_a7a
    .array-data 1
        0x8t
        -0x78t
        -0x60t
        0x17t
        0x27t
        -0x36t
        -0x60t
        -0x1ft
    .end array-data

    :array_a82
    .array-data 1
        0x1t
        0x5bt
        0x7dt
        0x33t
    .end array-data

    :array_a88
    .array-data 1
        0x65t
        0x3at
        0x9t
        0x52t
        0x21t
        -0x3at
        0x45t
        -0x77t
    .end array-data

    :array_a90
    .array-data 1
        -0x7ft
        -0x25t
        -0x3t
        -0x17t
    .end array-data

    :array_a96
    .array-data 1
        -0x1bt
        -0x46t
        -0x77t
        -0x78t
        0x37t
        0x44t
        -0x3at
        0x3et
    .end array-data

    :array_a9e
    .array-data 1
        -0x4at
        0xbt
        0x2et
        0x77t
    .end array-data

    :array_aa4
    .array-data 1
        -0x26t
        0x62t
        0x5dt
        0x3t
        -0x29t
        0x8t
        -0x2ft
        0x2et
    .end array-data

    :array_aac
    .array-data 1
        0x1bt
        -0x1ft
        -0x9t
        0x6ct
    .end array-data

    :array_ab2
    .array-data 1
        0x7ft
        -0x80t
        -0x7dt
        0xdt
        -0xct
        0x2at
        -0x48t
        0x59t
    .end array-data

    :array_aba
    .array-data 1
        -0x4at
        -0x37t
        0x49t
        -0x22t
    .end array-data

    :array_ac0
    .array-data 1
        -0x26t
        -0x60t
        0x3at
        -0x56t
        -0x7ct
        -0x61t
        -0x6bt
        0x1t
    .end array-data

    :array_ac8
    .array-data 1
        0x72t
        -0x1dt
        0x4at
        -0x52t
    .end array-data

    :array_ace
    .array-data 1
        0x16t
        -0x7et
        0x3et
        -0x31t
        0x4et
        -0x31t
        -0x72t
        0x65t
    .end array-data

    :array_ad6
    .array-data 1
        0x5at
        0x57t
        0x66t
        -0x80t
    .end array-data

    :array_adc
    .array-data 1
        0x36t
        0x3et
        0x15t
        -0xct
        -0x36t
        0x1ct
        0x22t
        0x73t
    .end array-data

    :array_ae4
    .array-data 1
        0xct
        -0x57t
        -0x71t
        -0x2dt
    .end array-data

    :array_aea
    .array-data 1
        0x68t
        -0x38t
        -0x5t
        -0x4et
        0x1et
        0x53t
        0x5bt
        -0x6bt
    .end array-data

    :array_af2
    .array-data 1
        -0x46t
        0x2ct
        0x55t
        0x5ct
    .end array-data

    :array_af8
    .array-data 1
        -0x22t
        0x4dt
        0x21t
        0x3dt
        -0x5at
        0x61t
        -0x5ct
        0x2ct
    .end array-data

    :array_b00
    .array-data 1
        -0x28t
        0x47t
        -0x7ft
        0x14t
    .end array-data

    :array_b06
    .array-data 1
        -0x44t
        0x26t
        -0xbt
        0x75t
        -0x11t
        -0x6at
        0x78t
        -0x4ct
    .end array-data

    :array_b0e
    .array-data 1
        -0x5ft
        0x22t
        -0x5ft
        0x4bt
        0x8t
        -0xet
    .end array-data

    nop

    :array_b16
    .array-data 1
        -0x29t
        0x4dt
        -0x3bt
        0x14t
        0x61t
        -0x6at
        0x56t
        -0x5ct
    .end array-data

    :array_b1e
    .array-data 1
        0x55t
        0x5at
        0x6t
        0x27t
        0x20t
        0x1et
    .end array-data

    nop

    :array_b26
    .array-data 1
        0x23t
        0x35t
        0x62t
        0x78t
        0x49t
        0x7at
        0x44t
        0x47t
    .end array-data

    :array_b2e
    .array-data 1
        0x4et
        -0x6bt
        -0x22t
        0x70t
        -0x3t
        -0x4t
    .end array-data

    nop

    :array_b36
    .array-data 1
        0x38t
        -0x6t
        -0x46t
        0x2ft
        -0x6ct
        -0x68t
        -0x59t
        0x12t
    .end array-data

    :array_b3e
    .array-data 1
        0x6at
        0x76t
        0x18t
        -0x22t
        -0x23t
        -0x26t
        -0x11t
        -0x19t
    .end array-data

    :array_b46
    .array-data 1
        0x1ct
        0x19t
        0x7ct
        -0x7ft
        -0x4dt
        -0x45t
        -0x7et
        -0x7et
    .end array-data

    :array_b4e
    .array-data 1
        0x3bt
        -0x4bt
        0x1ft
        -0x3at
        -0x1et
        -0x2dt
        0xft
        0x53t
    .end array-data

    :array_b56
    .array-data 1
        0x4dt
        -0x26t
        0x7bt
        -0x67t
        -0x74t
        -0x4et
        0x62t
        0x36t
    .end array-data

    :array_b5e
    .array-data 1
        0x44t
        0x7ct
        -0x76t
        -0x34t
        -0x32t
        -0x7ft
        0x2t
    .end array-data

    :array_b66
    .array-data 1
        0x32t
        0x13t
        -0x12t
        -0x6dt
        -0x42t
        -0x18t
        0x61t
        -0xct
    .end array-data

    :array_b6e
    .array-data 1
        -0x43t
        0x4ft
        -0xft
        0x27t
        0x56t
        -0x60t
        -0x43t
    .end array-data

    :array_b76
    .array-data 1
        -0x35t
        0x20t
        -0x6bt
        0x78t
        0x26t
        -0x37t
        -0x22t
        0x19t
    .end array-data

    :array_b7e
    .array-data 1
        0x63t
        -0x2et
        -0x76t
        -0x1dt
        0x43t
        0x68t
        0x35t
        0x49t
        0x67t
        -0x2at
        -0x63t
    .end array-data

    :array_b88
    .array-data 1
        0x15t
        -0x43t
        -0x12t
        -0x44t
        0x31t
        0xdt
        0x58t
        0x28t
    .end array-data

    :array_b90
    .array-data 1
        0x53t
        -0x3ft
        -0x23t
        -0xet
        -0x7dt
        -0x2et
        0x3ct
        0x20t
        0x57t
        -0x3bt
        -0x36t
    .end array-data

    :array_b9a
    .array-data 1
        0x25t
        -0x52t
        -0x47t
        -0x53t
        -0xft
        -0x49t
        0x51t
        0x41t
    .end array-data

    :array_ba2
    .array-data 1
        0x68t
        -0x2et
        0x3bt
        -0xet
        0x23t
        -0x54t
    .end array-data

    nop

    :array_baa
    .array-data 1
        0x1et
        -0x43t
        0x5ft
        -0x53t
        0x4at
        -0x38t
        0x52t
        -0x7dt
    .end array-data

    :array_bb2
    .array-data 1
        0x7bt
        -0x72t
        -0x17t
        -0x35t
        0x29t
        0x5at
        0x37t
        -0x19t
    .end array-data

    :array_bba
    .array-data 1
        0x15t
        -0x15t
        -0x6ft
        -0x41t
        0x45t
        0x33t
        0x59t
        -0x74t
    .end array-data

    :array_bc2
    .array-data 1
        -0x66t
        -0x4dt
        0x7et
        -0x10t
        -0x80t
        0x3bt
        0x15t
        -0x27t
    .end array-data

    :array_bca
    .array-data 1
        -0x14t
        -0x24t
        0x1at
        -0x51t
        -0x12t
        0x5at
        0x78t
        -0x44t
    .end array-data

    :array_bd2
    .array-data 1
        -0x71t
        0xdt
        -0x2t
        -0x4ft
        -0x35t
    .end array-data

    nop

    :array_bda
    .array-data 1
        -0x5t
        0x64t
        -0x76t
        -0x23t
        -0x52t
        0x4dt
        0x64t
        -0x35t
    .end array-data

    :array_be2
    .array-data 1
        0x29t
        0x6at
        -0x62t
        -0x6ft
        -0xat
        0x60t
        0x51t
    .end array-data

    :array_bea
    .array-data 1
        0x5ft
        0x5t
        -0x6t
        -0x32t
        -0x7at
        0x9t
        0x32t
        -0x37t
    .end array-data

    :array_bf2
    .array-data 1
        -0x6bt
        0x13t
        0x46t
    .end array-data

    :array_bf8
    .array-data 1
        -0x1bt
        0x7at
        0x25t
        -0x73t
        0x0t
        -0x29t
        0x73t
        0x9t
    .end array-data

    :array_c00
    .array-data 1
        -0x14t
        0x3bt
        0x1t
        -0x4at
        -0x6ct
        -0x54t
        -0x80t
        -0x6at
        -0x18t
        0x3ft
        0x16t
    .end array-data

    :array_c0a
    .array-data 1
        -0x66t
        0x54t
        0x65t
        -0x17t
        -0x1at
        -0x37t
        -0x13t
        -0x9t
    .end array-data

    :array_c12
    .array-data 1
        -0x66t
        0x33t
        0x3dt
        0x67t
        -0xbt
    .end array-data

    nop

    :array_c1a
    .array-data 1
        -0x17t
        0x47t
        0x5ct
        0x13t
        -0x70t
        0x72t
        0x5ct
        0x5et
    .end array-data

    :array_c22
    .array-data 1
        0x2t
        0x57t
        0x77t
        0x5et
    .end array-data

    :array_c28
    .array-data 1
        0x72t
        0x36t
        0x10t
        0x3bt
        -0x2et
        0x41t
        0x75t
        -0xdt
    .end array-data

    :array_c30
    .array-data 1
        -0x5et
        0x46t
        0x49t
        -0x31t
        -0x66t
        -0x21t
        -0x6ct
        0x52t
        -0x5at
    .end array-data

    nop

    :array_c3a
    .array-data 1
        -0x2et
        0x27t
        0x2et
        -0x56t
        -0x7t
        -0x50t
        -0x1ft
        0x3ct
    .end array-data

    :array_c42
    .array-data 1
        -0x53t
        0x3dt
        0x73t
        0x48t
        -0x7ct
    .end array-data

    nop

    :array_c4a
    .array-data 1
        -0x3ft
        0x54t
        0x1et
        0x21t
        -0x10t
        -0x1ct
        -0x2et
        0x37t
    .end array-data

    :array_c52
    .array-data 1
        -0x27t
        -0x4bt
        -0x5at
        0x79t
        0x36t
    .end array-data

    nop

    :array_c5a
    .array-data 1
        -0x53t
        -0x26t
        -0x2et
        0x18t
        0x5at
        -0x4ct
        0x7et
        0x24t
    .end array-data

    :array_c62
    .array-data 1
        0x53t
        -0x5et
        0x70t
        -0x5ct
    .end array-data

    :array_c68
    .array-data 1
        0x3ft
        -0x35t
        0x3t
        -0x30t
        -0x4et
        -0xft
        0x67t
        -0x3dt
    .end array-data
.end method

.method final d(Ljava/lang/String;)Ljava/lang/String;
    .registers 6

    const/16 v0, 0xb

    new-array v1, v0, [B

    fill-array-data v1, :array_106

    const/16 v2, 0x8

    new-array v3, v2, [B

    fill-array-data v3, :array_110

    invoke-static {v1, v3}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {p1, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_b9

    const/4 v1, 0x5

    new-array v1, v1, [B

    fill-array-data v1, :array_118

    new-array v3, v2, [B

    fill-array-data v3, :array_120

    invoke-static {v1, v3}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {p1, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-eqz v1, :cond_2f

    goto/16 :goto_b9

    :cond_2f
    const/4 v1, 0x4

    new-array v1, v1, [B

    fill-array-data v1, :array_128

    new-array v3, v2, [B

    fill-array-data v3, :array_12e

    invoke-static {v1, v3}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {p1, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-eqz v1, :cond_a4

    new-array v1, v0, [B

    fill-array-data v1, :array_136

    new-array v3, v2, [B

    fill-array-data v3, :array_140

    invoke-static {v1, v3}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {p1, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-eqz v1, :cond_69

    const/16 p1, 0x29

    new-array p1, p1, [B

    fill-array-data p1, :array_148

    new-array v0, v2, [B

    fill-array-data v0, :array_162

    invoke-static {p1, v0}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object p1

    return-object p1

    :cond_69
    new-array v1, v2, [B

    fill-array-data v1, :array_16a

    new-array v3, v2, [B

    fill-array-data v3, :array_172

    invoke-static {v1, v3}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {p1, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-eqz v1, :cond_90

    .line 1
    invoke-static {p1}, Lcom/github/catvod/spider/appysv2/b/t;->b(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p1

    new-array v0, v0, [B

    .line 2
    fill-array-data v0, :array_17a

    new-array v1, v2, [B

    fill-array-data v1, :array_184

    .line 3
    invoke-static {v0, v1, p1}, Lcom/github/catvod/spider/appysv2/b/t;->a([B[BLjava/lang/StringBuilder;)Ljava/lang/String;

    move-result-object p1

    return-object p1

    .line 4
    :cond_90
    invoke-static {p1}, Lcom/github/catvod/spider/appysv2/b/t;->b(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p1

    const/4 v0, 0x6

    new-array v0, v0, [B

    .line 5
    fill-array-data v0, :array_18c

    new-array v1, v2, [B

    fill-array-data v1, :array_194

    .line 6
    invoke-static {v0, v1, p1}, Lcom/github/catvod/spider/appysv2/b/t;->a([B[BLjava/lang/StringBuilder;)Ljava/lang/String;

    move-result-object p1

    return-object p1

    .line 7
    :cond_a4
    invoke-static {p1}, Lcom/github/catvod/spider/appysv2/b/t;->b(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p1

    const/16 v0, 0xf

    new-array v0, v0, [B

    .line 8
    fill-array-data v0, :array_19c

    new-array v1, v2, [B

    fill-array-data v1, :array_1a8

    .line 9
    invoke-static {v0, v1, p1}, Lcom/github/catvod/spider/appysv2/b/t;->a([B[BLjava/lang/StringBuilder;)Ljava/lang/String;

    move-result-object p1

    return-object p1

    :cond_b9
    :goto_b9
    new-array v0, v2, [B

    .line 10
    fill-array-data v0, :array_1b0

    new-array v1, v2, [B

    fill-array-data v1, :array_1b8

    invoke-static {v0, v1}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    const/16 v1, 0xa

    if-eqz v0, :cond_f2

    const/16 p1, 0x24

    new-array p1, p1, [B

    fill-array-data p1, :array_1c0

    new-array v0, v2, [B

    fill-array-data v0, :array_1d6

    invoke-static {p1, v0}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object p1

    .line 11
    invoke-static {p1}, Lcom/github/catvod/spider/appysv2/b/t;->b(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p1

    new-array v0, v1, [B

    .line 12
    fill-array-data v0, :array_1de

    new-array v1, v2, [B

    fill-array-data v1, :array_1e8

    .line 13
    invoke-static {v0, v1, p1}, Lcom/github/catvod/spider/appysv2/b/t;->a([B[BLjava/lang/StringBuilder;)Ljava/lang/String;

    move-result-object p1

    return-object p1

    .line 14
    :cond_f2
    invoke-static {p1}, Lcom/github/catvod/spider/appysv2/b/t;->b(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p1

    new-array v0, v1, [B

    .line 15
    fill-array-data v0, :array_1f0

    new-array v1, v2, [B

    fill-array-data v1, :array_1fa

    .line 16
    invoke-static {v0, v1, p1}, Lcom/github/catvod/spider/appysv2/b/t;->a([B[BLjava/lang/StringBuilder;)Ljava/lang/String;

    move-result-object p1

    return-object p1

    nop

    :array_106
    .array-data 1
        -0x70t
        -0x12t
        -0x48t
        -0x36t
        0x70t
        -0x40t
        -0x68t
        -0x3t
        -0x70t
        -0x12t
        -0x5ft
    .end array-data

    :array_110
    .array-data 1
        -0xft
        -0x62t
        -0x2ft
        -0x1ct
        0x0t
        -0x58t
        -0x18t
        -0x2et
    .end array-data

    :array_118
    .array-data 1
        0x32t
        -0x52t
        0x74t
        0x65t
        0x40t
    .end array-data

    nop

    :array_120
    .array-data 1
        0x4at
        -0x37t
        0x15t
        0x15t
        0x30t
        0x19t
        -0x58t
        0x4dt
    .end array-data

    :array_128
    .array-data 1
        0x3ft
        0x58t
        0x78t
        0x5dt
    .end array-data

    :array_12e
    .array-data 1
        0x11t
        0x2et
        0x17t
        0x39t
        -0x52t
        0x48t
        -0x9t
        -0x1t
    .end array-data

    :array_136
    .array-data 1
        0x18t
        0x25t
        0xat
        -0x4et
        0xbt
        0x6t
        -0x47t
        -0x54t
        0x42t
        0x30t
        0x47t
    .end array-data

    :array_140
    .array-data 1
        0x6ct
        0x53t
        0x24t
        -0x30t
        0x7et
        0x6at
        -0x24t
        -0x3bt
    .end array-data

    :array_148
    .array-data 1
        -0x7at
        -0x6t
        -0x3ft
        0x12t
        -0x22t
        0x18t
        -0x13t
        0x1dt
        -0x66t
        -0x8t
        -0x65t
        0x0t
        -0x28t
        0x4et
        -0x59t
        0x5bt
        -0x40t
        -0x13t
        -0x2at
        0x4dt
        -0x34t
        0x52t
        -0x55t
        0x0t
        -0x40t
        -0x2t
        -0x23t
        0x12t
        -0x7et
        0x54t
        -0xdt
        0x1ct
        -0x68t
        -0x1ft
        -0x2ft
        0x5dt
        -0x27t
        0x5bt
        -0x4et
        0x57t
        -0x2dt
    .end array-data

    nop

    :array_162
    .array-data 1
        -0x12t
        -0x72t
        -0x4bt
        0x62t
        -0x53t
        0x22t
        -0x3et
        0x32t
    .end array-data

    :array_16a
    .array-data 1
        -0x23t
        -0x76t
        0x42t
        -0x70t
        -0x6ft
        -0x41t
        0x76t
        -0x75t
    .end array-data

    :array_172
    .array-data 1
        -0x4ct
        -0x1bt
        0x32t
        -0xbt
        -0x1t
        -0x3at
        0x3t
        -0x1bt
    .end array-data

    :array_17a
    .array-data 1
        0x34t
        0x27t
        0x6ct
        0x25t
        0x17t
        -0x2et
        0x50t
        0x50t
        0x6bt
        0x2et
        0x38t
    .end array-data

    :array_184
    .array-data 1
        0x1bt
        0x4bt
        0x5t
        0x56t
        0x63t
        -0x13t
        0x24t
        0x29t
    .end array-data

    :array_18c
    .array-data 1
        -0x1dt
        0x75t
        -0x68t
        0x4bt
        -0x11t
        -0x71t
    .end array-data

    nop

    :array_194
    .array-data 1
        -0x24t
        0x1t
        -0x1ft
        0x3bt
        -0x76t
        -0x4et
        0x1ft
        0x7ct
    .end array-data

    :array_19c
    .array-data 1
        0x6ft
        -0x18t
        -0x4ft
        -0x43t
        -0x1ft
        -0x20t
        0x69t
        -0x20t
        0x76t
        -0x16t
        -0x42t
        -0x1ft
        -0x2t
        -0x6t
        0x27t
    .end array-data

    :array_1a8
    .array-data 1
        0x50t
        -0x77t
        -0x2et
        -0x80t
        -0x73t
        -0x77t
        0x1at
        -0x6ct
    .end array-data

    :array_1b0
    .array-data 1
        -0x6ct
        0x31t
        -0x61t
        -0x7dt
        0x3t
        -0x3dt
        -0x5dt
        -0x18t
    .end array-data

    :array_1b8
    .array-data 1
        -0x10t
        0x58t
        -0xbt
        -0x16t
        0x62t
        -0x45t
        -0x36t
        -0x77t
    .end array-data

    :array_1c0
    .array-data 1
        0x6et
        -0x27t
        -0x6dt
        0x75t
        0x4at
        -0x66t
        0x2ft
        -0x73t
        0x71t
        -0x26t
        -0x37t
        0x61t
        0x19t
        -0x21t
        0x69t
        -0x65t
        0x7et
        -0x3ct
        -0x7at
        0x2bt
        0x13t
        -0x26t
        0x6dt
        -0x2bt
        0x67t
        -0x23t
        -0x72t
        0x2bt
        0x0t
        -0x23t
        0x70t
        -0x2bt
        0x67t
        -0x23t
        -0x69t
        0x2at
    .end array-data

    :array_1d6
    .array-data 1
        0x6t
        -0x53t
        -0x19t
        0x5t
        0x70t
        -0x4bt
        0x0t
        -0x6t
    .end array-data

    :array_1de
    .array-data 1
        -0x52t
        -0x1et
        -0x7et
        -0x6ft
        -0x6at
        -0x7ct
        -0x79t
        0x5t
        -0x44t
        -0x4at
    .end array-data

    nop

    :array_1e8
    .array-data 1
        -0x28t
        -0x75t
        -0x1at
        -0xct
        -0x7t
        -0x45t
        -0xdt
        0x6ct
    .end array-data

    :array_1f0
    .array-data 1
        0x56t
        -0x4et
        0xbt
        0x1ft
        0x7ct
        0x29t
        0x5bt
        0x47t
        0x44t
        -0x1at
    .end array-data

    nop

    :array_1fa
    .array-data 1
        0x20t
        -0x25t
        0x6ft
        0x7at
        0x13t
        0x16t
        0x2ft
        0x2et
    .end array-data
.end method

.method public detailContent(Ljava/util/List;)Ljava/lang/String;
    .registers 9
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;)",
            "Ljava/lang/String;"
        }
    .end annotation

    invoke-direct {p0}, Lcom/github/catvod/spider/AppYsV2;->c()Ljava/lang/String;

    move-result-object v0

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/16 v2, 0xb

    new-array v2, v2, [B

    .line 1
    fill-array-data v2, :array_16c

    const/16 v3, 0x8

    new-array v4, v3, [B

    fill-array-data v4, :array_176

    invoke-static {v2, v4}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v2

    const/4 v4, 0x4

    if-nez v2, :cond_90

    const/4 v2, 0x5

    new-array v2, v2, [B

    fill-array-data v2, :array_17e

    new-array v5, v3, [B

    fill-array-data v5, :array_186

    invoke-static {v2, v5}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v2

    if-eqz v2, :cond_38

    goto :goto_90

    :cond_38
    new-array v2, v4, [B

    fill-array-data v2, :array_18e

    new-array v5, v3, [B

    fill-array-data v5, :array_194

    invoke-static {v2, v5}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v2

    if-eqz v2, :cond_8c

    new-array v2, v3, [B

    fill-array-data v2, :array_19c

    new-array v5, v3, [B

    fill-array-data v5, :array_1a4

    invoke-static {v2, v5}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v2

    if-eqz v2, :cond_76

    .line 2
    invoke-static {v0}, Lcom/github/catvod/spider/appysv2/b/t;->b(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const/16 v5, 0x11

    new-array v5, v5, [B

    .line 3
    fill-array-data v5, :array_1ac

    new-array v6, v3, [B

    fill-array-data v6, :array_1ba

    invoke-static {v5, v6}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v5

    goto/16 :goto_113

    .line 4
    :cond_76
    invoke-static {v0}, Lcom/github/catvod/spider/appysv2/b/t;->b(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const/16 v5, 0xf

    new-array v5, v5, [B

    .line 5
    fill-array-data v5, :array_1c2

    new-array v6, v3, [B

    fill-array-data v6, :array_1ce

    invoke-static {v5, v6}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v5

    goto/16 :goto_113

    :cond_8c
    const-string v2, ""

    goto/16 :goto_11a

    :cond_90
    :goto_90
    new-array v2, v3, [B

    fill-array-data v2, :array_1d6

    new-array v5, v3, [B

    fill-array-data v5, :array_1de

    invoke-static {v2, v5}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v2

    const/16 v5, 0x10

    if-eqz v2, :cond_c9

    const/16 v2, 0x25

    new-array v2, v2, [B

    fill-array-data v2, :array_1e6

    new-array v6, v3, [B

    fill-array-data v6, :array_1fe

    invoke-static {v2, v6}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v2

    .line 6
    invoke-static {v2}, Lcom/github/catvod/spider/appysv2/b/t;->b(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    new-array v5, v5, [B

    .line 7
    fill-array-data v5, :array_206

    new-array v6, v3, [B

    fill-array-data v6, :array_212

    invoke-static {v5, v6}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v5

    goto :goto_113

    :cond_c9
    const/4 v2, 0x6

    new-array v2, v2, [B

    fill-array-data v2, :array_21a

    new-array v6, v3, [B

    fill-array-data v6, :array_222

    invoke-static {v2, v6}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v2

    if-eqz v2, :cond_101

    const/16 v2, 0x21

    new-array v2, v2, [B

    fill-array-data v2, :array_22a

    new-array v6, v3, [B

    fill-array-data v6, :array_240

    invoke-static {v2, v6}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v2

    .line 8
    invoke-static {v2}, Lcom/github/catvod/spider/appysv2/b/t;->b(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    new-array v5, v5, [B

    .line 9
    fill-array-data v5, :array_248

    new-array v6, v3, [B

    fill-array-data v6, :array_254

    invoke-static {v5, v6}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v5

    goto :goto_113

    .line 10
    :cond_101
    invoke-static {v0}, Lcom/github/catvod/spider/appysv2/b/t;->b(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    new-array v5, v5, [B

    .line 11
    fill-array-data v5, :array_25c

    new-array v6, v3, [B

    fill-array-data v6, :array_268

    invoke-static {v5, v6}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v5

    :goto_113
    invoke-virtual {v2, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    .line 12
    :goto_11a
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x0

    invoke-interface {p1, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/lang/String;

    invoke-virtual {v1, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Lcom/github/catvod/crawler/SpiderDebug;->log(Ljava/lang/String;)V

    invoke-direct {p0, v1}, Lcom/github/catvod/spider/AppYsV2;->h(Ljava/lang/String;)Ljava/util/HashMap;

    move-result-object v5

    invoke-static {v1, v5}, Lcom/github/catvod/spider/appysv2/n/c;->m(Ljava/lang/String;Ljava/util/Map;)Ljava/lang/String;

    move-result-object v1

    new-instance v5, Lorg/json/JSONObject;

    invoke-direct {v5, v1}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    new-instance v1, Lorg/json/JSONObject;

    invoke-direct {v1}, Lorg/json/JSONObject;-><init>()V

    new-instance v6, Lorg/json/JSONObject;

    invoke-direct {v6}, Lorg/json/JSONObject;-><init>()V

    invoke-interface {p1, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/lang/String;

    invoke-direct {p0, v0, v5, v6, p1}, Lcom/github/catvod/spider/AppYsV2;->b(Ljava/lang/String;Lorg/json/JSONObject;Lorg/json/JSONObject;Ljava/lang/String;)V

    new-instance p1, Lorg/json/JSONArray;

    invoke-direct {p1}, Lorg/json/JSONArray;-><init>()V

    invoke-virtual {p1, v6}, Lorg/json/JSONArray;->put(Ljava/lang/Object;)Lorg/json/JSONArray;

    new-array v0, v4, [B

    fill-array-data v0, :array_270

    new-array v2, v3, [B

    fill-array-data v2, :array_276

    invoke-static {v0, v2}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v1, v0, p1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    invoke-virtual {v1}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object p1

    return-object p1

    :array_16c
    .array-data 1
        0x1ct
        -0x4ct
        0x68t
        -0x77t
        -0x46t
        0x8t
        0x54t
        -0x1dt
        0x1ct
        -0x4ct
        0x71t
    .end array-data

    :array_176
    .array-data 1
        0x7dt
        -0x3ct
        0x1t
        -0x59t
        -0x36t
        0x60t
        0x24t
        -0x34t
    .end array-data

    :array_17e
    .array-data 1
        -0x3ct
        -0x27t
        0x29t
        0x66t
        -0x6et
    .end array-data

    nop

    :array_186
    .array-data 1
        -0x44t
        -0x42t
        0x48t
        0x16t
        -0x1et
        -0x4dt
        0x53t
        -0x33t
    .end array-data

    :array_18e
    .array-data 1
        0x3t
        0x45t
        -0x3ct
        0x31t
    .end array-data

    :array_194
    .array-data 1
        0x2dt
        0x33t
        -0x55t
        0x55t
        -0x75t
        0x54t
        -0x46t
        0x21t
    .end array-data

    :array_19c
    .array-data 1
        -0x26t
        0x31t
        -0x52t
        -0x13t
        -0x56t
        -0x5dt
        0x24t
        0x37t
    .end array-data

    :array_1a4
    .array-data 1
        -0x4dt
        0x5et
        -0x22t
        -0x78t
        -0x3ct
        -0x26t
        0x51t
        0x59t
    .end array-data

    :array_1ac
    .array-data 1
        0x6et
        -0x3dt
        0x13t
        0x3at
        0x78t
        0x4ft
        0x3bt
        0x47t
        0x5t
        -0x68t
        0x0t
        0x21t
        0x7dt
        0x79t
        0x3et
        0x6at
        0x7ct
    .end array-data

    nop

    :array_1ba
    .array-data 1
        0x41t
        -0x59t
        0x76t
        0x4et
        0x19t
        0x26t
        0x57t
        0xet
    .end array-data

    :array_1c2
    .array-data 1
        -0x35t
        -0x19t
        0x21t
        0x18t
        0x6ft
        0x74t
        -0x56t
        -0x3at
        -0x6et
        -0x14t
        0x20t
        0x33t
        0x67t
        0x79t
        -0x5t
    .end array-data

    :array_1ce
    .array-data 1
        -0x1ct
        -0x7dt
        0x44t
        0x6ct
        0xet
        0x1dt
        -0x3at
        -0x7t
    .end array-data

    :array_1d6
    .array-data 1
        -0x4ct
        -0x70t
        0xat
        -0x10t
        0x5dt
        0x56t
        -0x27t
        -0x5ct
    .end array-data

    :array_1de
    .array-data 1
        -0x30t
        -0x7t
        0x60t
        -0x67t
        0x3ct
        0x2et
        -0x50t
        -0x3bt
    .end array-data

    :array_1e6
    .array-data 1
        -0x5at
        -0x54t
        0x74t
        0x1ct
        0x2ft
        0x37t
        -0x59t
        -0x32t
        -0x47t
        -0x51t
        0x77t
        0x42t
        0x38t
        0x64t
        -0x1et
        -0x78t
        -0x51t
        -0x60t
        0x69t
        0xdt
        0x72t
        0x6et
        -0x19t
        -0x74t
        -0x1ft
        -0x47t
        0x70t
        0x5t
        0x72t
        0x7dt
        -0x20t
        -0x6ft
        -0x1ft
        -0x47t
        0x70t
        0x1ct
        0x73t
    .end array-data

    nop

    :array_1fe
    .array-data 1
        -0x32t
        -0x28t
        0x0t
        0x6ct
        0x5ct
        0xdt
        -0x78t
        -0x1ft
    .end array-data

    :array_206
    .array-data 1
        -0x27t
        -0x3at
        -0x6et
        -0x64t
        -0xft
        -0x10t
        0x58t
        -0x72t
        -0x25t
        -0x32t
        -0x61t
        -0x6bt
        -0x5ft
        -0x3at
        0x58t
        -0x2at
    .end array-data

    :array_212
    .array-data 1
        -0x51t
        -0x51t
        -0xat
        -0x7t
        -0x62t
        -0x51t
        0x3ct
        -0x15t
    .end array-data

    :array_21a
    .array-data 1
        0x4ct
        -0x60t
        0x7et
        -0x51t
        -0x71t
        0x3ft
    .end array-data

    nop

    :array_222
    .array-data 1
        0x7dt
        -0x70t
        0x4ft
        -0x61t
        -0x15t
        0x46t
        0x2ct
        -0xat
    .end array-data

    :array_22a
    .array-data 1
        0x6t
        0x40t
        0x19t
        0x30t
        -0x2at
        0x67t
        -0x56t
        -0x40t
        0x19t
        0x43t
        0x43t
        0x71t
        -0x24t
        0x79t
        -0x4bt
        -0x2dt
        0x17t
        0x1at
        0xet
        0x23t
        -0x3dt
        0x29t
        -0xbt
        -0x22t
        0x40t
        0x44t
        0x5t
        0x30t
        -0x3dt
        0x29t
        -0xbt
        -0x39t
        0x41t
    .end array-data

    nop

    :array_240
    .array-data 1
        0x6et
        0x34t
        0x6dt
        0x40t
        -0x14t
        0x48t
        -0x7bt
        -0x49t
    .end array-data

    :array_248
    .array-data 1
        0x8t
        -0x11t
        0x68t
        -0x4ct
        -0xat
        0x15t
        0x10t
        0x40t
        0xat
        -0x19t
        0x65t
        -0x43t
        -0x5at
        0x23t
        0x10t
        0x18t
    .end array-data

    :array_254
    .array-data 1
        0x7et
        -0x7at
        0xct
        -0x2ft
        -0x67t
        0x4at
        0x74t
        0x25t
    .end array-data

    :array_25c
    .array-data 1
        0x2at
        0x8t
        0x7ct
        0x24t
        0x34t
        -0x39t
        -0x42t
        -0x75t
        0x28t
        0x0t
        0x71t
        0x2dt
        0x64t
        -0xft
        -0x42t
        -0x2dt
    .end array-data

    :array_268
    .array-data 1
        0x5ct
        0x61t
        0x18t
        0x41t
        0x5bt
        -0x68t
        -0x26t
        -0x12t
    .end array-data

    :array_270
    .array-data 1
        0x59t
        -0x5dt
        0x53t
        0x17t
    .end array-data

    :array_276
    .array-data 1
        0x35t
        -0x36t
        0x20t
        0x63t
        -0x75t
        0x3ct
        0x16t
        0x44t
    .end array-data
.end method

.method final e(Ljava/lang/String;)Ljava/lang/String;
    .registers 5

    const/16 v0, 0xb

    new-array v0, v0, [B

    fill-array-data v0, :array_76

    const/16 v1, 0x8

    new-array v2, v1, [B

    fill-array-data v2, :array_80

    invoke-static {v0, v2}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    if-nez v0, :cond_65

    const/4 v0, 0x5

    new-array v0, v0, [B

    fill-array-data v0, :array_88

    new-array v2, v1, [B

    fill-array-data v2, :array_90

    invoke-static {v0, v2}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    if-eqz v0, :cond_2e

    goto :goto_65

    :cond_2e
    const/4 v0, 0x4

    new-array v0, v0, [B

    fill-array-data v0, :array_98

    new-array v2, v1, [B

    fill-array-data v2, :array_9e

    invoke-static {v0, v2}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result p1

    if-eqz p1, :cond_54

    const/16 p1, 0x5f

    new-array p1, p1, [B

    fill-array-data p1, :array_a6

    new-array v0, v1, [B

    fill-array-data v0, :array_da

    invoke-static {p1, v0}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object p1

    return-object p1

    :cond_54
    const/16 p1, 0x3c

    new-array p1, p1, [B

    fill-array-data p1, :array_e2

    new-array v0, v1, [B

    fill-array-data v0, :array_104

    invoke-static {p1, v0}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object p1

    return-object p1

    :cond_65
    :goto_65
    const/16 p1, 0x53

    new-array p1, p1, [B

    fill-array-data p1, :array_10c

    new-array v0, v1, [B

    fill-array-data v0, :array_13a

    invoke-static {p1, v0}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object p1

    return-object p1

    :array_76
    .array-data 1
        -0x62t
        -0x49t
        0x52t
        0x77t
        0x5ct
        -0x1ft
        0x29t
        -0x28t
        -0x62t
        -0x49t
        0x4bt
    .end array-data

    :array_80
    .array-data 1
        -0x1t
        -0x39t
        0x3bt
        0x59t
        0x2ct
        -0x77t
        0x59t
        -0x9t
    .end array-data

    :array_88
    .array-data 1
        -0x7dt
        -0x74t
        0x6bt
        0x22t
        -0x7t
    .end array-data

    nop

    :array_90
    .array-data 1
        -0x5t
        -0x15t
        0xat
        0x52t
        -0x77t
        0x4ft
        -0x2bt
        0x8t
    .end array-data

    :array_98
    .array-data 1
        0x3et
        0x74t
        0x0t
        0x1t
    .end array-data

    :array_9e
    .array-data 1
        0x10t
        0x2t
        0x6ft
        0x65t
        -0x4t
        -0x75t
        0x12t
        -0x7dt
    .end array-data

    :array_a6
    .array-data 1
        0x35t
        -0x64t
        0x2at
        0x6ft
        0x5et
        0x1at
        -0x15t
        -0x21t
        -0x42t
        0x64t
        -0x51t
        -0x72t
        -0x5ct
        0xat
        -0x46t
        0x59t
        0x60t
        -0x74t
        0x60t
        0x6ft
        0x5ft
        0xct
        -0x49t
        0x5t
        -0xct
        0x52t
        -0x23t
        -0x19t
        -0x53t
        -0x20t
        -0x49t
        0x4at
        0x76t
        -0x62t
        0x60t
        0x62t
        0x4ct
        0x7t
        -0x4ft
        0x5t
        -0xct
        0x52t
        -0x23t
        -0x19t
        -0x53t
        -0x20t
        -0x46t
        0x59t
        0x7dt
        -0x68t
        0x60t
        0x77t
        0x48t
        0x8t
        -0x5ct
        0x5t
        -0xct
        0x52t
        -0x23t
        -0x19t
        -0x53t
        -0x20t
        -0x51t
        0x5dt
        0x72t
        -0x73t
        0x60t
        0x6ct
        0x54t
        0x54t
        0x30t
        -0x4at
        -0x7ft
        0x1at
        -0x4t
        -0x7ft
        0xbt
        0x5t
        -0x41t
        0x55t
        0x7at
        -0x75t
        0x7bt
        0x3ft
        0x15t
        0x4ft
        -0x5at
        0x59t
        0x74t
        -0x66t
        0x7bt
        0x2dt
        0x7dt
        0x27t
        -0xbt
    .end array-data

    :array_da
    .array-data 1
        0x13t
        -0x1t
        0x46t
        0xet
        0x2dt
        0x69t
        -0x2at
        0x38t
    .end array-data

    :array_e2
    .array-data 1
        -0x47t
        -0x21t
        -0x78t
        -0x71t
        0x29t
        -0x4ft
        -0x4ft
        0x49t
        -0x2ft
        -0x74t
        -0x31t
        -0x77t
        0x3et
        -0x17t
        -0xdt
        0x24t
        0x78t
        0x2t
        0x72t
        0x1t
        -0x34t
        0x5t
        -0xdt
        0x6bt
        -0x6t
        -0x32t
        -0x31t
        -0x64t
        0x35t
        -0x4t
        -0x9t
        0x24t
        0x78t
        0x2t
        0x72t
        0x1t
        -0x34t
        0x5t
        -0xft
        0x75t
        -0x2t
        -0x24t
        -0x66t
        -0x32t
        0x3ft
        -0x8t
        -0xdt
        0x6bt
        -0x15t
        -0x6et
        0xet
        0x45t
        -0x29t
        0x65t
        0x12t
        -0x70t
        -0x1at
        -0x36t
        -0x78t
        -0x66t
    .end array-data

    :array_104
    .array-data 1
        -0x61t
        -0x51t
        -0x17t
        -0x18t
        0x4ct
        -0x74t
        -0x6et
        0x19t
    .end array-data

    :array_10c
    .array-data 1
        0x37t
        0x11t
        0x63t
        0x7et
        -0xet
        -0x63t
        0x42t
        -0x72t
        -0x44t
        -0x17t
        -0x1at
        -0x61t
        0x8t
        -0x73t
        0x13t
        0x8t
        0x62t
        0x1t
        0x29t
        0x7et
        -0xdt
        -0x75t
        0x1et
        0x54t
        -0xat
        -0x21t
        -0x6ct
        -0xat
        0x1t
        0x67t
        0x1et
        0x1bt
        0x74t
        0x13t
        0x29t
        0x73t
        -0x20t
        -0x80t
        0x18t
        0x54t
        -0xat
        -0x21t
        -0x6ct
        -0xat
        0x1t
        0x67t
        0x13t
        0x8t
        0x7ft
        0x15t
        0x29t
        0x66t
        -0x1ct
        -0x71t
        0xdt
        0x54t
        -0xat
        -0x21t
        -0x6ct
        -0xat
        0x1t
        0x67t
        0x6t
        0xct
        0x70t
        0x0t
        0x29t
        0x73t
        -0x18t
        -0x7dt
        0x16t
        0x1dt
        0x2ct
        0x43t
        0x37t
        0x39t
        -0xft
        -0x77t
        0x42t
        0x4at
        0x41t
        0x3ct
        0x2ct
    .end array-data

    :array_13a
    .array-data 1
        0x11t
        0x72t
        0xft
        0x1ft
        -0x7ft
        -0x12t
        0x7ft
        0x69t
    .end array-data
.end method

.method final f(Ljava/lang/String;)Ljava/lang/String;
    .registers 6

    const/16 v0, 0xb

    new-array v0, v0, [B

    fill-array-data v0, :array_a0

    const/16 v1, 0x8

    new-array v2, v1, [B

    fill-array-data v2, :array_aa

    invoke-static {v0, v2}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    const/16 v2, 0xa

    if-nez v0, :cond_85

    const/4 v0, 0x5

    new-array v0, v0, [B

    fill-array-data v0, :array_b2

    new-array v3, v1, [B

    fill-array-data v3, :array_ba

    invoke-static {v0, v3}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    if-eqz v0, :cond_30

    goto :goto_85

    :cond_30
    const/4 v0, 0x4

    new-array v0, v0, [B

    fill-array-data v0, :array_c2

    new-array v3, v1, [B

    fill-array-data v3, :array_c8

    invoke-static {v0, v3}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    if-eqz v0, :cond_82

    const/16 v0, 0xc

    new-array v0, v0, [B

    fill-array-data v0, :array_d0

    new-array v3, v1, [B

    fill-array-data v3, :array_da

    invoke-static {v0, v3}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    if-eqz v0, :cond_6e

    .line 1
    invoke-static {p1}, Lcom/github/catvod/spider/appysv2/b/t;->b(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p1

    new-array v0, v2, [B

    .line 2
    fill-array-data v0, :array_e2

    new-array v1, v1, [B

    fill-array-data v1, :array_ec

    invoke-static {v0, v1}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v0

    goto :goto_97

    .line 3
    :cond_6e
    invoke-static {p1}, Lcom/github/catvod/spider/appysv2/b/t;->b(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p1

    const/4 v0, 0x6

    new-array v0, v0, [B

    .line 4
    fill-array-data v0, :array_f4

    new-array v1, v1, [B

    fill-array-data v1, :array_fc

    invoke-static {v0, v1}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v0

    goto :goto_97

    :cond_82
    const-string p1, ""

    return-object p1

    .line 5
    :cond_85
    :goto_85
    invoke-static {p1}, Lcom/github/catvod/spider/appysv2/b/t;->b(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p1

    new-array v0, v2, [B

    .line 6
    fill-array-data v0, :array_104

    new-array v1, v1, [B

    fill-array-data v1, :array_10e

    invoke-static {v0, v1}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v0

    :goto_97
    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    return-object p1

    nop

    :array_a0
    .array-data 1
        -0x24t
        0x1dt
        -0x6et
        -0xdt
        -0x1ct
        -0x1ft
        -0x33t
        -0x6ct
        -0x24t
        0x1dt
        -0x75t
    .end array-data

    :array_aa
    .array-data 1
        -0x43t
        0x6dt
        -0x5t
        -0x23t
        -0x6ct
        -0x77t
        -0x43t
        -0x45t
    .end array-data

    :array_b2
    .array-data 1
        -0x38t
        -0x28t
        -0x26t
        -0x8t
        0x51t
    .end array-data

    nop

    :array_ba
    .array-data 1
        -0x50t
        -0x41t
        -0x45t
        -0x78t
        0x21t
        0x1dt
        -0x37t
        -0x4ct
    .end array-data

    :array_c2
    .array-data 1
        -0x54t
        -0xbt
        -0x3dt
        -0x23t
    .end array-data

    :array_c8
    .array-data 1
        -0x7et
        -0x7dt
        -0x54t
        -0x47t
        0x20t
        0xct
        -0x29t
        -0x3t
    .end array-data

    :array_d0
    .array-data 1
        0x23t
        -0x28t
        -0x61t
        0x47t
        0x27t
        0x1bt
        0x39t
        0x30t
        0x64t
        -0x2ct
        -0x80t
        0x4ft
    .end array-data

    :array_da
    .array-data 1
        0x4at
        -0x49t
        -0x11t
        0x22t
        0x49t
        0x62t
        0x4ct
        0x5et
    .end array-data

    :array_e2
    .array-data 1
        0x58t
        0x64t
        0x5ct
        -0x27t
        0x7et
        -0x76t
        0x20t
        -0x1t
        0x7t
        0x6dt
    .end array-data

    nop

    :array_ec
    .array-data 1
        0x77t
        0x8t
        0x35t
        -0x56t
        0xat
        -0x4bt
        0x54t
        -0x7at
    .end array-data

    :array_f4
    .array-data 1
        -0x3ft
        -0x2ct
        -0x52t
        -0x3dt
        0x1bt
        0x64t
    .end array-data

    nop

    :array_fc
    .array-data 1
        -0x12t
        -0x60t
        -0x29t
        -0x4dt
        0x7et
        0x17t
        0x3at
        0x19t
    .end array-data

    :array_104
    .array-data 1
        -0x45t
        -0x4ct
        -0x9t
        0x2et
        -0x5ct
        0x75t
        -0x6ft
        0x15t
        -0x45t
        -0x18t
    .end array-data

    nop

    :array_10e
    .array-data 1
        -0x2bt
        -0x2bt
        -0x7ft
        0x11t
        -0x30t
        0x1at
        -0x6t
        0x70t
    .end array-data
.end method

.method final g(Ljava/lang/String;Lorg/json/JSONObject;)Ljava/lang/String;
    .registers 23

    move-object/from16 v0, p1

    move-object/from16 v1, p2

    const/4 v2, 0x5

    const/4 v3, 0x4

    const/16 v4, 0x8

    const-string v5, ""

    if-eqz v1, :cond_17e

    invoke-virtual/range {p2 .. p2}, Lorg/json/JSONObject;->keys()Ljava/util/Iterator;

    move-result-object v6

    :cond_10
    :goto_10
    invoke-interface {v6}, Ljava/util/Iterator;->hasNext()Z

    move-result v7

    if-eqz v7, :cond_17e

    invoke-interface {v6}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Ljava/lang/String;

    new-array v8, v2, [B

    fill-array-data v8, :array_1e4

    new-array v9, v4, [B

    fill-array-data v9, :array_1ec

    invoke-static {v8, v9}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v7, v8}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v8

    if-nez v8, :cond_6c

    new-array v8, v3, [B

    fill-array-data v8, :array_1f4

    new-array v9, v4, [B

    fill-array-data v9, :array_1fa

    invoke-static {v8, v9}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v7, v8}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v8

    if-nez v8, :cond_6c

    new-array v8, v3, [B

    fill-array-data v8, :array_202

    new-array v9, v4, [B

    fill-array-data v9, :array_208

    invoke-static {v8, v9}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v7, v8}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v8

    if-nez v8, :cond_6c

    new-array v8, v3, [B

    fill-array-data v8, :array_210

    new-array v9, v4, [B

    fill-array-data v9, :array_216

    invoke-static {v8, v9}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v7, v8}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v8

    if-eqz v8, :cond_10

    :cond_6c
    :try_start_6c
    new-instance v8, Ljava/lang/StringBuilder;

    invoke-direct {v8}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v8, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x6

    new-array v9, v9, [B

    const/16 v10, -0x69

    const/4 v11, 0x0

    aput-byte v10, v9, v11

    const/16 v10, -0x4d

    const/4 v12, 0x1

    aput-byte v10, v9, v12

    const/16 v10, 0x56

    const/4 v13, 0x2

    aput-byte v10, v9, v13

    const/16 v10, -0x7f

    const/4 v14, 0x3

    aput-byte v10, v9, v14

    const/16 v10, -0x28

    aput-byte v10, v9, v3

    const/16 v15, 0x51

    aput-byte v15, v9, v2

    new-array v15, v4, [B

    const/16 v16, 0x70

    aput-byte v16, v15, v11

    const/16 v16, 0x1e

    aput-byte v16, v15, v12

    const/16 v16, -0x33

    aput-byte v16, v15, v13

    const/16 v16, 0x68

    aput-byte v16, v15, v14

    const/16 v16, 0x58

    aput-byte v16, v15, v3

    aput-byte v10, v15, v2

    const/16 v10, 0x3c

    const/16 v17, 0x6

    aput-byte v10, v15, v17

    const/16 v17, 0x3b

    const/16 v18, 0x7

    aput-byte v17, v15, v18

    invoke-static {v9, v15}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v8, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v9, 0x9

    new-array v9, v9, [B

    const/16 v15, 0x3f

    aput-byte v15, v9, v11

    aput-byte v2, v9, v12

    aput-byte v10, v9, v13

    const/16 v10, -0x2f

    aput-byte v10, v9, v14

    const/16 v10, -0x3f

    aput-byte v10, v9, v3

    const/4 v10, -0x8

    aput-byte v10, v9, v2

    const/16 v10, -0xe

    const/16 v19, 0x6

    aput-byte v10, v9, v19

    aput-byte v17, v9, v18

    aput-byte v15, v9, v4

    new-array v10, v4, [B

    const/16 v15, 0x14

    aput-byte v15, v10, v11

    const/16 v15, -0x20

    aput-byte v15, v10, v12

    const/16 v15, -0x47

    aput-byte v15, v10, v13

    const/16 v15, 0x79

    aput-byte v15, v10, v14

    const/16 v15, 0x28

    aput-byte v15, v10, v3

    const/16 v15, 0x7b

    aput-byte v15, v10, v2

    const/16 v15, 0x5a

    const/16 v17, 0x6

    aput-byte v15, v10, v17

    aput-byte v17, v10, v18

    invoke-static {v9, v10}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v7}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    new-array v9, v12, [B

    const/16 v10, -0x4e

    aput-byte v10, v9, v11

    new-array v10, v4, [B

    const/16 v15, -0x62

    aput-byte v15, v10, v11

    const/16 v15, -0x72

    aput-byte v15, v10, v12

    const/16 v15, -0x3c

    aput-byte v15, v10, v13

    const/16 v15, 0x30

    aput-byte v15, v10, v14

    const/16 v15, -0x2a

    aput-byte v15, v10, v3

    aput-byte v16, v10, v2

    const/4 v15, 0x6

    aput-byte v2, v10, v15

    const/16 v15, 0x39

    aput-byte v15, v10, v18

    invoke-static {v9, v10}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v9

    new-array v10, v12, [B

    const/16 v15, -0x24

    aput-byte v15, v10, v11

    new-array v15, v4, [B

    const/16 v16, -0x9

    aput-byte v16, v15, v11

    const/16 v11, -0x15

    aput-byte v11, v15, v12

    const/16 v11, 0x5b

    aput-byte v11, v15, v13

    const/16 v11, -0x4b

    aput-byte v11, v15, v14

    const/16 v11, -0x5e

    aput-byte v11, v15, v3

    const/16 v11, 0x36

    aput-byte v11, v15, v2

    const/16 v11, -0x7b

    const/4 v12, 0x6

    aput-byte v11, v15, v12

    const/16 v11, -0x1c

    aput-byte v11, v15, v18

    invoke-static {v10, v15}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v7, v9, v10}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v8, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v7, "4D"

    invoke-static {v7}, Lcom/github/catvod/spider/appysv2/KKB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v8, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v8}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5
    :try_end_179
    .catch Lorg/json/JSONException; {:try_start_6c .. :try_end_179} :catch_17b

    goto/16 :goto_10

    :catch_17b
    nop

    goto/16 :goto_10

    :cond_17e
    new-array v1, v3, [B

    fill-array-data v1, :array_21e

    new-array v3, v4, [B

    fill-array-data v3, :array_224

    invoke-static {v1, v3}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-eqz v1, :cond_1a7

    .line 1
    invoke-static {v5}, Lcom/github/catvod/spider/appysv2/b/t;->b(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const/16 v1, 0x34

    new-array v1, v1, [B

    .line 2
    fill-array-data v1, :array_22c

    new-array v2, v4, [B

    fill-array-data v2, :array_24a

    .line 3
    invoke-static {v1, v2, v0}, Lcom/github/catvod/spider/appysv2/b/t;->a([B[BLjava/lang/StringBuilder;)Ljava/lang/String;

    move-result-object v5

    goto :goto_1e2

    :cond_1a7
    const/16 v1, 0xb

    new-array v1, v1, [B

    .line 4
    fill-array-data v1, :array_252

    new-array v3, v4, [B

    fill-array-data v3, :array_25c

    invoke-static {v1, v3}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_1e2

    new-array v1, v2, [B

    fill-array-data v1, :array_264

    new-array v2, v4, [B

    fill-array-data v2, :array_26c

    invoke-static {v1, v2}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    if-eqz v0, :cond_1d2

    goto :goto_1e2

    :cond_1d2
    const/16 v0, 0x269

    new-array v0, v0, [B

    fill-array-data v0, :array_274

    new-array v1, v4, [B

    fill-array-data v1, :array_3ae

    invoke-static {v0, v1}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v5

    :cond_1e2
    :goto_1e2
    return-object v5

    nop

    :array_1e4
    .array-data 1
        0x69t
        -0x5at
        0x70t
        0x1at
        -0x58t
    .end array-data

    nop

    :array_1ec
    .array-data 1
        0xat
        -0x36t
        0x11t
        0x69t
        -0x25t
        -0x64t
        0x63t
        0x6ft
    .end array-data

    :array_1f4
    .array-data 1
        0x40t
        0x2et
        0x37t
        0x0t
    .end array-data

    :array_1fa
    .array-data 1
        0x21t
        0x5ct
        0x52t
        0x61t
        -0x20t
        0x30t
        0x7at
        -0x41t
    .end array-data

    :array_202
    .array-data 1
        0x2bt
        -0x73t
        -0x52t
        0x6ct
    .end array-data

    :array_208
    .array-data 1
        0x47t
        -0x14t
        -0x40t
        0xbt
        -0x36t
        0x41t
        -0x4ft
        0x6t
    .end array-data

    :array_210
    .array-data 1
        0x17t
        -0x55t
        0x1bt
        -0x75t
    .end array-data

    :array_216
    .array-data 1
        0x6et
        -0x32t
        0x7at
        -0x7t
        -0x5dt
        0x39t
        -0x18t
        -0x65t
    .end array-data

    :array_21e
    .array-data 1
        0x45t
        0x3ft
        -0x49t
        -0x50t
    .end array-data

    :array_224
    .array-data 1
        0x6bt
        0x49t
        -0x28t
        -0x2ct
        -0x4bt
        0x7at
        -0x23t
        -0x1ct
    .end array-data

    :array_22c
    .array-data 1
        0x62t
        -0x57t
        -0x3t
        -0x29t
        -0x6t
        -0x64t
        -0x7dt
        0x49t
        -0x73t
        -0x36t
        -0x25t
        -0x54t
        -0x64t
        -0x72t
        0x31t
        0x49t
        -0x72t
        -0x2dt
        -0xdt
        -0x5dt
        -0x77t
        -0x6at
        0x31t
        0x16t
        0x1t
        0x22t
        0x16t
        0x6et
        -0x7t
        -0x46t
        -0x74t
        -0x7bt
        -0x15t
        -0x1et
        0x4et
        0x2dt
        0x76t
        0x52t
        0x7ft
        0x49t
        -0x80t
        -0x20t
        -0x9t
        -0x60t
        -0x69t
        -0x60t
        0x31t
        0x11t
        0xbt
        0x20t
        0x1t
        0x20t
    .end array-data

    :array_24a
    .array-data 1
        0x68t
        0x4ft
        0x73t
        0x45t
        0x1ft
        0x26t
        0xct
        0x62t
    .end array-data

    :array_252
    .array-data 1
        0x24t
        0x26t
        0x6ct
        -0x29t
        0x50t
        0x78t
        0x4at
        0x51t
        0x24t
        0x26t
        0x75t
    .end array-data

    :array_25c
    .array-data 1
        0x45t
        0x56t
        0x5t
        -0x7t
        0x20t
        0x10t
        0x3at
        0x7et
    .end array-data

    :array_264
    .array-data 1
        -0x9t
        -0x70t
        -0x16t
        0x5et
        -0x6ft
    .end array-data

    nop

    :array_26c
    .array-data 1
        -0x71t
        -0x9t
        -0x75t
        0x2et
        -0x1ft
        0x6at
        0x23t
        -0x32t
    .end array-data

    :array_274
    .array-data 1
        0x58t
        -0x65t
        0x4t
        -0x5at
        0x19t
        0x6dt
        0x1bt
        -0x5t
        0x38t
        -0x45t
        0x6bt
        -0x3et
        0x0t
        -0x15t
        0x1bt
        -0x7t
        0x29t
        -0x5at
        0x67t
        -0x4t
        0x19t
        -0x15t
        0x5dt
        0x71t
        -0x35t
        0x7at
        -0x19t
        0x6at
        0x40t
        0x69t
        -0x52t
        -0x7t
        0x6t
        -0x42t
        0x67t
        -0x38t
        0xft
        -0x15t
        0x44t
        0x68t
        -0x33t
        0x7ft
        -0x1dt
        0x38t
        -0x7dt
        0x31t
        -0x75t
        -0x5et
        0x55t
        -0x66t
        0x38t
        0x7ct
        -0x24t
        -0x60t
        0x43t
        0x76t
        -0x2et
        0x64t
        -0x57t
        -0x5ct
        0x22t
        0x7et
        -0x2at
        -0x5et
        0x16t
        0x2et
        -0x1ft
        0x2et
        -0x3bt
        -0x41t
        0x53t
        0x35t
        -0x77t
        0x58t
        -0x41t
        0x2ct
        -0x39t
        -0x60t
        0x59t
        0x7bt
        -0x1et
        0x27t
        -0x17t
        0x6at
        0x4ct
        0x6bt
        -0x5dt
        -0xat
        0x3ft
        -0x5ft
        -0x41t
        0x35t
        -0x3ft
        -0x51t
        0x45t
        0x14t
        0x5at
        -0x42t
        0x19t
        -0x58t
        0x28t
        0x5ft
        0x53t
        0x72t
        -0x24t
        0x60t
        -0xft
        0x6at
        0x4dt
        0x53t
        -0x68t
        -0x9t
        0x3et
        -0x45t
        -0x41t
        0x6at
        0x4dt
        0x40t
        -0x54t
        -0x5t
        0x34t
        -0x4ct
        -0x57t
        -0x5at
        0x20t
        0x67t
        -0x2at
        -0x63t
        0x38t
        0x38t
        0x64t
        -0x40t
        0x38t
        0x30t
        -0x50t
        -0x78t
        -0x6at
        -0xat
        0x8t
        -0x17t
        0x4ct
        0x6bt
        -0x54t
        0x35t
        0x5at
        -0x4ct
        0x13t
        -0x5ct
        0x11t
        0x6dt
        0x1bt
        -0x5t
        0x34t
        -0x4ct
        0x64t
        -0x3et
        0x2dt
        -0x3t
        -0x2at
        -0x6at
        0x25t
        -0x9t
        0x38t
        -0x38t
        -0x7dt
        0x3et
        -0x63t
        -0x48t
        0x58t
        -0x61t
        0x28t
        0x6at
        0x4ft
        0x5ct
        -0x61t
        -0x7t
        0x0t
        -0x47t
        -0x57t
        -0x5ct
        0x22t
        0x7et
        -0x29t
        -0x76t
        0x6t
        0x38t
        0x67t
        -0x1ct
        0x2ft
        0x33t
        -0x77t
        -0x5bt
        -0x6at
        -0xbt
        0x2ft
        -0x19t
        0x4ct
        0x68t
        -0x70t
        0x35t
        0x58t
        -0x6bt
        0x10t
        -0x58t
        0x31t
        0x7ft
        0x1bt
        -0x8t
        0x23t
        -0x47t
        0x64t
        -0x37t
        0x30t
        -0x3t
        -0x2at
        -0x61t
        0x2dt
        -0xbt
        0x2t
        -0x29t
        -0x7dt
        0x30t
        -0x4et
        -0x4et
        0x5at
        -0x7bt
        0x13t
        0x6at
        0x4et
        0x55t
        -0x46t
        -0x8t
        0x3ft
        -0x77t
        -0x57t
        -0x5at
        0x13t
        0x59t
        -0x2bt
        -0x65t
        0x5t
        0x38t
        0x6bt
        -0x24t
        0x3at
        0x30t
        -0x58t
        -0x45t
        -0x6at
        -0xbt
        0x14t
        -0x3at
        0x40t
        0x5ft
        -0x76t
        0x35t
        0x58t
        -0x53t
        0x2ct
        -0x5at
        0x3ct
        0x63t
        -0x2bt
        -0x5dt
        0xct
        0x38t
        0x67t
        -0x32t
        0xct
        0x3et
        -0x6dt
        -0x65t
        -0x6at
        -0xat
        0xct
        -0x39t
        0x4dt
        0x59t
        -0x7et
        0x35t
        0x55t
        -0x54t
        0x12t
        -0x5ct
        0x22t
        0x7et
        0x1bt
        -0x5t
        0x3bt
        -0x71t
        0x64t
        -0x24t
        0x39t
        -0x3t
        -0x2at
        -0x63t
        0x37t
        -0xbt
        0x0t
        -0x25t
        -0x7dt
        0x30t
        -0x4dt
        -0x6ct
        0x5bt
        -0x6ft
        0x18t
        0x6at
        0x4ct
        0x6at
        -0x6at
        -0x7t
        0x2dt
        -0x6bt
        -0x57t
        -0x59t
        0x2bt
        0x53t
        -0x28t
        -0x69t
        0xft
        0x38t
        0x65t
        -0x19t
        0x27t
        0x33t
        -0x48t
        -0x49t
        -0x6at
        -0x9t
        0x3at
        -0x38t
        0x4ft
        0x6ct
        -0x69t
        0x35t
        0x58t
        -0x69t
        0x3dt
        -0x5at
        0x3t
        0x73t
        0x1bt
        -0x7t
        0x0t
        -0x7et
        0x65t
        -0x6t
        0x34t
        0x31t
        -0x5ct
        -0x55t
        0x58t
        -0x52t
        0x33t
        0x4bt
        0x4ft
        0x7bt
        -0x55t
        -0x9t
        0x3dt
        -0x66t
        -0x1dt
        0x33t
        -0x33t
        -0x49t
        0x1bt
        -0x5t
        0x38t
        -0x45t
        0x6bt
        -0x3et
        0x0t
        -0x15t
        0x1bt
        -0x5t
        0x19t
        -0x4ct
        0x6bt
        -0x28t
        0x2et
        -0x3t
        -0x27t
        -0x48t
        0x24t
        -0xbt
        0x3at
        -0x12t
        -0x7dt
        0x33t
        -0x41t
        -0x52t
        0x5bt
        -0x56t
        0x3ct
        0x6at
        0x4ft
        0x68t
        -0x42t
        -0x5t
        0x26t
        -0x52t
        -0x57t
        -0x57t
        0x23t
        0x67t
        -0x2bt
        -0x7bt
        0x0t
        0x38t
        0x64t
        -0xet
        0x3dt
        0x33t
        -0x55t
        -0x5dt
        -0x6at
        -0xbt
        0x15t
        -0x1ct
        0x4et
        0x4at
        -0x64t
        0x35t
        0x54t
        -0x74t
        0x2bt
        -0x5ct
        0x33t
        0x6bt
        0x1bt
        -0x5t
        0x3t
        -0x5ct
        0x67t
        -0x26t
        0x15t
        -0x3t
        -0x2at
        -0x53t
        0xdt
        -0xat
        0x19t
        -0x4t
        -0x7dt
        0x33t
        -0x43t
        -0x52t
        0x58t
        -0x57t
        0x24t
        0x6at
        0x40t
        0x73t
        -0x71t
        -0x7t
        0x32t
        -0x42t
        0x65t
        -0x38t
        0x31t
        -0x3t
        -0x2bt
        -0x6ct
        0x1dt
        -0xbt
        0x9t
        -0x2t
        0x4dt
        0x72t
        -0x69t
        0x35t
        0x58t
        -0x6at
        0x34t
        -0x5bt
        0x13t
        0x40t
        0x3at
        -0x7t
        0x10t
        -0x78t
        0x6bt
        -0x3ft
        0x21t
        -0x51t
        0x55t
        0x7ft
        -0x31t
        0x38t
        0x67t
        -0x3ct
        0x0t
        0x3ft
        -0x4dt
        -0x4at
        -0x80t
        0x38t
        -0x50t
        0x71t
        -0x66t
        -0x1bt
        0x1bt
        0x2ct
        -0x73t
        0x21t
        -0x50t
        0x6at
        -0x66t
        -0x1at
        0x2t
        0x2ft
        -0x6at
        0x21t
        -0x4et
        0x73t
        -0x68t
        -0x3t
        0x2t
        0x2et
        -0x74t
        0x2at
        -0x57t
        0x73t
        -0x68t
        -0x19t
        0x8t
        0x35t
        -0x71t
        0x23t
        -0x4dt
        0x76t
        -0x7dt
        -0x1ct
        0x0t
        0x2ft
        -0x75t
        0x38t
        -0x50t
        0x71t
        -0x67t
        -0x1dt
        0x1bt
        0x2ct
        -0x73t
        0x22t
        -0x4at
        0x6at
        -0x66t
        -0x1at
        0x1t
        0x2dt
        -0x6at
        0x21t
        -0x4et
        0x70t
        -0x66t
        -0x3t
        0x2t
        0x2et
        -0x74t
        0x22t
        -0x57t
        0x73t
        -0x68t
        -0x19t
        0x0t
        0x35t
        -0x71t
        0x23t
        -0x4et
        0x78t
        -0x7dt
        -0x1ct
        0x0t
        0x2et
        -0x7bt
        0x38t
        -0x50t
        0x71t
        -0x68t
        -0x1ft
        0x1bt
        0x2ct
        -0x73t
        0x23t
        -0x4ct
        0x6at
        -0x66t
        -0x1at
        0x0t
        0x2bt
        -0x6at
        0x21t
        -0x4et
        0x71t
        -0x64t
        -0x3t
        0x2t
        0x2et
        -0x73t
        0x20t
        -0x57t
        0x73t
        -0x68t
        -0x1at
        0x2t
        0x35t
        -0x71t
        0x23t
        -0x4et
        0x70t
        -0x7dt
        -0x1ct
        0x0t
        0x2et
        -0x73t
    .end array-data

    nop

    :array_3ae
    .array-data 1
        -0x43t
        0x13t
        -0x7et
        0x41t
        -0x58t
        -0x2at
        0x30t
        0x1et
    .end array-data
.end method

.method public homeContent(Z)Ljava/lang/String;
    .registers 28

    move-object/from16 v0, p0

    invoke-direct/range {p0 .. p0}, Lcom/github/catvod/spider/AppYsV2;->c()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/github/catvod/spider/AppYsV2;->f(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/String;->isEmpty()Z

    move-result v2

    const-string v3, "4D"

    invoke-static {v3}, Lcom/github/catvod/spider/appysv2/KKB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    const/4 v4, 0x0

    const/16 v5, 0x9

    const/4 v6, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x0

    const/4 v9, 0x1

    const/4 v10, 0x4

    const/16 v11, 0x8

    if-nez v2, :cond_146

    invoke-static {v1}, Lcom/github/catvod/crawler/SpiderDebug;->log(Ljava/lang/String;)V

    invoke-direct {v0, v1}, Lcom/github/catvod/spider/AppYsV2;->h(Ljava/lang/String;)Ljava/util/HashMap;

    move-result-object v2

    invoke-static {v1, v2}, Lcom/github/catvod/spider/appysv2/n/c;->m(Ljava/lang/String;Ljava/util/Map;)Ljava/lang/String;

    move-result-object v2

    new-instance v12, Lorg/json/JSONObject;

    invoke-direct {v12, v2}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    new-array v2, v10, [B

    fill-array-data v2, :array_506

    new-array v13, v11, [B

    fill-array-data v13, :array_50c

    invoke-static {v2, v13}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v12, v2}, Lorg/json/JSONObject;->has(Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_6e

    new-array v2, v10, [B

    fill-array-data v2, :array_514

    new-array v13, v11, [B

    fill-array-data v13, :array_51a

    invoke-static {v2, v13}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v12, v2}, Lorg/json/JSONObject;->get(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v2

    instance-of v2, v2, Lorg/json/JSONArray;

    if-eqz v2, :cond_6e

    new-array v2, v10, [B

    fill-array-data v2, :array_522

    new-array v4, v11, [B

    fill-array-data v4, :array_528

    invoke-static {v2, v4}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v2

    :goto_68
    invoke-virtual {v12, v2}, Lorg/json/JSONObject;->getJSONArray(Ljava/lang/String;)Lorg/json/JSONArray;

    move-result-object v4

    goto/16 :goto_1c2

    :cond_6e
    new-array v2, v10, [B

    fill-array-data v2, :array_530

    new-array v13, v11, [B

    fill-array-data v13, :array_536

    invoke-static {v2, v13}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v12, v2}, Lorg/json/JSONObject;->has(Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_10c

    new-array v2, v10, [B

    fill-array-data v2, :array_53e

    new-array v13, v11, [B

    fill-array-data v13, :array_544

    invoke-static {v2, v13}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v12, v2}, Lorg/json/JSONObject;->get(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v2

    instance-of v2, v2, Lorg/json/JSONObject;

    if-eqz v2, :cond_10c

    new-array v2, v10, [B

    fill-array-data v2, :array_54c

    new-array v13, v11, [B

    fill-array-data v13, :array_552

    invoke-static {v2, v13}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v12, v2}, Lorg/json/JSONObject;->getJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v2

    new-array v13, v10, [B

    fill-array-data v13, :array_55a

    new-array v14, v11, [B

    fill-array-data v14, :array_560

    invoke-static {v13, v14}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v13

    invoke-virtual {v2, v13}, Lorg/json/JSONObject;->has(Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_10c

    new-array v2, v10, [B

    fill-array-data v2, :array_568

    new-array v13, v11, [B

    fill-array-data v13, :array_56e

    invoke-static {v2, v13}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v12, v2}, Lorg/json/JSONObject;->getJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v2

    new-array v13, v10, [B

    fill-array-data v13, :array_576

    new-array v14, v11, [B

    fill-array-data v14, :array_57c

    invoke-static {v13, v14}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v13

    invoke-virtual {v2, v13}, Lorg/json/JSONObject;->get(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v2

    instance-of v2, v2, Lorg/json/JSONArray;

    if-eqz v2, :cond_10c

    new-array v2, v10, [B

    fill-array-data v2, :array_584

    new-array v4, v11, [B

    fill-array-data v4, :array_58a

    invoke-static {v2, v4}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v12, v2}, Lorg/json/JSONObject;->getJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v2

    new-array v4, v10, [B

    fill-array-data v4, :array_592

    new-array v12, v11, [B

    fill-array-data v12, :array_598

    invoke-static {v4, v12}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v2, v4}, Lorg/json/JSONObject;->getJSONArray(Ljava/lang/String;)Lorg/json/JSONArray;

    move-result-object v4

    goto/16 :goto_1c2

    :cond_10c
    new-array v2, v10, [B

    fill-array-data v2, :array_5a0

    new-array v13, v11, [B

    fill-array-data v13, :array_5a6

    invoke-static {v2, v13}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v12, v2}, Lorg/json/JSONObject;->has(Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_1c2

    new-array v2, v10, [B

    fill-array-data v2, :array_5ae

    new-array v13, v11, [B

    fill-array-data v13, :array_5b4

    invoke-static {v2, v13}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v12, v2}, Lorg/json/JSONObject;->get(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v2

    instance-of v2, v2, Lorg/json/JSONArray;

    if-eqz v2, :cond_1c2

    new-array v2, v10, [B

    fill-array-data v2, :array_5bc

    new-array v4, v11, [B

    fill-array-data v4, :array_5c2

    invoke-static {v2, v4}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v2

    goto/16 :goto_68

    :cond_146
    invoke-virtual {v0, v1, v4}, Lcom/github/catvod/spider/AppYsV2;->g(Ljava/lang/String;Lorg/json/JSONObject;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v2, v3}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v2

    aget-object v2, v2, v8

    new-array v4, v6, [B

    fill-array-data v4, :array_5ca

    new-array v12, v11, [B

    fill-array-data v12, :array_5d0

    invoke-static {v4, v12}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v2, v4}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v2

    new-instance v4, Lorg/json/JSONArray;

    invoke-direct {v4}, Lorg/json/JSONArray;-><init>()V

    const/4 v12, 0x1

    :goto_168
    array-length v13, v2

    if-ge v12, v13, :cond_1c2

    aget-object v13, v2, v12

    invoke-virtual {v13}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v13

    new-array v14, v9, [B

    const/16 v15, -0x4c

    aput-byte v15, v14, v8

    new-array v15, v11, [B

    fill-array-data v15, :array_5d8

    invoke-static {v14, v15}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v14

    invoke-virtual {v13, v14}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v13

    array-length v14, v13

    if-ge v14, v6, :cond_188

    goto :goto_1be

    :cond_188
    new-instance v14, Lorg/json/JSONObject;

    invoke-direct {v14}, Lorg/json/JSONObject;-><init>()V

    new-array v15, v5, [B

    fill-array-data v15, :array_5e0

    new-array v10, v11, [B

    fill-array-data v10, :array_5ea

    invoke-static {v15, v10}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v10

    aget-object v15, v13, v8

    invoke-virtual {v15}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v15

    invoke-virtual {v14, v10, v15}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    new-array v10, v7, [B

    fill-array-data v10, :array_5f2

    new-array v15, v11, [B

    fill-array-data v15, :array_5fa

    invoke-static {v10, v15}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v10

    aget-object v13, v13, v9

    invoke-virtual {v13}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v13

    invoke-virtual {v14, v10, v13}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    invoke-virtual {v4, v14}, Lorg/json/JSONArray;->put(Ljava/lang/Object;)Lorg/json/JSONArray;

    :goto_1be
    add-int/lit8 v12, v12, 0x1

    const/4 v10, 0x4

    goto :goto_168

    :cond_1c2
    :goto_1c2
    new-instance v2, Lorg/json/JSONObject;

    invoke-direct {v2}, Lorg/json/JSONObject;-><init>()V

    new-instance v10, Lorg/json/JSONArray;

    invoke-direct {v10}, Lorg/json/JSONArray;-><init>()V

    if-eqz v4, :cond_4da

    const/4 v13, 0x0

    :goto_1cf
    invoke-virtual {v4}, Lorg/json/JSONArray;->length()I

    move-result v14

    if-ge v13, v14, :cond_4da

    invoke-virtual {v4, v13}, Lorg/json/JSONArray;->getJSONObject(I)Lorg/json/JSONObject;

    move-result-object v14

    new-array v15, v5, [B

    fill-array-data v15, :array_602

    new-array v9, v11, [B

    fill-array-data v9, :array_60c

    invoke-static {v15, v9}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v14, v9}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    new-array v15, v7, [B

    fill-array-data v15, :array_614

    new-array v12, v11, [B

    fill-array-data v12, :array_61c

    invoke-static {v15, v12}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v12

    invoke-virtual {v14, v12}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v12

    new-instance v15, Lorg/json/JSONObject;

    invoke-direct {v15}, Lorg/json/JSONObject;-><init>()V

    new-array v8, v7, [B

    fill-array-data v8, :array_624

    new-array v7, v11, [B

    fill-array-data v7, :array_62c

    invoke-static {v8, v7}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v15, v7, v12}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    new-array v7, v5, [B

    fill-array-data v7, :array_634

    new-array v8, v11, [B

    fill-array-data v8, :array_63e

    invoke-static {v7, v8}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v15, v7, v9}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/16 v7, 0xb

    new-array v7, v7, [B

    fill-array-data v7, :array_646

    new-array v8, v11, [B

    fill-array-data v8, :array_650

    invoke-static {v7, v8}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v14, v7}, Lorg/json/JSONObject;->optJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v7

    if-eqz p1, :cond_4ba

    invoke-virtual {v0, v1, v7}, Lcom/github/catvod/spider/AppYsV2;->g(Ljava/lang/String;Lorg/json/JSONObject;)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v7, v3}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v7

    new-instance v8, Lorg/json/JSONArray;

    invoke-direct {v8}, Lorg/json/JSONArray;-><init>()V

    invoke-virtual {v1}, Ljava/lang/String;->isEmpty()Z

    move-result v9

    :goto_24b
    array-length v14, v7

    if-ge v9, v14, :cond_46f

    aget-object v14, v7, v9

    invoke-virtual {v14}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v14

    invoke-virtual {v14}, Ljava/lang/String;->isEmpty()Z

    move-result v19

    if-eqz v19, :cond_268

    move-object/from16 v21, v1

    move-object/from16 v20, v3

    move-object/from16 v17, v4

    move-object/from16 v23, v7

    const/16 v3, 0x8

    const/16 v18, 0x0

    goto/16 :goto_45c

    :cond_268
    new-array v5, v6, [B

    fill-array-data v5, :array_658

    new-array v6, v11, [B

    fill-array-data v6, :array_65e

    invoke-static {v5, v6}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v14, v5}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v5

    const/4 v6, 0x0

    aget-object v14, v5, v6

    invoke-virtual {v14}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v6

    const/4 v14, 0x6

    new-array v0, v14, [B

    fill-array-data v0, :array_666

    new-array v14, v11, [B

    fill-array-data v14, :array_66e

    invoke-static {v0, v14}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v6, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    if-eqz v0, :cond_363

    const/4 v0, 0x6

    new-array v14, v0, [B

    fill-array-data v14, :array_676

    new-array v0, v11, [B

    fill-array-data v0, :array_67e

    invoke-static {v14, v0}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v0

    const-string v14, ""

    invoke-virtual {v6, v0, v14}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v14

    move-object/from16 v21, v1

    sparse-switch v14, :sswitch_data_4f4

    goto :goto_311

    :sswitch_2b5
    const/4 v14, 0x5

    new-array v1, v14, [B

    fill-array-data v1, :array_686

    new-array v14, v11, [B

    fill-array-data v14, :array_68e

    invoke-static {v1, v14}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_311

    const/4 v1, 0x0

    goto :goto_312

    :sswitch_2cc
    const/4 v1, 0x4

    new-array v14, v1, [B

    fill-array-data v14, :array_696

    new-array v1, v11, [B

    fill-array-data v1, :array_69c

    invoke-static {v14, v1}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_311

    const/4 v1, 0x3

    goto :goto_312

    :sswitch_2e3
    const/4 v1, 0x4

    new-array v14, v1, [B

    fill-array-data v14, :array_6a4

    new-array v1, v11, [B

    fill-array-data v1, :array_6aa

    invoke-static {v14, v1}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_311

    const/4 v1, 0x2

    goto :goto_312

    :sswitch_2fa
    const/4 v1, 0x4

    new-array v14, v1, [B

    fill-array-data v14, :array_6b2

    new-array v1, v11, [B

    fill-array-data v1, :array_6b8

    invoke-static {v14, v1}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_311

    const/4 v1, 0x1

    goto :goto_312

    :cond_311
    :goto_311
    const/4 v1, -0x1

    :goto_312
    if-eqz v1, :cond_353

    const/4 v14, 0x1

    if-eq v1, v14, :cond_343

    const/4 v14, 0x2

    if-eq v1, v14, :cond_333

    const/4 v14, 0x3

    if-eq v1, v14, :cond_323

    :goto_31d
    move-object/from16 v25, v6

    move-object v6, v0

    move-object/from16 v0, v25

    goto :goto_366

    :cond_323
    const/4 v1, 0x6

    new-array v1, v1, [B

    fill-array-data v1, :array_6c0

    new-array v6, v11, [B

    fill-array-data v6, :array_6c8

    invoke-static {v1, v6}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v6

    goto :goto_31d

    :cond_333
    const/4 v1, 0x6

    new-array v1, v1, [B

    fill-array-data v1, :array_6d0

    new-array v6, v11, [B

    fill-array-data v6, :array_6d8

    invoke-static {v1, v6}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v6

    goto :goto_31d

    :cond_343
    const/4 v1, 0x6

    new-array v1, v1, [B

    fill-array-data v1, :array_6e0

    new-array v6, v11, [B

    fill-array-data v6, :array_6e8

    invoke-static {v1, v6}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v6

    goto :goto_31d

    :cond_353
    const/4 v1, 0x6

    new-array v1, v1, [B

    fill-array-data v1, :array_6f0

    new-array v6, v11, [B

    fill-array-data v6, :array_6f8

    invoke-static {v1, v6}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v6

    goto :goto_31d

    :cond_363
    move-object/from16 v21, v1

    move-object v0, v6

    :goto_366
    new-instance v1, Lorg/json/JSONObject;

    invoke-direct {v1}, Lorg/json/JSONObject;-><init>()V

    const/4 v14, 0x3

    new-array v14, v14, [B

    fill-array-data v14, :array_700

    move-object/from16 v20, v3

    new-array v3, v11, [B

    fill-array-data v3, :array_706

    invoke-static {v14, v3}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v1, v3, v6}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v3, 0x4

    new-array v6, v3, [B

    fill-array-data v6, :array_70e

    new-array v14, v11, [B

    fill-array-data v14, :array_714

    invoke-static {v6, v14}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v1, v6, v0}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    new-instance v0, Lorg/json/JSONArray;

    invoke-direct {v0}, Lorg/json/JSONArray;-><init>()V

    const/4 v14, 0x1

    :goto_397
    array-length v6, v5

    if-ge v14, v6, :cond_43f

    new-instance v6, Lorg/json/JSONObject;

    invoke-direct {v6}, Lorg/json/JSONObject;-><init>()V

    aget-object v16, v5, v14

    invoke-virtual/range {v16 .. v16}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v3

    move-object/from16 v17, v4

    const/4 v11, 0x1

    new-array v4, v11, [B

    const/16 v22, 0x25

    const/4 v11, 0x0

    aput-byte v22, v4, v11

    move-object/from16 v22, v5

    const/16 v11, 0x8

    new-array v5, v11, [B

    fill-array-data v5, :array_71c

    invoke-static {v4, v5}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/String;->indexOf(Ljava/lang/String;)I

    move-result v4

    const/4 v5, -0x1

    if-ne v4, v5, :cond_3f0

    const/4 v5, 0x1

    new-array v4, v5, [B

    const/16 v16, 0x21

    const/4 v5, 0x0

    aput-byte v16, v4, v5

    new-array v5, v11, [B

    fill-array-data v5, :array_724

    invoke-static {v4, v5}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v6, v4, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v5, 0x1

    new-array v4, v5, [B

    const/16 v16, 0x78

    const/4 v5, 0x0

    aput-byte v16, v4, v5

    new-array v5, v11, [B

    fill-array-data v5, :array_72c

    invoke-static {v4, v5}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v6, v4, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    move-object/from16 v23, v7

    const/16 v18, 0x0

    goto :goto_42f

    :cond_3f0
    const/4 v5, 0x0

    invoke-virtual {v3, v5, v4}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v16

    move-object/from16 v23, v7

    const/4 v11, 0x1

    new-array v7, v11, [B

    const/16 v24, -0x74

    aput-byte v24, v7, v5

    const/16 v5, 0x8

    new-array v11, v5, [B

    fill-array-data v11, :array_734

    invoke-static {v7, v11}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v7

    invoke-virtual/range {v16 .. v16}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v11

    invoke-virtual {v6, v7, v11}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v7, 0x1

    new-array v11, v7, [B

    const/16 v16, -0x38

    const/16 v18, 0x0

    aput-byte v16, v11, v18

    new-array v7, v5, [B

    fill-array-data v7, :array_73c

    invoke-static {v11, v7}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v5

    add-int/lit8 v4, v4, 0x1

    invoke-virtual {v3, v4}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v6, v5, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    :goto_42f
    invoke-virtual {v0, v6}, Lorg/json/JSONArray;->put(Ljava/lang/Object;)Lorg/json/JSONArray;

    add-int/lit8 v14, v14, 0x1

    move-object/from16 v4, v17

    move-object/from16 v5, v22

    move-object/from16 v7, v23

    const/4 v3, 0x4

    const/16 v11, 0x8

    goto/16 :goto_397

    :cond_43f
    move-object/from16 v17, v4

    move-object/from16 v23, v7

    const/4 v3, 0x5

    const/16 v18, 0x0

    new-array v4, v3, [B

    fill-array-data v4, :array_744

    const/16 v3, 0x8

    new-array v5, v3, [B

    fill-array-data v5, :array_74c

    invoke-static {v4, v5}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v1, v4, v0}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    invoke-virtual {v8, v1}, Lorg/json/JSONArray;->put(Ljava/lang/Object;)Lorg/json/JSONArray;

    :goto_45c
    add-int/lit8 v9, v9, 0x1

    move-object/from16 v0, p0

    move-object/from16 v4, v17

    move-object/from16 v3, v20

    move-object/from16 v1, v21

    move-object/from16 v7, v23

    const/16 v5, 0x9

    const/4 v6, 0x2

    const/16 v11, 0x8

    goto/16 :goto_24b

    :cond_46f
    move-object/from16 v21, v1

    move-object/from16 v20, v3

    move-object/from16 v17, v4

    const/4 v0, 0x7

    const/16 v3, 0x8

    const/16 v18, 0x0

    new-array v1, v0, [B

    fill-array-data v1, :array_754

    new-array v4, v3, [B

    fill-array-data v4, :array_75c

    invoke-static {v1, v4}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v2, v1}, Lorg/json/JSONObject;->has(Ljava/lang/String;)Z

    move-result v1

    if-nez v1, :cond_4a4

    new-array v1, v0, [B

    fill-array-data v1, :array_764

    new-array v4, v3, [B

    fill-array-data v4, :array_76c

    invoke-static {v1, v4}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v1

    new-instance v4, Lorg/json/JSONObject;

    invoke-direct {v4}, Lorg/json/JSONObject;-><init>()V

    invoke-virtual {v2, v1, v4}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    :cond_4a4
    new-array v1, v0, [B

    fill-array-data v1, :array_774

    new-array v4, v3, [B

    fill-array-data v4, :array_77c

    invoke-static {v1, v4}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v2, v1}, Lorg/json/JSONObject;->getJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v1

    invoke-virtual {v1, v12, v8}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    goto :goto_4c3

    :cond_4ba
    move-object/from16 v21, v1

    move-object/from16 v20, v3

    move-object/from16 v17, v4

    const/4 v0, 0x7

    const/16 v18, 0x0

    :goto_4c3
    invoke-virtual {v10, v15}, Lorg/json/JSONArray;->put(Ljava/lang/Object;)Lorg/json/JSONArray;

    add-int/lit8 v13, v13, 0x1

    move-object/from16 v0, p0

    move-object/from16 v4, v17

    move-object/from16 v3, v20

    move-object/from16 v1, v21

    const/16 v5, 0x9

    const/4 v6, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x0

    const/4 v9, 0x1

    const/16 v11, 0x8

    goto/16 :goto_1cf

    :cond_4da
    const/4 v0, 0x5

    new-array v0, v0, [B

    fill-array-data v0, :array_784

    const/16 v1, 0x8

    new-array v1, v1, [B

    fill-array-data v1, :array_78c

    invoke-static {v0, v1}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v2, v0, v10}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    invoke-virtual {v2}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0

    nop

    :sswitch_data_4f4
    .sparse-switch
        0x2dd08d -> :sswitch_2fa
        0x3291ee -> :sswitch_2e3
        0x38883d -> :sswitch_2cc
        0x5a5a978 -> :sswitch_2b5
    .end sparse-switch

    :array_506
    .array-data 1
        -0x65t
        0x14t
        0x11t
        0x18t
    .end array-data

    :array_50c
    .array-data 1
        -0x9t
        0x7dt
        0x62t
        0x6ct
        -0x7t
        -0x5at
        -0x71t
        -0x1t
    .end array-data

    :array_514
    .array-data 1
        -0x4et
        0x5dt
        0x3t
        0x67t
    .end array-data

    :array_51a
    .array-data 1
        -0x22t
        0x34t
        0x70t
        0x13t
        -0x2bt
        -0x14t
        0x51t
        -0x6dt
    .end array-data

    :array_522
    .array-data 1
        0x55t
        -0xft
        -0x44t
        0x44t
    .end array-data

    :array_528
    .array-data 1
        0x39t
        -0x68t
        -0x31t
        0x30t
        -0x1ft
        0x61t
        -0x80t
        0x6at
    .end array-data

    :array_530
    .array-data 1
        -0x4et
        0x17t
        0x6dt
        0x7et
    .end array-data

    :array_536
    .array-data 1
        -0x2at
        0x76t
        0x19t
        0x1ft
        0x51t
        -0x3bt
        -0x2t
        0x0t
    .end array-data

    :array_53e
    .array-data 1
        -0x46t
        0x55t
        0x5dt
        -0x60t
    .end array-data

    :array_544
    .array-data 1
        -0x22t
        0x34t
        0x29t
        -0x3ft
        0x65t
        0x60t
        0x1ft
        0x69t
    .end array-data

    :array_54c
    .array-data 1
        0x56t
        -0x44t
        0x6ct
        -0x68t
    .end array-data

    :array_552
    .array-data 1
        0x32t
        -0x23t
        0x18t
        -0x7t
        -0x35t
        0x15t
        0x6bt
        -0x64t
    .end array-data

    :array_55a
    .array-data 1
        -0x1at
        -0x41t
        -0x2ct
        -0x6et
    .end array-data

    :array_560
    .array-data 1
        -0x76t
        -0x2at
        -0x59t
        -0x1at
        -0x5et
        -0x35t
        0x17t
        -0x54t
    .end array-data

    :array_568
    .array-data 1
        -0x1ct
        0x47t
        -0x15t
        -0x5ct
    .end array-data

    :array_56e
    .array-data 1
        -0x80t
        0x26t
        -0x61t
        -0x3bt
        0x2et
        0x1dt
        -0x51t
        -0x73t
    .end array-data

    :array_576
    .array-data 1
        0xbt
        -0x4bt
        -0x24t
        0x29t
    .end array-data

    :array_57c
    .array-data 1
        0x67t
        -0x24t
        -0x51t
        0x5dt
        -0x2ft
        0x1ct
        -0xdt
        0x59t
    .end array-data

    :array_584
    .array-data 1
        -0x6ft
        -0x5dt
        0x1bt
        0x5dt
    .end array-data

    :array_58a
    .array-data 1
        -0xbt
        -0x3et
        0x6ft
        0x3ct
        0x6at
        0x5ct
        0x18t
        0x11t
    .end array-data

    :array_592
    .array-data 1
        0x44t
        -0x4dt
        0x31t
        -0x64t
    .end array-data

    :array_598
    .array-data 1
        0x28t
        -0x26t
        0x42t
        -0x18t
        -0x5ft
        0x18t
        -0x1ct
        0x44t
    .end array-data

    :array_5a0
    .array-data 1
        0x69t
        0xat
        -0xet
        0x7ft
    .end array-data

    :array_5a6
    .array-data 1
        0xdt
        0x6bt
        -0x7at
        0x1et
        -0x55t
        0x5et
        -0x36t
        -0x16t
    .end array-data

    :array_5ae
    .array-data 1
        0x3at
        -0x66t
        0xat
        -0x43t
    .end array-data

    :array_5b4
    .array-data 1
        0x5et
        -0x5t
        0x7et
        -0x24t
        0x1bt
        -0x3et
        0x1ft
        0x19t
    .end array-data

    :array_5bc
    .array-data 1
        0x5bt
        -0x7t
        -0x80t
        -0x6bt
    .end array-data

    :array_5c2
    .array-data 1
        0x3ft
        -0x68t
        -0xct
        -0xct
        -0x3t
        0x7et
        0x0t
        -0x45t
    .end array-data

    :array_5ca
    .array-data 1
        -0x6at
        -0x58t
    .end array-data

    nop

    :array_5d0
    .array-data 1
        -0x36t
        -0x7dt
        -0x71t
        0x70t
        -0x70t
        -0x51t
        -0x48t
        -0x2at
    .end array-data

    :array_5d8
    .array-data 1
        -0x77t
        0x8t
        0x3dt
        0x25t
        0x71t
        -0x20t
        -0x56t
        -0x3ft
    .end array-data

    :array_5e0
    .array-data 1
        -0x3bt
        -0x8t
        0x75t
        0x6t
        0x7ct
        -0x47t
        -0x33t
        0xct
        -0x2ct
    .end array-data

    nop

    :array_5ea
    .array-data 1
        -0x4ft
        -0x7ft
        0x5t
        0x63t
        0x23t
        -0x29t
        -0x54t
        0x61t
    .end array-data

    :array_5f2
    .array-data 1
        0x49t
        -0x44t
        -0x7at
        0x2et
        0x5ct
        -0x42t
        0x6t
    .end array-data

    :array_5fa
    .array-data 1
        0x3dt
        -0x3bt
        -0xat
        0x4bt
        0x3t
        -0x29t
        0x62t
        -0x44t
    .end array-data

    :array_602
    .array-data 1
        -0x2et
        -0x43t
        -0x32t
        -0x58t
        0x64t
        -0x47t
        0xbt
        0x40t
        -0x3dt
    .end array-data

    nop

    :array_60c
    .array-data 1
        -0x5at
        -0x3ct
        -0x42t
        -0x33t
        0x3bt
        -0x29t
        0x6at
        0x2dt
    .end array-data

    :array_614
    .array-data 1
        0x5at
        0x6et
        0x30t
        -0x24t
        -0x30t
        -0xet
        -0x9t
    .end array-data

    :array_61c
    .array-data 1
        0x2et
        0x17t
        0x40t
        -0x47t
        -0x71t
        -0x65t
        -0x6dt
        -0x56t
    .end array-data

    :array_624
    .array-data 1
        0x1t
        0x21t
        -0x7bt
        0xct
        0x1at
        -0x2t
        -0x4ft
    .end array-data

    :array_62c
    .array-data 1
        0x75t
        0x58t
        -0xbt
        0x69t
        0x45t
        -0x69t
        -0x2bt
        -0x28t
    .end array-data

    :array_634
    .array-data 1
        -0x55t
        -0x6dt
        -0x3t
        0x35t
        -0x1ft
        -0x68t
        0x50t
        -0x9t
        -0x46t
    .end array-data

    nop

    :array_63e
    .array-data 1
        -0x21t
        -0x16t
        -0x73t
        0x50t
        -0x42t
        -0xat
        0x31t
        -0x66t
    .end array-data

    :array_646
    .array-data 1
        0x57t
        -0x47t
        0x4bt
        0x4dt
        -0x4et
        0x32t
        -0x4ft
        -0x5dt
        0x46t
        -0x52t
        0x5ft
    .end array-data

    :array_650
    .array-data 1
        0x23t
        -0x40t
        0x3bt
        0x28t
        -0x13t
        0x57t
        -0x37t
        -0x29t
    .end array-data

    :array_658
    .array-data 1
        -0x68t
        0x1at
    .end array-data

    nop

    :array_65e
    .array-data 1
        -0x3ct
        0x31t
        -0xft
        0x21t
        -0x78t
        0x41t
        -0x2bt
        -0x20t
    .end array-data

    :array_666
    .array-data 1
        -0x49t
        -0x1dt
        -0x36t
        -0x67t
        -0x9t
        0x49t
    .end array-data

    nop

    :array_66e
    .array-data 1
        0x50t
        0x4et
        0x51t
        0x70t
        0x77t
        -0x40t
        0x24t
        -0x32t
    .end array-data

    :array_676
    .array-data 1
        0x27t
        0x22t
        -0x77t
        0x2ct
        -0x59t
        0x20t
    .end array-data

    nop

    :array_67e
    .array-data 1
        -0x40t
        -0x71t
        0x12t
        -0x3bt
        0x27t
        -0x57t
        0x75t
        0x50t
    .end array-data

    :array_686
    .array-data 1
        0x79t
        -0x3et
        -0x6dt
        0x14t
        0x3at
    .end array-data

    nop

    :array_68e
    .array-data 1
        0x1at
        -0x52t
        -0xet
        0x67t
        0x49t
        -0x63t
        0x5at
        0x6dt
    .end array-data

    :array_696
    .array-data 1
        0x65t
        -0x65t
        0x5et
        -0x5ct
    .end array-data

    :array_69c
    .array-data 1
        0x1ct
        -0x2t
        0x3ft
        -0x2at
        -0x34t
        0x65t
        0x23t
        -0xet
    .end array-data

    :array_6a4
    .array-data 1
        -0x37t
        0x4ft
        -0x34t
        0x3bt
    .end array-data

    :array_6aa
    .array-data 1
        -0x5bt
        0x2et
        -0x5et
        0x5ct
        -0x6bt
        0x68t
        -0x37t
        -0x2at
    .end array-data

    :array_6b2
    .array-data 1
        0x3dt
        -0x3t
        0x1et
        0x18t
    .end array-data

    :array_6b8
    .array-data 1
        0x5ct
        -0x71t
        0x7bt
        0x79t
        0x73t
        0x7bt
        0x2at
        -0x4t
    .end array-data

    :array_6c0
    .array-data 1
        0xdt
        -0x2ct
        -0x38t
        -0x5ft
        -0x3t
        0x5at
    .end array-data

    nop

    :array_6c8
    .array-data 1
        -0x18t
        0x6dt
        0x7ct
        0x45t
        0x46t
        -0x19t
        0x33t
        -0x72t
    .end array-data

    :array_6d0
    .array-data 1
        -0x13t
        0x59t
        0x24t
        -0x3ct
        0x6ft
        0x3ft
    .end array-data

    nop

    :array_6d8
    .array-data 1
        0x5t
        -0xat
        -0x77t
        0x2ct
        -0x39t
        -0x41t
        -0xet
        0x31t
    .end array-data

    :array_6e0
    .array-data 1
        0x4bt
        0x2ft
        -0x41t
        0x33t
        0x5dt
        -0x54t
    .end array-data

    nop

    :array_6e8
    .array-data 1
        -0x52t
        -0x4dt
        0xft
        -0x2at
        -0x2ft
        0x16t
        -0x1bt
        -0x4at
    .end array-data

    :array_6f0
    .array-data 1
        -0x8t
        0x19t
        0x21t
        0x4et
        0x8t
        -0x56t
    .end array-data

    nop

    :array_6f8
    .array-data 1
        0x1ft
        -0x58t
        -0x66t
        -0x55t
        -0x6at
        0x21t
        -0x6ft
        -0x15t
    .end array-data

    :array_700
    .array-data 1
        -0x1ft
        0x5et
        -0x63t
    .end array-data

    :array_706
    .array-data 1
        -0x76t
        0x3bt
        -0x1ct
        -0x4dt
        0x63t
        0xft
        0x67t
        0x1dt
    .end array-data

    :array_70e
    .array-data 1
        0x53t
        -0x75t
        0x50t
        -0x45t
    .end array-data

    :array_714
    .array-data 1
        0x3dt
        -0x16t
        0x3dt
        -0x22t
        -0x5t
        0x68t
        -0x1at
        -0x6ft
    .end array-data

    :array_71c
    .array-data 1
        0x18t
        0x8t
        0x42t
        -0x5dt
        -0x7dt
        -0x6t
        0x58t
        0x66t
    .end array-data

    :array_724
    .array-data 1
        0x4ft
        0x14t
        -0xft
        -0x3dt
        -0x76t
        0x6ft
        -0x18t
        -0x79t
    .end array-data

    :array_72c
    .array-data 1
        0xet
        0x0t
        -0x4dt
        0x3et
        -0x17t
        -0x3et
        0x38t
        0x36t
    .end array-data

    :array_734
    .array-data 1
        -0x1et
        0x49t
        0x4ct
        0x69t
        -0x5ft
        0x0t
        -0x63t
        0xft
    .end array-data

    :array_73c
    .array-data 1
        -0x42t
        -0x48t
        -0x1bt
        -0x62t
        0x62t
        -0x75t
        -0x42t
        0x37t
    .end array-data

    :array_744
    .array-data 1
        -0x4bt
        -0x6t
        0x8t
        0xct
        0x46t
    .end array-data

    nop

    :array_74c
    .array-data 1
        -0x3dt
        -0x65t
        0x64t
        0x79t
        0x23t
        0x13t
        0x7dt
        -0x6ft
    .end array-data

    :array_754
    .array-data 1
        -0x17t
        -0x6ct
        -0x30t
        -0x50t
        -0x30t
        0x7ft
        -0x2ft
    .end array-data

    :array_75c
    .array-data 1
        -0x71t
        -0x3t
        -0x44t
        -0x3ct
        -0x4bt
        0xdt
        -0x5et
        0x7dt
    .end array-data

    :array_764
    .array-data 1
        -0x36t
        -0x2bt
        0x74t
        -0x4dt
        -0x4dt
        0x2ct
        -0x6ct
    .end array-data

    :array_76c
    .array-data 1
        -0x54t
        -0x44t
        0x18t
        -0x39t
        -0x2at
        0x5et
        -0x19t
        -0x4ct
    .end array-data

    :array_774
    .array-data 1
        -0x4t
        0x7at
        -0x49t
        -0xft
        -0x75t
        -0x38t
        -0x51t
    .end array-data

    :array_77c
    .array-data 1
        -0x66t
        0x13t
        -0x25t
        -0x7bt
        -0x12t
        -0x46t
        -0x24t
        -0x15t
    .end array-data

    :array_784
    .array-data 1
        0x38t
        0x79t
        -0x29t
        -0x59t
        0x3dt
    .end array-data

    nop

    :array_78c
    .array-data 1
        0x5bt
        0x15t
        -0x4at
        -0x2ct
        0x4et
        0x64t
        0x52t
        0x1ct
    .end array-data
.end method

.method public homeVideoContent()Ljava/lang/String;
    .registers 16

    invoke-direct {p0}, Lcom/github/catvod/spider/AppYsV2;->c()Ljava/lang/String;

    move-result-object v0

    const/16 v1, 0xb

    new-array v2, v1, [B

    .line 1
    fill-array-data v2, :array_250

    const/16 v3, 0x8

    new-array v4, v3, [B

    fill-array-data v4, :array_25a

    invoke-static {v2, v4}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v2

    const/4 v4, 0x4

    const/4 v5, 0x5

    if-nez v2, :cond_5f

    new-array v2, v5, [B

    fill-array-data v2, :array_262

    new-array v6, v3, [B

    fill-array-data v6, :array_26a

    invoke-static {v2, v6}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v2

    if-eqz v2, :cond_33

    goto :goto_5f

    :cond_33
    new-array v2, v4, [B

    fill-array-data v2, :array_272

    new-array v6, v3, [B

    fill-array-data v6, :array_278

    invoke-static {v2, v6}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v2

    if-eqz v2, :cond_5c

    .line 2
    invoke-static {v0}, Lcom/github/catvod/spider/appysv2/b/t;->b(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const/16 v6, 0xa

    new-array v6, v6, [B

    .line 3
    fill-array-data v6, :array_280

    new-array v7, v3, [B

    fill-array-data v7, :array_28a

    invoke-static {v6, v7}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v6

    goto :goto_73

    :cond_5c
    const-string v2, ""

    goto :goto_7a

    .line 4
    :cond_5f
    :goto_5f
    invoke-static {v0}, Lcom/github/catvod/spider/appysv2/b/t;->b(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const/16 v6, 0x12

    new-array v6, v6, [B

    .line 5
    fill-array-data v6, :array_292

    new-array v7, v3, [B

    fill-array-data v7, :array_2a0

    invoke-static {v6, v7}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v6

    :goto_73
    invoke-virtual {v2, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    .line 6
    :goto_7a
    invoke-virtual {v2}, Ljava/lang/String;->isEmpty()Z

    move-result v6

    if-eqz v6, :cond_9e

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {p0, v0}, Lcom/github/catvod/spider/AppYsV2;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v0, 0x1f

    new-array v0, v0, [B

    fill-array-data v0, :array_2a8

    new-array v6, v3, [B

    fill-array-data v6, :array_2bc

    .line 7
    invoke-static {v0, v6, v2}, Lcom/github/catvod/spider/appysv2/b/t;->a([B[BLjava/lang/StringBuilder;)Ljava/lang/String;

    move-result-object v2

    const/4 v0, 0x1

    goto :goto_9f

    :cond_9e
    const/4 v0, 0x0

    .line 8
    :goto_9f
    invoke-static {v2}, Lcom/github/catvod/crawler/SpiderDebug;->log(Ljava/lang/String;)V

    invoke-direct {p0, v2}, Lcom/github/catvod/spider/AppYsV2;->h(Ljava/lang/String;)Ljava/util/HashMap;

    move-result-object v6

    invoke-static {v2, v6}, Lcom/github/catvod/spider/appysv2/n/c;->m(Ljava/lang/String;Ljava/util/Map;)Ljava/lang/String;

    move-result-object v2

    new-instance v6, Lorg/json/JSONObject;

    invoke-direct {v6, v2}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    new-instance v2, Lorg/json/JSONArray;

    invoke-direct {v2}, Lorg/json/JSONArray;-><init>()V

    const/4 v7, 0x7

    const/4 v8, 0x6

    if-eqz v0, :cond_156

    new-array v0, v4, [B

    fill-array-data v0, :array_2c4

    new-array v9, v3, [B

    fill-array-data v9, :array_2ca

    invoke-static {v0, v9}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v6, v0}, Lorg/json/JSONObject;->getJSONArray(Ljava/lang/String;)Lorg/json/JSONArray;

    move-result-object v0

    const/4 v6, 0x0

    :goto_cb
    invoke-virtual {v0}, Lorg/json/JSONArray;->length()I

    move-result v9

    if-ge v6, v9, :cond_235

    invoke-virtual {v0, v6}, Lorg/json/JSONArray;->getJSONObject(I)Lorg/json/JSONObject;

    move-result-object v9

    new-instance v10, Lorg/json/JSONObject;

    invoke-direct {v10}, Lorg/json/JSONObject;-><init>()V

    new-array v11, v8, [B

    fill-array-data v11, :array_2d2

    new-array v12, v3, [B

    fill-array-data v12, :array_2da

    invoke-static {v11, v12}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v11

    new-array v12, v3, [B

    fill-array-data v12, :array_2e2

    new-array v13, v3, [B

    fill-array-data v13, :array_2ea

    .line 9
    invoke-static {v12, v13, v9, v10, v11}, Lcom/github/catvod/spider/appysv2/o/a;->a([B[BLorg/json/JSONObject;Lorg/json/JSONObject;Ljava/lang/String;)V

    new-array v11, v3, [B

    .line 10
    fill-array-data v11, :array_2f2

    new-array v12, v3, [B

    fill-array-data v12, :array_2fa

    invoke-static {v11, v12}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v11

    new-array v12, v5, [B

    fill-array-data v12, :array_302

    new-array v13, v3, [B

    fill-array-data v13, :array_30a

    .line 11
    invoke-static {v12, v13, v9, v10, v11}, Lcom/github/catvod/spider/appysv2/o/a;->a([B[BLorg/json/JSONObject;Lorg/json/JSONObject;Ljava/lang/String;)V

    new-array v11, v7, [B

    .line 12
    fill-array-data v11, :array_312

    new-array v12, v3, [B

    fill-array-data v12, :array_31a

    invoke-static {v11, v12}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v11

    const/4 v12, 0x3

    new-array v12, v12, [B

    fill-array-data v12, :array_322

    new-array v13, v3, [B

    fill-array-data v13, :array_328

    .line 13
    invoke-static {v12, v13, v9, v10, v11}, Lcom/github/catvod/spider/appysv2/o/a;->a([B[BLorg/json/JSONObject;Lorg/json/JSONObject;Ljava/lang/String;)V

    new-array v11, v1, [B

    .line 14
    fill-array-data v11, :array_330

    new-array v12, v3, [B

    fill-array-data v12, :array_33a

    invoke-static {v11, v12}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v11

    new-array v12, v5, [B

    fill-array-data v12, :array_342

    new-array v13, v3, [B

    fill-array-data v13, :array_34a

    invoke-static {v12, v13}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v12

    invoke-virtual {v9, v12}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v10, v11, v9}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    invoke-virtual {v2, v10}, Lorg/json/JSONArray;->put(Ljava/lang/Object;)Lorg/json/JSONArray;

    add-int/lit8 v6, v6, 0x1

    goto/16 :goto_cb

    :cond_156
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    new-array v5, v5, [B

    fill-array-data v5, :array_352

    new-array v9, v3, [B

    fill-array-data v9, :array_35a

    invoke-static {v5, v9}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-direct {p0, v6, v5, v0}, Lcom/github/catvod/spider/AppYsV2;->a(Lorg/json/JSONObject;Ljava/lang/String;Ljava/util/ArrayList;)V

    invoke-virtual {v0}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v5

    if-eqz v5, :cond_183

    new-array v5, v3, [B

    fill-array-data v5, :array_362

    new-array v9, v3, [B

    fill-array-data v9, :array_36a

    invoke-static {v5, v9}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-direct {p0, v6, v5, v0}, Lcom/github/catvod/spider/AppYsV2;->a(Lorg/json/JSONObject;Ljava/lang/String;Ljava/util/ArrayList;)V

    :cond_183
    new-instance v5, Ljava/util/ArrayList;

    invoke-direct {v5}, Ljava/util/ArrayList;-><init>()V

    invoke-virtual {v0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :cond_18c
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v6

    if-eqz v6, :cond_235

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Lorg/json/JSONArray;

    const/4 v9, 0x0

    :goto_199
    invoke-virtual {v6}, Lorg/json/JSONArray;->length()I

    move-result v10

    if-ge v9, v10, :cond_18c

    invoke-virtual {v6, v9}, Lorg/json/JSONArray;->getJSONObject(I)Lorg/json/JSONObject;

    move-result-object v10

    new-array v11, v8, [B

    fill-array-data v11, :array_372

    new-array v12, v3, [B

    fill-array-data v12, :array_37a

    invoke-static {v11, v12}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v11

    invoke-virtual {v10, v11}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v11

    invoke-virtual {v5, v11}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result v12

    if-eqz v12, :cond_1bc

    goto :goto_231

    :cond_1bc
    invoke-virtual {v5, v11}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    new-instance v12, Lorg/json/JSONObject;

    invoke-direct {v12}, Lorg/json/JSONObject;-><init>()V

    new-array v13, v8, [B

    fill-array-data v13, :array_382

    new-array v14, v3, [B

    fill-array-data v14, :array_38a

    invoke-static {v13, v14}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v13

    invoke-virtual {v12, v13, v11}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    new-array v11, v3, [B

    fill-array-data v11, :array_392

    new-array v13, v3, [B

    fill-array-data v13, :array_39a

    invoke-static {v11, v13}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v11

    new-array v13, v3, [B

    fill-array-data v13, :array_3a2

    new-array v14, v3, [B

    fill-array-data v14, :array_3aa

    .line 15
    invoke-static {v13, v14, v10, v12, v11}, Lcom/github/catvod/spider/appysv2/o/a;->a([B[BLorg/json/JSONObject;Lorg/json/JSONObject;Ljava/lang/String;)V

    new-array v11, v7, [B

    .line 16
    fill-array-data v11, :array_3b2

    new-array v13, v3, [B

    fill-array-data v13, :array_3ba

    invoke-static {v11, v13}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v11

    new-array v13, v7, [B

    fill-array-data v13, :array_3c2

    new-array v14, v3, [B

    fill-array-data v14, :array_3ca

    .line 17
    invoke-static {v13, v14, v10, v12, v11}, Lcom/github/catvod/spider/appysv2/o/a;->a([B[BLorg/json/JSONObject;Lorg/json/JSONObject;Ljava/lang/String;)V

    new-array v11, v1, [B

    .line 18
    fill-array-data v11, :array_3d2

    new-array v13, v3, [B

    fill-array-data v13, :array_3dc

    invoke-static {v11, v13}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v11

    new-array v13, v1, [B

    fill-array-data v13, :array_3e4

    new-array v14, v3, [B

    fill-array-data v14, :array_3ee

    invoke-static {v13, v14}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v13

    invoke-virtual {v10, v13}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v12, v11, v10}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    invoke-virtual {v2, v12}, Lorg/json/JSONArray;->put(Ljava/lang/Object;)Lorg/json/JSONArray;

    :goto_231
    add-int/lit8 v9, v9, 0x1

    goto/16 :goto_199

    :cond_235
    new-instance v0, Lorg/json/JSONObject;

    invoke-direct {v0}, Lorg/json/JSONObject;-><init>()V

    new-array v1, v4, [B

    fill-array-data v1, :array_3f6

    new-array v3, v3, [B

    fill-array-data v3, :array_3fc

    invoke-static {v1, v3}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    invoke-virtual {v0}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0

    :array_250
    .array-data 1
        0x15t
        -0x7t
        0x13t
        0x3at
        -0x9t
        -0x80t
        0x6at
        0x7at
        0x15t
        -0x7t
        0xat
    .end array-data

    :array_25a
    .array-data 1
        0x74t
        -0x77t
        0x7at
        0x14t
        -0x79t
        -0x18t
        0x1at
        0x55t
    .end array-data

    :array_262
    .array-data 1
        -0x44t
        0x40t
        0x46t
        -0x62t
        -0x69t
    .end array-data

    nop

    :array_26a
    .array-data 1
        -0x3ct
        0x27t
        0x27t
        -0x12t
        -0x19t
        0x29t
        0x30t
        -0x52t
    .end array-data

    :array_272
    .array-data 1
        -0x1dt
        0x40t
        0x3ct
        0x43t
    .end array-data

    :array_278
    .array-data 1
        -0x33t
        0x36t
        0x53t
        0x27t
        0x60t
        0x70t
        -0x4ct
        0x37t
    .end array-data

    :array_280
    .array-data 1
        -0x3ct
        0x55t
        -0x21t
        0x15t
        -0x38t
        -0x5t
        0x2bt
        0x63t
        -0x79t
        0x4ft
    .end array-data

    nop

    :array_28a
    .array-data 1
        -0x15t
        0x23t
        -0x50t
        0x71t
        -0x68t
        -0x6dt
        0x49t
        0x22t
    .end array-data

    :array_292
    .array-data 1
        -0x80t
        0x2t
        0x71t
        -0x7at
        0x38t
        -0x48t
        -0x64t
        -0x3ft
        -0x73t
        0x9t
        0x7at
        -0x24t
        0x34t
        -0x78t
        -0x7ft
        -0x33t
        -0x79t
        0x51t
    .end array-data

    nop

    :array_2a0
    .array-data 1
        -0x17t
        0x6ct
        0x15t
        -0x1dt
        0x40t
        -0x19t
        -0x16t
        -0x58t
    .end array-data

    :array_2a8
    .array-data 1
        0x2et
        -0x5at
        -0x65t
        -0x7t
        0x31t
        0x3t
        0x53t
        0x67t
        0x24t
        -0x54t
        -0x30t
        -0x5ft
        0x72t
        0x44t
        0x51t
        0x63t
        0x22t
        -0xct
        -0x35t
        -0x1ct
        0x2dt
        0x55t
        0x46t
        0x3bt
        0x65t
        -0x46t
        -0x67t
        -0xft
        0x26t
        0x51t
        0x1et
    .end array-data

    :array_2bc
    .array-data 1
        0x43t
        -0x37t
        -0x13t
        -0x70t
        0x54t
        0x25t
        0x23t
        0x6t
    .end array-data

    :array_2c4
    .array-data 1
        -0x1bt
        0x1bt
        -0x5at
        -0x6et
    .end array-data

    :array_2ca
    .array-data 1
        -0x7ft
        0x7at
        -0x2et
        -0xdt
        0x3et
        -0x16t
        -0x22t
        -0x1et
    .end array-data

    :array_2d2
    .array-data 1
        -0x41t
        -0x56t
        0x27t
        -0x42t
        -0x67t
        0x54t
    .end array-data

    nop

    :array_2da
    .array-data 1
        -0x37t
        -0x3bt
        0x43t
        -0x1ft
        -0x10t
        0x30t
        0x55t
        -0x15t
    .end array-data

    :array_2e2
    .array-data 1
        -0x7ft
        0x23t
        -0x61t
        -0x2et
        -0x68t
        0x49t
        -0x3ct
        0x15t
    .end array-data

    :array_2ea
    .array-data 1
        -0x11t
        0x46t
        -0x19t
        -0x5at
        -0xct
        0x20t
        -0x56t
        0x7et
    .end array-data

    :array_2f2
    .array-data 1
        -0x4ft
        -0x5t
        0x72t
        0x32t
        -0x70t
        0x3t
        -0x47t
        0x5ct
    .end array-data

    :array_2fa
    .array-data 1
        -0x39t
        -0x6ct
        0x16t
        0x6dt
        -0x2t
        0x62t
        -0x2ct
        0x39t
    .end array-data

    :array_302
    .array-data 1
        0x28t
        -0x45t
        0x1et
        -0x3dt
        0x12t
    .end array-data

    nop

    :array_30a
    .array-data 1
        0x5ct
        -0x2et
        0x6at
        -0x51t
        0x77t
        -0x23t
        -0x48t
        -0x7ft
    .end array-data

    :array_312
    .array-data 1
        0x50t
        0xdt
        -0x32t
        0x52t
        0x13t
        -0x80t
        -0x62t
    .end array-data

    :array_31a
    .array-data 1
        0x26t
        0x62t
        -0x56t
        0xdt
        0x63t
        -0x17t
        -0x3t
        -0x73t
    .end array-data

    :array_322
    .array-data 1
        0xat
        -0x37t
        0x9t
    .end array-data

    :array_328
    .array-data 1
        0x7at
        -0x60t
        0x6at
        0x25t
        0x64t
        0x34t
        0x2ct
        -0x13t
    .end array-data

    :array_330
    .array-data 1
        0x1dt
        0x16t
        0x54t
        0x69t
        -0x46t
        -0x10t
        0x5dt
        0x79t
        0x19t
        0x12t
        0x43t
    .end array-data

    :array_33a
    .array-data 1
        0x6bt
        0x79t
        0x30t
        0x36t
        -0x38t
        -0x6bt
        0x30t
        0x18t
    .end array-data

    :array_342
    .array-data 1
        0x8t
        -0x25t
        -0x63t
        -0x11t
        -0x38t
    .end array-data

    nop

    :array_34a
    .array-data 1
        0x7bt
        -0x51t
        -0x4t
        -0x65t
        -0x53t
        -0x1et
        -0x75t
        -0x44t
    .end array-data

    :array_352
    .array-data 1
        -0x32t
        -0x6et
        -0x6et
        -0x72t
        -0x61t
    .end array-data

    nop

    :array_35a
    .array-data 1
        -0x48t
        -0x2t
        -0x5t
        -0x3t
        -0x15t
        0x14t
        0x72t
        -0x4et
    .end array-data

    :array_362
    .array-data 1
        0x4at
        -0x38t
        0x16t
        -0x2et
        -0x37t
        -0x18t
        0xdt
        0x7bt
    .end array-data

    :array_36a
    .array-data 1
        0x3ct
        -0x59t
        0x72t
        -0x73t
        -0x5bt
        -0x7ft
        0x7et
        0xft
    .end array-data

    :array_372
    .array-data 1
        -0x1at
        0x4at
        -0x31t
        -0x80t
        -0x7ct
        0x8t
    .end array-data

    nop

    :array_37a
    .array-data 1
        -0x70t
        0x25t
        -0x55t
        -0x21t
        -0x13t
        0x6ct
        -0x4dt
        0x45t
    .end array-data

    :array_382
    .array-data 1
        -0x16t
        -0x2t
        0x9t
        -0x5bt
        -0x7dt
        0xbt
    .end array-data

    nop

    :array_38a
    .array-data 1
        -0x64t
        -0x6ft
        0x6dt
        -0x6t
        -0x16t
        0x6ft
        -0x66t
        0x41t
    .end array-data

    :array_392
    .array-data 1
        -0x1et
        0x45t
        0x1at
        -0x2at
        -0x1ct
        0x54t
        0x50t
        0x65t
    .end array-data

    :array_39a
    .array-data 1
        -0x6ct
        0x2at
        0x7et
        -0x77t
        -0x76t
        0x35t
        0x3dt
        0x0t
    .end array-data

    :array_3a2
    .array-data 1
        0x5t
        -0x1ft
        -0x9t
        0x48t
        0x1bt
        -0xct
        0x2ft
        0x2et
    .end array-data

    :array_3aa
    .array-data 1
        0x73t
        -0x72t
        -0x6dt
        0x17t
        0x75t
        -0x6bt
        0x42t
        0x4bt
    .end array-data

    :array_3b2
    .array-data 1
        0x29t
        0x77t
        -0x3ft
        -0x38t
        0x6ct
        -0x24t
        -0x20t
    .end array-data

    :array_3ba
    .array-data 1
        0x5ft
        0x18t
        -0x5bt
        -0x69t
        0x1ct
        -0x4bt
        -0x7dt
        0xft
    .end array-data

    :array_3c2
    .array-data 1
        -0x37t
        0x3bt
        0x71t
        0x7t
        0x1dt
        0x4bt
        -0x40t
    .end array-data

    :array_3ca
    .array-data 1
        -0x41t
        0x54t
        0x15t
        0x58t
        0x6dt
        0x22t
        -0x5dt
        -0x13t
    .end array-data

    :array_3d2
    .array-data 1
        0x27t
        0x18t
        0x13t
        0x28t
        -0x76t
        -0x77t
        -0x6at
        0x49t
        0x23t
        0x1ct
        0x4t
    .end array-data

    :array_3dc
    .array-data 1
        0x51t
        0x77t
        0x77t
        0x77t
        -0x8t
        -0x14t
        -0x5t
        0x28t
    .end array-data

    :array_3e4
    .array-data 1
        -0x5ft
        0x46t
        -0x28t
        -0x47t
        -0x26t
        -0x4et
        0x4ft
        0x6t
        -0x5bt
        0x42t
        -0x31t
    .end array-data

    :array_3ee
    .array-data 1
        -0x29t
        0x29t
        -0x44t
        -0x1at
        -0x58t
        -0x29t
        0x22t
        0x67t
    .end array-data

    :array_3f6
    .array-data 1
        -0x62t
        0x5t
        -0x58t
        -0x39t
    .end array-data

    :array_3fc
    .array-data 1
        -0xet
        0x6ct
        -0x25t
        -0x4dt
        0x23t
        -0x30t
        -0x6at
        -0x44t
    .end array-data
.end method

.method public init(Landroid/content/Context;Ljava/lang/String;)V
    .registers 9

    invoke-super {p0, p1, p2}, Lcom/github/catvod/crawler/Spider;->init(Landroid/content/Context;Ljava/lang/String;)V

    const/4 p1, 0x3

    :try_start_4
    new-array v0, p1, [B

    const/16 v1, 0x40

    const/4 v2, 0x0

    aput-byte v1, v0, v2

    const/16 v1, -0x5c

    const/4 v3, 0x1

    aput-byte v1, v0, v3

    const/16 v1, -0x9

    const/4 v4, 0x2

    aput-byte v1, v0, v4

    const/16 v1, 0x8

    new-array v1, v1, [B

    const/16 v5, 0x63

    aput-byte v5, v1, v2

    const/16 v2, -0x79

    aput-byte v2, v1, v3

    const/16 v2, -0x2c

    aput-byte v2, v1, v4

    const/16 v2, -0x13

    aput-byte v2, v1, p1

    const/4 v2, 0x4

    const/16 v3, 0x6e

    aput-byte v3, v1, v2

    const/4 v2, 0x5

    const/16 v3, 0x6a

    aput-byte v3, v1, v2

    const/4 v2, 0x6

    aput-byte p1, v1, v2

    const/4 p1, 0x7

    const/16 v2, 0x56

    aput-byte v2, v1, p1

    invoke-static {v0, v1}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p2, p1}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object p1

    iput-object p1, p0, Lcom/github/catvod/spider/AppYsV2;->b:[Ljava/lang/String;
    :try_end_45
    .catch Ljava/lang/Exception; {:try_start_4 .. :try_end_45} :catch_45

    :catch_45
    return-void
.end method

.method public isVideoFormat(Ljava/lang/String;)Z
    .registers 2

    invoke-static {p1}, Lcom/github/catvod/spider/appysv2/p/C;->o(Ljava/lang/String;)Z

    move-result p1

    return p1
.end method

.method public manualVideoCheck()Z
    .registers 2

    const/4 v0, 0x1

    return v0
.end method

.method public playerContent(Ljava/lang/String;Ljava/lang/String;Ljava/util/List;)Ljava/lang/String;
    .registers 20
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;)",
            "Ljava/lang/String;"
        }
    .end annotation

    move-object/from16 v0, p1

    move-object/from16 v1, p2

    const/4 v2, 0x6

    new-array v3, v2, [B

    fill-array-data v3, :array_216

    const/16 v4, 0x8

    new-array v5, v4, [B

    fill-array-data v5, :array_21e

    invoke-static {v3, v5}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v0, v3}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v3

    const-string v5, ""

    const/4 v6, 0x7

    const/4 v7, 0x3

    const/4 v8, 0x5

    const/4 v9, 0x0

    if-eqz v3, :cond_64

    invoke-static/range {p2 .. p2}, Lcom/github/catvod/spider/appysv2/p/C;->o(Ljava/lang/String;)Z

    move-result v3

    if-eqz v3, :cond_64

    new-instance v0, Lorg/json/JSONObject;

    invoke-direct {v0}, Lorg/json/JSONObject;-><init>()V

    new-array v2, v8, [B

    fill-array-data v2, :array_226

    new-array v3, v4, [B

    fill-array-data v3, :array_22e

    invoke-static {v2, v3}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2, v9}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    new-array v2, v6, [B

    fill-array-data v2, :array_236

    new-array v3, v4, [B

    fill-array-data v3, :array_23e

    invoke-static {v2, v3}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2, v5}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    new-array v2, v7, [B

    fill-array-data v2, :array_246

    new-array v3, v4, [B

    fill-array-data v3, :array_24c

    invoke-static {v2, v3}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v2

    :goto_5c
    invoke-virtual {v0, v2, v1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    invoke-virtual {v0}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0

    :cond_64
    move-object/from16 v3, p0

    iget-object v10, v3, Lcom/github/catvod/spider/AppYsV2;->a:Ljava/util/HashMap;

    invoke-virtual {v10, v0}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/util/ArrayList;

    if-nez v0, :cond_75

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    :cond_75
    invoke-virtual {v0}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v10

    const/4 v11, 0x1

    if-nez v10, :cond_190

    .line 1
    invoke-virtual {v0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v0

    move-object v10, v5

    :goto_81
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v12

    const/4 v13, 0x0

    if-eqz v12, :cond_14b

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v12

    check-cast v12, Ljava/lang/String;

    invoke-virtual {v12}, Ljava/lang/String;->isEmpty()Z

    move-result v14

    if-nez v14, :cond_147

    const/4 v14, 0x4

    new-array v14, v14, [B

    fill-array-data v14, :array_254

    new-array v15, v4, [B

    fill-array-data v15, :array_25a

    invoke-static {v14, v15}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v14

    invoke-virtual {v12, v14}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v14

    if-eqz v14, :cond_ab

    goto/16 :goto_147

    :cond_ab
    new-instance v14, Ljava/lang/StringBuilder;

    invoke-direct {v14}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v14, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v14, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v14}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v14

    .line 2
    invoke-static {v14, v13}, Lcom/github/catvod/spider/appysv2/n/c;->m(Ljava/lang/String;Ljava/util/Map;)Ljava/lang/String;

    move-result-object v14

    .line 3
    :try_start_be
    invoke-static {v1, v14}, Lcom/github/catvod/spider/AppYsV2;->jsonParse(Ljava/lang/String;Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v13
    :try_end_c2
    .catchall {:try_start_be .. :try_end_c2} :catchall_c3

    goto :goto_c4

    :catchall_c3
    nop

    :goto_c4
    if-eqz v13, :cond_117

    new-array v15, v7, [B

    fill-array-data v15, :array_262

    new-array v9, v4, [B

    fill-array-data v9, :array_268

    invoke-static {v15, v9}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v13, v9}, Lorg/json/JSONObject;->has(Ljava/lang/String;)Z

    move-result v9

    if-eqz v9, :cond_117

    new-array v9, v2, [B

    fill-array-data v9, :array_270

    new-array v15, v4, [B

    fill-array-data v15, :array_278

    invoke-static {v9, v15}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v13, v9}, Lorg/json/JSONObject;->has(Ljava/lang/String;)Z

    move-result v9

    if-eqz v9, :cond_117

    new-array v0, v2, [B

    fill-array-data v0, :array_280

    new-array v9, v4, [B

    fill-array-data v9, :array_288

    invoke-static {v0, v9}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v0

    new-array v2, v2, [B

    fill-array-data v2, :array_290

    new-array v9, v4, [B

    fill-array-data v9, :array_298

    invoke-static {v2, v9}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v13, v2}, Lorg/json/JSONObject;->getJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v2

    invoke-virtual {v2}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v13, v0, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    goto/16 :goto_189

    :cond_117
    new-array v9, v8, [B

    fill-array-data v9, :array_2a0

    new-array v13, v4, [B

    fill-array-data v13, :array_2a8

    invoke-static {v9, v13}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v14, v9}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v9

    if-eqz v9, :cond_147

    sget-object v9, Lcom/github/catvod/spider/AppYsV2;->f:[Ljava/util/regex/Pattern;

    array-length v13, v9

    const/4 v15, 0x0

    :goto_12f
    if-ge v15, v13, :cond_143

    aget-object v2, v9, v15

    invoke-virtual {v2, v14}, Ljava/util/regex/Pattern;->matcher(Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;

    move-result-object v2

    invoke-virtual {v2}, Ljava/util/regex/Matcher;->find()Z

    move-result v2

    if-eqz v2, :cond_13f

    const/4 v2, 0x1

    goto :goto_144

    :cond_13f
    add-int/lit8 v15, v15, 0x1

    const/4 v2, 0x6

    goto :goto_12f

    :cond_143
    const/4 v2, 0x0

    :goto_144
    if-eqz v2, :cond_147

    move-object v10, v12

    :cond_147
    :goto_147
    const/4 v2, 0x6

    const/4 v9, 0x0

    goto/16 :goto_81

    :cond_14b
    invoke-virtual {v10}, Ljava/lang/String;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_189

    new-instance v13, Lorg/json/JSONObject;

    invoke-direct {v13}, Lorg/json/JSONObject;-><init>()V

    new-array v0, v8, [B

    fill-array-data v0, :array_2b0

    new-array v2, v4, [B

    fill-array-data v2, :array_2b8

    invoke-static {v0, v2}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v13, v0, v11}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    new-array v0, v6, [B

    fill-array-data v0, :array_2c0

    new-array v2, v4, [B

    fill-array-data v2, :array_2c8

    invoke-static {v0, v2}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v13, v0, v10}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    new-array v0, v7, [B

    fill-array-data v0, :array_2d0

    new-array v2, v4, [B

    fill-array-data v2, :array_2d6

    invoke-static {v0, v2}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v13, v0, v1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    :cond_189
    :goto_189
    if-eqz v13, :cond_190

    .line 4
    invoke-virtual {v13}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0

    :cond_190
    invoke-static/range {p2 .. p2}, Lcom/github/catvod/spider/appysv2/p/C;->o(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_1ce

    new-instance v0, Lorg/json/JSONObject;

    invoke-direct {v0}, Lorg/json/JSONObject;-><init>()V

    new-array v2, v8, [B

    fill-array-data v2, :array_2de

    new-array v8, v4, [B

    fill-array-data v8, :array_2e6

    invoke-static {v2, v8}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v2

    const/4 v8, 0x0

    invoke-virtual {v0, v2, v8}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    new-array v2, v6, [B

    fill-array-data v2, :array_2ee

    new-array v6, v4, [B

    fill-array-data v6, :array_2f6

    invoke-static {v2, v6}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2, v5}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    new-array v2, v7, [B

    fill-array-data v2, :array_2fe

    new-array v4, v4, [B

    fill-array-data v4, :array_304

    invoke-static {v2, v4}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v2

    goto/16 :goto_5c

    :cond_1ce
    new-instance v0, Lorg/json/JSONObject;

    invoke-direct {v0}, Lorg/json/JSONObject;-><init>()V

    new-array v2, v8, [B

    fill-array-data v2, :array_30c

    new-array v5, v4, [B

    fill-array-data v5, :array_314

    invoke-static {v2, v5}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2, v11}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    const/4 v2, 0x2

    new-array v2, v2, [B

    fill-array-data v2, :array_31c

    new-array v5, v4, [B

    fill-array-data v5, :array_322

    invoke-static {v2, v5}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v2

    new-array v5, v11, [B

    const/16 v6, -0x1d

    const/4 v8, 0x0

    aput-byte v6, v5, v8

    new-array v6, v4, [B

    fill-array-data v6, :array_32a

    invoke-static {v5, v6}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v0, v2, v5}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    new-array v2, v7, [B

    fill-array-data v2, :array_332

    new-array v4, v4, [B

    fill-array-data v4, :array_338

    invoke-static {v2, v4}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v2

    goto/16 :goto_5c

    :array_216
    .array-data 1
        0x13t
        0xbt
        0x12t
        -0x7ct
        0x41t
        0x53t
    .end array-data

    nop

    :array_21e
    .array-data 1
        0x75t
        0x6at
        0x7ct
        -0xbt
        0x28t
        0x36t
        -0x64t
        0x27t
    .end array-data

    :array_226
    .array-data 1
        0x57t
        -0x2ft
        -0x5dt
        0x29t
        0x30t
    .end array-data

    nop

    :array_22e
    .array-data 1
        0x27t
        -0x50t
        -0x2ft
        0x5at
        0x55t
        -0x10t
        -0x79t
        -0x6at
    .end array-data

    :array_236
    .array-data 1
        -0x5dt
        -0x68t
        -0x52t
        0x15t
        0x76t
        -0x53t
        -0x6ft
    .end array-data

    :array_23e
    .array-data 1
        -0x2dt
        -0xct
        -0x31t
        0x6ct
        0x23t
        -0x21t
        -0x3t
        -0x13t
    .end array-data

    :array_246
    .array-data 1
        -0x9t
        -0x5t
        0x14t
    .end array-data

    :array_24c
    .array-data 1
        -0x7et
        -0x77t
        0x78t
        0x41t
        -0xct
        0x4at
        -0x39t
        0x7et
    .end array-data

    :array_254
    .array-data 1
        0x53t
        -0x6t
        -0x69t
        -0x5et
    .end array-data

    :array_25a
    .array-data 1
        0x3dt
        -0x71t
        -0x5t
        -0x32t
        0x4ft
        -0x4at
        -0x72t
        0x79t
    .end array-data

    :array_262
    .array-data 1
        0x20t
        -0x78t
        0x62t
    .end array-data

    :array_268
    .array-data 1
        0x55t
        -0x6t
        0xet
        -0x3ct
        0x7at
        -0x3at
        -0x73t
        0x10t
    .end array-data

    :array_270
    .array-data 1
        -0x6at
        -0xet
        0x37t
        -0x27t
        -0x74t
        0x19t
    .end array-data

    nop

    :array_278
    .array-data 1
        -0x2t
        -0x69t
        0x56t
        -0x43t
        -0x17t
        0x6bt
        0x5at
        0x6bt
    .end array-data

    :array_280
    .array-data 1
        0x22t
        -0x43t
        -0x6at
        0x40t
        0x75t
        0x49t
    .end array-data

    nop

    :array_288
    .array-data 1
        0x4at
        -0x28t
        -0x9t
        0x24t
        0x10t
        0x3bt
        0x2ct
        -0xat
    .end array-data

    :array_290
    .array-data 1
        0x57t
        -0x38t
        -0x21t
        0x18t
        -0x6at
        0xct
    .end array-data

    nop

    :array_298
    .array-data 1
        0x3ft
        -0x53t
        -0x42t
        0x7ct
        -0xdt
        0x7et
        -0x1et
        0x52t
    .end array-data

    :array_2a0
    .array-data 1
        0x31t
        0x36t
        -0x33t
        0x35t
        0x7et
    .end array-data

    nop

    :array_2a8
    .array-data 1
        0xdt
        0x5et
        -0x47t
        0x58t
        0x12t
        -0xet
        -0x49t
        -0x3t
    .end array-data

    :array_2b0
    .array-data 1
        -0x3t
        0x1bt
        -0x78t
        -0x8t
        -0x3at
    .end array-data

    nop

    :array_2b8
    .array-data 1
        -0x73t
        0x7at
        -0x6t
        -0x75t
        -0x5dt
        0x16t
        0x69t
        0x1et
    .end array-data

    :array_2c0
    .array-data 1
        0x1at
        0x20t
        -0x57t
        0x6at
        0x73t
        0x50t
        -0x29t
    .end array-data

    :array_2c8
    .array-data 1
        0x6at
        0x4ct
        -0x38t
        0x13t
        0x26t
        0x22t
        -0x45t
        -0x4et
    .end array-data

    :array_2d0
    .array-data 1
        -0x2t
        -0x2et
        -0x2dt
    .end array-data

    :array_2d6
    .array-data 1
        -0x75t
        -0x60t
        -0x41t
        0x5ct
        -0x75t
        -0x62t
        -0x74t
        -0x7at
    .end array-data

    :array_2de
    .array-data 1
        -0xbt
        -0x80t
        0x8t
        -0x4bt
        0x1t
    .end array-data

    nop

    :array_2e6
    .array-data 1
        -0x7bt
        -0x1ft
        0x7at
        -0x3at
        0x64t
        -0x5t
        0x49t
        -0x47t
    .end array-data

    :array_2ee
    .array-data 1
        -0x7ft
        0x58t
        0x74t
        -0x53t
        0x7ft
        0x55t
        -0x7t
    .end array-data

    :array_2f6
    .array-data 1
        -0xft
        0x34t
        0x15t
        -0x2ct
        0x2at
        0x27t
        -0x6bt
        0x64t
    .end array-data

    :array_2fe
    .array-data 1
        -0x36t
        0x5ct
        -0x43t
    .end array-data

    :array_304
    .array-data 1
        -0x41t
        0x2et
        -0x2ft
        -0x1ft
        0x2at
        -0x26t
        -0x4dt
        -0x4at
    .end array-data

    :array_30c
    .array-data 1
        -0x79t
        -0x14t
        0x6ft
        -0x41t
        -0x9t
    .end array-data

    nop

    :array_314
    .array-data 1
        -0x9t
        -0x73t
        0x1dt
        -0x34t
        -0x6et
        -0x38t
        0xft
        0x3ft
    .end array-data

    :array_31c
    .array-data 1
        -0x62t
        0x7et
    .end array-data

    nop

    :array_322
    .array-data 1
        -0xct
        0x6t
        -0x34t
        0x73t
        0x8t
        -0x42t
        0x3bt
        -0x80t
    .end array-data

    :array_32a
    .array-data 1
        -0x2et
        -0x61t
        -0x29t
        0x1ft
        -0x6t
        -0x46t
        -0x11t
        0x45t
    .end array-data

    :array_332
    .array-data 1
        0x16t
        0x77t
        0x3dt
    .end array-data

    :array_338
    .array-data 1
        0x63t
        0x5t
        0x51t
        -0x47t
        0x14t
        0x36t
        0x17t
        -0x63t
    .end array-data
.end method

.method public searchContent(Ljava/lang/String;Z)Ljava/lang/String;
    .registers 14

    invoke-direct {p0}, Lcom/github/catvod/spider/AppYsV2;->c()Ljava/lang/String;

    move-result-object p2

    invoke-static {p1}, Ljava/net/URLEncoder;->encode(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    invoke-direct {p0, p2, p1}, Lcom/github/catvod/spider/AppYsV2;->i(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    invoke-direct {p0, p1}, Lcom/github/catvod/spider/AppYsV2;->h(Ljava/lang/String;)Ljava/util/HashMap;

    move-result-object p2

    invoke-static {p1, p2}, Lcom/github/catvod/spider/appysv2/n/c;->m(Ljava/lang/String;Ljava/util/Map;)Ljava/lang/String;

    move-result-object p1

    new-instance p2, Lorg/json/JSONObject;

    invoke-direct {p2, p1}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    new-instance p1, Lorg/json/JSONArray;

    invoke-direct {p1}, Lorg/json/JSONArray;-><init>()V

    const/4 v0, 0x4

    new-array v1, v0, [B

    fill-array-data v1, :array_268

    const/16 v2, 0x8

    new-array v3, v2, [B

    fill-array-data v3, :array_26e

    invoke-static {v1, v3}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {p2, v1}, Lorg/json/JSONObject;->has(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_5b

    new-array v1, v0, [B

    fill-array-data v1, :array_276

    new-array v3, v2, [B

    fill-array-data v3, :array_27c

    invoke-static {v1, v3}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {p2, v1}, Lorg/json/JSONObject;->get(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v1

    instance-of v1, v1, Lorg/json/JSONArray;

    if-eqz v1, :cond_5b

    new-array v1, v0, [B

    fill-array-data v1, :array_284

    new-array v3, v2, [B

    fill-array-data v3, :array_28a

    invoke-static {v1, v3}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v1

    goto/16 :goto_12c

    :cond_5b
    new-array v1, v0, [B

    fill-array-data v1, :array_292

    new-array v3, v2, [B

    fill-array-data v3, :array_298

    invoke-static {v1, v3}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {p2, v1}, Lorg/json/JSONObject;->has(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_f4

    new-array v1, v0, [B

    fill-array-data v1, :array_2a0

    new-array v3, v2, [B

    fill-array-data v3, :array_2a6

    invoke-static {v1, v3}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {p2, v1}, Lorg/json/JSONObject;->get(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v1

    instance-of v1, v1, Lorg/json/JSONObject;

    if-eqz v1, :cond_f4

    new-array v1, v0, [B

    fill-array-data v1, :array_2ae

    new-array v3, v2, [B

    fill-array-data v3, :array_2b4

    invoke-static {v1, v3}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {p2, v1}, Lorg/json/JSONObject;->getJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v1

    new-array v3, v0, [B

    fill-array-data v3, :array_2bc

    new-array v4, v2, [B

    fill-array-data v4, :array_2c2

    invoke-static {v3, v4}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v1, v3}, Lorg/json/JSONObject;->has(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_f4

    new-array v1, v0, [B

    fill-array-data v1, :array_2ca

    new-array v3, v2, [B

    fill-array-data v3, :array_2d0

    invoke-static {v1, v3}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {p2, v1}, Lorg/json/JSONObject;->getJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v1

    new-array v3, v0, [B

    fill-array-data v3, :array_2d8

    new-array v4, v2, [B

    fill-array-data v4, :array_2de

    invoke-static {v3, v4}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v1, v3}, Lorg/json/JSONObject;->get(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v1

    instance-of v1, v1, Lorg/json/JSONArray;

    if-eqz v1, :cond_f4

    new-array v1, v0, [B

    fill-array-data v1, :array_2e6

    new-array v3, v2, [B

    fill-array-data v3, :array_2ec

    invoke-static {v1, v3}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {p2, v1}, Lorg/json/JSONObject;->getJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object p2

    new-array v1, v0, [B

    fill-array-data v1, :array_2f4

    new-array v3, v2, [B

    fill-array-data v3, :array_2fa

    invoke-static {v1, v3}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v1

    goto :goto_12c

    :cond_f4
    new-array v1, v0, [B

    fill-array-data v1, :array_302

    new-array v3, v2, [B

    fill-array-data v3, :array_308

    invoke-static {v1, v3}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {p2, v1}, Lorg/json/JSONObject;->has(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_131

    new-array v1, v0, [B

    fill-array-data v1, :array_310

    new-array v3, v2, [B

    fill-array-data v3, :array_316

    invoke-static {v1, v3}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {p2, v1}, Lorg/json/JSONObject;->get(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v1

    instance-of v1, v1, Lorg/json/JSONArray;

    if-eqz v1, :cond_131

    new-array v1, v0, [B

    fill-array-data v1, :array_31e

    new-array v3, v2, [B

    fill-array-data v3, :array_324

    invoke-static {v1, v3}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v1

    :goto_12c
    invoke-virtual {p2, v1}, Lorg/json/JSONObject;->getJSONArray(Ljava/lang/String;)Lorg/json/JSONArray;

    move-result-object p2

    goto :goto_132

    :cond_131
    const/4 p2, 0x0

    :goto_132
    if-eqz p2, :cond_24c

    const/4 v1, 0x0

    :goto_135
    invoke-virtual {p2}, Lorg/json/JSONArray;->length()I

    move-result v3

    if-ge v1, v3, :cond_24c

    invoke-virtual {p2, v1}, Lorg/json/JSONArray;->getJSONObject(I)Lorg/json/JSONObject;

    move-result-object v3

    const/4 v4, 0x6

    new-array v5, v4, [B

    fill-array-data v5, :array_32c

    new-array v6, v2, [B

    fill-array-data v6, :array_334

    invoke-static {v5, v6}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v3, v5}, Lorg/json/JSONObject;->has(Ljava/lang/String;)Z

    move-result v5

    const/16 v6, 0xb

    const/4 v7, 0x7

    if-eqz v5, :cond_1ca

    new-instance v5, Lorg/json/JSONObject;

    invoke-direct {v5}, Lorg/json/JSONObject;-><init>()V

    new-array v8, v4, [B

    fill-array-data v8, :array_33c

    new-array v9, v2, [B

    fill-array-data v9, :array_344

    invoke-static {v8, v9}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v8

    new-array v4, v4, [B

    fill-array-data v4, :array_34c

    new-array v9, v2, [B

    fill-array-data v9, :array_354

    .line 1
    invoke-static {v4, v9, v3, v5, v8}, Lcom/github/catvod/spider/appysv2/o/a;->a([B[BLorg/json/JSONObject;Lorg/json/JSONObject;Ljava/lang/String;)V

    new-array v4, v2, [B

    .line 2
    fill-array-data v4, :array_35c

    new-array v8, v2, [B

    fill-array-data v8, :array_364

    invoke-static {v4, v8}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v4

    new-array v8, v2, [B

    fill-array-data v8, :array_36c

    new-array v9, v2, [B

    fill-array-data v9, :array_374

    .line 3
    invoke-static {v8, v9, v3, v5, v4}, Lcom/github/catvod/spider/appysv2/o/a;->a([B[BLorg/json/JSONObject;Lorg/json/JSONObject;Ljava/lang/String;)V

    new-array v4, v7, [B

    .line 4
    fill-array-data v4, :array_37c

    new-array v8, v2, [B

    fill-array-data v8, :array_384

    invoke-static {v4, v8}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v4

    new-array v7, v7, [B

    fill-array-data v7, :array_38c

    new-array v8, v2, [B

    fill-array-data v8, :array_394

    .line 5
    invoke-static {v7, v8, v3, v5, v4}, Lcom/github/catvod/spider/appysv2/o/a;->a([B[BLorg/json/JSONObject;Lorg/json/JSONObject;Ljava/lang/String;)V

    new-array v4, v6, [B

    .line 6
    fill-array-data v4, :array_39c

    new-array v7, v2, [B

    fill-array-data v7, :array_3a6

    invoke-static {v4, v7}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v4

    new-array v6, v6, [B

    fill-array-data v6, :array_3ae

    new-array v7, v2, [B

    fill-array-data v7, :array_3b8

    invoke-static {v6, v7}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v6

    goto :goto_23e

    :cond_1ca
    new-instance v5, Lorg/json/JSONObject;

    invoke-direct {v5}, Lorg/json/JSONObject;-><init>()V

    new-array v4, v4, [B

    fill-array-data v4, :array_3c0

    new-array v8, v2, [B

    fill-array-data v8, :array_3c8

    invoke-static {v4, v8}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v4

    new-array v8, v2, [B

    fill-array-data v8, :array_3d0

    new-array v9, v2, [B

    fill-array-data v9, :array_3d8

    .line 7
    invoke-static {v8, v9, v3, v5, v4}, Lcom/github/catvod/spider/appysv2/o/a;->a([B[BLorg/json/JSONObject;Lorg/json/JSONObject;Ljava/lang/String;)V

    new-array v4, v2, [B

    .line 8
    fill-array-data v4, :array_3e0

    new-array v8, v2, [B

    fill-array-data v8, :array_3e8

    invoke-static {v4, v8}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v4

    const/4 v8, 0x5

    new-array v9, v8, [B

    fill-array-data v9, :array_3f0

    new-array v10, v2, [B

    fill-array-data v10, :array_3f8

    .line 9
    invoke-static {v9, v10, v3, v5, v4}, Lcom/github/catvod/spider/appysv2/o/a;->a([B[BLorg/json/JSONObject;Lorg/json/JSONObject;Ljava/lang/String;)V

    new-array v4, v7, [B

    .line 10
    fill-array-data v4, :array_400

    new-array v7, v2, [B

    fill-array-data v7, :array_408

    invoke-static {v4, v7}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v4

    const/4 v7, 0x3

    new-array v7, v7, [B

    fill-array-data v7, :array_410

    new-array v9, v2, [B

    fill-array-data v9, :array_416

    .line 11
    invoke-static {v7, v9, v3, v5, v4}, Lcom/github/catvod/spider/appysv2/o/a;->a([B[BLorg/json/JSONObject;Lorg/json/JSONObject;Ljava/lang/String;)V

    new-array v4, v6, [B

    .line 12
    fill-array-data v4, :array_41e

    new-array v6, v2, [B

    fill-array-data v6, :array_428

    invoke-static {v4, v6}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v4

    new-array v6, v8, [B

    fill-array-data v6, :array_430

    new-array v7, v2, [B

    fill-array-data v7, :array_438

    invoke-static {v6, v7}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v6

    :goto_23e
    invoke-virtual {v3, v6}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v5, v4, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    invoke-virtual {p1, v5}, Lorg/json/JSONArray;->put(Ljava/lang/Object;)Lorg/json/JSONArray;

    add-int/lit8 v1, v1, 0x1

    goto/16 :goto_135

    :cond_24c
    new-instance p2, Lorg/json/JSONObject;

    invoke-direct {p2}, Lorg/json/JSONObject;-><init>()V

    new-array v0, v0, [B

    fill-array-data v0, :array_440

    new-array v1, v2, [B

    fill-array-data v1, :array_446

    invoke-static {v0, v1}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p2, v0, p1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    invoke-virtual {p2}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object p1

    return-object p1

    nop

    :array_268
    .array-data 1
        -0x70t
        -0x6dt
        0x3bt
        -0x25t
    .end array-data

    :array_26e
    .array-data 1
        -0x4t
        -0x6t
        0x48t
        -0x51t
        0x4ft
        -0x5et
        0x5et
        -0x46t
    .end array-data

    :array_276
    .array-data 1
        0x5bt
        0x1at
        -0xat
        0x15t
    .end array-data

    :array_27c
    .array-data 1
        0x37t
        0x73t
        -0x7bt
        0x61t
        -0x7dt
        0x18t
        -0x3at
        0x11t
    .end array-data

    :array_284
    .array-data 1
        0xct
        -0x73t
        0x44t
        0x6at
    .end array-data

    :array_28a
    .array-data 1
        0x60t
        -0x1ct
        0x37t
        0x1et
        0x49t
        0x26t
        0x6dt
        0x4at
    .end array-data

    :array_292
    .array-data 1
        -0x28t
        -0x69t
        0x6ct
        -0xat
    .end array-data

    :array_298
    .array-data 1
        -0x44t
        -0xat
        0x18t
        -0x69t
        -0x74t
        0x5bt
        0x12t
        -0x6et
    .end array-data

    :array_2a0
    .array-data 1
        -0x67t
        0x22t
        0x67t
        0x9t
    .end array-data

    :array_2a6
    .array-data 1
        -0x3t
        0x43t
        0x13t
        0x68t
        0x9t
        0x1at
        -0x14t
        0x2et
    .end array-data

    :array_2ae
    .array-data 1
        0x6dt
        -0x51t
        -0x1at
        0x7et
    .end array-data

    :array_2b4
    .array-data 1
        0x9t
        -0x32t
        -0x6et
        0x1ft
        0xdt
        0x76t
        -0x2dt
        0x36t
    .end array-data

    :array_2bc
    .array-data 1
        -0x4et
        -0x60t
        0xet
        0x7at
    .end array-data

    :array_2c2
    .array-data 1
        -0x22t
        -0x37t
        0x7dt
        0xet
        -0xft
        -0x38t
        -0x1at
        -0x64t
    .end array-data

    :array_2ca
    .array-data 1
        0x18t
        -0x3at
        0x76t
        0x19t
    .end array-data

    :array_2d0
    .array-data 1
        0x7ct
        -0x59t
        0x2t
        0x78t
        0x3ct
        0x17t
        0x63t
        -0x7bt
    .end array-data

    :array_2d8
    .array-data 1
        0x3t
        -0x50t
        0x77t
        -0x4et
    .end array-data

    :array_2de
    .array-data 1
        0x6ft
        -0x27t
        0x4t
        -0x3at
        0x1et
        -0x45t
        -0x58t
        0x3dt
    .end array-data

    :array_2e6
    .array-data 1
        0x0t
        -0x10t
        0x7ct
        -0x40t
    .end array-data

    :array_2ec
    .array-data 1
        0x64t
        -0x6ft
        0x8t
        -0x5ft
        0x63t
        0x10t
        0x40t
        -0x43t
    .end array-data

    :array_2f4
    .array-data 1
        -0xat
        -0x26t
        0x36t
        -0x3bt
    .end array-data

    :array_2fa
    .array-data 1
        -0x66t
        -0x4dt
        0x45t
        -0x4ft
        -0x5ft
        -0x27t
        -0x31t
        0x26t
    .end array-data

    :array_302
    .array-data 1
        0x3bt
        -0x61t
        0x10t
        0x45t
    .end array-data

    :array_308
    .array-data 1
        0x5ft
        -0x2t
        0x64t
        0x24t
        0xdt
        0x4ct
        -0xat
        0x9t
    .end array-data

    :array_310
    .array-data 1
        -0x67t
        0x12t
        0x74t
        0x76t
    .end array-data

    :array_316
    .array-data 1
        -0x3t
        0x73t
        0x0t
        0x17t
        -0x29t
        -0x34t
        -0x1at
        -0x71t
    .end array-data

    :array_31e
    .array-data 1
        -0x60t
        -0x6dt
        0x6ft
        0x32t
    .end array-data

    :array_324
    .array-data 1
        -0x3ct
        -0xet
        0x1bt
        0x53t
        0x8t
        -0x7ct
        -0x58t
        -0x54t
    .end array-data

    :array_32c
    .array-data 1
        -0x19t
        0xct
        0x58t
        0x31t
        -0x47t
        0x51t
    .end array-data

    nop

    :array_334
    .array-data 1
        -0x6ft
        0x63t
        0x3ct
        0x6et
        -0x30t
        0x35t
        0x4bt
        0x21t
    .end array-data

    :array_33c
    .array-data 1
        0x77t
        0x44t
        -0x5ft
        -0x3ft
        0x4at
        0x27t
    .end array-data

    nop

    :array_344
    .array-data 1
        0x1t
        0x2bt
        -0x3bt
        -0x62t
        0x23t
        0x43t
        -0x6ct
        -0x68t
    .end array-data

    :array_34c
    .array-data 1
        -0x6ft
        0x6ct
        -0x7ft
        0x2at
        0x79t
        0x2t
    .end array-data

    nop

    :array_354
    .array-data 1
        -0x19t
        0x3t
        -0x1bt
        0x75t
        0x10t
        0x66t
        -0x42t
        0x28t
    .end array-data

    :array_35c
    .array-data 1
        0x12t
        0x4at
        -0x76t
        0x26t
        0x72t
        -0x16t
        0x45t
        0x17t
    .end array-data

    :array_364
    .array-data 1
        0x64t
        0x25t
        -0x12t
        0x79t
        0x1ct
        -0x75t
        0x28t
        0x72t
    .end array-data

    :array_36c
    .array-data 1
        -0x5t
        -0x39t
        -0x5ct
        0x1ft
        -0x5et
        -0x30t
        0x59t
        -0x11t
    .end array-data

    :array_374
    .array-data 1
        -0x73t
        -0x58t
        -0x40t
        0x40t
        -0x34t
        -0x4ft
        0x34t
        -0x76t
    .end array-data

    :array_37c
    .array-data 1
        0xet
        -0x3bt
        0x5dt
        -0x44t
        -0x7t
        0x37t
        0x22t
    .end array-data

    :array_384
    .array-data 1
        0x78t
        -0x56t
        0x39t
        -0x1dt
        -0x77t
        0x5et
        0x41t
        -0x42t
    .end array-data

    :array_38c
    .array-data 1
        -0x17t
        0x69t
        -0x80t
        -0x72t
        0x7bt
        -0x77t
        -0x68t
    .end array-data

    :array_394
    .array-data 1
        -0x61t
        0x6t
        -0x1ct
        -0x2ft
        0xbt
        -0x20t
        -0x5t
        0x18t
    .end array-data

    :array_39c
    .array-data 1
        -0x27t
        0x3ct
        0x1dt
        -0x7dt
        -0x24t
        -0x6dt
        -0x2et
        -0x78t
        -0x23t
        0x38t
        0xat
    .end array-data

    :array_3a6
    .array-data 1
        -0x51t
        0x53t
        0x79t
        -0x24t
        -0x52t
        -0xat
        -0x41t
        -0x17t
    .end array-data

    :array_3ae
    .array-data 1
        -0x1et
        -0x8t
        -0x1at
        0x59t
        0x4bt
        -0x6et
        -0x33t
        -0x33t
        -0x1at
        -0x4t
        -0xft
    .end array-data

    :array_3b8
    .array-data 1
        -0x6ct
        -0x69t
        -0x7et
        0x6t
        0x39t
        -0x9t
        -0x60t
        -0x54t
    .end array-data

    :array_3c0
    .array-data 1
        -0x2t
        -0x57t
        -0x28t
        -0x66t
        -0x63t
        0x4bt
    .end array-data

    nop

    :array_3c8
    .array-data 1
        -0x78t
        -0x3at
        -0x44t
        -0x3bt
        -0xct
        0x2ft
        -0x4ct
        0x7bt
    .end array-data

    :array_3d0
    .array-data 1
        -0x32t
        0x36t
        0x2ct
        -0x4t
        -0x33t
        -0x6et
        -0x9t
        -0x60t
    .end array-data

    :array_3d8
    .array-data 1
        -0x60t
        0x53t
        0x54t
        -0x78t
        -0x5ft
        -0x5t
        -0x67t
        -0x35t
    .end array-data

    :array_3e0
    .array-data 1
        0x51t
        -0x39t
        -0x2bt
        0x65t
        -0x80t
        -0x60t
        0x62t
        0x7et
    .end array-data

    :array_3e8
    .array-data 1
        0x27t
        -0x58t
        -0x4ft
        0x3at
        -0x12t
        -0x3ft
        0xft
        0x1bt
    .end array-data

    :array_3f0
    .array-data 1
        0x7dt
        0x7at
        0x37t
        0x4dt
        0x14t
    .end array-data

    nop

    :array_3f8
    .array-data 1
        0x9t
        0x13t
        0x43t
        0x21t
        0x71t
        0x4et
        -0x54t
        0x0t
    .end array-data

    :array_400
    .array-data 1
        -0x53t
        -0x2at
        0x17t
        -0x1et
        -0x6dt
        0x6dt
        0x63t
    .end array-data

    :array_408
    .array-data 1
        -0x25t
        -0x47t
        0x73t
        -0x43t
        -0x1dt
        0x4t
        0x0t
        0x41t
    .end array-data

    :array_410
    .array-data 1
        0x38t
        -0x42t
        0x62t
    .end array-data

    :array_416
    .array-data 1
        0x48t
        -0x29t
        0x1t
        -0x10t
        0x70t
        -0x52t
        0x3dt
        -0x10t
    .end array-data

    :array_41e
    .array-data 1
        -0x2et
        0x40t
        0x4ft
        0x7at
        -0xet
        0x69t
        0x28t
        -0x70t
        -0x2at
        0x44t
        0x58t
    .end array-data

    :array_428
    .array-data 1
        -0x5ct
        0x2ft
        0x2bt
        0x25t
        -0x80t
        0xct
        0x45t
        -0xft
    .end array-data

    :array_430
    .array-data 1
        -0x2at
        -0x39t
        0x47t
        -0x1ft
        -0x4dt
    .end array-data

    nop

    :array_438
    .array-data 1
        -0x5bt
        -0x4dt
        0x26t
        -0x6bt
        -0x2at
        0x14t
        0x79t
        0x0t
    .end array-data

    :array_440
    .array-data 1
        0x2ft
        -0x71t
        0x7t
        0x7ft
    .end array-data

    :array_446
    .array-data 1
        0x43t
        -0x1at
        0x74t
        0xbt
        -0x63t
        -0x46t
        0x53t
        -0x3bt
    .end array-data
.end method
