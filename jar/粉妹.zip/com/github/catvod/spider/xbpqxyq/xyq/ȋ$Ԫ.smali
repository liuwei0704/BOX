.class public abstract Lcom/github/catvod/spider/xbpqxyq/xyq/ȋ$Ԫ;
.super Lcom/github/catvod/spider/xbpqxyq/xyq/ȋ;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/github/catvod/spider/xbpqxyq/xyq/ȋ;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x409
    name = "Ԫ"
.end annotation


# instance fields
.field Ϳ:Ljava/lang/String;

.field Ԩ:Ljava/lang/String;


# direct methods
.method public constructor <init>(Ljava/lang/String;Ljava/lang/String;)V
    .registers 4

    const/4 v0, 0x1

    .line 1
    invoke-direct {p0, p1, p2, v0}, Lcom/github/catvod/spider/xbpqxyq/xyq/ȋ$Ԫ;-><init>(Ljava/lang/String;Ljava/lang/String;Z)V

    return-void
.end method

.method public constructor <init>(Ljava/lang/String;Ljava/lang/String;Z)V
    .registers 6

    .line 2
    invoke-direct {p0}, Lcom/github/catvod/spider/xbpqxyq/xyq/ȋ;-><init>()V

    .line 3
    invoke-static {p1}, Lcom/github/catvod/spider/xbpqxyq/xyq/ǃ;->ԭ(Ljava/lang/String;)V

    .line 4
    invoke-static {p2}, Lcom/github/catvod/spider/xbpqxyq/xyq/ǃ;->ԭ(Ljava/lang/String;)V

    .line 5
    invoke-static {p1}, Lcom/github/catvod/spider/xbpqxyq/xyq/ۦ;->Ԩ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    iput-object p1, p0, Lcom/github/catvod/spider/xbpqxyq/xyq/ȋ$Ԫ;->Ϳ:Ljava/lang/String;

    const-string p1, "55"

    invoke-static {p1}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    .line 6
    invoke-virtual {p2, p1}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v0

    const/4 v1, 0x1

    if-eqz v0, :cond_22

    invoke-virtual {p2, p1}, Ljava/lang/String;->endsWith(Ljava/lang/String;)Z

    move-result p1

    if-nez p1, :cond_34

    :cond_22
    const-string p1, "50"

    invoke-static {p1}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    .line 7
    invoke-virtual {p2, p1}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_36

    invoke-virtual {p2, p1}, Ljava/lang/String;->endsWith(Ljava/lang/String;)Z

    move-result p1

    if-eqz p1, :cond_36

    :cond_34
    const/4 p1, 0x1

    goto :goto_37

    :cond_36
    const/4 p1, 0x0

    :goto_37
    if-eqz p1, :cond_42

    .line 8
    invoke-virtual {p2}, Ljava/lang/String;->length()I

    move-result v0

    sub-int/2addr v0, v1

    invoke-virtual {p2, v1, v0}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object p2

    :cond_42
    if-eqz p3, :cond_49

    .line 9
    invoke-static {p2}, Lcom/github/catvod/spider/xbpqxyq/xyq/ۦ;->Ԩ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    goto :goto_4d

    :cond_49
    invoke-static {p2, p1}, Lcom/github/catvod/spider/xbpqxyq/xyq/ۦ;->ԩ(Ljava/lang/String;Z)Ljava/lang/String;

    move-result-object p1

    :goto_4d
    iput-object p1, p0, Lcom/github/catvod/spider/xbpqxyq/xyq/ȋ$Ԫ;->Ԩ:Ljava/lang/String;

    return-void
.end method
