.class public final Lcom/github/catvod/spider/xbpqxyq/xyq/ȋ$ޛ;
.super Lcom/github/catvod/spider/xbpqxyq/xyq/ȋ;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/github/catvod/spider/xbpqxyq/xyq/ȋ;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "ޛ"
.end annotation


# instance fields
.field private final Ϳ:Ljava/util/regex/Pattern;


# direct methods
.method public constructor <init>(Ljava/util/regex/Pattern;)V
    .registers 2

    .line 1
    invoke-direct {p0}, Lcom/github/catvod/spider/xbpqxyq/xyq/ȋ;-><init>()V

    .line 2
    iput-object p1, p0, Lcom/github/catvod/spider/xbpqxyq/xyq/ȋ$ޛ;->Ϳ:Ljava/util/regex/Pattern;

    return-void
.end method


# virtual methods
.method public toString()Ljava/lang/String;
    .registers 4

    const/4 v0, 0x1

    new-array v0, v0, [Ljava/lang/Object;

    .line 1
    iget-object v1, p0, Lcom/github/catvod/spider/xbpqxyq/xyq/ȋ$ޛ;->Ϳ:Ljava/util/regex/Pattern;

    const/4 v2, 0x0

    aput-object v1, v0, v2

    const-string v1, "482F3225392C17311C26346C57317A"

    invoke-static {v1}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-static {v1, v0}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public Ϳ(Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;)Z
    .registers 3

    .line 1
    iget-object p1, p0, Lcom/github/catvod/spider/xbpqxyq/xyq/ȋ$ޛ;->Ϳ:Ljava/util/regex/Pattern;

    invoke-virtual {p2}, Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;->ࢫ()Ljava/lang/String;

    move-result-object p2

    invoke-virtual {p1, p2}, Ljava/util/regex/Pattern;->matcher(Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;

    move-result-object p1

    .line 2
    invoke-virtual {p1}, Ljava/util/regex/Matcher;->find()Z

    move-result p1

    return p1
.end method
