.class abstract Lcom/github/catvod/spider/xbpqxyq/xyq/ĭ;
.super Lcom/github/catvod/spider/xbpqxyq/xyq/ȋ;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/github/catvod/spider/xbpqxyq/xyq/ĭ$Ԩ;,
        Lcom/github/catvod/spider/xbpqxyq/xyq/ĭ$Ϳ;
    }
.end annotation


# instance fields
.field final Ϳ:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Lcom/github/catvod/spider/xbpqxyq/xyq/ȋ;",
            ">;"
        }
    .end annotation
.end field

.field Ԩ:I


# direct methods
.method constructor <init>()V
    .registers 2

    .line 1
    invoke-direct {p0}, Lcom/github/catvod/spider/xbpqxyq/xyq/ȋ;-><init>()V

    const/4 v0, 0x0

    .line 2
    iput v0, p0, Lcom/github/catvod/spider/xbpqxyq/xyq/ĭ;->Ԩ:I

    .line 3
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xyq/ĭ;->Ϳ:Ljava/util/ArrayList;

    return-void
.end method

.method constructor <init>(Ljava/util/Collection;)V
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/Collection<",
            "Lcom/github/catvod/spider/xbpqxyq/xyq/ȋ;",
            ">;)V"
        }
    .end annotation

    .line 4
    invoke-direct {p0}, Lcom/github/catvod/spider/xbpqxyq/xyq/ĭ;-><init>()V

    .line 5
    iget-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xyq/ĭ;->Ϳ:Ljava/util/ArrayList;

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    .line 6
    invoke-virtual {p0}, Lcom/github/catvod/spider/xbpqxyq/xyq/ĭ;->Ԫ()V

    return-void
.end method


# virtual methods
.method Ԩ(Lcom/github/catvod/spider/xbpqxyq/xyq/ȋ;)V
    .registers 4

    .line 1
    iget-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xyq/ĭ;->Ϳ:Ljava/util/ArrayList;

    iget v1, p0, Lcom/github/catvod/spider/xbpqxyq/xyq/ĭ;->Ԩ:I

    add-int/lit8 v1, v1, -0x1

    invoke-virtual {v0, v1, p1}, Ljava/util/ArrayList;->set(ILjava/lang/Object;)Ljava/lang/Object;

    return-void
.end method

.method ԩ()Lcom/github/catvod/spider/xbpqxyq/xyq/ȋ;
    .registers 3
    .annotation runtime Ljavax/annotation/Nullable;
    .end annotation

    .line 1
    iget v0, p0, Lcom/github/catvod/spider/xbpqxyq/xyq/ĭ;->Ԩ:I

    if-lez v0, :cond_f

    iget-object v1, p0, Lcom/github/catvod/spider/xbpqxyq/xyq/ĭ;->Ϳ:Ljava/util/ArrayList;

    add-int/lit8 v0, v0, -0x1

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/github/catvod/spider/xbpqxyq/xyq/ȋ;

    goto :goto_10

    :cond_f
    const/4 v0, 0x0

    :goto_10
    return-object v0
.end method

.method Ԫ()V
    .registers 2

    .line 1
    iget-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xyq/ĭ;->Ϳ:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    iput v0, p0, Lcom/github/catvod/spider/xbpqxyq/xyq/ĭ;->Ԩ:I

    return-void
.end method
