.class final Lcom/github/catvod/spider/xbpqxyq/xyq/ſ$Ԯ;
.super Lcom/github/catvod/spider/xbpqxyq/xyq/ſ;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/github/catvod/spider/xbpqxyq/xyq/ſ;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = "Ԯ"
.end annotation


# instance fields
.field final Ԩ:Ljava/lang/StringBuilder;

.field ԩ:Ljava/lang/String;

.field final Ԫ:Ljava/lang/StringBuilder;

.field final ԫ:Ljava/lang/StringBuilder;

.field Ԭ:Z


# direct methods
.method constructor <init>()V
    .registers 3

    const/4 v0, 0x0

    .line 1
    invoke-direct {p0, v0}, Lcom/github/catvod/spider/xbpqxyq/xyq/ſ;-><init>(Lcom/github/catvod/spider/xbpqxyq/xyq/ſ$Ϳ;)V

    .line 2
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    iput-object v1, p0, Lcom/github/catvod/spider/xbpqxyq/xyq/ſ$Ԯ;->Ԩ:Ljava/lang/StringBuilder;

    .line 3
    iput-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xyq/ſ$Ԯ;->ԩ:Ljava/lang/String;

    .line 4
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    iput-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xyq/ſ$Ԯ;->Ԫ:Ljava/lang/StringBuilder;

    .line 5
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    iput-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xyq/ſ$Ԯ;->ԫ:Ljava/lang/StringBuilder;

    const/4 v0, 0x0

    .line 6
    iput-boolean v0, p0, Lcom/github/catvod/spider/xbpqxyq/xyq/ſ$Ԯ;->Ԭ:Z

    .line 7
    sget-object v0, Lcom/github/catvod/spider/xbpqxyq/xyq/ſ$ނ;->Ϳ:Lcom/github/catvod/spider/xbpqxyq/xyq/ſ$ނ;

    iput-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xyq/ſ;->Ϳ:Lcom/github/catvod/spider/xbpqxyq/xyq/ſ$ނ;

    return-void
.end method


# virtual methods
.method ށ()Lcom/github/catvod/spider/xbpqxyq/xyq/ſ;
    .registers 2

    .line 1
    iget-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xyq/ſ$Ԯ;->Ԩ:Ljava/lang/StringBuilder;

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xyq/ſ;->ނ(Ljava/lang/StringBuilder;)V

    const/4 v0, 0x0

    .line 2
    iput-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xyq/ſ$Ԯ;->ԩ:Ljava/lang/String;

    .line 3
    iget-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xyq/ſ$Ԯ;->Ԫ:Ljava/lang/StringBuilder;

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xyq/ſ;->ނ(Ljava/lang/StringBuilder;)V

    .line 4
    iget-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xyq/ſ$Ԯ;->ԫ:Ljava/lang/StringBuilder;

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xyq/ſ;->ނ(Ljava/lang/StringBuilder;)V

    const/4 v0, 0x0

    .line 5
    iput-boolean v0, p0, Lcom/github/catvod/spider/xbpqxyq/xyq/ſ$Ԯ;->Ԭ:Z

    return-object p0
.end method

.method ބ()Ljava/lang/String;
    .registers 2

    .line 1
    iget-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xyq/ſ$Ԯ;->Ԩ:Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method ޅ()Ljava/lang/String;
    .registers 2

    .line 1
    iget-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xyq/ſ$Ԯ;->ԩ:Ljava/lang/String;

    return-object v0
.end method

.method ކ()Ljava/lang/String;
    .registers 2

    .line 1
    iget-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xyq/ſ$Ԯ;->Ԫ:Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public އ()Ljava/lang/String;
    .registers 2

    .line 1
    iget-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xyq/ſ$Ԯ;->ԫ:Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public ވ()Z
    .registers 2

    .line 1
    iget-boolean v0, p0, Lcom/github/catvod/spider/xbpqxyq/xyq/ſ$Ԯ;->Ԭ:Z

    return v0
.end method
