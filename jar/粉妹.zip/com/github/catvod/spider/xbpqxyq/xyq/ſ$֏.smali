.class final Lcom/github/catvod/spider/xbpqxyq/xyq/ſ$֏;
.super Lcom/github/catvod/spider/xbpqxyq/xyq/ſ;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/github/catvod/spider/xbpqxyq/xyq/ſ;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = "֏"
.end annotation


# direct methods
.method constructor <init>()V
    .registers 2

    const/4 v0, 0x0

    .line 1
    invoke-direct {p0, v0}, Lcom/github/catvod/spider/xbpqxyq/xyq/ſ;-><init>(Lcom/github/catvod/spider/xbpqxyq/xyq/ſ$Ϳ;)V

    .line 2
    sget-object v0, Lcom/github/catvod/spider/xbpqxyq/xyq/ſ$ނ;->Ԭ:Lcom/github/catvod/spider/xbpqxyq/xyq/ſ$ނ;

    iput-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xyq/ſ;->Ϳ:Lcom/github/catvod/spider/xbpqxyq/xyq/ſ$ނ;

    return-void
.end method


# virtual methods
.method public toString()Ljava/lang/String;
    .registers 2

    const-string v0, ""

    return-object v0
.end method

.method ށ()Lcom/github/catvod/spider/xbpqxyq/xyq/ſ;
    .registers 1

    return-object p0
.end method
