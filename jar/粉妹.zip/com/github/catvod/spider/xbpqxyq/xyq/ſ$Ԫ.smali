.class Lcom/github/catvod/spider/xbpqxyq/xyq/ſ$Ԫ;
.super Lcom/github/catvod/spider/xbpqxyq/xyq/ſ;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/github/catvod/spider/xbpqxyq/xyq/ſ;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x8
    name = "Ԫ"
.end annotation


# instance fields
.field private Ԩ:Ljava/lang/String;


# direct methods
.method constructor <init>()V
    .registers 2

    const/4 v0, 0x0

    .line 1
    invoke-direct {p0, v0}, Lcom/github/catvod/spider/xbpqxyq/xyq/ſ;-><init>(Lcom/github/catvod/spider/xbpqxyq/xyq/ſ$Ϳ;)V

    .line 2
    sget-object v0, Lcom/github/catvod/spider/xbpqxyq/xyq/ſ$ނ;->ԫ:Lcom/github/catvod/spider/xbpqxyq/xyq/ſ$ނ;

    iput-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xyq/ſ;->Ϳ:Lcom/github/catvod/spider/xbpqxyq/xyq/ſ$ނ;

    return-void
.end method


# virtual methods
.method public toString()Ljava/lang/String;
    .registers 2

    .line 1
    invoke-virtual {p0}, Lcom/github/catvod/spider/xbpqxyq/xyq/ſ$Ԫ;->ޅ()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method ށ()Lcom/github/catvod/spider/xbpqxyq/xyq/ſ;
    .registers 2

    const/4 v0, 0x0

    .line 1
    iput-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xyq/ſ$Ԫ;->Ԩ:Ljava/lang/String;

    return-object p0
.end method

.method ބ(Ljava/lang/String;)Lcom/github/catvod/spider/xbpqxyq/xyq/ſ$Ԫ;
    .registers 2

    .line 1
    iput-object p1, p0, Lcom/github/catvod/spider/xbpqxyq/xyq/ſ$Ԫ;->Ԩ:Ljava/lang/String;

    return-object p0
.end method

.method ޅ()Ljava/lang/String;
    .registers 2

    .line 1
    iget-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xyq/ſ$Ԫ;->Ԩ:Ljava/lang/String;

    return-object v0
.end method
