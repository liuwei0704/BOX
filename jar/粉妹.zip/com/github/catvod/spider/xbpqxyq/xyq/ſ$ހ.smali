.class final Lcom/github/catvod/spider/xbpqxyq/xyq/ſ$ހ;
.super Lcom/github/catvod/spider/xbpqxyq/xyq/ſ$ށ;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/github/catvod/spider/xbpqxyq/xyq/ſ;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = "ހ"
.end annotation


# direct methods
.method constructor <init>()V
    .registers 2

    .line 1
    invoke-direct {p0}, Lcom/github/catvod/spider/xbpqxyq/xyq/ſ$ށ;-><init>()V

    .line 2
    sget-object v0, Lcom/github/catvod/spider/xbpqxyq/xyq/ſ$ނ;->Ԩ:Lcom/github/catvod/spider/xbpqxyq/xyq/ſ$ނ;

    iput-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xyq/ſ;->Ϳ:Lcom/github/catvod/spider/xbpqxyq/xyq/ſ$ނ;

    return-void
.end method


# virtual methods
.method public toString()Ljava/lang/String;
    .registers 4

    .line 1
    invoke-virtual {p0}, Lcom/github/catvod/spider/xbpqxyq/xyq/ſ$ށ;->ގ()Z

    move-result v0

    const-string v1, "4C"

    invoke-static {v1}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const-string v2, "4E"

    invoke-static {v2}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    if-eqz v0, :cond_43

    iget-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xyq/ſ$ށ;->֏:Lcom/github/catvod/spider/xbpqxyq/xyq/ྋ;

    invoke-virtual {v0}, Lcom/github/catvod/spider/xbpqxyq/xyq/ྋ;->size()I

    move-result v0

    if-lez v0, :cond_43

    .line 2
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, Lcom/github/catvod/spider/xbpqxyq/xyq/ſ$ށ;->ޖ()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v2, "52"

    invoke-static {v2}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v2, p0, Lcom/github/catvod/spider/xbpqxyq/xyq/ſ$ށ;->֏:Lcom/github/catvod/spider/xbpqxyq/xyq/ྋ;

    invoke-virtual {v2}, Lcom/github/catvod/spider/xbpqxyq/xyq/ྋ;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0

    .line 3
    :cond_43
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, Lcom/github/catvod/spider/xbpqxyq/xyq/ſ$ށ;->ޖ()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method bridge synthetic ށ()Lcom/github/catvod/spider/xbpqxyq/xyq/ſ;
    .registers 2

    .line 1
    invoke-virtual {p0}, Lcom/github/catvod/spider/xbpqxyq/xyq/ſ$ހ;->ޔ()Lcom/github/catvod/spider/xbpqxyq/xyq/ſ$ށ;

    move-result-object v0

    return-object v0
.end method

.method ޔ()Lcom/github/catvod/spider/xbpqxyq/xyq/ſ$ށ;
    .registers 2

    .line 1
    invoke-super {p0}, Lcom/github/catvod/spider/xbpqxyq/xyq/ſ$ށ;->ޔ()Lcom/github/catvod/spider/xbpqxyq/xyq/ſ$ށ;

    const/4 v0, 0x0

    .line 2
    iput-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xyq/ſ$ށ;->֏:Lcom/github/catvod/spider/xbpqxyq/xyq/ྋ;

    return-object p0
.end method

.method ޗ(Ljava/lang/String;Lcom/github/catvod/spider/xbpqxyq/xyq/ྋ;)Lcom/github/catvod/spider/xbpqxyq/xyq/ſ$ހ;
    .registers 3

    .line 1
    iput-object p1, p0, Lcom/github/catvod/spider/xbpqxyq/xyq/ſ$ށ;->Ԩ:Ljava/lang/String;

    .line 2
    iput-object p2, p0, Lcom/github/catvod/spider/xbpqxyq/xyq/ſ$ށ;->֏:Lcom/github/catvod/spider/xbpqxyq/xyq/ྋ;

    .line 3
    invoke-static {p1}, Lcom/github/catvod/spider/xbpqxyq/xyq/ۦ;->Ϳ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    iput-object p1, p0, Lcom/github/catvod/spider/xbpqxyq/xyq/ſ$ށ;->ԩ:Ljava/lang/String;

    return-object p0
.end method
