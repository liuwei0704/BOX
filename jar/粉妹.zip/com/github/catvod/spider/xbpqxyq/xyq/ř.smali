.class public Lcom/github/catvod/spider/xbpqxyq/xyq/ř;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lcom/github/catvod/spider/xbpqxyq/xyq/İ;


# direct methods
.method public constructor <init>()V
    .registers 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public name()Ljava/lang/String;
    .registers 2

    const-string v0, "023036323F201B2C347C292D102E3A3F3D"

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public Ϳ(Lcom/github/catvod/spider/xbpqxyq/xyq/ำ;)Lcom/github/catvod/spider/xbpqxyq/xyq/ߠ;
    .registers 4

    .line 1
    new-instance v0, Ljava/util/LinkedList;

    invoke-direct {v0}, Ljava/util/LinkedList;-><init>()V

    .line 2
    invoke-virtual {p1}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :goto_9
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_20

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;

    .line 3
    invoke-static {v1}, Lcom/github/catvod/spider/xbpqxyq/xyq/ʏ;->Ԫ(Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;)Lcom/github/catvod/spider/xbpqxyq/xyq/ำ;

    move-result-object v1

    if-nez v1, :cond_1c

    goto :goto_9

    .line 4
    :cond_1c
    invoke-interface {v0, v1}, Ljava/util/List;->addAll(Ljava/util/Collection;)Z

    goto :goto_9

    .line 5
    :cond_20
    new-instance p1, Lcom/github/catvod/spider/xbpqxyq/xyq/ำ;

    invoke-direct {p1}, Lcom/github/catvod/spider/xbpqxyq/xyq/ำ;-><init>()V

    .line 6
    invoke-virtual {p1, v0}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    .line 7
    invoke-static {p1}, Lcom/github/catvod/spider/xbpqxyq/xyq/ߠ;->֏(Ljava/lang/Object;)Lcom/github/catvod/spider/xbpqxyq/xyq/ߠ;

    move-result-object p1

    return-object p1
.end method
