.class public interface abstract Lcom/github/catvod/spider/xbpqxyq/xyq/ł;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/github/catvod/spider/xbpqxyq/xyq/ł$Ϳ;
    }
.end annotation


# virtual methods
.method public abstract Ϳ(Lcom/github/catvod/spider/xbpqxyq/xyq/ւ;I)Lcom/github/catvod/spider/xbpqxyq/xyq/ł$Ϳ;
.end method

.method public abstract Ԩ(Lcom/github/catvod/spider/xbpqxyq/xyq/ւ;I)Lcom/github/catvod/spider/xbpqxyq/xyq/ł$Ϳ;
.end method
