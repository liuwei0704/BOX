.class public final enum Lcom/github/catvod/spider/xbpqxyq/xyq/ǐ$Ϳ$Ϳ;
.super Ljava/lang/Enum;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/github/catvod/spider/xbpqxyq/xyq/ǐ$Ϳ;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x4019
    name = "Ϳ"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "Lcom/github/catvod/spider/xbpqxyq/xyq/ǐ$Ϳ$Ϳ;",
        ">;"
    }
.end annotation


# static fields
.field public static final enum Ϳ:Lcom/github/catvod/spider/xbpqxyq/xyq/ǐ$Ϳ$Ϳ;

.field public static final enum Ԩ:Lcom/github/catvod/spider/xbpqxyq/xyq/ǐ$Ϳ$Ϳ;

.field private static final synthetic ԩ:[Lcom/github/catvod/spider/xbpqxyq/xyq/ǐ$Ϳ$Ϳ;


# direct methods
.method static constructor <clinit>()V
    .registers 5

    .line 1
    new-instance v0, Lcom/github/catvod/spider/xbpqxyq/xyq/ǐ$Ϳ$Ϳ;

    const-string v1, "1A363E3D"

    invoke-static {v1}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const/4 v2, 0x0

    invoke-direct {v0, v1, v2}, Lcom/github/catvod/spider/xbpqxyq/xyq/ǐ$Ϳ$Ϳ;-><init>(Ljava/lang/String;I)V

    sput-object v0, Lcom/github/catvod/spider/xbpqxyq/xyq/ǐ$Ϳ$Ϳ;->Ϳ:Lcom/github/catvod/spider/xbpqxyq/xyq/ǐ$Ϳ$Ϳ;

    new-instance v1, Lcom/github/catvod/spider/xbpqxyq/xyq/ǐ$Ϳ$Ϳ;

    const-string v3, "0A2F3F"

    invoke-static {v3}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    const/4 v4, 0x1

    invoke-direct {v1, v3, v4}, Lcom/github/catvod/spider/xbpqxyq/xyq/ǐ$Ϳ$Ϳ;-><init>(Ljava/lang/String;I)V

    sput-object v1, Lcom/github/catvod/spider/xbpqxyq/xyq/ǐ$Ϳ$Ϳ;->Ԩ:Lcom/github/catvod/spider/xbpqxyq/xyq/ǐ$Ϳ$Ϳ;

    const/4 v3, 0x2

    new-array v3, v3, [Lcom/github/catvod/spider/xbpqxyq/xyq/ǐ$Ϳ$Ϳ;

    aput-object v0, v3, v2

    aput-object v1, v3, v4

    sput-object v3, Lcom/github/catvod/spider/xbpqxyq/xyq/ǐ$Ϳ$Ϳ;->ԩ:[Lcom/github/catvod/spider/xbpqxyq/xyq/ǐ$Ϳ$Ϳ;

    return-void
.end method

.method private constructor <init>(Ljava/lang/String;I)V
    .registers 3

    .line 1
    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    return-void
.end method
