.class public abstract Lcom/github/catvod/spider/xbpqxyq/xyq/ȋ$ފ;
.super Lcom/github/catvod/spider/xbpqxyq/xyq/ȋ;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/github/catvod/spider/xbpqxyq/xyq/ȋ;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x409
    name = "ފ"
.end annotation


# instance fields
.field Ϳ:I


# direct methods
.method public constructor <init>(I)V
    .registers 2

    .line 1
    invoke-direct {p0}, Lcom/github/catvod/spider/xbpqxyq/xyq/ȋ;-><init>()V

    .line 2
    iput p1, p0, Lcom/github/catvod/spider/xbpqxyq/xyq/ȋ$ފ;->Ϳ:I

    return-void
.end method
