.class public final Lcom/github/catvod/spider/xbpqxyq/xyq/ȋ$ޓ;
.super Lcom/github/catvod/spider/xbpqxyq/xyq/ȋ$އ;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/github/catvod/spider/xbpqxyq/xyq/ȋ;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "ޓ"
.end annotation


# direct methods
.method public constructor <init>(II)V
    .registers 3

    .line 1
    invoke-direct {p0, p1, p2}, Lcom/github/catvod/spider/xbpqxyq/xyq/ȋ$އ;-><init>(II)V

    return-void
.end method


# virtual methods
.method protected Ԩ(Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;)I
    .registers 3

    .line 1
    invoke-virtual {p2}, Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;->ࢭ()Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;

    move-result-object p1

    if-nez p1, :cond_8

    const/4 p1, 0x0

    return p1

    .line 2
    :cond_8
    invoke-virtual {p2}, Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;->ࢭ()Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;

    move-result-object p1

    invoke-virtual {p1}, Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;->ࡤ()Lcom/github/catvod/spider/xbpqxyq/xyq/ำ;

    move-result-object p1

    invoke-virtual {p1}, Ljava/util/ArrayList;->size()I

    move-result p1

    invoke-virtual {p2}, Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;->ࡨ()I

    move-result p2

    sub-int/2addr p1, p2

    return p1
.end method

.method protected ԩ()Ljava/lang/String;
    .registers 2

    const-string v0, "1C363B7C362501367E32322D1E26"

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method
