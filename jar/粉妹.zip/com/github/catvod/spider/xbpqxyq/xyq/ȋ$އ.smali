.class public abstract Lcom/github/catvod/spider/xbpqxyq/xyq/ȋ$އ;
.super Lcom/github/catvod/spider/xbpqxyq/xyq/ȋ;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/github/catvod/spider/xbpqxyq/xyq/ȋ;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x409
    name = "އ"
.end annotation


# instance fields
.field protected final Ϳ:I

.field protected final Ԩ:I


# direct methods
.method public constructor <init>(II)V
    .registers 3

    .line 1
    invoke-direct {p0}, Lcom/github/catvod/spider/xbpqxyq/xyq/ȋ;-><init>()V

    .line 2
    iput p1, p0, Lcom/github/catvod/spider/xbpqxyq/xyq/ȋ$އ;->Ϳ:I

    .line 3
    iput p2, p0, Lcom/github/catvod/spider/xbpqxyq/xyq/ȋ$އ;->Ԩ:I

    return-void
.end method


# virtual methods
.method public toString()Ljava/lang/String;
    .registers 6

    .line 1
    iget v0, p0, Lcom/github/catvod/spider/xbpqxyq/xyq/ȋ$އ;->Ϳ:I

    const/4 v1, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x2

    if-nez v0, :cond_22

    new-array v0, v3, [Ljava/lang/Object;

    .line 2
    invoke-virtual {p0}, Lcom/github/catvod/spider/xbpqxyq/xyq/ȋ$އ;->ԩ()Ljava/lang/String;

    move-result-object v3

    aput-object v3, v0, v2

    iget v2, p0, Lcom/github/catvod/spider/xbpqxyq/xyq/ȋ$އ;->Ԩ:I

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    aput-object v2, v0, v1

    const-string v1, "486720797F205B"

    invoke-static {v1}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-static {v1, v0}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    return-object v0

    .line 3
    :cond_22
    iget v0, p0, Lcom/github/catvod/spider/xbpqxyq/xyq/ȋ$އ;->Ԩ:I

    if-nez v0, :cond_41

    new-array v0, v3, [Ljava/lang/Object;

    .line 4
    invoke-virtual {p0}, Lcom/github/catvod/spider/xbpqxyq/xyq/ȋ$އ;->ԩ()Ljava/lang/String;

    move-result-object v3

    aput-object v3, v0, v2

    iget v2, p0, Lcom/github/catvod/spider/xbpqxyq/xyq/ȋ$އ;->Ϳ:I

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    aput-object v2, v0, v1

    const-string v1, "486720797F201C6B"

    invoke-static {v1}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-static {v1, v0}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    return-object v0

    :cond_41
    const/4 v0, 0x3

    new-array v0, v0, [Ljava/lang/Object;

    .line 5
    invoke-virtual {p0}, Lcom/github/catvod/spider/xbpqxyq/xyq/ȋ$އ;->ԩ()Ljava/lang/String;

    move-result-object v4

    aput-object v4, v0, v2

    iget v2, p0, Lcom/github/catvod/spider/xbpqxyq/xyq/ȋ$އ;->Ϳ:I

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    aput-object v2, v0, v1

    iget v1, p0, Lcom/github/catvod/spider/xbpqxyq/xyq/ȋ$އ;->Ԩ:I

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    aput-object v1, v0, v3

    const-string v1, "486720797F201C67783573"

    invoke-static {v1}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-static {v1, v0}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public Ϳ(Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;)Z
    .registers 7

    .line 1
    invoke-virtual {p2}, Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;->ࢭ()Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;

    move-result-object v0

    const/4 v1, 0x0

    if-eqz v0, :cond_28

    .line 2
    instance-of v0, v0, Lcom/github/catvod/spider/xbpqxyq/xyq/ǐ;

    if-eqz v0, :cond_c

    goto :goto_28

    .line 3
    :cond_c
    invoke-virtual {p0, p1, p2}, Lcom/github/catvod/spider/xbpqxyq/xyq/ȋ$އ;->Ԩ(Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;)I

    move-result p1

    .line 4
    iget p2, p0, Lcom/github/catvod/spider/xbpqxyq/xyq/ȋ$އ;->Ϳ:I

    const/4 v0, 0x1

    if-nez p2, :cond_1b

    iget p2, p0, Lcom/github/catvod/spider/xbpqxyq/xyq/ȋ$އ;->Ԩ:I

    if-ne p1, p2, :cond_1a

    const/4 v1, 0x1

    :cond_1a
    return v1

    .line 5
    :cond_1b
    iget v2, p0, Lcom/github/catvod/spider/xbpqxyq/xyq/ȋ$އ;->Ԩ:I

    sub-int v3, p1, v2

    mul-int v3, v3, p2

    if-ltz v3, :cond_28

    sub-int/2addr p1, v2

    rem-int/2addr p1, p2

    if-nez p1, :cond_28

    const/4 v1, 0x1

    :cond_28
    :goto_28
    return v1
.end method

.method protected abstract Ԩ(Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;)I
.end method

.method protected abstract ԩ()Ljava/lang/String;
.end method
