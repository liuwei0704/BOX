.class public final Lcom/github/catvod/spider/xbpqxyq/xyq/ȋ$ޒ;
.super Lcom/github/catvod/spider/xbpqxyq/xyq/ȋ$އ;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/github/catvod/spider/xbpqxyq/xyq/ȋ;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "ޒ"
.end annotation


# direct methods
.method public constructor <init>(II)V
    .registers 3

    .line 1
    invoke-direct {p0, p1, p2}, Lcom/github/catvod/spider/xbpqxyq/xyq/ȋ$އ;-><init>(II)V

    return-void
.end method


# virtual methods
.method protected Ԩ(Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;)I
    .registers 3

    .line 1
    invoke-virtual {p2}, Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;->ࡨ()I

    move-result p1

    add-int/lit8 p1, p1, 0x1

    return p1
.end method

.method protected ԩ()Ljava/lang/String;
    .registers 2

    const-string v0, "1C363B7C392C1B2E37"

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method
