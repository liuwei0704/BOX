.class public final Lcom/github/catvod/spider/xbpqxyq/xyq/ȋ$ޙ;
.super Lcom/github/catvod/spider/xbpqxyq/xyq/ȋ;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/github/catvod/spider/xbpqxyq/xyq/ȋ;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "ޙ"
.end annotation


# direct methods
.method public constructor <init>()V
    .registers 1

    .line 1
    invoke-direct {p0}, Lcom/github/catvod/spider/xbpqxyq/xyq/ȋ;-><init>()V

    return-void
.end method


# virtual methods
.method public toString()Ljava/lang/String;
    .registers 2

    const-string v0, "482F3225392C26272B25"

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public Ϳ(Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;)Z
    .registers 8

    .line 1
    instance-of p1, p2, Lcom/github/catvod/spider/xbpqxyq/xyq/ľ;

    if-eqz p1, :cond_6

    const/4 p1, 0x1

    return p1

    .line 2
    :cond_6
    invoke-virtual {p2}, Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;->ࢻ()Ljava/util/List;

    move-result-object p1

    .line 3
    invoke-interface {p1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :goto_e
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_36

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/github/catvod/spider/xbpqxyq/xyq/ŀ;

    .line 4
    new-instance v1, Lcom/github/catvod/spider/xbpqxyq/xyq/ľ;

    .line 5
    invoke-virtual {p2}, Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;->ࢸ()Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Lcom/github/catvod/spider/xbpqxyq/xyq/ȉ;->ނ(Ljava/lang/String;)Lcom/github/catvod/spider/xbpqxyq/xyq/ȉ;

    move-result-object v2

    invoke-virtual {p2}, Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;->Ԭ()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {p2}, Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;->ԫ()Lcom/github/catvod/spider/xbpqxyq/xyq/ྋ;

    move-result-object v4

    invoke-direct {v1, v2, v3, v4}, Lcom/github/catvod/spider/xbpqxyq/xyq/ľ;-><init>(Lcom/github/catvod/spider/xbpqxyq/xyq/ȉ;Ljava/lang/String;Lcom/github/catvod/spider/xbpqxyq/xyq/ྋ;)V

    .line 6
    invoke-virtual {v0, v1}, Lcom/github/catvod/spider/xbpqxyq/xyq/ւ;->ޘ(Lcom/github/catvod/spider/xbpqxyq/xyq/ւ;)V

    .line 7
    invoke-virtual {v1, v0}, Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;->ޢ(Lcom/github/catvod/spider/xbpqxyq/xyq/ւ;)Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;

    goto :goto_e

    :cond_36
    const/4 p1, 0x0

    return p1
.end method
