.class public Lcom/github/catvod/spider/xbpqxyq/xyq/ǐ$Ϳ;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Cloneable;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/github/catvod/spider/xbpqxyq/xyq/ǐ;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "Ϳ"
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/github/catvod/spider/xbpqxyq/xyq/ǐ$Ϳ$Ϳ;
    }
.end annotation


# instance fields
.field private Ϳ:Lcom/github/catvod/spider/xbpqxyq/xyq/ו$Ԫ;

.field private Ԩ:Ljava/nio/charset/Charset;

.field private final ԩ:Ljava/lang/ThreadLocal;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/lang/ThreadLocal<",
            "Ljava/nio/charset/CharsetEncoder;",
            ">;"
        }
    .end annotation
.end field

.field Ԫ:Lcom/github/catvod/spider/xbpqxyq/xyq/ו$Ԩ;
    .annotation runtime Ljavax/annotation/Nullable;
    .end annotation
.end field

.field private ԫ:Z

.field private Ԭ:Z

.field private ԭ:I

.field private Ԯ:Lcom/github/catvod/spider/xbpqxyq/xyq/ǐ$Ϳ$Ϳ;


# direct methods
.method public constructor <init>()V
    .registers 3

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    sget-object v0, Lcom/github/catvod/spider/xbpqxyq/xyq/ו$Ԫ;->Ԩ:Lcom/github/catvod/spider/xbpqxyq/xyq/ו$Ԫ;

    iput-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xyq/ǐ$Ϳ;->Ϳ:Lcom/github/catvod/spider/xbpqxyq/xyq/ו$Ԫ;

    .line 3
    sget-object v0, Lcom/github/catvod/spider/xbpqxyq/xyq/ٵ;->Ԩ:Ljava/nio/charset/Charset;

    iput-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xyq/ǐ$Ϳ;->Ԩ:Ljava/nio/charset/Charset;

    .line 4
    new-instance v0, Ljava/lang/ThreadLocal;

    invoke-direct {v0}, Ljava/lang/ThreadLocal;-><init>()V

    iput-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xyq/ǐ$Ϳ;->ԩ:Ljava/lang/ThreadLocal;

    const/4 v0, 0x1

    .line 5
    iput-boolean v0, p0, Lcom/github/catvod/spider/xbpqxyq/xyq/ǐ$Ϳ;->ԫ:Z

    const/4 v1, 0x0

    .line 6
    iput-boolean v1, p0, Lcom/github/catvod/spider/xbpqxyq/xyq/ǐ$Ϳ;->Ԭ:Z

    .line 7
    iput v0, p0, Lcom/github/catvod/spider/xbpqxyq/xyq/ǐ$Ϳ;->ԭ:I

    .line 8
    sget-object v0, Lcom/github/catvod/spider/xbpqxyq/xyq/ǐ$Ϳ$Ϳ;->Ϳ:Lcom/github/catvod/spider/xbpqxyq/xyq/ǐ$Ϳ$Ϳ;

    iput-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xyq/ǐ$Ϳ;->Ԯ:Lcom/github/catvod/spider/xbpqxyq/xyq/ǐ$Ϳ$Ϳ;

    return-void
.end method


# virtual methods
.method public bridge synthetic clone()Ljava/lang/Object;
    .registers 2

    .line 1
    invoke-virtual {p0}, Lcom/github/catvod/spider/xbpqxyq/xyq/ǐ$Ϳ;->ԩ()Lcom/github/catvod/spider/xbpqxyq/xyq/ǐ$Ϳ;

    move-result-object v0

    return-object v0
.end method

.method public Ϳ(Ljava/lang/String;)Lcom/github/catvod/spider/xbpqxyq/xyq/ǐ$Ϳ;
    .registers 2

    .line 1
    invoke-static {p1}, Ljava/nio/charset/Charset;->forName(Ljava/lang/String;)Ljava/nio/charset/Charset;

    move-result-object p1

    invoke-virtual {p0, p1}, Lcom/github/catvod/spider/xbpqxyq/xyq/ǐ$Ϳ;->Ԩ(Ljava/nio/charset/Charset;)Lcom/github/catvod/spider/xbpqxyq/xyq/ǐ$Ϳ;

    return-object p0
.end method

.method public Ԩ(Ljava/nio/charset/Charset;)Lcom/github/catvod/spider/xbpqxyq/xyq/ǐ$Ϳ;
    .registers 2

    .line 1
    iput-object p1, p0, Lcom/github/catvod/spider/xbpqxyq/xyq/ǐ$Ϳ;->Ԩ:Ljava/nio/charset/Charset;

    return-object p0
.end method

.method public ԩ()Lcom/github/catvod/spider/xbpqxyq/xyq/ǐ$Ϳ;
    .registers 3

    .line 1
    :try_start_0
    invoke-super {p0}, Ljava/lang/Object;->clone()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/github/catvod/spider/xbpqxyq/xyq/ǐ$Ϳ;
    :try_end_6
    .catch Ljava/lang/CloneNotSupportedException; {:try_start_0 .. :try_end_6} :catch_1c

    .line 2
    iget-object v1, p0, Lcom/github/catvod/spider/xbpqxyq/xyq/ǐ$Ϳ;->Ԩ:Ljava/nio/charset/Charset;

    invoke-virtual {v1}, Ljava/nio/charset/Charset;->name()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/github/catvod/spider/xbpqxyq/xyq/ǐ$Ϳ;->Ϳ(Ljava/lang/String;)Lcom/github/catvod/spider/xbpqxyq/xyq/ǐ$Ϳ;

    .line 3
    iget-object v1, p0, Lcom/github/catvod/spider/xbpqxyq/xyq/ǐ$Ϳ;->Ϳ:Lcom/github/catvod/spider/xbpqxyq/xyq/ו$Ԫ;

    invoke-virtual {v1}, Ljava/lang/Enum;->name()Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Lcom/github/catvod/spider/xbpqxyq/xyq/ו$Ԫ;->ؠ(Ljava/lang/String;)Lcom/github/catvod/spider/xbpqxyq/xyq/ו$Ԫ;

    move-result-object v1

    iput-object v1, v0, Lcom/github/catvod/spider/xbpqxyq/xyq/ǐ$Ϳ;->Ϳ:Lcom/github/catvod/spider/xbpqxyq/xyq/ו$Ԫ;

    return-object v0

    :catch_1c
    move-exception v0

    .line 4
    new-instance v1, Ljava/lang/RuntimeException;

    invoke-direct {v1, v0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/Throwable;)V

    throw v1
.end method

.method Ԫ()Ljava/nio/charset/CharsetEncoder;
    .registers 2

    .line 1
    iget-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xyq/ǐ$Ϳ;->ԩ:Ljava/lang/ThreadLocal;

    invoke-virtual {v0}, Ljava/lang/ThreadLocal;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/nio/charset/CharsetEncoder;

    if-eqz v0, :cond_b

    goto :goto_f

    .line 2
    :cond_b
    invoke-virtual {p0}, Lcom/github/catvod/spider/xbpqxyq/xyq/ǐ$Ϳ;->Ԯ()Ljava/nio/charset/CharsetEncoder;

    move-result-object v0

    :goto_f
    return-object v0
.end method

.method public ԫ()Lcom/github/catvod/spider/xbpqxyq/xyq/ו$Ԫ;
    .registers 2

    .line 1
    iget-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xyq/ǐ$Ϳ;->Ϳ:Lcom/github/catvod/spider/xbpqxyq/xyq/ו$Ԫ;

    return-object v0
.end method

.method public Ԭ()I
    .registers 2

    .line 1
    iget v0, p0, Lcom/github/catvod/spider/xbpqxyq/xyq/ǐ$Ϳ;->ԭ:I

    return v0
.end method

.method public ԭ()Z
    .registers 2

    .line 1
    iget-boolean v0, p0, Lcom/github/catvod/spider/xbpqxyq/xyq/ǐ$Ϳ;->Ԭ:Z

    return v0
.end method

.method Ԯ()Ljava/nio/charset/CharsetEncoder;
    .registers 3

    .line 1
    iget-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xyq/ǐ$Ϳ;->Ԩ:Ljava/nio/charset/Charset;

    invoke-virtual {v0}, Ljava/nio/charset/Charset;->newEncoder()Ljava/nio/charset/CharsetEncoder;

    move-result-object v0

    .line 2
    iget-object v1, p0, Lcom/github/catvod/spider/xbpqxyq/xyq/ǐ$Ϳ;->ԩ:Ljava/lang/ThreadLocal;

    invoke-virtual {v1, v0}, Ljava/lang/ThreadLocal;->set(Ljava/lang/Object;)V

    .line 3
    invoke-virtual {v0}, Ljava/nio/charset/CharsetEncoder;->charset()Ljava/nio/charset/Charset;

    move-result-object v1

    invoke-virtual {v1}, Ljava/nio/charset/Charset;->name()Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Lcom/github/catvod/spider/xbpqxyq/xyq/ו$Ԩ;->Ϳ(Ljava/lang/String;)Lcom/github/catvod/spider/xbpqxyq/xyq/ו$Ԩ;

    move-result-object v1

    iput-object v1, p0, Lcom/github/catvod/spider/xbpqxyq/xyq/ǐ$Ϳ;->Ԫ:Lcom/github/catvod/spider/xbpqxyq/xyq/ו$Ԩ;

    return-object v0
.end method

.method public ԯ()Z
    .registers 2

    .line 1
    iget-boolean v0, p0, Lcom/github/catvod/spider/xbpqxyq/xyq/ǐ$Ϳ;->ԫ:Z

    return v0
.end method

.method public ֏()Lcom/github/catvod/spider/xbpqxyq/xyq/ǐ$Ϳ$Ϳ;
    .registers 2

    .line 1
    iget-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xyq/ǐ$Ϳ;->Ԯ:Lcom/github/catvod/spider/xbpqxyq/xyq/ǐ$Ϳ$Ϳ;

    return-object v0
.end method
