.class Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ$Ϳ;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lcom/github/catvod/spider/xbpqxyq/xyq/ཬ;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;->ࢹ()Ljava/lang/String;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic Ϳ:Ljava/lang/StringBuilder;

.field final synthetic Ԩ:Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;


# direct methods
.method constructor <init>(Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;Ljava/lang/StringBuilder;)V
    .registers 3

    .line 1
    iput-object p1, p0, Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ$Ϳ;->Ԩ:Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;

    iput-object p2, p0, Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ$Ϳ;->Ϳ:Ljava/lang/StringBuilder;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public Ϳ(Lcom/github/catvod/spider/xbpqxyq/xyq/ւ;I)V
    .registers 3

    .line 1
    instance-of p2, p1, Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;

    if-eqz p2, :cond_24

    .line 2
    move-object p2, p1

    check-cast p2, Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;

    .line 3
    invoke-virtual {p2}, Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;->ࢦ()Z

    move-result p2

    if-eqz p2, :cond_24

    invoke-virtual {p1}, Lcom/github/catvod/spider/xbpqxyq/xyq/ւ;->ވ()Lcom/github/catvod/spider/xbpqxyq/xyq/ւ;

    move-result-object p1

    instance-of p1, p1, Lcom/github/catvod/spider/xbpqxyq/xyq/ŀ;

    if-eqz p1, :cond_24

    iget-object p1, p0, Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ$Ϳ;->Ϳ:Ljava/lang/StringBuilder;

    invoke-static {p1}, Lcom/github/catvod/spider/xbpqxyq/xyq/ŀ;->ޥ(Ljava/lang/StringBuilder;)Z

    move-result p1

    if-nez p1, :cond_24

    .line 4
    iget-object p1, p0, Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ$Ϳ;->Ϳ:Ljava/lang/StringBuilder;

    const/16 p2, 0x20

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    :cond_24
    return-void
.end method

.method public Ԩ(Lcom/github/catvod/spider/xbpqxyq/xyq/ւ;I)V
    .registers 3

    .line 1
    instance-of p2, p1, Lcom/github/catvod/spider/xbpqxyq/xyq/ŀ;

    if-eqz p2, :cond_c

    .line 2
    check-cast p1, Lcom/github/catvod/spider/xbpqxyq/xyq/ŀ;

    .line 3
    iget-object p2, p0, Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ$Ϳ;->Ϳ:Ljava/lang/StringBuilder;

    invoke-static {p2, p1}, Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;->ޟ(Ljava/lang/StringBuilder;Lcom/github/catvod/spider/xbpqxyq/xyq/ŀ;)V

    goto :goto_43

    .line 4
    :cond_c
    instance-of p2, p1, Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;

    if-eqz p2, :cond_43

    .line 5
    check-cast p1, Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;

    .line 6
    iget-object p2, p0, Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ$Ϳ;->Ϳ:Ljava/lang/StringBuilder;

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->length()I

    move-result p2

    if-lez p2, :cond_43

    .line 7
    invoke-virtual {p1}, Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;->ࢦ()Z

    move-result p2

    if-nez p2, :cond_34

    invoke-static {p1}, Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;->ޠ(Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;)Lcom/github/catvod/spider/xbpqxyq/xyq/ȉ;

    move-result-object p1

    invoke-virtual {p1}, Lcom/github/catvod/spider/xbpqxyq/xyq/ȉ;->ԩ()Ljava/lang/String;

    move-result-object p1

    const-string p2, "1030"

    invoke-static {p2}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p2

    invoke-virtual {p1, p2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_43

    :cond_34
    iget-object p1, p0, Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ$Ϳ;->Ϳ:Ljava/lang/StringBuilder;

    .line 8
    invoke-static {p1}, Lcom/github/catvod/spider/xbpqxyq/xyq/ŀ;->ޥ(Ljava/lang/StringBuilder;)Z

    move-result p1

    if-nez p1, :cond_43

    .line 9
    iget-object p1, p0, Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ$Ϳ;->Ϳ:Ljava/lang/StringBuilder;

    const/16 p2, 0x20

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    :cond_43
    :goto_43
    return-void
.end method
