.class public Lcom/github/catvod/spider/xbpqxyq/xyq/ı$Ԩ;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/github/catvod/spider/xbpqxyq/xyq/ı;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "Ԩ"
.end annotation


# instance fields
.field Ϳ:Ljava/lang/StringBuilder;
    .annotation runtime Ljavax/annotation/Nullable;
    .end annotation
.end field

.field final Ԩ:Ljava/lang/String;

.field ԩ:Z


# direct methods
.method public constructor <init>(Ljava/lang/String;)V
    .registers 3

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    invoke-static {}, Lcom/github/catvod/spider/xbpqxyq/xyq/ı;->Ԩ()Ljava/lang/StringBuilder;

    move-result-object v0

    iput-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xyq/ı$Ԩ;->Ϳ:Ljava/lang/StringBuilder;

    const/4 v0, 0x1

    .line 3
    iput-boolean v0, p0, Lcom/github/catvod/spider/xbpqxyq/xyq/ı$Ԩ;->ԩ:Z

    .line 4
    iput-object p1, p0, Lcom/github/catvod/spider/xbpqxyq/xyq/ı$Ԩ;->Ԩ:Ljava/lang/String;

    return-void
.end method


# virtual methods
.method public Ϳ(Ljava/lang/Object;)Lcom/github/catvod/spider/xbpqxyq/xyq/ı$Ԩ;
    .registers 4

    .line 1
    iget-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xyq/ı$Ԩ;->Ϳ:Ljava/lang/StringBuilder;

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xyq/ǃ;->ԯ(Ljava/lang/Object;)V

    .line 2
    iget-boolean v0, p0, Lcom/github/catvod/spider/xbpqxyq/xyq/ı$Ԩ;->ԩ:Z

    if-nez v0, :cond_10

    .line 3
    iget-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xyq/ı$Ԩ;->Ϳ:Ljava/lang/StringBuilder;

    iget-object v1, p0, Lcom/github/catvod/spider/xbpqxyq/xyq/ı$Ԩ;->Ԩ:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 4
    :cond_10
    iget-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xyq/ı$Ԩ;->Ϳ:Ljava/lang/StringBuilder;

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 p1, 0x0

    .line 5
    iput-boolean p1, p0, Lcom/github/catvod/spider/xbpqxyq/xyq/ı$Ԩ;->ԩ:Z

    return-object p0
.end method

.method public Ԩ()Ljava/lang/String;
    .registers 3

    .line 1
    iget-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xyq/ı$Ԩ;->Ϳ:Ljava/lang/StringBuilder;

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xyq/ı;->ށ(Ljava/lang/StringBuilder;)Ljava/lang/String;

    move-result-object v0

    const/4 v1, 0x0

    .line 2
    iput-object v1, p0, Lcom/github/catvod/spider/xbpqxyq/xyq/ı$Ԩ;->Ϳ:Ljava/lang/StringBuilder;

    return-object v0
.end method
