.class public final Lcom/github/catvod/spider/xbpqxyq/xyq/ȋ$ޘ;
.super Lcom/github/catvod/spider/xbpqxyq/xyq/ȋ;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/github/catvod/spider/xbpqxyq/xyq/ȋ;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "ޘ"
.end annotation


# direct methods
.method public constructor <init>()V
    .registers 1

    .line 1
    invoke-direct {p0}, Lcom/github/catvod/spider/xbpqxyq/xyq/ȋ;-><init>()V

    return-void
.end method


# virtual methods
.method public toString()Ljava/lang/String;
    .registers 2

    const-string v0, "48303C3E2E"

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public Ϳ(Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;)Z
    .registers 5

    .line 1
    instance-of v0, p1, Lcom/github/catvod/spider/xbpqxyq/xyq/ǐ;

    const/4 v1, 0x0

    if-eqz v0, :cond_9

    invoke-virtual {p1, v1}, Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;->ࡢ(I)Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;

    move-result-object p1

    :cond_9
    if-ne p2, p1, :cond_c

    const/4 v1, 0x1

    :cond_c
    return v1
.end method
