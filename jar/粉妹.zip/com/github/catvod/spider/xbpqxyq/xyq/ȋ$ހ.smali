.class public final Lcom/github/catvod/spider/xbpqxyq/xyq/ȋ$ހ;
.super Lcom/github/catvod/spider/xbpqxyq/xyq/ȋ;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/github/catvod/spider/xbpqxyq/xyq/ȋ;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "ހ"
.end annotation


# instance fields
.field Ϳ:Ljava/lang/String;

.field Ԩ:Ljava/util/regex/Pattern;


# direct methods
.method public constructor <init>(Ljava/lang/String;Ljava/util/regex/Pattern;)V
    .registers 3

    .line 1
    invoke-direct {p0}, Lcom/github/catvod/spider/xbpqxyq/xyq/ȋ;-><init>()V

    .line 2
    invoke-static {p1}, Lcom/github/catvod/spider/xbpqxyq/xyq/ۦ;->Ԩ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    iput-object p1, p0, Lcom/github/catvod/spider/xbpqxyq/xyq/ȋ$ހ;->Ϳ:Ljava/lang/String;

    .line 3
    iput-object p2, p0, Lcom/github/catvod/spider/xbpqxyq/xyq/ȋ$ހ;->Ԩ:Ljava/util/regex/Pattern;

    return-void
.end method


# virtual methods
.method public toString()Ljava/lang/String;
    .registers 4

    const/4 v0, 0x2

    new-array v0, v0, [Ljava/lang/Object;

    .line 1
    iget-object v1, p0, Lcom/github/catvod/spider/xbpqxyq/xyq/ȋ$ހ;->Ϳ:Ljava/lang/String;

    const/4 v2, 0x0

    aput-object v1, v0, v2

    iget-object v1, p0, Lcom/github/catvod/spider/xbpqxyq/xyq/ȋ$ހ;->Ԩ:Ljava/util/regex/Pattern;

    invoke-virtual {v1}, Ljava/util/regex/Pattern;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v2, 0x1

    aput-object v1, v0, v2

    const-string v1, "2967202F6761011F"

    invoke-static {v1}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-static {v1, v0}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public Ϳ(Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;)Z
    .registers 4

    .line 1
    iget-object p1, p0, Lcom/github/catvod/spider/xbpqxyq/xyq/ȋ$ހ;->Ϳ:Ljava/lang/String;

    invoke-virtual {p2, p1}, Lcom/github/catvod/spider/xbpqxyq/xyq/ւ;->ބ(Ljava/lang/String;)Z

    move-result p1

    if-eqz p1, :cond_1c

    iget-object p1, p0, Lcom/github/catvod/spider/xbpqxyq/xyq/ȋ$ހ;->Ԩ:Ljava/util/regex/Pattern;

    iget-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xyq/ȋ$ހ;->Ϳ:Ljava/lang/String;

    invoke-virtual {p2, v0}, Lcom/github/catvod/spider/xbpqxyq/xyq/ւ;->ԩ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p2

    invoke-virtual {p1, p2}, Ljava/util/regex/Pattern;->matcher(Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;

    move-result-object p1

    invoke-virtual {p1}, Ljava/util/regex/Matcher;->find()Z

    move-result p1

    if-eqz p1, :cond_1c

    const/4 p1, 0x1

    goto :goto_1d

    :cond_1c
    const/4 p1, 0x0

    :goto_1d
    return p1
.end method
