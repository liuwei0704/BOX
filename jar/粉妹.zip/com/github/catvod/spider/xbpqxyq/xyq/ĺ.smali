.class public Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;
.super Lcom/github/catvod/spider/xbpqxyq/xyq/ւ;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ$Ԩ;
    }
.end annotation


# static fields
.field private static final Ԫ:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;",
            ">;"
        }
    .end annotation
.end field

.field private static final ԫ:Ljava/util/regex/Pattern;

.field private static final Ԭ:Ljava/lang/String;


# instance fields
.field private ԭ:Lcom/github/catvod/spider/xbpqxyq/xyq/ȉ;

.field private Ԯ:Ljava/lang/ref/WeakReference;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/lang/ref/WeakReference<",
            "Ljava/util/List<",
            "Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;",
            ">;>;"
        }
    .end annotation

    .annotation runtime Ljavax/annotation/Nullable;
    .end annotation
.end field

.field ԯ:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lcom/github/catvod/spider/xbpqxyq/xyq/ւ;",
            ">;"
        }
    .end annotation
.end field

.field private ֏:Lcom/github/catvod/spider/xbpqxyq/xyq/ྋ;
    .annotation runtime Ljavax/annotation/Nullable;
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .registers 1

    .line 1
    invoke-static {}, Ljava/util/Collections;->emptyList()Ljava/util/List;

    move-result-object v0

    sput-object v0, Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;->Ԫ:Ljava/util/List;

    const-string v0, "2E3178"

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 2
    invoke-static {v0}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    move-result-object v0

    sput-object v0, Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;->ԫ:Ljava/util/regex/Pattern;

    const-string v0, "102320340F361B"

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 3
    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xyq/ྋ;->އ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;->Ԭ:Ljava/lang/String;

    return-void
.end method

.method public constructor <init>(Lcom/github/catvod/spider/xbpqxyq/xyq/ȉ;Ljava/lang/String;)V
    .registers 4

    const/4 v0, 0x0

    .line 8
    invoke-direct {p0, p1, p2, v0}, Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;-><init>(Lcom/github/catvod/spider/xbpqxyq/xyq/ȉ;Ljava/lang/String;Lcom/github/catvod/spider/xbpqxyq/xyq/ྋ;)V

    return-void
.end method

.method public constructor <init>(Lcom/github/catvod/spider/xbpqxyq/xyq/ȉ;Ljava/lang/String;Lcom/github/catvod/spider/xbpqxyq/xyq/ྋ;)V
    .registers 5
    .param p2  # Ljava/lang/String;
        .annotation runtime Ljavax/annotation/Nullable;
        .end annotation
    .end param
    .param p3  # Lcom/github/catvod/spider/xbpqxyq/xyq/ྋ;
        .annotation runtime Ljavax/annotation/Nullable;
        .end annotation
    .end param

    .line 2
    invoke-direct {p0}, Lcom/github/catvod/spider/xbpqxyq/xyq/ւ;-><init>()V

    .line 3
    invoke-static {p1}, Lcom/github/catvod/spider/xbpqxyq/xyq/ǃ;->ԯ(Ljava/lang/Object;)V

    .line 4
    sget-object v0, Lcom/github/catvod/spider/xbpqxyq/xyq/ւ;->Ϳ:Ljava/util/List;

    iput-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;->ԯ:Ljava/util/List;

    .line 5
    iput-object p3, p0, Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;->֏:Lcom/github/catvod/spider/xbpqxyq/xyq/ྋ;

    .line 6
    iput-object p1, p0, Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;->ԭ:Lcom/github/catvod/spider/xbpqxyq/xyq/ȉ;

    if-eqz p2, :cond_13

    .line 7
    invoke-virtual {p0, p2}, Lcom/github/catvod/spider/xbpqxyq/xyq/ւ;->ޚ(Ljava/lang/String;)V

    :cond_13
    return-void
.end method

.method public constructor <init>(Ljava/lang/String;)V
    .registers 4

    .line 1
    invoke-static {p1}, Lcom/github/catvod/spider/xbpqxyq/xyq/ȉ;->ނ(Ljava/lang/String;)Lcom/github/catvod/spider/xbpqxyq/xyq/ȉ;

    move-result-object p1

    const-string v0, ""

    const/4 v1, 0x0

    invoke-direct {p0, p1, v0, v1}, Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;-><init>(Lcom/github/catvod/spider/xbpqxyq/xyq/ȉ;Ljava/lang/String;Lcom/github/catvod/spider/xbpqxyq/xyq/ྋ;)V

    return-void
.end method

.method static synthetic ޟ(Ljava/lang/StringBuilder;Lcom/github/catvod/spider/xbpqxyq/xyq/ŀ;)V
    .registers 2

    .line 1
    invoke-static {p0, p1}, Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;->ޤ(Ljava/lang/StringBuilder;Lcom/github/catvod/spider/xbpqxyq/xyq/ŀ;)V

    return-void
.end method

.method static synthetic ޠ(Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;)Lcom/github/catvod/spider/xbpqxyq/xyq/ȉ;
    .registers 1

    .line 1
    iget-object p0, p0, Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;->ԭ:Lcom/github/catvod/spider/xbpqxyq/xyq/ȉ;

    return-object p0
.end method

.method private static ޡ(Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;Lcom/github/catvod/spider/xbpqxyq/xyq/ำ;)V
    .registers 4

    .line 1
    invoke-virtual {p0}, Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;->ࢭ()Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;

    move-result-object p0

    if-eqz p0, :cond_1c

    .line 2
    invoke-virtual {p0}, Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;->ࢸ()Ljava/lang/String;

    move-result-object v0

    const-string v1, "51303C3E2E"

    invoke-static {v1}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_1c

    .line 3
    invoke-virtual {p1, p0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 4
    invoke-static {p0, p1}, Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;->ޡ(Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;Lcom/github/catvod/spider/xbpqxyq/xyq/ำ;)V

    :cond_1c
    return-void
.end method

.method private static ޤ(Ljava/lang/StringBuilder;Lcom/github/catvod/spider/xbpqxyq/xyq/ŀ;)V
    .registers 4

    .line 1
    invoke-virtual {p1}, Lcom/github/catvod/spider/xbpqxyq/xyq/ŀ;->ޣ()Ljava/lang/String;

    move-result-object v0

    .line 2
    iget-object v1, p1, Lcom/github/catvod/spider/xbpqxyq/xyq/ւ;->Ԩ:Lcom/github/catvod/spider/xbpqxyq/xyq/ւ;

    invoke-static {v1}, Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;->ࢯ(Lcom/github/catvod/spider/xbpqxyq/xyq/ւ;)Z

    move-result v1

    if-nez v1, :cond_19

    instance-of p1, p1, Lcom/github/catvod/spider/xbpqxyq/xyq/ˍ;

    if-eqz p1, :cond_11

    goto :goto_19

    .line 3
    :cond_11
    invoke-static {p0}, Lcom/github/catvod/spider/xbpqxyq/xyq/ŀ;->ޥ(Ljava/lang/StringBuilder;)Z

    move-result p1

    invoke-static {p0, v0, p1}, Lcom/github/catvod/spider/xbpqxyq/xyq/ı;->Ϳ(Ljava/lang/StringBuilder;Ljava/lang/String;Z)V

    goto :goto_1c

    .line 4
    :cond_19
    :goto_19
    invoke-virtual {p0, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    :goto_1c
    return-void
.end method

.method private static ޱ(Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;Ljava/lang/StringBuilder;)V
    .registers 3

    .line 1
    iget-object p0, p0, Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;->ԭ:Lcom/github/catvod/spider/xbpqxyq/xyq/ȉ;

    invoke-virtual {p0}, Lcom/github/catvod/spider/xbpqxyq/xyq/ȉ;->ԩ()Ljava/lang/String;

    move-result-object p0

    const-string v0, "1030"

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p0

    if-eqz p0, :cond_21

    invoke-static {p1}, Lcom/github/catvod/spider/xbpqxyq/xyq/ŀ;->ޥ(Ljava/lang/StringBuilder;)Z

    move-result p0

    if-nez p0, :cond_21

    const-string p0, "52"

    invoke-static {p0}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    .line 2
    invoke-virtual {p1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    :cond_21
    return-void
.end method

.method private static ࢥ(Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;Ljava/util/List;)I
    .registers 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<E:",
            "Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;",
            ">(",
            "Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;",
            "Ljava/util/List<",
            "TE;>;)I"
        }
    .end annotation

    .line 1
    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result v0

    const/4 v1, 0x0

    const/4 v2, 0x0

    :goto_6
    if-ge v2, v0, :cond_12

    .line 2
    invoke-interface {p1, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v3

    if-ne v3, p0, :cond_f

    return v2

    :cond_f
    add-int/lit8 v2, v2, 0x1

    goto :goto_6

    :cond_12
    return v1
.end method

.method private ࢧ(Lcom/github/catvod/spider/xbpqxyq/xyq/ǐ$Ϳ;)Z
    .registers 3

    .line 1
    iget-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;->ԭ:Lcom/github/catvod/spider/xbpqxyq/xyq/ȉ;

    invoke-virtual {v0}, Lcom/github/catvod/spider/xbpqxyq/xyq/ȉ;->Ԩ()Z

    move-result v0

    if-nez v0, :cond_25

    invoke-virtual {p0}, Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;->ࢭ()Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;

    move-result-object v0

    if-eqz v0, :cond_1c

    invoke-virtual {p0}, Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;->ࢭ()Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;

    move-result-object v0

    invoke-virtual {v0}, Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;->ࢷ()Lcom/github/catvod/spider/xbpqxyq/xyq/ȉ;

    move-result-object v0

    invoke-virtual {v0}, Lcom/github/catvod/spider/xbpqxyq/xyq/ȉ;->Ԩ()Z

    move-result v0

    if-nez v0, :cond_25

    :cond_1c
    invoke-virtual {p1}, Lcom/github/catvod/spider/xbpqxyq/xyq/ǐ$Ϳ;->ԭ()Z

    move-result p1

    if-eqz p1, :cond_23

    goto :goto_25

    :cond_23
    const/4 p1, 0x0

    goto :goto_26

    :cond_25
    :goto_25
    const/4 p1, 0x1

    :goto_26
    return p1
.end method

.method private ࢨ(Lcom/github/catvod/spider/xbpqxyq/xyq/ǐ$Ϳ;)Z
    .registers 3

    .line 1
    invoke-virtual {p0}, Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;->ࢷ()Lcom/github/catvod/spider/xbpqxyq/xyq/ȉ;

    move-result-object v0

    invoke-virtual {v0}, Lcom/github/catvod/spider/xbpqxyq/xyq/ȉ;->ԭ()Z

    move-result v0

    if-eqz v0, :cond_32

    .line 2
    invoke-virtual {p0}, Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;->ࢷ()Lcom/github/catvod/spider/xbpqxyq/xyq/ȉ;

    move-result-object v0

    invoke-virtual {v0}, Lcom/github/catvod/spider/xbpqxyq/xyq/ȉ;->ԫ()Z

    move-result v0

    if-nez v0, :cond_32

    .line 3
    invoke-virtual {p0}, Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;->ࢭ()Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;

    move-result-object v0

    if-eqz v0, :cond_24

    invoke-virtual {p0}, Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;->ࢭ()Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;

    move-result-object v0

    invoke-virtual {v0}, Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;->ࢦ()Z

    move-result v0

    if-eqz v0, :cond_32

    .line 4
    :cond_24
    invoke-virtual {p0}, Lcom/github/catvod/spider/xbpqxyq/xyq/ւ;->ޒ()Lcom/github/catvod/spider/xbpqxyq/xyq/ւ;

    move-result-object v0

    if-eqz v0, :cond_32

    .line 5
    invoke-virtual {p1}, Lcom/github/catvod/spider/xbpqxyq/xyq/ǐ$Ϳ;->ԭ()Z

    move-result p1

    if-nez p1, :cond_32

    const/4 p1, 0x1

    goto :goto_33

    :cond_32
    const/4 p1, 0x0

    :goto_33
    return p1
.end method

.method private ࢬ(Ljava/lang/StringBuilder;)V
    .registers 5

    .line 1
    iget-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;->ԯ:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :cond_6
    :goto_6
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_26

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcom/github/catvod/spider/xbpqxyq/xyq/ւ;

    .line 2
    instance-of v2, v1, Lcom/github/catvod/spider/xbpqxyq/xyq/ŀ;

    if-eqz v2, :cond_1c

    .line 3
    check-cast v1, Lcom/github/catvod/spider/xbpqxyq/xyq/ŀ;

    .line 4
    invoke-static {p1, v1}, Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;->ޤ(Ljava/lang/StringBuilder;Lcom/github/catvod/spider/xbpqxyq/xyq/ŀ;)V

    goto :goto_6

    .line 5
    :cond_1c
    instance-of v2, v1, Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;

    if-eqz v2, :cond_6

    .line 6
    check-cast v1, Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;

    invoke-static {v1, p1}, Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;->ޱ(Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;Ljava/lang/StringBuilder;)V

    goto :goto_6

    :cond_26
    return-void
.end method

.method static ࢯ(Lcom/github/catvod/spider/xbpqxyq/xyq/ւ;)Z
    .registers 5
    .param p0  # Lcom/github/catvod/spider/xbpqxyq/xyq/ւ;
        .annotation runtime Ljavax/annotation/Nullable;
        .end annotation
    .end param

    .line 1
    instance-of v0, p0, Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;

    const/4 v1, 0x0

    if-eqz v0, :cond_1c

    .line 2
    check-cast p0, Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;

    const/4 v0, 0x0

    .line 3
    :cond_8
    iget-object v2, p0, Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;->ԭ:Lcom/github/catvod/spider/xbpqxyq/xyq/ȉ;

    invoke-virtual {v2}, Lcom/github/catvod/spider/xbpqxyq/xyq/ȉ;->ؠ()Z

    move-result v2

    const/4 v3, 0x1

    if-eqz v2, :cond_12

    return v3

    .line 4
    :cond_12
    invoke-virtual {p0}, Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;->ࢭ()Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;

    move-result-object p0

    add-int/2addr v0, v3

    const/4 v2, 0x6

    if-ge v0, v2, :cond_1c

    if-nez p0, :cond_8

    :cond_1c
    return v1
.end method

.method private static ࢲ(Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;Ljava/lang/String;)Ljava/lang/String;
    .registers 3

    :goto_0
    if-eqz p0, :cond_18

    .line 1
    iget-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;->֏:Lcom/github/catvod/spider/xbpqxyq/xyq/ྋ;

    if-eqz v0, :cond_13

    invoke-virtual {v0, p1}, Lcom/github/catvod/spider/xbpqxyq/xyq/ྋ;->ށ(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_13

    .line 2
    iget-object p0, p0, Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;->֏:Lcom/github/catvod/spider/xbpqxyq/xyq/ྋ;

    invoke-virtual {p0, p1}, Lcom/github/catvod/spider/xbpqxyq/xyq/ྋ;->ؠ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    return-object p0

    .line 3
    :cond_13
    invoke-virtual {p0}, Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;->ࢭ()Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;

    move-result-object p0

    goto :goto_0

    :cond_18
    const-string p0, ""

    return-object p0
.end method


# virtual methods
.method public bridge synthetic clone()Ljava/lang/Object;
    .registers 2

    .line 1
    invoke-virtual {p0}, Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;->ࡥ()Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;

    move-result-object v0

    return-object v0
.end method

.method public ԫ()Lcom/github/catvod/spider/xbpqxyq/xyq/ྋ;
    .registers 2

    .line 1
    iget-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;->֏:Lcom/github/catvod/spider/xbpqxyq/xyq/ྋ;

    if-nez v0, :cond_b

    .line 2
    new-instance v0, Lcom/github/catvod/spider/xbpqxyq/xyq/ྋ;

    invoke-direct {v0}, Lcom/github/catvod/spider/xbpqxyq/xyq/ྋ;-><init>()V

    iput-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;->֏:Lcom/github/catvod/spider/xbpqxyq/xyq/ྋ;

    .line 3
    :cond_b
    iget-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;->֏:Lcom/github/catvod/spider/xbpqxyq/xyq/ྋ;

    return-object v0
.end method

.method public Ԭ()Ljava/lang/String;
    .registers 2

    .line 1
    sget-object v0, Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;->Ԭ:Ljava/lang/String;

    invoke-static {p0, v0}, Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;->ࢲ(Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public ԯ()I
    .registers 2

    .line 1
    iget-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;->ԯ:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v0

    return v0
.end method

.method public bridge synthetic ؠ()Lcom/github/catvod/spider/xbpqxyq/xyq/ւ;
    .registers 2

    .line 1
    invoke-virtual {p0}, Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;->ࡥ()Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;

    move-result-object v0

    return-object v0
.end method

.method protected bridge synthetic ހ(Lcom/github/catvod/spider/xbpqxyq/xyq/ւ;)Lcom/github/catvod/spider/xbpqxyq/xyq/ւ;
    .registers 2
    .param p1  # Lcom/github/catvod/spider/xbpqxyq/xyq/ւ;
        .annotation runtime Ljavax/annotation/Nullable;
        .end annotation
    .end param

    .line 1
    invoke-virtual {p0, p1}, Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;->ࡧ(Lcom/github/catvod/spider/xbpqxyq/xyq/ւ;)Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;

    move-result-object p1

    return-object p1
.end method

.method protected ށ(Ljava/lang/String;)V
    .registers 4

    .line 1
    invoke-virtual {p0}, Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;->ԫ()Lcom/github/catvod/spider/xbpqxyq/xyq/ྋ;

    move-result-object v0

    sget-object v1, Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;->Ԭ:Ljava/lang/String;

    invoke-virtual {v0, v1, p1}, Lcom/github/catvod/spider/xbpqxyq/xyq/ྋ;->ފ(Ljava/lang/String;Ljava/lang/String;)Lcom/github/catvod/spider/xbpqxyq/xyq/ྋ;

    return-void
.end method

.method public bridge synthetic ނ()Lcom/github/catvod/spider/xbpqxyq/xyq/ւ;
    .registers 2

    .line 1
    invoke-virtual {p0}, Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;->ࡩ()Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;

    move-result-object v0

    return-object v0
.end method

.method protected ރ()Ljava/util/List;
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lcom/github/catvod/spider/xbpqxyq/xyq/ւ;",
            ">;"
        }
    .end annotation

    .line 1
    iget-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;->ԯ:Ljava/util/List;

    sget-object v1, Lcom/github/catvod/spider/xbpqxyq/xyq/ւ;->Ϳ:Ljava/util/List;

    if-ne v0, v1, :cond_e

    .line 2
    new-instance v0, Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ$Ԩ;

    const/4 v1, 0x4

    invoke-direct {v0, p0, v1}, Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ$Ԩ;-><init>(Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;I)V

    iput-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;->ԯ:Ljava/util/List;

    .line 3
    :cond_e
    iget-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;->ԯ:Ljava/util/List;

    return-object v0
.end method

.method protected ޅ()Z
    .registers 2

    .line 1
    iget-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;->֏:Lcom/github/catvod/spider/xbpqxyq/xyq/ྋ;

    if-eqz v0, :cond_6

    const/4 v0, 0x1

    goto :goto_7

    :cond_6
    const/4 v0, 0x0

    :goto_7
    return v0
.end method

.method public މ()Ljava/lang/String;
    .registers 2

    .line 1
    iget-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;->ԭ:Lcom/github/catvod/spider/xbpqxyq/xyq/ȉ;

    invoke-virtual {v0}, Lcom/github/catvod/spider/xbpqxyq/xyq/ȉ;->ԩ()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method ފ()V
    .registers 2

    .line 1
    invoke-super {p0}, Lcom/github/catvod/spider/xbpqxyq/xyq/ւ;->ފ()V

    const/4 v0, 0x0

    .line 2
    iput-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;->Ԯ:Ljava/lang/ref/WeakReference;

    return-void
.end method

.method ލ(Ljava/lang/Appendable;ILcom/github/catvod/spider/xbpqxyq/xyq/ǐ$Ϳ;)V
    .registers 5

    .line 1
    invoke-virtual {p3}, Lcom/github/catvod/spider/xbpqxyq/xyq/ǐ$Ϳ;->ԯ()Z

    move-result v0

    if-eqz v0, :cond_26

    invoke-direct {p0, p3}, Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;->ࢧ(Lcom/github/catvod/spider/xbpqxyq/xyq/ǐ$Ϳ;)Z

    move-result v0

    if-eqz v0, :cond_26

    invoke-direct {p0, p3}, Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;->ࢨ(Lcom/github/catvod/spider/xbpqxyq/xyq/ǐ$Ϳ;)Z

    move-result v0

    if-nez v0, :cond_26

    .line 2
    instance-of v0, p1, Ljava/lang/StringBuilder;

    if-eqz v0, :cond_23

    .line 3
    move-object v0, p1

    check-cast v0, Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->length()I

    move-result v0

    if-lez v0, :cond_26

    .line 4
    invoke-virtual {p0, p1, p2, p3}, Lcom/github/catvod/spider/xbpqxyq/xyq/ւ;->އ(Ljava/lang/Appendable;ILcom/github/catvod/spider/xbpqxyq/xyq/ǐ$Ϳ;)V

    goto :goto_26

    .line 5
    :cond_23
    invoke-virtual {p0, p1, p2, p3}, Lcom/github/catvod/spider/xbpqxyq/xyq/ւ;->އ(Ljava/lang/Appendable;ILcom/github/catvod/spider/xbpqxyq/xyq/ǐ$Ϳ;)V

    :cond_26
    :goto_26
    const/16 p2, 0x3c

    .line 6
    invoke-interface {p1, p2}, Ljava/lang/Appendable;->append(C)Ljava/lang/Appendable;

    move-result-object p2

    invoke-virtual {p0}, Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;->ࢸ()Ljava/lang/String;

    move-result-object v0

    invoke-interface {p2, v0}, Ljava/lang/Appendable;->append(Ljava/lang/CharSequence;)Ljava/lang/Appendable;

    .line 7
    iget-object p2, p0, Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;->֏:Lcom/github/catvod/spider/xbpqxyq/xyq/ྋ;

    if-eqz p2, :cond_3a

    invoke-virtual {p2, p1, p3}, Lcom/github/catvod/spider/xbpqxyq/xyq/ྋ;->ބ(Ljava/lang/Appendable;Lcom/github/catvod/spider/xbpqxyq/xyq/ǐ$Ϳ;)V

    .line 8
    :cond_3a
    iget-object p2, p0, Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;->ԯ:Ljava/util/List;

    invoke-interface {p2}, Ljava/util/List;->isEmpty()Z

    move-result p2

    const/16 v0, 0x3e

    if-eqz p2, :cond_6a

    iget-object p2, p0, Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;->ԭ:Lcom/github/catvod/spider/xbpqxyq/xyq/ȉ;

    invoke-virtual {p2}, Lcom/github/catvod/spider/xbpqxyq/xyq/ȉ;->ԯ()Z

    move-result p2

    if-eqz p2, :cond_6a

    .line 9
    invoke-virtual {p3}, Lcom/github/catvod/spider/xbpqxyq/xyq/ǐ$Ϳ;->֏()Lcom/github/catvod/spider/xbpqxyq/xyq/ǐ$Ϳ$Ϳ;

    move-result-object p2

    sget-object p3, Lcom/github/catvod/spider/xbpqxyq/xyq/ǐ$Ϳ$Ϳ;->Ϳ:Lcom/github/catvod/spider/xbpqxyq/xyq/ǐ$Ϳ$Ϳ;

    if-ne p2, p3, :cond_60

    iget-object p2, p0, Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;->ԭ:Lcom/github/catvod/spider/xbpqxyq/xyq/ȉ;

    invoke-virtual {p2}, Lcom/github/catvod/spider/xbpqxyq/xyq/ȉ;->ԫ()Z

    move-result p2

    if-eqz p2, :cond_60

    .line 10
    invoke-interface {p1, v0}, Ljava/lang/Appendable;->append(C)Ljava/lang/Appendable;

    goto :goto_6d

    :cond_60
    const-string p2, "526D6D"

    invoke-static {p2}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p2

    .line 11
    invoke-interface {p1, p2}, Ljava/lang/Appendable;->append(Ljava/lang/CharSequence;)Ljava/lang/Appendable;

    goto :goto_6d

    .line 12
    :cond_6a
    invoke-interface {p1, v0}, Ljava/lang/Appendable;->append(C)Ljava/lang/Appendable;

    :goto_6d
    return-void
.end method

.method ގ(Ljava/lang/Appendable;ILcom/github/catvod/spider/xbpqxyq/xyq/ǐ$Ϳ;)V
    .registers 6

    .line 1
    iget-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;->ԯ:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->isEmpty()Z

    move-result v0

    if-eqz v0, :cond_10

    iget-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;->ԭ:Lcom/github/catvod/spider/xbpqxyq/xyq/ȉ;

    invoke-virtual {v0}, Lcom/github/catvod/spider/xbpqxyq/xyq/ȉ;->ԯ()Z

    move-result v0

    if-nez v0, :cond_62

    .line 2
    :cond_10
    invoke-virtual {p3}, Lcom/github/catvod/spider/xbpqxyq/xyq/ǐ$Ϳ;->ԯ()Z

    move-result v0

    if-eqz v0, :cond_4b

    iget-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;->ԯ:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_4b

    iget-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;->ԭ:Lcom/github/catvod/spider/xbpqxyq/xyq/ȉ;

    .line 3
    invoke-virtual {v0}, Lcom/github/catvod/spider/xbpqxyq/xyq/ȉ;->Ԩ()Z

    move-result v0

    if-nez v0, :cond_48

    invoke-virtual {p3}, Lcom/github/catvod/spider/xbpqxyq/xyq/ǐ$Ϳ;->ԭ()Z

    move-result v0

    if-eqz v0, :cond_4b

    iget-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;->ԯ:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v0

    const/4 v1, 0x1

    if-gt v0, v1, :cond_48

    iget-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;->ԯ:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v0

    if-ne v0, v1, :cond_4b

    iget-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;->ԯ:Ljava/util/List;

    const/4 v1, 0x0

    invoke-interface {v0, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    instance-of v0, v0, Lcom/github/catvod/spider/xbpqxyq/xyq/ŀ;

    if-nez v0, :cond_4b

    .line 4
    :cond_48
    invoke-virtual {p0, p1, p2, p3}, Lcom/github/catvod/spider/xbpqxyq/xyq/ւ;->އ(Ljava/lang/Appendable;ILcom/github/catvod/spider/xbpqxyq/xyq/ǐ$Ϳ;)V

    :cond_4b
    const-string p2, "4E6D"

    invoke-static {p2}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p2

    .line 5
    invoke-interface {p1, p2}, Ljava/lang/Appendable;->append(Ljava/lang/CharSequence;)Ljava/lang/Appendable;

    move-result-object p1

    invoke-virtual {p0}, Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;->ࢸ()Ljava/lang/String;

    move-result-object p2

    invoke-interface {p1, p2}, Ljava/lang/Appendable;->append(Ljava/lang/CharSequence;)Ljava/lang/Appendable;

    move-result-object p1

    const/16 p2, 0x3e

    invoke-interface {p1, p2}, Ljava/lang/Appendable;->append(C)Ljava/lang/Appendable;

    :cond_62
    return-void
.end method

.method public bridge synthetic ސ()Lcom/github/catvod/spider/xbpqxyq/xyq/ւ;
    .registers 2

    .line 1
    invoke-virtual {p0}, Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;->ࢭ()Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;

    move-result-object v0

    return-object v0
.end method

.method public bridge synthetic ޙ()Lcom/github/catvod/spider/xbpqxyq/xyq/ւ;
    .registers 2

    .line 1
    invoke-virtual {p0}, Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;->ࢱ()Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;

    move-result-object v0

    return-object v0
.end method

.method public ޢ(Lcom/github/catvod/spider/xbpqxyq/xyq/ւ;)Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;
    .registers 3

    .line 1
    invoke-static {p1}, Lcom/github/catvod/spider/xbpqxyq/xyq/ǃ;->ԯ(Ljava/lang/Object;)V

    .line 2
    invoke-virtual {p0, p1}, Lcom/github/catvod/spider/xbpqxyq/xyq/ւ;->ޖ(Lcom/github/catvod/spider/xbpqxyq/xyq/ւ;)V

    .line 3
    invoke-virtual {p0}, Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;->ރ()Ljava/util/List;

    .line 4
    iget-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;->ԯ:Ljava/util/List;

    invoke-interface {v0, p1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 5
    iget-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;->ԯ:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v0

    add-int/lit8 v0, v0, -0x1

    invoke-virtual {p1, v0}, Lcom/github/catvod/spider/xbpqxyq/xyq/ւ;->ޜ(I)V

    return-object p0
.end method

.method public ޣ(Ljava/lang/String;)Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;
    .registers 4

    .line 1
    new-instance v0, Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;

    invoke-static {p0}, Lcom/github/catvod/spider/xbpqxyq/xyq/г;->Ԩ(Lcom/github/catvod/spider/xbpqxyq/xyq/ւ;)Lcom/github/catvod/spider/xbpqxyq/xyq/ͱ;

    move-result-object v1

    invoke-virtual {v1}, Lcom/github/catvod/spider/xbpqxyq/xyq/ͱ;->Ԭ()Lcom/github/catvod/spider/xbpqxyq/xyq/ॽ;

    move-result-object v1

    invoke-static {p1, v1}, Lcom/github/catvod/spider/xbpqxyq/xyq/ȉ;->ރ(Ljava/lang/String;Lcom/github/catvod/spider/xbpqxyq/xyq/ॽ;)Lcom/github/catvod/spider/xbpqxyq/xyq/ȉ;

    move-result-object p1

    invoke-virtual {p0}, Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;->Ԭ()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, p1, v1}, Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;-><init>(Lcom/github/catvod/spider/xbpqxyq/xyq/ȉ;Ljava/lang/String;)V

    .line 2
    invoke-virtual {p0, v0}, Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;->ޢ(Lcom/github/catvod/spider/xbpqxyq/xyq/ւ;)Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;

    return-object v0
.end method

.method public ޥ(Ljava/lang/String;)Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;
    .registers 3

    .line 1
    invoke-static {p1}, Lcom/github/catvod/spider/xbpqxyq/xyq/ǃ;->ԯ(Ljava/lang/Object;)V

    .line 2
    new-instance v0, Lcom/github/catvod/spider/xbpqxyq/xyq/ŀ;

    invoke-direct {v0, p1}, Lcom/github/catvod/spider/xbpqxyq/xyq/ŀ;-><init>(Ljava/lang/String;)V

    .line 3
    invoke-virtual {p0, v0}, Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;->ޢ(Lcom/github/catvod/spider/xbpqxyq/xyq/ւ;)Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;

    return-object p0
.end method

.method public ࡠ(Ljava/lang/String;Ljava/lang/String;)Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;
    .registers 3

    .line 1
    invoke-super {p0, p1, p2}, Lcom/github/catvod/spider/xbpqxyq/xyq/ւ;->Ԫ(Ljava/lang/String;Ljava/lang/String;)Lcom/github/catvod/spider/xbpqxyq/xyq/ւ;

    return-object p0
.end method

.method public ࡡ(Lcom/github/catvod/spider/xbpqxyq/xyq/ւ;)Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;
    .registers 2

    .line 1
    invoke-super {p0, p1}, Lcom/github/catvod/spider/xbpqxyq/xyq/ւ;->ԭ(Lcom/github/catvod/spider/xbpqxyq/xyq/ւ;)Lcom/github/catvod/spider/xbpqxyq/xyq/ւ;

    move-result-object p1

    check-cast p1, Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;

    return-object p1
.end method

.method public ࡢ(I)Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;
    .registers 3

    .line 1
    invoke-virtual {p0}, Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;->ࡣ()Ljava/util/List;

    move-result-object v0

    invoke-interface {v0, p1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;

    return-object p1
.end method

.method ࡣ()Ljava/util/List;
    .registers 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;",
            ">;"
        }
    .end annotation

    .line 1
    invoke-virtual {p0}, Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;->ԯ()I

    move-result v0

    if-nez v0, :cond_9

    .line 2
    sget-object v0, Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;->Ԫ:Ljava/util/List;

    return-object v0

    .line 3
    :cond_9
    iget-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;->Ԯ:Ljava/lang/ref/WeakReference;

    if-eqz v0, :cond_15

    invoke-virtual {v0}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/util/List;

    if-nez v0, :cond_3f

    .line 4
    :cond_15
    iget-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;->ԯ:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v0

    .line 5
    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1, v0}, Ljava/util/ArrayList;-><init>(I)V

    const/4 v2, 0x0

    :goto_21
    if-ge v2, v0, :cond_37

    .line 6
    iget-object v3, p0, Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;->ԯ:Ljava/util/List;

    invoke-interface {v3, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lcom/github/catvod/spider/xbpqxyq/xyq/ւ;

    .line 7
    instance-of v4, v3, Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;

    if-eqz v4, :cond_34

    .line 8
    check-cast v3, Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;

    invoke-interface {v1, v3}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    :cond_34
    add-int/lit8 v2, v2, 0x1

    goto :goto_21

    .line 9
    :cond_37
    new-instance v0, Ljava/lang/ref/WeakReference;

    invoke-direct {v0, v1}, Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V

    iput-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;->Ԯ:Ljava/lang/ref/WeakReference;

    move-object v0, v1

    :cond_3f
    return-object v0
.end method

.method public ࡤ()Lcom/github/catvod/spider/xbpqxyq/xyq/ำ;
    .registers 3

    .line 1
    new-instance v0, Lcom/github/catvod/spider/xbpqxyq/xyq/ำ;

    invoke-virtual {p0}, Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;->ࡣ()Ljava/util/List;

    move-result-object v1

    invoke-direct {v0, v1}, Lcom/github/catvod/spider/xbpqxyq/xyq/ำ;-><init>(Ljava/util/List;)V

    return-object v0
.end method

.method public ࡥ()Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;
    .registers 2

    .line 1
    invoke-super {p0}, Lcom/github/catvod/spider/xbpqxyq/xyq/ւ;->ؠ()Lcom/github/catvod/spider/xbpqxyq/xyq/ւ;

    move-result-object v0

    check-cast v0, Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;

    return-object v0
.end method

.method public ࡦ()Ljava/lang/String;
    .registers 5

    .line 1
    invoke-static {}, Lcom/github/catvod/spider/xbpqxyq/xyq/ı;->Ԩ()Ljava/lang/StringBuilder;

    move-result-object v0

    .line 2
    iget-object v1, p0, Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;->ԯ:Ljava/util/List;

    invoke-interface {v1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :cond_a
    :goto_a
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_4e

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcom/github/catvod/spider/xbpqxyq/xyq/ւ;

    .line 3
    instance-of v3, v2, Lcom/github/catvod/spider/xbpqxyq/xyq/ĩ;

    if-eqz v3, :cond_24

    .line 4
    check-cast v2, Lcom/github/catvod/spider/xbpqxyq/xyq/ĩ;

    .line 5
    invoke-virtual {v2}, Lcom/github/catvod/spider/xbpqxyq/xyq/ĩ;->ޣ()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    goto :goto_a

    .line 6
    :cond_24
    instance-of v3, v2, Lcom/github/catvod/spider/xbpqxyq/xyq/ī;

    if-eqz v3, :cond_32

    .line 7
    check-cast v2, Lcom/github/catvod/spider/xbpqxyq/xyq/ī;

    .line 8
    invoke-virtual {v2}, Lcom/github/catvod/spider/xbpqxyq/xyq/ī;->ޣ()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    goto :goto_a

    .line 9
    :cond_32
    instance-of v3, v2, Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;

    if-eqz v3, :cond_40

    .line 10
    check-cast v2, Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;

    .line 11
    invoke-virtual {v2}, Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;->ࡦ()Ljava/lang/String;

    move-result-object v2

    .line 12
    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    goto :goto_a

    .line 13
    :cond_40
    instance-of v3, v2, Lcom/github/catvod/spider/xbpqxyq/xyq/ˍ;

    if-eqz v3, :cond_a

    .line 14
    check-cast v2, Lcom/github/catvod/spider/xbpqxyq/xyq/ˍ;

    .line 15
    invoke-virtual {v2}, Lcom/github/catvod/spider/xbpqxyq/xyq/ŀ;->ޣ()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    goto :goto_a

    .line 16
    :cond_4e
    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xyq/ı;->ށ(Ljava/lang/StringBuilder;)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method protected ࡧ(Lcom/github/catvod/spider/xbpqxyq/xyq/ւ;)Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;
    .registers 4
    .param p1  # Lcom/github/catvod/spider/xbpqxyq/xyq/ւ;
        .annotation runtime Ljavax/annotation/Nullable;
        .end annotation
    .end param

    .line 1
    invoke-super {p0, p1}, Lcom/github/catvod/spider/xbpqxyq/xyq/ւ;->ހ(Lcom/github/catvod/spider/xbpqxyq/xyq/ւ;)Lcom/github/catvod/spider/xbpqxyq/xyq/ւ;

    move-result-object p1

    check-cast p1, Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;

    .line 2
    iget-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;->֏:Lcom/github/catvod/spider/xbpqxyq/xyq/ྋ;

    if-eqz v0, :cond_f

    invoke-virtual {v0}, Lcom/github/catvod/spider/xbpqxyq/xyq/ྋ;->ԯ()Lcom/github/catvod/spider/xbpqxyq/xyq/ྋ;

    move-result-object v0

    goto :goto_10

    :cond_f
    const/4 v0, 0x0

    :goto_10
    iput-object v0, p1, Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;->֏:Lcom/github/catvod/spider/xbpqxyq/xyq/ྋ;

    .line 3
    new-instance v0, Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ$Ԩ;

    iget-object v1, p0, Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;->ԯ:Ljava/util/List;

    invoke-interface {v1}, Ljava/util/List;->size()I

    move-result v1

    invoke-direct {v0, p1, v1}, Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ$Ԩ;-><init>(Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;I)V

    iput-object v0, p1, Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;->ԯ:Ljava/util/List;

    .line 4
    iget-object v1, p0, Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;->ԯ:Ljava/util/List;

    invoke-interface {v0, v1}, Ljava/util/List;->addAll(Ljava/util/Collection;)Z

    return-object p1
.end method

.method public ࡨ()I
    .registers 2

    .line 1
    invoke-virtual {p0}, Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;->ࢭ()Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;

    move-result-object v0

    if-nez v0, :cond_8

    const/4 v0, 0x0

    return v0

    .line 2
    :cond_8
    invoke-virtual {p0}, Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;->ࢭ()Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;

    move-result-object v0

    invoke-virtual {v0}, Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;->ࡣ()Ljava/util/List;

    move-result-object v0

    invoke-static {p0, v0}, Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;->ࢥ(Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;Ljava/util/List;)I

    move-result v0

    return v0
.end method

.method public ࡩ()Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;
    .registers 2

    .line 1
    iget-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;->ԯ:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->clear()V

    return-object p0
.end method

.method public ࡪ()Lcom/github/catvod/spider/xbpqxyq/xyq/ำ;
    .registers 2

    .line 1
    new-instance v0, Lcom/github/catvod/spider/xbpqxyq/xyq/ȋ$Ϳ;

    invoke-direct {v0}, Lcom/github/catvod/spider/xbpqxyq/xyq/ȋ$Ϳ;-><init>()V

    invoke-static {v0, p0}, Lcom/github/catvod/spider/xbpqxyq/xyq/ߺ;->Ϳ(Lcom/github/catvod/spider/xbpqxyq/xyq/ȋ;Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;)Lcom/github/catvod/spider/xbpqxyq/xyq/ำ;

    move-result-object v0

    return-object v0
.end method

.method public ࢠ(Ljava/lang/String;)Lcom/github/catvod/spider/xbpqxyq/xyq/ำ;
    .registers 3

    .line 1
    invoke-static {p1}, Lcom/github/catvod/spider/xbpqxyq/xyq/ǃ;->ԭ(Ljava/lang/String;)V

    .line 2
    invoke-static {p1}, Lcom/github/catvod/spider/xbpqxyq/xyq/ۦ;->Ԩ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    .line 3
    new-instance v0, Lcom/github/catvod/spider/xbpqxyq/xyq/ȋ$ޜ;

    invoke-direct {v0, p1}, Lcom/github/catvod/spider/xbpqxyq/xyq/ȋ$ޜ;-><init>(Ljava/lang/String;)V

    invoke-static {v0, p0}, Lcom/github/catvod/spider/xbpqxyq/xyq/ߺ;->Ϳ(Lcom/github/catvod/spider/xbpqxyq/xyq/ȋ;Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;)Lcom/github/catvod/spider/xbpqxyq/xyq/ำ;

    move-result-object p1

    return-object p1
.end method

.method public ࢡ(Ljava/lang/String;)Z
    .registers 15

    .line 1
    iget-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;->֏:Lcom/github/catvod/spider/xbpqxyq/xyq/ྋ;

    const/4 v1, 0x0

    if-nez v0, :cond_6

    return v1

    :cond_6
    const-string v2, "112E322229"

    invoke-static {v2}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    .line 2
    invoke-virtual {v0, v2}, Lcom/github/catvod/spider/xbpqxyq/xyq/ྋ;->ހ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 3
    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v2

    .line 4
    invoke-virtual {p1}, Ljava/lang/String;->length()I

    move-result v9

    if-eqz v2, :cond_60

    if-ge v2, v9, :cond_1d

    goto :goto_60

    :cond_1d
    if-ne v2, v9, :cond_24

    .line 5
    invoke-virtual {p1, v0}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result p1

    return p1

    :cond_24
    const/4 v3, 0x0

    const/4 v10, 0x0

    const/4 v11, 0x0

    :goto_27
    if-ge v11, v2, :cond_50

    .line 6
    invoke-virtual {v0, v11}, Ljava/lang/String;->charAt(I)C

    move-result v4

    invoke-static {v4}, Ljava/lang/Character;->isWhitespace(C)Z

    move-result v4

    const/4 v12, 0x1

    if-eqz v4, :cond_49

    if-eqz v3, :cond_4d

    sub-int v3, v11, v10

    if-ne v3, v9, :cond_47

    const/4 v4, 0x1

    const/4 v7, 0x0

    move-object v3, v0

    move v5, v10

    move-object v6, p1

    move v8, v9

    .line 7
    invoke-virtual/range {v3 .. v8}, Ljava/lang/String;->regionMatches(ZILjava/lang/String;II)Z

    move-result v3

    if-eqz v3, :cond_47

    return v12

    :cond_47
    const/4 v3, 0x0

    goto :goto_4d

    :cond_49
    if-nez v3, :cond_4d

    move v10, v11

    const/4 v3, 0x1

    :cond_4d
    :goto_4d
    add-int/lit8 v11, v11, 0x1

    goto :goto_27

    :cond_50
    if-eqz v3, :cond_60

    sub-int/2addr v2, v10

    if-ne v2, v9, :cond_60

    const/4 v4, 0x1

    const/4 v7, 0x0

    move-object v3, v0

    move v5, v10

    move-object v6, p1

    move v8, v9

    .line 8
    invoke-virtual/range {v3 .. v8}, Ljava/lang/String;->regionMatches(ZILjava/lang/String;II)Z

    move-result p1

    return p1

    :cond_60
    :goto_60
    return v1
.end method

.method public ࢢ(Ljava/lang/Appendable;)Ljava/lang/Appendable;
    .registers 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T::",
            "Ljava/lang/Appendable;",
            ">(TT;)TT;"
        }
    .end annotation

    .line 1
    iget-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;->ԯ:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v0

    const/4 v1, 0x0

    :goto_7
    if-ge v1, v0, :cond_17

    .line 2
    iget-object v2, p0, Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;->ԯ:Ljava/util/List;

    invoke-interface {v2, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcom/github/catvod/spider/xbpqxyq/xyq/ւ;

    invoke-virtual {v2, p1}, Lcom/github/catvod/spider/xbpqxyq/xyq/ւ;->ތ(Ljava/lang/Appendable;)V

    add-int/lit8 v1, v1, 0x1

    goto :goto_7

    :cond_17
    return-object p1
.end method

.method public ࢣ()Ljava/lang/String;
    .registers 3

    .line 1
    invoke-static {}, Lcom/github/catvod/spider/xbpqxyq/xyq/ı;->Ԩ()Ljava/lang/StringBuilder;

    move-result-object v0

    .line 2
    invoke-virtual {p0, v0}, Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;->ࢢ(Ljava/lang/Appendable;)Ljava/lang/Appendable;

    .line 3
    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xyq/ı;->ށ(Ljava/lang/StringBuilder;)Ljava/lang/String;

    move-result-object v0

    .line 4
    invoke-static {p0}, Lcom/github/catvod/spider/xbpqxyq/xyq/г;->Ϳ(Lcom/github/catvod/spider/xbpqxyq/xyq/ւ;)Lcom/github/catvod/spider/xbpqxyq/xyq/ǐ$Ϳ;

    move-result-object v1

    invoke-virtual {v1}, Lcom/github/catvod/spider/xbpqxyq/xyq/ǐ$Ϳ;->ԯ()Z

    move-result v1

    if-eqz v1, :cond_19

    invoke-virtual {v0}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v0

    :cond_19
    return-object v0
.end method

.method public ࢤ()Ljava/lang/String;
    .registers 3

    .line 1
    iget-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;->֏:Lcom/github/catvod/spider/xbpqxyq/xyq/ྋ;

    if-eqz v0, :cond_f

    const-string v1, "1B26"

    invoke-static {v1}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/github/catvod/spider/xbpqxyq/xyq/ྋ;->ހ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    goto :goto_11

    :cond_f
    const-string v0, ""

    :goto_11
    return-object v0
.end method

.method public ࢦ()Z
    .registers 2

    .line 1
    iget-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;->ԭ:Lcom/github/catvod/spider/xbpqxyq/xyq/ȉ;

    invoke-virtual {v0}, Lcom/github/catvod/spider/xbpqxyq/xyq/ȉ;->Ԫ()Z

    move-result v0

    return v0
.end method

.method public ࢩ()Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;
    .registers 5
    .annotation runtime Ljavax/annotation/Nullable;
    .end annotation

    .line 1
    iget-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xyq/ւ;->Ԩ:Lcom/github/catvod/spider/xbpqxyq/xyq/ւ;

    const/4 v1, 0x0

    if-nez v0, :cond_6

    return-object v1

    .line 2
    :cond_6
    invoke-virtual {p0}, Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;->ࢭ()Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;

    move-result-object v0

    invoke-virtual {v0}, Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;->ࡣ()Ljava/util/List;

    move-result-object v0

    .line 3
    invoke-static {p0, v0}, Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;->ࢥ(Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;Ljava/util/List;)I

    move-result v2

    .line 4
    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v3

    add-int/lit8 v2, v2, 0x1

    if-le v3, v2, :cond_21

    .line 5
    invoke-interface {v0, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;

    return-object v0

    :cond_21
    return-object v1
.end method

.method public ࢪ()Ljava/lang/String;
    .registers 2

    .line 1
    iget-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;->ԭ:Lcom/github/catvod/spider/xbpqxyq/xyq/ȉ;

    invoke-virtual {v0}, Lcom/github/catvod/spider/xbpqxyq/xyq/ȉ;->֏()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public ࢫ()Ljava/lang/String;
    .registers 2

    .line 1
    invoke-static {}, Lcom/github/catvod/spider/xbpqxyq/xyq/ı;->Ԩ()Ljava/lang/StringBuilder;

    move-result-object v0

    .line 2
    invoke-direct {p0, v0}, Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;->ࢬ(Ljava/lang/StringBuilder;)V

    .line 3
    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xyq/ı;->ށ(Ljava/lang/StringBuilder;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public final ࢭ()Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;
    .registers 2

    .line 1
    iget-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xyq/ւ;->Ԩ:Lcom/github/catvod/spider/xbpqxyq/xyq/ւ;

    check-cast v0, Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;

    return-object v0
.end method

.method public ࢮ()Lcom/github/catvod/spider/xbpqxyq/xyq/ำ;
    .registers 2

    .line 1
    new-instance v0, Lcom/github/catvod/spider/xbpqxyq/xyq/ำ;

    invoke-direct {v0}, Lcom/github/catvod/spider/xbpqxyq/xyq/ำ;-><init>()V

    .line 2
    invoke-static {p0, v0}, Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;->ޡ(Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;Lcom/github/catvod/spider/xbpqxyq/xyq/ำ;)V

    return-object v0
.end method

.method public ࢰ()Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;
    .registers 4
    .annotation runtime Ljavax/annotation/Nullable;
    .end annotation

    .line 1
    iget-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xyq/ւ;->Ԩ:Lcom/github/catvod/spider/xbpqxyq/xyq/ւ;

    const/4 v1, 0x0

    if-nez v0, :cond_6

    return-object v1

    .line 2
    :cond_6
    invoke-virtual {p0}, Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;->ࢭ()Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;

    move-result-object v0

    invoke-virtual {v0}, Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;->ࡣ()Ljava/util/List;

    move-result-object v0

    .line 3
    invoke-static {p0, v0}, Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;->ࢥ(Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;Ljava/util/List;)I

    move-result v2

    if-lez v2, :cond_1d

    add-int/lit8 v2, v2, -0x1

    .line 4
    invoke-interface {v0, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;

    return-object v0

    :cond_1d
    return-object v1
.end method

.method public ࢱ()Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;
    .registers 2

    .line 1
    invoke-super {p0}, Lcom/github/catvod/spider/xbpqxyq/xyq/ւ;->ޙ()Lcom/github/catvod/spider/xbpqxyq/xyq/ւ;

    move-result-object v0

    check-cast v0, Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;

    return-object v0
.end method

.method public ࢳ(Ljava/lang/String;)Lcom/github/catvod/spider/xbpqxyq/xyq/ำ;
    .registers 2

    .line 1
    invoke-static {p1, p0}, Lcom/github/catvod/spider/xbpqxyq/xyq/Γ;->Ԩ(Ljava/lang/String;Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;)Lcom/github/catvod/spider/xbpqxyq/xyq/ำ;

    move-result-object p1

    return-object p1
.end method

.method public ࢴ(Ljava/lang/String;)Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;
    .registers 2
    .annotation runtime Ljavax/annotation/Nullable;
    .end annotation

    .line 1
    invoke-static {p1, p0}, Lcom/github/catvod/spider/xbpqxyq/xyq/Γ;->Ԫ(Ljava/lang/String;Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;)Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;

    move-result-object p1

    return-object p1
.end method

.method public ࢶ()Lcom/github/catvod/spider/xbpqxyq/xyq/ำ;
    .registers 4

    .line 1
    iget-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xyq/ւ;->Ԩ:Lcom/github/catvod/spider/xbpqxyq/xyq/ւ;

    if-nez v0, :cond_b

    .line 2
    new-instance v0, Lcom/github/catvod/spider/xbpqxyq/xyq/ำ;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, Lcom/github/catvod/spider/xbpqxyq/xyq/ำ;-><init>(I)V

    return-object v0

    .line 3
    :cond_b
    invoke-virtual {p0}, Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;->ࢭ()Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;

    move-result-object v0

    invoke-virtual {v0}, Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;->ࡣ()Ljava/util/List;

    move-result-object v0

    .line 4
    new-instance v1, Lcom/github/catvod/spider/xbpqxyq/xyq/ำ;

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v2

    add-int/lit8 v2, v2, -0x1

    invoke-direct {v1, v2}, Lcom/github/catvod/spider/xbpqxyq/xyq/ำ;-><init>(I)V

    .line 5
    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :cond_22
    :goto_22
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_34

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;

    if-eq v2, p0, :cond_22

    .line 6
    invoke-virtual {v1, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_22

    :cond_34
    return-object v1
.end method

.method public ࢷ()Lcom/github/catvod/spider/xbpqxyq/xyq/ȉ;
    .registers 2

    .line 1
    iget-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;->ԭ:Lcom/github/catvod/spider/xbpqxyq/xyq/ȉ;

    return-object v0
.end method

.method public ࢸ()Ljava/lang/String;
    .registers 2

    .line 1
    iget-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;->ԭ:Lcom/github/catvod/spider/xbpqxyq/xyq/ȉ;

    invoke-virtual {v0}, Lcom/github/catvod/spider/xbpqxyq/xyq/ȉ;->ԩ()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public ࢹ()Ljava/lang/String;
    .registers 3

    .line 1
    invoke-static {}, Lcom/github/catvod/spider/xbpqxyq/xyq/ı;->Ԩ()Ljava/lang/StringBuilder;

    move-result-object v0

    .line 2
    new-instance v1, Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ$Ϳ;

    invoke-direct {v1, p0, v0}, Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ$Ϳ;-><init>(Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;Ljava/lang/StringBuilder;)V

    invoke-static {v1, p0}, Lcom/github/catvod/spider/xbpqxyq/xyq/ɾ;->Ԩ(Lcom/github/catvod/spider/xbpqxyq/xyq/ཬ;Lcom/github/catvod/spider/xbpqxyq/xyq/ւ;)V

    .line 3
    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xyq/ı;->ށ(Ljava/lang/StringBuilder;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public ࢺ(Ljava/lang/String;)Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;
    .registers 4

    .line 1
    invoke-static {p1}, Lcom/github/catvod/spider/xbpqxyq/xyq/ǃ;->ԯ(Ljava/lang/Object;)V

    .line 2
    invoke-virtual {p0}, Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;->ࡩ()Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;

    .line 3
    invoke-virtual {p0}, Lcom/github/catvod/spider/xbpqxyq/xyq/ւ;->ޏ()Lcom/github/catvod/spider/xbpqxyq/xyq/ǐ;

    move-result-object v0

    if-eqz v0, :cond_23

    .line 4
    invoke-virtual {v0}, Lcom/github/catvod/spider/xbpqxyq/xyq/ǐ;->ೱ()Lcom/github/catvod/spider/xbpqxyq/xyq/ͱ;

    move-result-object v0

    invoke-virtual {p0}, Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;->ࢪ()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/github/catvod/spider/xbpqxyq/xyq/ͱ;->Ԫ(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_23

    .line 5
    new-instance v0, Lcom/github/catvod/spider/xbpqxyq/xyq/ĩ;

    invoke-direct {v0, p1}, Lcom/github/catvod/spider/xbpqxyq/xyq/ĩ;-><init>(Ljava/lang/String;)V

    invoke-virtual {p0, v0}, Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;->ޢ(Lcom/github/catvod/spider/xbpqxyq/xyq/ւ;)Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;

    goto :goto_2b

    .line 6
    :cond_23
    new-instance v0, Lcom/github/catvod/spider/xbpqxyq/xyq/ŀ;

    invoke-direct {v0, p1}, Lcom/github/catvod/spider/xbpqxyq/xyq/ŀ;-><init>(Ljava/lang/String;)V

    invoke-virtual {p0, v0}, Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;->ޢ(Lcom/github/catvod/spider/xbpqxyq/xyq/ւ;)Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;

    :goto_2b
    return-object p0
.end method

.method public ࢻ()Ljava/util/List;
    .registers 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lcom/github/catvod/spider/xbpqxyq/xyq/ŀ;",
            ">;"
        }
    .end annotation

    .line 1
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 2
    iget-object v1, p0, Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;->ԯ:Ljava/util/List;

    invoke-interface {v1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :cond_b
    :goto_b
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_21

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcom/github/catvod/spider/xbpqxyq/xyq/ւ;

    .line 3
    instance-of v3, v2, Lcom/github/catvod/spider/xbpqxyq/xyq/ŀ;

    if-eqz v3, :cond_b

    .line 4
    check-cast v2, Lcom/github/catvod/spider/xbpqxyq/xyq/ŀ;

    invoke-interface {v0, v2}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    goto :goto_b

    .line 5
    :cond_21
    invoke-static {v0}, Ljava/util/Collections;->unmodifiableList(Ljava/util/List;)Ljava/util/List;

    move-result-object v0

    return-object v0
.end method
