.class final Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ$Ԩ;
.super Lcom/github/catvod/spider/xbpqxyq/xyq/ˌ;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1a
    name = "Ԩ"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/github/catvod/spider/xbpqxyq/xyq/ˌ<",
        "Lcom/github/catvod/spider/xbpqxyq/xyq/ւ;",
        ">;"
    }
.end annotation


# instance fields
.field private final Ϳ:Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;


# direct methods
.method constructor <init>(Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;I)V
    .registers 3

    .line 1
    invoke-direct {p0, p2}, Lcom/github/catvod/spider/xbpqxyq/xyq/ˌ;-><init>(I)V

    .line 2
    iput-object p1, p0, Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ$Ԩ;->Ϳ:Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;

    return-void
.end method


# virtual methods
.method public Ϳ()V
    .registers 2

    .line 1
    iget-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ$Ԩ;->Ϳ:Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;

    invoke-virtual {v0}, Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;->ފ()V

    return-void
.end method
