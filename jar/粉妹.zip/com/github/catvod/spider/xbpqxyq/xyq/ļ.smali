.class public interface abstract Lcom/github/catvod/spider/xbpqxyq/xyq/ļ;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract Ϳ(Ljava/lang/String;)Lcom/github/catvod/spider/xbpqxyq/xyq/ཁ;
.end method
