.class public Lcom/github/catvod/spider/xbpqxyq/xyq/ĩ;
.super Lcom/github/catvod/spider/xbpqxyq/xyq/ː;
.source "SourceFile"


# direct methods
.method public constructor <init>(Ljava/lang/String;)V
    .registers 2

    .line 1
    invoke-direct {p0}, Lcom/github/catvod/spider/xbpqxyq/xyq/ː;-><init>()V

    .line 2
    iput-object p1, p0, Lcom/github/catvod/spider/xbpqxyq/xyq/ː;->Ԫ:Ljava/lang/Object;

    return-void
.end method


# virtual methods
.method public bridge synthetic clone()Ljava/lang/Object;
    .registers 2

    .line 1
    invoke-virtual {p0}, Lcom/github/catvod/spider/xbpqxyq/xyq/ĩ;->ޢ()Lcom/github/catvod/spider/xbpqxyq/xyq/ĩ;

    move-result-object v0

    return-object v0
.end method

.method public toString()Ljava/lang/String;
    .registers 2

    .line 1
    invoke-virtual {p0}, Lcom/github/catvod/spider/xbpqxyq/xyq/ւ;->ދ()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public bridge synthetic Ϳ(Ljava/lang/String;)Ljava/lang/String;
    .registers 2

    .line 1
    invoke-super {p0, p1}, Lcom/github/catvod/spider/xbpqxyq/xyq/ː;->Ϳ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    return-object p1
.end method

.method public bridge synthetic ԩ(Ljava/lang/String;)Ljava/lang/String;
    .registers 2

    .line 1
    invoke-super {p0, p1}, Lcom/github/catvod/spider/xbpqxyq/xyq/ː;->ԩ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    return-object p1
.end method

.method public bridge synthetic Ԭ()Ljava/lang/String;
    .registers 2

    .line 1
    invoke-super {p0}, Lcom/github/catvod/spider/xbpqxyq/xyq/ː;->Ԭ()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public bridge synthetic ԯ()I
    .registers 2

    .line 1
    invoke-super {p0}, Lcom/github/catvod/spider/xbpqxyq/xyq/ː;->ԯ()I

    move-result v0

    return v0
.end method

.method public bridge synthetic ؠ()Lcom/github/catvod/spider/xbpqxyq/xyq/ւ;
    .registers 2

    .line 1
    invoke-virtual {p0}, Lcom/github/catvod/spider/xbpqxyq/xyq/ĩ;->ޢ()Lcom/github/catvod/spider/xbpqxyq/xyq/ĩ;

    move-result-object v0

    return-object v0
.end method

.method public bridge synthetic ނ()Lcom/github/catvod/spider/xbpqxyq/xyq/ւ;
    .registers 2

    .line 1
    invoke-super {p0}, Lcom/github/catvod/spider/xbpqxyq/xyq/ː;->ނ()Lcom/github/catvod/spider/xbpqxyq/xyq/ւ;

    move-result-object v0

    return-object v0
.end method

.method public މ()Ljava/lang/String;
    .registers 2

    const-string v0, "512632253B"

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method ލ(Ljava/lang/Appendable;ILcom/github/catvod/spider/xbpqxyq/xyq/ǐ$Ϳ;)V
    .registers 4

    .line 1
    invoke-virtual {p0}, Lcom/github/catvod/spider/xbpqxyq/xyq/ĩ;->ޣ()Ljava/lang/String;

    move-result-object p2

    invoke-interface {p1, p2}, Ljava/lang/Appendable;->append(Ljava/lang/CharSequence;)Ljava/lang/Appendable;

    return-void
.end method

.method ގ(Ljava/lang/Appendable;ILcom/github/catvod/spider/xbpqxyq/xyq/ǐ$Ϳ;)V
    .registers 4

    return-void
.end method

.method public ޢ()Lcom/github/catvod/spider/xbpqxyq/xyq/ĩ;
    .registers 2

    .line 1
    invoke-super {p0}, Lcom/github/catvod/spider/xbpqxyq/xyq/ւ;->ؠ()Lcom/github/catvod/spider/xbpqxyq/xyq/ւ;

    move-result-object v0

    check-cast v0, Lcom/github/catvod/spider/xbpqxyq/xyq/ĩ;

    return-object v0
.end method

.method public ޣ()Ljava/lang/String;
    .registers 2

    .line 1
    invoke-virtual {p0}, Lcom/github/catvod/spider/xbpqxyq/xyq/ː;->ޟ()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method
