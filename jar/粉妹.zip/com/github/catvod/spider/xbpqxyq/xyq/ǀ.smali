.class public Lcom/github/catvod/spider/xbpqxyq/xyq/ǀ;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lcom/github/catvod/spider/xbpqxyq/xyq/ߙ;


# static fields
.field private static Ϳ:Ljava/util/regex/Pattern;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    const-string v0, "2E26790D747B2E2678"

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 1
    invoke-static {v0}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    move-result-object v0

    sput-object v0, Lcom/github/catvod/spider/xbpqxyq/xyq/ǀ;->Ϳ:Ljava/util/regex/Pattern;

    return-void
.end method

.method public constructor <init>()V
    .registers 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public name()Ljava/lang/String;
    .registers 2

    const-string v0, "1C373E"

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public Ϳ(Lcom/github/catvod/spider/xbpqxyq/xyq/ŕ;)Lcom/github/catvod/spider/xbpqxyq/xyq/ߠ;
    .registers 4

    const-string v0, "132E3F053F3C06"

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 1
    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xyq/ү;->Ԩ(Ljava/lang/String;)Lcom/github/catvod/spider/xbpqxyq/xyq/ߙ;

    move-result-object v0

    .line 2
    invoke-interface {v0, p1}, Lcom/github/catvod/spider/xbpqxyq/xyq/ߙ;->Ϳ(Lcom/github/catvod/spider/xbpqxyq/xyq/ŕ;)Lcom/github/catvod/spider/xbpqxyq/xyq/ߠ;

    move-result-object p1

    .line 3
    invoke-virtual {p1}, Lcom/github/catvod/spider/xbpqxyq/xyq/ߠ;->ԫ()Ljava/util/List;

    move-result-object p1

    const-string v0, ""

    invoke-static {p1, v0}, Lcom/github/catvod/spider/xbpqxyq/xyq/ˑ;->ހ(Ljava/lang/Iterable;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    .line 4
    sget-object v0, Lcom/github/catvod/spider/xbpqxyq/xyq/ǀ;->Ϳ:Ljava/util/regex/Pattern;

    invoke-virtual {v0, p1}, Ljava/util/regex/Pattern;->matcher(Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;

    move-result-object p1

    .line 5
    invoke-virtual {p1}, Ljava/util/regex/Matcher;->find()Z

    move-result v0

    if-eqz v0, :cond_3a

    .line 6
    invoke-virtual {p1}, Ljava/util/regex/Matcher;->group()Ljava/lang/String;

    move-result-object p1

    .line 7
    new-instance v0, Ljava/math/BigDecimal;

    invoke-direct {v0, p1}, Ljava/math/BigDecimal;-><init>(Ljava/lang/String;)V

    .line 8
    invoke-virtual {v0}, Ljava/math/BigDecimal;->doubleValue()D

    move-result-wide v0

    invoke-static {v0, v1}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object p1

    invoke-static {p1}, Lcom/github/catvod/spider/xbpqxyq/xyq/ߠ;->֏(Ljava/lang/Object;)Lcom/github/catvod/spider/xbpqxyq/xyq/ߠ;

    move-result-object p1

    return-object p1

    :cond_3a
    const/4 p1, 0x0

    .line 9
    invoke-static {p1}, Lcom/github/catvod/spider/xbpqxyq/xyq/ߠ;->֏(Ljava/lang/Object;)Lcom/github/catvod/spider/xbpqxyq/xyq/ߠ;

    move-result-object p1

    return-object p1
.end method
