.class public interface abstract Lcom/github/catvod/spider/xbpqxyq/xyq/İ;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract name()Ljava/lang/String;
.end method

.method public abstract Ϳ(Lcom/github/catvod/spider/xbpqxyq/xyq/ำ;)Lcom/github/catvod/spider/xbpqxyq/xyq/ߠ;
.end method
