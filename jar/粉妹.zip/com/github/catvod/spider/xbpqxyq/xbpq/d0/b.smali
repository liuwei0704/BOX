.class public final Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b;
.super Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/i1;
.source "SourceFile"


# static fields
.field static final A:[Ljava/lang/String;

.field static final B:[Ljava/lang/String;

.field static final v:[Ljava/lang/String;

.field static final w:[Ljava/lang/String;

.field static final x:[Ljava/lang/String;

.field static final y:[Ljava/lang/String;

.field static final z:[Ljava/lang/String;


# instance fields
.field private k:Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/A;

.field private l:Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/A;

.field private m:Z

.field private n:Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/l;

.field private o:Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/o;

.field private p:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/l;",
            ">;"
        }
    .end annotation
.end field

.field private q:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field private r:Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/L;

.field private s:Z

.field private t:Z

.field private u:[Ljava/lang/String;


# direct methods
.method static constructor <clinit>()V
    .registers 24

    const/16 v0, 0x8

    new-array v1, v0, [Ljava/lang/String;

    const/4 v2, 0x0

    const-string v3, "160835091621"

    invoke-static {v3}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    aput-object v3, v1, v2

    const/4 v4, 0x1

    const-string v5, "141935111A3A19"

    invoke-static {v5}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    aput-object v5, v1, v4

    const/4 v6, 0x2

    const-string v7, "1F0C2809"

    invoke-static {v7}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    aput-object v7, v1, v6

    const/4 v8, 0x3

    const-string v9, "1A193714063012"

    invoke-static {v9}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    aput-object v9, v1, v8

    const/4 v10, 0x4

    const-string v11, "181A2F001021"

    invoke-static {v11}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v11

    aput-object v11, v1, v10

    const/4 v12, 0x5

    const-string v13, "0319270916"

    invoke-static {v13}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v13

    aput-object v13, v1, v12

    const/4 v14, 0x6

    const-string v15, "031C"

    invoke-static {v15}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v15

    aput-object v15, v1, v14

    const/16 v16, 0x7

    const-string v17, "0310"

    invoke-static/range {v17 .. v17}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v17

    aput-object v17, v1, v16

    sput-object v1, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b;->v:[Ljava/lang/String;

    new-array v1, v6, [Ljava/lang/String;

    const-string v18, "1814"

    invoke-static/range {v18 .. v18}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v18

    aput-object v18, v1, v2

    const-string v19, "0214"

    invoke-static/range {v19 .. v19}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v19

    aput-object v19, v1, v4

    sput-object v1, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b;->w:[Ljava/lang/String;

    new-array v1, v4, [Ljava/lang/String;

    const-string v20, "150D31111C3B"

    invoke-static/range {v20 .. v20}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v20

    aput-object v20, v1, v2

    sput-object v1, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b;->x:[Ljava/lang/String;

    new-array v1, v6, [Ljava/lang/String;

    aput-object v7, v1, v2

    aput-object v13, v1, v4

    sput-object v1, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b;->y:[Ljava/lang/String;

    new-array v1, v6, [Ljava/lang/String;

    const-string v21, "18083102013A0208"

    invoke-static/range {v21 .. v21}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v21

    aput-object v21, v1, v2

    const-string v22, "1808310C1C3B"

    invoke-static/range {v22 .. v22}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v22

    aput-object v22, v1, v4

    sput-object v1, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b;->z:[Ljava/lang/String;

    new-array v1, v0, [Ljava/lang/String;

    const-string v23, "131C"

    invoke-static/range {v23 .. v23}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v23

    aput-object v23, v1, v2

    const-string v23, "130C"

    invoke-static/range {v23 .. v23}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v23

    aput-object v23, v1, v4

    const-string v23, "1B11"

    invoke-static/range {v23 .. v23}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v23

    aput-object v23, v1, v6

    aput-object v21, v1, v8

    aput-object v22, v1, v10

    const-string v21, "07"

    invoke-static/range {v21 .. v21}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v21

    aput-object v21, v1, v12

    const-string v21, "0508"

    invoke-static/range {v21 .. v21}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v21

    aput-object v21, v1, v14

    const-string v21, "050C"

    invoke-static/range {v21 .. v21}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v21

    aput-object v21, v1, v16

    sput-object v1, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b;->A:[Ljava/lang/String;

    const/16 v1, 0x4f

    new-array v1, v1, [Ljava/lang/String;

    const-string v21, "161C2117162604"

    invoke-static/range {v21 .. v21}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v21

    aput-object v21, v1, v2

    aput-object v3, v1, v4

    const-string v2, "160A2004"

    invoke-static {v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    aput-object v2, v1, v6

    const-string v2, "160A310C103912"

    invoke-static {v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    aput-object v2, v1, v8

    const-string v2, "160B2C0116"

    invoke-static {v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    aput-object v2, v1, v10

    const-string v2, "15193600"

    invoke-static {v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    aput-object v2, v1, v12

    const-string v2, "15193600153A190C"

    invoke-static {v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    aput-object v2, v1, v14

    const-string v2, "151F360A063B13"

    invoke-static {v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    aput-object v2, v1, v16

    const-string v2, "15142A06182402173100"

    invoke-static {v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    aput-object v2, v1, v0

    const/16 v0, 0x9

    const-string v2, "1517211C"

    invoke-static {v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    aput-object v2, v1, v0

    const/16 v0, 0xa

    const-string v2, "150A"

    invoke-static {v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    aput-object v2, v1, v0

    const/16 v0, 0xb

    aput-object v20, v1, v0

    const/16 v0, 0xc

    aput-object v5, v1, v0

    const/16 v0, 0xd

    const-string v2, "141D2B111627"

    invoke-static {v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    aput-object v2, v1, v0

    const/16 v0, 0xe

    const-string v2, "141729"

    invoke-static {v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    aput-object v2, v1, v0

    const/16 v0, 0xf

    const-string v2, "14172902013A0208"

    invoke-static {v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    aput-object v2, v1, v0

    const/16 v0, 0x10

    const-string v2, "14172808123B13"

    invoke-static {v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    aput-object v2, v1, v0

    const/16 v0, 0x11

    const-string v2, "131C"

    invoke-static {v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    aput-object v2, v1, v0

    const/16 v0, 0x12

    const-string v2, "131D31041A3904"

    invoke-static {v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    aput-object v2, v1, v0

    const/16 v0, 0x13

    const-string v2, "131137"

    invoke-static {v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    aput-object v2, v1, v0

    const/16 v0, 0x14

    const-string v2, "131133"

    invoke-static {v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    aput-object v2, v1, v0

    const/16 v0, 0x15

    const-string v2, "1314"

    invoke-static {v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    aput-object v2, v1, v0

    const/16 v0, 0x16

    const-string v2, "130C"

    invoke-static {v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    aput-object v2, v1, v0

    const/16 v0, 0x17

    const-string v2, "1215270017"

    invoke-static {v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    aput-object v2, v1, v0

    const/16 v0, 0x18

    const-string v2, "111120091726120C"

    invoke-static {v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    aput-object v2, v1, v0

    const/16 v0, 0x19

    const-string v2, "11112206122503112A0B"

    invoke-static {v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    aput-object v2, v1, v0

    const/16 v0, 0x1a

    const-string v2, "111122100130"

    invoke-static {v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    aput-object v2, v1, v0

    const/16 v0, 0x1b

    const-string v2, "11172A111627"

    invoke-static {v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    aput-object v2, v1, v0

    const/16 v0, 0x1c

    const-string v2, "11173708"

    invoke-static {v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    aput-object v2, v1, v0

    const/16 v0, 0x1d

    const-string v2, "110A240816"

    invoke-static {v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    aput-object v2, v1, v0

    const/16 v0, 0x1e

    const-string v2, "110A24081626120C"

    invoke-static {v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    aput-object v2, v1, v0

    const/16 v0, 0x1f

    const-string v2, "1F49"

    invoke-static {v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    aput-object v2, v1, v0

    const/16 v0, 0x20

    const-string v2, "1F4A"

    invoke-static {v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    aput-object v2, v1, v0

    const/16 v0, 0x21

    const-string v2, "1F4B"

    invoke-static {v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    aput-object v2, v1, v0

    const/16 v0, 0x22

    const-string v2, "1F4C"

    invoke-static {v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    aput-object v2, v1, v0

    const/16 v0, 0x23

    const-string v2, "1F4D"

    invoke-static {v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    aput-object v2, v1, v0

    const/16 v0, 0x24

    const-string v2, "1F4E"

    invoke-static {v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    aput-object v2, v1, v0

    const/16 v0, 0x25

    const-string v2, "1F1D2401"

    invoke-static {v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    aput-object v2, v1, v0

    const/16 v0, 0x26

    const-string v2, "1F1D24011627"

    invoke-static {v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    aput-object v2, v1, v0

    const/16 v0, 0x27

    const-string v2, "1F1F370A0625"

    invoke-static {v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    aput-object v2, v1, v0

    const/16 v0, 0x28

    const-string v2, "1F0A"

    invoke-static {v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    aput-object v2, v1, v0

    const/16 v0, 0x29

    aput-object v7, v1, v0

    const/16 v0, 0x2a

    const-string v2, "1E1E37041E30"

    invoke-static {v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    aput-object v2, v1, v0

    const/16 v0, 0x2b

    const-string v2, "1E1522"

    invoke-static {v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    aput-object v2, v1, v0

    const/16 v0, 0x2c

    const-string v2, "1E16351007"

    invoke-static {v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    aput-object v2, v1, v0

    const/16 v0, 0x2d

    const-string v2, "1E0B2C0B17300F"

    invoke-static {v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    aput-object v2, v1, v0

    const/16 v0, 0x2e

    const-string v2, "1B11"

    invoke-static {v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    aput-object v2, v1, v0

    const/16 v0, 0x2f

    const-string v2, "1B112B0E"

    invoke-static {v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    aput-object v2, v1, v0

    const/16 v0, 0x30

    const-string v2, "1B1136111A3B10"

    invoke-static {v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    aput-object v2, v1, v0

    const/16 v0, 0x31

    aput-object v9, v1, v0

    const/16 v0, 0x32

    const-string v2, "1A1D2B10"

    invoke-static {v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    aput-object v2, v1, v0

    const/16 v0, 0x33

    const-string v2, "1A1D3104"

    invoke-static {v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    aput-object v2, v1, v0

    const/16 v0, 0x34

    const-string v2, "191933"

    invoke-static {v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    aput-object v2, v1, v0

    const/16 v0, 0x35

    const-string v2, "19172008113013"

    invoke-static {v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    aput-object v2, v1, v0

    const/16 v0, 0x36

    const-string v2, "191723171238120B"

    invoke-static {v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    aput-object v2, v1, v0

    const/16 v0, 0x37

    const-string v2, "19173606013C070C"

    invoke-static {v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    aput-object v2, v1, v0

    const/16 v0, 0x38

    aput-object v11, v1, v0

    const/16 v0, 0x39

    aput-object v18, v1, v0

    const/16 v0, 0x3a

    const-string v2, "07"

    invoke-static {v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    aput-object v2, v1, v0

    const/16 v0, 0x3b

    const-string v2, "071937041E"

    invoke-static {v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    aput-object v2, v1, v0

    const/16 v0, 0x3c

    const-string v2, "0714240C1D21120031"

    invoke-static {v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    aput-object v2, v1, v0

    const/16 v0, 0x3d

    const-string v2, "070A20"

    invoke-static {v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    aput-object v2, v1, v0

    const/16 v0, 0x3e

    const-string v2, "041B370C0321"

    invoke-static {v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    aput-object v2, v1, v0

    const/16 v0, 0x3f

    const-string v2, "041D26111A3A19"

    invoke-static {v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    aput-object v2, v1, v0

    const/16 v0, 0x40

    const-string v2, "041D29001021"

    invoke-static {v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    aput-object v2, v1, v0

    const/16 v0, 0x41

    const-string v2, "040C3C0916"

    invoke-static {v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    aput-object v2, v1, v0

    const/16 v0, 0x42

    const-string v2, "040D280812270E"

    invoke-static {v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    aput-object v2, v1, v0

    const/16 v0, 0x43

    aput-object v13, v1, v0

    const/16 v0, 0x44

    const-string v2, "031A2A010A"

    invoke-static {v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    aput-object v2, v1, v0

    const/16 v0, 0x45

    aput-object v15, v1, v0

    const/16 v0, 0x46

    const-string v2, "031D3D1112271219"

    invoke-static {v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    aput-object v2, v1, v0

    const/16 v0, 0x47

    const-string v2, "031E2A0A07"

    invoke-static {v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    aput-object v2, v1, v0

    const/16 v0, 0x48

    aput-object v17, v1, v0

    const/16 v0, 0x49

    const-string v2, "0310200417"

    invoke-static {v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    aput-object v2, v1, v0

    const/16 v0, 0x4a

    const-string v2, "0311310916"

    invoke-static {v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    aput-object v2, v1, v0

    const/16 v0, 0x4b

    const-string v2, "030A"

    invoke-static {v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    aput-object v2, v1, v0

    const/16 v0, 0x4c

    aput-object v19, v1, v0

    const/16 v0, 0x4d

    const-string v2, "001A37"

    invoke-static {v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    aput-object v2, v1, v0

    const/16 v0, 0x4e

    const-string v2, "0F1535"

    invoke-static {v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    aput-object v2, v1, v0

    sput-object v1, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b;->B:[Ljava/lang/String;

    return-void
.end method

.method public constructor <init>()V
    .registers 4

    invoke-direct {p0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/i1;-><init>()V

    const/4 v0, 0x1

    new-array v0, v0, [Ljava/lang/String;

    const/4 v1, 0x0

    const/4 v2, 0x0

    aput-object v2, v0, v1

    iput-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b;->u:[Ljava/lang/String;

    return-void
.end method

.method private A([Ljava/lang/String;[Ljava/lang/String;[Ljava/lang/String;)Z
    .registers 10

    iget-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/i1;->e:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    const/4 v1, 0x1

    sub-int/2addr v0, v1

    const/4 v2, 0x0

    const/16 v3, 0x64

    if-le v0, v3, :cond_10

    add-int/lit8 v3, v0, -0x64

    goto :goto_11

    :cond_10
    const/4 v3, 0x0

    :goto_11
    if-lt v0, v3, :cond_39

    iget-object v4, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/i1;->e:Ljava/util/ArrayList;

    invoke-virtual {v4, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/l;

    invoke-virtual {v4}, Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/l;->d0()Ljava/lang/String;

    move-result-object v4

    invoke-static {v4, p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/b0/b;->b(Ljava/lang/String;[Ljava/lang/String;)Z

    move-result v5

    if-eqz v5, :cond_26

    return v1

    :cond_26
    invoke-static {v4, p2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/b0/b;->b(Ljava/lang/String;[Ljava/lang/String;)Z

    move-result v5

    if-eqz v5, :cond_2d

    return v2

    :cond_2d
    if-eqz p3, :cond_36

    invoke-static {v4, p3}, Lcom/github/catvod/spider/xbpqxyq/xbpq/b0/b;->b(Ljava/lang/String;[Ljava/lang/String;)Z

    move-result v4

    if-eqz v4, :cond_36

    return v2

    :cond_36
    add-int/lit8 v0, v0, -0x1

    goto :goto_11

    :cond_39
    return v2
.end method

.method private K(Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/r;)V
    .registers 3

    iget-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/i1;->e:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v0

    if-eqz v0, :cond_b

    iget-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/i1;->d:Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/h;

    goto :goto_17

    .line 1
    :cond_b
    iget-boolean v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b;->t:Z

    if-eqz v0, :cond_13

    .line 2
    invoke-virtual {p0, p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b;->I(Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/r;)V

    goto :goto_1a

    :cond_13
    invoke-virtual {p0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/i1;->a()Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/l;

    move-result-object v0

    .line 3
    :goto_17
    invoke-virtual {v0, p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/l;->L(Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/r;)Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/l;

    .line 4
    :goto_1a
    instance-of v0, p1, Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/l;

    if-eqz v0, :cond_31

    check-cast p1, Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/l;

    invoke-virtual {p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/l;->m0()Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/F;

    move-result-object v0

    invoke-virtual {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/F;->e()Z

    move-result v0

    if-eqz v0, :cond_31

    iget-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b;->o:Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/o;

    if-eqz v0, :cond_31

    invoke-virtual {v0, p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/o;->r0(Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/l;)Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/o;

    :cond_31
    return-void
.end method

.method private M(Ljava/util/ArrayList;Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/l;)Z
    .registers 8
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/ArrayList<",
            "Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/l;",
            ">;",
            "Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/l;",
            ")Z"
        }
    .end annotation

    invoke-virtual {p1}, Ljava/util/ArrayList;->size()I

    move-result v0

    const/4 v1, 0x1

    sub-int/2addr v0, v1

    const/4 v2, 0x0

    const/16 v3, 0x100

    if-lt v0, v3, :cond_e

    add-int/lit16 v3, v0, -0x100

    goto :goto_f

    :cond_e
    const/4 v3, 0x0

    :goto_f
    if-lt v0, v3, :cond_1d

    invoke-virtual {p1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/l;

    if-ne v4, p2, :cond_1a

    return v1

    :cond_1a
    add-int/lit8 v0, v0, -0x1

    goto :goto_f

    :cond_1d
    return v2
.end method

.method private varargs j([Ljava/lang/String;)V
    .registers 10

    iget-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/i1;->e:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    const/4 v1, 0x1

    sub-int/2addr v0, v1

    :goto_8
    if-ltz v0, :cond_45

    iget-object v2, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/i1;->e:Ljava/util/ArrayList;

    invoke-virtual {v2, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/l;

    invoke-virtual {v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/l;->d0()Ljava/lang/String;

    move-result-object v3

    sget v4, Lcom/github/catvod/spider/xbpqxyq/xbpq/b0/b;->d:I

    .line 1
    array-length v4, p1

    const/4 v5, 0x0

    const/4 v6, 0x0

    :goto_1b
    if-ge v6, v4, :cond_2a

    aget-object v7, p1, v6

    invoke-virtual {v7, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v7

    if-eqz v7, :cond_27

    const/4 v5, 0x1

    goto :goto_2a

    :cond_27
    add-int/lit8 v6, v6, 0x1

    goto :goto_1b

    :cond_2a
    :goto_2a
    if-nez v5, :cond_45

    .line 2
    invoke-virtual {v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/l;->d0()Ljava/lang/String;

    move-result-object v2

    const-string v3, "1F0C2809"

    invoke-static {v3}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_3d

    goto :goto_45

    :cond_3d
    iget-object v2, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/i1;->e:Ljava/util/ArrayList;

    invoke-virtual {v2, v0}, Ljava/util/ArrayList;->remove(I)Ljava/lang/Object;

    add-int/lit8 v0, v0, -0x1

    goto :goto_8

    :cond_45
    :goto_45
    return-void
.end method


# virtual methods
.method final B(Ljava/lang/String;)Z
    .registers 5

    sget-object v0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b;->y:[Ljava/lang/String;

    iget-object v1, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b;->u:[Ljava/lang/String;

    const/4 v2, 0x0

    aput-object p1, v1, v2

    const/4 p1, 0x0

    invoke-direct {p0, v1, v0, p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b;->A([Ljava/lang/String;[Ljava/lang/String;[Ljava/lang/String;)Z

    move-result p1

    return p1
.end method

.method protected final C(Ljava/io/Reader;Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/E;)V
    .registers 5

    .line 1
    new-instance v0, Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/h;

    invoke-direct {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/h;-><init>()V

    iput-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/i1;->d:Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/h;

    invoke-virtual {v0, p2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/h;->t0(Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/E;)Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/h;

    iput-object p2, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/i1;->a:Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/E;

    sget-object v0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/D;->c:Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/D;

    iput-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/i1;->h:Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/D;

    new-instance v0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/a;

    const v1, 0x8000

    .line 2
    invoke-direct {v0, p1, v1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/a;-><init>(Ljava/io/Reader;I)V

    .line 3
    iput-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/i1;->b:Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/a;

    const/4 p1, 0x0

    iput-object p1, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/i1;->g:Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/O;

    new-instance v0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/Q;

    iget-object v1, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/i1;->b:Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/a;

    invoke-virtual {p2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/E;->a()Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/C;

    move-result-object p2

    invoke-direct {v0, v1, p2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/Q;-><init>(Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/a;Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/C;)V

    iput-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/i1;->c:Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/Q;

    new-instance p2, Ljava/util/ArrayList;

    const/16 v0, 0x20

    invoke-direct {p2, v0}, Ljava/util/ArrayList;-><init>(I)V

    iput-object p2, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/i1;->e:Ljava/util/ArrayList;

    const-string p2, ""

    iput-object p2, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/i1;->f:Ljava/lang/String;

    .line 4
    sget-object p2, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/A;->c:Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/m;

    iput-object p2, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b;->k:Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/A;

    iput-object p1, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b;->l:Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/A;

    const/4 p2, 0x0

    iput-boolean p2, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b;->m:Z

    iput-object p1, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b;->n:Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/l;

    iput-object p1, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b;->o:Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/o;

    new-instance p1, Ljava/util/ArrayList;

    invoke-direct {p1}, Ljava/util/ArrayList;-><init>()V

    iput-object p1, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b;->p:Ljava/util/ArrayList;

    new-instance p1, Ljava/util/ArrayList;

    invoke-direct {p1}, Ljava/util/ArrayList;-><init>()V

    iput-object p1, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b;->q:Ljava/util/ArrayList;

    new-instance p1, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/L;

    invoke-direct {p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/L;-><init>()V

    iput-object p1, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b;->r:Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/L;

    const/4 p1, 0x1

    iput-boolean p1, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b;->s:Z

    iput-boolean p2, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b;->t:Z

    return-void
.end method

.method final D(Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/M;)Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/l;
    .registers 6

    invoke-virtual {p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/N;->r()Z

    move-result v0

    if-eqz v0, :cond_38

    iget-object v0, p1, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/N;->j:Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/c;

    invoke-virtual {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/c;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_38

    iget-object v0, p1, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/N;->j:Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/c;

    iget-object v1, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/i1;->h:Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/D;

    invoke-virtual {v0, v1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/c;->i(Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/D;)I

    move-result v0

    if-lez v0, :cond_38

    .line 1
    iget-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/i1;->a:Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/E;

    invoke-virtual {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/E;->a()Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/C;

    move-result-object v0

    invoke-virtual {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/C;->a()Z

    move-result v1

    if-eqz v1, :cond_38

    new-instance v1, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/B;

    iget-object v2, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/i1;->b:Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/a;

    invoke-virtual {v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/a;->E()I

    move-result v2

    const-string v3, "330D35091A36160C20451221030A2C07062112"

    invoke-static {v3}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-direct {v1, v2, v3}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/B;-><init>(ILjava/lang/String;)V

    invoke-virtual {v0, v1}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    .line 2
    :cond_38
    iget-boolean v0, p1, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/N;->i:Z

    if-eqz v0, :cond_5e

    .line 3
    invoke-virtual {p0, p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b;->G(Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/M;)Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/l;

    move-result-object p1

    iget-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/i1;->e:Ljava/util/ArrayList;

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    iget-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/i1;->c:Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/Q;

    sget-object v1, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/h1;->c:Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/c0;

    invoke-virtual {v0, v1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/Q;->u(Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/h1;)V

    iget-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/i1;->c:Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/Q;

    iget-object v1, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b;->r:Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/L;

    invoke-virtual {v1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/N;->v()Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/N;

    invoke-virtual {p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/l;->n0()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/N;->s(Ljava/lang/String;)Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/N;

    invoke-virtual {v0, v1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/Q;->j(Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/O;)V

    return-object p1

    :cond_5e
    new-instance v0, Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/l;

    invoke-virtual {p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/N;->t()Ljava/lang/String;

    move-result-object v1

    iget-object v2, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/i1;->h:Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/D;

    invoke-static {v1, v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/F;->l(Ljava/lang/String;Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/D;)Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/F;

    move-result-object v1

    const/4 v2, 0x0

    iget-object v3, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/i1;->h:Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/D;

    iget-object p1, p1, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/N;->j:Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/c;

    invoke-virtual {v3, p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/D;->b(Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/c;)Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/c;

    invoke-direct {v0, v1, v2, p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/l;-><init>(Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/F;Ljava/lang/String;Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/c;)V

    .line 4
    invoke-direct {p0, v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b;->K(Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/r;)V

    iget-object p1, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/i1;->e:Ljava/util/ArrayList;

    invoke-virtual {p1, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    return-object v0
.end method

.method final E(Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/H;)V
    .registers 5

    invoke-virtual {p0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/i1;->a()Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/l;

    move-result-object v0

    if-nez v0, :cond_8

    iget-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/i1;->d:Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/h;

    :cond_8
    invoke-virtual {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/l;->d0()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/H;->j()Ljava/lang/String;

    move-result-object v2

    .line 1
    instance-of p1, p1, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/G;

    if-eqz p1, :cond_1a

    .line 2
    new-instance p1, Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/d;

    invoke-direct {p1, v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/d;-><init>(Ljava/lang/String;)V

    goto :goto_2b

    :cond_1a
    invoke-virtual {p0, v1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b;->b(Ljava/lang/String;)Z

    move-result p1

    if-eqz p1, :cond_26

    new-instance p1, Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/f;

    invoke-direct {p1, v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/f;-><init>(Ljava/lang/String;)V

    goto :goto_2b

    :cond_26
    new-instance p1, Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/u;

    invoke-direct {p1, v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/u;-><init>(Ljava/lang/String;)V

    :goto_2b
    invoke-virtual {v0, p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/l;->L(Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/r;)Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/l;

    return-void
.end method

.method final F(Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/I;)V
    .registers 3

    new-instance v0, Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/e;

    invoke-virtual {p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/I;->k()Ljava/lang/String;

    move-result-object p1

    invoke-direct {v0, p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/e;-><init>(Ljava/lang/String;)V

    invoke-direct {p0, v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b;->K(Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/r;)V

    return-void
.end method

.method final G(Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/M;)Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/l;
    .registers 6

    invoke-virtual {p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/N;->t()Ljava/lang/String;

    move-result-object v0

    iget-object v1, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/i1;->h:Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/D;

    invoke-static {v0, v1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/F;->l(Ljava/lang/String;Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/D;)Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/F;

    move-result-object v0

    new-instance v1, Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/l;

    iget-object v2, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/i1;->h:Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/D;

    iget-object v3, p1, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/N;->j:Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/c;

    invoke-virtual {v2, v3}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/D;->b(Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/c;)Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/c;

    const/4 v2, 0x0

    invoke-direct {v1, v0, v2, v3}, Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/l;-><init>(Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/F;Ljava/lang/String;Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/c;)V

    invoke-direct {p0, v1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b;->K(Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/r;)V

    .line 1
    iget-boolean p1, p1, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/N;->i:Z

    if-eqz p1, :cond_39

    .line 2
    invoke-virtual {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/F;->g()Z

    move-result p1

    if-eqz p1, :cond_36

    invoke-virtual {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/F;->d()Z

    move-result p1

    if-nez p1, :cond_39

    iget-object p1, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/i1;->c:Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/Q;

    const-string v0, "23192245103419162A115337125836001F33571B290A003C191F7E451D3A03582445053A1E1C65111232"

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/Q;->r(Ljava/lang/String;)V

    goto :goto_39

    :cond_36
    invoke-virtual {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/F;->k()Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/F;

    :cond_39
    :goto_39
    return-object v1
.end method

.method final H(Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/M;Z)Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/o;
    .registers 6

    invoke-virtual {p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/N;->t()Ljava/lang/String;

    move-result-object v0

    iget-object v1, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/i1;->h:Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/D;

    invoke-static {v0, v1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/F;->l(Ljava/lang/String;Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/D;)Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/F;

    move-result-object v0

    new-instance v1, Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/o;

    iget-object v2, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/i1;->h:Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/D;

    iget-object p1, p1, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/N;->j:Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/c;

    invoke-virtual {v2, p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/D;->b(Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/c;)Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/c;

    invoke-direct {v1, v0, p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/o;-><init>(Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/F;Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/c;)V

    .line 1
    iput-object v1, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b;->o:Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/o;

    .line 2
    invoke-direct {p0, v1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b;->K(Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/r;)V

    if-eqz p2, :cond_22

    iget-object p1, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/i1;->e:Ljava/util/ArrayList;

    invoke-virtual {p1, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_22
    return-object v1
.end method

.method final I(Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/r;)V
    .registers 5

    const-string v0, "0319270916"

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p0, v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b;->t(Ljava/lang/String;)Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/l;

    move-result-object v0

    const/4 v1, 0x0

    if-eqz v0, :cond_20

    invoke-virtual {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/l;->f0()Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/l;

    move-result-object v2

    if-eqz v2, :cond_1b

    invoke-virtual {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/l;->f0()Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/l;

    move-result-object v1

    const/4 v2, 0x1

    move-object v2, v1

    const/4 v1, 0x1

    goto :goto_28

    :cond_1b
    invoke-virtual {p0, v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b;->g(Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/l;)Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/l;

    move-result-object v2

    goto :goto_28

    :cond_20
    iget-object v2, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/i1;->e:Ljava/util/ArrayList;

    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/l;

    :goto_28
    if-eqz v1, :cond_31

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/N/a;->k(Ljava/lang/Object;)V

    .line 1
    invoke-virtual {v0, p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/r;->f(Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/r;)Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/r;

    goto :goto_34

    .line 2
    :cond_31
    invoke-virtual {v2, p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/l;->L(Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/r;)Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/l;

    :goto_34
    return-void
.end method

.method final J()V
    .registers 3

    iget-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b;->p:Ljava/util/ArrayList;

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    return-void
.end method

.method final L(Ljava/lang/String;)Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/l;
    .registers 4

    new-instance v0, Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/l;

    iget-object v1, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/i1;->h:Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/D;

    invoke-static {p1, v1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/F;->l(Ljava/lang/String;Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/D;)Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/F;

    move-result-object p1

    const/4 v1, 0x0

    .line 1
    invoke-direct {v0, p1, v1, v1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/l;-><init>(Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/F;Ljava/lang/String;Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/c;)V

    .line 2
    invoke-direct {p0, v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b;->K(Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/r;)V

    iget-object p1, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/i1;->e:Ljava/util/ArrayList;

    invoke-virtual {p1, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    return-object v0
.end method

.method final N(Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/l;)Z
    .registers 3

    iget-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b;->p:Ljava/util/ArrayList;

    invoke-direct {p0, v0, p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b;->M(Ljava/util/ArrayList;Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/l;)Z

    move-result p1

    return p1
.end method

.method final O(Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/l;)Z
    .registers 3

    invoke-virtual {p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/l;->d0()Ljava/lang/String;

    move-result-object p1

    sget-object v0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b;->B:[Ljava/lang/String;

    invoke-static {p1, v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/b0/b;->b(Ljava/lang/String;[Ljava/lang/String;)Z

    move-result p1

    return p1
.end method

.method final P()V
    .registers 2

    iget-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b;->k:Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/A;

    iput-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b;->l:Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/A;

    return-void
.end method

.method final Q(Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/l;)V
    .registers 3

    iget-boolean v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b;->m:Z

    if-eqz v0, :cond_5

    return-void

    :cond_5
    const-string v0, "1F0A2003"

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/r;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/String;->length()I

    move-result v0

    if-eqz v0, :cond_1f

    iput-object p1, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/i1;->f:Ljava/lang/String;

    const/4 v0, 0x1

    iput-boolean v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b;->m:Z

    iget-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/i1;->d:Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/h;

    invoke-virtual {v0, p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/r;->G(Ljava/lang/String;)V

    :cond_1f
    return-void
.end method

.method final R()V
    .registers 2

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b;->q:Ljava/util/ArrayList;

    return-void
.end method

.method final S(Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/l;)Z
    .registers 3

    iget-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/i1;->e:Ljava/util/ArrayList;

    invoke-direct {p0, v0, p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b;->M(Ljava/util/ArrayList;Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/l;)Z

    move-result p1

    return p1
.end method

.method final T()Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/A;
    .registers 2

    iget-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b;->l:Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/A;

    return-object v0
.end method

.method final U()Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/l;
    .registers 3

    iget-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/i1;->e:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    iget-object v1, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/i1;->e:Ljava/util/ArrayList;

    add-int/lit8 v0, v0, -0x1

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->remove(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/l;

    return-object v0
.end method

.method final V(Ljava/lang/String;)Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/l;
    .registers 5

    iget-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/i1;->e:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    add-int/lit8 v0, v0, -0x1

    :goto_8
    if-ltz v0, :cond_25

    iget-object v1, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/i1;->e:Ljava/util/ArrayList;

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/l;

    iget-object v2, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/i1;->e:Ljava/util/ArrayList;

    invoke-virtual {v2, v0}, Ljava/util/ArrayList;->remove(I)Ljava/lang/Object;

    invoke-virtual {v1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/l;->d0()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v2, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_22

    return-object v1

    :cond_22
    add-int/lit8 v0, v0, -0x1

    goto :goto_8

    :cond_25
    const/4 p1, 0x0

    return-object p1
.end method

.method final W(Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/l;)I
    .registers 4

    const/4 v0, 0x0

    :goto_1
    iget-object v1, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b;->p:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    if-ge v0, v1, :cond_15

    iget-object v1, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b;->p:Ljava/util/ArrayList;

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    if-ne p1, v1, :cond_12

    return v0

    :cond_12
    add-int/lit8 v0, v0, 0x1

    goto :goto_1

    :cond_15
    const/4 p1, -0x1

    return p1
.end method

.method final X(Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/O;Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/A;)Z
    .registers 3

    iput-object p1, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/i1;->g:Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/O;

    invoke-virtual {p2, p1, p0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/A;->d(Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/O;Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b;)Z

    move-result p1

    return p1
.end method

.method final Y(Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/l;)V
    .registers 3

    invoke-virtual {p0, p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b;->h(Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/l;)V

    iget-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b;->p:Ljava/util/ArrayList;

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    return-void
.end method

.method final Z(Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/l;I)V
    .registers 4

    invoke-virtual {p0, p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b;->h(Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/l;)V

    iget-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b;->p:Ljava/util/ArrayList;

    invoke-virtual {v0, p2, p1}, Ljava/util/ArrayList;->add(ILjava/lang/Object;)V

    return-void
.end method

.method final a0()V
    .registers 8

    .line 1
    iget-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b;->p:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    if-lez v0, :cond_17

    iget-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b;->p:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v1

    add-int/lit8 v1, v1, -0x1

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/l;

    goto :goto_18

    :cond_17
    const/4 v0, 0x0

    :goto_18
    if-eqz v0, :cond_6a

    .line 2
    invoke-virtual {p0, v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b;->S(Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/l;)Z

    move-result v1

    if-eqz v1, :cond_21

    goto :goto_6a

    :cond_21
    iget-object v1, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b;->p:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    const/4 v2, 0x1

    sub-int/2addr v1, v2

    move v3, v1

    :cond_2a
    const/4 v4, 0x0

    if-nez v3, :cond_2e

    goto :goto_41

    :cond_2e
    iget-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b;->p:Ljava/util/ArrayList;

    add-int/lit8 v3, v3, -0x1

    invoke-virtual {v0, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/l;

    if-eqz v0, :cond_40

    invoke-virtual {p0, v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b;->S(Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/l;)Z

    move-result v5

    if-eqz v5, :cond_2a

    :cond_40
    const/4 v2, 0x0

    :goto_41
    if-nez v2, :cond_4d

    iget-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b;->p:Ljava/util/ArrayList;

    add-int/lit8 v3, v3, 0x1

    invoke-virtual {v0, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/l;

    :cond_4d
    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/N/a;->k(Ljava/lang/Object;)V

    invoke-virtual {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/l;->d0()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {p0, v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b;->L(Ljava/lang/String;)Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/l;

    move-result-object v2

    invoke-virtual {v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/l;->d()Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/c;

    move-result-object v5

    invoke-virtual {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/l;->d()Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/c;

    move-result-object v6

    invoke-virtual {v5, v6}, Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/c;->e(Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/c;)V

    iget-object v5, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b;->p:Ljava/util/ArrayList;

    invoke-virtual {v5, v3, v2}, Ljava/util/ArrayList;->set(ILjava/lang/Object;)Ljava/lang/Object;

    if-ne v3, v1, :cond_40

    :cond_6a
    :goto_6a
    return-void
.end method

.method protected final b(Ljava/lang/String;)Z
    .registers 3

    const-string v0, "041B370C0321"

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_1b

    const-string v0, "040C3C0916"

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_19

    goto :goto_1b

    :cond_19
    const/4 p1, 0x0

    goto :goto_1c

    :cond_1b
    :goto_1b
    const/4 p1, 0x1

    :goto_1c
    return p1
.end method

.method final b0(Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/l;)V
    .registers 4

    iget-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b;->p:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    :cond_6
    add-int/lit8 v0, v0, -0x1

    if-ltz v0, :cond_19

    iget-object v1, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b;->p:Ljava/util/ArrayList;

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/l;

    if-ne v1, p1, :cond_6

    iget-object p1, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b;->p:Ljava/util/ArrayList;

    invoke-virtual {p1, v0}, Ljava/util/ArrayList;->remove(I)Ljava/lang/Object;

    :cond_19
    return-void
.end method

.method protected final c(Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/O;)Z
    .registers 3

    iput-object p1, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/i1;->g:Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/O;

    iget-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b;->k:Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/A;

    invoke-virtual {v0, p1, p0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/A;->d(Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/O;Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b;)Z

    move-result p1

    return p1
.end method

.method final c0(Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/l;)Z
    .registers 5

    iget-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/i1;->e:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    const/4 v1, 0x1

    sub-int/2addr v0, v1

    :goto_8
    if-ltz v0, :cond_1d

    iget-object v2, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/i1;->e:Ljava/util/ArrayList;

    invoke-virtual {v2, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/l;

    if-ne v2, p1, :cond_1a

    iget-object p1, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/i1;->e:Ljava/util/ArrayList;

    invoke-virtual {p1, v0}, Ljava/util/ArrayList;->remove(I)Ljava/lang/Object;

    return v1

    :cond_1a
    add-int/lit8 v0, v0, -0x1

    goto :goto_8

    :cond_1d
    const/4 p1, 0x0

    return p1
.end method

.method final d0(Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/l;Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/l;)V
    .registers 5

    iget-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b;->p:Ljava/util/ArrayList;

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->lastIndexOf(Ljava/lang/Object;)I

    move-result p1

    const/4 v1, -0x1

    if-eq p1, v1, :cond_b

    const/4 v1, 0x1

    goto :goto_c

    :cond_b
    const/4 v1, 0x0

    :goto_c
    invoke-static {v1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/N/a;->f(Z)V

    invoke-virtual {v0, p1, p2}, Ljava/util/ArrayList;->set(ILjava/lang/Object;)Ljava/lang/Object;

    return-void
.end method

.method final e0()V
    .registers 6

    iget-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/i1;->e:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    const/4 v1, 0x1

    sub-int/2addr v0, v1

    const/4 v2, 0x0

    :goto_9
    if-ltz v0, :cond_f6

    iget-object v3, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/i1;->e:Ljava/util/ArrayList;

    invoke-virtual {v3, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/l;

    if-nez v0, :cond_17

    const/4 v3, 0x0

    const/4 v2, 0x1

    :cond_17
    if-eqz v3, :cond_1e

    invoke-virtual {v3}, Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/l;->d0()Ljava/lang/String;

    move-result-object v3

    goto :goto_20

    :cond_1e
    const-string v3, ""

    :goto_20
    const-string v4, "041D29001021"

    invoke-static {v4}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v4, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_30

    sget-object v0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/A;->r:Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/i;

    goto/16 :goto_f4

    :cond_30
    const-string v4, "031C"

    invoke-static {v4}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    .line 1
    invoke-virtual {v4, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-nez v4, :cond_f2

    const-string v4, "0310"

    invoke-static {v4}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v4, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_4c

    if-nez v2, :cond_4c

    goto/16 :goto_f2

    :cond_4c
    const-string v4, "030A"

    invoke-static {v4}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v4, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_5c

    sget-object v0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/A;->p:Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/g;

    goto/16 :goto_f4

    :cond_5c
    const-string v4, "031A2A010A"

    invoke-static {v4}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v4, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-nez v4, :cond_ef

    const-string v4, "0310200417"

    invoke-static {v4}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v4, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-nez v4, :cond_ef

    const-string v4, "031E2A0A07"

    invoke-static {v4}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v4, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_81

    goto :goto_ef

    :cond_81
    const-string v4, "141935111A3A19"

    invoke-static {v4}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v4, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_90

    sget-object v0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/A;->m:Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/d;

    goto :goto_f4

    :cond_90
    const-string v4, "14172902013A0208"

    invoke-static {v4}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v4, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_9f

    sget-object v0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/A;->n:Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/e;

    goto :goto_f4

    :cond_9f
    const-string v4, "0319270916"

    invoke-static {v4}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v4, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_ae

    sget-object v0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/A;->k:Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/y;

    goto :goto_f4

    :cond_ae
    const-string v4, "1F1D2401"

    invoke-static {v4}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v4, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_bb

    goto :goto_e8

    :cond_bb
    const-string v4, "1517211C"

    invoke-static {v4}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v4, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_c8

    goto :goto_e8

    :cond_c8
    const-string v4, "110A24081626120C"

    invoke-static {v4}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v4, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_d7

    sget-object v0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/A;->u:Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/l;

    goto :goto_f4

    :cond_d7
    const-string v4, "1F0C2809"

    invoke-static {v4}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v4, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_e6

    sget-object v0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/A;->e:Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/s;

    goto :goto_f4

    :cond_e6
    if-eqz v2, :cond_eb

    :goto_e8
    sget-object v0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/A;->i:Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/w;

    goto :goto_f4

    :cond_eb
    add-int/lit8 v0, v0, -0x1

    goto/16 :goto_9

    :cond_ef
    :goto_ef
    sget-object v0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/A;->o:Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/f;

    goto :goto_f4

    :cond_f2
    :goto_f2
    sget-object v0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/A;->q:Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/h;

    .line 2
    :goto_f4
    iput-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b;->k:Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/A;

    :cond_f6
    return-void
.end method

.method final f0()V
    .registers 2

    const/4 v0, 0x0

    iput-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b;->o:Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/o;

    return-void
.end method

.method final g(Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/l;)Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/l;
    .registers 4

    iget-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/i1;->e:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    add-int/lit8 v0, v0, -0x1

    :goto_8
    if-ltz v0, :cond_22

    iget-object v1, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/i1;->e:Ljava/util/ArrayList;

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/l;

    if-ne v1, p1, :cond_1f

    iget-object p1, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/i1;->e:Ljava/util/ArrayList;

    add-int/lit8 v0, v0, -0x1

    invoke-virtual {p1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/l;

    return-object p1

    :cond_1f
    add-int/lit8 v0, v0, -0x1

    goto :goto_8

    :cond_22
    const/4 p1, 0x0

    return-object p1
.end method

.method final g0(Z)V
    .registers 2

    iput-boolean p1, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b;->t:Z

    return-void
.end method

.method final h(Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/l;)V
    .registers 9

    iget-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b;->p:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    const/4 v1, 0x1

    sub-int/2addr v0, v1

    const/4 v2, 0x0

    const/4 v3, 0x0

    :goto_a
    if-ltz v0, :cond_46

    iget-object v4, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b;->p:Ljava/util/ArrayList;

    invoke-virtual {v4, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/l;

    if-nez v4, :cond_17

    goto :goto_46

    .line 1
    :cond_17
    invoke-virtual {p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/l;->d0()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4}, Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/l;->d0()Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v5, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_35

    invoke-virtual {p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/l;->d()Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/c;

    move-result-object v5

    invoke-virtual {v4}, Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/l;->d()Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/c;

    move-result-object v4

    invoke-virtual {v5, v4}, Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/c;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_35

    const/4 v4, 0x1

    goto :goto_36

    :cond_35
    const/4 v4, 0x0

    :goto_36
    if-eqz v4, :cond_3a

    add-int/lit8 v3, v3, 0x1

    :cond_3a
    const/4 v4, 0x3

    if-ne v3, v4, :cond_43

    .line 2
    iget-object p1, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b;->p:Ljava/util/ArrayList;

    invoke-virtual {p1, v0}, Ljava/util/ArrayList;->remove(I)Ljava/lang/Object;

    goto :goto_46

    :cond_43
    add-int/lit8 v0, v0, -0x1

    goto :goto_a

    :cond_46
    :goto_46
    return-void
.end method

.method final h0(Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/l;)V
    .registers 2

    iput-object p1, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b;->n:Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/l;

    return-void
.end method

.method final i()V
    .registers 3

    :cond_0
    iget-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b;->p:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_1e

    iget-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b;->p:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    if-lez v0, :cond_1b

    iget-object v1, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b;->p:Ljava/util/ArrayList;

    add-int/lit8 v0, v0, -0x1

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->remove(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/l;

    goto :goto_1c

    :cond_1b
    const/4 v0, 0x0

    :goto_1c
    if-nez v0, :cond_0

    :cond_1e
    return-void
.end method

.method final i0()Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/A;
    .registers 2

    iget-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b;->k:Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/A;

    return-object v0
.end method

.method final j0(Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/A;)V
    .registers 2

    iput-object p1, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b;->k:Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/A;

    return-void
.end method

.method final k()V
    .registers 4

    const/4 v0, 0x4

    new-array v0, v0, [Ljava/lang/String;

    const/4 v1, 0x0

    const-string v2, "031A2A010A"

    invoke-static {v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    aput-object v2, v0, v1

    const/4 v1, 0x1

    const-string v2, "031E2A0A07"

    invoke-static {v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    aput-object v2, v0, v1

    const/4 v1, 0x2

    const-string v2, "0310200417"

    invoke-static {v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    aput-object v2, v0, v1

    const/4 v1, 0x3

    const-string v2, "031D28151F34031D"

    invoke-static {v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    aput-object v2, v0, v1

    invoke-direct {p0, v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b;->j([Ljava/lang/String;)V

    return-void
.end method

.method final l()V
    .registers 4

    const/4 v0, 0x1

    new-array v0, v0, [Ljava/lang/String;

    const/4 v1, 0x0

    const-string v2, "0319270916"

    invoke-static {v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    aput-object v2, v0, v1

    invoke-direct {p0, v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b;->j([Ljava/lang/String;)V

    return-void
.end method

.method final m()V
    .registers 4

    const/4 v0, 0x2

    new-array v0, v0, [Ljava/lang/String;

    const/4 v1, 0x0

    const-string v2, "030A"

    invoke-static {v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    aput-object v2, v0, v1

    const/4 v1, 0x1

    const-string v2, "031D28151F34031D"

    invoke-static {v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    aput-object v2, v0, v1

    invoke-direct {p0, v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b;->j([Ljava/lang/String;)V

    return-void
.end method

.method final n(Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/A;)V
    .registers 8

    iget-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/i1;->a:Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/E;

    invoke-virtual {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/E;->a()Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/C;

    move-result-object v0

    invoke-virtual {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/C;->a()Z

    move-result v0

    if-eqz v0, :cond_39

    iget-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/i1;->a:Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/E;

    invoke-virtual {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/E;->a()Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/C;

    move-result-object v0

    new-instance v1, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/B;

    iget-object v2, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/i1;->b:Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/a;

    invoke-virtual {v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/a;->E()I

    move-result v2

    const/4 v3, 0x2

    new-array v3, v3, [Ljava/lang/Object;

    const/4 v4, 0x0

    iget-object v5, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/i1;->g:Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/O;

    .line 1
    invoke-virtual {v5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    move-result-object v5

    aput-object v5, v3, v4

    const/4 v4, 0x1

    aput-object p1, v3, v4

    const-string p1, "2216201D0330140C200153211813200B530E520B1845043D1216650C1D75040C241116752C5D3638"

    invoke-static {p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    .line 2
    invoke-direct {v1, v2, p1, v3}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/B;-><init>(ILjava/lang/String;[Ljava/lang/Object;)V

    invoke-virtual {v0, v1}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    :cond_39
    return-void
.end method

.method final o(Z)V
    .registers 2

    iput-boolean p1, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b;->s:Z

    return-void
.end method

.method final p()Z
    .registers 2

    iget-boolean v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b;->s:Z

    return v0
.end method

.method final q(Ljava/lang/String;)V
    .registers 4

    :goto_0
    if-eqz p1, :cond_24

    invoke-virtual {p0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/i1;->a()Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/l;

    move-result-object v0

    invoke-virtual {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/l;->d0()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_24

    invoke-virtual {p0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/i1;->a()Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/l;

    move-result-object v0

    invoke-virtual {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/l;->d0()Ljava/lang/String;

    move-result-object v0

    sget-object v1, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b;->A:[Ljava/lang/String;

    invoke-static {v0, v1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/b0/b;->b(Ljava/lang/String;[Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_24

    invoke-virtual {p0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b;->U()Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/l;

    goto :goto_0

    :cond_24
    return-void
.end method

.method final r(Ljava/lang/String;)Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/l;
    .registers 5

    iget-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b;->p:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    add-int/lit8 v0, v0, -0x1

    :goto_8
    if-ltz v0, :cond_23

    iget-object v1, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b;->p:Ljava/util/ArrayList;

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/l;

    if-nez v1, :cond_15

    goto :goto_23

    :cond_15
    invoke-virtual {v1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/l;->d0()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v2, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_20

    return-object v1

    :cond_20
    add-int/lit8 v0, v0, -0x1

    goto :goto_8

    :cond_23
    :goto_23
    const/4 p1, 0x0

    return-object p1
.end method

.method final s()Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/o;
    .registers 2

    iget-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b;->o:Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/o;

    return-object v0
.end method

.method final t(Ljava/lang/String;)Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/l;
    .registers 5

    iget-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/i1;->e:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    :cond_6
    add-int/lit8 v0, v0, -0x1

    if-ltz v0, :cond_1d

    iget-object v1, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/i1;->e:Ljava/util/ArrayList;

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/l;

    invoke-virtual {v1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/l;->d0()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v2, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_6

    return-object v1

    :cond_1d
    const/4 p1, 0x0

    return-object p1
.end method

.method public final toString()Ljava/lang/String;
    .registers 3

    const-string v0, "230A200031201E142100012E140D3717163B032C2A0E163B4A"

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 1
    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d/d;->b(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    .line 2
    iget-object v1, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/i1;->g:Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/O;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v1, "5B58361112211245"

    invoke-static {v1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b;->k:Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/A;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v1, "5B5826100127121631201F301A1D2B114E"

    invoke-static {v1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/i1;->a()Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/l;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/16 v1, 0x7d

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method final u()Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/l;
    .registers 2

    iget-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b;->n:Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/l;

    return-object v0
.end method

.method final v()Ljava/util/List;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    iget-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b;->q:Ljava/util/ArrayList;

    return-object v0
.end method

.method final w(Ljava/lang/String;)Z
    .registers 3

    sget-object v0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b;->x:[Ljava/lang/String;

    invoke-virtual {p0, p1, v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b;->x(Ljava/lang/String;[Ljava/lang/String;)Z

    move-result p1

    return p1
.end method

.method final x(Ljava/lang/String;[Ljava/lang/String;)Z
    .registers 6

    sget-object v0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b;->v:[Ljava/lang/String;

    iget-object v1, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b;->u:[Ljava/lang/String;

    const/4 v2, 0x0

    aput-object p1, v1, v2

    invoke-direct {p0, v1, v0, p2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b;->A([Ljava/lang/String;[Ljava/lang/String;[Ljava/lang/String;)Z

    move-result p1

    return p1
.end method

.method final y([Ljava/lang/String;)Z
    .registers 4

    sget-object v0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b;->v:[Ljava/lang/String;

    const/4 v1, 0x0

    invoke-direct {p0, p1, v0, v1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b;->A([Ljava/lang/String;[Ljava/lang/String;[Ljava/lang/String;)Z

    move-result p1

    return p1
.end method

.method final z(Ljava/lang/String;)Z
    .registers 6

    iget-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/i1;->e:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    const/4 v1, 0x1

    sub-int/2addr v0, v1

    :goto_8
    if-ltz v0, :cond_2a

    iget-object v2, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/i1;->e:Ljava/util/ArrayList;

    invoke-virtual {v2, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/l;

    invoke-virtual {v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/l;->d0()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v2, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_1d

    return v1

    :cond_1d
    sget-object v3, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b;->z:[Ljava/lang/String;

    invoke-static {v2, v3}, Lcom/github/catvod/spider/xbpqxyq/xbpq/b0/b;->b(Ljava/lang/String;[Ljava/lang/String;)Z

    move-result v2

    if-nez v2, :cond_27

    const/4 p1, 0x0

    return p1

    :cond_27
    add-int/lit8 v0, v0, -0x1

    goto :goto_8

    :cond_2a
    const-string p1, "24102A101F3157162A1153371258370012361F19270916"

    invoke-static {p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    invoke-static {p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/N/a;->a(Ljava/lang/String;)V

    const/4 p1, 0x0

    goto :goto_36

    :goto_35
    throw p1

    :goto_36
    goto :goto_35
.end method
