.class public final Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/k;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field private static final b:Ljava/util/UUID;

.field private static final c:Ljava/util/UUID;

.field private static final d:Ljava/util/UUID;

.field private static final e:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Ljava/util/UUID;",
            ">;"
        }
    .end annotation
.end field

.field public static final f:Ljava/util/UUID;


# instance fields
.field private final a:Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/g;


# direct methods
.method static constructor <clinit>()V
    .registers 5

    const-string v0, "444B72534217453C68524B173555712447665A4007553178433E702736104F3904263566"

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Ljava/util/UUID;->fromString(Ljava/lang/String;)Ljava/util/UUID;

    move-result-object v0

    const-string v1, "463C04553060403C68533065415571564B145A4107574478464807263166343D75234564"

    invoke-static {v1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Ljava/util/UUID;->fromString(Ljava/lang/String;)Ljava/util/UUID;

    move-result-object v1

    sput-object v1, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/k;->b:Ljava/util/UUID;

    const-string v2, "363901274B11403D682436103155715142605A39015731784F4A75513763343E75514110"

    invoke-static {v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Ljava/util/UUID;->fromString(Ljava/lang/String;)Ljava/util/UUID;

    move-result-object v2

    sput-object v2, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/k;->c:Ljava/util/UUID;

    const-string v3, "4241735744624F4C685631104255715444145A3A7C2031784F4976543262454073554B6C"

    invoke-static {v3}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-static {v3}, Ljava/util/UUID;->fromString(Ljava/lang/String;)Ljava/util/UUID;

    move-result-object v3

    sput-object v3, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/k;->d:Ljava/util/UUID;

    new-instance v4, Ljava/util/ArrayList;

    invoke-direct {v4}, Ljava/util/ArrayList;-><init>()V

    sput-object v4, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/k;->e:Ljava/util/ArrayList;

    invoke-virtual {v4, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    invoke-virtual {v4, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    invoke-virtual {v4, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    invoke-virtual {v4, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    sput-object v3, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/k;->f:Ljava/util/UUID;

    return-void
.end method

.method public constructor <init>()V
    .registers 2

    invoke-static {}, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/g;->a()Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/g;

    move-result-object v0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/k;->a:Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/g;

    return-void
.end method

.method private c([CILjava/util/List;Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/j;)I
    .registers 14
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "([CI",
            "Ljava/util/List<",
            "Lcom/github/catvod/spider/xbpqxyq/xbpq/S/j;",
            ">;",
            "Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/j;",
            ")I"
        }
    .end annotation

    add-int/lit8 v0, p2, 0x1

    aget-char p2, p1, p2

    const/4 v1, 0x0

    const/4 v2, 0x0

    :goto_6
    if-ge v2, p2, :cond_44

    aget-char v3, p1, v0

    add-int/lit8 v0, v0, 0x1

    new-instance v4, Lcom/github/catvod/spider/xbpqxyq/xbpq/S/j;

    new-array v5, v1, [I

    invoke-direct {v4, v5}, Lcom/github/catvod/spider/xbpqxyq/xbpq/S/j;-><init>([I)V

    invoke-interface {p3, v4}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    add-int/lit8 v5, v0, 0x1

    aget-char v0, p1, v0

    if-eqz v0, :cond_1e

    const/4 v0, 0x1

    goto :goto_1f

    :cond_1e
    const/4 v0, 0x0

    :goto_1f
    if-eqz v0, :cond_25

    const/4 v0, -0x1

    invoke-virtual {v4, v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/S/j;->a(I)V

    :cond_25
    move v0, v5

    const/4 v5, 0x0

    :goto_27
    if-ge v5, v3, :cond_41

    invoke-interface {p4, p1, v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/j;->a([CI)I

    move-result v6

    invoke-interface {p4}, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/j;->size()I

    move-result v7

    add-int/2addr v0, v7

    invoke-interface {p4, p1, v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/j;->a([CI)I

    move-result v7

    invoke-interface {p4}, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/j;->size()I

    move-result v8

    add-int/2addr v0, v8

    invoke-virtual {v4, v6, v7}, Lcom/github/catvod/spider/xbpqxyq/xbpq/S/j;->b(II)V

    add-int/lit8 v5, v5, 0x1

    goto :goto_27

    :cond_41
    add-int/lit8 v2, v2, 0x1

    goto :goto_6

    :cond_44
    return v0
.end method

.method protected static d(Ljava/util/UUID;Ljava/util/UUID;)Z
    .registers 4

    sget-object v0, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/k;->e:Ljava/util/ArrayList;

    invoke-virtual {v0, p0}, Ljava/util/ArrayList;->indexOf(Ljava/lang/Object;)I

    move-result p0

    const/4 v1, 0x0

    if-gez p0, :cond_a

    return v1

    :cond_a
    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->indexOf(Ljava/lang/Object;)I

    move-result p1

    if-lt p1, p0, :cond_11

    const/4 v1, 0x1

    :cond_11
    return v1
.end method

.method protected static e([CI)J
    .registers 6

    aget-char v0, p0, p1

    add-int/lit8 v1, p1, 0x1

    aget-char v1, p0, v1

    shl-int/lit8 v1, v1, 0x10

    or-int/2addr v0, v1

    int-to-long v0, v0

    const-wide v2, 0xffffffffL

    and-long/2addr v0, v2

    add-int/lit8 p1, p1, 0x2

    aget-char v2, p0, p1

    add-int/lit8 p1, p1, 0x1

    aget-char p0, p0, p1

    shl-int/lit8 p0, p0, 0x10

    or-int/2addr p0, v2

    int-to-long p0, p0

    const/16 v2, 0x20

    shl-long/2addr p0, v2

    or-long/2addr p0, v0

    return-wide p0
.end method


# virtual methods
.method protected final a(Z)V
    .registers 3

    if-eqz p1, :cond_3

    return-void

    :cond_3
    new-instance p1, Ljava/lang/IllegalStateException;

    const/4 v0, 0x0

    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p1
.end method

.method public final b([C)Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/a;
    .registers 20

    move-object/from16 v0, p0

    const-class v1, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/a;

    invoke-virtual/range {p1 .. p1}, [C->clone()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, [C

    const/4 v3, 0x1

    const/4 v4, 0x1

    :goto_c
    array-length v5, v2

    const/4 v6, 0x2

    if-ge v4, v5, :cond_19

    aget-char v5, v2, v4

    sub-int/2addr v5, v6

    int-to-char v5, v5

    aput-char v5, v2, v4

    add-int/lit8 v4, v4, 0x1

    goto :goto_c

    :cond_19
    const/4 v4, 0x0

    aget-char v5, v2, v4

    const/4 v7, 0x3

    if-ne v5, v7, :cond_525

    .line 1
    invoke-static {v2, v3}, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/k;->e([CI)J

    move-result-wide v7

    const/4 v5, 0x5

    invoke-static {v2, v5}, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/k;->e([CI)J

    move-result-wide v9

    new-instance v5, Ljava/util/UUID;

    invoke-direct {v5, v9, v10, v7, v8}, Ljava/util/UUID;-><init>(JJ)V

    const/16 v7, 0x9

    .line 2
    sget-object v8, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/k;->e:Ljava/util/ArrayList;

    invoke-virtual {v8, v5}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result v8

    if-eqz v8, :cond_4ff

    sget-object v1, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/k;->b:Ljava/util/UUID;

    invoke-static {v1, v5}, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/k;->d(Ljava/util/UUID;Ljava/util/UUID;)Z

    move-result v1

    sget-object v8, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/k;->c:Ljava/util/UUID;

    invoke-static {v8, v5}, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/k;->d(Ljava/util/UUID;Ljava/util/UUID;)Z

    move-result v8

    .line 3
    invoke-static {v6}, Lcom/github/catvod/spider/xbpqxyq/xbpq/l/a;->b(I)[I

    move-result-object v6

    const/16 v9, 0xa

    .line 4
    aget-char v7, v2, v7

    aget v6, v6, v7

    const/16 v7, 0xb

    aget-char v9, v2, v9

    new-instance v10, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/a;

    invoke-direct {v10, v6, v9}, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/a;-><init>(II)V

    new-instance v6, Ljava/util/ArrayList;

    invoke-direct {v6}, Ljava/util/ArrayList;-><init>()V

    new-instance v9, Ljava/util/ArrayList;

    invoke-direct {v9}, Ljava/util/ArrayList;-><init>()V

    aget-char v7, v2, v7

    const/16 v11, 0xc

    const/4 v12, 0x0

    const/16 v13, 0xc

    :goto_67
    const v14, 0xffff

    if-ge v12, v7, :cond_12a

    add-int/lit8 v16, v13, 0x1

    aget-char v13, v2, v13

    const/4 v15, 0x0

    if-nez v13, :cond_7a

    invoke-virtual {v10, v15}, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/a;->a(Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/m;)V

    move/from16 v13, v16

    goto/16 :goto_123

    :cond_7a
    add-int/lit8 v17, v16, 0x1

    aget-char v15, v2, v16

    if-ne v15, v14, :cond_81

    const/4 v15, -0x1

    :cond_81
    packed-switch v13, :pswitch_data_554

    .line 5
    invoke-static {}, Ljava/util/Locale;->getDefault()Ljava/util/Locale;

    move-result-object v1

    new-array v2, v3, [Ljava/lang/Object;

    invoke-static {v13}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    const/4 v4, 0x0

    aput-object v3, v2, v4

    const-string v3, "231020450025121B2C031A301358361112211258311C0330575D21451A2657162A11532316142C015D"

    invoke-static {v3}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-static {v1, v3, v2}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    new-instance v2, Ljava/lang/IllegalArgumentException;

    invoke-direct {v2, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v2

    :pswitch_a1  #0xc
    new-instance v14, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/O;

    invoke-direct {v14}, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/O;-><init>()V

    goto :goto_e8

    :pswitch_a7  #0xb
    new-instance v14, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/U;

    invoke-direct {v14}, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/U;-><init>()V

    goto :goto_e8

    :pswitch_ad  #0xa
    new-instance v14, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/p0;

    invoke-direct {v14}, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/p0;-><init>()V

    goto :goto_e8

    :pswitch_b3  #0x9
    new-instance v14, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/q0;

    invoke-direct {v14}, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/q0;-><init>()V

    goto :goto_e8

    :pswitch_b9  #0x8
    new-instance v14, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/t;

    invoke-direct {v14}, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/t;-><init>()V

    goto :goto_e8

    :pswitch_bf  #0x7
    new-instance v14, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/e0;

    invoke-direct {v14}, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/e0;-><init>()V

    goto :goto_e8

    :pswitch_c5  #0x6
    new-instance v14, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/r0;

    invoke-direct {v14}, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/r0;-><init>()V

    goto :goto_e8

    :pswitch_cb  #0x5
    new-instance v14, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/o0;

    invoke-direct {v14}, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/o0;-><init>()V

    goto :goto_e8

    :pswitch_d1  #0x4
    new-instance v14, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/T;

    invoke-direct {v14}, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/T;-><init>()V

    goto :goto_e8

    :pswitch_d7  #0x3
    new-instance v14, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/r;

    invoke-direct {v14}, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/r;-><init>()V

    goto :goto_e8

    :pswitch_dd  #0x2
    new-instance v14, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/d0;

    invoke-direct {v14}, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/d0;-><init>()V

    goto :goto_e8

    :pswitch_e3  #0x1
    new-instance v14, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/s;

    invoke-direct {v14}, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/s;-><init>()V

    :goto_e8
    iput v15, v14, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/m;->c:I

    move-object v15, v14

    goto :goto_ed

    :pswitch_ec  #0x0
    const/4 v15, 0x0

    :goto_ed
    if-ne v13, v11, :cond_105

    add-int/lit8 v13, v17, 0x1

    .line 6
    aget-char v14, v2, v17

    new-instance v11, Lcom/github/catvod/spider/xbpqxyq/xbpq/S/l;

    move-object v4, v15

    check-cast v4, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/O;

    invoke-static {v14}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v14

    invoke-direct {v11, v4, v14}, Lcom/github/catvod/spider/xbpqxyq/xbpq/S/l;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    invoke-virtual {v6, v11}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    move/from16 v17, v13

    goto :goto_11e

    :cond_105
    instance-of v4, v15, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/u;

    if-eqz v4, :cond_11e

    add-int/lit8 v4, v17, 0x1

    aget-char v11, v2, v17

    new-instance v13, Lcom/github/catvod/spider/xbpqxyq/xbpq/S/l;

    move-object v14, v15

    check-cast v14, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/u;

    invoke-static {v11}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v11

    invoke-direct {v13, v14, v11}, Lcom/github/catvod/spider/xbpqxyq/xbpq/S/l;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    invoke-virtual {v9, v13}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    move/from16 v17, v4

    :cond_11e
    :goto_11e
    invoke-virtual {v10, v15}, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/a;->a(Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/m;)V

    move/from16 v13, v17

    :goto_123
    add-int/lit8 v12, v12, 0x1

    const/4 v4, 0x0

    const/16 v11, 0xc

    goto/16 :goto_67

    :cond_12a
    invoke-virtual {v6}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v4

    :goto_12e
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    move-result v6

    if-eqz v6, :cond_151

    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Lcom/github/catvod/spider/xbpqxyq/xbpq/S/l;

    iget-object v7, v6, Lcom/github/catvod/spider/xbpqxyq/xbpq/S/l;->c:Ljava/lang/Object;

    check-cast v7, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/O;

    iget-object v11, v10, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/a;->a:Ljava/util/ArrayList;

    iget-object v6, v6, Lcom/github/catvod/spider/xbpqxyq/xbpq/S/l;->d:Ljava/lang/Object;

    check-cast v6, Ljava/lang/Integer;

    invoke-virtual {v6}, Ljava/lang/Integer;->intValue()I

    move-result v6

    invoke-virtual {v11, v6}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/m;

    iput-object v6, v7, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/O;->g:Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/m;

    goto :goto_12e

    :cond_151
    invoke-virtual {v9}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v4

    :goto_155
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    move-result v6

    if-eqz v6, :cond_178

    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Lcom/github/catvod/spider/xbpqxyq/xbpq/S/l;

    iget-object v7, v6, Lcom/github/catvod/spider/xbpqxyq/xbpq/S/l;->c:Ljava/lang/Object;

    check-cast v7, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/u;

    iget-object v9, v10, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/a;->a:Ljava/util/ArrayList;

    iget-object v6, v6, Lcom/github/catvod/spider/xbpqxyq/xbpq/S/l;->d:Ljava/lang/Object;

    check-cast v6, Ljava/lang/Integer;

    invoke-virtual {v6}, Ljava/lang/Integer;->intValue()I

    move-result v6

    invoke-virtual {v9, v6}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/t;

    iput-object v6, v7, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/u;->i:Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/t;

    goto :goto_155

    :cond_178
    add-int/lit8 v4, v13, 0x1

    aget-char v6, v2, v13

    const/4 v7, 0x0

    :goto_17d
    if-ge v7, v6, :cond_191

    add-int/lit8 v9, v4, 0x1

    aget-char v4, v2, v4

    iget-object v11, v10, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/a;->a:Ljava/util/ArrayList;

    invoke-virtual {v11, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/v;

    iput-boolean v3, v4, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/v;->h:Z

    add-int/lit8 v7, v7, 0x1

    move v4, v9

    goto :goto_17d

    :cond_191
    if-eqz v1, :cond_1ad

    add-int/lit8 v1, v4, 0x1

    aget-char v4, v2, v4

    const/4 v6, 0x0

    :goto_198
    if-ge v6, v4, :cond_1ac

    add-int/lit8 v7, v1, 0x1

    aget-char v1, v2, v1

    iget-object v9, v10, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/a;->a:Ljava/util/ArrayList;

    invoke-virtual {v9, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/d0;

    iput-boolean v3, v1, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/d0;->h:Z

    add-int/lit8 v6, v6, 0x1

    move v1, v7

    goto :goto_198

    :cond_1ac
    move v4, v1

    :cond_1ad
    add-int/lit8 v1, v4, 0x1

    aget-char v4, v2, v4

    iget v6, v10, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/a;->e:I

    if-ne v6, v3, :cond_1b9

    new-array v6, v4, [I

    iput-object v6, v10, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/a;->g:[I

    :cond_1b9
    new-array v6, v4, [Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/d0;

    iput-object v6, v10, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/a;->c:[Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/d0;

    const/4 v6, 0x0

    :goto_1be
    if-ge v6, v4, :cond_1ef

    add-int/lit8 v7, v1, 0x1

    aget-char v1, v2, v1

    iget-object v9, v10, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/a;->a:Ljava/util/ArrayList;

    invoke-virtual {v9, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/d0;

    iget-object v9, v10, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/a;->c:[Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/d0;

    aput-object v1, v9, v6

    iget v1, v10, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/a;->e:I

    if-ne v1, v3, :cond_1eb

    add-int/lit8 v1, v7, 0x1

    aget-char v7, v2, v7

    if-ne v7, v14, :cond_1db

    const/4 v7, -0x1

    :cond_1db
    iget-object v9, v10, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/a;->g:[I

    aput v7, v9, v6

    sget-object v7, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/k;->c:Ljava/util/UUID;

    invoke-static {v7, v5}, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/k;->d(Ljava/util/UUID;Ljava/util/UUID;)Z

    move-result v7

    if-nez v7, :cond_1ec

    add-int/lit8 v7, v1, 0x1

    aget-char v1, v2, v1

    :cond_1eb
    move v1, v7

    :cond_1ec
    add-int/lit8 v6, v6, 0x1

    goto :goto_1be

    :cond_1ef
    new-array v4, v4, [Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/e0;

    iput-object v4, v10, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/a;->d:[Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/e0;

    iget-object v4, v10, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/a;->a:Ljava/util/ArrayList;

    invoke-virtual {v4}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v4

    :goto_1f9
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    move-result v6

    if-eqz v6, :cond_21a

    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/m;

    instance-of v7, v6, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/e0;

    if-nez v7, :cond_20a

    goto :goto_1f9

    :cond_20a
    move-object v7, v6

    check-cast v7, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/e0;

    iget-object v9, v10, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/a;->d:[Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/e0;

    iget v6, v6, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/m;->c:I

    aput-object v7, v9, v6

    iget-object v9, v10, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/a;->c:[Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/d0;

    aget-object v6, v9, v6

    iput-object v7, v6, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/d0;->g:Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/e0;

    goto :goto_1f9

    :cond_21a
    add-int/lit8 v4, v1, 0x1

    aget-char v1, v2, v1

    const/4 v6, 0x0

    :goto_21f
    if-ge v6, v1, :cond_236

    add-int/lit8 v7, v4, 0x1

    aget-char v4, v2, v4

    iget-object v9, v10, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/a;->i:Ljava/util/ArrayList;

    iget-object v11, v10, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/a;->a:Ljava/util/ArrayList;

    invoke-virtual {v11, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/r0;

    invoke-virtual {v9, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/lit8 v6, v6, 0x1

    move v4, v7

    goto :goto_21f

    :cond_236
    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    .line 7
    new-instance v6, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/h;

    invoke-direct {v6}, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/h;-><init>()V

    .line 8
    invoke-direct {v0, v2, v4, v1, v6}, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/k;->c([CILjava/util/List;Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/j;)I

    move-result v4

    sget-object v6, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/k;->d:Ljava/util/UUID;

    invoke-static {v6, v5}, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/k;->d(Ljava/util/UUID;Ljava/util/UUID;)Z

    move-result v5

    if-eqz v5, :cond_255

    .line 9
    new-instance v5, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/i;

    invoke-direct {v5}, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/i;-><init>()V

    .line 10
    invoke-direct {v0, v2, v4, v1, v5}, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/k;->c([CILjava/util/List;Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/j;)I

    move-result v4

    :cond_255
    add-int/lit8 v5, v4, 0x1

    aget-char v4, v2, v4

    const/4 v6, 0x0

    :goto_25a
    if-ge v6, v4, :cond_301

    aget-char v7, v2, v5

    add-int/lit8 v9, v5, 0x1

    aget-char v9, v2, v9

    add-int/lit8 v11, v5, 0x2

    aget-char v11, v2, v11

    add-int/lit8 v12, v5, 0x3

    aget-char v12, v2, v12

    add-int/lit8 v13, v5, 0x4

    aget-char v13, v2, v13

    add-int/lit8 v15, v5, 0x5

    aget-char v15, v2, v15

    .line 11
    iget-object v14, v10, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/a;->a:Ljava/util/ArrayList;

    invoke-virtual {v14, v9}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v9

    check-cast v9, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/m;

    packed-switch v11, :pswitch_data_572

    new-instance v1, Ljava/lang/IllegalArgumentException;

    const-string v2, "231020450025121B2C031A3013583117123B0411310C1C3B570C3C1516751E0B650B1C21570E24091A3159"

    invoke-static {v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-direct {v1, v2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v1

    :pswitch_289  #0xa
    new-instance v11, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/V;

    invoke-direct {v11, v9, v12}, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/V;-><init>(Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/m;I)V

    goto :goto_2d8

    :pswitch_28f  #0x9
    new-instance v11, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/u0;

    invoke-direct {v11, v9}, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/u0;-><init>(Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/m;)V

    goto :goto_2d8

    :pswitch_295  #0x8
    new-instance v11, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/P;

    invoke-virtual {v1, v12}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v12

    check-cast v12, Lcom/github/catvod/spider/xbpqxyq/xbpq/S/j;

    invoke-direct {v11, v9, v12}, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/P;-><init>(Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/m;Lcom/github/catvod/spider/xbpqxyq/xbpq/S/j;)V

    goto :goto_2d8

    :pswitch_2a1  #0x7
    new-instance v11, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/m0;

    invoke-virtual {v1, v12}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v12

    check-cast v12, Lcom/github/catvod/spider/xbpqxyq/xbpq/S/j;

    invoke-direct {v11, v9, v12}, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/m0;-><init>(Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/m;Lcom/github/catvod/spider/xbpqxyq/xbpq/S/j;)V

    goto :goto_2d8

    :pswitch_2ad  #0x6
    new-instance v11, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/o;

    invoke-direct {v11, v9, v12, v13}, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/o;-><init>(Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/m;II)V

    goto :goto_2d8

    :pswitch_2b3  #0x5
    new-instance v11, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/q;

    if-eqz v15, :cond_2bc

    const/4 v13, -0x1

    invoke-direct {v11, v9, v13}, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/q;-><init>(Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/m;I)V

    goto :goto_2d8

    :cond_2bc
    invoke-direct {v11, v9, v12}, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/q;-><init>(Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/m;I)V

    goto :goto_2d8

    :pswitch_2c0  #0x4
    new-instance v11, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/W;

    if-eqz v15, :cond_2c6

    const/4 v14, 0x1

    goto :goto_2c7

    :cond_2c6
    const/4 v14, 0x0

    :goto_2c7
    invoke-direct {v11, v9, v12, v13, v14}, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/W;-><init>(Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/m;IIZ)V

    goto :goto_2d8

    :pswitch_2cb  #0x3
    new-instance v11, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/f0;

    iget-object v13, v10, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/a;->a:Ljava/util/ArrayList;

    invoke-virtual {v13, v12}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v12

    check-cast v12, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/d0;

    invoke-direct {v11, v12, v15, v9}, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/f0;-><init>(Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/d0;ILcom/github/catvod/spider/xbpqxyq/xbpq/Q/m;)V

    :goto_2d8
    const/4 v14, -0x1

    goto :goto_2ed

    :pswitch_2da  #0x2
    new-instance v11, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/c0;

    const/4 v14, -0x1

    if-eqz v15, :cond_2e3

    invoke-direct {v11, v9, v14, v13}, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/c0;-><init>(Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/m;II)V

    goto :goto_2ed

    :cond_2e3
    invoke-direct {v11, v9, v12, v13}, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/c0;-><init>(Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/m;II)V

    goto :goto_2ed

    :pswitch_2e7  #0x1
    const/4 v14, -0x1

    new-instance v11, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/x;

    invoke-direct {v11, v9}, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/x;-><init>(Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/m;)V

    .line 12
    :goto_2ed
    iget-object v9, v10, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/a;->a:Ljava/util/ArrayList;

    invoke-virtual {v9, v7}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/m;

    invoke-virtual {v7, v11}, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/m;->a(Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/t0;)V

    add-int/lit8 v5, v5, 0x6

    add-int/lit8 v6, v6, 0x1

    const v14, 0xffff

    goto/16 :goto_25a

    :cond_301
    const/4 v14, -0x1

    iget-object v1, v10, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/a;->a:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :cond_308
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    if-eqz v4, :cond_34d

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/m;

    const/4 v6, 0x0

    :goto_315
    invoke-virtual {v4}, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/m;->b()I

    move-result v7

    if-ge v6, v7, :cond_308

    invoke-virtual {v4, v6}, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/m;->d(I)Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/t0;

    move-result-object v7

    instance-of v9, v7, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/f0;

    if-nez v9, :cond_324

    goto :goto_34a

    :cond_324
    check-cast v7, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/f0;

    iget-object v9, v10, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/a;->c:[Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/d0;

    iget-object v11, v7, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/t0;->a:Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/m;

    iget v13, v11, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/m;->c:I

    aget-object v9, v9, v13

    iget-boolean v9, v9, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/d0;->h:Z

    if-eqz v9, :cond_337

    iget v9, v7, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/f0;->b:I

    if-nez v9, :cond_337

    goto :goto_338

    :cond_337
    const/4 v13, -0x1

    :goto_338
    new-instance v9, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/x;

    iget-object v11, v7, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/f0;->c:Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/m;

    invoke-direct {v9, v11, v13}, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/x;-><init>(Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/m;I)V

    iget-object v11, v10, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/a;->d:[Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/e0;

    iget-object v7, v7, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/t0;->a:Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/m;

    iget v7, v7, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/m;->c:I

    aget-object v7, v11, v7

    invoke-virtual {v7, v9}, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/m;->a(Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/t0;)V

    :goto_34a
    add-int/lit8 v6, v6, 0x1

    goto :goto_315

    :cond_34d
    iget-object v1, v10, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/a;->a:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :cond_353
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    if-eqz v4, :cond_3b9

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/m;

    instance-of v6, v4, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/u;

    if-eqz v6, :cond_37d

    move-object v6, v4

    check-cast v6, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/u;

    iget-object v7, v6, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/u;->i:Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/t;

    if-eqz v7, :cond_377

    iget-object v9, v7, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/t;->g:Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/u;

    if-nez v9, :cond_371

    iput-object v6, v7, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/t;->g:Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/u;

    goto :goto_37d

    :cond_371
    new-instance v1, Ljava/lang/IllegalStateException;

    invoke-direct {v1}, Ljava/lang/IllegalStateException;-><init>()V

    throw v1

    :cond_377
    new-instance v1, Ljava/lang/IllegalStateException;

    invoke-direct {v1}, Ljava/lang/IllegalStateException;-><init>()V

    throw v1

    :cond_37d
    :goto_37d
    instance-of v6, v4, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/U;

    if-eqz v6, :cond_39b

    check-cast v4, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/U;

    const/4 v6, 0x0

    :goto_384
    invoke-virtual {v4}, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/m;->b()I

    move-result v7

    if-ge v6, v7, :cond_353

    invoke-virtual {v4, v6}, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/m;->d(I)Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/t0;

    move-result-object v7

    iget-object v7, v7, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/t0;->a:Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/m;

    instance-of v9, v7, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/T;

    if-eqz v9, :cond_398

    check-cast v7, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/T;

    iput-object v4, v7, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/T;->j:Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/U;

    :cond_398
    add-int/lit8 v6, v6, 0x1

    goto :goto_384

    :cond_39b
    instance-of v6, v4, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/q0;

    if-eqz v6, :cond_353

    check-cast v4, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/q0;

    const/4 v6, 0x0

    :goto_3a2
    invoke-virtual {v4}, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/m;->b()I

    move-result v7

    if-ge v6, v7, :cond_353

    invoke-virtual {v4, v6}, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/m;->d(I)Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/t0;

    move-result-object v7

    iget-object v7, v7, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/t0;->a:Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/m;

    instance-of v9, v7, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/p0;

    if-eqz v9, :cond_3b6

    check-cast v7, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/p0;

    iput-object v4, v7, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/p0;->i:Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/q0;

    :cond_3b6
    add-int/lit8 v6, v6, 0x1

    goto :goto_3a2

    :cond_3b9
    add-int/lit8 v1, v5, 0x1

    aget-char v4, v2, v5

    const/4 v5, 0x1

    :goto_3be
    if-gt v5, v4, :cond_3d9

    add-int/lit8 v6, v1, 0x1

    aget-char v1, v2, v1

    iget-object v7, v10, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/a;->a:Ljava/util/ArrayList;

    invoke-virtual {v7, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/v;

    iget-object v7, v10, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/a;->b:Ljava/util/ArrayList;

    invoke-virtual {v7, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/lit8 v7, v5, -0x1

    iput v7, v1, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/v;->g:I

    add-int/lit8 v5, v5, 0x1

    move v1, v6

    goto :goto_3be

    :cond_3d9
    iget v4, v10, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/a;->e:I

    if-ne v4, v3, :cond_4ad

    if-eqz v8, :cond_456

    add-int/lit8 v4, v1, 0x1

    aget-char v1, v2, v1

    new-array v1, v1, [Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/C;

    iput-object v1, v10, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/a;->h:[Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/C;

    const/4 v1, 0x0

    :goto_3e8
    iget-object v5, v10, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/a;->h:[Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/C;

    array-length v5, v5

    if-ge v1, v5, :cond_4ad

    invoke-static {}, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/E;->values()[Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/E;

    move-result-object v5

    add-int/lit8 v6, v4, 0x1

    aget-char v4, v2, v4

    aget-object v4, v5, v4

    add-int/lit8 v5, v6, 0x1

    aget-char v13, v2, v6

    const v6, 0xffff

    if-ne v13, v6, :cond_401

    const/4 v13, -0x1

    :cond_401
    add-int/lit8 v7, v5, 0x1

    aget-char v5, v2, v5

    if-ne v5, v6, :cond_408

    const/4 v5, -0x1

    .line 13
    :cond_408
    invoke-virtual {v4}, Ljava/lang/Enum;->ordinal()I

    move-result v8

    packed-switch v8, :pswitch_data_58a

    invoke-static {}, Ljava/util/Locale;->getDefault()Ljava/util/Locale;

    move-result-object v1

    new-array v2, v3, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object v4, v2, v3

    const-string v3, "231020450025121B2C031A30135829000B3005582406073C181665110A2512586001533C04582B0A07750119290C177B"

    invoke-static {v3}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-static {v1, v3, v2}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    new-instance v2, Ljava/lang/IllegalArgumentException;

    invoke-direct {v2, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v2

    :pswitch_428  #0x7
    new-instance v4, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/N;

    invoke-direct {v4, v13}, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/N;-><init>(I)V

    goto :goto_44e

    :pswitch_42e  #0x6
    sget-object v4, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/M;->a:Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/M;

    goto :goto_44e

    :pswitch_431  #0x5
    new-instance v4, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/L;

    invoke-direct {v4, v13}, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/L;-><init>(I)V

    goto :goto_44e

    :pswitch_437  #0x4
    sget-object v4, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/K;->a:Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/K;

    goto :goto_44e

    :pswitch_43a  #0x3
    sget-object v4, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/J;->a:Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/J;

    goto :goto_44e

    :pswitch_43d  #0x2
    new-instance v4, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/I;

    invoke-direct {v4, v13}, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/I;-><init>(I)V

    goto :goto_44e

    :pswitch_443  #0x1
    new-instance v4, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/G;

    invoke-direct {v4, v13, v5}, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/G;-><init>(II)V

    goto :goto_44e

    :pswitch_449  #0x0
    new-instance v4, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/F;

    invoke-direct {v4, v13}, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/F;-><init>(I)V

    .line 14
    :goto_44e
    iget-object v5, v10, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/a;->h:[Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/C;

    aput-object v4, v5, v1

    add-int/lit8 v1, v1, 0x1

    move v4, v7

    goto :goto_3e8

    :cond_456
    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    iget-object v2, v10, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/a;->a:Ljava/util/ArrayList;

    invoke-virtual {v2}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :cond_461
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    if-eqz v4, :cond_49f

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/m;

    const/4 v5, 0x0

    :goto_46e
    invoke-virtual {v4}, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/m;->b()I

    move-result v6

    if-ge v5, v6, :cond_461

    invoke-virtual {v4, v5}, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/m;->d(I)Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/t0;

    move-result-object v6

    instance-of v7, v6, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/o;

    if-nez v7, :cond_47d

    goto :goto_49c

    :cond_47d
    move-object v7, v6

    check-cast v7, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/o;

    iget v8, v7, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/o;->b:I

    iget v7, v7, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/o;->c:I

    new-instance v9, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/G;

    invoke-direct {v9, v8, v7}, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/G;-><init>(II)V

    new-instance v7, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/o;

    iget-object v6, v6, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/t0;->a:Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/m;

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v11

    invoke-direct {v7, v6, v8, v11}, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/o;-><init>(Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/m;II)V

    .line 15
    iget-object v6, v4, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/m;->e:Ljava/util/ArrayList;

    invoke-virtual {v6, v5, v7}, Ljava/util/ArrayList;->set(ILjava/lang/Object;)Ljava/lang/Object;

    .line 16
    invoke-virtual {v1, v9}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :goto_49c
    add-int/lit8 v5, v5, 0x1

    goto :goto_46e

    :cond_49f
    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v2

    new-array v2, v2, [Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/C;

    invoke-virtual {v1, v2}, Ljava/util/ArrayList;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;

    move-result-object v1

    check-cast v1, [Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/C;

    iput-object v1, v10, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/a;->h:[Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/C;

    .line 17
    :cond_4ad
    iget-object v1, v10, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/a;->a:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :cond_4b3
    :goto_4b3
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_4f1

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/m;

    instance-of v4, v2, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/p0;

    if-nez v4, :cond_4c4

    goto :goto_4b3

    :cond_4c4
    iget-object v4, v10, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/a;->c:[Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/d0;

    iget v5, v2, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/m;->c:I

    aget-object v4, v4, v5

    iget-boolean v4, v4, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/d0;->h:Z

    if-eqz v4, :cond_4b3

    invoke-virtual {v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/m;->b()I

    move-result v4

    sub-int/2addr v4, v3

    invoke-virtual {v2, v4}, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/m;->d(I)Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/t0;

    move-result-object v4

    iget-object v4, v4, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/t0;->a:Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/m;

    instance-of v5, v4, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/O;

    if-eqz v5, :cond_4b3

    iget-boolean v5, v4, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/m;->d:Z

    if-eqz v5, :cond_4b3

    const/4 v5, 0x0

    invoke-virtual {v4, v5}, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/m;->d(I)Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/t0;

    move-result-object v4

    iget-object v4, v4, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/t0;->a:Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/m;

    instance-of v4, v4, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/e0;

    if-eqz v4, :cond_4b3

    check-cast v2, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/p0;

    iput-boolean v3, v2, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/p0;->j:Z

    goto :goto_4b3

    .line 18
    :cond_4f1
    iget-object v1, v0, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/k;->a:Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/g;

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v0, v10}, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/k;->f(Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/a;)V

    iget-object v1, v0, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/k;->a:Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/g;

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    return-object v10

    :cond_4ff
    invoke-static {}, Ljava/util/Locale;->getDefault()Ljava/util/Locale;

    move-result-object v2

    new-array v4, v6, [Ljava/lang/Object;

    const/4 v6, 0x0

    aput-object v5, v4, v6

    sget-object v5, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/k;->f:Ljava/util/UUID;

    aput-object v5, v4, v3

    const-string v3, "341730091775191731451730041D370C12391E02204532013958320C073D572D102C3775520B654D162D071D26111631575D36451C27571965091632161B3C4526003E3C6C4B"

    invoke-static {v3}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-static {v2, v3, v4}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v2

    new-instance v3, Ljava/lang/UnsupportedOperationException;

    new-instance v4, Ljava/io/InvalidClassException;

    invoke-virtual {v1}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v4, v1, v2}, Ljava/io/InvalidClassException;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    invoke-direct {v3, v4}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/Throwable;)V

    throw v3

    :cond_525
    invoke-static {}, Ljava/util/Locale;->getDefault()Ljava/util/Locale;

    move-result-object v2

    new-array v4, v6, [Ljava/lang/Object;

    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    const/4 v6, 0x0

    aput-object v5, v4, v6

    invoke-static {v7}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    aput-object v5, v4, v3

    const-string v3, "341730091775191731451730041D370C12391E02204532013958320C073D570E2017003C1816654017755F1D3D151636031D214556315E56"

    invoke-static {v3}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-static {v2, v3, v4}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v2

    new-instance v3, Ljava/lang/UnsupportedOperationException;

    new-instance v4, Ljava/io/InvalidClassException;

    invoke-virtual {v1}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v4, v1, v2}, Ljava/io/InvalidClassException;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    invoke-direct {v3, v4}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/Throwable;)V

    goto :goto_552

    :goto_551
    throw v3

    :goto_552
    goto :goto_551

    nop

    :pswitch_data_554
    .packed-switch 0x0
        :pswitch_ec  #00000000
        :pswitch_e3  #00000001
        :pswitch_dd  #00000002
        :pswitch_d7  #00000003
        :pswitch_d1  #00000004
        :pswitch_cb  #00000005
        :pswitch_c5  #00000006
        :pswitch_bf  #00000007
        :pswitch_b9  #00000008
        :pswitch_b3  #00000009
        :pswitch_ad  #0000000a
        :pswitch_a7  #0000000b
        :pswitch_a1  #0000000c
    .end packed-switch

    :pswitch_data_572
    .packed-switch 0x1
        :pswitch_2e7  #00000001
        :pswitch_2da  #00000002
        :pswitch_2cb  #00000003
        :pswitch_2c0  #00000004
        :pswitch_2b3  #00000005
        :pswitch_2ad  #00000006
        :pswitch_2a1  #00000007
        :pswitch_295  #00000008
        :pswitch_28f  #00000009
        :pswitch_289  #0000000a
    .end packed-switch

    :pswitch_data_58a
    .packed-switch 0x0
        :pswitch_449  #00000000
        :pswitch_443  #00000001
        :pswitch_43d  #00000002
        :pswitch_43a  #00000003
        :pswitch_437  #00000004
        :pswitch_431  #00000005
        :pswitch_42e  #00000006
        :pswitch_428  #00000007
    .end packed-switch
.end method

.method protected final f(Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/a;)V
    .registers 8

    iget-object p1, p1, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/a;->a:Ljava/util/ArrayList;

    invoke-virtual {p1}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :goto_6
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_111

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/m;

    if-nez v0, :cond_15

    goto :goto_6

    .line 1
    :cond_15
    iget-boolean v1, v0, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/m;->d:Z

    const/4 v2, 0x0

    const/4 v3, 0x1

    if-nez v1, :cond_24

    .line 2
    invoke-virtual {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/m;->b()I

    move-result v1

    if-gt v1, v3, :cond_22

    goto :goto_24

    :cond_22
    const/4 v1, 0x0

    goto :goto_25

    :cond_24
    :goto_24
    const/4 v1, 0x1

    :goto_25
    invoke-virtual {p0, v1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/k;->a(Z)V

    instance-of v1, v0, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/T;

    if-eqz v1, :cond_39

    move-object v1, v0

    check-cast v1, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/T;

    iget-object v1, v1, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/T;->j:Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/U;

    if-eqz v1, :cond_35

    const/4 v1, 0x1

    goto :goto_36

    :cond_35
    const/4 v1, 0x0

    :goto_36
    invoke-virtual {p0, v1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/k;->a(Z)V

    :cond_39
    instance-of v1, v0, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/p0;

    if-eqz v1, :cond_91

    move-object v1, v0

    check-cast v1, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/p0;

    iget-object v4, v1, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/p0;->i:Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/q0;

    if-eqz v4, :cond_46

    const/4 v4, 0x1

    goto :goto_47

    :cond_46
    const/4 v4, 0x0

    :goto_47
    invoke-virtual {p0, v4}, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/k;->a(Z)V

    invoke-virtual {v1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/m;->b()I

    move-result v4

    const/4 v5, 0x2

    if-ne v4, v5, :cond_53

    const/4 v4, 0x1

    goto :goto_54

    :cond_53
    const/4 v4, 0x0

    :goto_54
    invoke-virtual {p0, v4}, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/k;->a(Z)V

    invoke-virtual {v1, v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/m;->d(I)Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/t0;

    move-result-object v4

    iget-object v4, v4, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/t0;->a:Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/m;

    instance-of v4, v4, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/o0;

    if-eqz v4, :cond_70

    invoke-virtual {v1, v3}, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/m;->d(I)Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/t0;

    move-result-object v4

    iget-object v4, v4, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/t0;->a:Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/m;

    instance-of v4, v4, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/O;

    invoke-virtual {p0, v4}, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/k;->a(Z)V

    iget-boolean v1, v1, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/v;->h:Z

    xor-int/2addr v1, v3

    goto :goto_87

    :cond_70
    invoke-virtual {v1, v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/m;->d(I)Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/t0;

    move-result-object v4

    iget-object v4, v4, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/t0;->a:Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/m;

    instance-of v4, v4, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/O;

    if-eqz v4, :cond_8b

    invoke-virtual {v1, v3}, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/m;->d(I)Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/t0;

    move-result-object v4

    iget-object v4, v4, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/t0;->a:Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/m;

    instance-of v4, v4, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/o0;

    invoke-virtual {p0, v4}, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/k;->a(Z)V

    iget-boolean v1, v1, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/v;->h:Z

    :goto_87
    invoke-virtual {p0, v1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/k;->a(Z)V

    goto :goto_91

    :cond_8b
    new-instance p1, Ljava/lang/IllegalStateException;

    invoke-direct {p1}, Ljava/lang/IllegalStateException;-><init>()V

    throw p1

    :cond_91
    :goto_91
    instance-of v1, v0, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/q0;

    if-eqz v1, :cond_ac

    invoke-virtual {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/m;->b()I

    move-result v1

    if-ne v1, v3, :cond_9d

    const/4 v1, 0x1

    goto :goto_9e

    :cond_9d
    const/4 v1, 0x0

    :goto_9e
    invoke-virtual {p0, v1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/k;->a(Z)V

    invoke-virtual {v0, v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/m;->d(I)Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/t0;

    move-result-object v1

    iget-object v1, v1, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/t0;->a:Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/m;

    instance-of v1, v1, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/p0;

    invoke-virtual {p0, v1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/k;->a(Z)V

    :cond_ac
    instance-of v1, v0, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/O;

    if-eqz v1, :cond_bd

    move-object v1, v0

    check-cast v1, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/O;

    iget-object v1, v1, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/O;->g:Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/m;

    if-eqz v1, :cond_b9

    const/4 v1, 0x1

    goto :goto_ba

    :cond_b9
    const/4 v1, 0x0

    :goto_ba
    invoke-virtual {p0, v1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/k;->a(Z)V

    :cond_bd
    instance-of v1, v0, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/d0;

    if-eqz v1, :cond_ce

    move-object v1, v0

    check-cast v1, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/d0;

    iget-object v1, v1, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/d0;->g:Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/e0;

    if-eqz v1, :cond_ca

    const/4 v1, 0x1

    goto :goto_cb

    :cond_ca
    const/4 v1, 0x0

    :goto_cb
    invoke-virtual {p0, v1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/k;->a(Z)V

    :cond_ce
    instance-of v1, v0, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/u;

    if-eqz v1, :cond_df

    move-object v1, v0

    check-cast v1, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/u;

    iget-object v1, v1, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/u;->i:Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/t;

    if-eqz v1, :cond_db

    const/4 v1, 0x1

    goto :goto_dc

    :cond_db
    const/4 v1, 0x0

    :goto_dc
    invoke-virtual {p0, v1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/k;->a(Z)V

    :cond_df
    instance-of v1, v0, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/t;

    if-eqz v1, :cond_f0

    move-object v1, v0

    check-cast v1, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/t;

    iget-object v1, v1, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/t;->g:Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/u;

    if-eqz v1, :cond_ec

    const/4 v1, 0x1

    goto :goto_ed

    :cond_ec
    const/4 v1, 0x0

    :goto_ed
    invoke-virtual {p0, v1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/k;->a(Z)V

    :cond_f0
    instance-of v1, v0, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/v;

    if-eqz v1, :cond_101

    check-cast v0, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/v;

    invoke-virtual {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/m;->b()I

    move-result v1

    if-le v1, v3, :cond_10b

    iget v0, v0, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/v;->g:I

    if-ltz v0, :cond_10c

    goto :goto_10b

    :cond_101
    invoke-virtual {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/m;->b()I

    move-result v1

    if-le v1, v3, :cond_10b

    instance-of v0, v0, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/e0;

    if-eqz v0, :cond_10c

    :cond_10b
    :goto_10b
    const/4 v2, 0x1

    :cond_10c
    invoke-virtual {p0, v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/k;->a(Z)V

    goto/16 :goto_6

    :cond_111
    return-void
.end method
