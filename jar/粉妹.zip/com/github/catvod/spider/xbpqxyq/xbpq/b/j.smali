.class public final synthetic Lcom/github/catvod/spider/xbpqxyq/xbpq/b/j;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic c:I

.field public final synthetic d:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(Ljava/lang/Object;I)V
    .registers 3

    iput p2, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/j;->c:I

    iput-object p1, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/j;->d:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 2

    iget v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/j;->c:I

    packed-switch v0, :pswitch_data_16

    goto :goto_e

    :pswitch_6  #0x0
    iget-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/j;->d:Ljava/lang/Object;

    check-cast v0, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;->d(Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;)V

    return-void

    :goto_e
    iget-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/j;->d:Ljava/lang/Object;

    check-cast v0, Lcom/google/net/cronet/okhttptransport/CronetInterceptor;

    invoke-static {v0}, Lcom/google/net/cronet/okhttptransport/CronetInterceptor;->a(Lcom/google/net/cronet/okhttptransport/CronetInterceptor;)V

    return-void

    :pswitch_data_16
    .packed-switch 0x0
        :pswitch_6  #00000000
    .end packed-switch
.end method
