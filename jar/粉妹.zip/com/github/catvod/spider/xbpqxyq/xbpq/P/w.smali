.class public abstract Lcom/github/catvod/spider/xbpqxyq/xbpq/P/w;
.super Lcom/github/catvod/spider/xbpqxyq/xbpq/P/B;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/github/catvod/spider/xbpqxyq/xbpq/P/B<",
        "Lcom/github/catvod/spider/xbpqxyq/xbpq/P/D;",
        "Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/S;",
        ">;"
    }
.end annotation


# instance fields
.field protected d:Lcom/github/catvod/spider/xbpqxyq/xbpq/P/o;

.field protected e:Lcom/github/catvod/spider/xbpqxyq/xbpq/P/G;

.field protected final f:Lcom/github/catvod/spider/xbpqxyq/xbpq/S/h;

.field protected g:Lcom/github/catvod/spider/xbpqxyq/xbpq/P/x;

.field protected h:Z

.field private i:Lcom/github/catvod/spider/xbpqxyq/xbpq/P/v;

.field protected j:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lcom/github/catvod/spider/xbpqxyq/xbpq/T/c;",
            ">;"
        }
    .end annotation
.end field

.field protected k:Z


# direct methods
.method static constructor <clinit>()V
    .registers 1

    new-instance v0, Ljava/util/WeakHashMap;

    invoke-direct {v0}, Ljava/util/WeakHashMap;-><init>()V

    return-void
.end method

.method public constructor <init>(Lcom/github/catvod/spider/xbpqxyq/xbpq/P/G;)V
    .registers 7

    invoke-direct {p0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/B;-><init>()V

    new-instance v0, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/o;

    invoke-direct {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/o;-><init>()V

    iput-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/w;->d:Lcom/github/catvod/spider/xbpqxyq/xbpq/P/o;

    new-instance v0, Lcom/github/catvod/spider/xbpqxyq/xbpq/S/h;

    invoke-direct {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/S/h;-><init>()V

    iput-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/w;->f:Lcom/github/catvod/spider/xbpqxyq/xbpq/S/h;

    const/4 v1, 0x0

    .line 1
    invoke-virtual {v0, v1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/S/g;->a(I)V

    const/4 v2, 0x1

    .line 2
    iput-boolean v2, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/w;->h:Z

    const/4 v2, 0x0

    .line 3
    iput-object v2, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/w;->e:Lcom/github/catvod/spider/xbpqxyq/xbpq/P/G;

    .line 4
    iget-object v3, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/w;->d:Lcom/github/catvod/spider/xbpqxyq/xbpq/P/o;

    .line 5
    iput-boolean v1, v3, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/o;->a:Z

    iput-object v2, v3, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/o;->c:Lcom/github/catvod/spider/xbpqxyq/xbpq/S/j;

    const/4 v4, -0x1

    iput v4, v3, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/o;->b:I

    .line 6
    iput-object v2, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/w;->g:Lcom/github/catvod/spider/xbpqxyq/xbpq/P/x;

    iput-boolean v1, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/w;->k:Z

    .line 7
    iget-object v3, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/w;->i:Lcom/github/catvod/spider/xbpqxyq/xbpq/P/v;

    invoke-virtual {p0, v3}, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/w;->u(Lcom/github/catvod/spider/xbpqxyq/xbpq/T/c;)V

    iput-object v2, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/w;->i:Lcom/github/catvod/spider/xbpqxyq/xbpq/P/v;

    .line 8
    invoke-virtual {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/S/g;->b()V

    .line 9
    invoke-virtual {v0, v1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/S/g;->a(I)V

    .line 10
    iget-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/B;->b:Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/l;

    if-eqz v0, :cond_3c

    .line 11
    invoke-virtual {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/l;->a()V

    .line 12
    :cond_3c
    iput-object p1, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/w;->e:Lcom/github/catvod/spider/xbpqxyq/xbpq/P/G;

    return-void
.end method


# virtual methods
.method public final j(I)Z
    .registers 4

    iget-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/w;->f:Lcom/github/catvod/spider/xbpqxyq/xbpq/S/h;

    invoke-virtual {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/S/g;->f()I

    move-result v1

    add-int/lit8 v1, v1, -0x1

    invoke-virtual {v0, v1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/S/g;->c(I)I

    move-result v0

    if-lt p1, v0, :cond_10

    const/4 p1, 0x1

    goto :goto_11

    :cond_10
    const/4 p1, 0x0

    :goto_11
    return p1
.end method

.method public final l()Lcom/github/catvod/spider/xbpqxyq/xbpq/P/D;
    .registers 5

    invoke-virtual {p0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/w;->q()Lcom/github/catvod/spider/xbpqxyq/xbpq/P/D;

    move-result-object v0

    invoke-interface {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/D;->e()I

    move-result v1

    const/4 v2, -0x1

    if-eq v1, v2, :cond_10

    .line 1
    iget-object v1, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/w;->e:Lcom/github/catvod/spider/xbpqxyq/xbpq/P/G;

    .line 2
    invoke-interface {v1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/r;->j()V

    :cond_10
    iget-object v1, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/w;->j:Ljava/util/ArrayList;

    if-eqz v1, :cond_1c

    invoke-virtual {v1}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v1

    if-nez v1, :cond_1c

    const/4 v1, 0x1

    goto :goto_1d

    :cond_1c
    const/4 v1, 0x0

    :goto_1d
    iget-boolean v2, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/w;->h:Z

    if-nez v2, :cond_23

    if-eqz v1, :cond_73

    :cond_23
    iget-object v1, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/w;->d:Lcom/github/catvod/spider/xbpqxyq/xbpq/P/o;

    .line 3
    iget-boolean v1, v1, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/o;->a:Z

    if-eqz v1, :cond_4e

    .line 4
    iget-object v1, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/w;->g:Lcom/github/catvod/spider/xbpqxyq/xbpq/P/x;

    .line 5
    new-instance v2, Lcom/github/catvod/spider/xbpqxyq/xbpq/T/a;

    invoke-direct {v2, v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/T/a;-><init>(Lcom/github/catvod/spider/xbpqxyq/xbpq/P/D;)V

    .line 6
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 7
    invoke-virtual {v1, v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/x;->h(Lcom/github/catvod/spider/xbpqxyq/xbpq/T/b;)Lcom/github/catvod/spider/xbpqxyq/xbpq/T/b;

    .line 8
    iget-object v1, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/w;->j:Ljava/util/ArrayList;

    if-eqz v1, :cond_73

    invoke-virtual {v1}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_3e
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_73

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcom/github/catvod/spider/xbpqxyq/xbpq/T/c;

    invoke-interface {v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/T/c;->a()V

    goto :goto_3e

    :cond_4e
    iget-object v1, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/w;->g:Lcom/github/catvod/spider/xbpqxyq/xbpq/P/x;

    .line 9
    new-instance v2, Lcom/github/catvod/spider/xbpqxyq/xbpq/T/g;

    invoke-direct {v2, v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/T/g;-><init>(Lcom/github/catvod/spider/xbpqxyq/xbpq/P/D;)V

    .line 10
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 11
    invoke-virtual {v1, v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/x;->h(Lcom/github/catvod/spider/xbpqxyq/xbpq/T/b;)Lcom/github/catvod/spider/xbpqxyq/xbpq/T/b;

    .line 12
    iget-object v1, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/w;->j:Ljava/util/ArrayList;

    if-eqz v1, :cond_73

    invoke-virtual {v1}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_63
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_73

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lcom/github/catvod/spider/xbpqxyq/xbpq/T/c;

    invoke-interface {v3, v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/T/c;->b(Lcom/github/catvod/spider/xbpqxyq/xbpq/T/f;)V

    goto :goto_63

    :cond_73
    return-object v0
.end method

.method public final m(Lcom/github/catvod/spider/xbpqxyq/xbpq/P/x;)V
    .registers 5

    iget-boolean v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/w;->h:Z

    if-eqz v0, :cond_1e

    iget-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/w;->g:Lcom/github/catvod/spider/xbpqxyq/xbpq/P/x;

    if-eq v0, p1, :cond_1e

    iget-object v0, v0, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/C;->a:Lcom/github/catvod/spider/xbpqxyq/xbpq/P/C;

    check-cast v0, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/x;

    if-eqz v0, :cond_1e

    .line 1
    iget-object v1, v0, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/x;->d:Ljava/util/ArrayList;

    if-eqz v1, :cond_1b

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v2

    add-int/lit8 v2, v2, -0x1

    invoke-virtual {v1, v2}, Ljava/util/ArrayList;->remove(I)Ljava/lang/Object;

    .line 2
    :cond_1b
    invoke-virtual {v0, p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/x;->h(Lcom/github/catvod/spider/xbpqxyq/xbpq/T/b;)Lcom/github/catvod/spider/xbpqxyq/xbpq/T/b;

    .line 3
    :cond_1e
    iput-object p1, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/w;->g:Lcom/github/catvod/spider/xbpqxyq/xbpq/P/x;

    return-void
.end method

.method public final n(Lcom/github/catvod/spider/xbpqxyq/xbpq/P/x;I)V
    .registers 4

    invoke-virtual {p0, p2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/B;->k(I)V

    iput-object p1, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/w;->g:Lcom/github/catvod/spider/xbpqxyq/xbpq/P/x;

    iget-object p2, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/w;->e:Lcom/github/catvod/spider/xbpqxyq/xbpq/P/G;

    const/4 v0, 0x1

    invoke-interface {p2, v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/G;->e(I)Lcom/github/catvod/spider/xbpqxyq/xbpq/P/D;

    move-result-object p2

    iput-object p2, p1, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/x;->e:Lcom/github/catvod/spider/xbpqxyq/xbpq/P/D;

    iget-boolean p1, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/w;->h:Z

    if-eqz p1, :cond_1d

    .line 1
    iget-object p1, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/w;->g:Lcom/github/catvod/spider/xbpqxyq/xbpq/P/x;

    iget-object p2, p1, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/C;->a:Lcom/github/catvod/spider/xbpqxyq/xbpq/P/C;

    check-cast p2, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/x;

    if-eqz p2, :cond_1d

    .line 2
    invoke-virtual {p2, p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/x;->h(Lcom/github/catvod/spider/xbpqxyq/xbpq/T/b;)Lcom/github/catvod/spider/xbpqxyq/xbpq/T/b;

    .line 3
    :cond_1d
    iget-object p1, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/w;->j:Ljava/util/ArrayList;

    if-eqz p1, :cond_3c

    .line 4
    invoke-virtual {p1}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :goto_25
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result p2

    if-eqz p2, :cond_3c

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object p2

    check-cast p2, Lcom/github/catvod/spider/xbpqxyq/xbpq/T/c;

    iget-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/w;->g:Lcom/github/catvod/spider/xbpqxyq/xbpq/P/x;

    invoke-interface {p2, v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/T/c;->h(Lcom/github/catvod/spider/xbpqxyq/xbpq/P/x;)V

    iget-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/w;->g:Lcom/github/catvod/spider/xbpqxyq/xbpq/P/x;

    invoke-virtual {v0, p2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/x;->i(Lcom/github/catvod/spider/xbpqxyq/xbpq/T/c;)V

    goto :goto_25

    :cond_3c
    return-void
.end method

.method public final o()V
    .registers 5

    iget-boolean v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/w;->k:Z

    const/4 v1, -0x1

    if-eqz v0, :cond_f

    iget-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/w;->g:Lcom/github/catvod/spider/xbpqxyq/xbpq/P/x;

    iget-object v2, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/w;->e:Lcom/github/catvod/spider/xbpqxyq/xbpq/P/G;

    const/4 v3, 0x1

    invoke-interface {v2, v3}, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/G;->e(I)Lcom/github/catvod/spider/xbpqxyq/xbpq/P/D;

    move-result-object v2

    goto :goto_17

    :cond_f
    iget-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/w;->g:Lcom/github/catvod/spider/xbpqxyq/xbpq/P/x;

    iget-object v2, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/w;->e:Lcom/github/catvod/spider/xbpqxyq/xbpq/P/G;

    invoke-interface {v2, v1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/G;->e(I)Lcom/github/catvod/spider/xbpqxyq/xbpq/P/D;

    move-result-object v2

    :goto_17
    iput-object v2, v0, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/x;->f:Lcom/github/catvod/spider/xbpqxyq/xbpq/P/D;

    iget-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/w;->j:Ljava/util/ArrayList;

    if-eqz v0, :cond_39

    .line 1
    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    add-int/2addr v0, v1

    :goto_22
    if-ltz v0, :cond_39

    iget-object v1, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/w;->j:Ljava/util/ArrayList;

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcom/github/catvod/spider/xbpqxyq/xbpq/T/c;

    iget-object v2, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/w;->g:Lcom/github/catvod/spider/xbpqxyq/xbpq/P/x;

    invoke-virtual {v2, v1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/x;->j(Lcom/github/catvod/spider/xbpqxyq/xbpq/T/c;)V

    iget-object v2, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/w;->g:Lcom/github/catvod/spider/xbpqxyq/xbpq/P/x;

    invoke-interface {v1, v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/T/c;->S(Lcom/github/catvod/spider/xbpqxyq/xbpq/P/x;)V

    add-int/lit8 v0, v0, -0x1

    goto :goto_22

    .line 2
    :cond_39
    iget-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/w;->g:Lcom/github/catvod/spider/xbpqxyq/xbpq/P/x;

    iget v0, v0, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/C;->b:I

    invoke-virtual {p0, v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/B;->k(I)V

    iget-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/w;->g:Lcom/github/catvod/spider/xbpqxyq/xbpq/P/x;

    iget-object v0, v0, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/C;->a:Lcom/github/catvod/spider/xbpqxyq/xbpq/P/C;

    check-cast v0, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/x;

    iput-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/w;->g:Lcom/github/catvod/spider/xbpqxyq/xbpq/P/x;

    return-void
.end method

.method public final p()Lcom/github/catvod/spider/xbpqxyq/xbpq/P/x;
    .registers 2

    iget-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/w;->g:Lcom/github/catvod/spider/xbpqxyq/xbpq/P/x;

    return-object v0
.end method

.method public final q()Lcom/github/catvod/spider/xbpqxyq/xbpq/P/D;
    .registers 3

    iget-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/w;->e:Lcom/github/catvod/spider/xbpqxyq/xbpq/P/G;

    const/4 v1, 0x1

    invoke-interface {v0, v1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/G;->e(I)Lcom/github/catvod/spider/xbpqxyq/xbpq/P/D;

    move-result-object v0

    return-object v0
.end method

.method public final r()I
    .registers 4

    iget-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/w;->f:Lcom/github/catvod/spider/xbpqxyq/xbpq/S/h;

    invoke-virtual {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/S/g;->d()Z

    move-result v0

    const/4 v1, -0x1

    if-eqz v0, :cond_a

    return v1

    :cond_a
    iget-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/w;->f:Lcom/github/catvod/spider/xbpqxyq/xbpq/S/h;

    invoke-virtual {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/S/g;->f()I

    move-result v2

    add-int/2addr v2, v1

    invoke-virtual {v0, v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/S/g;->c(I)I

    move-result v0

    return v0
.end method

.method public final s(I)Lcom/github/catvod/spider/xbpqxyq/xbpq/P/D;
    .registers 5

    invoke-virtual {p0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/w;->q()Lcom/github/catvod/spider/xbpqxyq/xbpq/P/D;

    move-result-object v0

    invoke-interface {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/D;->e()I

    move-result v1

    const/4 v2, -0x1

    if-ne v1, p1, :cond_19

    if-ne p1, v2, :cond_10

    const/4 p1, 0x1

    iput-boolean p1, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/w;->k:Z

    :cond_10
    iget-object p1, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/w;->d:Lcom/github/catvod/spider/xbpqxyq/xbpq/P/o;

    invoke-virtual {p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/o;->i()V

    invoke-virtual {p0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/w;->l()Lcom/github/catvod/spider/xbpqxyq/xbpq/P/D;

    goto :goto_36

    :cond_19
    iget-object p1, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/w;->d:Lcom/github/catvod/spider/xbpqxyq/xbpq/P/o;

    invoke-virtual {p1, p0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/o;->g(Lcom/github/catvod/spider/xbpqxyq/xbpq/P/w;)Lcom/github/catvod/spider/xbpqxyq/xbpq/P/D;

    move-result-object v0

    iget-boolean p1, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/w;->h:Z

    if-eqz p1, :cond_36

    invoke-interface {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/D;->g()I

    move-result p1

    if-ne p1, v2, :cond_36

    iget-object p1, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/w;->g:Lcom/github/catvod/spider/xbpqxyq/xbpq/P/x;

    .line 1
    new-instance v1, Lcom/github/catvod/spider/xbpqxyq/xbpq/T/a;

    invoke-direct {v1, v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/T/a;-><init>(Lcom/github/catvod/spider/xbpqxyq/xbpq/P/D;)V

    .line 2
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 3
    invoke-virtual {p1, v1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/x;->h(Lcom/github/catvod/spider/xbpqxyq/xbpq/T/b;)Lcom/github/catvod/spider/xbpqxyq/xbpq/T/b;

    :cond_36
    :goto_36
    return-object v0
.end method

.method public final t(Lcom/github/catvod/spider/xbpqxyq/xbpq/P/D;Ljava/lang/String;Lcom/github/catvod/spider/xbpqxyq/xbpq/P/z;)V
    .registers 11

    invoke-interface {p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/D;->d()I

    move-result v3

    invoke-interface {p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/D;->a()I

    move-result v4

    invoke-virtual {p0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/B;->g()Lcom/github/catvod/spider/xbpqxyq/xbpq/P/a;

    move-result-object v0

    check-cast v0, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/y;

    move-object v1, p0

    move-object v2, p1

    move-object v5, p2

    move-object v6, p3

    invoke-virtual/range {v0 .. v6}, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/y;->a(Lcom/github/catvod/spider/xbpqxyq/xbpq/P/B;Ljava/lang/Object;IILjava/lang/String;Lcom/github/catvod/spider/xbpqxyq/xbpq/P/z;)V

    return-void
.end method

.method public final u(Lcom/github/catvod/spider/xbpqxyq/xbpq/T/c;)V
    .registers 3

    iget-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/w;->j:Ljava/util/ArrayList;

    if-eqz v0, :cond_15

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->remove(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_15

    iget-object p1, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/w;->j:Ljava/util/ArrayList;

    invoke-virtual {p1}, Ljava/util/ArrayList;->isEmpty()Z

    move-result p1

    if-eqz p1, :cond_15

    const/4 p1, 0x0

    iput-object p1, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/w;->j:Ljava/util/ArrayList;

    :cond_15
    return-void
.end method

.method public final v(Lcom/github/catvod/spider/xbpqxyq/xbpq/P/o;)V
    .registers 2

    iput-object p1, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/w;->d:Lcom/github/catvod/spider/xbpqxyq/xbpq/P/o;

    return-void
.end method
