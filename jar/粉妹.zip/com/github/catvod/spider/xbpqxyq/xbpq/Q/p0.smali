.class public final Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/p0;
.super Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/v;
.source "SourceFile"


# instance fields
.field public i:Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/q0;

.field public j:Z


# direct methods
.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/v;-><init>()V

    return-void
.end method


# virtual methods
.method public final c()I
    .registers 2

    const/16 v0, 0xa

    return v0
.end method
