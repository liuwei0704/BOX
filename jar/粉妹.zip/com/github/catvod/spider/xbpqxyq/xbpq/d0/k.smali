.class final enum Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/k;
.super Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/A;
.source "SourceFile"


# direct methods
.method constructor <init>()V
    .registers 4

    const-string v0, "361E31000117181C3C"

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/16 v1, 0x11

    const/4 v2, 0x0

    invoke-direct {p0, v0, v1, v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/A;-><init>(Ljava/lang/String;ILcom/github/catvod/spider/xbpqxyq/xbpq/d0/m;)V

    return-void
.end method


# virtual methods
.method final d(Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/O;Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b;)Z
    .registers 6

    sget-object v0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/A;->i:Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/w;

    invoke-static {p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/A;->a(Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/O;)Z

    move-result v1

    if-eqz v1, :cond_e

    .line 1
    check-cast p1, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/H;

    .line 2
    invoke-virtual {p2, p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b;->E(Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/H;)V

    goto :goto_61

    :cond_e
    invoke-virtual {p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/O;->b()Z

    move-result v1

    if-eqz v1, :cond_1a

    .line 3
    check-cast p1, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/I;

    .line 4
    invoke-virtual {p2, p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b;->F(Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/I;)V

    goto :goto_61

    :cond_1a
    invoke-virtual {p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/O;->c()Z

    move-result v1

    if-eqz v1, :cond_25

    invoke-virtual {p2, p0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b;->n(Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/A;)V

    const/4 p1, 0x0

    return p1

    :cond_25
    invoke-virtual {p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/O;->f()Z

    move-result v1

    const-string v2, "1F0C2809"

    invoke-static {v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    if-eqz v1, :cond_41

    .line 5
    move-object v1, p1

    check-cast v1, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/M;

    .line 6
    iget-object v1, v1, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/N;->c:Ljava/lang/String;

    .line 7
    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_41

    invoke-virtual {p2, p1, v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b;->X(Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/O;Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/A;)Z

    move-result p1

    return p1

    :cond_41
    invoke-virtual {p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/O;->e()Z

    move-result v1

    if-eqz v1, :cond_5b

    .line 8
    move-object v1, p1

    check-cast v1, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/L;

    .line 9
    iget-object v1, v1, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/N;->c:Ljava/lang/String;

    .line 10
    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_5b

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    sget-object p1, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/A;->w:Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/o;

    invoke-virtual {p2, p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b;->j0(Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/A;)V

    goto :goto_61

    :cond_5b
    invoke-virtual {p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/O;->d()Z

    move-result v1

    if-eqz v1, :cond_63

    :goto_61
    const/4 p1, 0x1

    return p1

    :cond_63
    invoke-virtual {p2, p0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b;->n(Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/A;)V

    invoke-virtual {p2, v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b;->j0(Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/A;)V

    invoke-virtual {p2, p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b;->c(Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/O;)Z

    move-result p1

    return p1
.end method
