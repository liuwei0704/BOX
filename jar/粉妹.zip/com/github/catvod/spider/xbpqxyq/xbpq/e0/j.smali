.class public abstract Lcom/github/catvod/spider/xbpqxyq/xbpq/e0/j;
.super Lcom/github/catvod/spider/xbpqxyq/xbpq/e0/N;
.source "SourceFile"


# instance fields
.field a:Ljava/lang/String;

.field b:Ljava/lang/String;


# direct methods
.method public constructor <init>(Ljava/lang/String;Ljava/lang/String;Z)V
    .registers 6

    invoke-direct {p0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/e0/N;-><init>()V

    invoke-static {p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/N/a;->i(Ljava/lang/String;)V

    invoke-static {p2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/N/a;->i(Ljava/lang/String;)V

    invoke-static {p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/x/a;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    iput-object p1, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/e0/j;->a:Ljava/lang/String;

    const-string p1, "50"

    invoke-static {p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p2, p1}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v0

    const/4 v1, 0x1

    if-eqz v0, :cond_22

    invoke-virtual {p2, p1}, Ljava/lang/String;->endsWith(Ljava/lang/String;)Z

    move-result p1

    if-nez p1, :cond_34

    :cond_22
    const-string p1, "55"

    invoke-static {p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p2, p1}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_36

    invoke-virtual {p2, p1}, Ljava/lang/String;->endsWith(Ljava/lang/String;)Z

    move-result p1

    if-eqz p1, :cond_36

    :cond_34
    const/4 p1, 0x1

    goto :goto_37

    :cond_36
    const/4 p1, 0x0

    :goto_37
    if-eqz p1, :cond_42

    invoke-virtual {p2}, Ljava/lang/String;->length()I

    move-result v0

    sub-int/2addr v0, v1

    invoke-virtual {p2, v1, v0}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object p2

    :cond_42
    if-eqz p3, :cond_49

    invoke-static {p2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/x/a;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    goto :goto_54

    :cond_49
    if-eqz p1, :cond_50

    .line 1
    invoke-static {p2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/x/a;->c(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    goto :goto_54

    :cond_50
    invoke-static {p2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/x/a;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    .line 2
    :goto_54
    iput-object p1, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/e0/j;->b:Ljava/lang/String;

    return-void
.end method
