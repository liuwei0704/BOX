.class public final Lcom/github/catvod/spider/xbpqxyq/xbpq/j/l;
.super Ljava/lang/Object;
.source "SourceFile"


# direct methods
.method public static final a(Ljava/lang/Throwable;)Ljava/lang/Object;
    .registers 2

    new-instance v0, Lcom/github/catvod/spider/xbpqxyq/xbpq/x/f;

    invoke-direct {v0, p0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/x/f;-><init>(Ljava/lang/Throwable;)V

    return-object v0
.end method

.method public static b(Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/l;)Lcom/github/catvod/spider/xbpqxyq/xbpq/e0/g;
    .registers 2

    new-instance v0, Lcom/github/catvod/spider/xbpqxyq/xbpq/e0/g;

    invoke-direct {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/e0/g;-><init>()V

    :goto_5
    invoke-virtual {p0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/l;->b0()Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/l;

    move-result-object p0

    if-eqz p0, :cond_f

    invoke-virtual {v0, p0}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    goto :goto_5

    :cond_f
    invoke-virtual {v0}, Ljava/util/AbstractCollection;->size()I

    move-result p0

    if-lez p0, :cond_16

    return-object v0

    :cond_16
    const/4 p0, 0x0

    return-object p0
.end method

.method public static c(Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/l;Lcom/github/catvod/spider/xbpqxyq/xbpq/h0/d;)I
    .registers 8

    invoke-virtual {p0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/l;->f0()Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/l;

    move-result-object v0

    invoke-virtual {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/l;->R()Lcom/github/catvod/spider/xbpqxyq/xbpq/e0/g;

    move-result-object v0

    invoke-virtual {v0}, Ljava/util/AbstractCollection;->iterator()Ljava/util/Iterator;

    move-result-object v0

    const/4 v1, 0x1

    const/4 v2, 0x1

    :cond_e
    :goto_e
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_3d

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/l;

    invoke-virtual {p0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/l;->n0()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3}, Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/l;->n0()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_e

    invoke-virtual {p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/h0/d;->a()Lcom/github/catvod/spider/xbpqxyq/xbpq/e0/g;

    move-result-object v4

    invoke-virtual {v4, v3}, Ljava/util/AbstractCollection;->contains(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_e

    if-ne p0, v3, :cond_36

    const/4 v3, 0x1

    goto :goto_37

    :cond_36
    const/4 v3, 0x0

    :goto_37
    if-eqz v3, :cond_3a

    goto :goto_3d

    :cond_3a
    add-int/lit8 v2, v2, 0x1

    goto :goto_e

    :cond_3d
    :goto_3d
    return v2
.end method

.method public static d(Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/l;)Lcom/github/catvod/spider/xbpqxyq/xbpq/e0/g;
    .registers 2

    new-instance v0, Lcom/github/catvod/spider/xbpqxyq/xbpq/e0/g;

    invoke-direct {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/e0/g;-><init>()V

    :goto_5
    invoke-virtual {p0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/l;->i0()Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/l;

    move-result-object p0

    if-eqz p0, :cond_f

    invoke-virtual {v0, p0}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    goto :goto_5

    :cond_f
    invoke-virtual {v0}, Ljava/util/AbstractCollection;->size()I

    move-result p0

    if-lez p0, :cond_16

    return-object v0

    :cond_16
    const/4 p0, 0x0

    return-object p0
.end method

.method public static e(Ljava/io/InputStream;)Ljava/lang/String;
    .registers 4

    :try_start_0
    new-instance v0, Ljava/io/BufferedReader;

    new-instance v1, Ljava/io/InputStreamReader;

    invoke-direct {v1, p0}, Ljava/io/InputStreamReader;-><init>(Ljava/io/InputStream;)V

    invoke-direct {v0, v1}, Ljava/io/BufferedReader;-><init>(Ljava/io/Reader;)V

    new-instance p0, Ljava/lang/StringBuilder;

    invoke-direct {p0}, Ljava/lang/StringBuilder;-><init>()V

    :goto_f
    invoke-virtual {v0}, Ljava/io/BufferedReader;->readLine()Ljava/lang/String;

    move-result-object v1

    if-eqz v1, :cond_22

    invoke-virtual {p0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, "7D"

    invoke-static {v1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {p0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    goto :goto_f

    :cond_22
    invoke-virtual {v0}, Ljava/io/BufferedReader;->close()V

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    sget v0, Lcom/github/catvod/spider/xbpqxyq/xbpq/j/o;->a:I

    if-eqz p0, :cond_3e

    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v0

    const/4 v1, 0x1

    if-le v0, v1, :cond_3e

    const/4 v0, 0x0

    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v2

    sub-int/2addr v2, v1

    invoke-virtual {p0, v0, v2}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object p0
    :try_end_3e
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_3e} :catch_3f

    :cond_3e
    return-object p0

    :catch_3f
    const-string p0, ""

    return-object p0
.end method

.method public static f(Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/l;I)V
    .registers 3

    invoke-static {p1}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object p1

    const-string v0, "32341A36321832271124340A3E3601202B0A3C3D1C"

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p0, v0, p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/r;->b(Ljava/lang/String;Ljava/lang/String;)Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/r;

    return-void
.end method

.method public static g(Ljava/io/File;Ljava/lang/String;)V
    .registers 4

    invoke-virtual {p1}, Ljava/lang/String;->getBytes()[B

    move-result-object p1

    .line 1
    :try_start_4
    new-instance v0, Ljava/io/FileOutputStream;

    invoke-direct {v0, p0}, Ljava/io/FileOutputStream;-><init>(Ljava/io/File;)V

    invoke-virtual {v0, p1}, Ljava/io/FileOutputStream;->write([B)V

    invoke-virtual {v0}, Ljava/io/OutputStream;->flush()V

    invoke-virtual {v0}, Ljava/io/FileOutputStream;->close()V
    :try_end_12
    .catch Ljava/lang/Exception; {:try_start_4 .. :try_end_12} :catch_38

    .line 2
    :try_start_12
    invoke-static {}, Ljava/lang/Runtime;->getRuntime()Ljava/lang/Runtime;

    move-result-object p1

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "1410280A1775404F7245"

    invoke-static {v1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-virtual {p1, p0}, Ljava/lang/Runtime;->exec(Ljava/lang/String;)Ljava/lang/Process;

    move-result-object p0

    invoke-virtual {p0}, Ljava/lang/Process;->waitFor()I
    :try_end_32
    .catch Ljava/lang/Exception; {:try_start_12 .. :try_end_32} :catch_33

    goto :goto_3c

    :catch_33
    move-exception p0

    :try_start_34
    invoke-virtual {p0}, Ljava/lang/Throwable;->printStackTrace()V
    :try_end_37
    .catch Ljava/lang/Exception; {:try_start_34 .. :try_end_37} :catch_38

    goto :goto_3c

    :catch_38
    move-exception p0

    .line 3
    invoke-virtual {p0}, Ljava/lang/Throwable;->printStackTrace()V

    :goto_3c
    return-void
.end method
