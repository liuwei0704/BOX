.class public final synthetic Lcom/github/catvod/spider/xbpqxyq/xbpq/i/b;
.super Ljava/lang/Object;
.source "SourceFile"


# direct methods
.method public static a(Ljava/lang/Exception;Ljava/lang/StringBuilder;Lcom/github/catvod/crawler/SpiderApi;)V
    .registers 3

    .line 1
    invoke-virtual {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p0

    .line 2
    invoke-virtual {p1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 3
    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    .line 4
    invoke-virtual {p2, p0}, Lcom/github/catvod/crawler/SpiderApi;->log(Ljava/lang/String;)V

    return-void
.end method
