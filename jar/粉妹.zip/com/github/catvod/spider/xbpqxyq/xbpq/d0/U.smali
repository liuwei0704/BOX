.class final enum Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/U;
.super Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/h1;
.source "SourceFile"


# direct methods
.method constructor <init>()V
    .registers 4

    const-string v0, "253B012427143216213112323808200B"

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/16 v1, 0xb

    const/4 v2, 0x0

    invoke-direct {p0, v0, v1, v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/h1;-><init>(Ljava/lang/String;ILcom/github/catvod/spider/xbpqxyq/xbpq/d0/c0;)V

    return-void
.end method


# virtual methods
.method final g(Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/Q;Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/a;)V
    .registers 5

    invoke-virtual {p2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/a;->C()Z

    move-result v0

    if-eqz v0, :cond_22

    const/4 v0, 0x0

    invoke-virtual {p1, v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/Q;->g(Z)Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/N;

    iget-object v0, p1, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/Q;->i:Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/N;

    invoke-virtual {p2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/a;->s()C

    move-result v1

    invoke-virtual {v0, v1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/N;->n(C)V

    iget-object v0, p1, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/Q;->h:Ljava/lang/StringBuilder;

    invoke-virtual {p2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/a;->s()C

    move-result p2

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    sget-object p2, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/h1;->o:Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/V;

    invoke-virtual {p1, p2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/Q;->a(Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/h1;)V

    goto :goto_30

    :cond_22
    const-string p2, "4B57"

    invoke-static {p2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p2

    invoke-virtual {p1, p2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/Q;->k(Ljava/lang/String;)V

    sget-object p2, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/h1;->e:Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/y0;

    invoke-virtual {p1, p2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/Q;->u(Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/h1;)V

    :goto_30
    return-void
.end method
