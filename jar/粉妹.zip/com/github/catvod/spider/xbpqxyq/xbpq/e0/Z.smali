.class abstract Lcom/github/catvod/spider/xbpqxyq/xbpq/e0/Z;
.super Lcom/github/catvod/spider/xbpqxyq/xbpq/e0/N;
.source "SourceFile"


# instance fields
.field a:Lcom/github/catvod/spider/xbpqxyq/xbpq/e0/N;


# direct methods
.method constructor <init>()V
    .registers 1

    invoke-direct {p0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/e0/N;-><init>()V

    return-void
.end method
