.class public final Lcom/github/catvod/spider/xbpqxyq/xbpq/W/a;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lcom/github/catvod/spider/xbpqxyq/xbpq/n0/a;


# direct methods
.method public synthetic constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static b(Ljava/lang/Throwable;)Ljava/lang/String;
    .registers 4

    .line 1
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    move-object v1, p0

    :goto_6
    if-eqz v1, :cond_16

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_16

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    invoke-virtual {v1}, Ljava/lang/Throwable;->getCause()Ljava/lang/Throwable;

    move-result-object v1

    goto :goto_6

    .line 2
    :cond_16
    invoke-virtual {v0}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v1

    if-eqz v1, :cond_1e

    const/4 v0, 0x0

    goto :goto_2a

    :cond_1e
    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v1

    add-int/lit8 v1, v1, -0x1

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Throwable;

    :goto_2a
    if-nez v0, :cond_2d

    goto :goto_2e

    :cond_2d
    move-object p0, v0

    .line 3
    :goto_2e
    sget v0, Lcom/github/catvod/spider/xbpqxyq/xbpq/U/b;->e:I

    .line 4
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v0

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/U/b;->a(Ljava/lang/Class;)Ljava/lang/String;

    move-result-object v0

    .line 5
    invoke-virtual {p0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p0

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v0, "4D58"

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    sget v0, Lcom/github/catvod/spider/xbpqxyq/xbpq/U/h;->a:I

    if-nez p0, :cond_53

    const-string p0, ""

    :cond_53
    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method public static c(Lcom/github/catvod/spider/xbpqxyq/xbpq/e0/O;Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/r;)V
    .registers 7

    const/4 v0, 0x0

    move-object v1, p1

    const/4 v2, 0x0

    :goto_3
    if-eqz v1, :cond_47

    invoke-virtual {v1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/r;->A()Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/r;

    move-result-object v3

    invoke-interface {p0, v1, v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/e0/O;->a(Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/r;I)V

    if-eqz v3, :cond_1c

    invoke-virtual {v1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/r;->q()Z

    move-result v4

    if-nez v4, :cond_1c

    invoke-virtual {v1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/r;->H()I

    move-result v1

    invoke-virtual {v3, v1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/r;->g(I)Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/r;

    move-result-object v1

    :cond_1c
    invoke-virtual {v1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/r;->h()I

    move-result v3

    if-lez v3, :cond_29

    invoke-virtual {v1, v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/r;->g(I)Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/r;

    move-result-object v1

    add-int/lit8 v2, v2, 0x1

    goto :goto_3

    :cond_29
    :goto_29
    invoke-virtual {v1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/r;->s()Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/r;

    move-result-object v3

    if-nez v3, :cond_3c

    if-gtz v2, :cond_32

    goto :goto_3c

    :cond_32
    invoke-interface {p0, v1, v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/e0/O;->b(Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/r;I)V

    invoke-virtual {v1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/r;->A()Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/r;

    move-result-object v1

    add-int/lit8 v2, v2, -0x1

    goto :goto_29

    :cond_3c
    :goto_3c
    invoke-interface {p0, v1, v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/e0/O;->b(Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/r;I)V

    if-ne v1, p1, :cond_42

    goto :goto_47

    :cond_42
    invoke-virtual {v1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/r;->s()Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/r;

    move-result-object v1

    goto :goto_3

    :cond_47
    :goto_47
    return-void
.end method


# virtual methods
.method public a(Ljava/lang/String;)Lcom/github/catvod/spider/xbpqxyq/xbpq/n0/b;
    .registers 2

    sget-object p1, Lcom/github/catvod/spider/xbpqxyq/xbpq/p0/b;->c:Lcom/github/catvod/spider/xbpqxyq/xbpq/p0/b;

    return-object p1
.end method
