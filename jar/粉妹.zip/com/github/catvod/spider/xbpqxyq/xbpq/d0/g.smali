.class final enum Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/g;
.super Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/A;
.source "SourceFile"


# direct methods
.method constructor <init>()V
    .registers 4

    const-string v0, "3E16170A04"

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/16 v1, 0xd

    const/4 v2, 0x0

    invoke-direct {p0, v0, v1, v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/A;-><init>(Ljava/lang/String;ILcom/github/catvod/spider/xbpqxyq/xbpq/d0/m;)V

    return-void
.end method


# virtual methods
.method final d(Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/O;Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b;)Z
    .registers 9

    sget-object v0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/A;->o:Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/f;

    sget-object v1, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/A;->k:Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/y;

    invoke-virtual {p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/O;->f()Z

    move-result v2

    const-string v3, "030A"

    invoke-static {v3}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    const/4 v4, 0x0

    if-eqz v2, :cond_56

    .line 1
    move-object v0, p1

    check-cast v0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/M;

    .line 2
    iget-object v2, v0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/N;->c:Ljava/lang/String;

    const-string v5, "031D28151F34031D"

    invoke-static {v5}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    .line 3
    invoke-virtual {v2, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_27

    invoke-virtual {p2, v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b;->D(Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/M;)Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/l;

    goto/16 :goto_a6

    :cond_27
    sget-object v5, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/z;->x:[Ljava/lang/String;

    invoke-static {v2, v5}, Lcom/github/catvod/spider/xbpqxyq/xbpq/b0/b;->b(Ljava/lang/String;[Ljava/lang/String;)Z

    move-result v5

    if-eqz v5, :cond_3e

    invoke-virtual {p2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b;->m()V

    invoke-virtual {p2, v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b;->D(Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/M;)Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/l;

    sget-object p1, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/A;->q:Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/h;

    invoke-virtual {p2, p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b;->j0(Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/A;)V

    invoke-virtual {p2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b;->J()V

    goto :goto_a6

    :cond_3e
    sget-object v0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/z;->F:[Ljava/lang/String;

    invoke-static {v2, v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/b0/b;->b(Ljava/lang/String;[Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_51

    .line 4
    invoke-virtual {p2, v3}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/i1;->d(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_50

    invoke-virtual {p2, p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b;->c(Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/O;)Z

    move-result v4

    :cond_50
    return v4

    .line 5
    :cond_51
    invoke-virtual {p2, p1, v1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b;->X(Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/O;Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/A;)Z

    move-result p1

    return p1

    .line 6
    :cond_56
    invoke-virtual {p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/O;->e()Z

    move-result v2

    if-eqz v2, :cond_bd

    .line 7
    move-object v2, p1

    check-cast v2, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/L;

    .line 8
    iget-object v2, v2, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/N;->c:Ljava/lang/String;

    .line 9
    invoke-virtual {v2, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_71

    invoke-virtual {p2, v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b;->B(Ljava/lang/String;)Z

    move-result p1

    if-nez p1, :cond_9d

    invoke-virtual {p2, p0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b;->n(Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/A;)V

    return v4

    :cond_71
    const-string v5, "0319270916"

    invoke-static {v5}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v2, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_88

    .line 10
    invoke-virtual {p2, v3}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/i1;->d(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_87

    invoke-virtual {p2, p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b;->c(Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/O;)Z

    move-result v4

    :cond_87
    return v4

    .line 11
    :cond_88
    sget-object v5, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/z;->u:[Ljava/lang/String;

    invoke-static {v2, v5}, Lcom/github/catvod/spider/xbpqxyq/xbpq/b0/b;->b(Ljava/lang/String;[Ljava/lang/String;)Z

    move-result v5

    if-eqz v5, :cond_ac

    invoke-virtual {p2, v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b;->B(Ljava/lang/String;)Z

    move-result p1

    if-eqz p1, :cond_a8

    invoke-virtual {p2, v3}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b;->B(Ljava/lang/String;)Z

    move-result p1

    if-nez p1, :cond_9d

    goto :goto_a8

    :cond_9d
    invoke-virtual {p2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b;->m()V

    invoke-virtual {p2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b;->U()Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/l;

    invoke-virtual {p2, v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b;->j0(Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/A;)V

    :goto_a6
    const/4 p1, 0x1

    return p1

    :cond_a8
    :goto_a8
    invoke-virtual {p2, p0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b;->n(Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/A;)V

    return v4

    :cond_ac
    sget-object v0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/z;->G:[Ljava/lang/String;

    invoke-static {v2, v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/b0/b;->b(Ljava/lang/String;[Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_b8

    invoke-virtual {p2, p0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b;->n(Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/A;)V

    return v4

    .line 12
    :cond_b8
    invoke-virtual {p2, p1, v1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b;->X(Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/O;Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/A;)Z

    move-result p1

    return p1

    :cond_bd
    invoke-virtual {p2, p1, v1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b;->X(Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/O;Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/A;)Z

    move-result p1

    return p1
.end method
