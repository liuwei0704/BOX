.class public interface abstract Lcom/github/catvod/spider/xbpqxyq/xbpq/P/G;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lcom/github/catvod/spider/xbpqxyq/xbpq/P/r;


# virtual methods
.method public abstract b()Lcom/github/catvod/spider/xbpqxyq/xbpq/P/F;
.end method

.method public abstract c(Lcom/github/catvod/spider/xbpqxyq/xbpq/P/D;Lcom/github/catvod/spider/xbpqxyq/xbpq/P/D;)Ljava/lang/String;
.end method

.method public abstract e(I)Lcom/github/catvod/spider/xbpqxyq/xbpq/P/D;
.end method

.method public abstract get(I)Lcom/github/catvod/spider/xbpqxyq/xbpq/P/D;
.end method
