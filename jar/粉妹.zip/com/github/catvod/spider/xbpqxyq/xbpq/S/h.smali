.class public final Lcom/github/catvod/spider/xbpqxyq/xbpq/S/h;
.super Lcom/github/catvod/spider/xbpqxyq/xbpq/S/g;
.source "SourceFile"


# direct methods
.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/S/g;-><init>()V

    return-void
.end method
