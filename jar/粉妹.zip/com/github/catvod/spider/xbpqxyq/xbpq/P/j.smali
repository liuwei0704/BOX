.class public abstract Lcom/github/catvod/spider/xbpqxyq/xbpq/P/j;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lcom/github/catvod/spider/xbpqxyq/xbpq/P/d;


# instance fields
.field protected final a:I

.field protected b:I


# direct methods
.method constructor <init>(I)V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput p1, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/j;->a:I

    const/4 p1, 0x0

    iput p1, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/j;->b:I

    return-void
.end method

.method public static k(Lcom/github/catvod/spider/xbpqxyq/xbpq/P/f;)Lcom/github/catvod/spider/xbpqxyq/xbpq/P/j;
    .registers 5

    invoke-virtual {p0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/f;->e()I

    move-result v0

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/l/a;->a(I)I

    move-result v0

    if-eqz v0, :cond_46

    const/4 v1, 0x1

    if-eq v0, v1, :cond_31

    const/4 v1, 0x2

    if-ne v0, v1, :cond_25

    new-instance v0, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/h;

    invoke-virtual {p0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/f;->g()I

    move-result v1

    invoke-virtual {p0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/f;->h()I

    move-result v2

    invoke-virtual {p0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/f;->f()[I

    move-result-object v3

    invoke-virtual {p0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/f;->a()I

    invoke-direct {v0, v1, v2, v3}, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/h;-><init>(II[I)V

    return-object v0

    :cond_25
    new-instance p0, Ljava/lang/UnsupportedOperationException;

    const-string v0, "391731450130161B2D0017"

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-direct {p0, v0}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_31
    new-instance v0, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/g;

    invoke-virtual {p0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/f;->g()I

    move-result v1

    invoke-virtual {p0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/f;->h()I

    move-result v2

    invoke-virtual {p0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/f;->d()[C

    move-result-object v3

    invoke-virtual {p0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/f;->a()I

    invoke-direct {v0, v1, v2, v3}, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/g;-><init>(II[C)V

    return-object v0

    :cond_46
    new-instance v0, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/i;

    invoke-virtual {p0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/f;->g()I

    move-result v1

    invoke-virtual {p0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/f;->h()I

    move-result v2

    invoke-virtual {p0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/f;->c()[B

    move-result-object v3

    invoke-virtual {p0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/f;->a()I

    invoke-direct {v0, v1, v2, v3}, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/i;-><init>(II[B)V

    return-object v0
.end method


# virtual methods
.method public final a()V
    .registers 1

    return-void
.end method

.method public final d(I)V
    .registers 2

    iput p1, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/j;->b:I

    return-void
.end method

.method public final g()I
    .registers 2

    const/4 v0, -0x1

    return v0
.end method

.method public final i()I
    .registers 2

    iget v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/j;->b:I

    return v0
.end method

.method public final j()V
    .registers 3

    iget v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/j;->a:I

    iget v1, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/j;->b:I

    sub-int/2addr v0, v1

    if-eqz v0, :cond_c

    add-int/lit8 v1, v1, 0x1

    iput v1, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/j;->b:I

    return-void

    :cond_c
    new-instance v0, Ljava/lang/IllegalStateException;

    const-string v1, "14192B0B1C21571B2A0B00201A1D65203C13"

    invoke-static {v1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method public final size()I
    .registers 2

    iget v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/j;->a:I

    return v0
.end method

.method public final toString()Ljava/lang/String;
    .registers 3

    iget v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/j;->a:I

    add-int/lit8 v0, v0, -0x1

    const/4 v1, 0x0

    invoke-static {v1, v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/S/i;->b(II)Lcom/github/catvod/spider/xbpqxyq/xbpq/S/i;

    move-result-object v0

    invoke-interface {p0, v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/d;->h(Lcom/github/catvod/spider/xbpqxyq/xbpq/S/i;)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method
