.class public interface abstract Lcom/github/catvod/spider/xbpqxyq/xbpq/j/j;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract vertifyCode(Ljava/lang/String;)V
.end method
