.class final Lcom/github/catvod/spider/xbpqxyq/xbpq/h/a;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field static volatile a:Lcom/github/catvod/spider/xbpqxyq/xbpq/h/b;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    new-instance v0, Lcom/github/catvod/spider/xbpqxyq/xbpq/h/b;

    invoke-direct {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/h/b;-><init>()V

    sput-object v0, Lcom/github/catvod/spider/xbpqxyq/xbpq/h/a;->a:Lcom/github/catvod/spider/xbpqxyq/xbpq/h/b;

    return-void
.end method
