.class final enum Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/r;
.super Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/A;
.source "SourceFile"


# direct methods
.method constructor <init>()V
    .registers 4

    const-string v0, "351D230A01303F0C2809"

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-direct {p0, v0, v1, v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/A;-><init>(Ljava/lang/String;ILcom/github/catvod/spider/xbpqxyq/xbpq/d0/m;)V

    return-void
.end method


# virtual methods
.method final d(Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/O;Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b;)Z
    .registers 8

    sget-object v0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/A;->e:Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/s;

    invoke-virtual {p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/O;->c()Z

    move-result v1

    const/4 v2, 0x0

    if-eqz v1, :cond_d

    invoke-virtual {p2, p0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b;->n(Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/A;)V

    return v2

    :cond_d
    invoke-virtual {p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/O;->b()Z

    move-result v1

    if-eqz v1, :cond_19

    .line 1
    check-cast p1, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/I;

    .line 2
    invoke-virtual {p2, p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b;->F(Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/I;)V

    goto :goto_42

    :cond_19
    invoke-static {p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/A;->a(Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/O;)Z

    move-result v1

    if-eqz v1, :cond_25

    .line 3
    check-cast p1, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/H;

    .line 4
    invoke-virtual {p2, p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b;->E(Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/H;)V

    goto :goto_42

    :cond_25
    invoke-virtual {p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/O;->f()Z

    move-result v1

    const-string v3, "1F0C2809"

    invoke-static {v3}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    if-eqz v1, :cond_44

    .line 5
    move-object v1, p1

    check-cast v1, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/M;

    .line 6
    iget-object v4, v1, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/N;->c:Ljava/lang/String;

    .line 7
    invoke-virtual {v4, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_44

    invoke-virtual {p2, v1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b;->D(Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/M;)Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/l;

    invoke-virtual {p2, v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b;->j0(Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/A;)V

    :goto_42
    const/4 p1, 0x1

    return p1

    :cond_44
    invoke-virtual {p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/O;->e()Z

    move-result v1

    if-eqz v1, :cond_62

    .line 8
    move-object v1, p1

    check-cast v1, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/L;

    .line 9
    iget-object v1, v1, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/N;->c:Ljava/lang/String;

    .line 10
    sget-object v4, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/z;->e:[Ljava/lang/String;

    invoke-static {v1, v4}, Lcom/github/catvod/spider/xbpqxyq/xbpq/b0/b;->b(Ljava/lang/String;[Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_62

    .line 11
    :cond_57
    invoke-virtual {p2, v3}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b;->L(Ljava/lang/String;)Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/l;

    invoke-virtual {p2, v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b;->j0(Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/A;)V

    invoke-virtual {p2, p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b;->c(Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/O;)Z

    move-result p1

    return p1

    .line 12
    :cond_62
    invoke-virtual {p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/O;->e()Z

    move-result v1

    if-eqz v1, :cond_57

    invoke-virtual {p2, p0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b;->n(Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/A;)V

    return v2
.end method
