.class public abstract Lcom/github/catvod/spider/xbpqxyq/xbpq/P/s;
.super Lcom/github/catvod/spider/xbpqxyq/xbpq/P/B;
.source "SourceFile"

# interfaces
.implements Lcom/github/catvod/spider/xbpqxyq/xbpq/P/F;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/github/catvod/spider/xbpqxyq/xbpq/P/B<",
        "Ljava/lang/Integer;",
        "Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/B;",
        ">;",
        "Lcom/github/catvod/spider/xbpqxyq/xbpq/P/F;"
    }
.end annotation


# instance fields
.field public d:Lcom/github/catvod/spider/xbpqxyq/xbpq/P/d;

.field protected e:Lcom/github/catvod/spider/xbpqxyq/xbpq/S/l;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/github/catvod/spider/xbpqxyq/xbpq/S/l<",
            "Lcom/github/catvod/spider/xbpqxyq/xbpq/P/F;",
            "Lcom/github/catvod/spider/xbpqxyq/xbpq/P/d;",
            ">;"
        }
    .end annotation
.end field

.field protected f:Lcom/github/catvod/spider/xbpqxyq/xbpq/P/l;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/github/catvod/spider/xbpqxyq/xbpq/P/E<",
            "*>;"
        }
    .end annotation
.end field

.field public g:Lcom/github/catvod/spider/xbpqxyq/xbpq/P/D;

.field public h:I

.field public i:I

.field public j:I

.field public k:Z

.field public l:I

.field public m:I

.field public final n:Lcom/github/catvod/spider/xbpqxyq/xbpq/S/h;

.field public o:I


# direct methods
.method public constructor <init>(Lcom/github/catvod/spider/xbpqxyq/xbpq/P/d;)V
    .registers 3

    invoke-direct {p0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/B;-><init>()V

    sget-object v0, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/l;->a:Lcom/github/catvod/spider/xbpqxyq/xbpq/P/l;

    iput-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/s;->f:Lcom/github/catvod/spider/xbpqxyq/xbpq/P/l;

    const/4 v0, -0x1

    iput v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/s;->h:I

    new-instance v0, Lcom/github/catvod/spider/xbpqxyq/xbpq/S/h;

    invoke-direct {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/S/h;-><init>()V

    iput-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/s;->n:Lcom/github/catvod/spider/xbpqxyq/xbpq/S/h;

    const/4 v0, 0x0

    iput v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/s;->o:I

    iput-object p1, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/s;->d:Lcom/github/catvod/spider/xbpqxyq/xbpq/P/d;

    new-instance v0, Lcom/github/catvod/spider/xbpqxyq/xbpq/S/l;

    invoke-direct {v0, p0, p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/S/l;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    iput-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/s;->e:Lcom/github/catvod/spider/xbpqxyq/xbpq/S/l;

    return-void
.end method


# virtual methods
.method public final a()I
    .registers 2

    .line 1
    iget-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/B;->b:Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/l;

    .line 2
    check-cast v0, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/B;

    invoke-virtual {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/B;->g()I

    move-result v0

    return v0
.end method

.method public final b()Lcom/github/catvod/spider/xbpqxyq/xbpq/P/d;
    .registers 2

    iget-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/s;->d:Lcom/github/catvod/spider/xbpqxyq/xbpq/P/d;

    return-object v0
.end method

.method public final c()Lcom/github/catvod/spider/xbpqxyq/xbpq/P/D;
    .registers 12

    iget-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/s;->d:Lcom/github/catvod/spider/xbpqxyq/xbpq/P/d;

    if-eqz v0, :cond_a8

    invoke-interface {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/r;->g()I

    :goto_7
    :try_start_7
    iget-boolean v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/s;->k:Z

    if-eqz v0, :cond_10

    invoke-virtual {p0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/s;->l()Lcom/github/catvod/spider/xbpqxyq/xbpq/P/D;

    goto/16 :goto_99

    :cond_10
    const/4 v0, 0x0

    iput-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/s;->g:Lcom/github/catvod/spider/xbpqxyq/xbpq/P/D;

    const/4 v0, 0x0

    iput v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/s;->l:I

    iget-object v1, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/s;->d:Lcom/github/catvod/spider/xbpqxyq/xbpq/P/d;

    invoke-interface {v1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/r;->i()I

    move-result v1

    iput v1, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/s;->h:I

    .line 1
    iget-object v1, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/B;->b:Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/l;

    .line 2
    check-cast v1, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/B;

    invoke-virtual {v1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/B;->g()I

    move-result v1

    iput v1, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/s;->j:I

    .line 3
    iget-object v1, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/B;->b:Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/l;

    .line 4
    check-cast v1, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/B;

    invoke-virtual {v1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/B;->h()I

    move-result v1

    iput v1, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/s;->i:I

    :cond_32
    iput v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/s;->m:I
    :try_end_34
    .catchall {:try_start_7 .. :try_end_34} :catchall_a1

    const/4 v1, 0x1

    const/4 v2, -0x1

    const/4 v3, -0x3

    .line 5
    :try_start_37
    iget-object v4, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/B;->b:Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/l;

    .line 6
    check-cast v4, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/B;

    iget-object v5, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/s;->d:Lcom/github/catvod/spider/xbpqxyq/xbpq/P/d;

    iget v6, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/s;->o:I

    invoke-virtual {v4, v5, v6}, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/B;->i(Lcom/github/catvod/spider/xbpqxyq/xbpq/P/d;I)I

    move-result v4
    :try_end_43
    .catch Lcom/github/catvod/spider/xbpqxyq/xbpq/P/t; {:try_start_37 .. :try_end_43} :catch_44
    .catchall {:try_start_37 .. :try_end_43} :catchall_a1

    goto :goto_5a

    :catch_44
    move-exception v4

    :try_start_45
    invoke-virtual {p0, v4}, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/s;->m(Lcom/github/catvod/spider/xbpqxyq/xbpq/P/t;)V

    .line 7
    iget-object v4, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/s;->d:Lcom/github/catvod/spider/xbpqxyq/xbpq/P/d;

    invoke-interface {v4, v1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/r;->f(I)I

    move-result v4

    if-eq v4, v2, :cond_59

    .line 8
    iget-object v4, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/B;->b:Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/l;

    .line 9
    check-cast v4, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/B;

    iget-object v5, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/s;->d:Lcom/github/catvod/spider/xbpqxyq/xbpq/P/d;

    invoke-virtual {v4, v5}, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/B;->e(Lcom/github/catvod/spider/xbpqxyq/xbpq/P/d;)V

    :cond_59
    const/4 v4, -0x3

    .line 10
    :goto_5a
    iget-object v5, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/s;->d:Lcom/github/catvod/spider/xbpqxyq/xbpq/P/d;

    invoke-interface {v5, v1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/r;->f(I)I

    move-result v5

    if-ne v5, v2, :cond_64

    iput-boolean v1, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/s;->k:Z

    :cond_64
    iget v1, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/s;->m:I

    if-nez v1, :cond_6a

    iput v4, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/s;->m:I

    :cond_6a
    iget v4, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/s;->m:I

    if-ne v4, v3, :cond_6f

    goto :goto_7

    :cond_6f
    const/4 v1, -0x2

    if-eq v4, v1, :cond_32

    iget-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/s;->g:Lcom/github/catvod/spider/xbpqxyq/xbpq/P/D;

    if-nez v0, :cond_99

    .line 11
    iget-object v1, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/s;->f:Lcom/github/catvod/spider/xbpqxyq/xbpq/P/l;

    iget-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/s;->e:Lcom/github/catvod/spider/xbpqxyq/xbpq/S/l;

    const/4 v5, 0x0

    iget v6, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/s;->l:I

    iget v7, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/s;->h:I

    .line 12
    iget-object v3, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/s;->d:Lcom/github/catvod/spider/xbpqxyq/xbpq/P/d;

    invoke-interface {v3}, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/r;->i()I

    move-result v3

    add-int/lit8 v8, v3, -0x1

    .line 13
    iget v9, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/s;->i:I

    iget v10, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/s;->j:I

    move-object v2, v0

    move v3, v4

    move-object v4, v5

    move v5, v6

    move v6, v7

    move v7, v8

    move v8, v9

    move v9, v10

    invoke-virtual/range {v1 .. v9}, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/l;->a(Lcom/github/catvod/spider/xbpqxyq/xbpq/S/l;ILjava/lang/String;IIIII)Lcom/github/catvod/spider/xbpqxyq/xbpq/P/D;

    move-result-object v0

    .line 14
    iput-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/s;->g:Lcom/github/catvod/spider/xbpqxyq/xbpq/P/D;

    .line 15
    :cond_99
    :goto_99
    iget-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/s;->g:Lcom/github/catvod/spider/xbpqxyq/xbpq/P/D;
    :try_end_9b
    .catchall {:try_start_45 .. :try_end_9b} :catchall_a1

    iget-object v1, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/s;->d:Lcom/github/catvod/spider/xbpqxyq/xbpq/P/d;

    invoke-interface {v1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/r;->a()V

    return-object v0

    :catchall_a1
    move-exception v0

    .line 16
    iget-object v1, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/s;->d:Lcom/github/catvod/spider/xbpqxyq/xbpq/P/d;

    invoke-interface {v1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/r;->a()V

    throw v0

    :cond_a8
    new-instance v0, Ljava/lang/IllegalStateException;

    const-string v1, "191D3D11273A1C1D2B450130060D2C1716265719650B1C3B5A1630091F751E1635100775040C3700123859"

    invoke-static {v1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    goto :goto_b5

    :goto_b4
    throw v0

    :goto_b5
    goto :goto_b4
.end method

.method public final d()I
    .registers 2

    .line 1
    iget-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/B;->b:Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/l;

    .line 2
    check-cast v0, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/B;

    invoke-virtual {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/B;->h()I

    move-result v0

    return v0
.end method

.method public final e()Lcom/github/catvod/spider/xbpqxyq/xbpq/P/E;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/github/catvod/spider/xbpqxyq/xbpq/P/E<",
            "+",
            "Lcom/github/catvod/spider/xbpqxyq/xbpq/P/D;",
            ">;"
        }
    .end annotation

    iget-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/s;->f:Lcom/github/catvod/spider/xbpqxyq/xbpq/P/l;

    return-object v0
.end method

.method public final l()Lcom/github/catvod/spider/xbpqxyq/xbpq/P/D;
    .registers 11

    .line 1
    iget-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/B;->b:Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/l;

    .line 2
    check-cast v0, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/B;

    invoke-virtual {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/B;->g()I

    move-result v9

    .line 3
    iget-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/B;->b:Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/l;

    .line 4
    check-cast v0, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/B;

    invoke-virtual {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/B;->h()I

    move-result v8

    .line 5
    iget-object v1, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/s;->f:Lcom/github/catvod/spider/xbpqxyq/xbpq/P/l;

    iget-object v2, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/s;->e:Lcom/github/catvod/spider/xbpqxyq/xbpq/S/l;

    iget-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/s;->d:Lcom/github/catvod/spider/xbpqxyq/xbpq/P/d;

    invoke-interface {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/r;->i()I

    move-result v6

    iget-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/s;->d:Lcom/github/catvod/spider/xbpqxyq/xbpq/P/d;

    invoke-interface {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/r;->i()I

    move-result v0

    add-int/lit8 v7, v0, -0x1

    const/4 v3, -0x1

    const/4 v4, 0x0

    const/4 v5, 0x0

    invoke-virtual/range {v1 .. v9}, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/l;->a(Lcom/github/catvod/spider/xbpqxyq/xbpq/S/l;ILjava/lang/String;IIIII)Lcom/github/catvod/spider/xbpqxyq/xbpq/P/D;

    move-result-object v0

    .line 6
    iput-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/s;->g:Lcom/github/catvod/spider/xbpqxyq/xbpq/P/D;

    return-object v0
.end method

.method public final m(Lcom/github/catvod/spider/xbpqxyq/xbpq/P/t;)V
    .registers 11

    iget-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/s;->d:Lcom/github/catvod/spider/xbpqxyq/xbpq/P/d;

    iget v1, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/s;->h:I

    invoke-interface {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/r;->i()I

    move-result v2

    invoke-static {v1, v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/S/i;->b(II)Lcom/github/catvod/spider/xbpqxyq/xbpq/S/i;

    move-result-object v1

    invoke-interface {v0, v1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/d;->h(Lcom/github/catvod/spider/xbpqxyq/xbpq/S/i;)Ljava/lang/String;

    move-result-object v0

    const-string v1, "03172E001D75051D260A143B1E0C2C0A1D75120A370A0175160C7F4554"

    invoke-static {v1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    .line 1
    invoke-static {v1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d/d;->b(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    .line 2
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v0}, Ljava/lang/String;->toCharArray()[C

    move-result-object v0

    array-length v3, v0

    const/4 v4, 0x0

    :goto_25
    if-ge v4, v3, :cond_5f

    aget-char v5, v0, v4

    int-to-char v6, v5

    .line 3
    invoke-static {v6}, Ljava/lang/String;->valueOf(C)Ljava/lang/String;

    move-result-object v6

    const/4 v7, -0x1

    if-eq v5, v7, :cond_53

    const/16 v7, 0xd

    if-eq v5, v7, :cond_4c

    const/16 v7, 0x9

    if-eq v5, v7, :cond_45

    const/16 v7, 0xa

    if-eq v5, v7, :cond_3e

    goto :goto_59

    :cond_3e
    const-string v6, "2B16"

    invoke-static {v6}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    goto :goto_59

    :cond_45
    const-string v6, "2B0C"

    invoke-static {v6}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    goto :goto_59

    :cond_4c
    const-string v6, "2B0A"

    invoke-static {v6}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    goto :goto_59

    :cond_53
    const-string v6, "4B3D0A234D"

    invoke-static {v6}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    .line 4
    :goto_59
    invoke-virtual {v2, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    add-int/lit8 v4, v4, 0x1

    goto :goto_25

    :cond_5f
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    .line 5
    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v0, "50"

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v7

    invoke-virtual {p0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/B;->g()Lcom/github/catvod/spider/xbpqxyq/xbpq/P/a;

    move-result-object v0

    const/4 v4, 0x0

    iget v5, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/s;->i:I

    iget v6, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/s;->j:I

    move-object v2, v0

    check-cast v2, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/y;

    move-object v3, p0

    move-object v8, p1

    invoke-virtual/range {v2 .. v8}, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/y;->a(Lcom/github/catvod/spider/xbpqxyq/xbpq/P/B;Ljava/lang/Object;IILjava/lang/String;Lcom/github/catvod/spider/xbpqxyq/xbpq/P/z;)V

    return-void
.end method
