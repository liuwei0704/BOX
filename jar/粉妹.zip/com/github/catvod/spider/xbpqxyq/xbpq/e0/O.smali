.class public interface abstract Lcom/github/catvod/spider/xbpqxyq/xbpq/e0/O;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract a(Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/r;I)V
.end method

.method public abstract b(Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/r;I)V
.end method
