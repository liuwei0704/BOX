.class final enum Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/v;
.super Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/A;
.source "SourceFile"


# direct methods
.method constructor <init>()V
    .registers 4

    const-string v0, "361E3100011D121921"

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v1, 0x5

    const/4 v2, 0x0

    invoke-direct {p0, v0, v1, v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/A;-><init>(Ljava/lang/String;ILcom/github/catvod/spider/xbpqxyq/xbpq/d0/m;)V

    return-void
.end method

.method private e(Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/O;Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b;)Z
    .registers 4

    const-string v0, "1517211C"

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p2, v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/i1;->f(Ljava/lang/String;)Z

    const/4 v0, 0x1

    invoke-virtual {p2, v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b;->o(Z)V

    invoke-virtual {p2, p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b;->c(Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/O;)Z

    move-result p1

    return p1
.end method


# virtual methods
.method final d(Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/O;Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b;)Z
    .registers 8

    sget-object v0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/A;->i:Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/w;

    invoke-static {p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/A;->a(Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/O;)Z

    move-result v1

    if-eqz v1, :cond_f

    .line 1
    check-cast p1, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/H;

    .line 2
    invoke-virtual {p2, p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b;->E(Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/H;)V

    goto/16 :goto_b7

    :cond_f
    invoke-virtual {p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/O;->b()Z

    move-result v1

    if-eqz v1, :cond_1c

    .line 3
    check-cast p1, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/I;

    .line 4
    invoke-virtual {p2, p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b;->F(Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/I;)V

    goto/16 :goto_b7

    :cond_1c
    invoke-virtual {p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/O;->c()Z

    move-result v1

    if-eqz v1, :cond_27

    invoke-virtual {p2, p0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b;->n(Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/A;)V

    goto/16 :goto_b7

    :cond_27
    invoke-virtual {p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/O;->f()Z

    move-result v1

    const/4 v2, 0x0

    if-eqz v1, :cond_9c

    .line 5
    move-object v1, p1

    check-cast v1, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/M;

    .line 6
    iget-object v3, v1, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/N;->c:Ljava/lang/String;

    const-string v4, "1F0C2809"

    invoke-static {v4}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    .line 7
    invoke-virtual {v3, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_44

    invoke-virtual {p2, p1, v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b;->X(Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/O;Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/A;)Z

    move-result p1

    return p1

    :cond_44
    const-string v4, "1517211C"

    invoke-static {v4}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_5a

    invoke-virtual {p2, v1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b;->D(Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/M;)Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/l;

    invoke-virtual {p2, v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b;->o(Z)V

    invoke-virtual {p2, v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b;->j0(Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/A;)V

    goto :goto_b7

    :cond_5a
    const-string v0, "110A24081626120C"

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v3, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_6f

    invoke-virtual {p2, v1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b;->D(Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/M;)Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/l;

    sget-object p1, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/A;->u:Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/l;

    invoke-virtual {p2, p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b;->j0(Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/A;)V

    goto :goto_b7

    :cond_6f
    sget-object v0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/z;->g:[Ljava/lang/String;

    invoke-static {v3, v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/b0/b;->b(Ljava/lang/String;[Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_8c

    invoke-virtual {p2, p0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b;->n(Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/A;)V

    invoke-virtual {p2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b;->u()Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/l;

    move-result-object v0

    .line 8
    iget-object v1, p2, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/i1;->e:Ljava/util/ArrayList;

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 9
    sget-object v1, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/A;->f:Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/t;

    invoke-virtual {p2, p1, v1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b;->X(Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/O;Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/A;)Z

    invoke-virtual {p2, v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b;->c0(Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/l;)Z

    goto :goto_b7

    :cond_8c
    const-string v0, "1F1D2401"

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v3, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_b4

    invoke-virtual {p2, p0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b;->n(Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/A;)V

    return v2

    :cond_9c
    invoke-virtual {p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/O;->e()Z

    move-result v0

    if-eqz v0, :cond_b4

    .line 10
    move-object v0, p1

    check-cast v0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/L;

    .line 11
    iget-object v0, v0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/N;->c:Ljava/lang/String;

    .line 12
    sget-object v1, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/z;->d:[Ljava/lang/String;

    invoke-static {v0, v1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/b0/b;->b(Ljava/lang/String;[Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_b0

    goto :goto_b4

    :cond_b0
    invoke-virtual {p2, p0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b;->n(Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/A;)V

    return v2

    :cond_b4
    :goto_b4
    invoke-direct {p0, p1, p2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/v;->e(Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/O;Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b;)Z

    :goto_b7
    const/4 p1, 0x1

    return p1
.end method
