.class public interface abstract Lcom/github/catvod/spider/xbpqxyq/xbpq/T/c;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract S(Lcom/github/catvod/spider/xbpqxyq/xbpq/P/x;)V
.end method

.method public abstract a()V
.end method

.method public abstract b(Lcom/github/catvod/spider/xbpqxyq/xbpq/T/f;)V
.end method

.method public abstract h(Lcom/github/catvod/spider/xbpqxyq/xbpq/P/x;)V
.end method
