.class public interface abstract Lcom/github/catvod/spider/xbpqxyq/xbpq/P/H;
.super Ljava/lang/Object;
.source "SourceFile"
