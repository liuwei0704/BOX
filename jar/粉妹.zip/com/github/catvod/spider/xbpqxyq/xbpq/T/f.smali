.class public interface abstract Lcom/github/catvod/spider/xbpqxyq/xbpq/T/f;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lcom/github/catvod/spider/xbpqxyq/xbpq/T/b;


# virtual methods
.method public abstract a()Lcom/github/catvod/spider/xbpqxyq/xbpq/P/D;
.end method
