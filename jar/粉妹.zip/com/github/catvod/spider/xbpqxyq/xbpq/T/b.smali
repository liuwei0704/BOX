.class public interface abstract Lcom/github/catvod/spider/xbpqxyq/xbpq/T/b;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract b(I)Lcom/github/catvod/spider/xbpqxyq/xbpq/T/b;
.end method

.method public abstract c()Ljava/lang/String;
.end method

.method public abstract d()I
.end method

.method public abstract e(Lcom/github/catvod/spider/xbpqxyq/xbpq/T/d;)Ljava/lang/Object;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Lcom/github/catvod/spider/xbpqxyq/xbpq/T/d<",
            "+TT;>;)TT;"
        }
    .end annotation
.end method
