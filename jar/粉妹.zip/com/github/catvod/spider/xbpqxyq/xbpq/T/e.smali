.class public interface abstract Lcom/github/catvod/spider/xbpqxyq/xbpq/T/e;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lcom/github/catvod/spider/xbpqxyq/xbpq/T/b;
