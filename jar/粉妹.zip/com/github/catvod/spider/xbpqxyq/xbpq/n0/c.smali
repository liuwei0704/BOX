.class public final Lcom/github/catvod/spider/xbpqxyq/xbpq/n0/c;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field static volatile a:I

.field static final b:Lcom/github/catvod/spider/xbpqxyq/xbpq/p0/d;

.field static final c:Lcom/github/catvod/spider/xbpqxyq/xbpq/W/a;

.field static d:Z

.field private static final e:[Ljava/lang/String;

.field private static f:Ljava/lang/String;


# direct methods
.method static constructor <clinit>()V
    .registers 3

    new-instance v0, Lcom/github/catvod/spider/xbpqxyq/xbpq/p0/d;

    invoke-direct {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/p0/d;-><init>()V

    sput-object v0, Lcom/github/catvod/spider/xbpqxyq/xbpq/n0/c;->b:Lcom/github/catvod/spider/xbpqxyq/xbpq/p0/d;

    new-instance v0, Lcom/github/catvod/spider/xbpqxyq/xbpq/W/a;

    invoke-direct {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/W/a;-><init>()V

    sput-object v0, Lcom/github/catvod/spider/xbpqxyq/xbpq/n0/c;->c:Lcom/github/catvod/spider/xbpqxyq/xbpq/W/a;

    const-string v0, "04142351197B131D310010213B1722021627391928003E3C04152411103D"

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v1, 0x0

    .line 1
    :try_start_15
    invoke-static {v0}, Ljava/lang/System;->getProperty(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1
    :try_end_19
    .catch Ljava/lang/SecurityException; {:try_start_15 .. :try_end_19} :catch_1a

    goto :goto_1b

    :catch_1a
    nop

    :goto_1b
    const/4 v0, 0x0

    if-nez v1, :cond_20

    const/4 v1, 0x0

    goto :goto_2a

    :cond_20
    const-string v2, "030A3000"

    invoke-static {v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    .line 2
    invoke-virtual {v1, v2}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v1

    .line 3
    :goto_2a
    sput-boolean v1, Lcom/github/catvod/spider/xbpqxyq/xbpq/n0/c;->d:Z

    const/4 v1, 0x2

    new-array v1, v1, [Ljava/lang/String;

    const-string v2, "465673"

    invoke-static {v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    aput-object v2, v1, v0

    const/4 v0, 0x1

    const-string v2, "465672"

    invoke-static {v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    aput-object v2, v1, v0

    sput-object v1, Lcom/github/catvod/spider/xbpqxyq/xbpq/n0/c;->e:[Ljava/lang/String;

    const-string v0, "180A224A0039114C2F4A1A3807146A360734031126291C32101D37271A3B131D374B1039160B36"

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lcom/github/catvod/spider/xbpqxyq/xbpq/n0/c;->f:Ljava/lang/String;

    return-void
.end method

.method private constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method private static final a()V
    .registers 7

    const-string v0, "31192C091631570C2A451A3B040C240B073C160C20452019314C0F453F3A101F20173534140C2A170A"

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v1, 0x0

    const/4 v2, 0x2

    :try_start_8
    invoke-static {}, Lcom/github/catvod/spider/xbpqxyq/xbpq/n0/c;->f()Z

    move-result v3

    if-nez v3, :cond_15

    invoke-static {}, Lcom/github/catvod/spider/xbpqxyq/xbpq/n0/c;->b()Ljava/util/Set;

    move-result-object v1

    invoke-static {v1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/n0/c;->i(Ljava/util/Set;)V

    :cond_15
    invoke-static {}, Lorg/slf4j/impl/StaticLoggerBinder;->getSingleton()Lorg/slf4j/impl/StaticLoggerBinder;

    const/4 v3, 0x3

    sput v3, Lcom/github/catvod/spider/xbpqxyq/xbpq/n0/c;->a:I

    invoke-static {v1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/n0/c;->h(Ljava/util/Set;)V
    :try_end_1e
    .catch Ljava/lang/NoClassDefFoundError; {:try_start_8 .. :try_end_1e} :catch_69
    .catch Ljava/lang/NoSuchMethodError; {:try_start_8 .. :try_end_1e} :catch_38
    .catch Ljava/lang/Exception; {:try_start_8 .. :try_end_1e} :catch_26
    .catchall {:try_start_8 .. :try_end_1e} :catchall_23

    :goto_1e
    invoke-static {}, Lcom/github/catvod/spider/xbpqxyq/xbpq/n0/c;->g()V

    goto/16 :goto_b0

    :catchall_23
    move-exception v0

    goto/16 :goto_b7

    :catch_26
    move-exception v1

    .line 1
    :try_start_27
    sput v2, Lcom/github/catvod/spider/xbpqxyq/xbpq/n0/c;->a:I

    invoke-static {v0, v1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/p0/f;->c(Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 2
    new-instance v0, Ljava/lang/IllegalStateException;

    const-string v2, "2216201D0330140C2001533C1911310C12391E0224111A3A195823041A39020A20"

    invoke-static {v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-direct {v0, v2, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    throw v0

    :catch_38
    move-exception v0

    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v1

    if-eqz v1, :cond_68

    const-string v3, "180A224B0039114C2F4B1A3807146B360734031126291C32101D37271A3B131D374B1430032B2C0B1439120C2A0B5B7C"

    invoke-static {v3}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v1, v3}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-eqz v1, :cond_68

    sput v2, Lcom/github/catvod/spider/xbpqxyq/xbpq/n0/c;->a:I

    const-string v1, "04142351197816082C45427B41563D455B3A0558290407300551650C00751E16260A1E25160C2C071F30570F2C111B7503102C1653371E16210C1D3259"

    invoke-static {v1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/p0/f;->b(Ljava/lang/String;)V

    const-string v1, "2E17301753371E16210C1D32571136450530050B2C0A1D754656704B4675180A650012271B1120175D"

    invoke-static {v1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/p0/f;->b(Ljava/lang/String;)V

    const-string v1, "22082217123112583C0A0627571A2C0B173C191F65111C75011D37161A3A1958744B457B0F56"

    invoke-static {v1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/p0/f;->b(Ljava/lang/String;)V

    :cond_68
    throw v0

    :catch_69
    move-exception v1

    invoke-virtual {v1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v3

    const/4 v4, 0x0

    if-nez v3, :cond_72

    goto :goto_8e

    :cond_72
    const-string v5, "180A224A0039114C2F4A1A3807146A360734031126291C32101D37271A3B131D37"

    invoke-static {v5}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    .line 3
    invoke-virtual {v3, v5}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v5

    const/4 v6, 0x1

    if-eqz v5, :cond_81

    :goto_7f
    const/4 v4, 0x1

    goto :goto_8e

    :cond_81
    const-string v5, "180A224B0039114C2F4B1A3807146B360734031126291C32101D37271A3B131D37"

    invoke-static {v5}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v3, v5}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v3

    if-eqz v3, :cond_8e

    goto :goto_7f

    :cond_8e
    :goto_8e
    if-eqz v4, :cond_b1

    const/4 v0, 0x4

    .line 4
    sput v0, Lcom/github/catvod/spider/xbpqxyq/xbpq/n0/c;->a:I

    const-string v0, "31192C091631570C2A451F3A161C65061F34040B65471C271056360915611D562C080339592B3104073C14342A021430053A2C0B1730055A6B"

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/p0/f;->b(Ljava/lang/String;)V

    const-string v0, "331D2304063903112B02532118582B0A5E3A071D3704073C1816654D3D1A275165091C32101D37451A3807142008163B0319310C1C3B"

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/p0/f;->b(Ljava/lang/String;)V

    const-string v0, "241D20451B2103087F4A5C22000F6B161F3343126B0A0132581B2A011626591031081F76240C24111A363B172202162735112B011627571E2A175333020A310D1627571C2011123C1B0B6B"

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/p0/f;->b(Ljava/lang/String;)V

    goto/16 :goto_1e

    :goto_b0
    return-void

    .line 5
    :cond_b1
    sput v2, Lcom/github/catvod/spider/xbpqxyq/xbpq/n0/c;->a:I

    invoke-static {v0, v1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/p0/f;->c(Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 6
    throw v1
    :try_end_b7
    .catchall {:try_start_27 .. :try_end_b7} :catchall_23

    :goto_b7
    invoke-static {}, Lcom/github/catvod/spider/xbpqxyq/xbpq/n0/c;->g()V

    goto :goto_bc

    :goto_bb
    throw v0

    :goto_bc
    goto :goto_bb
.end method

.method static b()Ljava/util/Set;
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Set<",
            "Ljava/net/URL;",
            ">;"
        }
    .end annotation

    new-instance v0, Ljava/util/LinkedHashSet;

    invoke-direct {v0}, Ljava/util/LinkedHashSet;-><init>()V

    :try_start_5
    const-class v1, Lcom/github/catvod/spider/xbpqxyq/xbpq/n0/c;

    invoke-virtual {v1}, Ljava/lang/Class;->getClassLoader()Ljava/lang/ClassLoader;

    move-result-object v1

    if-nez v1, :cond_14

    sget-object v1, Lcom/github/catvod/spider/xbpqxyq/xbpq/n0/c;->f:Ljava/lang/String;

    invoke-static {v1}, Ljava/lang/ClassLoader;->getSystemResources(Ljava/lang/String;)Ljava/util/Enumeration;

    move-result-object v1

    goto :goto_1a

    :cond_14
    sget-object v2, Lcom/github/catvod/spider/xbpqxyq/xbpq/n0/c;->f:Ljava/lang/String;

    invoke-virtual {v1, v2}, Ljava/lang/ClassLoader;->getResources(Ljava/lang/String;)Ljava/util/Enumeration;

    move-result-object v1

    :goto_1a
    invoke-interface {v1}, Ljava/util/Enumeration;->hasMoreElements()Z

    move-result v2

    if-eqz v2, :cond_34

    invoke-interface {v1}, Ljava/util/Enumeration;->nextElement()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/net/URL;

    invoke-interface {v0, v2}, Ljava/util/Set;->add(Ljava/lang/Object;)Z
    :try_end_29
    .catch Ljava/io/IOException; {:try_start_5 .. :try_end_29} :catch_2a

    goto :goto_1a

    :catch_2a
    move-exception v1

    const-string v2, "320A370A0175101D31111A3B10583700003A020A26000075110A2A085325160C2D"

    invoke-static {v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-static {v2, v1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/p0/f;->c(Ljava/lang/String;Ljava/lang/Throwable;)V

    :cond_34
    return-object v0
.end method

.method public static c()Lcom/github/catvod/spider/xbpqxyq/xbpq/n0/a;
    .registers 4

    sget v0, Lcom/github/catvod/spider/xbpqxyq/xbpq/n0/c;->a:I

    const/4 v1, 0x3

    const/4 v2, 0x1

    if-nez v0, :cond_1e

    const-class v0, Lcom/github/catvod/spider/xbpqxyq/xbpq/n0/c;

    monitor-enter v0

    :try_start_9
    sget v3, Lcom/github/catvod/spider/xbpqxyq/xbpq/n0/c;->a:I

    if-nez v3, :cond_19

    sput v2, Lcom/github/catvod/spider/xbpqxyq/xbpq/n0/c;->a:I

    .line 1
    invoke-static {}, Lcom/github/catvod/spider/xbpqxyq/xbpq/n0/c;->a()V

    sget v3, Lcom/github/catvod/spider/xbpqxyq/xbpq/n0/c;->a:I

    if-ne v3, v1, :cond_19

    invoke-static {}, Lcom/github/catvod/spider/xbpqxyq/xbpq/n0/c;->j()V

    .line 2
    :cond_19
    monitor-exit v0

    goto :goto_1e

    :catchall_1b
    move-exception v1

    monitor-exit v0
    :try_end_1d
    .catchall {:try_start_9 .. :try_end_1d} :catchall_1b

    throw v1

    :cond_1e
    :goto_1e
    sget v0, Lcom/github/catvod/spider/xbpqxyq/xbpq/n0/c;->a:I

    if-eq v0, v2, :cond_4e

    const/4 v2, 0x2

    if-eq v0, v2, :cond_42

    if-eq v0, v1, :cond_39

    const/4 v1, 0x4

    if-ne v0, v1, :cond_2d

    sget-object v0, Lcom/github/catvod/spider/xbpqxyq/xbpq/n0/c;->c:Lcom/github/catvod/spider/xbpqxyq/xbpq/W/a;

    return-object v0

    :cond_2d
    new-instance v0, Ljava/lang/IllegalStateException;

    const-string v1, "2216370012361F192709167514172100"

    invoke-static {v1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_39
    invoke-static {}, Lorg/slf4j/impl/StaticLoggerBinder;->getSingleton()Lorg/slf4j/impl/StaticLoggerBinder;

    move-result-object v0

    invoke-virtual {v0}, Lorg/slf4j/impl/StaticLoggerBinder;->getLoggerFactory()Lorg/slf4j/ILoggerFactory;

    move-result-object v0

    return-object v0

    :cond_42
    new-instance v0, Ljava/lang/IllegalStateException;

    const-string v1, "180A224B0039114C2F4B3F3A101F20173534140C2A170A751E166503123C1B1D21450021160C204B531A0511220C1D341B58201D1030070C2C0A1D7500193645073D0517320B5310362A092C36075958160016751614360A533D030C355F5C7A000F324B0039114C2F4B1C271057260A173004562D111E39540D2B160636141D361615201B312B0C07"

    invoke-static {v1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_4e
    sget-object v0, Lcom/github/catvod/spider/xbpqxyq/xbpq/n0/c;->b:Lcom/github/catvod/spider/xbpqxyq/xbpq/p0/d;

    return-object v0
.end method

.method public static d(Ljava/lang/Class;)Lcom/github/catvod/spider/xbpqxyq/xbpq/n0/b;
    .registers 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Class<",
            "*>;)",
            "Lcom/github/catvod/spider/xbpqxyq/xbpq/n0/b;"
        }
    .end annotation

    invoke-virtual {p0}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v0

    .line 1
    invoke-static {}, Lcom/github/catvod/spider/xbpqxyq/xbpq/n0/c;->c()Lcom/github/catvod/spider/xbpqxyq/xbpq/n0/a;

    move-result-object v1

    invoke-interface {v1, v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/n0/a;->a(Ljava/lang/String;)Lcom/github/catvod/spider/xbpqxyq/xbpq/n0/b;

    move-result-object v0

    .line 2
    sget-boolean v1, Lcom/github/catvod/spider/xbpqxyq/xbpq/n0/c;->d:Z

    if-eqz v1, :cond_44

    invoke-static {}, Lcom/github/catvod/spider/xbpqxyq/xbpq/p0/f;->a()Ljava/lang/Class;

    move-result-object v1

    if-eqz v1, :cond_44

    .line 3
    invoke-virtual {v1, p0}, Ljava/lang/Class;->isAssignableFrom(Ljava/lang/Class;)Z

    move-result p0

    const/4 v2, 0x1

    xor-int/2addr p0, v2

    if-eqz p0, :cond_44

    const/4 p0, 0x2

    new-array p0, p0, [Ljava/lang/Object;

    const/4 v3, 0x0

    .line 4
    invoke-interface {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/n0/b;->b()Ljava/lang/String;

    move-result-object v4

    aput-object v4, p0, v3

    invoke-virtual {v1}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v1

    aput-object v1, p0, v2

    const-string v1, "331D31001021121C65091C32101D37451D341A1D65081A261A1931061B7B573F2C13163B57162408166F575A6016516E571B2A080320031D21451D341A1D7F455170045A6B"

    invoke-static {v1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-static {v1, p0}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p0

    invoke-static {p0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/p0/f;->b(Ljava/lang/String;)V

    const-string p0, "241D20451B2103087F4A5C22000F6B161F3343126B0A0132581B2A011626591031081F761B1722021627391928003E3C04152411103D571E2A1753341958201D0339161624111A3A19"

    invoke-static {p0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    invoke-static {p0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/p0/f;->b(Ljava/lang/String;)V

    :cond_44
    return-object v0
.end method

.method public static e(Ljava/lang/String;)Lcom/github/catvod/spider/xbpqxyq/xbpq/n0/b;
    .registers 2

    invoke-static {}, Lcom/github/catvod/spider/xbpqxyq/xbpq/n0/c;->c()Lcom/github/catvod/spider/xbpqxyq/xbpq/n0/a;

    move-result-object v0

    invoke-interface {v0, p0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/n0/a;->a(Ljava/lang/String;)Lcom/github/catvod/spider/xbpqxyq/xbpq/n0/b;

    move-result-object p0

    return-object p0
.end method

.method private static f()Z
    .registers 2

    const-string v0, "1D1933045D231216210A017B020A29"

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v1, 0x0

    .line 1
    :try_start_7
    invoke-static {v0}, Ljava/lang/System;->getProperty(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1
    :try_end_b
    .catch Ljava/lang/SecurityException; {:try_start_7 .. :try_end_b} :catch_b

    :catch_b
    if-nez v1, :cond_f

    const/4 v0, 0x0

    return v0

    .line 2
    :cond_f
    invoke-virtual {v1}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object v0

    const-string v1, "161621171C3C13"

    invoke-static {v1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    return v0
.end method

.method private static g()V
    .registers 10

    .line 1
    sget-object v0, Lcom/github/catvod/spider/xbpqxyq/xbpq/n0/c;->b:Lcom/github/catvod/spider/xbpqxyq/xbpq/p0/d;

    monitor-enter v0

    :try_start_3
    invoke-virtual {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/p0/d;->e()V

    invoke-virtual {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/p0/d;->d()Ljava/util/List;

    move-result-object v1

    check-cast v1, Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_10
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_28

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcom/github/catvod/spider/xbpqxyq/xbpq/p0/c;

    invoke-virtual {v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/p0/c;->b()Ljava/lang/String;

    move-result-object v3

    invoke-static {v3}, Lcom/github/catvod/spider/xbpqxyq/xbpq/n0/c;->e(Ljava/lang/String;)Lcom/github/catvod/spider/xbpqxyq/xbpq/n0/b;

    move-result-object v3

    invoke-virtual {v2, v3}, Lcom/github/catvod/spider/xbpqxyq/xbpq/p0/c;->g(Lcom/github/catvod/spider/xbpqxyq/xbpq/n0/b;)V

    goto :goto_10

    :cond_28
    monitor-exit v0
    :try_end_29
    .catchall {:try_start_3 .. :try_end_29} :catchall_10a

    .line 2
    sget-object v0, Lcom/github/catvod/spider/xbpqxyq/xbpq/n0/c;->b:Lcom/github/catvod/spider/xbpqxyq/xbpq/p0/d;

    invoke-virtual {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/p0/d;->c()Ljava/util/concurrent/LinkedBlockingQueue;

    move-result-object v1

    invoke-virtual {v1}, Ljava/util/concurrent/LinkedBlockingQueue;->size()I

    move-result v2

    new-instance v3, Ljava/util/ArrayList;

    const/16 v4, 0x80

    invoke-direct {v3, v4}, Ljava/util/ArrayList;-><init>(I)V

    const/4 v0, 0x0

    :goto_3b
    invoke-virtual {v1, v3, v4}, Ljava/util/concurrent/LinkedBlockingQueue;->drainTo(Ljava/util/Collection;I)I

    move-result v5

    if-nez v5, :cond_47

    .line 3
    sget-object v0, Lcom/github/catvod/spider/xbpqxyq/xbpq/n0/c;->b:Lcom/github/catvod/spider/xbpqxyq/xbpq/p0/d;

    invoke-virtual {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/p0/d;->b()V

    return-void

    .line 4
    :cond_47
    invoke-virtual {v3}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v5

    :goto_4b
    invoke-interface {v5}, Ljava/util/Iterator;->hasNext()Z

    move-result v6

    if-eqz v6, :cond_105

    invoke-interface {v5}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Lcom/github/catvod/spider/xbpqxyq/xbpq/o0/c;

    if-nez v6, :cond_5a

    goto :goto_7c

    .line 5
    :cond_5a
    invoke-virtual {v6}, Lcom/github/catvod/spider/xbpqxyq/xbpq/o0/c;->a()Lcom/github/catvod/spider/xbpqxyq/xbpq/p0/c;

    move-result-object v7

    invoke-virtual {v7}, Lcom/github/catvod/spider/xbpqxyq/xbpq/p0/c;->b()Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v7}, Lcom/github/catvod/spider/xbpqxyq/xbpq/p0/c;->e()Z

    move-result v9

    if-nez v9, :cond_f9

    invoke-virtual {v7}, Lcom/github/catvod/spider/xbpqxyq/xbpq/p0/c;->d()Z

    move-result v9

    if-eqz v9, :cond_6f

    goto :goto_7c

    :cond_6f
    invoke-virtual {v7}, Lcom/github/catvod/spider/xbpqxyq/xbpq/p0/c;->c()Z

    move-result v9

    if-eqz v9, :cond_79

    invoke-virtual {v7, v6}, Lcom/github/catvod/spider/xbpqxyq/xbpq/p0/c;->f(Lcom/github/catvod/spider/xbpqxyq/xbpq/o0/b;)V

    goto :goto_7c

    :cond_79
    invoke-static {v8}, Lcom/github/catvod/spider/xbpqxyq/xbpq/p0/f;->b(Ljava/lang/String;)V

    :goto_7c
    add-int/lit8 v7, v0, 0x1

    if-nez v0, :cond_f6

    .line 6
    invoke-virtual {v6}, Lcom/github/catvod/spider/xbpqxyq/xbpq/o0/c;->a()Lcom/github/catvod/spider/xbpqxyq/xbpq/p0/c;

    move-result-object v0

    invoke-virtual {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/p0/c;->c()Z

    move-result v0

    if-eqz v0, :cond_be

    .line 7
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v6, "36582B101E37120A654D"

    invoke-static {v6}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v0, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v6, "5E582A035339181F220C1D32571B24091F26571C30171A3B1058310D16751E162C111A341B113F04073C181665151B34041D650D122312582700163B57112B111627141D3511163157192B015334051D"

    invoke-static {v6}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v0, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/p0/f;->b(Ljava/lang/String;)V

    const-string v0, "1917324511301E16224501300714241C16315958110D1626125824171675040D270F16360358310A53211F1D65031A39031D370C1D32570A3009162657172345073D1258300B173005143C0C1D3257142A02143C191F65160A26031D284B"

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/p0/f;->b(Ljava/lang/String;)V

    const-string v0, "241D204512390417650D072107426A4A04220056360915611D562A17147A14172100007B1F0C28095027120829040A"

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/p0/f;->b(Ljava/lang/String;)V

    goto :goto_f6

    .line 8
    :cond_be
    invoke-virtual {v6}, Lcom/github/catvod/spider/xbpqxyq/xbpq/o0/c;->a()Lcom/github/catvod/spider/xbpqxyq/xbpq/p0/c;

    move-result-object v0

    invoke-virtual {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/p0/c;->d()Z

    move-result v0

    if-eqz v0, :cond_c9

    goto :goto_f6

    :cond_c9
    const-string v0, "23102045153A1B142A121A3B105836000775181E65160637040C2C1106211258290A1432120A36451E340E582D040530571A20001D75161B26000026121C"

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 9
    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/p0/f;->b(Ljava/lang/String;)V

    const-string v0, "130D370C1D32570C2D00533C1911310C12391E0224111A3A1958350D1226125665291C3210112B025336161429165331020A2C0B147503102C16"

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/p0/f;->b(Ljava/lang/String;)V

    const-string v0, "071024161675001D3700533B180C650D1C3B180A20015D753F1732000530055465160637041D3410163B0358290A14321E16224510341B143645073A570C2D000030"

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/p0/f;->b(Ljava/lang/String;)V

    const-string v0, "1B17220216270458320C1F39570F2A171875160B650B1C271A1929090A75120035001021121C6B"

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/p0/f;->b(Ljava/lang/String;)V

    const-string v0, "241D204512390417650D072107426A4A04220056360915611D562A17147A14172100007B1F0C28095026021A36111A21020C20291C32101D37"

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/p0/f;->b(Ljava/lang/String;)V

    :cond_f6
    :goto_f6
    move v0, v7

    goto/16 :goto_4b

    .line 10
    :cond_f9
    new-instance v0, Ljava/lang/IllegalStateException;

    const-string v1, "331D29001434031D65091C32101D3745103419162A11533712582B101F3957193145073D1E0B65160734031D6B"

    invoke-static {v1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v0

    .line 11
    :cond_105
    invoke-virtual {v3}, Ljava/util/ArrayList;->clear()V

    goto/16 :goto_3b

    :catchall_10a
    move-exception v1

    .line 12
    :try_start_10b
    monitor-exit v0
    :try_end_10c
    .catchall {:try_start_10b .. :try_end_10c} :catchall_10a

    goto :goto_10e

    :goto_10d
    throw v1

    :goto_10e
    goto :goto_10d
.end method

.method private static h(Ljava/util/Set;)V
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/Set<",
            "Ljava/net/URL;",
            ">;)V"
        }
    .end annotation

    if-eqz p0, :cond_32

    .line 1
    invoke-interface {p0}, Ljava/util/Set;->size()I

    move-result p0

    const/4 v0, 0x1

    if-le p0, v0, :cond_a

    goto :goto_b

    :cond_a
    const/4 v0, 0x0

    :goto_b
    if-eqz v0, :cond_32

    const-string p0, "361B31101239571A2C0B173C191F650C0075181E65110A2512581E"

    invoke-static {p0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    .line 2
    invoke-static {p0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d/d;->b(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p0

    .line 3
    invoke-static {}, Lorg/slf4j/impl/StaticLoggerBinder;->getSingleton()Lorg/slf4j/impl/StaticLoggerBinder;

    move-result-object v0

    invoke-virtual {v0}, Lorg/slf4j/impl/StaticLoggerBinder;->getLoggerFactoryClassStr()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p0, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v0, "2A"

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p0, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-static {p0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/p0/f;->b(Ljava/lang/String;)V

    :cond_32
    return-void
.end method

.method private static i(Ljava/util/Set;)V
    .registers 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/Set<",
            "Ljava/net/URL;",
            ">;)V"
        }
    .end annotation

    .line 1
    invoke-interface {p0}, Ljava/util/Set;->size()I

    move-result v0

    const/4 v1, 0x1

    if-le v0, v1, :cond_8

    goto :goto_9

    :cond_8
    const/4 v1, 0x0

    :goto_9
    if-eqz v1, :cond_4f

    const-string v0, "3414241600750719310D5336181631041A3B045828101F211E08290053063B3E712F53371E16210C1D320456"

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 2
    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/p0/f;->b(Ljava/lang/String;)V

    invoke-interface {p0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object p0

    :goto_18
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_46

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/net/URL;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "3117300B177515112B011A3B10582C0B530E"

    invoke-static {v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v0, "2A"

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/p0/f;->b(Ljava/lang/String;)V

    goto :goto_18

    :cond_46
    const-string p0, "241D20451B2103087F4A5C22000F6B161F3343126B0A0132581B2A011626591031081F761A0D29111A251B1D1A071A3B13112B02007511173745123B571D3D151F341919310C1C3B59"

    invoke-static {p0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    invoke-static {p0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/p0/f;->b(Ljava/lang/String;)V

    :cond_4f
    return-void
.end method

.method private static final j()V
    .registers 6

    :try_start_0
    sget-object v0, Lorg/slf4j/impl/StaticLoggerBinder;->REQUESTED_API_VERSION:Ljava/lang/String;

    sget-object v1, Lcom/github/catvod/spider/xbpqxyq/xbpq/n0/c;->e:[Ljava/lang/String;

    array-length v2, v1

    const/4 v3, 0x0

    const/4 v4, 0x0

    :goto_7
    if-ge v3, v2, :cond_15

    aget-object v5, v1, v3

    invoke-virtual {v0, v5}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v5

    if-eqz v5, :cond_12

    const/4 v4, 0x1

    :cond_12
    add-int/lit8 v3, v3, 0x1

    goto :goto_7

    :cond_15
    if-nez v4, :cond_59

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "231020450130060D201607301358330001261E172B45"

    invoke-static {v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v0, "571A3C450A3A020A65161F33431265071A3B13112B02533C04582B0A07751417281512211E1A290053221E0C2D45"

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    sget-object v0, Lcom/github/catvod/spider/xbpqxyq/xbpq/n0/c;->e:[Ljava/lang/String;

    invoke-static {v0}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/p0/f;->b(Ljava/lang/String;)V

    const-string v0, "241D20451B2103087F4A5C22000F6B161F3343126B0A0132581B2A011626591031081F76011D37161A3A1927280C0038160C260D5333180A65030627031020175331120C240C1F2659"

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/p0/f;->b(Ljava/lang/String;)V
    :try_end_4e
    .catch Ljava/lang/NoSuchFieldError; {:try_start_0 .. :try_end_4e} :catch_59
    .catchall {:try_start_0 .. :try_end_4e} :catchall_4f

    goto :goto_59

    :catchall_4f
    move-exception v0

    const-string v1, "2216201D0330140C20015325051727091638571726060627121C650106271E1622450530050B2C0A1D7504192B0C072C571B2D00103E"

    invoke-static {v1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-static {v1, v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/p0/f;->c(Ljava/lang/String;Ljava/lang/Throwable;)V

    :catch_59
    :cond_59
    :goto_59
    return-void
.end method
