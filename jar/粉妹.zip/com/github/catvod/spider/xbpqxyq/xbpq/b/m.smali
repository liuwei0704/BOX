.class public final synthetic Lcom/github/catvod/spider/xbpqxyq/xbpq/b/m;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic c:Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;


# direct methods
.method public synthetic constructor <init>(Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;)V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/m;->c:Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 2

    iget-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/m;->c:Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;->f(Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;)V

    return-void
.end method
