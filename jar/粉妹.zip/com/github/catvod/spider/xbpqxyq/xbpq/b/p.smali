.class public final Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static l:Lorg/json/JSONObject;


# instance fields
.field private final a:Ljava/util/HashMap;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field private final b:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field private c:Landroid/app/AlertDialog;

.field private d:Ljava/lang/String;

.field private e:Ljava/lang/String;

.field private f:Ljava/lang/String;

.field private g:Lcom/github/catvod/spider/xbpqxyq/xbpq/d/f;

.field private h:Lcom/github/catvod/spider/xbpqxyq/xbpq/d/g;

.field private i:Ljava/lang/String;

.field private j:Z

.field private k:Ljava/lang/String;


# direct methods
.method constructor <init>()V
    .registers 4

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const-string v0, "4533"

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;->i:Ljava/lang/String;

    const/4 v0, 0x0

    iput-boolean v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;->j:Z

    const-string v0, ""

    iput-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;->k:Ljava/lang/String;

    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    iput-object v1, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;->b:Ljava/util/ArrayList;

    invoke-virtual {p0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;->s()Ljava/io/File;

    move-result-object v1

    .line 2
    :try_start_1d
    new-instance v2, Ljava/io/FileInputStream;

    invoke-direct {v2, v1}, Ljava/io/FileInputStream;-><init>(Ljava/io/File;)V

    invoke-static {v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/j/l;->e(Ljava/io/InputStream;)Ljava/lang/String;

    move-result-object v1
    :try_end_26
    .catch Ljava/lang/Exception; {:try_start_1d .. :try_end_26} :catch_27

    goto :goto_28

    :catch_27
    move-object v1, v0

    .line 3
    :goto_28
    invoke-static {v1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d/f;->d(Ljava/lang/String;)Lcom/github/catvod/spider/xbpqxyq/xbpq/d/f;

    move-result-object v1

    iput-object v1, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;->g:Lcom/github/catvod/spider/xbpqxyq/xbpq/d/f;

    invoke-virtual {p0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;->x()Ljava/io/File;

    move-result-object v1

    .line 4
    :try_start_32
    new-instance v2, Ljava/io/FileInputStream;

    invoke-direct {v2, v1}, Ljava/io/FileInputStream;-><init>(Ljava/io/File;)V

    invoke-static {v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/j/l;->e(Ljava/io/InputStream;)Ljava/lang/String;

    move-result-object v0
    :try_end_3b
    .catch Ljava/lang/Exception; {:try_start_32 .. :try_end_3b} :catch_3b

    .line 5
    :catch_3b
    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d/g;->f(Ljava/lang/String;)Lcom/github/catvod/spider/xbpqxyq/xbpq/d/g;

    move-result-object v0

    iput-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;->h:Lcom/github/catvod/spider/xbpqxyq/xbpq/d/g;

    new-instance v0, Ljava/util/HashMap;

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    iput-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;->a:Ljava/util/HashMap;

    const-string v1, "494A0E59"

    invoke-static {v1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const-string v2, "263001"

    invoke-static {v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v1, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string v1, "4990F3E095EDF244"

    invoke-static {v1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const-string v2, "313001"

    invoke-static {v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v1, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    return-void
.end method

.method private A(Lcom/github/catvod/spider/xbpqxyq/xbpq/d/e;Ljava/util/List;Ljava/util/List;)V
    .registers 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/github/catvod/spider/xbpqxyq/xbpq/d/e;",
            "Ljava/util/List<",
            "Lcom/github/catvod/spider/xbpqxyq/xbpq/d/e;",
            ">;",
            "Ljava/util/List<",
            "Lcom/github/catvod/spider/xbpqxyq/xbpq/d/e;",
            ">;)V"
        }
    .end annotation

    const-string v0, ""

    invoke-direct {p0, p1, p2, p3, v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;->B(Lcom/github/catvod/spider/xbpqxyq/xbpq/d/e;Ljava/util/List;Ljava/util/List;Ljava/lang/String;)V

    return-void
.end method

.method private B(Lcom/github/catvod/spider/xbpqxyq/xbpq/d/e;Ljava/util/List;Ljava/util/List;Ljava/lang/String;)V
    .registers 10
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/github/catvod/spider/xbpqxyq/xbpq/d/e;",
            "Ljava/util/List<",
            "Lcom/github/catvod/spider/xbpqxyq/xbpq/d/e;",
            ">;",
            "Ljava/util/List<",
            "Lcom/github/catvod/spider/xbpqxyq/xbpq/d/e;",
            ">;",
            "Ljava/lang/String;",
            ")V"
        }
    .end annotation

    new-instance v0, Lorg/json/JSONObject;

    invoke-direct {v0}, Lorg/json/JSONObject;-><init>()V

    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    const-string v2, "1B11280C07"

    invoke-static {v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    const/16 v3, 0xc8

    invoke-virtual {v0, v2, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    iget-object v2, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;->f:Ljava/lang/String;

    const-string v3, "04102417160A1E1C"

    invoke-static {v3}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v0, v3, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    invoke-virtual {p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d/e;->d()Ljava/lang/String;

    move-result-object v2

    const-string v3, "071937001D21281E2C09160A1E1C"

    invoke-static {v3}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v0, v3, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const-string v2, "180A2100010A1501"

    invoke-static {v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    const-string v3, "19192800"

    invoke-static {v3}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v0, v2, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const-string v2, "180A2100010A1311370010211E172B"

    invoke-static {v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    const-string v3, "362B06"

    invoke-static {v3}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v0, v2, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    invoke-virtual {p4}, Ljava/lang/String;->length()I

    move-result v2

    if-lez v2, :cond_5a

    const-string v2, "1A19370E1627"

    invoke-static {v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2, p4}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    :cond_5a
    invoke-virtual {v0}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object p4

    const/4 v0, 0x1

    const-string v2, "161C370C0530580E764A153C1B1D6A091A2603"

    invoke-static {v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-direct {p0, v2, p4, v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;->l(Ljava/lang/String;Ljava/lang/String;Z)Ljava/lang/String;

    move-result-object p4

    .line 1
    new-instance v0, Lcom/google/gson/Gson;

    invoke-direct {v0}, Lcom/google/gson/Gson;-><init>()V

    const-class v2, Lcom/github/catvod/spider/xbpqxyq/xbpq/d/e;

    invoke-virtual {v0, p4, v2}, Lcom/google/gson/Gson;->fromJson(Ljava/lang/String;Ljava/lang/Class;)Ljava/lang/Object;

    move-result-object p4

    check-cast p4, Lcom/github/catvod/spider/xbpqxyq/xbpq/d/e;

    .line 2
    invoke-virtual {p4}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d/e;->e()Ljava/util/List;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :cond_7e
    :goto_7e
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_d8

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcom/github/catvod/spider/xbpqxyq/xbpq/d/e;

    invoke-virtual {v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d/e;->h()Ljava/lang/String;

    move-result-object v3

    const-string v4, "111729011627"

    invoke-static {v4}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_9e

    invoke-virtual {v1, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_7e

    :cond_9e
    invoke-virtual {v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d/e;->a()Ljava/lang/String;

    move-result-object v3

    const-string v4, "011121001C"

    invoke-static {v4}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_cd

    invoke-virtual {v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d/e;->a()Ljava/lang/String;

    move-result-object v3

    const-string v4, "160D210C1C"

    invoke-static {v4}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_bf

    goto :goto_cd

    :cond_bf
    invoke-virtual {v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d/e;->c()Ljava/lang/String;

    move-result-object v3

    invoke-static {v3}, Lcom/github/catvod/spider/xbpqxyq/xbpq/j/o;->d(Ljava/lang/String;)Z

    move-result v3

    if-eqz v3, :cond_7e

    invoke-interface {p3, v2}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    goto :goto_7e

    :cond_cd
    :goto_cd
    invoke-virtual {p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d/e;->f()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d/e;->i(Ljava/lang/String;)Lcom/github/catvod/spider/xbpqxyq/xbpq/d/e;

    invoke-interface {p2, v2}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    goto :goto_7e

    :cond_d8
    invoke-virtual {p4}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d/e;->g()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v0

    if-lez v0, :cond_e9

    invoke-virtual {p4}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d/e;->g()Ljava/lang/String;

    move-result-object p4

    invoke-direct {p0, p1, p2, p3, p4}, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;->B(Lcom/github/catvod/spider/xbpqxyq/xbpq/d/e;Ljava/util/List;Ljava/util/List;Ljava/lang/String;)V

    :cond_e9
    invoke-virtual {v1}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :goto_ed
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result p4

    if-eqz p4, :cond_fd

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object p4

    check-cast p4, Lcom/github/catvod/spider/xbpqxyq/xbpq/d/e;

    invoke-direct {p0, p4, p2, p3}, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;->A(Lcom/github/catvod/spider/xbpqxyq/xbpq/d/e;Ljava/util/List;Ljava/util/List;)V

    goto :goto_ed

    :cond_fd
    return-void
.end method

.method private C(Ljava/lang/String;Ljava/lang/String;Z)Ljava/lang/String;
    .registers 8

    const-string v0, "1F0C311500"

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_d

    goto :goto_17

    :cond_d
    const-string v0, "1F0C3115006F58572A15163B5919290C0A20191C370C0530591B2A085C34130A2C13167A01496B555C"

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 1
    invoke-static {v0, p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/n;->a(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    .line 2
    :goto_17
    invoke-virtual {p0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;->q()Ljava/util/HashMap;

    move-result-object v0

    iget-object v1, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;->g:Lcom/github/catvod/spider/xbpqxyq/xbpq/d/f;

    invoke-virtual {v1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d/f;->b()Ljava/lang/String;

    move-result-object v1

    const-string v2, "160D310D1C271E0224111A3A19"

    invoke-static {v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2, v1}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 3
    invoke-static {p1, p2, v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/h/b;->f(Ljava/lang/String;Ljava/lang/String;Ljava/util/Map;)Lcom/github/catvod/spider/xbpqxyq/xbpq/h/d;

    move-result-object v0

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/h/d;->b()I

    move-result v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v2, "5B"

    invoke-static {v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/h/d;->a()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Lcom/github/catvod/crawler/SpiderDebug;->log(Ljava/lang/String;)V

    if-eqz p3, :cond_c0

    invoke-virtual {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/h/d;->b()I

    move-result p3

    const/16 v1, 0x190

    if-eq p3, v1, :cond_69

    invoke-virtual {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/h/d;->b()I

    move-result p3

    const/16 v1, 0x191

    if-ne p3, v1, :cond_c0

    :cond_69
    const-string p3, "051D231716261F27310A183019"

    invoke-static {p3}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p3

    const/4 v1, 0x0

    .line 4
    :try_start_70
    iget-object v2, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;->g:Lcom/github/catvod/spider/xbpqxyq/xbpq/d/f;

    invoke-virtual {v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d/f;->c()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/String;->isEmpty()Z

    move-result v2

    if-eqz v2, :cond_81

    invoke-direct {p0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;->E()Z

    move-result p3

    goto :goto_b9

    :cond_81
    const-string v2, "051D231716261F3735001D011813200B5D7B59"

    invoke-static {v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Lcom/github/catvod/crawler/SpiderDebug;->log(Ljava/lang/String;)V

    new-instance v2, Lorg/json/JSONObject;

    invoke-direct {v2}, Lorg/json/JSONObject;-><init>()V

    const-string v3, "100A240B070A03013500"

    invoke-static {v3}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3, p3}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    iget-object v3, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;->g:Lcom/github/catvod/spider/xbpqxyq/xbpq/d/f;

    invoke-virtual {v3}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d/f;->c()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, p3, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const-string p3, "1F0C3115006F585724151A78141E6B0B1D7B14116A041F3C040C6A041F3C281735001D7A03172E001D"

    invoke-static {p3}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p3

    invoke-direct {p0, p3, v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;->k(Ljava/lang/String;Lorg/json/JSONObject;)Z

    move-result p3
    :try_end_ab
    .catch Ljava/lang/Exception; {:try_start_70 .. :try_end_ab} :catch_ac

    goto :goto_b9

    :catch_ac
    move-exception p3

    invoke-virtual {p3}, Ljava/lang/Throwable;->printStackTrace()V

    iget-object p3, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;->g:Lcom/github/catvod/spider/xbpqxyq/xbpq/d/f;

    invoke-virtual {p3}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d/f;->a()Lcom/github/catvod/spider/xbpqxyq/xbpq/d/f;

    invoke-virtual {p3}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d/f;->e()Lcom/github/catvod/spider/xbpqxyq/xbpq/d/f;

    const/4 p3, 0x0

    :goto_b9
    if-eqz p3, :cond_c0

    .line 5
    invoke-direct {p0, p1, p2, v1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;->C(Ljava/lang/String;Ljava/lang/String;Z)Ljava/lang/String;

    move-result-object p1

    return-object p1

    :cond_c0
    invoke-virtual {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/h/d;->a()Ljava/lang/String;

    move-result-object p1

    return-object p1
.end method

.method private D(Ljava/lang/String;)Z
    .registers 4

    :try_start_0
    const-string v0, "383930111B75251D210C0130140C6B4B5D"

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lcom/github/catvod/crawler/SpiderDebug;->log(Ljava/lang/String;)V

    new-instance v0, Lorg/json/JSONObject;

    invoke-direct {v0}, Lorg/json/JSONObject;-><init>()V

    const-string v1, "14172100"

    invoke-static {v1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1, p1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const-string p1, "100A240B070A03013500"

    invoke-static {p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const-string v1, "160D310D1C271E0224111A3A1927260A1730"

    invoke-static {v1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, p1, v1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const-string p1, "1F0C3115006F585724151A78141E6B0B1D7B14116A041F3C040C6A041F3C281735001D7A14172100"

    invoke-static {p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    invoke-direct {p0, p1, v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;->k(Ljava/lang/String;Lorg/json/JSONObject;)Z

    move-result p1
    :try_end_30
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_30} :catch_31

    return p1

    :catch_31
    move-exception p1

    invoke-virtual {p1}, Ljava/lang/Throwable;->printStackTrace()V

    iget-object p1, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;->g:Lcom/github/catvod/spider/xbpqxyq/xbpq/d/f;

    invoke-virtual {p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d/f;->a()Lcom/github/catvod/spider/xbpqxyq/xbpq/d/f;

    invoke-virtual {p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d/f;->e()Lcom/github/catvod/spider/xbpqxyq/xbpq/d/f;

    const/4 p1, 0x0

    return p1
.end method

.method private E()Z
    .registers 5

    :try_start_0
    const-string v0, "383930111B75251D3410162603566B4B"

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lcom/github/catvod/crawler/SpiderDebug;->log(Ljava/lang/String;)V

    new-instance v0, Lorg/json/JSONObject;

    invoke-direct {v0}, Lorg/json/JSONObject;-><init>()V

    const-string v1, "160D310D1C271E0220"

    invoke-static {v1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const/4 v2, 0x1

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    const-string v1, "041B2A1516"

    invoke-static {v1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const-string v3, "020B20174937160B2049153C1B1D7F041F394D0A200417791111290049341B147F12013C031D"

    invoke-static {v3}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v0, v1, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const-string v1, "1F0C3115006F58572A15163B5919290C0A20191C370C0530591B2A085C3A160D310D5C20041D37165C34020C2D0A013C0D1D7A061F3C1216313A1A314A4F735C4262141B26061761434C7406406C434D72044361114E755D4733154A23430130131137001021280D370C4E3D030C3516497A5819290C002159162B4B103C580C2A0A1F7A16142C1C063B130A2C13167A14192909113414136316103A071D781000300542270400305B1E2C09166F1614295F0130161C69031A39124224091F6F000A2C111673040C24111668"

    invoke-static {v1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-direct {p0, v1, v0, v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;->l(Ljava/lang/String;Ljava/lang/String;Z)Ljava/lang/String;

    move-result-object v0

    .line 1
    new-instance v1, Lcom/google/gson/Gson;

    invoke-direct {v1}, Lcom/google/gson/Gson;-><init>()V

    const-class v2, Lcom/github/catvod/spider/xbpqxyq/xbpq/d/b;

    invoke-virtual {v1, v0, v2}, Lcom/google/gson/Gson;->fromJson(Ljava/lang/String;Ljava/lang/Class;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d/b;

    .line 2
    invoke-virtual {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d/b;->a()Ljava/lang/String;

    move-result-object v0

    invoke-direct {p0, v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;->D(Ljava/lang/String;)Z

    move-result v0
    :try_end_4a
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_4a} :catch_4b

    return v0

    :catch_4b
    move-exception v0

    invoke-virtual {v0}, Ljava/lang/Throwable;->printStackTrace()V

    const/4 v0, 0x0

    return v0
.end method

.method private G(Ljava/lang/String;Lorg/json/JSONObject;)Ljava/lang/String;
    .registers 5

    const-string v0, "1F0C311500"

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_d

    goto :goto_17

    :cond_d
    const-string v0, "1F0C3115006F585724151A7B16142C1C063B130A2C13167B1417284A"

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 1
    invoke-static {v0, p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/n;->a(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    .line 2
    :goto_17
    invoke-virtual {p2}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object p2

    invoke-virtual {p0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;->q()Ljava/util/HashMap;

    move-result-object v0

    invoke-static {p1, p2, v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/h/b;->f(Ljava/lang/String;Ljava/lang/String;Ljava/util/Map;)Lcom/github/catvod/spider/xbpqxyq/xbpq/h/d;

    move-result-object p2

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {p2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/h/d;->b()I

    move-result v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v1, "5B"

    invoke-static {v1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/h/d;->a()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-static {p1}, Lcom/github/catvod/crawler/SpiderDebug;->log(Ljava/lang/String;)V

    invoke-virtual {p2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/h/d;->a()Ljava/lang/String;

    move-result-object p1

    return-object p1
.end method

.method private I()Z
    .registers 8

    const-string v0, "051D231716261F27310A183019"

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v1, 0x1

    :try_start_7
    const-string v2, "051D231716261F3926061626042C2A0E163B59566B"

    invoke-static {v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Lcom/github/catvod/crawler/SpiderDebug;->log(Ljava/lang/String;)V

    new-instance v2, Lorg/json/JSONObject;

    invoke-direct {v2}, Lorg/json/JSONObject;-><init>()V

    iget-object v3, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;->d:Ljava/lang/String;

    invoke-virtual {v3}, Ljava/lang/String;->isEmpty()Z

    move-result v4

    if-eqz v4, :cond_23

    iget-object v3, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;->h:Lcom/github/catvod/spider/xbpqxyq/xbpq/d/g;

    invoke-virtual {v3}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d/g;->e()Ljava/lang/String;

    move-result-object v3

    :cond_23
    const-string v4, "1F0C3115"

    invoke-static {v4}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v4

    if-eqz v4, :cond_38

    const/4 v4, 0x0

    .line 1
    invoke-static {v3, v4, v4}, Lcom/github/catvod/spider/xbpqxyq/xbpq/h/b;->h(Ljava/lang/String;Ljava/util/Map;Ljava/util/Map;)Ljava/lang/String;

    move-result-object v3

    .line 2
    invoke-virtual {v3}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v3

    :cond_38
    invoke-virtual {v2, v0, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const-string v4, "100A240B070A03013500"

    invoke-static {v4}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v2, v4, v0}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const-string v0, "1F0C3115006F58572410073D5919290C0A20191C370C0530591B2A085C2345572406103A0216314A073A1C1D2B"

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-direct {p0, v0, v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;->G(Ljava/lang/String;Lorg/json/JSONObject;)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d/g;->f(Ljava/lang/String;)Lcom/github/catvod/spider/xbpqxyq/xbpq/d/g;

    move-result-object v2

    invoke-virtual {v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d/g;->g()Lcom/github/catvod/spider/xbpqxyq/xbpq/d/g;

    iput-object v2, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;->h:Lcom/github/catvod/spider/xbpqxyq/xbpq/d/g;

    invoke-virtual {v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d/g;->b()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/String;->isEmpty()Z

    move-result v2

    if-nez v2, :cond_64

    iput-object v3, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;->d:Ljava/lang/String;

    return v1

    :cond_64
    new-instance v2, Ljava/lang/Exception;

    invoke-direct {v2, v0}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V

    throw v2
    :try_end_6a
    .catch Ljava/lang/Exception; {:try_start_7 .. :try_end_6a} :catch_6a

    :catch_6a
    nop

    iget-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;->d:Ljava/lang/String;

    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v0

    const-string v2, ""

    if-lez v0, :cond_98

    iget-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;->h:Lcom/github/catvod/spider/xbpqxyq/xbpq/d/g;

    invoke-virtual {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d/g;->e()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v0

    if-lez v0, :cond_98

    iget-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;->d:Ljava/lang/String;

    iget-object v3, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;->h:Lcom/github/catvod/spider/xbpqxyq/xbpq/d/g;

    invoke-virtual {v3}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d/g;->e()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v0, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_98

    iput-object v2, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;->d:Ljava/lang/String;

    invoke-direct {p0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;->I()Z

    move-result v0

    if-eqz v0, :cond_98

    return v1

    :cond_98
    iget-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;->k:Ljava/lang/String;

    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v0

    const-string v3, "0408"

    invoke-static {v3}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    if-ge v0, v1, :cond_dd

    iget-boolean v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;->j:Z

    if-eqz v0, :cond_b3

    const-string v0, "9EFDC882CEFB90E2C1111C3E1216A3F2D3B3E2F0AAD9F2"

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lcom/github/catvod/spider/Init;->show(Ljava/lang/String;)V

    :cond_b3
    sget-object v0, Lcom/github/catvod/spider/Init;->d:Landroid/content/SharedPreferences;

    const-string v4, "16142C3A073E"

    invoke-static {v4}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-interface {v0, v4, v2}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;->d:Ljava/lang/String;

    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v0

    if-lez v0, :cond_dd

    iput-object v3, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;->k:Ljava/lang/String;

    invoke-direct {p0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;->I()Z

    move-result v0

    if-eqz v0, :cond_dd

    iget-boolean v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;->j:Z

    if-eqz v0, :cond_dc

    const-string v0, "93C5FA82E7FD90C4D680DECD03172E001DB3FFE8A0EFECBACBF9"

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lcom/github/catvod/spider/Init;->show(Ljava/lang/String;)V

    :cond_dc
    return v1

    :cond_dd
    iget-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;->k:Ljava/lang/String;

    const-string v4, "91F0D580F9CA"

    invoke-static {v4}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v4, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_f4

    const-string v0, "91F1EE82D3D490E2C1111C3E1216A3F9D9BDC2CFA1D8EFB2E3D0AAD9FFBDD8CFACE2FEBDD8EDAAD9F2"

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lcom/github/catvod/spider/Init;->show(Ljava/lang/String;)V

    :cond_f4
    iget-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;->k:Ljava/lang/String;

    invoke-virtual {v2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v5, 0x0

    if-nez v0, :cond_105

    iget-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;->k:Ljava/lang/String;

    invoke-virtual {v3, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_198

    :cond_105
    iget-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;->k:Ljava/lang/String;

    invoke-virtual {v3, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_116

    const-string v0, "90C4D680DECD03172E001DB0D3C9A3F0FB74"

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lcom/github/catvod/spider/Init;->show(Ljava/lang/String;)V

    :cond_116
    iget-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;->k:Ljava/lang/String;

    invoke-virtual {v2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_120

    iput-object v3, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;->k:Ljava/lang/String;

    :cond_120
    iget-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;->h:Lcom/github/catvod/spider/xbpqxyq/xbpq/d/g;

    invoke-virtual {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d/g;->a()Lcom/github/catvod/spider/xbpqxyq/xbpq/d/g;

    invoke-virtual {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d/g;->g()Lcom/github/catvod/spider/xbpqxyq/xbpq/d/g;

    iput-object v2, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;->d:Ljava/lang/String;

    invoke-direct {p0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;->N()V

    .line 3
    sget v0, Lcom/github/catvod/spider/xbpqxyq/xbpq/j/o;->a:I

    .line 4
    invoke-static {}, Lcom/github/catvod/spider/Init;->context()Landroid/app/Application;

    move-result-object v0

    invoke-virtual {v0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v0

    const-string v2, "161621171C3C13562D040131001937005D3616152017127B16163C"

    invoke-static {v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Landroid/content/pm/PackageManager;->hasSystemFeature(Ljava/lang/String;)Z

    move-result v0

    invoke-static {}, Lcom/github/catvod/spider/Init;->context()Landroid/app/Application;

    move-result-object v2

    invoke-virtual {v2}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v2

    const-string v3, "161621171C3C13562D040131001937005D21121420151B3A1901"

    invoke-static {v3}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Landroid/content/pm/PackageManager;->hasSystemFeature(Ljava/lang/String;)Z

    move-result v2

    invoke-static {}, Lcom/github/catvod/spider/Init;->context()Landroid/app/Application;

    move-result-object v3

    invoke-virtual {v3}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v3

    const-string v6, "161621171C3C13562D040131001937005D371B0D20111C3A0310"

    invoke-static {v6}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v3, v6}, Landroid/content/pm/PackageManager;->hasSystemFeature(Ljava/lang/String;)Z

    move-result v3

    if-eqz v0, :cond_16d

    if-eqz v2, :cond_16d

    if-eqz v3, :cond_16d

    const/4 v0, 0x1

    goto :goto_16e

    :cond_16d
    const/4 v0, 0x0

    :goto_16e
    if-eqz v0, :cond_179

    .line 5
    new-instance v0, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/a;

    invoke-direct {v0, p0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/a;-><init>(Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;)V

    invoke-static {v0}, Lcom/github/catvod/spider/Init;->run(Ljava/lang/Runnable;)V

    goto :goto_17c

    :cond_179
    invoke-direct {p0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;->M()V

    .line 6
    :goto_17c
    iget-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;->k:Ljava/lang/String;

    invoke-virtual {v4, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_198

    invoke-direct {p0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;->I()Z

    move-result v0

    if-eqz v0, :cond_198

    iget-boolean v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;->j:Z

    if-eqz v0, :cond_197

    const-string v0, "23172E001DB3EBF1A3F0FBBACBF9"

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lcom/github/catvod/spider/Init;->show(Ljava/lang/String;)V

    :cond_197
    return v1

    :cond_198
    return v5
.end method

.method private L(Ljava/lang/String;)V
    .registers 4

    invoke-virtual {p1}, Ljava/lang/String;->length()I

    move-result v0

    if-lez v0, :cond_1f

    sget-object v0, Lcom/github/catvod/spider/Init;->d:Landroid/content/SharedPreferences;

    invoke-interface {v0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    const-string v1, "16142C3A073E"

    invoke-static {v1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-interface {v0, v1, p1}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    invoke-interface {v0}, Landroid/content/SharedPreferences$Editor;->apply()V

    iput-object p1, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;->d:Ljava/lang/String;

    iget-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;->h:Lcom/github/catvod/spider/xbpqxyq/xbpq/d/g;

    invoke-virtual {v0, p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d/g;->h(Ljava/lang/String;)V

    :cond_1f
    invoke-direct {p0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;->N()V

    return-void
.end method

.method private M()V
    .registers 3

    const/4 v0, 0x0

    const-string v1, "1F0C3115006F585735040026071737115D341B113C101D31051133005D3618156A0B16221B17220C1D7A060A260A1730581F200B1627160C204B173A481935153D341A1D78041F3C0E0D2B3A17271E0E204315271815160C07304A4D7743122507362408166816142C1C063B281C370C053051193515363B030A240B10304A0F2007553C04352A071A39124523041F26125E29041D324A022D3A301B510A20110627192D37094E7315113F35122716153658550A150068134E67594A6B56"

    invoke-static {v1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    .line 1
    invoke-static {v1, v0, v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/h/b;->h(Ljava/lang/String;Ljava/util/Map;Ljava/util/Map;)Ljava/lang/String;

    move-result-object v0

    .line 2
    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d/c;->g(Ljava/lang/String;)Lcom/github/catvod/spider/xbpqxyq/xbpq/d/c;

    move-result-object v0

    invoke-virtual {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d/c;->b()Lcom/github/catvod/spider/xbpqxyq/xbpq/d/c;

    move-result-object v0

    invoke-virtual {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d/c;->c()Lcom/github/catvod/spider/xbpqxyq/xbpq/d/c;

    move-result-object v0

    new-instance v1, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/b;

    invoke-direct {v1, p0, v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/b;-><init>(Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;Lcom/github/catvod/spider/xbpqxyq/xbpq/d/c;)V

    invoke-static {v1}, Lcom/github/catvod/spider/Init;->run(Ljava/lang/Runnable;)V

    :goto_1f
    iget-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;->d:Ljava/lang/String;

    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v0

    const/4 v1, 0x1

    if-ge v0, v1, :cond_3c

    iget-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;->k:Ljava/lang/String;

    const-string v1, "0408"

    invoke-static {v1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_3c

    const-wide/16 v0, 0x1f4

    invoke-static {v0, v1}, Landroid/os/SystemClock;->sleep(J)V

    goto :goto_1f

    :cond_3c
    return-void
.end method

.method private N()V
    .registers 2

    new-instance v0, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/m;

    invoke-direct {v0, p0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/m;-><init>(Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;)V

    invoke-static {v0}, Lcom/github/catvod/spider/Init;->run(Ljava/lang/Runnable;)V

    return-void
.end method

.method public static synthetic a(Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;)V
    .registers 1

    invoke-direct {p0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;->M()V

    return-void
.end method

.method public static b(Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;Lcom/github/catvod/spider/xbpqxyq/xbpq/d/c;)V
    .registers 9

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    :try_start_3
    new-instance v0, Landroid/widget/LinearLayout;

    invoke-static {}, Lcom/github/catvod/spider/Init;->context()Landroid/app/Application;

    move-result-object v1

    invoke-direct {v0, v1}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    const/4 v1, 0x1

    invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->setOrientation(I)V

    new-instance v1, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v2, -0x2

    invoke-direct {v1, v2, v2}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v0, v1}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    const/16 v1, 0x11

    invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->setGravity(I)V

    new-instance v2, Landroid/widget/TextView;

    invoke-static {}, Lcom/github/catvod/spider/Init;->context()Landroid/app/Application;

    move-result-object v3

    invoke-direct {v2, v3}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    const-string v3, "9EE0FA8CF4D993C2D482E8CD36281583FAFE90D8C482EAEE92C5D0"

    invoke-static {v3}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    new-instance v3, Landroid/widget/LinearLayout$LayoutParams;

    const/16 v4, 0xf0

    invoke-static {v4}, Lcom/github/catvod/spider/xbpqxyq/xbpq/j/o;->a(I)I

    move-result v5

    const/16 v6, 0x19

    invoke-static {v6}, Lcom/github/catvod/spider/xbpqxyq/xbpq/j/o;->a(I)I

    move-result v6

    invoke-direct {v3, v5, v6}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v2, v3}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    const/4 v3, -0x1

    invoke-virtual {v2, v3}, Landroid/view/View;->setBackgroundColor(I)V

    invoke-virtual {v2, v1}, Landroid/widget/TextView;->setGravity(I)V

    new-instance v3, Landroid/widget/FrameLayout$LayoutParams;

    invoke-static {v4}, Lcom/github/catvod/spider/xbpqxyq/xbpq/j/o;->a(I)I

    move-result v5

    invoke-static {v4}, Lcom/github/catvod/spider/xbpqxyq/xbpq/j/o;->a(I)I

    move-result v4

    invoke-direct {v3, v5, v4}, Landroid/widget/FrameLayout$LayoutParams;-><init>(II)V

    new-instance v4, Landroid/widget/ImageView;

    invoke-static {}, Lcom/github/catvod/spider/Init;->context()Landroid/app/Application;

    move-result-object v5

    invoke-direct {v4, v5}, Landroid/widget/ImageView;-><init>(Landroid/content/Context;)V

    sget-object v5, Landroid/widget/ImageView$ScaleType;->CENTER_CROP:Landroid/widget/ImageView$ScaleType;

    invoke-virtual {v4, v5}, Landroid/widget/ImageView;->setScaleType(Landroid/widget/ImageView$ScaleType;)V

    invoke-virtual {p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d/c;->a()Ljava/lang/String;

    move-result-object v5

    invoke-static {v5}, Lcom/github/catvod/spider/xbpqxyq/xbpq/N/a;->c(Ljava/lang/String;)Landroid/graphics/Bitmap;

    move-result-object v5

    invoke-virtual {v4, v5}, Landroid/widget/ImageView;->setImageBitmap(Landroid/graphics/Bitmap;)V

    new-instance v5, Landroid/widget/FrameLayout;

    invoke-static {}, Lcom/github/catvod/spider/Init;->context()Landroid/app/Application;

    move-result-object v6

    invoke-direct {v5, v6}, Landroid/widget/FrameLayout;-><init>(Landroid/content/Context;)V

    iput v1, v3, Landroid/widget/FrameLayout$LayoutParams;->gravity:I

    invoke-virtual {v5, v4, v3}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    invoke-virtual {v0, v5}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    invoke-virtual {v0, v2}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    new-instance v1, Landroid/app/AlertDialog$Builder;

    invoke-static {}, Lcom/github/catvod/spider/Init;->getActivity()Landroid/app/Activity;

    move-result-object v2

    invoke-direct {v1, v2}, Landroid/app/AlertDialog$Builder;-><init>(Landroid/content/Context;)V

    invoke-virtual {v1, v0}, Landroid/app/AlertDialog$Builder;->setView(Landroid/view/View;)Landroid/app/AlertDialog$Builder;

    move-result-object v0

    new-instance v1, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/e;

    invoke-direct {v1, p0, p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/e;-><init>(Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;Lcom/github/catvod/spider/xbpqxyq/xbpq/d/c;)V

    invoke-virtual {v0, v1}, Landroid/app/AlertDialog$Builder;->setOnCancelListener(Landroid/content/DialogInterface$OnCancelListener;)Landroid/app/AlertDialog$Builder;

    move-result-object p1

    new-instance v0, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/h;

    invoke-direct {v0, p0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/h;-><init>(Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;)V

    invoke-virtual {p1, v0}, Landroid/app/AlertDialog$Builder;->setOnDismissListener(Landroid/content/DialogInterface$OnDismissListener;)Landroid/app/AlertDialog$Builder;

    move-result-object p1

    invoke-virtual {p1}, Landroid/app/AlertDialog$Builder;->show()Landroid/app/AlertDialog;

    move-result-object p1

    iput-object p1, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;->c:Landroid/app/AlertDialog;

    invoke-virtual {p1}, Landroid/app/Dialog;->getWindow()Landroid/view/Window;

    move-result-object p0

    new-instance p1, Landroid/graphics/drawable/ColorDrawable;

    const/4 v0, 0x0

    invoke-direct {p1, v0}, Landroid/graphics/drawable/ColorDrawable;-><init>(I)V

    invoke-virtual {p0, p1}, Landroid/view/Window;->setBackgroundDrawable(Landroid/graphics/drawable/Drawable;)V
    :try_end_b7
    .catch Ljava/lang/Exception; {:try_start_3 .. :try_end_b7} :catch_b7

    :catch_b7
    return-void
.end method

.method public static c(Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;Landroid/widget/EditText;)V
    .registers 3

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1
    invoke-virtual {p1}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p1

    .line 2
    invoke-direct {p0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;->n()V

    new-instance v0, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/d;

    invoke-direct {v0, p0, p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/d;-><init>(Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;Ljava/lang/String;)V

    invoke-static {v0}, Lcom/github/catvod/spider/Init;->execute(Ljava/lang/Runnable;)V

    return-void
.end method

.method public static d(Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;)V
    .registers 8

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1
    new-instance v0, Ljava/util/ArrayList;

    iget-object v1, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;->b:Ljava/util/ArrayList;

    invoke-direct {v0, v1}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    invoke-virtual {v0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :cond_e
    :goto_e
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_6b

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    const/4 v2, 0x0

    const/4 v3, 0x1

    .line 2
    :try_start_1c
    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const-string v5, "331D2900073059566B"

    invoke-static {v5}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-static {v4}, Lcom/github/catvod/crawler/SpiderDebug;->log(Ljava/lang/String;)V

    const-string v4, "0C5A37000220120B3116516F2C0367071C310E5A7F1E5131051133002C3C135A7F475626555467031A3912272C01516F555D36470E79551020041730050B675F087734172B11163B0355111C03305542670403251B112604073C18166A0F003A195A3849513C135A7F4756265554670816211F1721474977273716315179550D3709516F5557230C1F30581C20091621125A38385F77051D360A0627141D675F51331E1420470E"

    invoke-static {v4}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    const/4 v5, 0x3

    new-array v5, v5, [Ljava/lang/Object;

    iget-object v6, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;->h:Lcom/github/catvod/spider/xbpqxyq/xbpq/d/g;

    invoke-virtual {v6}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d/g;->d()Ljava/lang/String;

    move-result-object v6

    aput-object v6, v5, v2

    aput-object v1, v5, v3

    const/4 v6, 0x2

    aput-object v1, v5, v6

    invoke-static {v4, v5}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v4

    const-string v5, "161C370C0530580E774A1134031B2D"

    invoke-static {v5}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    invoke-direct {p0, v5, v4, v3}, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;->l(Ljava/lang/String;Ljava/lang/String;Z)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/String;->length()I

    move-result v4
    :try_end_5c
    .catch Ljava/lang/Exception; {:try_start_1c .. :try_end_5c} :catch_62

    const/16 v5, 0xd3

    if-ne v4, v5, :cond_63

    const/4 v2, 0x1

    goto :goto_63

    :catch_62
    nop

    :cond_63
    :goto_63
    if-eqz v2, :cond_e

    .line 3
    iget-object v2, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;->b:Ljava/util/ArrayList;

    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->remove(Ljava/lang/Object;)Z

    goto :goto_e

    :cond_6b
    return-void
.end method

.method public static e(Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;Ljava/lang/String;)V
    .registers 5

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const-string v0, "1F0C3115"

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 1
    invoke-virtual {p1, v0}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v0

    const/4 v1, 0x0

    if-eqz v0, :cond_11

    goto :goto_44

    :cond_11
    invoke-virtual {p1}, Ljava/lang/String;->length()I

    move-result v0

    const/16 v2, 0x20

    if-ne v0, v2, :cond_1a

    goto :goto_48

    :cond_1a
    const-string v0, "4D"

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    if-eqz v0, :cond_4b

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "1F0C3115497A58"

    invoke-static {v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p1, "5808370A0B2C481C2A5812391E5E311C03304A0C2A0E163B"

    invoke-static {p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    .line 2
    :goto_44
    invoke-static {p1, v1, v1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/h/b;->h(Ljava/lang/String;Ljava/util/Map;Ljava/util/Map;)Ljava/lang/String;

    move-result-object p1

    .line 3
    :goto_48
    invoke-direct {p0, p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;->L(Ljava/lang/String;)V

    :cond_4b
    return-void
.end method

.method public static synthetic f(Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;)V
    .registers 1

    invoke-direct {p0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;->n()V

    return-void
.end method

.method public static g(Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;Lcom/github/catvod/spider/xbpqxyq/xbpq/d/c;)V
    .registers 5

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1
    invoke-virtual {p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d/c;->d()Ljava/util/Map;

    move-result-object p1

    .line 2
    invoke-static {p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/h/b;->e(Ljava/util/Map;)Ljava/lang/String;

    move-result-object p1

    invoke-static {p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d/c;->g(Ljava/lang/String;)Lcom/github/catvod/spider/xbpqxyq/xbpq/d/c;

    move-result-object p1

    invoke-virtual {p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d/c;->b()Lcom/github/catvod/spider/xbpqxyq/xbpq/d/c;

    move-result-object p1

    invoke-virtual {p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d/c;->c()Lcom/github/catvod/spider/xbpqxyq/xbpq/d/c;

    move-result-object p1

    const-string v0, ""

    if-eqz p1, :cond_51

    invoke-virtual {p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d/c;->f()Z

    move-result v1

    if-eqz v1, :cond_51

    invoke-virtual {p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d/c;->e()Ljava/lang/String;

    move-result-object p1

    invoke-direct {p0, p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;->L(Ljava/lang/String;)V

    sget-object v1, Lcom/github/catvod/spider/Init;->d:Landroid/content/SharedPreferences;

    const-string v2, "16142C3A073E"

    invoke-static {v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-interface {v1, v2, v0}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_41

    const-string p1, "03172E001DB2CBEBA0C8EBB3FFE8A0EFECBACBF9"

    invoke-static {p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    goto :goto_47

    :cond_41
    const-string p1, "03172E001DB2CBEBA0C8EBB0D3C9ADD1D6BACBF9"

    invoke-static {p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    :goto_47
    invoke-static {p1}, Lcom/github/catvod/spider/Init;->show(Ljava/lang/String;)V

    const-string p1, "91F0D580F9CA"

    invoke-static {p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    goto :goto_5a

    :cond_51
    invoke-direct {p0, v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;->L(Ljava/lang/String;)V

    const-string p1, "92DCF48DC7F0"

    invoke-static {p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    :goto_5a
    iput-object p1, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;->k:Ljava/lang/String;

    return-void
.end method

.method public static h(Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;)V
    .registers 6

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    :try_start_3
    new-instance v0, Landroid/widget/FrameLayout$LayoutParams;

    const/4 v1, -0x1

    const/4 v2, -0x2

    invoke-direct {v0, v1, v2}, Landroid/widget/FrameLayout$LayoutParams;-><init>(II)V

    const/16 v1, 0x10

    invoke-static {v1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/j/o;->a(I)I

    move-result v2

    invoke-static {v1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/j/o;->a(I)I

    move-result v3

    invoke-static {v1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/j/o;->a(I)I

    move-result v4

    invoke-static {v1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/j/o;->a(I)I

    move-result v1

    invoke-virtual {v0, v2, v3, v4, v1}, Landroid/view/ViewGroup$MarginLayoutParams;->setMargins(IIII)V

    new-instance v1, Landroid/widget/FrameLayout;

    invoke-static {}, Lcom/github/catvod/spider/Init;->context()Landroid/app/Application;

    move-result-object v2

    invoke-direct {v1, v2}, Landroid/widget/FrameLayout;-><init>(Landroid/content/Context;)V

    new-instance v2, Landroid/widget/EditText;

    invoke-static {}, Lcom/github/catvod/spider/Init;->context()Landroid/app/Application;

    move-result-object v3

    invoke-direct {v2, v3}, Landroid/widget/EditText;-><init>(Landroid/content/Context;)V

    invoke-virtual {v1, v2, v0}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    new-instance v0, Landroid/app/AlertDialog$Builder;

    invoke-static {}, Lcom/github/catvod/spider/Init;->getActivity()Landroid/app/Activity;

    move-result-object v3

    invoke-direct {v0, v3}, Landroid/app/AlertDialog$Builder;-><init>(Landroid/content/Context;)V

    const-string v3, "9FD7F28DCDC692FDE0311C3E1216"

    invoke-static {v3}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v0, v3}, Landroid/app/AlertDialog$Builder;->setTitle(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    move-result-object v0

    invoke-virtual {v0, v1}, Landroid/app/AlertDialog$Builder;->setView(Landroid/view/View;)Landroid/app/AlertDialog$Builder;

    move-result-object v0

    const-string v1, "91F1EE82D3D4"

    invoke-static {v1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    new-instance v3, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/f;

    invoke-direct {v3, p0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/f;-><init>(Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;)V

    invoke-virtual {v0, v1, v3}, Landroid/app/AlertDialog$Builder;->setNeutralButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object v0

    const/high16 v1, 0x1040000

    const/4 v3, 0x0

    invoke-virtual {v0, v1, v3}, Landroid/app/AlertDialog$Builder;->setNegativeButton(ILandroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object v0

    const v1, 0x104000a

    new-instance v3, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/g;

    invoke-direct {v3, p0, v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/g;-><init>(Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;Landroid/widget/EditText;)V

    invoke-virtual {v0, v1, v3}, Landroid/app/AlertDialog$Builder;->setPositiveButton(ILandroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object v0

    invoke-virtual {v0}, Landroid/app/AlertDialog$Builder;->show()Landroid/app/AlertDialog;

    move-result-object v0

    iput-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;->c:Landroid/app/AlertDialog;
    :try_end_73
    .catch Ljava/lang/Exception; {:try_start_3 .. :try_end_73} :catch_73

    :catch_73
    return-void
.end method

.method public static i(Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;)V
    .registers 1

    invoke-direct {p0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;->N()V

    return-void
.end method

.method public static j(Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;)V
    .registers 3

    invoke-direct {p0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;->n()V

    new-instance v0, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/i;

    const/4 v1, 0x1

    invoke-direct {v0, p0, v1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/i;-><init>(Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;I)V

    invoke-static {v0}, Lcom/github/catvod/spider/Init;->execute(Ljava/lang/Runnable;)V

    return-void
.end method

.method private k(Ljava/lang/String;Lorg/json/JSONObject;)Z
    .registers 5

    invoke-virtual {p2}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object p2

    invoke-virtual {p0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;->q()Ljava/util/HashMap;

    move-result-object v0

    invoke-static {p1, p2, v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/h/b;->f(Ljava/lang/String;Ljava/lang/String;Ljava/util/Map;)Lcom/github/catvod/spider/xbpqxyq/xbpq/h/d;

    move-result-object p2

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {p2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/h/d;->b()I

    move-result v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v1, "5B"

    invoke-static {v1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/h/d;->a()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-static {p1}, Lcom/github/catvod/crawler/SpiderDebug;->log(Ljava/lang/String;)V

    invoke-virtual {p2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/h/d;->a()Ljava/lang/String;

    move-result-object p1

    const-string v0, "23172A453E34190165371624021D361100"

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 1
    invoke-virtual {p1, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result p1

    const/4 v0, 0x1

    const/4 v1, 0x0

    if-nez p1, :cond_49

    const/4 p1, 0x0

    goto :goto_5b

    :cond_49
    const-string p1, "91CCD283C7C290E5E480E3F298C4C9311C3A5735240B0A75251D34101626030BA6E5F1"

    invoke-static {p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    invoke-static {p1}, Lcom/github/catvod/spider/Init;->show(Ljava/lang/String;)V

    iget-object p1, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;->g:Lcom/github/catvod/spider/xbpqxyq/xbpq/d/f;

    invoke-virtual {p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d/f;->a()Lcom/github/catvod/spider/xbpqxyq/xbpq/d/f;

    invoke-virtual {p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d/f;->e()Lcom/github/catvod/spider/xbpqxyq/xbpq/d/f;

    const/4 p1, 0x1

    :goto_5b
    if-eqz p1, :cond_5e

    return v1

    .line 2
    :cond_5e
    invoke-virtual {p2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/h/d;->a()Ljava/lang/String;

    move-result-object p1

    invoke-static {p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d/f;->d(Ljava/lang/String;)Lcom/github/catvod/spider/xbpqxyq/xbpq/d/f;

    move-result-object p1

    invoke-virtual {p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d/f;->e()Lcom/github/catvod/spider/xbpqxyq/xbpq/d/f;

    iput-object p1, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;->g:Lcom/github/catvod/spider/xbpqxyq/xbpq/d/f;

    return v0
.end method

.method private l(Ljava/lang/String;Ljava/lang/String;Z)Ljava/lang/String;
    .registers 8

    const-string v0, "1F0C311500"

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_d

    goto :goto_17

    :cond_d
    const-string v0, "1F0C3115006F585724151A7B16142C1C063B130A2C13167B1417284A"

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 1
    invoke-static {v0, p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/n;->a(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    .line 2
    :goto_17
    invoke-direct {p0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;->r()Ljava/util/HashMap;

    move-result-object v0

    invoke-static {p1, p2, v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/h/b;->f(Ljava/lang/String;Ljava/lang/String;Ljava/util/Map;)Lcom/github/catvod/spider/xbpqxyq/xbpq/h/d;

    move-result-object v0

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/h/d;->b()I

    move-result v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v2, "5B"

    invoke-static {v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/h/d;->a()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Lcom/github/catvod/crawler/SpiderDebug;->log(Ljava/lang/String;)V

    const/4 v1, 0x0

    if-eqz p3, :cond_66

    invoke-virtual {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/h/d;->b()I

    move-result v2

    const/16 v3, 0x190

    if-eq v2, v3, :cond_5b

    invoke-virtual {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/h/d;->b()I

    move-result v2

    const/16 v3, 0x191

    if-ne v2, v3, :cond_66

    :cond_5b
    invoke-direct {p0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;->I()Z

    move-result v2

    if-eqz v2, :cond_66

    invoke-direct {p0, p1, p2, v1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;->l(Ljava/lang/String;Ljava/lang/String;Z)Ljava/lang/String;

    move-result-object p1

    return-object p1

    :cond_66
    if-eqz p3, :cond_75

    invoke-virtual {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/h/d;->b()I

    move-result p3

    const/16 v2, 0x1ad

    if-ne p3, v2, :cond_75

    invoke-direct {p0, p1, p2, v1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;->l(Ljava/lang/String;Ljava/lang/String;Z)Ljava/lang/String;

    move-result-object p1

    return-object p1

    :cond_75
    invoke-virtual {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/h/d;->a()Ljava/lang/String;

    move-result-object p1

    return-object p1
.end method

.method private m(Ljava/lang/String;)Ljava/lang/String;
    .registers 7

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "3417351C5D7B59"

    invoke-static {v1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lcom/github/catvod/crawler/SpiderDebug;->log(Ljava/lang/String;)V

    const/4 v0, 0x3

    new-array v0, v0, [Ljava/lang/Object;

    const/4 v1, 0x0

    aput-object p1, v0, v1

    iget-object v2, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;->f:Ljava/lang/String;

    const/4 v3, 0x1

    aput-object v2, v0, v3

    iget-object v2, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;->h:Lcom/github/catvod/spider/xbpqxyq/xbpq/d/g;

    invoke-virtual {v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d/g;->d()Ljava/lang/String;

    move-result-object v2

    const/4 v4, 0x2

    aput-object v2, v0, v4

    const-string v2, "0C5A37000220120B3116516F2C0367071C310E5A7F1E51331E14203A1A315542674000775B5A360D122712272C01516F555D36475F77160D310A2C271216240816774D0C37101679550C2A3A0334051D2B112C331E14203A1A31554267171C3A035A6947073A281C370C0530281121474977520B67185F771F1D24011627045A7F1E5116181631001D215A2C3C1516774D5A241503391E1B24111A3A19572F161C3B550569471A31554267555179551520111B3A135A7F47231A242C674951200514675F517A111129005C3618083C470E085B5A3700003A020A2600516F551E2C0916770A"

    invoke-static {v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-static {v2, v0}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    const-string v2, "161C370C0530580E774A1134031B2D"

    invoke-static {v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-direct {p0, v2, v0, v3}, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;->l(Ljava/lang/String;Ljava/lang/String;Z)Ljava/lang/String;

    move-result-object v0

    const-string v2, "311737071A31131D2B2B1C05120A280C00261E172B4B353C1B1D"

    invoke-static {v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v2

    if-eqz v2, :cond_51

    invoke-direct {p0, p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;->m(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    return-object p1

    :cond_51
    new-instance p1, Lorg/json/JSONObject;

    invoke-direct {p1, v0}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    const-string v0, "051D36151C3B041D36"

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Lorg/json/JSONObject;->getJSONArray(Ljava/lang/String;)Lorg/json/JSONArray;

    move-result-object p1

    invoke-virtual {p1, v1}, Lorg/json/JSONArray;->getJSONObject(I)Lorg/json/JSONObject;

    move-result-object p1

    const-string v0, "1517211C"

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Lorg/json/JSONObject;->getJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object p1

    const-string v0, "111129002C3C13"

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    return-object p1
.end method

.method private n()V
    .registers 2

    :try_start_0
    iget-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;->c:Landroid/app/AlertDialog;

    if-eqz v0, :cond_7

    invoke-virtual {v0}, Landroid/app/Dialog;->dismiss()V
    :try_end_7
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_7} :catch_7

    :catch_7
    :cond_7
    return-void
.end method

.method public static o()Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;
    .registers 1

    sget-object v0, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/o;->a:Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;

    return-object v0
.end method

.method private r()Ljava/util/HashMap;
    .registers 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/HashMap<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    invoke-virtual {p0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;->q()Ljava/util/HashMap;

    move-result-object v0

    iget-object v1, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;->h:Lcom/github/catvod/spider/xbpqxyq/xbpq/d/g;

    invoke-virtual {v1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d/g;->c()Ljava/lang/String;

    move-result-object v1

    const-string v2, "160D310D1C271E0224111A3A19"

    invoke-static {v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2, v1}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    iget-object v1, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;->e:Ljava/lang/String;

    const-string v2, "0F55360D12271255310A183019"

    invoke-static {v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2, v1}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string v1, "2F5506041D340501"

    invoke-static {v1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const-string v2, "14142C001D214A392B01013A1E1C690403254A1921171A231254330001261E172B580561594B6B54"

    invoke-static {v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v1, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    return-object v0
.end method

.method private t(Lorg/json/JSONObject;Ljava/lang/String;)Ljava/lang/String;
    .registers 10

    const-string v0, "1B1133002C2105192B16103A13112B022C21160B2E3A1F3C040C"

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Lorg/json/JSONObject;->has(Ljava/lang/String;)Z

    move-result v1

    if-nez v1, :cond_f

    const-string p1, ""

    return-object p1

    :cond_f
    invoke-virtual {p1, v0}, Lorg/json/JSONObject;->getJSONArray(Ljava/lang/String;)Lorg/json/JSONArray;

    move-result-object v0

    const/4 v1, 0x0

    const/4 v2, 0x0

    :goto_15
    invoke-virtual {v0}, Lorg/json/JSONArray;->length()I

    move-result v3

    const-string v4, "020A29"

    invoke-static {v4}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    if-ge v2, v3, :cond_43

    invoke-virtual {v0, v2}, Lorg/json/JSONArray;->getJSONObject(I)Lorg/json/JSONObject;

    move-result-object v3

    const-string v5, "031D28151F34031D1A0C17"

    invoke-static {v5}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v3, v5}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    iget-object v6, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;->a:Ljava/util/HashMap;

    invoke-virtual {v6, p2}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v6

    invoke-virtual {v5, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_40

    invoke-virtual {v3, v4}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    return-object p1

    :cond_40
    add-int/lit8 v2, v2, 0x1

    goto :goto_15

    :cond_43
    const-string v2, "494A0E59"

    invoke-static {v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {p2, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p2

    if-eqz p2, :cond_5a

    const-string p2, "4990F3E095EDF244"

    invoke-static {p2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p2

    invoke-direct {p0, p1, p2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;->t(Lorg/json/JSONObject;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    return-object p1

    :cond_5a
    invoke-virtual {v0, v1}, Lorg/json/JSONArray;->getJSONObject(I)Lorg/json/JSONObject;

    move-result-object p1

    invoke-virtual {p1, v4}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    return-object p1
.end method

.method private u(Lorg/json/JSONObject;)Ljava/util/List;
    .registers 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lorg/json/JSONObject;",
            ")",
            "Ljava/util/List<",
            "Lcom/github/catvod/spider/xbpqxyq/xbpq/c/e;",
            ">;"
        }
    .end annotation

    const-string v0, "1B1133002C2105192B16103A13112B022C26021A310C073912273104003E28142C1607"

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Lorg/json/JSONObject;->has(Ljava/lang/String;)Z

    move-result v1

    if-nez v1, :cond_11

    invoke-static {}, Ljava/util/Collections;->emptyList()Ljava/util/List;

    move-result-object p1

    return-object p1

    :cond_11
    invoke-virtual {p1, v0}, Lorg/json/JSONObject;->getJSONArray(Ljava/lang/String;)Lorg/json/JSONArray;

    move-result-object p1

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    const/4 v1, 0x0

    :goto_1b
    invoke-virtual {p1}, Lorg/json/JSONArray;->length()I

    move-result v2

    if-ge v1, v2, :cond_57

    invoke-virtual {p1, v1}, Lorg/json/JSONArray;->getJSONObject(I)Lorg/json/JSONObject;

    move-result-object v2

    const-string v3, "1B192B020634101D"

    invoke-static {v3}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    const-string v4, "020A29"

    invoke-static {v4}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v2, v4}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    .line 1
    new-instance v4, Lcom/github/catvod/spider/xbpqxyq/xbpq/c/e;

    invoke-direct {v4}, Lcom/github/catvod/spider/xbpqxyq/xbpq/c/e;-><init>()V

    .line 2
    invoke-virtual {v4, v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/c/e;->d(Ljava/lang/String;)Lcom/github/catvod/spider/xbpqxyq/xbpq/c/e;

    invoke-virtual {v4, v3}, Lcom/github/catvod/spider/xbpqxyq/xbpq/c/e;->c(Ljava/lang/String;)Lcom/github/catvod/spider/xbpqxyq/xbpq/c/e;

    invoke-virtual {v4, v3}, Lcom/github/catvod/spider/xbpqxyq/xbpq/c/e;->b(Ljava/lang/String;)Lcom/github/catvod/spider/xbpqxyq/xbpq/c/e;

    const-string v2, "010C31"

    invoke-static {v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v4, v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/c/e;->a(Ljava/lang/String;)Lcom/github/catvod/spider/xbpqxyq/xbpq/c/e;

    move-result-object v2

    invoke-virtual {v0, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/lit8 v1, v1, 0x1

    goto :goto_1b

    :cond_57
    return-object v0
.end method


# virtual methods
.method public final F([Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    .registers 5

    const/4 v0, 0x0

    :try_start_1
    aget-object v0, p1, v0

    invoke-virtual {p0, v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;->y(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v0

    invoke-direct {p0, v0, p2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;->t(Lorg/json/JSONObject;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p2

    invoke-virtual {p0, p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;->v([Ljava/lang/String;)Ljava/util/List;

    move-result-object p1

    invoke-direct {p0, v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;->u(Lorg/json/JSONObject;)Ljava/util/List;

    move-result-object v0

    move-object v1, p1

    check-cast v1, Ljava/util/ArrayList;

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    .line 1
    new-instance v0, Lcom/github/catvod/spider/xbpqxyq/xbpq/c/d;

    invoke-direct {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/c/d;-><init>()V

    .line 2
    invoke-virtual {v0, p2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/c/d;->i(Ljava/lang/String;)Lcom/github/catvod/spider/xbpqxyq/xbpq/c/d;

    invoke-virtual {v0, p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/c/d;->h(Ljava/util/List;)Lcom/github/catvod/spider/xbpqxyq/xbpq/c/d;

    invoke-virtual {p0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;->q()Ljava/util/HashMap;

    move-result-object p1

    invoke-virtual {v0, p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/c/d;->a(Ljava/util/Map;)Lcom/github/catvod/spider/xbpqxyq/xbpq/c/d;

    .line 3
    invoke-virtual {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/c/d;->toString()Ljava/lang/String;

    move-result-object p1
    :try_end_2f
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_2f} :catch_30

    return-object p1

    :catch_30
    move-exception p1

    .line 4
    invoke-virtual {p1}, Ljava/lang/Throwable;->printStackTrace()V

    .line 5
    new-instance p1, Lcom/github/catvod/spider/xbpqxyq/xbpq/c/d;

    invoke-direct {p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/c/d;-><init>()V

    const-string p2, ""

    .line 6
    invoke-virtual {p1, p2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/c/d;->i(Ljava/lang/String;)Lcom/github/catvod/spider/xbpqxyq/xbpq/c/d;

    .line 7
    invoke-virtual {p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/c/d;->toString()Ljava/lang/String;

    move-result-object p1

    return-object p1
.end method

.method public final H(Ljava/util/Map;)[Ljava/lang/Object;
    .registers 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;)[",
            "Ljava/lang/Object;"
        }
    .end annotation

    const-string v0, "111129002C3C13"

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-interface {p1, v0}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/lang/String;

    invoke-virtual {p0, p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;->p(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    invoke-direct {p0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;->r()Ljava/util/HashMap;

    move-result-object v0

    invoke-static {p1, v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/h/b;->b(Ljava/lang/String;Ljava/util/Map;)Lokhttp3/Response;

    move-result-object p1

    invoke-virtual {p1}, Lokhttp3/Response;->body()Lokhttp3/ResponseBody;

    move-result-object p1

    invoke-virtual {p1}, Lokhttp3/ResponseBody;->bytes()[B

    move-result-object p1

    sget v0, Lcom/github/catvod/spider/xbpqxyq/xbpq/j/o;->a:I

    const-string v0, "303A0E"

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 1
    invoke-static {v0}, Ljava/nio/charset/Charset;->forName(Ljava/lang/String;)Ljava/nio/charset/Charset;

    move-result-object v1

    new-instance v2, Ljava/lang/String;

    invoke-direct {v2, p1, v1}, Ljava/lang/String;-><init>([BLjava/nio/charset/Charset;)V

    invoke-virtual {v2, v1}, Ljava/lang/String;->getBytes(Ljava/nio/charset/Charset;)[B

    move-result-object v1

    invoke-static {p1, v1}, Ljava/util/Arrays;->equals([B[B)Z

    move-result v1

    if-eqz v1, :cond_4e

    .line 2
    new-instance v1, Ljava/lang/String;

    invoke-static {v0}, Ljava/nio/charset/Charset;->forName(Ljava/lang/String;)Ljava/nio/charset/Charset;

    move-result-object v0

    invoke-direct {v1, p1, v0}, Ljava/lang/String;-><init>([BLjava/nio/charset/Charset;)V

    const-string p1, "222C03484B"

    invoke-static {p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v1, p1}, Ljava/lang/String;->getBytes(Ljava/lang/String;)[B

    move-result-object p1

    :cond_4e
    const/4 v0, 0x3

    new-array v0, v0, [Ljava/lang/Object;

    const/4 v1, 0x0

    const/16 v2, 0xc8

    .line 3
    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    aput-object v2, v0, v1

    const/4 v1, 0x1

    const-string v2, "160835091A36160C2C0A1D7A181B31000778040C37001238"

    invoke-static {v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    aput-object v2, v0, v1

    const/4 v1, 0x2

    new-instance v2, Ljava/io/ByteArrayInputStream;

    invoke-direct {v2, p1}, Ljava/io/ByteArrayInputStream;-><init>([B)V

    aput-object v2, v0, v1

    return-object v0
.end method

.method public final J(Ljava/lang/String;)V
    .registers 9

    invoke-virtual {p1}, Ljava/lang/String;->isEmpty()Z

    move-result v0

    const-string v1, "2C26044829345A0275484A08"

    invoke-static {v1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const/4 v2, 0x0

    const-string v3, ""

    if-eqz v0, :cond_1e

    const-string p1, "1F0C3115006F58572604077B141729041E3C190C6B061F20155724091A7803172E001D21"

    invoke-static {p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    .line 1
    :goto_15
    invoke-static {p1, v2, v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/h/b;->h(Ljava/lang/String;Ljava/util/Map;Ljava/util/Map;)Ljava/lang/String;

    move-result-object p1

    .line 2
    invoke-virtual {p1, v1, v3}, Ljava/lang/String;->replaceAll(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    goto :goto_9b

    :cond_1e
    const-string v0, "92F6DA82E7EE"

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v4

    const-string v5, "9FCEC083CBD0"

    invoke-static {v5}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    if-nez v4, :cond_52

    const-string v4, "499DCBFA94C1CC44"

    invoke-static {v4}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {p1, v4}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v4

    if-eqz v4, :cond_3d

    goto :goto_52

    :cond_3d
    invoke-virtual {p1, v5}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v4

    if-nez v4, :cond_4f

    const-string v4, "4990F3E095EDF244"

    invoke-static {v4}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {p1, v4}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v4

    if-eqz v4, :cond_54

    :cond_4f
    iput-object v5, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;->i:Ljava/lang/String;

    goto :goto_54

    :cond_52
    :goto_52
    iput-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;->i:Ljava/lang/String;

    :cond_54
    :goto_54
    const-string v4, "9FC8C68DDCC091D0E480CFDA"

    invoke-static {v4}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {p1, v4}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v6

    if-eqz v6, :cond_63

    const/4 v6, 0x1

    iput-boolean v6, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;->j:Z

    :cond_63
    invoke-virtual {p1, v5, v3}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p1, v0, v3}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object p1

    const-string v0, "494A0E59"

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0, v3}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object p1

    const-string v0, "4944"

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0, v3}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object p1

    const-string v0, "91E1EB82E7EE"

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0, v3}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p1, v4, v3}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object p1

    const-string v0, "1F0C3115"

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_9b

    goto/16 :goto_15

    :cond_9b
    :goto_9b
    if-nez p1, :cond_9e

    goto :goto_9f

    :cond_9e
    move-object v3, p1

    :goto_9f
    iput-object v3, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;->d:Ljava/lang/String;

    return-void
.end method

.method public final K(Ljava/lang/String;)V
    .registers 4

    invoke-virtual {p0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;->s()Ljava/io/File;

    move-result-object v0

    invoke-virtual {v0}, Ljava/io/File;->exists()Z

    move-result v0

    if-nez v0, :cond_12

    iget-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;->g:Lcom/github/catvod/spider/xbpqxyq/xbpq/d/f;

    invoke-virtual {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d/f;->a()Lcom/github/catvod/spider/xbpqxyq/xbpq/d/f;

    invoke-virtual {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d/f;->e()Lcom/github/catvod/spider/xbpqxyq/xbpq/d/f;

    :cond_12
    invoke-virtual {p0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;->x()Ljava/io/File;

    move-result-object v0

    invoke-virtual {v0}, Ljava/io/File;->exists()Z

    move-result v0

    if-nez v0, :cond_24

    iget-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;->h:Lcom/github/catvod/spider/xbpqxyq/xbpq/d/g;

    invoke-virtual {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d/g;->a()Lcom/github/catvod/spider/xbpqxyq/xbpq/d/g;

    invoke-virtual {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d/g;->g()Lcom/github/catvod/spider/xbpqxyq/xbpq/d/g;

    :cond_24
    iput-object p1, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;->f:Ljava/lang/String;

    :try_start_26
    const-string p1, "051D231716261F2B2D04013023172E001D7B5956"

    invoke-static {p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    invoke-static {p1}, Lcom/github/catvod/crawler/SpiderDebug;->log(Ljava/lang/String;)V

    new-instance p1, Lorg/json/JSONObject;

    invoke-direct {p1}, Lorg/json/JSONObject;-><init>()V

    const-string v0, "04102417160A1E1C"

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    iget-object v1, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;->f:Ljava/lang/String;

    invoke-virtual {p1, v0, v1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const-string v0, "04102417160A070F21"

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const-string v1, ""

    invoke-virtual {p1, v0, v1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const-string v0, "014A6A161B34051D1A091A3B1C572200070A04102417160A03172E001D"

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-direct {p0, v0, p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;->G(Ljava/lang/String;Lorg/json/JSONObject;)Ljava/lang/String;

    move-result-object p1

    new-instance v0, Lorg/json/JSONObject;

    invoke-direct {v0, p1}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    const-string p1, "04102417160A03172E001D"

    invoke-static {p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v0, p1}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    iput-object p1, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;->e:Ljava/lang/String;
    :try_end_65
    .catch Ljava/lang/Exception; {:try_start_26 .. :try_end_65} :catch_66

    goto :goto_73

    :catch_66
    move-exception p1

    invoke-virtual {p1}, Ljava/lang/Throwable;->printStackTrace()V

    const-string p1, "91E5E083EACF92EDE38ACFD99FD7E080FBD393C2EE80C4E792DCF483E6DD94F8C7"

    invoke-static {p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    invoke-static {p1}, Lcom/github/catvod/spider/Init;->show(Ljava/lang/String;)V

    :goto_73
    return-void
.end method

.method public final p(Ljava/lang/String;)Ljava/lang/String;
    .registers 5

    const/4 v0, 0x0

    :try_start_1
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "101D31211C2219142A04170005146B4B5D"

    invoke-static {v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Lcom/github/catvod/crawler/SpiderDebug;->log(Ljava/lang/String;)V

    iget-object v1, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;->b:Ljava/util/ArrayList;

    invoke-direct {p0, p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;->m(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v1, v0, p1}, Ljava/util/ArrayList;->add(ILjava/lang/Object;)V

    new-instance p1, Lorg/json/JSONObject;

    invoke-direct {p1}, Lorg/json/JSONObject;-><init>()V

    const-string v1, "111129002C3C13"

    invoke-static {v1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    iget-object v2, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;->b:Ljava/util/ArrayList;

    invoke-virtual {v2, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    invoke-virtual {p1, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const-string v1, "130A2C13160A1E1C"

    invoke-static {v1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    iget-object v2, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;->h:Lcom/github/catvod/spider/xbpqxyq/xbpq/d/g;

    invoke-virtual {v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d/g;->d()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {p1, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const-string v1, "1808200B353C1B1D6A0216213317320B1F3A161C10171F"

    invoke-static {v1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {p1}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v2, 0x1

    invoke-direct {p0, v1, p1, v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;->C(Ljava/lang/String;Ljava/lang/String;Z)Ljava/lang/String;

    move-result-object p1

    new-instance v1, Lorg/json/JSONObject;

    invoke-direct {v1, p1}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    const-string p1, "020A29"

    invoke-static {p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v1, p1}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1
    :try_end_63
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_63} :catch_6b
    .catchall {:try_start_1 .. :try_end_63} :catchall_69

    new-instance v0, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/l;

    invoke-direct {v0, p0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/l;-><init>(Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;)V

    goto :goto_76

    :catchall_69
    move-exception p1

    goto :goto_7a

    :catch_6b
    move-exception p1

    :try_start_6c
    invoke-virtual {p1}, Ljava/lang/Throwable;->printStackTrace()V

    const-string p1, ""
    :try_end_71
    .catchall {:try_start_6c .. :try_end_71} :catchall_69

    new-instance v0, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/l;

    invoke-direct {v0, p0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/l;-><init>(Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;)V

    :goto_76
    invoke-static {v0}, Lcom/github/catvod/spider/Init;->execute(Ljava/lang/Runnable;)V

    return-object p1

    :goto_7a
    new-instance v1, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/j;

    invoke-direct {v1, p0, v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/j;-><init>(Ljava/lang/Object;I)V

    invoke-static {v1}, Lcom/github/catvod/spider/Init;->execute(Ljava/lang/Runnable;)V

    throw p1
.end method

.method public final q()Ljava/util/HashMap;
    .registers 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/HashMap<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    new-instance v0, Ljava/util/HashMap;

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    const-string v1, "220B20175E14101D2B11"

    invoke-static {v1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const-string v2, "3A173F0C1F391657704B43755F2F2C0B173A000B652B277546486B55487520112B53476E570073515A75360835091602121A0E0C077A424B724B406357500E2D27183B5465091A3E12580200103E185165261B271815204A4A6159486B514565415670515306161E24171A7A424B724B4063"

    invoke-static {v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v1, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string v1, "251D2300013005"

    invoke-static {v1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const-string v2, "1F0C3115006F58573212047B16142C1C063B130A2C13167B1417284A"

    invoke-static {v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v1, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    return-object v0
.end method

.method public final s()Ljava/io/File;
    .registers 4

    .line 1
    new-instance v0, Ljava/io/File;

    .line 2
    invoke-static {}, Lcom/github/catvod/spider/Init;->context()Landroid/app/Application;

    move-result-object v1

    invoke-virtual {v1}, Landroid/content/Context;->getCacheDir()Ljava/io/File;

    move-result-object v1

    const-string v2, "16142C1C063B130A2C13160A181930111B"

    invoke-static {v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    .line 3
    invoke-direct {v0, v1, v2}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    return-object v0
.end method

.method public final v([Ljava/lang/String;)Ljava/util/List;
    .registers 11
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "([",
            "Ljava/lang/String;",
            ")",
            "Ljava/util/List<",
            "Lcom/github/catvod/spider/xbpqxyq/xbpq/c/e;",
            ">;"
        }
    .end annotation

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    array-length v1, p1

    const/4 v2, 0x0

    const/4 v3, 0x0

    :goto_8
    if-ge v3, v1, :cond_56

    aget-object v4, p1, v3

    const-string v5, "373805"

    invoke-static {v5}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v6

    if-nez v6, :cond_19

    goto :goto_53

    :cond_19
    invoke-virtual {v4, v5}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v4

    aget-object v5, v4, v2

    const/4 v6, 0x1

    aget-object v6, v4, v6

    new-instance v7, Ljava/lang/StringBuilder;

    invoke-direct {v7}, Ljava/lang/StringBuilder;-><init>()V

    invoke-static {}, Lcom/github/catvod/spider/Proxyq;->getUrl()Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v8, "481C2A5812391E5E311C03304A0B300755331E14203A1A314A"

    invoke-static {v8}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x2

    aget-object v4, v4, v8

    invoke-virtual {v7, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    .line 1
    new-instance v7, Lcom/github/catvod/spider/xbpqxyq/xbpq/c/e;

    invoke-direct {v7}, Lcom/github/catvod/spider/xbpqxyq/xbpq/c/e;-><init>()V

    .line 2
    invoke-virtual {v7, v5}, Lcom/github/catvod/spider/xbpqxyq/xbpq/c/e;->c(Ljava/lang/String;)Lcom/github/catvod/spider/xbpqxyq/xbpq/c/e;

    invoke-virtual {v7, v6}, Lcom/github/catvod/spider/xbpqxyq/xbpq/c/e;->a(Ljava/lang/String;)Lcom/github/catvod/spider/xbpqxyq/xbpq/c/e;

    move-result-object v5

    invoke-virtual {v5, v4}, Lcom/github/catvod/spider/xbpqxyq/xbpq/c/e;->d(Ljava/lang/String;)Lcom/github/catvod/spider/xbpqxyq/xbpq/c/e;

    invoke-virtual {v0, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :goto_53
    add-int/lit8 v3, v3, 0x1

    goto :goto_8

    :cond_56
    return-object v0
.end method

.method public final w()[Ljava/lang/Object;
    .registers 4

    const/4 v0, 0x3

    new-array v0, v0, [Ljava/lang/Object;

    const/16 v1, 0xc8

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    const/4 v2, 0x0

    aput-object v1, v0, v2

    const/4 v1, 0x1

    const-string v2, "031D3D115C251B192C0B"

    invoke-static {v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    aput-object v2, v0, v1

    new-instance v1, Ljava/io/ByteArrayInputStream;

    iget-object v2, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;->h:Lcom/github/catvod/spider/xbpqxyq/xbpq/d/g;

    invoke-virtual {v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d/g;->e()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/String;->getBytes()[B

    move-result-object v2

    invoke-direct {v1, v2}, Ljava/io/ByteArrayInputStream;-><init>([B)V

    const/4 v2, 0x2

    aput-object v1, v0, v2

    return-object v0
.end method

.method public final x()Ljava/io/File;
    .registers 4

    .line 1
    new-instance v0, Ljava/io/File;

    .line 2
    invoke-static {}, Lcom/github/catvod/spider/Init;->context()Landroid/app/Application;

    move-result-object v1

    invoke-virtual {v1}, Landroid/content/Context;->getCacheDir()Ljava/io/File;

    move-result-object v1

    const-string v2, "16142C1C063B130A2C13160A020B2017"

    invoke-static {v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    .line 3
    invoke-direct {v0, v1, v2}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    return-object v0
.end method

.method public final y(Ljava/lang/String;)Lorg/json/JSONObject;
    .registers 5

    const/4 v0, 0x0

    :try_start_1
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "101D31331A311217151716231E1D32351F340E312B031C7B5956"

    invoke-static {v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Lcom/github/catvod/crawler/SpiderDebug;->log(Ljava/lang/String;)V

    iget-object v1, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;->b:Ljava/util/ArrayList;

    invoke-direct {p0, p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;->m(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v1, v0, p1}, Ljava/util/ArrayList;->add(ILjava/lang/Object;)V

    new-instance p1, Lorg/json/JSONObject;

    invoke-direct {p1}, Lorg/json/JSONObject;-><init>()V

    const-string v1, "111129002C3C13"

    invoke-static {v1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    iget-object v2, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;->b:Ljava/util/ArrayList;

    invoke-virtual {v2, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    invoke-virtual {p1, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const-string v1, "130A2C13160A1E1C"

    invoke-static {v1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    iget-object v2, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;->h:Lcom/github/catvod/spider/xbpqxyq/xbpq/d/g;

    invoke-virtual {v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d/g;->d()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {p1, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const-string v1, "14193100143A0501"

    invoke-static {v1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const-string v2, "1B1133002C2105192B16103A13112B02"

    invoke-static {v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {p1, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const-string v1, "020A293A162D071137002C26121B"

    invoke-static {v1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const-string v2, "464C715543"

    invoke-static {v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {p1, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const-string v1, "1808200B353C1B1D6A021621211121001C05051D330C16222714241C3A3B1117"

    invoke-static {v1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {p1}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v2, 0x1

    invoke-direct {p0, v1, p1, v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;->C(Ljava/lang/String;Ljava/lang/String;Z)Ljava/lang/String;

    move-result-object p1

    new-instance v1, Lorg/json/JSONObject;

    invoke-direct {v1, p1}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    const-string p1, "011121001C0A070A20131A3000273509122C28112B031C"

    invoke-static {p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v1, p1}, Lorg/json/JSONObject;->getJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object p1
    :try_end_81
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_81} :catch_8c
    .catchall {:try_start_1 .. :try_end_81} :catchall_8a

    new-instance v0, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/l;

    invoke-direct {v0, p0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/l;-><init>(Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;)V

    invoke-static {v0}, Lcom/github/catvod/spider/Init;->execute(Ljava/lang/Runnable;)V

    return-object p1

    :catchall_8a
    move-exception p1

    goto :goto_9e

    :catch_8c
    move-exception p1

    :try_start_8d
    invoke-virtual {p1}, Ljava/lang/Throwable;->printStackTrace()V

    new-instance p1, Lorg/json/JSONObject;

    invoke-direct {p1}, Lorg/json/JSONObject;-><init>()V
    :try_end_95
    .catchall {:try_start_8d .. :try_end_95} :catchall_8a

    new-instance v1, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/k;

    invoke-direct {v1, p0, v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/k;-><init>(Ljava/lang/Object;I)V

    invoke-static {v1}, Lcom/github/catvod/spider/Init;->execute(Ljava/lang/Runnable;)V

    return-object p1

    :goto_9e
    new-instance v1, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/i;

    invoke-direct {v1, p0, v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/i;-><init>(Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;I)V

    invoke-static {v1}, Lcom/github/catvod/spider/Init;->execute(Ljava/lang/Runnable;)V

    throw p1
.end method

.method public final z(Ljava/lang/String;Ljava/lang/String;)Lcom/github/catvod/spider/xbpqxyq/xbpq/c/g;
    .registers 22

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    new-instance v2, Lorg/json/JSONObject;

    invoke-direct {v2}, Lorg/json/JSONObject;-><init>()V

    iget-object v3, v0, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;->f:Ljava/lang/String;

    const-string v4, "04102417160A1E1C"

    invoke-static {v4}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v2, v4, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const-string v3, "161C370C0530580E764A003D160A203A1F3C19136A021621280B2D040130281A3C3A123B18163C081C2004"

    invoke-static {v3}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-direct {v0, v3, v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;->G(Ljava/lang/String;Lorg/json/JSONObject;)Ljava/lang/String;

    move-result-object v2

    new-instance v3, Lorg/json/JSONObject;

    invoke-direct {v3, v2}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    new-instance v2, Ljava/util/ArrayList;

    invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V

    new-instance v4, Ljava/util/ArrayList;

    invoke-direct {v4}, Ljava/util/ArrayList;-><init>()V

    new-instance v5, Lcom/github/catvod/spider/xbpqxyq/xbpq/d/e;

    const-string v6, "111129002C3C191E2A16"

    invoke-static {v6}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    .line 1
    invoke-virtual {v3, v6}, Lorg/json/JSONObject;->getJSONArray(Ljava/lang/String;)Lorg/json/JSONArray;

    move-result-object v6

    invoke-static/range {p2 .. p2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v7

    const-string v8, "14193100143A0501"

    invoke-static {v8}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    const/4 v9, 0x0

    const-string v10, ""

    if-nez v7, :cond_4b

    move-object/from16 v6, p2

    goto :goto_9e

    :cond_4b
    invoke-virtual {v6}, Lorg/json/JSONArray;->length()I

    move-result v7

    if-nez v7, :cond_53

    :cond_51
    move-object v6, v10

    goto :goto_9e

    :cond_53
    invoke-virtual {v6, v9}, Lorg/json/JSONArray;->getJSONObject(I)Lorg/json/JSONObject;

    move-result-object v6

    const-string v7, "03013500"

    invoke-static {v7}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v6, v7}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v11

    const-string v12, "111729011627"

    invoke-static {v12}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v12

    invoke-virtual {v11, v12}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v11

    if-eqz v11, :cond_78

    const-string v7, "111129002C3C13"

    invoke-static {v7}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v6, v7}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    goto :goto_9e

    :cond_78
    invoke-virtual {v6, v7}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    const-string v11, "11112900"

    invoke-static {v11}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v11

    invoke-virtual {v7, v11}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v7

    if-eqz v7, :cond_51

    invoke-virtual {v6, v8}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    const-string v7, "011121001C"

    invoke-static {v7}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v6, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_51

    const-string v6, "05172A11"

    invoke-static {v6}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    .line 2
    :goto_9e
    invoke-direct {v5, v6}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d/e;-><init>(Ljava/lang/String;)V

    .line 3
    invoke-direct {v0, v5, v2, v4, v10}, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;->B(Lcom/github/catvod/spider/xbpqxyq/xbpq/d/e;Ljava/util/List;Ljava/util/List;Ljava/lang/String;)V

    .line 4
    iget-object v5, v0, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;->i:Ljava/lang/String;

    const-string v6, "9FCEC083CBD0"

    invoke-static {v6}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v6, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    const-string v6, "494A0E59"

    invoke-static {v6}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    const/4 v7, 0x2

    const-string v11, "499DCBFA94C1CC44"

    invoke-static {v11}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v11

    const-string v12, "4990F3E095EDF244"

    invoke-static {v12}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v12

    const/4 v13, 0x3

    const/4 v14, 0x1

    if-eqz v5, :cond_d4

    new-array v5, v13, [Ljava/lang/String;

    aput-object v12, v5, v9

    aput-object v11, v5, v14

    aput-object v6, v5, v7

    invoke-static {v5}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v5

    goto :goto_fb

    :cond_d4
    iget-object v5, v0, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;->i:Ljava/lang/String;

    const-string v15, "92F6DA82E7EE"

    invoke-static {v15}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v15

    invoke-virtual {v15, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_ef

    new-array v5, v13, [Ljava/lang/String;

    aput-object v11, v5, v9

    aput-object v6, v5, v14

    aput-object v12, v5, v7

    invoke-static {v5}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v5

    goto :goto_fb

    :cond_ef
    new-array v5, v13, [Ljava/lang/String;

    aput-object v6, v5, v9

    aput-object v11, v5, v14

    aput-object v12, v5, v7

    invoke-static {v5}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v5

    :goto_fb
    new-instance v6, Ljava/util/ArrayList;

    invoke-direct {v6}, Ljava/util/ArrayList;-><init>()V

    new-instance v7, Ljava/util/ArrayList;

    invoke-direct {v7}, Ljava/util/ArrayList;-><init>()V

    invoke-virtual {v2}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :goto_109
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v11

    if-eqz v11, :cond_1cd

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v11

    check-cast v11, Lcom/github/catvod/spider/xbpqxyq/xbpq/d/e;

    new-instance v12, Ljava/lang/StringBuilder;

    invoke-direct {v12}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v11}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d/e;->b()Ljava/lang/String;

    move-result-object v13

    invoke-virtual {v12, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v13, "53"

    invoke-static {v13}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v13

    invoke-virtual {v12, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v11}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d/e;->d()Ljava/lang/String;

    move-result-object v13

    invoke-virtual {v12, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v11}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d/e;->f()Ljava/lang/String;

    move-result-object v11

    .line 5
    new-instance v13, Ljava/util/ArrayList;

    invoke-direct {v13}, Ljava/util/ArrayList;-><init>()V

    invoke-static {v11}, Lcom/github/catvod/spider/xbpqxyq/xbpq/j/o;->e(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v11

    invoke-virtual {v11}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object v11

    .line 6
    invoke-virtual {v4}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v14

    :goto_146
    invoke-interface {v14}, Ljava/util/Iterator;->hasNext()Z

    move-result v15

    if-eqz v15, :cond_16f

    invoke-interface {v14}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v15

    check-cast v15, Lcom/github/catvod/spider/xbpqxyq/xbpq/d/e;

    invoke-virtual {v15}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d/e;->f()Ljava/lang/String;

    move-result-object v16

    invoke-static/range {v16 .. v16}, Lcom/github/catvod/spider/xbpqxyq/xbpq/j/o;->e(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v16

    invoke-virtual/range {v16 .. v16}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v11, v9}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v16

    if-nez v16, :cond_16a

    invoke-virtual {v9, v11}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v9

    if-eqz v9, :cond_16d

    :cond_16a
    invoke-virtual {v13, v15}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_16d
    const/4 v9, 0x0

    goto :goto_146

    .line 7
    :cond_16f
    invoke-virtual {v13}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v9

    if-eqz v9, :cond_178

    invoke-virtual {v13, v4}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    :cond_178
    new-instance v9, Ljava/lang/StringBuilder;

    invoke-direct {v9}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v13}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v11

    :goto_181
    invoke-interface {v11}, Ljava/util/Iterator;->hasNext()Z

    move-result v13

    if-eqz v13, :cond_1bc

    invoke-interface {v11}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v13

    check-cast v13, Lcom/github/catvod/spider/xbpqxyq/xbpq/d/e;

    const-string v14, "5C"

    invoke-static {v14}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v14

    invoke-virtual {v9, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v13}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d/e;->f()Ljava/lang/String;

    move-result-object v14

    invoke-static {v14}, Lcom/github/catvod/spider/xbpqxyq/xbpq/j/o;->e(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v14

    invoke-virtual {v9, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v14, "373805"

    invoke-static {v14}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v14

    invoke-virtual {v9, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v13}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d/e;->c()Ljava/lang/String;

    move-result-object v15

    invoke-virtual {v9, v15}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v9, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v13}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d/e;->d()Ljava/lang/String;

    move-result-object v13

    invoke-virtual {v9, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    goto :goto_181

    :cond_1bc
    invoke-virtual {v9}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v9

    .line 8
    invoke-virtual {v12, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v12}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v6, v9}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    const/4 v9, 0x0

    goto/16 :goto_109

    :cond_1cd
    const/4 v9, 0x0

    :goto_1ce
    invoke-interface {v5}, Ljava/util/List;->size()I

    move-result v2

    if-ge v9, v2, :cond_1e4

    const-string v2, "54"

    invoke-static {v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-static {v2, v6}, Landroid/text/TextUtils;->join(Ljava/lang/CharSequence;Ljava/lang/Iterable;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v7, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/lit8 v9, v9, 0x1

    goto :goto_1ce

    :cond_1e4
    new-instance v2, Lcom/github/catvod/spider/xbpqxyq/xbpq/c/g;

    invoke-direct {v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/c/g;-><init>()V

    invoke-virtual {v2, v1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/c/g;->f(Ljava/lang/String;)V

    iget-object v4, v0, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;->h:Lcom/github/catvod/spider/xbpqxyq/xbpq/d/g;

    invoke-virtual {v4}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d/g;->e()Ljava/lang/String;

    move-result-object v4

    sget-object v6, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;->l:Lorg/json/JSONObject;

    if-eqz v6, :cond_201

    const-string v9, "131D3606"

    invoke-static {v9}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v6, v9}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    goto :goto_202

    :cond_201
    move-object v6, v10

    :goto_202
    sget-object v9, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;->l:Lorg/json/JSONObject;

    if-eqz v9, :cond_20b

    invoke-virtual {v9, v8}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    goto :goto_20c

    :cond_20b
    move-object v8, v10

    :goto_20c
    sget-object v9, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;->l:Lorg/json/JSONObject;

    if-eqz v9, :cond_21b

    const-string v11, "160A2004"

    invoke-static {v11}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v11

    invoke-virtual {v9, v11}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    goto :goto_21c

    :cond_21b
    move-object v9, v10

    :goto_21c
    sget-object v11, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;->l:Lorg/json/JSONObject;

    if-eqz v11, :cond_22b

    const-string v12, "0E1D2417"

    invoke-static {v12}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v12

    invoke-virtual {v11, v12}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v11

    goto :goto_22c

    :cond_22b
    move-object v11, v10

    :goto_22c
    sget-object v12, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;->l:Lorg/json/JSONObject;

    if-eqz v12, :cond_23b

    const-string v13, "051D2804013E"

    invoke-static {v13}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v13

    invoke-virtual {v12, v13}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v12

    goto :goto_23c

    :cond_23b
    move-object v12, v10

    :goto_23c
    sget-object v13, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;->l:Lorg/json/JSONObject;

    if-eqz v13, :cond_24b

    const-string v14, "131137001021180A"

    invoke-static {v14}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v14

    invoke-virtual {v13, v14}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v13

    goto :goto_24c

    :cond_24b
    move-object v13, v10

    :goto_24c
    sget-object v14, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;->l:Lorg/json/JSONObject;

    if-eqz v14, :cond_25b

    const-string v15, "161B310A01"

    invoke-static {v15}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v15

    invoke-virtual {v14, v15}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v14

    goto :goto_25c

    :cond_25b
    move-object v14, v10

    :goto_25c
    iget-boolean v15, v0, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;->j:Z

    move-object/from16 p2, v5

    const-string v5, "98C4C98CE0EB91F6E08ACFCF"

    invoke-static {v5}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    move-object/from16 v16, v7

    const-string v7, "98C4C983E1F891ECFB"

    invoke-static {v7}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    move-object/from16 v17, v12

    const-string v12, "04102417160A19192800"

    invoke-static {v12}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v12

    if-eqz v15, :cond_29e

    invoke-virtual {v4}, Ljava/lang/String;->length()I

    move-result v15

    if-lez v15, :cond_29e

    sget-object v15, Lcom/github/catvod/spider/Init;->d:Landroid/content/SharedPreferences;

    move-object/from16 v18, v11

    const-string v11, "16142C3A073E"

    invoke-static {v11}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v11

    invoke-interface {v15, v11, v10}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v10, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v10

    if-eqz v10, :cond_2a0

    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    const-string v10, "91D5E680EFFD93C5FA82E7FD91F1EE82D3D492D5DD80F1FD03172E001DBACBE2"

    invoke-static {v10}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    goto :goto_2b5

    :cond_29e
    move-object/from16 v18, v11

    :cond_2a0
    iget-boolean v10, v0, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;->j:Z

    if-eqz v10, :cond_2d0

    invoke-virtual {v4}, Ljava/lang/String;->length()I

    move-result v10

    if-lez v10, :cond_2d0

    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    const-string v10, "91D5E680EFFD93C5FA82E7FD9EFDC882CEFB93C0E882E9D103172E001DBACBE2"

    invoke-static {v10}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    :goto_2b5
    invoke-virtual {v6, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v6, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, v12}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v6, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v6, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v6, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    goto :goto_2da

    :cond_2d0
    invoke-virtual {v6}, Ljava/lang/String;->length()I

    move-result v4

    if-lez v4, :cond_2da

    invoke-virtual {v2, v6}, Lcom/github/catvod/spider/xbpqxyq/xbpq/c/g;->d(Ljava/lang/String;)V

    goto :goto_2dd

    :cond_2da
    :goto_2da
    invoke-virtual {v2, v1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/c/g;->d(Ljava/lang/String;)V

    :goto_2dd
    invoke-virtual {v13}, Ljava/lang/String;->length()I

    move-result v1

    if-lez v1, :cond_2e6

    invoke-virtual {v2, v13}, Lcom/github/catvod/spider/xbpqxyq/xbpq/c/g;->e(Ljava/lang/String;)V

    :cond_2e6
    invoke-virtual {v14}, Ljava/lang/String;->length()I

    move-result v1

    if-lez v1, :cond_2ef

    invoke-virtual {v2, v14}, Lcom/github/catvod/spider/xbpqxyq/xbpq/c/g;->b(Ljava/lang/String;)V

    :cond_2ef
    invoke-virtual {v8}, Ljava/lang/String;->length()I

    move-result v1

    if-lez v1, :cond_2f8

    invoke-virtual {v2, v8}, Lcom/github/catvod/spider/xbpqxyq/xbpq/c/g;->a(Ljava/lang/String;)V

    :cond_2f8
    invoke-virtual {v9}, Ljava/lang/String;->length()I

    move-result v1

    if-lez v1, :cond_301

    invoke-virtual {v2, v9}, Lcom/github/catvod/spider/xbpqxyq/xbpq/c/g;->c(Ljava/lang/String;)V

    :cond_301
    invoke-virtual/range {v18 .. v18}, Ljava/lang/String;->length()I

    move-result v1

    if-lez v1, :cond_30c

    move-object/from16 v10, v18

    invoke-virtual {v2, v10}, Lcom/github/catvod/spider/xbpqxyq/xbpq/c/g;->l(Ljava/lang/String;)V

    :cond_30c
    invoke-virtual/range {v17 .. v17}, Ljava/lang/String;->length()I

    move-result v1

    if-lez v1, :cond_317

    move-object/from16 v10, v17

    invoke-virtual {v2, v10}, Lcom/github/catvod/spider/xbpqxyq/xbpq/c/g;->k(Ljava/lang/String;)V

    :cond_317
    const-string v1, "160E24111227"

    invoke-static {v1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v3, v1}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v2, v1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/c/g;->h(Ljava/lang/String;)V

    invoke-virtual {v3, v12}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v2, v1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/c/g;->g(Ljava/lang/String;)V

    const-string v1, "535C61"

    invoke-static {v1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    move-object/from16 v3, v16

    invoke-static {v1, v3}, Landroid/text/TextUtils;->join(Ljava/lang/CharSequence;Ljava/lang/Iterable;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Lcom/github/catvod/spider/xbpqxyq/xbpq/c/g;->j(Ljava/lang/String;)V

    move-object/from16 v5, p2

    invoke-static {v1, v5}, Landroid/text/TextUtils;->join(Ljava/lang/CharSequence;Ljava/lang/Iterable;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v2, v1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/c/g;->i(Ljava/lang/String;)V

    const-string v1, "9EE0FA8CF4D993C2D482E8CD"

    invoke-static {v1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v2, v1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/c/g;->a(Ljava/lang/String;)V

    return-object v2
.end method
