.class final enum Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/v0;
.super Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/h1;
.source "SourceFile"


# direct methods
.method constructor <init>()V
    .registers 4

    const-string v0, "351D230A0130360C31171A37020C20331239021D"

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/16 v1, 0x24

    const/4 v2, 0x0

    invoke-direct {p0, v0, v1, v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/h1;-><init>(Ljava/lang/String;ILcom/github/catvod/spider/xbpqxyq/xbpq/d0/c0;)V

    return-void
.end method


# virtual methods
.method final g(Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/Q;Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/a;)V
    .registers 7

    sget-object v0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/h1;->c:Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/c0;

    sget-object v1, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/h1;->P:Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/z0;

    invoke-virtual {p2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/a;->e()C

    move-result v2

    if-eqz v2, :cond_5b

    const/16 v3, 0x20

    if-eq v2, v3, :cond_69

    const/16 v3, 0x22

    if-eq v2, v3, :cond_55

    const/16 v3, 0x60

    if-eq v2, v3, :cond_4c

    const v3, 0xffff

    if-eq v2, v3, :cond_42

    const/16 v3, 0x9

    if-eq v2, v3, :cond_69

    const/16 v3, 0xa

    if-eq v2, v3, :cond_69

    const/16 v3, 0xc

    if-eq v2, v3, :cond_69

    const/16 v3, 0xd

    if-eq v2, v3, :cond_69

    const/16 v3, 0x26

    if-eq v2, v3, :cond_3e

    const/16 v3, 0x27

    if-eq v2, v3, :cond_3b

    packed-switch v2, :pswitch_data_6a

    goto :goto_3e

    :pswitch_37  #0x3e
    invoke-virtual {p1, p0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/Q;->q(Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/h1;)V

    goto :goto_45

    :cond_3b
    sget-object p2, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/h1;->O:Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/x0;

    goto :goto_57

    :cond_3e
    :goto_3e
    invoke-virtual {p2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/a;->G()V

    goto :goto_66

    :cond_42
    invoke-virtual {p1, p0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/Q;->p(Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/h1;)V

    :goto_45
    invoke-virtual {p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/Q;->o()V

    invoke-virtual {p1, v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/Q;->u(Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/h1;)V

    goto :goto_69

    :cond_4c
    :pswitch_4c  #0x3c, 0x3d
    invoke-virtual {p1, p0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/Q;->q(Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/h1;)V

    iget-object p2, p1, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/Q;->i:Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/N;

    invoke-virtual {p2, v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/N;->k(C)V

    goto :goto_66

    :cond_55
    sget-object p2, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/h1;->N:Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/w0;

    :goto_57
    invoke-virtual {p1, p2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/Q;->u(Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/h1;)V

    goto :goto_69

    :cond_5b
    invoke-virtual {p1, p0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/Q;->q(Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/h1;)V

    iget-object p2, p1, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/Q;->i:Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/N;

    const v0, 0xfffd

    invoke-virtual {p2, v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/N;->k(C)V

    :goto_66
    invoke-virtual {p1, v1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/Q;->u(Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/h1;)V

    :cond_69
    :goto_69
    return-void

    :pswitch_data_6a
    .packed-switch 0x3c
        :pswitch_4c  #0000003c
        :pswitch_4c  #0000003d
        :pswitch_37  #0000003e
    .end packed-switch
.end method
