.class public interface abstract Lcom/github/catvod/spider/xbpqxyq/xbpq/P/r;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract a()V
.end method

.method public abstract d(I)V
.end method

.method public abstract f(I)I
.end method

.method public abstract g()I
.end method

.method public abstract i()I
.end method

.method public abstract j()V
.end method

.method public abstract size()I
.end method
