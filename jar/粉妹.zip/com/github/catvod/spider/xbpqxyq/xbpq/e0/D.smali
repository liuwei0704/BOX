.class public final Lcom/github/catvod/spider/xbpqxyq/xbpq/e0/D;
.super Lcom/github/catvod/spider/xbpqxyq/xbpq/e0/G;
.source "SourceFile"


# direct methods
.method public constructor <init>()V
    .registers 3

    const/4 v0, 0x0

    const/4 v1, 0x1

    invoke-direct {p0, v0, v1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/e0/G;-><init>(II)V

    return-void
.end method


# virtual methods
.method public final toString()Ljava/lang/String;
    .registers 2

    const-string v0, "4D1424160778181E68110A2512"

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method
