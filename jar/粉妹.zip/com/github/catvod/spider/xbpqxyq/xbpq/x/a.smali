.class public final Lcom/github/catvod/spider/xbpqxyq/xbpq/x/a;
.super Ljava/lang/Object;
.source "SourceFile"


# direct methods
.method public static a(Ljava/lang/Throwable;Ljava/lang/Throwable;)V
    .registers 3

    const-string v0, "4B0C2D0C006B"

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-static {p0, v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/E/f;->e(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "1200260003211E172B"

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-static {p1, v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/E/f;->e(Ljava/lang/Object;Ljava/lang/String;)V

    if-eq p0, p1, :cond_19

    sget-object v0, Lcom/github/catvod/spider/xbpqxyq/xbpq/A/c;->a:Lcom/github/catvod/spider/xbpqxyq/xbpq/A/b;

    invoke-virtual {v0, p0, p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/A/b;->a(Ljava/lang/Throwable;Ljava/lang/Throwable;)V

    :cond_19
    return-void
.end method

.method public static b(Ljava/lang/String;Ljava/util/List;)Lokhttp3/HttpUrl;
    .registers 4

    invoke-static {p0}, Lokhttp3/HttpUrl;->get(Ljava/lang/String;)Lokhttp3/HttpUrl;

    move-result-object p0

    if-eqz p1, :cond_4b

    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result v0

    if-nez v0, :cond_d

    goto :goto_4b

    :cond_d
    invoke-virtual {p0}, Lokhttp3/HttpUrl;->newBuilder()Lokhttp3/HttpUrl$Builder;

    move-result-object p0

    invoke-interface {p1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :goto_15
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_47

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/github/catvod/spider/xbpqxyq/xbpq/u0/a;

    invoke-virtual {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/u0/a;->c()Z

    move-result v1

    if-eqz v1, :cond_37

    invoke-virtual {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/u0/a;->a()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/u0/a;->b()Ljava/lang/Object;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p0, v1, v0}, Lokhttp3/HttpUrl$Builder;->addEncodedQueryParameter(Ljava/lang/String;Ljava/lang/String;)Lokhttp3/HttpUrl$Builder;

    goto :goto_15

    :cond_37
    invoke-virtual {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/u0/a;->a()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/u0/a;->b()Ljava/lang/Object;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p0, v1, v0}, Lokhttp3/HttpUrl$Builder;->addQueryParameter(Ljava/lang/String;Ljava/lang/String;)Lokhttp3/HttpUrl$Builder;

    goto :goto_15

    :cond_47
    invoke-virtual {p0}, Lokhttp3/HttpUrl$Builder;->build()Lokhttp3/HttpUrl;

    move-result-object p0

    :cond_4b
    :goto_4b
    return-object p0
.end method

.method public static c(Ljava/lang/String;)Ljava/lang/String;
    .registers 2

    if-eqz p0, :cond_9

    sget-object v0, Ljava/util/Locale;->ENGLISH:Ljava/util/Locale;

    invoke-virtual {p0, v0}, Ljava/lang/String;->toLowerCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object p0

    goto :goto_b

    :cond_9
    const-string p0, ""

    :goto_b
    return-object p0
.end method

.method public static d(Ljava/lang/String;)Ljava/lang/String;
    .registers 1

    invoke-static {p0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/x/a;->c(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    invoke-virtual {p0}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method
