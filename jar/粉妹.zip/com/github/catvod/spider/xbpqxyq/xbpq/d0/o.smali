.class final enum Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/o;
.super Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/A;
.source "SourceFile"


# direct methods
.method constructor <init>()V
    .registers 4

    const-string v0, "361E31000114110C2017313A1301"

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/16 v1, 0x14

    const/4 v2, 0x0

    invoke-direct {p0, v0, v1, v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/A;-><init>(Ljava/lang/String;ILcom/github/catvod/spider/xbpqxyq/xbpq/d0/m;)V

    return-void
.end method


# virtual methods
.method final d(Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/O;Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b;)Z
    .registers 6

    sget-object v0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/A;->i:Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/w;

    invoke-virtual {p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/O;->b()Z

    move-result v1

    if-eqz v1, :cond_e

    .line 1
    check-cast p1, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/I;

    .line 2
    invoke-virtual {p2, p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b;->F(Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/I;)V

    goto :goto_56

    :cond_e
    invoke-virtual {p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/O;->c()Z

    move-result v1

    if-nez v1, :cond_63

    invoke-virtual {p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/O;->f()Z

    move-result v1

    const-string v2, "1F0C2809"

    invoke-static {v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    if-eqz v1, :cond_2c

    .line 3
    move-object v1, p1

    check-cast v1, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/M;

    .line 4
    iget-object v1, v1, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/N;->c:Ljava/lang/String;

    .line 5
    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_2c

    goto :goto_63

    :cond_2c
    invoke-static {p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/A;->a(Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/O;)Z

    move-result v1

    if-eqz v1, :cond_50

    invoke-virtual {p2, v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b;->V(Ljava/lang/String;)Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/l;

    move-result-object v0

    .line 6
    check-cast p1, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/H;

    .line 7
    invoke-virtual {p2, p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b;->E(Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/H;)V

    iget-object p1, p2, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/i1;->e:Ljava/util/ArrayList;

    invoke-virtual {p1, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    iget-object p1, p2, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/i1;->e:Ljava/util/ArrayList;

    const-string p2, "1517211C"

    invoke-static {p2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p2

    invoke-virtual {v0, p2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/l;->k0(Ljava/lang/String;)Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/l;

    move-result-object p2

    invoke-virtual {p1, p2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_56

    :cond_50
    invoke-virtual {p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/O;->d()Z

    move-result v1

    if-eqz v1, :cond_58

    :goto_56
    const/4 p1, 0x1

    return p1

    :cond_58
    invoke-virtual {p2, p0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b;->n(Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/A;)V

    invoke-virtual {p2, v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b;->j0(Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/A;)V

    invoke-virtual {p2, p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b;->c(Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/O;)Z

    move-result p1

    return p1

    :cond_63
    :goto_63
    invoke-virtual {p2, p1, v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b;->X(Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/O;Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/A;)Z

    move-result p1

    return p1
.end method
