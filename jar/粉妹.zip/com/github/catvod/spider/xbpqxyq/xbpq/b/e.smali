.class public final synthetic Lcom/github/catvod/spider/xbpqxyq/xbpq/b/e;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/content/DialogInterface$OnCancelListener;


# instance fields
.field public final synthetic a:Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;

.field public final synthetic b:Lcom/github/catvod/spider/xbpqxyq/xbpq/d/c;


# direct methods
.method public synthetic constructor <init>(Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;Lcom/github/catvod/spider/xbpqxyq/xbpq/d/c;)V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/e;->a:Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;

    iput-object p2, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/e;->b:Lcom/github/catvod/spider/xbpqxyq/xbpq/d/c;

    return-void
.end method


# virtual methods
.method public final onCancel(Landroid/content/DialogInterface;)V
    .registers 4

    iget-object p1, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/e;->a:Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;

    iget-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/e;->b:Lcom/github/catvod/spider/xbpqxyq/xbpq/d/c;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v1, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/c;

    invoke-direct {v1, p1, v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/c;-><init>(Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;Lcom/github/catvod/spider/xbpqxyq/xbpq/d/c;)V

    invoke-static {v1}, Lcom/github/catvod/spider/Init;->execute(Ljava/lang/Runnable;)V

    return-void
.end method
