.class public final synthetic Lcom/github/catvod/spider/xbpqxyq/xbpq/b/b;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic c:Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;

.field public final synthetic d:Lcom/github/catvod/spider/xbpqxyq/xbpq/d/c;


# direct methods
.method public synthetic constructor <init>(Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;Lcom/github/catvod/spider/xbpqxyq/xbpq/d/c;)V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/b;->c:Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;

    iput-object p2, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/b;->d:Lcom/github/catvod/spider/xbpqxyq/xbpq/d/c;

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 3

    iget-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/b;->c:Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;

    iget-object v1, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/b;->d:Lcom/github/catvod/spider/xbpqxyq/xbpq/d/c;

    invoke-static {v0, v1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;->b(Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;Lcom/github/catvod/spider/xbpqxyq/xbpq/d/c;)V

    return-void
.end method
