.class public final Lcom/github/catvod/spider/xbpqxyq/xbpq/c/e;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field private a:Ljava/lang/String;
    .annotation runtime Lcom/google/gson/annotations/SerializedName;
        value = "url"
    .end annotation
.end field

.field private b:Ljava/lang/String;
    .annotation runtime Lcom/google/gson/annotations/SerializedName;
        value = "name"
    .end annotation
.end field

.field private c:Ljava/lang/String;
    .annotation runtime Lcom/google/gson/annotations/SerializedName;
        value = "lang"
    .end annotation
.end field

.field private d:Ljava/lang/String;
    .annotation runtime Lcom/google/gson/annotations/SerializedName;
        value = "format"
    .end annotation
.end field


# direct methods
.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final a(Ljava/lang/String;)Lcom/github/catvod/spider/xbpqxyq/xbpq/c/e;
    .registers 4

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p1}, Ljava/lang/String;->hashCode()I

    move-result v0

    const/4 v1, -0x1

    sparse-switch v0, :sswitch_data_56

    goto :goto_38

    :sswitch_c
    const-string v0, "010C31"

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-nez p1, :cond_19

    goto :goto_38

    :cond_19
    const/4 v1, 0x2

    goto :goto_38

    :sswitch_1b
    const-string v0, "040B24"

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-nez p1, :cond_28

    goto :goto_38

    :cond_28
    const/4 v1, 0x1

    goto :goto_38

    :sswitch_2a
    const-string v0, "160B36"

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-nez p1, :cond_37

    goto :goto_38

    :cond_37
    const/4 v1, 0x0

    :goto_38
    packed-switch v1, :pswitch_data_64

    const-string p1, "160835091A36160C2C0A1D7A0F55361011271E08"

    invoke-static {p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    iput-object p1, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/c/e;->d:Ljava/lang/String;

    return-object p0

    :pswitch_44  #0x2
    const-string p1, "031D3D115C23030C"

    invoke-static {p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    iput-object p1, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/c/e;->d:Ljava/lang/String;

    return-object p0

    :pswitch_4d  #0x0, 0x1
    const-string p1, "031D3D115C2D5A0B3604"

    invoke-static {p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    iput-object p1, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/c/e;->d:Ljava/lang/String;

    return-object p0

    :sswitch_data_56
    .sparse-switch
        0x17a81 -> :sswitch_2a
        0x1be01 -> :sswitch_1b
        0x1c976 -> :sswitch_c
    .end sparse-switch

    :pswitch_data_64
    .packed-switch 0x0
        :pswitch_4d  #00000000
        :pswitch_4d  #00000001
        :pswitch_44  #00000002
    .end packed-switch
.end method

.method public final b(Ljava/lang/String;)Lcom/github/catvod/spider/xbpqxyq/xbpq/c/e;
    .registers 2

    iput-object p1, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/c/e;->c:Ljava/lang/String;

    return-object p0
.end method

.method public final c(Ljava/lang/String;)Lcom/github/catvod/spider/xbpqxyq/xbpq/c/e;
    .registers 2

    iput-object p1, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/c/e;->b:Ljava/lang/String;

    return-object p0
.end method

.method public final d(Ljava/lang/String;)Lcom/github/catvod/spider/xbpqxyq/xbpq/c/e;
    .registers 2

    iput-object p1, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/c/e;->a:Ljava/lang/String;

    return-object p0
.end method
