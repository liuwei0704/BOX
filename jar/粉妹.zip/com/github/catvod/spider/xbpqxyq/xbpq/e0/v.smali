.class public final Lcom/github/catvod/spider/xbpqxyq/xbpq/e0/v;
.super Lcom/github/catvod/spider/xbpqxyq/xbpq/e0/w;
.source "SourceFile"


# direct methods
.method public constructor <init>(I)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/e0/w;-><init>(I)V

    return-void
.end method


# virtual methods
.method public final a(Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/l;Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/l;)Z
    .registers 3

    invoke-virtual {p2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/l;->U()I

    move-result p1

    iget p2, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/e0/w;->a:I

    if-ne p1, p2, :cond_a

    const/4 p1, 0x1

    goto :goto_b

    :cond_a
    const/4 p1, 0x0

    :goto_b
    return p1
.end method

.method public final toString()Ljava/lang/String;
    .registers 4

    const/4 v0, 0x1

    new-array v0, v0, [Ljava/lang/Object;

    iget v1, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/e0/w;->a:I

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    const/4 v2, 0x0

    aput-object v1, v0, v2

    const-string v1, "4D1D344D56315E"

    invoke-static {v1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-static {v1, v0}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method
