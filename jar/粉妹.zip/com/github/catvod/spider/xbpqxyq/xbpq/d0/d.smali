.class final enum Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/d;
.super Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/A;
.source "SourceFile"


# direct methods
.method constructor <init>()V
    .registers 4

    const-string v0, "3E16060403211E172B"

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/16 v1, 0xa

    const/4 v2, 0x0

    invoke-direct {p0, v0, v1, v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/A;-><init>(Ljava/lang/String;ILcom/github/catvod/spider/xbpqxyq/xbpq/d0/m;)V

    return-void
.end method


# virtual methods
.method final d(Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/O;Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b;)Z
    .registers 7

    invoke-virtual {p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/O;->e()Z

    move-result v0

    const/4 v1, 0x0

    const-string v2, "141935111A3A19"

    invoke-static {v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    if-eqz v0, :cond_41

    .line 1
    move-object v0, p1

    check-cast v0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/L;

    .line 2
    iget-object v3, v0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/N;->c:Ljava/lang/String;

    .line 3
    invoke-virtual {v3, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_41

    .line 4
    iget-object p1, v0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/N;->c:Ljava/lang/String;

    .line 5
    invoke-virtual {p2, p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b;->B(Ljava/lang/String;)Z

    move-result p1

    if-nez p1, :cond_24

    invoke-virtual {p2, p0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b;->n(Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/A;)V

    return v1

    :cond_24
    invoke-virtual {p2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/i1;->a()Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/l;

    move-result-object p1

    invoke-virtual {p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/l;->d0()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-nez p1, :cond_35

    invoke-virtual {p2, p0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b;->n(Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/A;)V

    :cond_35
    invoke-virtual {p2, v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b;->V(Ljava/lang/String;)Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/l;

    invoke-virtual {p2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b;->i()V

    sget-object p1, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/A;->k:Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/y;

    invoke-virtual {p2, p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b;->j0(Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/A;)V

    goto :goto_79

    :cond_41
    invoke-virtual {p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/O;->f()Z

    move-result v0

    if-eqz v0, :cond_54

    .line 6
    move-object v0, p1

    check-cast v0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/M;

    .line 7
    iget-object v0, v0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/N;->c:Ljava/lang/String;

    .line 8
    sget-object v3, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/z;->A:[Ljava/lang/String;

    invoke-static {v0, v3}, Lcom/github/catvod/spider/xbpqxyq/xbpq/b0/b;->b(Ljava/lang/String;[Ljava/lang/String;)Z

    move-result v0

    if-nez v0, :cond_6b

    :cond_54
    invoke-virtual {p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/O;->e()Z

    move-result v0

    if-eqz v0, :cond_7b

    .line 9
    move-object v0, p1

    check-cast v0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/L;

    .line 10
    iget-object v0, v0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/N;->c:Ljava/lang/String;

    const-string v3, "0319270916"

    invoke-static {v3}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    .line 11
    invoke-virtual {v0, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_7b

    :cond_6b
    invoke-virtual {p2, p0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b;->n(Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/A;)V

    invoke-virtual {p2, v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/i1;->d(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_79

    invoke-virtual {p2, p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b;->c(Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/O;)Z

    move-result p1

    return p1

    :cond_79
    :goto_79
    const/4 p1, 0x1

    return p1

    :cond_7b
    invoke-virtual {p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/O;->e()Z

    move-result v0

    if-eqz v0, :cond_92

    .line 12
    move-object v0, p1

    check-cast v0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/L;

    .line 13
    iget-object v0, v0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/N;->c:Ljava/lang/String;

    .line 14
    sget-object v2, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/z;->L:[Ljava/lang/String;

    invoke-static {v0, v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/b0/b;->b(Ljava/lang/String;[Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_92

    invoke-virtual {p2, p0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b;->n(Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/A;)V

    return v1

    :cond_92
    sget-object v0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/A;->i:Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/w;

    invoke-virtual {p2, p1, v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b;->X(Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/O;Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/A;)Z

    move-result p1

    return p1
.end method
