.class final enum Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b1;
.super Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/h1;
.source "SourceFile"


# direct methods
.method constructor <init>()V
    .registers 4

    const-string v0, "351722100011181B311C0330"

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/16 v1, 0x41

    const/4 v2, 0x0

    invoke-direct {p0, v0, v1, v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/h1;-><init>(Ljava/lang/String;ILcom/github/catvod/spider/xbpqxyq/xbpq/d0/c0;)V

    return-void
.end method


# virtual methods
.method final g(Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/Q;Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/a;)V
    .registers 5

    sget-object v0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/h1;->c:Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/c0;

    invoke-virtual {p2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/a;->e()C

    move-result p2

    const/16 v1, 0x3e

    if-eq p2, v1, :cond_10

    const v1, 0xffff

    if-eq p2, v1, :cond_10

    goto :goto_16

    :cond_10
    invoke-virtual {p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/Q;->n()V

    invoke-virtual {p1, v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/Q;->u(Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/h1;)V

    :goto_16
    return-void
.end method
