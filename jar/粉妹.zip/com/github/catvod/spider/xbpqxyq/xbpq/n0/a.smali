.class public interface abstract Lcom/github/catvod/spider/xbpqxyq/xbpq/n0/a;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract a(Ljava/lang/String;)Lcom/github/catvod/spider/xbpqxyq/xbpq/n0/b;
.end method
