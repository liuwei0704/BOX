.class public Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/f;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/util/Set;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Ljava/util/Set<",
        "Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/b;",
        ">;"
    }
.end annotation


# instance fields
.field protected c:Z

.field public d:Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/e;

.field public final e:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/b;",
            ">;"
        }
    .end annotation
.end field

.field public f:I

.field protected g:Ljava/util/BitSet;

.field public h:Z

.field public i:Z

.field public final j:Z

.field private k:I


# direct methods
.method public constructor <init>()V
    .registers 2

    const/4 v0, 0x1

    invoke-direct {p0, v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/f;-><init>(Z)V

    return-void
.end method

.method public constructor <init>(Z)V
    .registers 5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x0

    iput-boolean v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/f;->c:Z

    new-instance v1, Ljava/util/ArrayList;

    const/4 v2, 0x7

    invoke-direct {v1, v2}, Ljava/util/ArrayList;-><init>(I)V

    iput-object v1, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/f;->e:Ljava/util/ArrayList;

    const/4 v1, -0x1

    iput v1, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/f;->k:I

    new-instance v1, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/e;

    invoke-direct {v1, v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/e;-><init>(I)V

    iput-object v1, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/f;->d:Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/e;

    iput-boolean p1, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/f;->j:Z

    return-void
.end method


# virtual methods
.method public final a(Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/b;Lcom/github/catvod/spider/xbpqxyq/xbpq/S/c;)V
    .registers 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/b;",
            "Lcom/github/catvod/spider/xbpqxyq/xbpq/S/c<",
            "Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/X;",
            "Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/X;",
            "Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/X;",
            ">;)Z"
        }
    .end annotation

    iget-boolean v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/f;->c:Z

    if-nez v0, :cond_4d

    iget-object v0, p1, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/b;->e:Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/l0;

    sget-object v1, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/l0;->c:Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/k0;

    const/4 v2, 0x1

    if-eq v0, v1, :cond_d

    iput-boolean v2, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/f;->h:Z

    :cond_d
    invoke-virtual {p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/b;->b()I

    move-result v0

    if-lez v0, :cond_15

    iput-boolean v2, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/f;->i:Z

    :cond_15
    iget-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/f;->d:Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/e;

    invoke-virtual {v0, p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/S/b;->f(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/b;

    if-ne v0, p1, :cond_28

    const/4 p2, -0x1

    iput p2, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/f;->k:I

    iget-object p2, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/f;->e:Ljava/util/ArrayList;

    invoke-virtual {p2, p1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    return-void

    :cond_28
    iget-boolean v1, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/f;->j:Z

    xor-int/2addr v1, v2

    iget-object v2, v0, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/b;->c:Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/X;

    iget-object v3, p1, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/b;->c:Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/X;

    invoke-static {v2, v3, v1, p2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/X;->g(Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/X;Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/X;ZLcom/github/catvod/spider/xbpqxyq/xbpq/S/c;)Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/X;

    move-result-object p2

    iget v1, v0, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/b;->d:I

    iget v2, p1, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/b;->d:I

    invoke-static {v1, v2}, Ljava/lang/Math;->max(II)I

    move-result v1

    iput v1, v0, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/b;->d:I

    invoke-virtual {p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/b;->c()Z

    move-result p1

    if-eqz p1, :cond_4a

    .line 1
    iget p1, v0, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/b;->d:I

    const/high16 v1, 0x40000000  # 2.0f

    or-int/2addr p1, v1

    iput p1, v0, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/b;->d:I

    .line 2
    :cond_4a
    iput-object p2, v0, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/b;->c:Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/X;

    return-void

    :cond_4d
    new-instance p1, Ljava/lang/IllegalStateException;

    const-string p2, "23102C165326120C650C0075051D24011C3B1B01"

    invoke-static {p2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p2

    invoke-direct {p1, p2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p1
.end method

.method public final add(Ljava/lang/Object;)Z
    .registers 3

    check-cast p1, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/b;

    const/4 v0, 0x0

    invoke-virtual {p0, p1, v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/f;->a(Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/b;Lcom/github/catvod/spider/xbpqxyq/xbpq/S/c;)V

    const/4 p1, 0x1

    return p1
.end method

.method public final addAll(Ljava/util/Collection;)Z
    .registers 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/Collection<",
            "+",
            "Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/b;",
            ">;)Z"
        }
    .end annotation

    invoke-interface {p1}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :goto_4
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_15

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/b;

    const/4 v1, 0x0

    invoke-virtual {p0, v0, v1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/f;->a(Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/b;Lcom/github/catvod/spider/xbpqxyq/xbpq/S/c;)V

    goto :goto_4

    :cond_15
    const/4 p1, 0x0

    return p1
.end method

.method public final b(Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/l;)V
    .registers 8

    iget-boolean v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/f;->c:Z

    if-nez v0, :cond_3a

    iget-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/f;->d:Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/e;

    invoke-virtual {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/S/b;->isEmpty()Z

    move-result v0

    if-eqz v0, :cond_d

    return-void

    :cond_d
    iget-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/f;->e:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_13
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_39

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/b;

    iget-object v2, v1, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/b;->c:Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/X;

    .line 1
    iget-object v3, p1, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/l;->b:Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/Y;

    if-nez v3, :cond_26

    goto :goto_33

    :cond_26
    monitor-enter v3

    :try_start_27
    new-instance v4, Ljava/util/IdentityHashMap;

    invoke-direct {v4}, Ljava/util/IdentityHashMap;-><init>()V

    iget-object v5, p1, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/l;->b:Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/Y;

    invoke-static {v2, v5, v4}, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/X;->b(Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/X;Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/Y;Ljava/util/IdentityHashMap;)Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/X;

    move-result-object v2

    monitor-exit v3
    :try_end_33
    .catchall {:try_start_27 .. :try_end_33} :catchall_36

    .line 2
    :goto_33
    iput-object v2, v1, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/b;->c:Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/X;

    goto :goto_13

    :catchall_36
    move-exception p1

    .line 3
    :try_start_37
    monitor-exit v3
    :try_end_38
    .catchall {:try_start_37 .. :try_end_38} :catchall_36

    throw p1

    :cond_39
    return-void

    .line 4
    :cond_3a
    new-instance p1, Ljava/lang/IllegalStateException;

    const-string v0, "23102C165326120C650C0075051D24011C3B1B01"

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    goto :goto_47

    :goto_46
    throw p1

    :goto_47
    goto :goto_46
.end method

.method public final clear()V
    .registers 3

    iget-boolean v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/f;->c:Z

    if-nez v0, :cond_12

    iget-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/f;->e:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V

    const/4 v0, -0x1

    iput v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/f;->k:I

    iget-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/f;->d:Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/e;

    invoke-virtual {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/S/b;->clear()V

    return-void

    :cond_12
    new-instance v0, Ljava/lang/IllegalStateException;

    const-string v1, "23102C165326120C650C0075051D24011C3B1B01"

    invoke-static {v1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method public final contains(Ljava/lang/Object;)Z
    .registers 3

    iget-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/f;->d:Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/e;

    if-eqz v0, :cond_9

    invoke-virtual {v0, p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/S/b;->contains(Ljava/lang/Object;)Z

    move-result p1

    return p1

    :cond_9
    new-instance p1, Ljava/lang/UnsupportedOperationException;

    const-string v0, "23102C165338120C2D0A17751E0B650B1C21571128151F301A1D2B111631571E2A1753271219210A1D390E583600072659"

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-direct {p1, v0}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V

    throw p1
.end method

.method public final containsAll(Ljava/util/Collection;)Z
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/Collection<",
            "*>;)Z"
        }
    .end annotation

    new-instance p1, Ljava/lang/UnsupportedOperationException;

    invoke-direct {p1}, Ljava/lang/UnsupportedOperationException;-><init>()V

    throw p1
.end method

.method public final equals(Ljava/lang/Object;)Z
    .registers 6

    const/4 v0, 0x1

    if-ne p1, p0, :cond_4

    return v0

    :cond_4
    instance-of v1, p1, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/f;

    const/4 v2, 0x0

    if-nez v1, :cond_a

    return v2

    :cond_a
    check-cast p1, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/f;

    iget-object v1, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/f;->e:Ljava/util/ArrayList;

    if-eqz v1, :cond_37

    iget-object v3, p1, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/f;->e:Ljava/util/ArrayList;

    invoke-virtual {v1, v3}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_37

    iget-boolean v1, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/f;->j:Z

    iget-boolean v3, p1, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/f;->j:Z

    if-ne v1, v3, :cond_37

    iget v1, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/f;->f:I

    iget v3, p1, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/f;->f:I

    if-ne v1, v3, :cond_37

    iget-object v1, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/f;->g:Ljava/util/BitSet;

    iget-object v3, p1, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/f;->g:Ljava/util/BitSet;

    if-ne v1, v3, :cond_37

    iget-boolean v1, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/f;->h:Z

    iget-boolean v3, p1, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/f;->h:Z

    if-ne v1, v3, :cond_37

    iget-boolean v1, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/f;->i:Z

    iget-boolean p1, p1, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/f;->i:Z

    if-ne v1, p1, :cond_37

    goto :goto_38

    :cond_37
    const/4 v0, 0x0

    :goto_38
    return v0
.end method

.method public final hashCode()I
    .registers 3

    .line 1
    iget-boolean v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/f;->c:Z

    if-eqz v0, :cond_14

    .line 2
    iget v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/f;->k:I

    const/4 v1, -0x1

    if-ne v0, v1, :cond_11

    iget-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/f;->e:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/lang/Object;->hashCode()I

    move-result v0

    iput v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/f;->k:I

    :cond_11
    iget v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/f;->k:I

    return v0

    :cond_14
    iget-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/f;->e:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/lang/Object;->hashCode()I

    move-result v0

    return v0
.end method

.method public final isEmpty()Z
    .registers 2

    iget-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/f;->e:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v0

    return v0
.end method

.method public final iterator()Ljava/util/Iterator;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Iterator<",
            "Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/b;",
            ">;"
        }
    .end annotation

    iget-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/f;->e:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v0

    return-object v0
.end method

.method public final remove(Ljava/lang/Object;)Z
    .registers 2

    new-instance p1, Ljava/lang/UnsupportedOperationException;

    invoke-direct {p1}, Ljava/lang/UnsupportedOperationException;-><init>()V

    throw p1
.end method

.method public final removeAll(Ljava/util/Collection;)Z
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/Collection<",
            "*>;)Z"
        }
    .end annotation

    new-instance p1, Ljava/lang/UnsupportedOperationException;

    invoke-direct {p1}, Ljava/lang/UnsupportedOperationException;-><init>()V

    throw p1
.end method

.method public final retainAll(Ljava/util/Collection;)Z
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/Collection<",
            "*>;)Z"
        }
    .end annotation

    new-instance p1, Ljava/lang/UnsupportedOperationException;

    invoke-direct {p1}, Ljava/lang/UnsupportedOperationException;-><init>()V

    throw p1
.end method

.method public final size()I
    .registers 2

    iget-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/f;->e:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    return v0
.end method

.method public final toArray()[Ljava/lang/Object;
    .registers 2

    .line 1
    iget-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/f;->d:Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/e;

    invoke-virtual {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/S/b;->toArray()[Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/b;

    return-object v0
.end method

.method public final toArray([Ljava/lang/Object;)[Ljava/lang/Object;
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">([TT;)[TT;"
        }
    .end annotation

    iget-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/f;->d:Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/e;

    invoke-virtual {v0, p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/S/b;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;

    move-result-object p1

    return-object p1
.end method

.method public final toString()Ljava/lang/String;
    .registers 3

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    .line 1
    iget-object v1, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/f;->e:Ljava/util/ArrayList;

    .line 2
    invoke-virtual {v1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-boolean v1, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/f;->h:Z

    if-eqz v1, :cond_20

    const-string v1, "5B10241620301A192B111A3634172B11162D0345"

    invoke-static {v1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-boolean v1, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/f;->h:Z

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    :cond_20
    iget v1, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/f;->f:I

    if-eqz v1, :cond_32

    const-string v1, "5B0D2B0C0220123929114E"

    invoke-static {v1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v1, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/f;->f:I

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    :cond_32
    iget-object v1, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/f;->g:Ljava/util/BitSet;

    if-eqz v1, :cond_44

    const-string v1, "5B1B2A0B15391E1B310C1D32361431164E"

    invoke-static {v1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/f;->g:Ljava/util/BitSet;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    :cond_44
    iget-boolean v1, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/Q/f;->i:Z

    if-eqz v1, :cond_51

    const-string v1, "5B1C2C15001C190C2A2A0621120A060A1D21120031"

    invoke-static {v1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    :cond_51
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method
