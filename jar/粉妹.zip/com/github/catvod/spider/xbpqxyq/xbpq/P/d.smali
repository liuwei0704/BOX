.class public interface abstract Lcom/github/catvod/spider/xbpqxyq/xbpq/P/d;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lcom/github/catvod/spider/xbpqxyq/xbpq/P/r;


# virtual methods
.method public abstract h(Lcom/github/catvod/spider/xbpqxyq/xbpq/S/i;)Ljava/lang/String;
.end method
