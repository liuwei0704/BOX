.class final enum Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/I0;
.super Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/h1;
.source "SourceFile"


# direct methods
.method constructor <init>()V
    .registers 4

    const-string v0, "34172808163B033D2B01"

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/16 v1, 0x30

    const/4 v2, 0x0

    invoke-direct {p0, v0, v1, v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/h1;-><init>(Ljava/lang/String;ILcom/github/catvod/spider/xbpqxyq/xbpq/d0/c0;)V

    return-void
.end method


# virtual methods
.method final g(Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/Q;Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/a;)V
    .registers 7

    sget-object v0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/h1;->c:Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/c0;

    sget-object v1, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/h1;->W:Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/G0;

    invoke-virtual {p2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/a;->e()C

    move-result p2

    const-string v2, "5A55"

    invoke-static {v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    if-eqz p2, :cond_49

    const/16 v3, 0x21

    if-eq p2, v3, :cond_40

    const/16 v3, 0x2d

    if-eq p2, v3, :cond_37

    const/16 v3, 0x3e

    if-eq p2, v3, :cond_30

    const v3, 0xffff

    if-eq p2, v3, :cond_2d

    invoke-virtual {p1, p0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/Q;->q(Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/h1;)V

    iget-object v0, p1, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/Q;->n:Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/I;

    invoke-virtual {v0, v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/I;->j(Ljava/lang/String;)Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/I;

    invoke-virtual {v0, p2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/I;->i(C)Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/I;

    goto :goto_57

    :cond_2d
    invoke-virtual {p1, p0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/Q;->p(Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/h1;)V

    :cond_30
    invoke-virtual {p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/Q;->m()V

    invoke-virtual {p1, v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/Q;->u(Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/h1;)V

    goto :goto_5a

    :cond_37
    invoke-virtual {p1, p0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/Q;->q(Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/h1;)V

    iget-object p1, p1, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/Q;->n:Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/I;

    invoke-virtual {p1, v3}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/I;->i(C)Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/I;

    goto :goto_5a

    :cond_40
    invoke-virtual {p1, p0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/Q;->q(Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/h1;)V

    sget-object p2, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/h1;->Z:Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/K0;

    invoke-virtual {p1, p2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/Q;->u(Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/h1;)V

    goto :goto_5a

    :cond_49
    invoke-virtual {p1, p0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/Q;->q(Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/h1;)V

    iget-object p2, p1, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/Q;->n:Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/I;

    invoke-virtual {p2, v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/I;->j(Ljava/lang/String;)Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/I;

    const v0, 0xfffd

    invoke-virtual {p2, v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/I;->i(C)Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/I;

    :goto_57
    invoke-virtual {p1, v1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/Q;->u(Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/h1;)V

    :goto_5a
    return-void
.end method
