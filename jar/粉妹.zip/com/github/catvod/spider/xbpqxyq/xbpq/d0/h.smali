.class final enum Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/h;
.super Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/A;
.source "SourceFile"


# direct methods
.method constructor <init>()V
    .registers 4

    const-string v0, "3E1606001F39"

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/16 v1, 0xe

    const/4 v2, 0x0

    invoke-direct {p0, v0, v1, v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/A;-><init>(Ljava/lang/String;ILcom/github/catvod/spider/xbpqxyq/xbpq/d0/m;)V

    return-void
.end method


# virtual methods
.method final d(Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/O;Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b;)Z
    .registers 10

    sget-object v0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/A;->p:Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/g;

    sget-object v1, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/A;->i:Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/w;

    invoke-virtual {p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/O;->e()Z

    move-result v2

    const-string v3, "0310"

    invoke-static {v3}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    const-string v4, "031C"

    invoke-static {v4}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    const/4 v5, 0x0

    if-eqz v2, :cond_7f

    .line 1
    move-object v2, p1

    check-cast v2, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/L;

    .line 2
    iget-object v2, v2, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/N;->c:Ljava/lang/String;

    .line 3
    sget-object v6, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/z;->x:[Ljava/lang/String;

    invoke-static {v2, v6}, Lcom/github/catvod/spider/xbpqxyq/xbpq/b0/b;->b(Ljava/lang/String;[Ljava/lang/String;)Z

    move-result v6

    if-eqz v6, :cond_4d

    invoke-virtual {p2, v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b;->B(Ljava/lang/String;)Z

    move-result p1

    if-nez p1, :cond_31

    invoke-virtual {p2, p0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b;->n(Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/A;)V

    invoke-virtual {p2, v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b;->j0(Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/A;)V

    return v5

    :cond_31
    invoke-virtual {p2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/i1;->a()Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/l;

    move-result-object p1

    invoke-virtual {p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/l;->d0()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-nez p1, :cond_42

    invoke-virtual {p2, p0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b;->n(Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/A;)V

    :cond_42
    invoke-virtual {p2, v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b;->V(Ljava/lang/String;)Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/l;

    invoke-virtual {p2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b;->i()V

    invoke-virtual {p2, v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b;->j0(Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/A;)V

    const/4 p1, 0x1

    return p1

    :cond_4d
    sget-object v0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/z;->y:[Ljava/lang/String;

    invoke-static {v2, v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/b0/b;->b(Ljava/lang/String;[Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_59

    invoke-virtual {p2, p0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b;->n(Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/A;)V

    return v5

    :cond_59
    sget-object v0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/z;->z:[Ljava/lang/String;

    invoke-static {v2, v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/b0/b;->b(Ljava/lang/String;[Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_7a

    invoke-virtual {p2, v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b;->B(Ljava/lang/String;)Z

    move-result v0

    if-nez v0, :cond_6b

    invoke-virtual {p2, p0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b;->n(Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/A;)V

    return v5

    .line 4
    :cond_6b
    invoke-virtual {p2, v4}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b;->B(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_72

    move-object v3, v4

    :cond_72
    invoke-virtual {p2, v3}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/i1;->d(Ljava/lang/String;)Z

    .line 5
    invoke-virtual {p2, p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b;->c(Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/O;)Z

    move-result p1

    return p1

    .line 6
    :cond_7a
    invoke-virtual {p2, p1, v1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b;->X(Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/O;Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/A;)Z

    move-result p1

    return p1

    .line 7
    :cond_7f
    invoke-virtual {p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/O;->f()Z

    move-result v0

    if-eqz v0, :cond_b1

    .line 8
    move-object v0, p1

    check-cast v0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/M;

    .line 9
    iget-object v0, v0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/N;->c:Ljava/lang/String;

    .line 10
    sget-object v2, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/z;->A:[Ljava/lang/String;

    invoke-static {v0, v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/b0/b;->b(Ljava/lang/String;[Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_b1

    invoke-virtual {p2, v4}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b;->B(Ljava/lang/String;)Z

    move-result v0

    if-nez v0, :cond_a2

    invoke-virtual {p2, v3}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b;->B(Ljava/lang/String;)Z

    move-result v0

    if-nez v0, :cond_a2

    invoke-virtual {p2, p0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b;->n(Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/A;)V

    return v5

    .line 11
    :cond_a2
    invoke-virtual {p2, v4}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b;->B(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_a9

    move-object v3, v4

    :cond_a9
    invoke-virtual {p2, v3}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/i1;->d(Ljava/lang/String;)Z

    .line 12
    invoke-virtual {p2, p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b;->c(Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/O;)Z

    move-result p1

    return p1

    .line 13
    :cond_b1
    invoke-virtual {p2, p1, v1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b;->X(Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/O;Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/A;)Z

    move-result p1

    return p1
.end method
