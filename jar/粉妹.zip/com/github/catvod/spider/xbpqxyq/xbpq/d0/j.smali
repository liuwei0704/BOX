.class final enum Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/j;
.super Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/A;
.source "SourceFile"


# direct methods
.method constructor <init>()V
    .registers 4

    const-string v0, "3E1616001F30140C0C0B2734151420"

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/16 v1, 0x10

    const/4 v2, 0x0

    invoke-direct {p0, v0, v1, v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/A;-><init>(Ljava/lang/String;ILcom/github/catvod/spider/xbpqxyq/xbpq/d0/m;)V

    return-void
.end method


# virtual methods
.method final d(Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/O;Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b;)Z
    .registers 7

    invoke-virtual {p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/O;->f()Z

    move-result v0

    const-string v1, "041D29001021"

    invoke-static {v1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    if-eqz v0, :cond_24

    .line 1
    move-object v0, p1

    check-cast v0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/M;

    .line 2
    iget-object v0, v0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/N;->c:Ljava/lang/String;

    .line 3
    sget-object v2, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/z;->I:[Ljava/lang/String;

    invoke-static {v0, v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/b0/b;->b(Ljava/lang/String;[Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_24

    invoke-virtual {p2, p0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b;->n(Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/A;)V

    invoke-virtual {p2, v1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/i1;->d(Ljava/lang/String;)Z

    invoke-virtual {p2, p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b;->c(Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/O;)Z

    move-result p1

    return p1

    :cond_24
    invoke-virtual {p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/O;->e()Z

    move-result v0

    if-eqz v0, :cond_4c

    .line 4
    move-object v0, p1

    check-cast v0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/L;

    .line 5
    iget-object v2, v0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/N;->c:Ljava/lang/String;

    .line 6
    sget-object v3, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/z;->I:[Ljava/lang/String;

    invoke-static {v2, v3}, Lcom/github/catvod/spider/xbpqxyq/xbpq/b0/b;->b(Ljava/lang/String;[Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_4c

    invoke-virtual {p2, p0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b;->n(Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/A;)V

    .line 7
    iget-object v0, v0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/N;->c:Ljava/lang/String;

    .line 8
    invoke-virtual {p2, v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b;->B(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_4a

    invoke-virtual {p2, v1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/i1;->d(Ljava/lang/String;)Z

    invoke-virtual {p2, p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b;->c(Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/O;)Z

    move-result p1

    return p1

    :cond_4a
    const/4 p1, 0x0

    return p1

    :cond_4c
    sget-object v0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/A;->r:Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/i;

    invoke-virtual {p2, p1, v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b;->X(Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/O;Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/A;)Z

    move-result p1

    return p1
.end method
