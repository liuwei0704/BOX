.class public final Lcom/github/catvod/spider/xbpqxyq/xbpq/P/t;
.super Lcom/github/catvod/spider/xbpqxyq/xbpq/P/z;
.source "SourceFile"


# instance fields
.field private final h:I


# direct methods
.method public constructor <init>(Lcom/github/catvod/spider/xbpqxyq/xbpq/P/s;Lcom/github/catvod/spider/xbpqxyq/xbpq/P/d;I)V
    .registers 5

    const/4 v0, 0x0

    invoke-direct {p0, p1, p2, v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/z;-><init>(Lcom/github/catvod/spider/xbpqxyq/xbpq/P/B;Lcom/github/catvod/spider/xbpqxyq/xbpq/P/r;Lcom/github/catvod/spider/xbpqxyq/xbpq/P/x;)V

    iput p3, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/t;->h:I

    return-void
.end method


# virtual methods
.method public final toString()Ljava/lang/String;
    .registers 8

    iget v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/t;->h:I

    const/4 v1, 0x0

    if-ltz v0, :cond_61

    .line 1
    invoke-virtual {p0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/z;->b()Lcom/github/catvod/spider/xbpqxyq/xbpq/P/r;

    move-result-object v2

    check-cast v2, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/d;

    .line 2
    invoke-interface {v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/r;->size()I

    move-result v2

    if-ge v0, v2, :cond_61

    .line 3
    invoke-virtual {p0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/z;->b()Lcom/github/catvod/spider/xbpqxyq/xbpq/P/r;

    move-result-object v0

    check-cast v0, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/d;

    .line 4
    iget v2, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/t;->h:I

    invoke-static {v2, v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/S/i;->b(II)Lcom/github/catvod/spider/xbpqxyq/xbpq/S/i;

    move-result-object v2

    invoke-interface {v0, v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/d;->h(Lcom/github/catvod/spider/xbpqxyq/xbpq/S/i;)Ljava/lang/String;

    move-result-object v0

    .line 5
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v0}, Ljava/lang/String;->toCharArray()[C

    move-result-object v0

    array-length v3, v0

    const/4 v4, 0x0

    :goto_2c
    if-ge v4, v3, :cond_5c

    aget-char v5, v0, v4

    const/16 v6, 0x20

    const/16 v6, 0x9

    if-ne v5, v6, :cond_3d

    const-string v5, "2B0C"

    invoke-static {v5}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    goto :goto_52

    :cond_3d
    const/16 v6, 0xa

    if-ne v5, v6, :cond_48

    const-string v5, "2B16"

    invoke-static {v5}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    goto :goto_52

    :cond_48
    const/16 v6, 0xd

    if-ne v5, v6, :cond_56

    const-string v5, "2B0A"

    invoke-static {v5}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    :goto_52
    invoke-virtual {v2, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    goto :goto_59

    :cond_56
    invoke-virtual {v2, v5}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    :goto_59
    add-int/lit8 v4, v4, 0x1

    goto :goto_2c

    :cond_5c
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    goto :goto_63

    :cond_61
    const-string v0, ""

    .line 6
    :goto_63
    invoke-static {}, Ljava/util/Locale;->getDefault()Ljava/util/Locale;

    move-result-object v2

    const/4 v3, 0x2

    new-array v3, v3, [Ljava/lang/Object;

    const-class v4, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/t;

    invoke-virtual {v4}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    move-result-object v4

    aput-object v4, v3, v1

    const/4 v1, 0x1

    aput-object v0, v3, v1

    const-string v0, "520B6D4256265051"

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-static {v2, v0, v3}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method
