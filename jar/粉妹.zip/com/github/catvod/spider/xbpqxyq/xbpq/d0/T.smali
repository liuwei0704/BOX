.class final enum Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/T;
.super Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/h1;
.source "SourceFile"


# direct methods
.method constructor <init>()V
    .registers 4

    const-string v0, "251B210407343B1D3616073D1616160C143B"

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/16 v1, 0xa

    const/4 v2, 0x0

    invoke-direct {p0, v0, v1, v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/h1;-><init>(Ljava/lang/String;ILcom/github/catvod/spider/xbpqxyq/xbpq/d0/c0;)V

    return-void
.end method


# virtual methods
.method final g(Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/Q;Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/a;)V
    .registers 7

    const/16 v0, 0x2f

    invoke-virtual {p2, v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/a;->y(C)Z

    move-result v0

    if-eqz v0, :cond_11

    invoke-virtual {p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/Q;->h()V

    sget-object p2, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/h1;->n:Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/U;

    invoke-virtual {p1, p2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/Q;->a(Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/h1;)V

    goto :goto_71

    :cond_11
    invoke-virtual {p2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/a;->C()Z

    move-result v0

    if-eqz v0, :cond_63

    invoke-virtual {p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/Q;->b()Ljava/lang/String;

    move-result-object v0

    if-eqz v0, :cond_63

    const-string v0, "4B57"

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 1
    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d/d;->b(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    .line 2
    invoke-virtual {p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/Q;->b()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    .line 3
    sget-object v1, Ljava/util/Locale;->ENGLISH:Ljava/util/Locale;

    invoke-virtual {v0, v1}, Ljava/lang/String;->toLowerCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v1}, Ljava/lang/String;->toUpperCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p2, v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/a;->D(Ljava/lang/CharSequence;)I

    move-result v1

    const/4 v2, -0x1

    const/4 v3, 0x0

    if-gt v1, v2, :cond_4d

    invoke-virtual {p2, v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/a;->D(Ljava/lang/CharSequence;)I

    move-result p2

    if-le p2, v2, :cond_4b

    goto :goto_4d

    :cond_4b
    const/4 p2, 0x0

    goto :goto_4e

    :cond_4d
    :goto_4d
    const/4 p2, 0x1

    :goto_4e
    if-nez p2, :cond_63

    .line 4
    invoke-virtual {p1, v3}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/Q;->g(Z)Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/N;

    move-result-object p2

    invoke-virtual {p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/Q;->b()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p2, v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/N;->s(Ljava/lang/String;)Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/N;

    iput-object p2, p1, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/Q;->i:Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/N;

    invoke-virtual {p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/Q;->o()V

    sget-object p2, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/h1;->j:Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/f1;

    goto :goto_6e

    :cond_63
    const-string p2, "4B"

    invoke-static {p2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p2

    invoke-virtual {p1, p2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/Q;->k(Ljava/lang/String;)V

    sget-object p2, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/h1;->e:Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/y0;

    :goto_6e
    invoke-virtual {p1, p2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/Q;->u(Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/h1;)V

    :goto_71
    return-void
.end method
