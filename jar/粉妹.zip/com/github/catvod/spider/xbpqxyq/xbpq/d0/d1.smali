.class final enum Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/d1;
.super Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/h1;
.source "SourceFile"


# direct methods
.method constructor <init>()V
    .registers 4

    const-string v0, "241B370C032133193104"

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v1, 0x5

    const/4 v2, 0x0

    invoke-direct {p0, v0, v1, v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/h1;-><init>(Ljava/lang/String;ILcom/github/catvod/spider/xbpqxyq/xbpq/d0/c0;)V

    return-void
.end method


# virtual methods
.method final g(Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/Q;Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/a;)V
    .registers 4

    sget-object v0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/h1;->s:Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/Z;

    invoke-static {p1, p2, p0, v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/h1;->b(Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/Q;Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/a;Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/h1;Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/h1;)V

    return-void
.end method
