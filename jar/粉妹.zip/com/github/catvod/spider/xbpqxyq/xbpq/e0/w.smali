.class public abstract Lcom/github/catvod/spider/xbpqxyq/xbpq/e0/w;
.super Lcom/github/catvod/spider/xbpqxyq/xbpq/e0/N;
.source "SourceFile"


# instance fields
.field a:I


# direct methods
.method public constructor <init>(I)V
    .registers 2

    invoke-direct {p0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/e0/N;-><init>()V

    iput p1, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/e0/w;->a:I

    return-void
.end method
