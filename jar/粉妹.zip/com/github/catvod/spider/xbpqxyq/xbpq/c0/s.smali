.class final Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/s;
.super Ljava/lang/Object;
.source "SourceFile"


# direct methods
.method static a(Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/r;)Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/E;
    .registers 2

    invoke-virtual {p0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/r;->y()Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/h;

    move-result-object p0

    if-eqz p0, :cond_11

    invoke-virtual {p0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/h;->u0()Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/E;

    move-result-object v0

    if-eqz v0, :cond_11

    invoke-virtual {p0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/h;->u0()Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/E;

    move-result-object p0

    goto :goto_1b

    :cond_11
    new-instance p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/E;

    new-instance v0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b;

    invoke-direct {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b;-><init>()V

    invoke-direct {p0, v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/E;-><init>(Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/i1;)V

    :goto_1b
    return-object p0
.end method
