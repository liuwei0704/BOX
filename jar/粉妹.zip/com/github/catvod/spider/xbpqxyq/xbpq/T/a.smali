.class public final Lcom/github/catvod/spider/xbpqxyq/xbpq/T/a;
.super Lcom/github/catvod/spider/xbpqxyq/xbpq/T/g;
.source "SourceFile"


# direct methods
.method public constructor <init>(Lcom/github/catvod/spider/xbpqxyq/xbpq/P/D;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/T/g;-><init>(Lcom/github/catvod/spider/xbpqxyq/xbpq/P/D;)V

    return-void
.end method


# virtual methods
.method public final e(Lcom/github/catvod/spider/xbpqxyq/xbpq/T/d;)Ljava/lang/Object;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Lcom/github/catvod/spider/xbpqxyq/xbpq/T/d<",
            "+TT;>;)TT;"
        }
    .end annotation

    invoke-interface {p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/T/d;->a()V

    const/4 p1, 0x0

    return-object p1
.end method
