.class public final Lcom/github/catvod/spider/xbpqxyq/xbpq/P/u;
.super Lcom/github/catvod/spider/xbpqxyq/xbpq/P/z;
.source "SourceFile"


# instance fields
.field private final h:Lcom/github/catvod/spider/xbpqxyq/xbpq/P/D;


# direct methods
.method public constructor <init>(Lcom/github/catvod/spider/xbpqxyq/xbpq/P/w;)V
    .registers 6

    .line 1
    iget-object v0, p1, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/w;->e:Lcom/github/catvod/spider/xbpqxyq/xbpq/P/G;

    .line 2
    invoke-virtual {p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/w;->q()Lcom/github/catvod/spider/xbpqxyq/xbpq/P/D;

    move-result-object v1

    invoke-virtual {p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/w;->q()Lcom/github/catvod/spider/xbpqxyq/xbpq/P/D;

    move-result-object v2

    iget-object v3, p1, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/w;->g:Lcom/github/catvod/spider/xbpqxyq/xbpq/P/x;

    .line 3
    invoke-direct {p0, p1, v0, v3}, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/z;-><init>(Lcom/github/catvod/spider/xbpqxyq/xbpq/P/B;Lcom/github/catvod/spider/xbpqxyq/xbpq/P/r;Lcom/github/catvod/spider/xbpqxyq/xbpq/P/x;)V

    iput-object v1, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/u;->h:Lcom/github/catvod/spider/xbpqxyq/xbpq/P/D;

    invoke-virtual {p0, v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/z;->e(Lcom/github/catvod/spider/xbpqxyq/xbpq/P/D;)V

    return-void
.end method

.method public constructor <init>(Lcom/github/catvod/spider/xbpqxyq/xbpq/P/w;Lcom/github/catvod/spider/xbpqxyq/xbpq/P/G;Lcom/github/catvod/spider/xbpqxyq/xbpq/P/D;Lcom/github/catvod/spider/xbpqxyq/xbpq/P/D;Lcom/github/catvod/spider/xbpqxyq/xbpq/P/x;)V
    .registers 6

    invoke-direct {p0, p1, p2, p5}, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/z;-><init>(Lcom/github/catvod/spider/xbpqxyq/xbpq/P/B;Lcom/github/catvod/spider/xbpqxyq/xbpq/P/r;Lcom/github/catvod/spider/xbpqxyq/xbpq/P/x;)V

    iput-object p3, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/u;->h:Lcom/github/catvod/spider/xbpqxyq/xbpq/P/D;

    invoke-virtual {p0, p4}, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/z;->e(Lcom/github/catvod/spider/xbpqxyq/xbpq/P/D;)V

    return-void
.end method


# virtual methods
.method public final f()Lcom/github/catvod/spider/xbpqxyq/xbpq/P/D;
    .registers 2

    iget-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/u;->h:Lcom/github/catvod/spider/xbpqxyq/xbpq/P/D;

    return-object v0
.end method
