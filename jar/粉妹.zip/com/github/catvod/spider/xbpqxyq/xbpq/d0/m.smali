.class final enum Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/m;
.super Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/A;
.source "SourceFile"


# direct methods
.method constructor <init>()V
    .registers 4

    const-string v0, "3E162C111A341B"

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v1, 0x0

    const/4 v2, 0x0

    invoke-direct {p0, v0, v1, v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/A;-><init>(Ljava/lang/String;ILcom/github/catvod/spider/xbpqxyq/xbpq/d0/m;)V

    return-void
.end method


# virtual methods
.method final d(Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/O;Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b;)Z
    .registers 9

    sget-object v0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/A;->d:Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/r;

    invoke-static {p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/A;->a(Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/O;)Z

    move-result v1

    const/4 v2, 0x1

    if-eqz v1, :cond_a

    return v2

    :cond_a
    invoke-virtual {p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/O;->b()Z

    move-result v1

    if-eqz v1, :cond_16

    .line 1
    check-cast p1, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/I;

    .line 2
    invoke-virtual {p2, p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b;->F(Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/I;)V

    goto :goto_51

    :cond_16
    invoke-virtual {p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/O;->c()Z

    move-result v1

    if-eqz v1, :cond_52

    .line 3
    check-cast p1, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/J;

    .line 4
    new-instance v1, Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/i;

    iget-object v3, p2, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/i1;->h:Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/D;

    .line 5
    iget-object v4, p1, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/J;->b:Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    .line 6
    invoke-virtual {v3, v4}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/D;->c(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    .line 7
    iget-object v4, p1, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/J;->d:Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    .line 8
    iget-object v5, p1, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/J;->e:Ljava/lang/StringBuilder;

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    .line 9
    invoke-direct {v1, v3, v4, v5}, Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/i;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 10
    iget-object v3, p1, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/J;->c:Ljava/lang/String;

    .line 11
    invoke-virtual {v1, v3}, Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/i;->L(Ljava/lang/String;)V

    .line 12
    iget-object v3, p2, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/i1;->d:Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/h;

    .line 13
    invoke-virtual {v3, v1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/l;->L(Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/r;)Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/l;

    .line 14
    iget-boolean p1, p1, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/J;->f:Z

    if-eqz p1, :cond_4e

    .line 15
    iget-object p1, p2, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/i1;->d:Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/h;

    .line 16
    invoke-virtual {p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/h;->v0()Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/h;

    :cond_4e
    invoke-virtual {p2, v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b;->j0(Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/A;)V

    :goto_51
    return v2

    :cond_52
    invoke-virtual {p2, v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b;->j0(Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/A;)V

    invoke-virtual {p2, p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b;->c(Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/O;)Z

    move-result p1

    return p1
.end method
