.class public final synthetic Lcom/github/catvod/spider/xbpqxyq/xbpq/b/k;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic c:I

.field public final synthetic d:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(Ljava/lang/Object;I)V
    .registers 3

    iput p2, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/k;->c:I

    iput-object p1, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/k;->d:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 4

    iget v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/k;->c:I

    packed-switch v0, :pswitch_data_20

    goto :goto_e

    :pswitch_6  #0x0
    iget-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/k;->d:Ljava/lang/Object;

    check-cast v0, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;->d(Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;)V

    return-void

    :goto_e
    iget-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/k;->d:Ljava/lang/Object;

    check-cast v0, Ljava/lang/String;

    invoke-static {}, Lcom/github/catvod/spider/Init;->context()Landroid/app/Application;

    move-result-object v1

    const/4 v2, 0x1

    invoke-static {v1, v0, v2}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    return-void

    nop

    :pswitch_data_20
    .packed-switch 0x0
        :pswitch_6  #00000000
    .end packed-switch
.end method
