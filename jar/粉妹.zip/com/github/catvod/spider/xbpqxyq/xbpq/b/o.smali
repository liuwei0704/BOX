.class final Lcom/github/catvod/spider/xbpqxyq/xbpq/b/o;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field static volatile a:Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    new-instance v0, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;

    invoke-direct {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;-><init>()V

    sput-object v0, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/o;->a:Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;

    return-void
.end method
