.class public final synthetic Lcom/github/catvod/spider/xbpqxyq/xbpq/b/h;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/content/DialogInterface$OnDismissListener;


# instance fields
.field public final synthetic a:Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;


# direct methods
.method public synthetic constructor <init>(Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;)V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/h;->a:Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;

    return-void
.end method


# virtual methods
.method public final onDismiss(Landroid/content/DialogInterface;)V
    .registers 2

    iget-object p1, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/h;->a:Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;

    invoke-static {p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;->i(Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;)V

    return-void
.end method
