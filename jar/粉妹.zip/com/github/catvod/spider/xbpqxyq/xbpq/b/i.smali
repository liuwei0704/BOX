.class public final synthetic Lcom/github/catvod/spider/xbpqxyq/xbpq/b/i;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic c:I

.field public final synthetic d:Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;


# direct methods
.method public synthetic constructor <init>(Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;I)V
    .registers 3

    iput p2, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/i;->c:I

    iput-object p1, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/i;->d:Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 2

    iget v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/i;->c:I

    packed-switch v0, :pswitch_data_12

    goto :goto_c

    :pswitch_6  #0x0
    iget-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/i;->d:Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;->d(Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;)V

    return-void

    :goto_c
    iget-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/i;->d:Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;->a(Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;)V

    return-void

    :pswitch_data_12
    .packed-switch 0x0
        :pswitch_6  #00000000
    .end packed-switch
.end method
