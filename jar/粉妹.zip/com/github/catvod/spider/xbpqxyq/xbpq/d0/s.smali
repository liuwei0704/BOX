.class final enum Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/s;
.super Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/A;
.source "SourceFile"


# direct methods
.method constructor <init>()V
    .registers 4

    const-string v0, "351D230A01303F1D2401"

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v1, 0x2

    const/4 v2, 0x0

    invoke-direct {p0, v0, v1, v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/A;-><init>(Ljava/lang/String;ILcom/github/catvod/spider/xbpqxyq/xbpq/d0/m;)V

    return-void
.end method


# virtual methods
.method final d(Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/O;Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b;)Z
    .registers 7

    invoke-static {p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/A;->a(Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/O;)Z

    move-result v0

    if-eqz v0, :cond_c

    .line 1
    check-cast p1, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/H;

    .line 2
    invoke-virtual {p2, p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b;->E(Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/H;)V

    goto :goto_64

    :cond_c
    invoke-virtual {p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/O;->b()Z

    move-result v0

    if-eqz v0, :cond_18

    .line 3
    check-cast p1, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/I;

    .line 4
    invoke-virtual {p2, p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b;->F(Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/I;)V

    goto :goto_64

    :cond_18
    invoke-virtual {p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/O;->c()Z

    move-result v0

    const/4 v1, 0x0

    if-eqz v0, :cond_23

    invoke-virtual {p2, p0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b;->n(Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/A;)V

    return v1

    :cond_23
    invoke-virtual {p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/O;->f()Z

    move-result v0

    if-eqz v0, :cond_41

    .line 5
    move-object v0, p1

    check-cast v0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/M;

    .line 6
    iget-object v0, v0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/N;->c:Ljava/lang/String;

    const-string v2, "1F0C2809"

    invoke-static {v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    .line 7
    invoke-virtual {v0, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_41

    sget-object v0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/A;->i:Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/w;

    invoke-virtual {v0, p1, p2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/w;->d(Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/O;Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b;)Z

    move-result p1

    return p1

    :cond_41
    invoke-virtual {p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/O;->f()Z

    move-result v0

    const-string v2, "1F1D2401"

    invoke-static {v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    if-eqz v0, :cond_66

    .line 8
    move-object v0, p1

    check-cast v0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/M;

    .line 9
    iget-object v3, v0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/N;->c:Ljava/lang/String;

    .line 10
    invoke-virtual {v3, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_66

    invoke-virtual {p2, v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b;->D(Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/M;)Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/l;

    move-result-object p1

    invoke-virtual {p2, p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b;->h0(Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/l;)V

    sget-object p1, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/A;->f:Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/t;

    invoke-virtual {p2, p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b;->j0(Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/A;)V

    :goto_64
    const/4 p1, 0x1

    return p1

    :cond_66
    invoke-virtual {p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/O;->e()Z

    move-result v0

    if-eqz v0, :cond_81

    .line 11
    move-object v0, p1

    check-cast v0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/L;

    .line 12
    iget-object v0, v0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/N;->c:Ljava/lang/String;

    .line 13
    sget-object v3, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/z;->e:[Ljava/lang/String;

    invoke-static {v0, v3}, Lcom/github/catvod/spider/xbpqxyq/xbpq/b0/b;->b(Ljava/lang/String;[Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_81

    invoke-virtual {p2, v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/i1;->f(Ljava/lang/String;)Z

    invoke-virtual {p2, p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b;->c(Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/O;)Z

    move-result p1

    return p1

    :cond_81
    invoke-virtual {p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/O;->e()Z

    move-result v0

    if-eqz v0, :cond_8b

    invoke-virtual {p2, p0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b;->n(Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/A;)V

    return v1

    :cond_8b
    invoke-virtual {p2, v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/i1;->f(Ljava/lang/String;)Z

    invoke-virtual {p2, p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b;->c(Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/O;)Z

    move-result p1

    return p1
.end method
