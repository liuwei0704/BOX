.class final Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/q;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lcom/github/catvod/spider/xbpqxyq/xbpq/e0/O;


# instance fields
.field private final a:Ljava/lang/Appendable;

.field private final b:Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/g;


# direct methods
.method constructor <init>(Ljava/lang/Appendable;Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/g;)V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/q;->a:Ljava/lang/Appendable;

    iput-object p2, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/q;->b:Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/g;

    invoke-virtual {p2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/g;->e()Ljava/nio/charset/CharsetEncoder;

    return-void
.end method


# virtual methods
.method public final a(Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/r;I)V
    .registers 5

    :try_start_0
    iget-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/q;->a:Ljava/lang/Appendable;

    iget-object v1, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/q;->b:Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/g;

    invoke-virtual {p1, v0, p2, v1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/r;->w(Ljava/lang/Appendable;ILcom/github/catvod/spider/xbpqxyq/xbpq/c0/g;)V
    :try_end_7
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_7} :catch_8

    return-void

    :catch_8
    move-exception p1

    new-instance p2, Lcom/github/catvod/spider/xbpqxyq/xbpq/Z/a;

    invoke-direct {p2, p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/Z/a;-><init>(Ljava/lang/Throwable;)V

    throw p2
.end method

.method public final b(Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/r;I)V
    .registers 5

    invoke-virtual {p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/r;->t()Ljava/lang/String;

    move-result-object v0

    const-string v1, "540C201D07"

    invoke-static {v1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_1f

    :try_start_10
    iget-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/q;->a:Ljava/lang/Appendable;

    iget-object v1, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/q;->b:Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/g;

    invoke-virtual {p1, v0, p2, v1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/r;->x(Ljava/lang/Appendable;ILcom/github/catvod/spider/xbpqxyq/xbpq/c0/g;)V
    :try_end_17
    .catch Ljava/io/IOException; {:try_start_10 .. :try_end_17} :catch_18

    goto :goto_1f

    :catch_18
    move-exception p1

    new-instance p2, Lcom/github/catvod/spider/xbpqxyq/xbpq/Z/a;

    invoke-direct {p2, p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/Z/a;-><init>(Ljava/lang/Throwable;)V

    throw p2

    :cond_1f
    :goto_1f
    return-void
.end method
