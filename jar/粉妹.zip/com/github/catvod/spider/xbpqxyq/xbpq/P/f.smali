.class public final Lcom/github/catvod/spider/xbpqxyq/xbpq/P/f;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field private final a:I

.field private final b:Ljava/nio/ByteBuffer;

.field private final c:Ljava/nio/CharBuffer;

.field private final d:Ljava/nio/IntBuffer;


# direct methods
.method constructor <init>(ILjava/nio/ByteBuffer;Ljava/nio/CharBuffer;Ljava/nio/IntBuffer;)V
    .registers 5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput p1, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/f;->a:I

    iput-object p2, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/f;->b:Ljava/nio/ByteBuffer;

    iput-object p3, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/f;->c:Ljava/nio/CharBuffer;

    iput-object p4, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/f;->d:Ljava/nio/IntBuffer;

    return-void
.end method

.method public static b(I)Lcom/github/catvod/spider/xbpqxyq/xbpq/P/e;
    .registers 2

    new-instance v0, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/e;

    invoke-direct {v0, p0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/e;-><init>(I)V

    return-object v0
.end method


# virtual methods
.method final a()I
    .registers 3

    iget v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/f;->a:I

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/l/a;->a(I)I

    move-result v0

    if-eqz v0, :cond_28

    const/4 v1, 0x1

    if-eq v0, v1, :cond_21

    const/4 v1, 0x2

    if-ne v0, v1, :cond_15

    iget-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/f;->d:Ljava/nio/IntBuffer;

    invoke-virtual {v0}, Ljava/nio/IntBuffer;->arrayOffset()I

    move-result v0

    return v0

    :cond_15
    new-instance v0, Ljava/lang/UnsupportedOperationException;

    const-string v1, "391731450130161B2D0017"

    invoke-static {v1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_21
    iget-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/f;->c:Ljava/nio/CharBuffer;

    invoke-virtual {v0}, Ljava/nio/CharBuffer;->arrayOffset()I

    move-result v0

    return v0

    :cond_28
    iget-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/f;->b:Ljava/nio/ByteBuffer;

    invoke-virtual {v0}, Ljava/nio/ByteBuffer;->arrayOffset()I

    move-result v0

    return v0
.end method

.method final c()[B
    .registers 2

    iget-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/f;->b:Ljava/nio/ByteBuffer;

    invoke-virtual {v0}, Ljava/nio/ByteBuffer;->array()[B

    move-result-object v0

    return-object v0
.end method

.method final d()[C
    .registers 2

    iget-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/f;->c:Ljava/nio/CharBuffer;

    invoke-virtual {v0}, Ljava/nio/CharBuffer;->array()[C

    move-result-object v0

    return-object v0
.end method

.method final e()I
    .registers 2

    iget v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/f;->a:I

    return v0
.end method

.method final f()[I
    .registers 2

    iget-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/f;->d:Ljava/nio/IntBuffer;

    invoke-virtual {v0}, Ljava/nio/IntBuffer;->array()[I

    move-result-object v0

    return-object v0
.end method

.method public final g()I
    .registers 3

    iget v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/f;->a:I

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/l/a;->a(I)I

    move-result v0

    if-eqz v0, :cond_24

    const/4 v1, 0x1

    if-eq v0, v1, :cond_21

    const/4 v1, 0x2

    if-ne v0, v1, :cond_15

    iget-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/f;->d:Ljava/nio/IntBuffer;

    :goto_10
    invoke-virtual {v0}, Ljava/nio/Buffer;->position()I

    move-result v0

    return v0

    :cond_15
    new-instance v0, Ljava/lang/UnsupportedOperationException;

    const-string v1, "391731450130161B2D0017"

    invoke-static {v1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_21
    iget-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/f;->c:Ljava/nio/CharBuffer;

    goto :goto_10

    :cond_24
    iget-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/f;->b:Ljava/nio/ByteBuffer;

    goto :goto_10
.end method

.method public final h()I
    .registers 3

    iget v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/f;->a:I

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/l/a;->a(I)I

    move-result v0

    if-eqz v0, :cond_24

    const/4 v1, 0x1

    if-eq v0, v1, :cond_21

    const/4 v1, 0x2

    if-ne v0, v1, :cond_15

    iget-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/f;->d:Ljava/nio/IntBuffer;

    :goto_10
    invoke-virtual {v0}, Ljava/nio/Buffer;->remaining()I

    move-result v0

    return v0

    :cond_15
    new-instance v0, Ljava/lang/UnsupportedOperationException;

    const-string v1, "391731450130161B2D0017"

    invoke-static {v1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_21
    iget-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/f;->c:Ljava/nio/CharBuffer;

    goto :goto_10

    :cond_24
    iget-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/P/f;->b:Ljava/nio/ByteBuffer;

    goto :goto_10
.end method
