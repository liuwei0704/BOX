.class final enum Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/b0;
.super Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/h1;
.source "SourceFile"


# direct methods
.method constructor <init>()V
    .registers 4

    const-string v0, "241B370C032133193104363B132C24023D341A1D"

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/16 v1, 0x12

    const/4 v2, 0x0

    invoke-direct {p0, v0, v1, v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/h1;-><init>(Ljava/lang/String;ILcom/github/catvod/spider/xbpqxyq/xbpq/d0/c0;)V

    return-void
.end method


# virtual methods
.method final g(Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/Q;Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/a;)V
    .registers 4

    sget-object v0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/h1;->h:Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/d1;

    invoke-static {p1, p2, v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/h1;->e(Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/Q;Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/a;Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/h1;)V

    return-void
.end method
