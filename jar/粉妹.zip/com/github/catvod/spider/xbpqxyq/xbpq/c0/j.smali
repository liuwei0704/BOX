.class final Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/j;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lcom/github/catvod/spider/xbpqxyq/xbpq/e0/O;


# instance fields
.field final synthetic a:Ljava/lang/StringBuilder;


# direct methods
.method constructor <init>(Ljava/lang/StringBuilder;)V
    .registers 2

    iput-object p1, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/j;->a:Ljava/lang/StringBuilder;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final a(Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/r;I)V
    .registers 3

    instance-of p2, p1, Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/u;

    if-eqz p2, :cond_c

    check-cast p1, Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/u;

    iget-object p2, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/j;->a:Ljava/lang/StringBuilder;

    invoke-static {p2, p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/l;->I(Ljava/lang/StringBuilder;Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/u;)V

    goto :goto_43

    :cond_c
    instance-of p2, p1, Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/l;

    if-eqz p2, :cond_43

    check-cast p1, Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/l;

    iget-object p2, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/j;->a:Ljava/lang/StringBuilder;

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->length()I

    move-result p2

    if-lez p2, :cond_43

    invoke-virtual {p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/l;->a0()Z

    move-result p2

    if-nez p2, :cond_34

    invoke-static {p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/l;->J(Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/l;)Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/F;

    move-result-object p1

    invoke-virtual {p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/F;->b()Ljava/lang/String;

    move-result-object p1

    const-string p2, "150A"

    invoke-static {p2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p2

    invoke-virtual {p1, p2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_43

    :cond_34
    iget-object p1, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/j;->a:Ljava/lang/StringBuilder;

    invoke-static {p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/u;->M(Ljava/lang/StringBuilder;)Z

    move-result p1

    if-nez p1, :cond_43

    iget-object p1, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/j;->a:Ljava/lang/StringBuilder;

    const/16 p2, 0x20

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    :cond_43
    :goto_43
    return-void
.end method

.method public final b(Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/r;I)V
    .registers 3

    instance-of p2, p1, Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/l;

    if-eqz p2, :cond_24

    move-object p2, p1

    check-cast p2, Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/l;

    invoke-virtual {p2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/l;->a0()Z

    move-result p2

    if-eqz p2, :cond_24

    invoke-virtual {p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/r;->s()Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/r;

    move-result-object p1

    instance-of p1, p1, Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/u;

    if-eqz p1, :cond_24

    iget-object p1, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/j;->a:Ljava/lang/StringBuilder;

    invoke-static {p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/u;->M(Ljava/lang/StringBuilder;)Z

    move-result p1

    if-nez p1, :cond_24

    iget-object p1, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/j;->a:Ljava/lang/StringBuilder;

    const/16 p2, 0x20

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    :cond_24
    return-void
.end method
