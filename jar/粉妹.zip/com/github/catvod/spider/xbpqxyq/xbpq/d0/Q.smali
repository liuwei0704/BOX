.class final Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/Q;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field private static final r:[C

.field static final s:[I


# instance fields
.field private final a:Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/a;

.field private final b:Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/C;

.field private c:Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/h1;

.field private d:Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/O;

.field private e:Z

.field private f:Ljava/lang/String;

.field private g:Ljava/lang/StringBuilder;

.field h:Ljava/lang/StringBuilder;

.field i:Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/N;

.field j:Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/M;

.field k:Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/L;

.field l:Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/H;

.field m:Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/J;

.field n:Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/I;

.field private o:Ljava/lang/String;

.field private final p:[I

.field private final q:[I


# direct methods
.method static constructor <clinit>()V
    .registers 2

    const/4 v0, 0x7

    new-array v0, v0, [C

    fill-array-data v0, :array_16

    sput-object v0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/Q;->r:[C

    const/16 v1, 0x20

    new-array v1, v1, [I

    fill-array-data v1, :array_22

    sput-object v1, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/Q;->s:[I

    invoke-static {v0}, Ljava/util/Arrays;->sort([C)V

    return-void

    nop

    :array_16
    .array-data 2
        0x9s
        0xas
        0xds
        0xcs
        0x20s
        0x3cs
        0x26s
    .end array-data

    nop

    :array_22
    .array-data 4
        0x20ac
        0x81
        0x201a
        0x192
        0x201e
        0x2026
        0x2020
        0x2021
        0x2c6
        0x2030
        0x160
        0x2039
        0x152
        0x8d
        0x17d
        0x8f
        0x90
        0x2018
        0x2019
        0x201c
        0x201d
        0x2022
        0x2013
        0x2014
        0x2dc
        0x2122
        0x161
        0x203a
        0x153
        0x9d
        0x17e
        0x178
    .end array-data
.end method

.method constructor <init>(Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/a;Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/C;)V
    .registers 5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    sget-object v0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/h1;->c:Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/c0;

    iput-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/Q;->c:Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/h1;

    const/4 v0, 0x0

    iput-boolean v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/Q;->e:Z

    const/4 v0, 0x0

    iput-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/Q;->f:Ljava/lang/String;

    new-instance v0, Ljava/lang/StringBuilder;

    const/16 v1, 0x400

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(I)V

    iput-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/Q;->g:Ljava/lang/StringBuilder;

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(I)V

    iput-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/Q;->h:Ljava/lang/StringBuilder;

    new-instance v0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/M;

    invoke-direct {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/M;-><init>()V

    iput-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/Q;->j:Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/M;

    new-instance v0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/L;

    invoke-direct {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/L;-><init>()V

    iput-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/Q;->k:Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/L;

    new-instance v0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/H;

    invoke-direct {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/H;-><init>()V

    iput-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/Q;->l:Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/H;

    new-instance v0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/J;

    invoke-direct {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/J;-><init>()V

    iput-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/Q;->m:Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/J;

    new-instance v0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/I;

    invoke-direct {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/I;-><init>()V

    iput-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/Q;->n:Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/I;

    const/4 v0, 0x1

    new-array v0, v0, [I

    iput-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/Q;->p:[I

    const/4 v0, 0x2

    new-array v0, v0, [I

    iput-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/Q;->q:[I

    iput-object p1, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/Q;->a:Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/a;

    iput-object p2, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/Q;->b:Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/C;

    return-void
.end method

.method private c(Ljava/lang/String;)V
    .registers 7

    iget-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/Q;->b:Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/C;

    invoke-virtual {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/C;->a()Z

    move-result v0

    if-eqz v0, :cond_24

    iget-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/Q;->b:Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/C;

    new-instance v1, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/B;

    iget-object v2, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/Q;->a:Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/a;

    invoke-virtual {v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/a;->E()I

    move-result v2

    const/4 v3, 0x1

    new-array v3, v3, [Ljava/lang/Object;

    const/4 v4, 0x0

    aput-object p1, v3, v4

    const-string p1, "3E1633041F3C1358260D1227161B31000175051D23000130191B205F537004"

    invoke-static {p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    invoke-direct {v1, v2, p1, v3}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/B;-><init>(ILjava/lang/String;[Ljava/lang/Object;)V

    invoke-virtual {v0, v1}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    :cond_24
    return-void
.end method


# virtual methods
.method final a(Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/h1;)V
    .registers 3

    iget-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/Q;->a:Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/a;

    invoke-virtual {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/a;->a()V

    iput-object p1, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/Q;->c:Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/h1;

    return-void
.end method

.method final b()Ljava/lang/String;
    .registers 2

    iget-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/Q;->o:Ljava/lang/String;

    return-object v0
.end method

.method final d(Ljava/lang/Character;Z)[I
    .registers 11

    iget-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/Q;->a:Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/a;

    invoke-virtual {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/a;->t()Z

    move-result v0

    const/4 v1, 0x0

    if-eqz v0, :cond_a

    return-object v1

    :cond_a
    if-eqz p1, :cond_19

    invoke-virtual {p1}, Ljava/lang/Character;->charValue()C

    move-result p1

    iget-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/Q;->a:Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/a;

    invoke-virtual {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/a;->s()C

    move-result v0

    if-ne p1, v0, :cond_19

    return-object v1

    :cond_19
    iget-object p1, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/Q;->a:Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/a;

    sget-object v0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/Q;->r:[C

    invoke-virtual {p1, v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/a;->A([C)Z

    move-result p1

    if-eqz p1, :cond_24

    return-object v1

    :cond_24
    iget-object p1, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/Q;->p:[I

    iget-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/Q;->a:Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/a;

    invoke-virtual {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/a;->v()V

    iget-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/Q;->a:Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/a;

    const-string v2, "54"

    invoke-static {v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/a;->w(Ljava/lang/String;)Z

    move-result v0

    const-string v2, "1A1136161A3B105836001E3C1417290A1D"

    invoke-static {v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    const-string v3, "4C"

    invoke-static {v3}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    const/4 v4, 0x0

    if-eqz v0, :cond_d1

    iget-object p2, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/Q;->a:Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/a;

    const-string v0, "2F"

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p2, v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/a;->x(Ljava/lang/String;)Z

    move-result p2

    iget-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/Q;->a:Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/a;

    if-eqz p2, :cond_5b

    invoke-virtual {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/a;->i()Ljava/lang/String;

    move-result-object v0

    goto :goto_5f

    :cond_5b
    invoke-virtual {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/a;->h()Ljava/lang/String;

    move-result-object v0

    :goto_5f
    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v5

    if-nez v5, :cond_74

    const-string p1, "190D2800013C145837001530051D2B0616750011310D533B18582B101E3005192916"

    invoke-static {p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    invoke-direct {p0, p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/Q;->c(Ljava/lang/String;)V

    :cond_6e
    :goto_6e
    iget-object p1, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/Q;->a:Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/a;

    invoke-virtual {p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/a;->F()V

    return-object v1

    :cond_74
    iget-object v1, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/Q;->a:Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/a;

    invoke-virtual {v1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/a;->H()V

    iget-object v1, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/Q;->a:Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/a;

    invoke-virtual {v1, v3}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/a;->w(Ljava/lang/String;)Z

    move-result v1

    if-nez v1, :cond_84

    invoke-direct {p0, v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/Q;->c(Ljava/lang/String;)V

    :cond_84
    if-eqz p2, :cond_89

    const/16 p2, 0x10

    goto :goto_8b

    :cond_89
    const/16 p2, 0xa

    :goto_8b
    const/4 v1, -0x1

    :try_start_8c
    invoke-static {v0, p2}, Ljava/lang/Integer;->valueOf(Ljava/lang/String;I)Ljava/lang/Integer;

    move-result-object p2

    invoke-virtual {p2}, Ljava/lang/Integer;->intValue()I

    move-result p2
    :try_end_94
    .catch Ljava/lang/NumberFormatException; {:try_start_8c .. :try_end_94} :catch_95

    goto :goto_96

    :catch_95
    const/4 p2, -0x1

    :goto_96
    if-eq p2, v1, :cond_c2

    const v0, 0xd800

    if-lt p2, v0, :cond_a2

    const v0, 0xdfff

    if-le p2, v0, :cond_c2

    :cond_a2
    const v0, 0x10ffff

    if-le p2, v0, :cond_a8

    goto :goto_c2

    :cond_a8
    const/16 v0, 0x80

    if-lt p2, v0, :cond_bf

    sget-object v0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/Q;->s:[I

    const/16 v1, 0xa0

    if-ge p2, v1, :cond_bf

    const-string v1, "141024171236031D37451A2657162A115334570E24091A31570D2B0C103A131D65061C311258350A1A3B03"

    invoke-static {v1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-direct {p0, v1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/Q;->c(Ljava/lang/String;)V

    add-int/lit8 p2, p2, -0x80

    aget p2, v0, p2

    :cond_bf
    aput p2, p1, v4

    goto :goto_d0

    :cond_c2
    :goto_c2
    const-string p2, "141024171236031D37451C20030B2C011675181E651312391E1C6517123B101D"

    invoke-static {p2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p2

    invoke-direct {p0, p2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/Q;->c(Ljava/lang/String;)V

    const p2, 0xfffd

    aput p2, p1, v4

    :goto_d0
    return-object p1

    :cond_d1
    iget-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/Q;->a:Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/a;

    invoke-virtual {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/a;->k()Ljava/lang/String;

    move-result-object v0

    iget-object v5, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/Q;->a:Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/a;

    const/16 v6, 0x3b

    invoke-virtual {v5, v6}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/a;->y(C)Z

    move-result v5

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/n;->e(Ljava/lang/String;)Z

    move-result v6

    const/4 v7, 0x1

    if-nez v6, :cond_f1

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/n;->f(Ljava/lang/String;)Z

    move-result v6

    if-eqz v6, :cond_ef

    if-eqz v5, :cond_ef

    goto :goto_f1

    :cond_ef
    const/4 v6, 0x0

    goto :goto_f2

    :cond_f1
    :goto_f1
    const/4 v6, 0x1

    :goto_f2
    if-nez v6, :cond_105

    iget-object p1, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/Q;->a:Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/a;

    invoke-virtual {p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/a;->F()V

    if-eqz v5, :cond_104

    const-string p1, "1E1633041F3C13582B041E30135837001530051D2B0616"

    invoke-static {p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    invoke-direct {p0, p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/Q;->c(Ljava/lang/String;)V

    :cond_104
    return-object v1

    :cond_105
    if-eqz p2, :cond_127

    iget-object p2, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/Q;->a:Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/a;

    invoke-virtual {p2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/a;->C()Z

    move-result p2

    if-nez p2, :cond_6e

    iget-object p2, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/Q;->a:Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/a;

    invoke-virtual {p2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/a;->B()Z

    move-result p2

    if-nez p2, :cond_6e

    iget-object p2, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/Q;->a:Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/a;

    const/4 v5, 0x3

    new-array v5, v5, [C

    fill-array-data v5, :array_168

    invoke-virtual {p2, v5}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/a;->z([C)Z

    move-result p2

    if-eqz p2, :cond_127

    goto/16 :goto_6e

    :cond_127
    iget-object p2, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/Q;->a:Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/a;

    invoke-virtual {p2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/a;->H()V

    iget-object p2, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/Q;->a:Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/a;

    invoke-virtual {p2, v3}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/a;->w(Ljava/lang/String;)Z

    move-result p2

    if-nez p2, :cond_137

    invoke-direct {p0, v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/Q;->c(Ljava/lang/String;)V

    :cond_137
    iget-object p2, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/Q;->q:[I

    invoke-static {v0, p2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/n;->c(Ljava/lang/String;[I)I

    move-result p2

    if-ne p2, v7, :cond_146

    iget-object p2, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/Q;->q:[I

    aget p2, p2, v4

    aput p2, p1, v4

    return-object p1

    :cond_146
    const/4 p1, 0x2

    if-ne p2, p1, :cond_14c

    iget-object p1, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/Q;->q:[I

    return-object p1

    :cond_14c
    new-instance p1, Ljava/lang/StringBuilder;

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const-string p2, "2216201D0330140C200153361F1937041021120A36450130030D370B1631571E2A1753"

    invoke-static {p2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p2

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-static {p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/N/a;->a(Ljava/lang/String;)V

    goto :goto_166

    :goto_165
    throw v1

    :goto_166
    goto :goto_165

    nop

    :array_168
    .array-data 2
        0x3ds
        0x2ds
        0x5fs
    .end array-data
.end method

.method final e()V
    .registers 2

    iget-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/Q;->n:Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/I;

    invoke-virtual {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/I;->g()Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/O;

    iget-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/Q;->n:Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/I;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    return-void
.end method

.method final f()V
    .registers 2

    iget-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/Q;->m:Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/J;

    invoke-virtual {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/J;->g()Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/O;

    return-void
.end method

.method final g(Z)Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/N;
    .registers 2

    if-eqz p1, :cond_8

    iget-object p1, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/Q;->j:Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/M;

    invoke-virtual {p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/M;->v()Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/N;

    goto :goto_d

    :cond_8
    iget-object p1, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/Q;->k:Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/L;

    invoke-virtual {p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/N;->v()Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/N;

    :goto_d
    iput-object p1, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/Q;->i:Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/N;

    return-object p1
.end method

.method final h()V
    .registers 2

    iget-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/Q;->h:Ljava/lang/StringBuilder;

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/O;->h(Ljava/lang/StringBuilder;)V

    return-void
.end method

.method final i(C)V
    .registers 4

    iget-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/Q;->f:Ljava/lang/String;

    if-nez v0, :cond_b

    invoke-static {p1}, Ljava/lang/String;->valueOf(C)Ljava/lang/String;

    move-result-object p1

    iput-object p1, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/Q;->f:Ljava/lang/String;

    goto :goto_1f

    :cond_b
    iget-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/Q;->g:Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->length()I

    move-result v0

    if-nez v0, :cond_1a

    iget-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/Q;->g:Ljava/lang/StringBuilder;

    iget-object v1, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/Q;->f:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    :cond_1a
    iget-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/Q;->g:Ljava/lang/StringBuilder;

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    :goto_1f
    return-void
.end method

.method final j(Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/O;)V
    .registers 4

    iget-boolean v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/Q;->e:Z

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/N/a;->e(Z)V

    iput-object p1, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/Q;->d:Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/O;

    const/4 v0, 0x1

    iput-boolean v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/Q;->e:Z

    iget v0, p1, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/O;->a:I

    const/4 v1, 0x2

    if-ne v0, v1, :cond_16

    check-cast p1, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/M;

    iget-object p1, p1, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/N;->b:Ljava/lang/String;

    iput-object p1, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/Q;->o:Ljava/lang/String;

    goto :goto_2a

    :cond_16
    const/4 v1, 0x3

    if-ne v0, v1, :cond_2a

    check-cast p1, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/L;

    invoke-virtual {p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/N;->r()Z

    move-result p1

    if-eqz p1, :cond_2a

    const-string p1, "360C31171A37020C2016533C191B2A170130140C291C5325051D36001D2157172B45163B1358310414"

    invoke-static {p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p0, p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/Q;->r(Ljava/lang/String;)V

    :cond_2a
    :goto_2a
    return-void
.end method

.method final k(Ljava/lang/String;)V
    .registers 4

    iget-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/Q;->f:Ljava/lang/String;

    if-nez v0, :cond_7

    iput-object p1, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/Q;->f:Ljava/lang/String;

    goto :goto_1b

    :cond_7
    iget-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/Q;->g:Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->length()I

    move-result v0

    if-nez v0, :cond_16

    iget-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/Q;->g:Ljava/lang/StringBuilder;

    iget-object v1, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/Q;->f:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    :cond_16
    iget-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/Q;->g:Ljava/lang/StringBuilder;

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    :goto_1b
    return-void
.end method

.method final l(Ljava/lang/StringBuilder;)V
    .registers 4

    iget-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/Q;->f:Ljava/lang/String;

    if-nez v0, :cond_b

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    iput-object p1, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/Q;->f:Ljava/lang/String;

    goto :goto_1f

    :cond_b
    iget-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/Q;->g:Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->length()I

    move-result v0

    if-nez v0, :cond_1a

    iget-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/Q;->g:Ljava/lang/StringBuilder;

    iget-object v1, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/Q;->f:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    :cond_1a
    iget-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/Q;->g:Ljava/lang/StringBuilder;

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/CharSequence;)Ljava/lang/StringBuilder;

    :goto_1f
    return-void
.end method

.method final m()V
    .registers 2

    iget-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/Q;->n:Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/I;

    invoke-virtual {p0, v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/Q;->j(Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/O;)V

    return-void
.end method

.method final n()V
    .registers 2

    iget-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/Q;->m:Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/J;

    invoke-virtual {p0, v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/Q;->j(Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/O;)V

    return-void
.end method

.method final o()V
    .registers 2

    iget-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/Q;->i:Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/N;

    invoke-virtual {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/N;->q()V

    iget-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/Q;->i:Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/N;

    invoke-virtual {p0, v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/Q;->j(Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/O;)V

    return-void
.end method

.method final p(Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/h1;)V
    .registers 7

    iget-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/Q;->b:Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/C;

    invoke-virtual {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/C;->a()Z

    move-result v0

    if-eqz v0, :cond_24

    iget-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/Q;->b:Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/C;

    new-instance v1, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/B;

    iget-object v2, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/Q;->a:Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/a;

    invoke-virtual {v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/a;->E()I

    move-result v2

    const/4 v3, 0x1

    new-array v3, v3, [Ljava/lang/Object;

    const/4 v4, 0x0

    aput-object p1, v3, v4

    const-string p1, "2216201D0330140C20011F2C570A2004103D121C65001D3157172345153C1B1D654D361A3151650C1D751E1635100775040C241116752C5D3638"

    invoke-static {p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    invoke-direct {v1, v2, p1, v3}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/B;-><init>(ILjava/lang/String;[Ljava/lang/Object;)V

    invoke-virtual {v0, v1}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    :cond_24
    return-void
.end method

.method final q(Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/h1;)V
    .registers 8

    iget-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/Q;->b:Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/C;

    invoke-virtual {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/C;->a()Z

    move-result v0

    if-eqz v0, :cond_31

    iget-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/Q;->b:Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/C;

    new-instance v1, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/B;

    iget-object v2, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/Q;->a:Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/a;

    invoke-virtual {v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/a;->E()I

    move-result v2

    const/4 v3, 0x2

    new-array v3, v3, [Ljava/lang/Object;

    const/4 v4, 0x0

    iget-object v5, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/Q;->a:Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/a;

    invoke-virtual {v5}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/a;->s()C

    move-result v5

    invoke-static {v5}, Ljava/lang/Character;->valueOf(C)Ljava/lang/Character;

    move-result-object v5

    aput-object v5, v3, v4

    const/4 v4, 0x1

    aput-object p1, v3, v4

    const-string p1, "2216201D0330140C200153361F1937041021120A6542562650582C0B533C19083011532603193100530E520B18"

    invoke-static {p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    invoke-direct {v1, v2, p1, v3}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/B;-><init>(ILjava/lang/String;[Ljava/lang/Object;)V

    invoke-virtual {v0, v1}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    :cond_31
    return-void
.end method

.method final r(Ljava/lang/String;)V
    .registers 5

    iget-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/Q;->b:Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/C;

    invoke-virtual {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/C;->a()Z

    move-result v0

    if-eqz v0, :cond_18

    iget-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/Q;->b:Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/C;

    new-instance v1, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/B;

    iget-object v2, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/Q;->a:Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/a;

    invoke-virtual {v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/a;->E()I

    move-result v2

    invoke-direct {v1, v2, p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/B;-><init>(ILjava/lang/String;)V

    invoke-virtual {v0, v1}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    :cond_18
    return-void
.end method

.method final s()Z
    .registers 3

    iget-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/Q;->o:Ljava/lang/String;

    if-eqz v0, :cond_14

    iget-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/Q;->i:Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/N;

    invoke-virtual {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/N;->t()Ljava/lang/String;

    move-result-object v0

    iget-object v1, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/Q;->o:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_14

    const/4 v0, 0x1

    goto :goto_15

    :cond_14
    const/4 v0, 0x0

    :goto_15
    return v0
.end method

.method final t()Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/O;
    .registers 6

    :goto_0
    iget-boolean v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/Q;->e:Z

    if-nez v0, :cond_c

    iget-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/Q;->c:Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/h1;

    iget-object v1, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/Q;->a:Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/a;

    invoke-virtual {v0, p0, v1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/h1;->g(Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/Q;Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/a;)V

    goto :goto_0

    :cond_c
    iget-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/Q;->g:Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->length()I

    move-result v1

    const/4 v2, 0x0

    const/4 v3, 0x0

    if-eqz v1, :cond_29

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->length()I

    move-result v4

    invoke-virtual {v0, v3, v4}, Ljava/lang/StringBuilder;->delete(II)Ljava/lang/StringBuilder;

    iput-object v2, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/Q;->f:Ljava/lang/String;

    iget-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/Q;->l:Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/H;

    invoke-virtual {v0, v1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/H;->i(Ljava/lang/String;)Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/H;

    return-object v0

    :cond_29
    iget-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/Q;->f:Ljava/lang/String;

    if-eqz v0, :cond_35

    iget-object v1, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/Q;->l:Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/H;

    invoke-virtual {v1, v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/H;->i(Ljava/lang/String;)Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/H;

    iput-object v2, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/Q;->f:Ljava/lang/String;

    return-object v1

    :cond_35
    iput-boolean v3, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/Q;->e:Z

    iget-object v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/Q;->d:Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/O;

    return-object v0
.end method

.method final u(Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/h1;)V
    .registers 2

    iput-object p1, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/Q;->c:Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/h1;

    return-void
.end method
