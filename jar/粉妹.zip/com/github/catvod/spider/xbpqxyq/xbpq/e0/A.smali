.class public final Lcom/github/catvod/spider/xbpqxyq/xbpq/e0/A;
.super Lcom/github/catvod/spider/xbpqxyq/xbpq/e0/N;
.source "SourceFile"


# instance fields
.field public final synthetic a:I


# direct methods
.method public synthetic constructor <init>(I)V
    .registers 2

    iput p1, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/e0/A;->a:I

    invoke-direct {p0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/e0/N;-><init>()V

    return-void
.end method


# virtual methods
.method public final a(Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/l;Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/l;)Z
    .registers 5

    iget p1, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/e0/A;->a:I

    const/4 v0, 0x0

    const/4 v1, 0x1

    packed-switch p1, :pswitch_data_30

    goto :goto_1a

    .line 1
    :pswitch_8  #0x0
    invoke-virtual {p2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/l;->f0()Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/l;

    move-result-object p1

    if-eqz p1, :cond_19

    instance-of p1, p1, Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/h;

    if-nez p1, :cond_19

    invoke-virtual {p2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/l;->U()I

    move-result p1

    if-nez p1, :cond_19

    const/4 v0, 0x1

    :cond_19
    return v0

    .line 2
    :goto_1a
    invoke-virtual {p2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/l;->f0()Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/l;

    move-result-object p1

    if-eqz p1, :cond_2f

    instance-of p1, p1, Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/h;

    if-nez p1, :cond_2f

    invoke-virtual {p2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/c0/l;->l0()Lcom/github/catvod/spider/xbpqxyq/xbpq/e0/g;

    move-result-object p1

    invoke-virtual {p1}, Ljava/util/AbstractCollection;->isEmpty()Z

    move-result p1

    if-eqz p1, :cond_2f

    const/4 v0, 0x1

    :cond_2f
    return v0

    :pswitch_data_30
    .packed-switch 0x0
        :pswitch_8  #00000000
    .end packed-switch
.end method

.method public final toString()Ljava/lang/String;
    .registers 2

    iget v0, p0, Lcom/github/catvod/spider/xbpqxyq/xbpq/e0/A;->a:I

    packed-switch v0, :pswitch_data_14

    const-string v0, "4D172B090A7814102C0917"

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    return-object v0

    :pswitch_c  #0x0
    const-string v0, "4D1E2C1700215A1B2D0C1F31"

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    return-object v0

    nop

    :pswitch_data_14
    .packed-switch 0x0
        :pswitch_c  #00000000
    .end packed-switch
.end method
