.class final enum Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/K0;
.super Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/h1;
.source "SourceFile"


# direct methods
.method constructor <init>()V
    .registers 4

    const-string v0, "34172808163B033D2B013134191F"

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/16 v1, 0x31

    const/4 v2, 0x0

    invoke-direct {p0, v0, v1, v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/h1;-><init>(Ljava/lang/String;ILcom/github/catvod/spider/xbpqxyq/xbpq/d0/c0;)V

    return-void
.end method


# virtual methods
.method final g(Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/Q;Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/a;)V
    .registers 7

    sget-object v0, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/h1;->c:Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/c0;

    sget-object v1, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/h1;->W:Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/G0;

    invoke-virtual {p2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/a;->e()C

    move-result p2

    const-string v2, "5A5564"

    invoke-static {v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    if-eqz p2, :cond_3b

    const/16 v3, 0x2d

    if-eq p2, v3, :cond_30

    const/16 v3, 0x3e

    if-eq p2, v3, :cond_29

    const v3, 0xffff

    if-eq p2, v3, :cond_26

    iget-object v0, p1, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/Q;->n:Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/I;

    invoke-virtual {v0, v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/I;->j(Ljava/lang/String;)Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/I;

    invoke-virtual {v0, p2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/I;->i(C)Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/I;

    goto :goto_49

    :cond_26
    invoke-virtual {p1, p0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/Q;->p(Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/h1;)V

    :cond_29
    invoke-virtual {p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/Q;->m()V

    invoke-virtual {p1, v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/Q;->u(Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/h1;)V

    goto :goto_4c

    :cond_30
    iget-object p2, p1, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/Q;->n:Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/I;

    invoke-virtual {p2, v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/I;->j(Ljava/lang/String;)Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/I;

    sget-object p2, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/h1;->X:Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/H0;

    invoke-virtual {p1, p2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/Q;->u(Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/h1;)V

    goto :goto_4c

    :cond_3b
    invoke-virtual {p1, p0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/Q;->q(Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/h1;)V

    iget-object p2, p1, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/Q;->n:Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/I;

    invoke-virtual {p2, v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/I;->j(Ljava/lang/String;)Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/I;

    const v0, 0xfffd

    invoke-virtual {p2, v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/I;->i(C)Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/I;

    :goto_49
    invoke-virtual {p1, v1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/Q;->u(Lcom/github/catvod/spider/xbpqxyq/xbpq/d0/h1;)V

    :goto_4c
    return-void
.end method
