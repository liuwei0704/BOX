.class public Lcom/github/catvod/spider/XBPQPA;
.super Lcom/github/catvod/spider/XBPQAli;
.source "SourceFile"


# direct methods
.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, Lcom/github/catvod/spider/XBPQAli;-><init>()V

    return-void
.end method

.method private a(Ljava/lang/String;)Ljava/util/List;
    .registers 12
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            ")",
            "Ljava/util/List<",
            "Lcom/github/catvod/spider/xbpqxyq/xbpq/c/e;",
            ">;"
        }
    .end annotation

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    const-string v1, "11112900497A58"

    invoke-static {v1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {p1, v1}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v2

    const/4 v3, 0x0

    if-eqz v2, :cond_6f

    .line 1
    new-instance v2, Ljava/io/File;

    const-string v4, ""

    invoke-virtual {p1, v1, v4}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object v4

    invoke-direct {v2, v4}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    invoke-virtual {v2}, Ljava/io/File;->getParentFile()Ljava/io/File;

    move-result-object v4

    if-nez v4, :cond_24

    goto :goto_6f

    :cond_24
    invoke-virtual {v2}, Ljava/io/File;->getParentFile()Ljava/io/File;

    move-result-object v2

    invoke-virtual {v2}, Ljava/io/File;->listFiles()[Ljava/io/File;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    array-length v4, v2

    const/4 v5, 0x0

    :goto_31
    if-ge v5, v4, :cond_6f

    aget-object v6, v2, v5

    invoke-virtual {v6}, Ljava/io/File;->getName()Ljava/lang/String;

    move-result-object v7

    invoke-static {v7}, Lcom/github/catvod/spider/xbpqxyq/xbpq/j/o;->b(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    invoke-static {v7}, Lcom/github/catvod/spider/xbpqxyq/xbpq/j/o;->d(Ljava/lang/String;)Z

    move-result v8

    if-eqz v8, :cond_6c

    .line 2
    new-instance v8, Lcom/github/catvod/spider/xbpqxyq/xbpq/c/e;

    invoke-direct {v8}, Lcom/github/catvod/spider/xbpqxyq/xbpq/c/e;-><init>()V

    .line 3
    invoke-virtual {v6}, Ljava/io/File;->getName()Ljava/lang/String;

    move-result-object v9

    invoke-static {v9}, Lcom/github/catvod/spider/xbpqxyq/xbpq/j/o;->e(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v8, v9}, Lcom/github/catvod/spider/xbpqxyq/xbpq/c/e;->c(Ljava/lang/String;)Lcom/github/catvod/spider/xbpqxyq/xbpq/c/e;

    invoke-virtual {v8, v7}, Lcom/github/catvod/spider/xbpqxyq/xbpq/c/e;->a(Ljava/lang/String;)Lcom/github/catvod/spider/xbpqxyq/xbpq/c/e;

    move-result-object v7

    .line 4
    invoke-static {v1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/d/d;->b(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    .line 5
    invoke-virtual {v6}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v8, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v8}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v7, v6}, Lcom/github/catvod/spider/xbpqxyq/xbpq/c/e;->d(Ljava/lang/String;)Lcom/github/catvod/spider/xbpqxyq/xbpq/c/e;

    invoke-virtual {v0, v7}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_6c
    add-int/lit8 v5, v5, 0x1

    goto :goto_31

    :cond_6f
    :goto_6f
    const-string v1, "1F0C3115497A58"

    invoke-static {v1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    .line 6
    invoke-virtual {p1, v1}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_102

    const/4 v1, 0x2

    :try_start_7c
    new-array v2, v1, [Ljava/lang/String;

    const-string v4, "1A0871"

    invoke-static {v4}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    aput-object v4, v2, v3

    const-string v4, "1A1333"

    invoke-static {v4}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    const/4 v5, 0x1

    aput-object v4, v2, v5

    .line 7
    invoke-static {v2}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v2

    new-array v1, v1, [Ljava/lang/String;

    const-string v4, "040A31"

    invoke-static {v4}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    aput-object v4, v1, v3

    const-string v3, "160B36"

    invoke-static {v3}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    aput-object v3, v1, v5

    invoke-static {v1}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v1

    invoke-static {p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/j/o;->b(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-interface {v2, v3}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_b4

    goto :goto_102

    :cond_b4
    invoke-interface {v1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_b8
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_102

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/String;

    .line 8
    invoke-static {p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/j/o;->e(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    const-string v4, "59"

    invoke-static {v4}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v3, v2}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-static {v3}, Lcom/github/catvod/spider/xbpqxyq/xbpq/h/b;->a(Ljava/lang/String;)Lokhttp3/Response;

    move-result-object v4

    invoke-virtual {v4}, Lokhttp3/Response;->code()I

    move-result v4

    const/16 v5, 0xc8

    if-eq v4, v5, :cond_e3

    goto :goto_b8

    :cond_e3
    invoke-static {v3}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v4

    invoke-virtual {v4}, Landroid/net/Uri;->getLastPathSegment()Ljava/lang/String;

    move-result-object v4

    .line 9
    new-instance v5, Lcom/github/catvod/spider/xbpqxyq/xbpq/c/e;

    invoke-direct {v5}, Lcom/github/catvod/spider/xbpqxyq/xbpq/c/e;-><init>()V

    .line 10
    invoke-virtual {v5, v4}, Lcom/github/catvod/spider/xbpqxyq/xbpq/c/e;->c(Ljava/lang/String;)Lcom/github/catvod/spider/xbpqxyq/xbpq/c/e;

    invoke-virtual {v5, v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/c/e;->a(Ljava/lang/String;)Lcom/github/catvod/spider/xbpqxyq/xbpq/c/e;

    move-result-object v2

    invoke-virtual {v2, v3}, Lcom/github/catvod/spider/xbpqxyq/xbpq/c/e;->d(Ljava/lang/String;)Lcom/github/catvod/spider/xbpqxyq/xbpq/c/e;

    invoke-virtual {v0, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    :try_end_fd
    .catch Ljava/lang/Exception; {:try_start_7c .. :try_end_fd} :catch_fe

    goto :goto_b8

    :catch_fe
    move-exception p1

    .line 11
    invoke-virtual {p1}, Ljava/lang/Throwable;->printStackTrace()V

    :cond_102
    :goto_102
    return-object v0
.end method

.method private b(Ljava/lang/String;)Lcom/github/catvod/spider/xbpqxyq/xbpq/c/g;
    .registers 11

    new-instance v0, Lcom/github/catvod/spider/xbpqxyq/xbpq/c/g;

    invoke-direct {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/c/g;-><init>()V

    invoke-virtual {v0, p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/c/g;->f(Ljava/lang/String;)V

    invoke-virtual {v0, p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/c/g;->g(Ljava/lang/String;)V

    const-string v1, "2F3A1534"

    invoke-static {v1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/c/g;->a(Ljava/lang/String;)V

    const-string v1, "1F0C3115006F5857350C107B0515274B1131040C24111A36591B2A085C371D106A541765154877014333424F23551261454A7554156C451B2407126046487200177B1D082002"

    invoke-static {v1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/c/g;->h(Ljava/lang/String;)V

    invoke-static {p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/j/m;->d(Ljava/lang/String;)Z

    move-result v1

    const-string v2, "92EFC083FDF7"

    invoke-static {v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    const-string v3, "9FDFE683EDC5"

    invoke-static {v3}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    const/4 v4, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x3

    if-eqz v1, :cond_46

    new-array v1, v7, [Ljava/lang/String;

    aput-object v3, v1, v6

    aput-object v2, v1, v5

    const-string v2, "90E3F18CE0EB"

    invoke-static {v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    aput-object v2, v1, v4

    invoke-static {v1}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v1

    goto :goto_78

    :cond_46
    invoke-static {p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/j/m;->c(Ljava/lang/String;)Z

    move-result v1

    const-string v8, "90E3F18DCCCB"

    invoke-static {v8}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    if-nez v1, :cond_6c

    const-string v1, "1A19220B1621"

    invoke-static {v1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {p1, v1}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_5f

    goto :goto_6c

    :cond_5f
    new-array v1, v7, [Ljava/lang/String;

    aput-object v2, v1, v6

    aput-object v3, v1, v5

    aput-object v8, v1, v4

    invoke-static {v1}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v1

    goto :goto_78

    :cond_6c
    :goto_6c
    new-array v1, v7, [Ljava/lang/String;

    aput-object v8, v1, v6

    aput-object v2, v1, v5

    aput-object v3, v1, v4

    invoke-static {v1}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v1

    :goto_78
    const-string v2, "535C61"

    invoke-static {v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-static {v2, v1}, Landroid/text/TextUtils;->join(Ljava/lang/CharSequence;Ljava/lang/Iterable;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/c/g;->i(Ljava/lang/String;)V

    new-array v1, v7, [Ljava/lang/String;

    const-string v3, "91EAE883E7EB53"

    invoke-static {v3}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    .line 1
    invoke-static {v3, p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/n;->a(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    aput-object v7, v1, v6

    invoke-static {v3, p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/n;->a(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    aput-object v6, v1, v5

    invoke-static {v3, p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/n;->a(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    aput-object p1, v1, v4

    .line 2
    invoke-static {v1}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    move-result-object p1

    invoke-static {v2, p1}, Landroid/text/TextUtils;->join(Ljava/lang/CharSequence;Ljava/lang/Iterable;)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v0, p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/c/g;->j(Ljava/lang/String;)V

    return-object v0
.end method


# virtual methods
.method public detailContent(Ljava/util/List;)Ljava/lang/String;
    .registers 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;)",
            "Ljava/lang/String;"
        }
    .end annotation

    const/4 v0, 0x0

    :try_start_1
    invoke-interface {p1, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    invoke-virtual {v0}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v0

    const-string v1, "1A19220B1621"

    invoke-static {v1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1
    :try_end_15
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_15} :catch_73

    const-string v2, "5349"

    invoke-static {v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    if-eqz v1, :cond_27

    :try_start_1d
    const-string v1, "2C24163900085D502804143B120C7F394C2D034530171D6F150C2C0D490E47557C045E3336550338086147056C3E2F062B0B184F"

    invoke-static {v1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1, v2}, Ljava/lang/String;->replaceAll(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    :cond_27
    const-string v1, "1F0C3115006F58573212047B16142C1C063B130A2C13167B1417284A007A"

    invoke-static {v1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_3f

    const-string v1, "1F0C3115006F58573212047B16142C15123B591B2A085C2658"

    invoke-static {v1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-eqz v1, :cond_59

    :cond_3f
    const-string v1, "000F324B12391E08240B5D361815"

    invoke-static {v1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const-string v3, "000F324B12391E01300B17271E0E204B103A1A"

    invoke-static {v3}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v0, v1, v3}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object v0

    const-string v1, "2C24163900085D502D11072504426A4A042200246B041F3C0E0D2B01013C011D194B103A1A57364A2F060C4974185A0E2B2B19162E7F"

    invoke-static {v1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1, v2}, Ljava/lang/String;->replaceAll(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    :cond_59
    const-string v1, "16142C1C063B130A2C1316"

    invoke-static {v1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-eqz v1, :cond_6a

    invoke-super {p0, p1}, Lcom/github/catvod/spider/XBPQAli;->detailContent(Ljava/util/List;)Ljava/lang/String;

    move-result-object p1

    return-object p1

    :cond_6a
    invoke-direct {p0, v0}, Lcom/github/catvod/spider/XBPQPA;->b(Ljava/lang/String;)Lcom/github/catvod/spider/xbpqxyq/xbpq/c/g;

    move-result-object p1

    invoke-static {p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/c/d;->e(Lcom/github/catvod/spider/xbpqxyq/xbpq/c/g;)Ljava/lang/String;

    move-result-object p1
    :try_end_72
    .catch Ljava/lang/Exception; {:try_start_1d .. :try_end_72} :catch_73

    return-object p1

    :catch_73
    const-string p1, ""

    return-object p1
.end method

.method public init(Landroid/content/Context;Ljava/lang/String;)V
    .registers 3

    invoke-super {p0, p1, p2}, Lcom/github/catvod/spider/XBPQAli;->init(Landroid/content/Context;Ljava/lang/String;)V

    return-void
.end method

.method public playerContent(Ljava/lang/String;Ljava/lang/String;Ljava/util/List;)Ljava/lang/String;
    .registers 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;)",
            "Ljava/lang/String;"
        }
    .end annotation

    :try_start_0
    const-string v0, "0E17301106371256260A1E"

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p2, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    if-eqz v0, :cond_1d

    .line 1
    new-instance p1, Lcom/github/catvod/spider/xbpqxyq/xbpq/c/d;

    invoke-direct {p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/c/d;-><init>()V

    .line 2
    invoke-static {p2}, Lcom/github/catvod/spider/Youtube;->fetch(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p2

    invoke-virtual {p1, p2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/c/d;->i(Ljava/lang/String;)Lcom/github/catvod/spider/xbpqxyq/xbpq/c/d;

    .line 3
    invoke-virtual {p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/c/d;->toString()Ljava/lang/String;

    move-result-object p1

    return-object p1

    :cond_1d
    const-string v0, "90E3F18DCCCB"

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 4
    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_3d

    .line 5
    new-instance p1, Lcom/github/catvod/spider/xbpqxyq/xbpq/c/d;

    invoke-direct {p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/c/d;-><init>()V

    .line 6
    invoke-virtual {p1, p2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/c/d;->i(Ljava/lang/String;)Lcom/github/catvod/spider/xbpqxyq/xbpq/c/d;

    invoke-direct {p0, p2}, Lcom/github/catvod/spider/XBPQPA;->a(Ljava/lang/String;)Ljava/util/List;

    move-result-object p2

    invoke-virtual {p1, p2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/c/d;->h(Ljava/util/List;)Lcom/github/catvod/spider/xbpqxyq/xbpq/c/d;

    .line 7
    invoke-virtual {p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/c/d;->toString()Ljava/lang/String;

    move-result-object p1

    return-object p1

    :cond_3d
    const-string v0, "92EFC083FDF7"

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 8
    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_59

    .line 9
    new-instance p1, Lcom/github/catvod/spider/xbpqxyq/xbpq/c/d;

    invoke-direct {p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/c/d;-><init>()V

    .line 10
    invoke-virtual {p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/c/d;->d()Lcom/github/catvod/spider/xbpqxyq/xbpq/c/d;

    invoke-virtual {p1, p2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/c/d;->i(Ljava/lang/String;)Lcom/github/catvod/spider/xbpqxyq/xbpq/c/d;

    .line 11
    invoke-virtual {p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/c/d;->toString()Ljava/lang/String;

    move-result-object p1

    return-object p1

    :cond_59
    const-string v0, "9FDFE683EDC5"

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 12
    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_78

    .line 13
    new-instance p1, Lcom/github/catvod/spider/xbpqxyq/xbpq/c/d;

    invoke-direct {p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/c/d;-><init>()V

    .line 14
    invoke-virtual {p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/c/d;->d()Lcom/github/catvod/spider/xbpqxyq/xbpq/c/d;

    invoke-virtual {p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/c/d;->b()Lcom/github/catvod/spider/xbpqxyq/xbpq/c/d;

    invoke-virtual {p1, p2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/c/d;->i(Ljava/lang/String;)Lcom/github/catvod/spider/xbpqxyq/xbpq/c/d;

    .line 15
    invoke-virtual {p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/c/d;->toString()Ljava/lang/String;

    move-result-object p1

    return-object p1

    .line 16
    :cond_78
    invoke-super {p0, p1, p2, p3}, Lcom/github/catvod/spider/XBPQAli;->playerContent(Ljava/lang/String;Ljava/lang/String;Ljava/util/List;)Ljava/lang/String;

    move-result-object p1
    :try_end_7c
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_7c} :catch_7d

    return-object p1

    :catch_7d
    const-string p1, ""

    return-object p1
.end method
