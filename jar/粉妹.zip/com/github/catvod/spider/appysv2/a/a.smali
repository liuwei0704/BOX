.class public final Lcom/github/catvod/spider/appysv2/a/a;
.super Ljava/lang/Object;
.source "SourceFile"


# direct methods
.method public static a([B[B)Ljava/lang/String;
    .registers 10

    .line 1
    new-instance v0, Ljava/lang/String;

    .line 2
    array-length v1, p0

    array-length v2, p1

    const/4 v3, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x0

    :goto_7
    if-ge v4, v1, :cond_19

    if-lt v5, v2, :cond_c

    const/4 v5, 0x0

    :cond_c
    aget-byte v6, p0, v4

    aget-byte v7, p1, v5

    xor-int/2addr v6, v7

    int-to-byte v6, v6

    aput-byte v6, p0, v4

    add-int/lit8 v4, v4, 0x1

    add-int/lit8 v5, v5, 0x1

    goto :goto_7

    .line 3
    :cond_19
    invoke-direct {v0, p0}, Ljava/lang/String;-><init>([B)V

    return-object v0
.end method

.method public static b(I)I
    .registers 3

    int-to-float p0, p0

    .line 1
    invoke-static {}, Lcom/github/catvod/spider/Init;->context()Landroid/app/Application;

    move-result-object v0

    invoke-virtual {v0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    invoke-virtual {v0}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v0

    const/4 v1, 0x1

    .line 2
    invoke-static {v1, p0, v0}, Landroid/util/TypedValue;->applyDimension(IFLandroid/util/DisplayMetrics;)F

    move-result p0

    float-to-int p0, p0

    return p0
.end method

.method public static c(Ljava/io/File;)V
    .registers 7

    new-instance v0, Landroid/content/Intent;

    const/16 v1, 0x1a

    new-array v1, v1, [B

    fill-array-data v1, :array_82

    const/16 v2, 0x8

    new-array v3, v2, [B

    fill-array-data v3, :array_94

    invoke-static {v1, v3}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const/high16 v1, 0x10000000

    invoke-virtual {v0, v1}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    const/4 v1, 0x1

    invoke-virtual {v0, v1}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    .line 1
    sget v1, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v3, 0x18

    if-ge v1, v3, :cond_2b

    invoke-static {p0}, Landroid/net/Uri;->fromFile(Ljava/io/File;)Landroid/net/Uri;

    move-result-object v1

    goto :goto_5a

    :cond_2b
    invoke-static {}, Lcom/github/catvod/spider/Init;->context()Landroid/app/Application;

    move-result-object v1

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    invoke-static {}, Lcom/github/catvod/spider/Init;->context()Landroid/app/Application;

    move-result-object v4

    invoke-virtual {v4}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v4, 0x9

    new-array v4, v4, [B

    fill-array-data v4, :array_9c

    new-array v5, v2, [B

    fill-array-data v5, :array_a6

    invoke-static {v4, v5}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-static {v1, v3, p0}, Lcom/github/catvod/spider/appysv2/p/d;->a(Landroid/content/Context;Ljava/lang/String;Ljava/io/File;)Landroid/net/Uri;

    move-result-object v1

    .line 2
    :goto_5a
    invoke-virtual {p0}, Ljava/io/File;->getName()Ljava/lang/String;

    move-result-object p0

    .line 3
    invoke-static {p0}, Ljava/net/URLConnection;->guessContentTypeFromName(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    invoke-static {p0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v3

    if-eqz v3, :cond_77

    const/4 p0, 0x3

    new-array p0, p0, [B

    fill-array-data p0, :array_ae

    new-array v2, v2, [B

    fill-array-data v2, :array_b4

    invoke-static {p0, v2}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object p0

    .line 4
    :cond_77
    invoke-virtual {v0, v1, p0}, Landroid/content/Intent;->setDataAndType(Landroid/net/Uri;Ljava/lang/String;)Landroid/content/Intent;

    invoke-static {}, Lcom/github/catvod/spider/Init;->context()Landroid/app/Application;

    move-result-object p0

    invoke-virtual {p0, v0}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V

    return-void

    :array_82
    .array-data 1
        0x4bt
        0x1ct
        -0xdt
        -0x2ct
        0x66t
        0x65t
        0x78t
        -0x57t
        0x43t
        0x1ct
        -0x1dt
        -0x3dt
        0x67t
        0x78t
        0x32t
        -0x1at
        0x49t
        0x6t
        -0x2t
        -0x37t
        0x67t
        0x22t
        0x4at
        -0x32t
        0x6ft
        0x25t
    .end array-data

    nop

    :array_94
    .array-data 1
        0x2at
        0x72t
        -0x69t
        -0x5at
        0x9t
        0xct
        0x1ct
        -0x79t
    .end array-data

    :array_9c
    .array-data 1
        -0x16t
        0x1et
        0x67t
        0x63t
        0x1ct
        -0x21t
        -0x4t
        -0x5dt
        -0x4at
    .end array-data

    nop

    :array_a6
    .array-data 1
        -0x3ct
        0x6et
        0x15t
        0xct
        0x6at
        -0x4at
        -0x68t
        -0x3at
    .end array-data

    :array_ae
    .array-data 1
        0x9t
        0x78t
        0x1at
    .end array-data

    :array_b4
    .array-data 1
        0x23t
        0x57t
        0x30t
        -0x30t
        0x1ct
        -0x19t
        -0x3t
        -0x35t
    .end array-data
.end method

.method public static d(Ljava/io/File;Ljava/io/File;)V
    .registers 8

    :try_start_0
    new-instance v0, Ljava/util/zip/ZipFile;

    invoke-virtual {p0}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;

    move-result-object p0

    invoke-direct {v0, p0}, Ljava/util/zip/ZipFile;-><init>(Ljava/lang/String;)V
    :try_end_9
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_9} :catch_4e

    :try_start_9
    invoke-virtual {v0}, Ljava/util/zip/ZipFile;->entries()Ljava/util/Enumeration;

    move-result-object p0

    :catch_d
    :cond_d
    :goto_d
    invoke-interface {p0}, Ljava/util/Enumeration;->hasMoreElements()Z

    move-result v1

    if-eqz v1, :cond_45

    invoke-interface {p0}, Ljava/util/Enumeration;->nextElement()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/util/zip/ZipEntry;

    new-instance v2, Ljava/io/File;

    invoke-virtual {v1}, Ljava/util/zip/ZipEntry;->getName()Ljava/lang/String;

    move-result-object v3

    invoke-direct {v2, p1, v3}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    invoke-virtual {v1}, Ljava/util/zip/ZipEntry;->isDirectory()Z

    move-result v3

    if-eqz v3, :cond_2c

    invoke-virtual {v2}, Ljava/io/File;->mkdirs()Z

    goto :goto_d

    :cond_2c
    invoke-virtual {v0, v1}, Ljava/util/zip/ZipFile;->getInputStream(Ljava/util/zip/ZipEntry;)Ljava/io/InputStream;

    move-result-object v1
    :try_end_30
    .catchall {:try_start_9 .. :try_end_30} :catchall_49

    .line 1
    :try_start_30
    new-instance v3, Ljava/io/FileOutputStream;

    invoke-direct {v3, v2}, Ljava/io/FileOutputStream;-><init>(Ljava/io/File;)V

    const/16 v2, 0x2000

    new-array v2, v2, [B

    .line 2
    :goto_39
    invoke-virtual {v1, v2}, Ljava/io/InputStream;->read([B)I

    move-result v4

    const/4 v5, -0x1

    if-eq v4, v5, :cond_d

    const/4 v5, 0x0

    invoke-virtual {v3, v2, v5, v4}, Ljava/io/OutputStream;->write([BII)V
    :try_end_44
    .catch Ljava/lang/Exception; {:try_start_30 .. :try_end_44} :catch_d
    .catchall {:try_start_30 .. :try_end_44} :catchall_49

    goto :goto_39

    .line 3
    :cond_45
    :try_start_45
    invoke-virtual {v0}, Ljava/util/zip/ZipFile;->close()V
    :try_end_48
    .catch Ljava/lang/Exception; {:try_start_45 .. :try_end_48} :catch_4e

    goto :goto_52

    :catchall_49
    move-exception p0

    :try_start_4a
    invoke-virtual {v0}, Ljava/util/zip/ZipFile;->close()V
    :try_end_4d
    .catchall {:try_start_4a .. :try_end_4d} :catchall_4d

    :catchall_4d
    :try_start_4d
    throw p0
    :try_end_4e
    .catch Ljava/lang/Exception; {:try_start_4d .. :try_end_4e} :catch_4e

    :catch_4e
    move-exception p0

    invoke-virtual {p0}, Ljava/lang/Throwable;->printStackTrace()V

    :goto_52
    return-void
.end method
