.class final Lcom/github/catvod/spider/appysv2/b/T;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field static volatile a:Lcom/github/catvod/spider/appysv2/b/U;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    new-instance v0, Lcom/github/catvod/spider/appysv2/b/U;

    invoke-direct {v0}, Lcom/github/catvod/spider/appysv2/b/U;-><init>()V

    sput-object v0, Lcom/github/catvod/spider/appysv2/b/T;->a:Lcom/github/catvod/spider/appysv2/b/U;

    return-void
.end method
