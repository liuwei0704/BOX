.class final Lcom/github/catvod/spider/appysv2/b/z;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field static volatile a:Lcom/github/catvod/spider/appysv2/b/A;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    new-instance v0, Lcom/github/catvod/spider/appysv2/b/A;

    invoke-direct {v0}, Lcom/github/catvod/spider/appysv2/b/A;-><init>()V

    sput-object v0, Lcom/github/catvod/spider/appysv2/b/z;->a:Lcom/github/catvod/spider/appysv2/b/A;

    return-void
.end method
