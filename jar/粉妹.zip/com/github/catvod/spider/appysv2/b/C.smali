.class public final synthetic Lcom/github/catvod/spider/appysv2/b/C;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/content/DialogInterface$OnClickListener;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Landroid/widget/EditText;

.field public final synthetic c:Landroid/widget/EditText;

.field public final synthetic d:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(Ljava/lang/Object;Landroid/widget/EditText;Landroid/widget/EditText;I)V
    .registers 5

    iput p4, p0, Lcom/github/catvod/spider/appysv2/b/C;->a:I

    iput-object p1, p0, Lcom/github/catvod/spider/appysv2/b/C;->d:Ljava/lang/Object;

    iput-object p2, p0, Lcom/github/catvod/spider/appysv2/b/C;->b:Landroid/widget/EditText;

    iput-object p3, p0, Lcom/github/catvod/spider/appysv2/b/C;->c:Landroid/widget/EditText;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/content/DialogInterface;I)V
    .registers 5

    iget p1, p0, Lcom/github/catvod/spider/appysv2/b/C;->a:I

    packed-switch p1, :pswitch_data_26

    goto :goto_12

    :pswitch_6  #0x0
    iget-object p1, p0, Lcom/github/catvod/spider/appysv2/b/C;->d:Ljava/lang/Object;

    check-cast p1, Lcom/github/catvod/spider/appysv2/b/F;

    iget-object p2, p0, Lcom/github/catvod/spider/appysv2/b/C;->b:Landroid/widget/EditText;

    iget-object v0, p0, Lcom/github/catvod/spider/appysv2/b/C;->c:Landroid/widget/EditText;

    invoke-static {p1, p2, v0}, Lcom/github/catvod/spider/appysv2/b/F;->c(Lcom/github/catvod/spider/appysv2/b/F;Landroid/widget/EditText;Landroid/widget/EditText;)V

    return-void

    :goto_12
    iget-object p1, p0, Lcom/github/catvod/spider/appysv2/b/C;->d:Ljava/lang/Object;

    check-cast p1, Lcom/github/catvod/spider/appysv2/p/B;

    iget-object p2, p0, Lcom/github/catvod/spider/appysv2/b/C;->b:Landroid/widget/EditText;

    iget-object v0, p0, Lcom/github/catvod/spider/appysv2/b/C;->c:Landroid/widget/EditText;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v1, Lcom/github/catvod/spider/appysv2/p/p;

    invoke-direct {v1, p1, p2, v0}, Lcom/github/catvod/spider/appysv2/p/p;-><init>(Lcom/github/catvod/spider/appysv2/p/B;Landroid/widget/EditText;Landroid/widget/EditText;)V

    invoke-static {v1}, Lcom/github/catvod/spider/Init;->execute(Ljava/lang/Runnable;)V

    return-void

    :pswitch_data_26
    .packed-switch 0x0
        :pswitch_6  #00000000
    .end packed-switch
.end method
