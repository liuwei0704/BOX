.class public final synthetic Lcom/github/catvod/spider/appysv2/b/Q;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lcom/github/catvod/spider/appysv2/b/U;

.field public final synthetic c:Lorg/json/JSONObject;


# direct methods
.method public synthetic constructor <init>(Lcom/github/catvod/spider/appysv2/b/U;Lorg/json/JSONObject;I)V
    .registers 4

    iput p3, p0, Lcom/github/catvod/spider/appysv2/b/Q;->a:I

    iput-object p1, p0, Lcom/github/catvod/spider/appysv2/b/Q;->b:Lcom/github/catvod/spider/appysv2/b/U;

    iput-object p2, p0, Lcom/github/catvod/spider/appysv2/b/Q;->c:Lorg/json/JSONObject;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 3

    iget v0, p0, Lcom/github/catvod/spider/appysv2/b/Q;->a:I

    packed-switch v0, :pswitch_data_16

    goto :goto_e

    :pswitch_6  #0x0
    iget-object v0, p0, Lcom/github/catvod/spider/appysv2/b/Q;->b:Lcom/github/catvod/spider/appysv2/b/U;

    iget-object v1, p0, Lcom/github/catvod/spider/appysv2/b/Q;->c:Lorg/json/JSONObject;

    invoke-static {v0, v1}, Lcom/github/catvod/spider/appysv2/b/U;->j(Lcom/github/catvod/spider/appysv2/b/U;Lorg/json/JSONObject;)V

    return-void

    :goto_e
    iget-object v0, p0, Lcom/github/catvod/spider/appysv2/b/Q;->b:Lcom/github/catvod/spider/appysv2/b/U;

    iget-object v1, p0, Lcom/github/catvod/spider/appysv2/b/Q;->c:Lorg/json/JSONObject;

    invoke-static {v0, v1}, Lcom/github/catvod/spider/appysv2/b/U;->i(Lcom/github/catvod/spider/appysv2/b/U;Lorg/json/JSONObject;)V

    return-void

    :pswitch_data_16
    .packed-switch 0x0
        :pswitch_6  #00000000
    .end packed-switch
.end method
