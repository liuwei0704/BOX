.class public final synthetic Lcom/github/catvod/spider/appysv2/b/j;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Ljava/lang/Object;

.field public final synthetic c:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(Ljava/lang/Object;Ljava/lang/Object;I)V
    .registers 4

    iput p3, p0, Lcom/github/catvod/spider/appysv2/b/j;->a:I

    iput-object p1, p0, Lcom/github/catvod/spider/appysv2/b/j;->b:Ljava/lang/Object;

    iput-object p2, p0, Lcom/github/catvod/spider/appysv2/b/j;->c:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 3

    iget v0, p0, Lcom/github/catvod/spider/appysv2/b/j;->a:I

    packed-switch v0, :pswitch_data_4e

    goto :goto_42

    :pswitch_6  #0x4
    iget-object v0, p0, Lcom/github/catvod/spider/appysv2/b/j;->b:Ljava/lang/Object;

    check-cast v0, Lcom/github/catvod/spider/appysv2/p/B;

    iget-object v1, p0, Lcom/github/catvod/spider/appysv2/b/j;->c:Ljava/lang/Object;

    check-cast v1, Ljava/util/Map;

    invoke-static {v0, v1}, Lcom/github/catvod/spider/appysv2/p/B;->d(Lcom/github/catvod/spider/appysv2/p/B;Ljava/util/Map;)V

    return-void

    :pswitch_12  #0x3
    iget-object v0, p0, Lcom/github/catvod/spider/appysv2/b/j;->b:Ljava/lang/Object;

    check-cast v0, Lcom/github/catvod/spider/Bili;

    iget-object v1, p0, Lcom/github/catvod/spider/appysv2/b/j;->c:Ljava/lang/Object;

    check-cast v1, Lcom/github/catvod/spider/appysv2/g/b;

    invoke-static {v0, v1}, Lcom/github/catvod/spider/Bili;->e(Lcom/github/catvod/spider/Bili;Lcom/github/catvod/spider/appysv2/g/b;)V

    return-void

    :pswitch_1e  #0x2
    iget-object v0, p0, Lcom/github/catvod/spider/appysv2/b/j;->b:Ljava/lang/Object;

    check-cast v0, Lcom/github/catvod/spider/appysv2/b/U;

    iget-object v1, p0, Lcom/github/catvod/spider/appysv2/b/j;->c:Ljava/lang/Object;

    check-cast v1, Lorg/json/JSONObject;

    invoke-static {v0, v1}, Lcom/github/catvod/spider/appysv2/b/U;->b(Lcom/github/catvod/spider/appysv2/b/U;Lorg/json/JSONObject;)V

    return-void

    :pswitch_2a  #0x1
    iget-object v0, p0, Lcom/github/catvod/spider/appysv2/b/j;->b:Ljava/lang/Object;

    check-cast v0, Lcom/github/catvod/spider/appysv2/b/M;

    iget-object v1, p0, Lcom/github/catvod/spider/appysv2/b/j;->c:Ljava/lang/Object;

    check-cast v1, Lorg/json/JSONObject;

    invoke-static {v0, v1}, Lcom/github/catvod/spider/appysv2/b/M;->a(Lcom/github/catvod/spider/appysv2/b/M;Lorg/json/JSONObject;)V

    return-void

    :pswitch_36  #0x0
    iget-object v0, p0, Lcom/github/catvod/spider/appysv2/b/j;->b:Ljava/lang/Object;

    check-cast v0, Lcom/github/catvod/spider/appysv2/b/x;

    iget-object v1, p0, Lcom/github/catvod/spider/appysv2/b/j;->c:Ljava/lang/Object;

    check-cast v1, Ljava/lang/String;

    invoke-static {v0, v1}, Lcom/github/catvod/spider/appysv2/b/x;->a(Lcom/github/catvod/spider/appysv2/b/x;Ljava/lang/String;)V

    return-void

    :goto_42
    iget-object v0, p0, Lcom/github/catvod/spider/appysv2/b/j;->b:Ljava/lang/Object;

    check-cast v0, Lcom/github/catvod/spider/appysv2/p/B;

    iget-object v1, p0, Lcom/github/catvod/spider/appysv2/b/j;->c:Ljava/lang/Object;

    check-cast v1, Landroid/widget/EditText;

    invoke-static {v0, v1}, Lcom/github/catvod/spider/appysv2/p/B;->k(Lcom/github/catvod/spider/appysv2/p/B;Landroid/widget/EditText;)V

    return-void

    :pswitch_data_4e
    .packed-switch 0x0
        :pswitch_36  #00000000
        :pswitch_2a  #00000001
        :pswitch_1e  #00000002
        :pswitch_12  #00000003
        :pswitch_6  #00000004
    .end packed-switch
.end method
