.class final Lcom/github/catvod/spider/appysv2/b/E;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field static volatile a:Lcom/github/catvod/spider/appysv2/b/F;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    new-instance v0, Lcom/github/catvod/spider/appysv2/b/F;

    invoke-direct {v0}, Lcom/github/catvod/spider/appysv2/b/F;-><init>()V

    sput-object v0, Lcom/github/catvod/spider/appysv2/b/E;->a:Lcom/github/catvod/spider/appysv2/b/F;

    return-void
.end method
