.class public final synthetic Lcom/github/catvod/spider/appysv2/b/O;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/content/DialogInterface$OnClickListener;


# instance fields
.field public final synthetic a:Lcom/github/catvod/spider/appysv2/b/U;

.field public final synthetic b:Landroid/widget/EditText;


# direct methods
.method public synthetic constructor <init>(Lcom/github/catvod/spider/appysv2/b/U;Landroid/widget/EditText;)V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/github/catvod/spider/appysv2/b/O;->a:Lcom/github/catvod/spider/appysv2/b/U;

    iput-object p2, p0, Lcom/github/catvod/spider/appysv2/b/O;->b:Landroid/widget/EditText;

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/content/DialogInterface;I)V
    .registers 3

    iget-object p1, p0, Lcom/github/catvod/spider/appysv2/b/O;->a:Lcom/github/catvod/spider/appysv2/b/U;

    iget-object p2, p0, Lcom/github/catvod/spider/appysv2/b/O;->b:Landroid/widget/EditText;

    invoke-static {p1, p2}, Lcom/github/catvod/spider/appysv2/b/U;->e(Lcom/github/catvod/spider/appysv2/b/U;Landroid/widget/EditText;)V

    return-void
.end method
