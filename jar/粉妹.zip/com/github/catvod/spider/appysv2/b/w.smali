.class final Lcom/github/catvod/spider/appysv2/b/w;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field static volatile a:Lcom/github/catvod/spider/appysv2/b/x;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    new-instance v0, Lcom/github/catvod/spider/appysv2/b/x;

    invoke-direct {v0}, Lcom/github/catvod/spider/appysv2/b/x;-><init>()V

    sput-object v0, Lcom/github/catvod/spider/appysv2/b/w;->a:Lcom/github/catvod/spider/appysv2/b/x;

    return-void
.end method
