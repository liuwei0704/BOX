.class public final synthetic Lcom/github/catvod/spider/appysv2/b/h;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Ljava/lang/Object;

.field public final synthetic c:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(Ljava/lang/Object;Ljava/lang/Object;I)V
    .registers 4

    iput p3, p0, Lcom/github/catvod/spider/appysv2/b/h;->a:I

    iput-object p1, p0, Lcom/github/catvod/spider/appysv2/b/h;->b:Ljava/lang/Object;

    iput-object p2, p0, Lcom/github/catvod/spider/appysv2/b/h;->c:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 3

    iget v0, p0, Lcom/github/catvod/spider/appysv2/b/h;->a:I

    packed-switch v0, :pswitch_data_2a

    goto :goto_1e

    :pswitch_6  #0x1
    iget-object v0, p0, Lcom/github/catvod/spider/appysv2/b/h;->b:Ljava/lang/Object;

    check-cast v0, Lcom/github/catvod/spider/appysv2/b/M;

    iget-object v1, p0, Lcom/github/catvod/spider/appysv2/b/h;->c:Ljava/lang/Object;

    check-cast v1, Lorg/json/JSONObject;

    invoke-static {v0, v1}, Lcom/github/catvod/spider/appysv2/b/M;->g(Lcom/github/catvod/spider/appysv2/b/M;Lorg/json/JSONObject;)V

    return-void

    :pswitch_12  #0x0
    iget-object v0, p0, Lcom/github/catvod/spider/appysv2/b/h;->b:Ljava/lang/Object;

    check-cast v0, Lcom/github/catvod/spider/appysv2/b/x;

    iget-object v1, p0, Lcom/github/catvod/spider/appysv2/b/h;->c:Ljava/lang/Object;

    check-cast v1, Lcom/github/catvod/spider/appysv2/d/e;

    invoke-static {v0, v1}, Lcom/github/catvod/spider/appysv2/b/x;->i(Lcom/github/catvod/spider/appysv2/b/x;Lcom/github/catvod/spider/appysv2/d/e;)V

    return-void

    :goto_1e
    iget-object v0, p0, Lcom/github/catvod/spider/appysv2/b/h;->b:Ljava/lang/Object;

    check-cast v0, Lcom/github/catvod/spider/Bili;

    iget-object v1, p0, Lcom/github/catvod/spider/appysv2/b/h;->c:Ljava/lang/Object;

    check-cast v1, Lcom/github/catvod/spider/appysv2/g/b;

    invoke-static {v0, v1}, Lcom/github/catvod/spider/Bili;->d(Lcom/github/catvod/spider/Bili;Lcom/github/catvod/spider/appysv2/g/b;)V

    return-void

    :pswitch_data_2a
    .packed-switch 0x0
        :pswitch_12  #00000000
        :pswitch_6  #00000001
    .end packed-switch
.end method
