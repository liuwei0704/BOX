.class public final Lcom/github/catvod/spider/appysv2/b/F;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field private static final d:Ljava/lang/String;

.field private static final e:Ljava/lang/String;

.field private static final f:Ljava/lang/String;


# instance fields
.field private a:Ljava/lang/String;

.field private b:Landroid/app/AlertDialog;

.field private c:Z


# direct methods
.method static constructor <clinit>()V
    .registers 3

    const/16 v0, 0x29

    new-array v0, v0, [B

    fill-array-data v0, :array_38

    const/16 v1, 0x8

    new-array v2, v1, [B

    fill-array-data v2, :array_52

    invoke-static {v0, v2}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lcom/github/catvod/spider/appysv2/b/F;->d:Ljava/lang/String;

    const/16 v0, 0x16

    new-array v0, v0, [B

    fill-array-data v0, :array_5a

    new-array v2, v1, [B

    fill-array-data v2, :array_6a

    invoke-static {v0, v2}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lcom/github/catvod/spider/appysv2/b/F;->e:Ljava/lang/String;

    new-array v0, v1, [B

    fill-array-data v0, :array_72

    new-array v1, v1, [B

    fill-array-data v1, :array_7a

    invoke-static {v0, v1}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lcom/github/catvod/spider/appysv2/b/F;->f:Ljava/lang/String;

    return-void

    nop

    :array_38
    .array-data 1
        -0x7t
        0x3dt
        -0x12t
        -0x44t
        0x5dt
        0xct
        0x16t
        -0x3ft
        -0x3t
        0x26t
        -0x3t
        -0x5bt
        0x40t
        0x18t
        0x8t
        -0x24t
        -0x5et
        0x39t
        -0x5t
        -0x5et
        0x0t
        0x55t
        0x56t
        -0x7dt
        -0x42t
        0x28t
        -0x16t
        -0x5bt
        0x1t
        0x43t
        0x4at
        -0x75t
        -0x1dt
        0x66t
        -0x17t
        -0x5bt
        0x49t
        0x58t
        0x66t
        -0x79t
        -0x1t
    .end array-data

    nop

    :array_52
    .array-data 1
        -0x6ft
        0x49t
        -0x66t
        -0x34t
        0x2et
        0x36t
        0x39t
        -0x12t
    .end array-data

    :array_5a
    .array-data 1
        -0x3ft
        0x51t
        0x73t
        0x9t
        0x7ct
        0x1at
        0x46t
        0x50t
        -0x22t
        0x52t
        0x70t
        0x57t
        0x3et
        0x12t
        0x5at
        0xft
        -0x38t
        0x4bt
        0x29t
        0x1at
        0x60t
        0x4dt
    .end array-data

    nop

    :array_6a
    .array-data 1
        -0x57t
        0x25t
        0x7t
        0x79t
        0xft
        0x20t
        0x69t
        0x7ft
    .end array-data

    :array_72
    .array-data 1
        -0x6t
        0x6t
        -0x7dt
        -0x1bt
        -0xdt
        -0x80t
        0x5ft
        -0x3ft
    .end array-data

    :array_7a
    .array-data 1
        -0x51t
        0x75t
        -0x1at
        -0x69t
        -0x46t
        -0x12t
        0x39t
        -0x52t
    .end array-data
.end method

.method constructor <init>()V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x0

    iput-boolean v0, p0, Lcom/github/catvod/spider/appysv2/b/F;->c:Z

    invoke-static {}, Lcom/github/catvod/spider/Init;->checkPermission()V

    const/16 v0, 0xb

    new-array v0, v0, [B

    fill-array-data v0, :array_20

    const/16 v1, 0x8

    new-array v1, v1, [B

    fill-array-data v1, :array_2a

    invoke-static {v0, v1}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lcom/github/catvod/crawler/SpiderDebug;->log(Ljava/lang/String;)V

    return-void

    nop

    :array_20
    .array-data 1
        0x60t
        0x5t
        0x68t
        0x73t
        0x79t
        0x59t
        -0x74t
        -0x14t
        0x5et
        0xdt
        0x72t
    .end array-data

    :array_2a
    .array-data 1
        0x30t
        0x64t
        0x6t
        0x42t
        0x4bt
        0x6at
        -0x54t
        -0x5bt
    .end array-data
.end method

.method public static a(Lcom/github/catvod/spider/appysv2/b/F;[Ljava/lang/String;)V
    .registers 35

    invoke-virtual/range {p0 .. p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v0, 0x0

    .line 1
    aget-object v1, p1, v0

    const/4 v2, 0x1

    aget-object v3, p1, v2

    const/4 v4, 0x2

    aget-object v5, p1, v4

    const/4 v6, 0x3

    aget-object v7, p1, v6

    const/4 v8, 0x5

    aget-object v9, p1, v8

    .line 2
    :try_start_12
    invoke-direct/range {p0 .. p0}, Lcom/github/catvod/spider/appysv2/b/F;->m()I

    move-result v10

    move-object/from16 v11, p0

    invoke-direct {v11, v10}, Lcom/github/catvod/spider/appysv2/b/F;->h(I)V

    new-instance v12, Lcom/google/gson/JsonArray;

    invoke-direct {v12}, Lcom/google/gson/JsonArray;-><init>()V

    new-instance v13, Lcom/google/gson/JsonObject;

    invoke-direct {v13}, Lcom/google/gson/JsonObject;-><init>()V

    const/4 v14, 0x7

    new-array v14, v14, [B

    const/16 v15, 0x7f

    aput-byte v15, v14, v0

    const/16 v16, 0xc

    aput-byte v16, v14, v2

    const/16 v16, -0x41

    aput-byte v16, v14, v4

    const/16 v17, -0x27

    aput-byte v17, v14, v6

    const/16 v18, 0x4

    const/16 v19, -0x65

    aput-byte v19, v14, v18

    const/16 v18, -0x72

    aput-byte v18, v14, v8

    const/4 v8, 0x6

    aput-byte v17, v14, v8

    const/16 v15, 0x8

    new-array v15, v15, [B

    const/16 v17, 0x19

    aput-byte v17, v15, v0

    const/16 v17, 0x65

    aput-byte v17, v15, v2

    const/16 v17, -0x2d

    aput-byte v17, v15, v4

    const/16 v20, -0x44

    aput-byte v20, v15, v6

    const/16 v20, -0x3c

    const/16 v21, 0x4

    aput-byte v20, v15, v21

    const/16 v21, -0x19

    const/16 v22, 0x5

    aput-byte v21, v15, v22

    const/16 v21, -0x43

    aput-byte v21, v15, v8

    const/16 v22, 0x50

    const/16 v23, 0x7

    aput-byte v22, v15, v23

    invoke-static {v14, v15}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v14

    invoke-virtual {v13, v14, v3}, Lcom/google/gson/JsonObject;->addProperty(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x4

    new-array v3, v3, [B

    const/16 v14, -0x6f

    aput-byte v14, v3, v0

    const/16 v14, -0x2a

    aput-byte v14, v3, v2

    const/16 v14, -0x22

    aput-byte v14, v3, v4

    const/16 v14, -0xb

    aput-byte v14, v3, v6

    const/16 v14, 0x8

    new-array v14, v14, [B

    const/16 v15, -0x1e

    aput-byte v15, v14, v0

    aput-byte v16, v14, v2

    const/16 v23, -0x5c

    aput-byte v23, v14, v4

    const/16 v23, -0x70

    aput-byte v23, v14, v6

    const/16 v23, 0x28

    const/16 v24, 0x4

    aput-byte v23, v14, v24

    const/16 v23, 0x61

    const/16 v24, 0x5

    aput-byte v23, v14, v24

    const/16 v24, 0x10

    aput-byte v24, v14, v8

    const/16 v25, -0x1a

    const/16 v26, 0x7

    aput-byte v25, v14, v26

    invoke-static {v3, v14}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v13, v3, v9}, Lcom/google/gson/JsonObject;->addProperty(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x4

    new-array v3, v3, [B

    const/16 v9, 0x8

    aput-byte v9, v3, v0

    const/16 v14, -0x5b

    aput-byte v14, v3, v2

    const/4 v14, -0x1

    aput-byte v14, v3, v4

    const/16 v14, -0x4c

    aput-byte v14, v3, v6

    new-array v9, v9, [B

    const/16 v14, 0x6d

    aput-byte v14, v9, v0

    const/16 v25, -0x2f

    aput-byte v25, v9, v2

    const/16 v25, -0x62

    aput-byte v25, v9, v4

    aput-byte v17, v9, v6

    const/16 v17, -0x55

    const/16 v25, 0x4

    aput-byte v17, v9, v25

    const/16 v17, -0x17

    const/16 v25, 0x5

    aput-byte v17, v9, v25

    const/16 v25, 0x6b

    aput-byte v25, v9, v8

    const/16 v25, 0x41

    const/16 v26, 0x7

    aput-byte v25, v9, v26

    invoke-static {v3, v9}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v13, v3, v7}, Lcom/google/gson/JsonObject;->addProperty(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x4

    new-array v3, v3, [B

    const/16 v7, 0xa

    aput-byte v7, v3, v0

    const/16 v9, -0x5a

    aput-byte v9, v3, v2

    const/16 v9, -0x73

    aput-byte v9, v3, v4

    aput-byte v2, v3, v6

    const/16 v9, 0x8

    new-array v9, v9, [B

    const/16 v25, 0x7e

    aput-byte v25, v9, v0

    const/16 v25, -0x21

    aput-byte v25, v9, v2

    const/16 v25, -0x3

    aput-byte v25, v9, v4

    const/16 v25, 0x64

    aput-byte v25, v9, v6

    const/16 v25, -0x6c

    const/16 v26, 0x4

    aput-byte v25, v9, v26

    const/16 v25, -0x10

    const/16 v26, 0x5

    aput-byte v25, v9, v26

    aput-byte v17, v9, v8

    const/16 v25, -0x3b

    const/16 v26, 0x7

    aput-byte v25, v9, v26

    invoke-static {v3, v9}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v3

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v9

    invoke-virtual {v13, v3, v9}, Lcom/google/gson/JsonObject;->addProperty(Ljava/lang/String;Ljava/lang/Number;)V

    const/16 v3, 0xe

    new-array v9, v3, [B

    const/16 v25, 0x70

    aput-byte v25, v9, v0

    const/16 v25, 0x2a

    aput-byte v25, v9, v2

    const/16 v26, -0x2

    aput-byte v26, v9, v4

    const/16 v26, -0x13

    aput-byte v26, v9, v6

    const/16 v26, -0x60

    const/16 v27, 0x4

    aput-byte v26, v9, v27

    const/16 v26, 0x4b

    const/16 v27, 0x5

    aput-byte v26, v9, v27

    aput-byte v15, v9, v8

    const/16 v15, 0xb

    const/16 v26, 0x7

    aput-byte v15, v9, v26

    const/16 v26, 0x69

    const/16 v27, 0x8

    aput-byte v26, v9, v27

    const/16 v3, 0x9

    const/16 v28, 0x27

    aput-byte v28, v9, v3

    aput-byte v17, v9, v7

    const/16 v7, -0x29

    aput-byte v7, v9, v15

    const/16 v17, -0x59

    const/16 v29, 0xc

    aput-byte v17, v9, v29

    const/16 v17, 0x5b

    const/16 v29, 0xd

    aput-byte v17, v9, v29

    const/16 v15, 0x8

    new-array v15, v15, [B

    aput-byte v0, v15, v0

    const/16 v29, 0x4b

    aput-byte v29, v15, v2

    const/16 v29, -0x74

    aput-byte v29, v15, v4

    const/16 v29, -0x78

    aput-byte v29, v15, v6

    const/16 v29, -0x32

    const/16 v30, 0x4

    aput-byte v29, v15, v30

    const/16 v29, 0x3f

    const/16 v30, 0x5

    aput-byte v29, v15, v30

    aput-byte v21, v15, v8

    const/16 v30, 0x7

    aput-byte v14, v15, v30

    invoke-static {v9, v15}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v9

    invoke-static {v10}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v10

    invoke-virtual {v13, v9, v10}, Lcom/google/gson/JsonObject;->addProperty(Ljava/lang/String;Ljava/lang/Number;)V

    new-array v9, v3, [B

    const/16 v10, 0x3d

    aput-byte v10, v9, v0

    aput-byte v8, v9, v2

    const/16 v10, 0x22

    aput-byte v10, v9, v4

    const/16 v10, 0x77

    aput-byte v10, v9, v6

    const/16 v10, 0x24

    const/4 v15, 0x4

    aput-byte v10, v9, v15

    const/16 v10, -0x6e

    const/4 v15, 0x5

    aput-byte v10, v9, v15

    const/16 v10, 0xc

    aput-byte v10, v9, v8

    const/16 v10, -0x77

    const/4 v15, 0x7

    aput-byte v10, v9, v15

    const/16 v10, 0x3e

    const/16 v15, 0x8

    aput-byte v10, v9, v15

    new-array v10, v15, [B

    const/16 v15, 0x5b

    aput-byte v15, v10, v0

    const/16 v15, 0x6f

    aput-byte v15, v10, v2

    const/16 v15, 0x4e

    aput-byte v15, v10, v4

    const/16 v15, 0x12

    aput-byte v15, v10, v6

    const/16 v30, 0x7b

    const/16 v31, 0x4

    aput-byte v30, v10, v31

    const/16 v31, -0x4

    const/16 v32, 0x5

    aput-byte v31, v10, v32

    aput-byte v14, v10, v8

    const/16 v14, -0x1c

    const/16 v31, 0x7

    aput-byte v14, v10, v31

    invoke-static {v9, v10}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v13, v9, v5}, Lcom/google/gson/JsonObject;->addProperty(Ljava/lang/String;Ljava/lang/String;)V

    const/16 v5, 0x8

    new-array v5, v5, [B

    const/16 v9, 0x6a

    aput-byte v9, v5, v0

    const/16 v9, 0x74

    aput-byte v9, v5, v2

    const/16 v9, 0x4a

    aput-byte v9, v5, v4

    const/16 v9, -0x4e

    aput-byte v9, v5, v6

    const/16 v10, -0x6b

    const/4 v14, 0x4

    aput-byte v10, v5, v14

    const/4 v10, 0x5

    aput-byte v16, v5, v10

    const/16 v10, -0x23

    aput-byte v10, v5, v8

    const/4 v10, 0x7

    aput-byte v15, v5, v10

    const/16 v10, 0x8

    new-array v10, v10, [B

    const/16 v14, 0xe

    aput-byte v14, v10, v0

    aput-byte v8, v10, v2

    const/16 v14, 0x23

    aput-byte v14, v10, v4

    aput-byte v20, v10, v6

    const/4 v15, 0x4

    const/16 v16, -0x10

    aput-byte v16, v10, v15

    const/16 v15, -0x20

    const/16 v16, 0x5

    aput-byte v15, v10, v16

    const/16 v15, -0x4c

    aput-byte v15, v10, v8

    const/16 v15, 0x76

    const/16 v16, 0x7

    aput-byte v15, v10, v16

    invoke-static {v5, v10}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v10

    invoke-virtual {v13, v5, v10}, Lcom/google/gson/JsonObject;->addProperty(Ljava/lang/String;Ljava/lang/Number;)V

    invoke-virtual {v12, v13}, Lcom/google/gson/JsonArray;->add(Lcom/google/gson/JsonElement;)V

    new-instance v5, Lcom/google/gson/JsonObject;

    invoke-direct {v5}, Lcom/google/gson/JsonObject;-><init>()V

    new-array v10, v3, [B

    aput-byte v26, v10, v0

    const/16 v13, -0x21

    aput-byte v13, v10, v2

    const/16 v13, 0xe

    aput-byte v13, v10, v4

    aput-byte v7, v10, v6

    const/4 v13, 0x4

    aput-byte v14, v10, v13

    const/16 v13, -0x45

    const/4 v14, 0x5

    aput-byte v13, v10, v14

    const/16 v13, -0x51

    aput-byte v13, v10, v8

    const/4 v13, 0x7

    aput-byte v29, v10, v13

    const/16 v13, 0x8

    aput-byte v30, v10, v13

    new-array v13, v13, [B

    const/16 v14, 0xf

    aput-byte v14, v13, v0

    const/16 v14, -0x4a

    aput-byte v14, v13, v2

    const/16 v15, 0x62

    aput-byte v15, v13, v4

    aput-byte v9, v13, v6

    const/16 v15, 0x7c

    const/16 v16, 0x4

    aput-byte v15, v13, v16

    const/4 v15, 0x5

    aput-byte v7, v13, v15

    const/16 v7, -0x3a

    aput-byte v7, v13, v8

    const/16 v7, 0x4c

    const/4 v15, 0x7

    aput-byte v7, v13, v15

    invoke-static {v10, v13}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v5, v10, v12}, Lcom/google/gson/JsonObject;->add(Ljava/lang/String;Lcom/google/gson/JsonElement;)V

    new-array v10, v3, [B

    const/16 v12, -0x1b

    aput-byte v12, v10, v0

    aput-byte v28, v10, v2

    aput-byte v19, v10, v4

    const/16 v12, 0x46

    aput-byte v12, v10, v6

    const/4 v12, 0x4

    aput-byte v21, v10, v12

    const/16 v12, -0x61

    const/4 v13, 0x5

    aput-byte v12, v10, v13

    const/16 v13, 0x7a

    aput-byte v13, v10, v8

    const/16 v13, 0x14

    const/4 v15, 0x7

    aput-byte v13, v10, v15

    const/16 v15, -0x11

    const/16 v12, 0x8

    aput-byte v15, v10, v12

    new-array v12, v12, [B

    const/16 v15, -0x6a

    aput-byte v15, v12, v0

    const/16 v15, 0x4f

    aput-byte v15, v12, v2

    const/16 v19, -0x6

    aput-byte v19, v12, v4

    const/16 v20, 0x34

    aput-byte v20, v12, v6

    const/16 v20, -0x28

    const/16 v21, 0x4

    aput-byte v20, v12, v21

    const/16 v20, -0x40

    const/16 v21, 0x5

    aput-byte v20, v12, v21

    const/16 v20, 0x11

    aput-byte v20, v12, v8

    const/16 v20, 0x71

    const/16 v21, 0x7

    aput-byte v20, v12, v21

    invoke-static {v10, v12}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v5, v10, v1}, Lcom/google/gson/JsonObject;->addProperty(Ljava/lang/String;Ljava/lang/String;)V

    const/16 v1, 0xd

    new-array v1, v1, [B

    const/16 v10, -0x14

    aput-byte v10, v1, v0

    aput-byte v13, v1, v2

    aput-byte v9, v1, v4

    const/16 v9, -0x11

    aput-byte v9, v1, v6

    const/16 v9, 0x68

    const/4 v10, 0x4

    aput-byte v9, v1, v10

    const/4 v9, 0x5

    aput-byte v15, v1, v9

    const/16 v9, 0x71

    aput-byte v9, v1, v8

    const/4 v9, 0x7

    aput-byte v7, v1, v9

    const/16 v9, -0x1d

    const/16 v10, 0x8

    aput-byte v9, v1, v10

    const/4 v9, 0x4

    aput-byte v9, v1, v3

    const/16 v9, 0xa

    aput-byte v14, v1, v9

    const/4 v9, -0x8

    const/16 v12, 0xb

    aput-byte v9, v1, v12

    const/16 v9, 0xc

    aput-byte v23, v1, v9

    new-array v9, v10, [B

    const/16 v10, -0x71

    aput-byte v10, v9, v0

    aput-byte v23, v9, v2

    const/16 v10, -0x40

    aput-byte v10, v9, v4

    const/16 v10, -0x63

    aput-byte v10, v9, v6

    const/4 v12, 0x4

    const/16 v14, 0xd

    aput-byte v14, v9, v12

    const/16 v12, 0x21

    const/4 v14, 0x5

    aput-byte v12, v9, v14

    aput-byte v14, v9, v8

    const/16 v12, 0x13

    const/4 v14, 0x7

    aput-byte v12, v9, v14

    invoke-static {v1, v9}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v9

    invoke-virtual {v5, v1, v9}, Lcom/google/gson/JsonObject;->addProperty(Ljava/lang/String;Ljava/lang/Number;)V

    const/4 v1, 0x5

    new-array v1, v1, [B

    const/16 v9, 0x57

    aput-byte v9, v1, v0

    const/16 v9, 0x38

    aput-byte v9, v1, v2

    aput-byte v19, v1, v4

    aput-byte v12, v1, v6

    const/4 v9, 0x4

    aput-byte v12, v1, v9

    const/16 v9, 0x8

    new-array v9, v9, [B

    const/16 v12, 0x32

    aput-byte v12, v9, v0

    const/16 v12, 0x4e

    aput-byte v12, v9, v2

    const/16 v12, -0x61

    aput-byte v12, v9, v4

    const/16 v12, 0x7d

    aput-byte v12, v9, v6

    const/16 v12, 0x67

    const/4 v14, 0x4

    aput-byte v12, v9, v14

    const/16 v12, 0x51

    const/4 v14, 0x5

    aput-byte v12, v9, v14

    const/16 v12, 0x6b

    aput-byte v12, v9, v8

    const/16 v12, 0x4d

    const/4 v14, 0x7

    aput-byte v12, v9, v14

    invoke-static {v1, v9}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v1

    const/16 v9, 0x8

    new-array v9, v9, [B

    const/16 v12, 0x30

    aput-byte v12, v9, v0

    aput-byte v25, v9, v2

    const/16 v12, 0x34

    aput-byte v12, v9, v4

    const/16 v12, 0x3b

    aput-byte v12, v9, v6

    const/16 v12, -0x12

    const/4 v14, 0x4

    aput-byte v12, v9, v14

    const/16 v12, -0x18

    const/4 v14, 0x5

    aput-byte v12, v9, v14

    aput-byte v25, v9, v8

    const/4 v12, 0x7

    aput-byte v3, v9, v12

    const/16 v12, 0x8

    new-array v12, v12, [B

    const/16 v14, 0x44

    aput-byte v14, v12, v0

    const/16 v14, 0x58

    aput-byte v14, v12, v2

    const/16 v14, 0x55

    aput-byte v14, v12, v4

    const/16 v14, 0x55

    aput-byte v14, v12, v6

    const/4 v14, 0x4

    aput-byte v10, v12, v14

    const/4 v14, 0x5

    aput-byte v18, v12, v14

    aput-byte v15, v12, v8

    const/4 v14, 0x7

    aput-byte v30, v12, v14

    invoke-static {v9, v12}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v5, v1, v9}, Lcom/google/gson/JsonObject;->addProperty(Ljava/lang/String;Ljava/lang/String;)V

    new-array v1, v14, [B

    const/16 v9, 0x2e

    aput-byte v9, v1, v0

    const/16 v9, 0x53

    aput-byte v9, v1, v2

    const/4 v9, -0x8

    aput-byte v9, v1, v4

    const/4 v9, 0x4

    aput-byte v9, v1, v6

    const/16 v12, 0x31

    aput-byte v12, v1, v9

    const/4 v9, 0x5

    aput-byte v29, v1, v9

    const/16 v9, -0x1e

    aput-byte v9, v1, v8

    const/16 v9, 0x8

    new-array v9, v9, [B

    const/16 v12, 0x48

    aput-byte v12, v9, v0

    const/16 v12, 0x3a

    aput-byte v12, v9, v2

    const/16 v12, -0x6c

    aput-byte v12, v9, v4

    aput-byte v23, v9, v6

    const/4 v12, 0x4

    const/16 v14, 0x7f

    aput-byte v14, v9, v12

    const/16 v12, 0x4a

    const/4 v14, 0x5

    aput-byte v12, v9, v14

    const/16 v12, -0x71

    aput-byte v12, v9, v8

    const/4 v12, 0x7

    aput-byte v13, v9, v12

    invoke-static {v1, v9}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v9

    invoke-virtual {v5, v1, v9}, Lcom/google/gson/JsonObject;->addProperty(Ljava/lang/String;Ljava/lang/Number;)V

    const/16 v1, 0xc

    new-array v1, v1, [B

    const/16 v9, -0x58

    aput-byte v9, v1, v0

    const/16 v9, 0x33

    aput-byte v9, v1, v2

    aput-byte v19, v1, v4

    const/16 v9, 0x2c

    aput-byte v9, v1, v6

    const/16 v9, 0x44

    const/4 v12, 0x4

    aput-byte v9, v1, v12

    const/4 v9, 0x5

    aput-byte v26, v1, v9

    const/16 v9, -0x25

    aput-byte v9, v1, v8

    const/16 v9, 0x56

    const/4 v12, 0x7

    aput-byte v9, v1, v12

    const/16 v9, -0x55

    const/16 v12, 0x8

    aput-byte v9, v1, v12

    const/16 v9, 0x22

    aput-byte v9, v1, v3

    const/4 v9, -0x4

    const/16 v14, 0xa

    aput-byte v9, v1, v14

    const/16 v9, 0x3b

    const/16 v14, 0xb

    aput-byte v9, v1, v14

    new-array v9, v12, [B

    const/16 v12, -0x39

    aput-byte v12, v9, v0

    const/16 v12, 0x43

    aput-byte v12, v9, v2

    const/16 v12, -0x61

    aput-byte v12, v9, v4

    const/16 v12, 0x5e

    aput-byte v12, v9, v6

    const/16 v12, 0x25

    const/4 v14, 0x4

    aput-byte v12, v9, v14

    const/16 v12, 0x1d

    const/4 v14, 0x5

    aput-byte v12, v9, v14

    const/16 v12, -0x42

    aput-byte v12, v9, v8

    const/4 v12, 0x7

    aput-byte v8, v9, v12

    invoke-static {v1, v9}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v9

    invoke-virtual {v5, v1, v9}, Lcom/google/gson/JsonObject;->addProperty(Ljava/lang/String;Ljava/lang/Number;)V

    const/16 v1, 0x2c

    new-array v1, v1, [B

    const/4 v9, -0x7

    aput-byte v9, v1, v0

    const/16 v9, -0x54

    aput-byte v9, v1, v2

    const/16 v9, -0x79

    aput-byte v9, v1, v4

    const/16 v9, -0x22

    aput-byte v9, v1, v6

    const/4 v9, 0x4

    aput-byte v7, v1, v9

    const/16 v7, -0x59

    const/4 v9, 0x5

    aput-byte v7, v1, v9

    const/16 v7, -0x16

    aput-byte v7, v1, v8

    const/16 v9, -0x52

    const/4 v12, 0x7

    aput-byte v9, v1, v12

    const/16 v9, -0x1a

    const/16 v12, 0x8

    aput-byte v9, v1, v12

    const/16 v9, -0x51

    aput-byte v9, v1, v3

    const/16 v3, -0x7c

    const/16 v12, 0xa

    aput-byte v3, v1, v12

    const/16 v3, -0x80

    const/16 v12, 0xb

    aput-byte v3, v1, v12

    const/16 v3, 0xe

    const/16 v12, 0xc

    aput-byte v3, v1, v12

    const/16 v12, 0xd

    aput-byte v9, v1, v12

    const/16 v9, -0xa

    aput-byte v9, v1, v3

    const/16 v3, 0xf

    const/16 v9, -0xf

    aput-byte v9, v1, v3

    const/16 v3, -0x10

    aput-byte v3, v1, v24

    const/16 v3, 0x11

    const/16 v9, -0x4a

    aput-byte v9, v1, v3

    const/16 v3, -0x23

    const/16 v9, 0x12

    aput-byte v3, v1, v9

    const/16 v3, -0x33

    const/16 v9, 0x13

    aput-byte v3, v1, v9

    aput-byte v22, v1, v13

    const/16 v3, 0x15

    const/16 v9, -0x10

    aput-byte v9, v1, v3

    const/16 v3, 0x16

    aput-byte v7, v1, v3

    const/16 v3, 0x17

    const/16 v9, -0x1d

    aput-byte v9, v1, v3

    const/16 v3, 0x18

    const/16 v9, -0x42

    aput-byte v9, v1, v3

    const/16 v3, -0x47

    const/16 v9, 0x19

    aput-byte v3, v1, v9

    const/16 v3, 0x1a

    const/16 v9, -0x7d

    aput-byte v9, v1, v3

    const/16 v3, 0x1b

    const/16 v9, -0x39

    aput-byte v9, v1, v3

    const/16 v3, 0x1c

    aput-byte v24, v1, v3

    const/16 v3, 0x1d

    const/4 v9, -0x5

    aput-byte v9, v1, v3

    const/16 v3, 0x1e

    const/16 v9, -0x54

    aput-byte v9, v1, v3

    const/16 v3, 0x1f

    const/16 v9, -0x13

    aput-byte v9, v1, v3

    const/16 v3, 0x20

    const/16 v9, -0xc

    aput-byte v9, v1, v3

    const/16 v3, 0x21

    const/16 v9, -0x9

    aput-byte v9, v1, v3

    const/16 v3, -0x70

    const/16 v9, 0x22

    aput-byte v3, v1, v9

    const/16 v3, -0x3f

    const/16 v9, 0x23

    aput-byte v3, v1, v9

    const/16 v3, 0x24

    aput-byte v15, v1, v3

    const/16 v3, 0x25

    const/16 v9, -0x1c

    aput-byte v9, v1, v3

    const/16 v3, 0x26

    aput-byte v7, v1, v3

    const/16 v3, -0x20

    aput-byte v3, v1, v28

    const/16 v3, 0x28

    const/16 v7, -0x1e

    aput-byte v7, v1, v3

    const/16 v3, 0x29

    const/16 v7, -0x5f

    aput-byte v7, v1, v3

    aput-byte v10, v1, v25

    const/16 v3, 0x2b

    const/16 v7, -0x33

    aput-byte v7, v1, v3

    const/16 v3, 0x8

    new-array v3, v3, [B

    const/16 v7, -0x6f

    aput-byte v7, v3, v0

    const/16 v0, -0x28

    aput-byte v0, v3, v2

    const/16 v0, -0xd

    aput-byte v0, v3, v4

    const/16 v0, -0x52

    aput-byte v0, v3, v6

    const/4 v0, 0x4

    aput-byte v29, v3, v0

    const/4 v0, 0x5

    aput-byte v10, v3, v0

    const/16 v0, -0x3b

    aput-byte v0, v3, v8

    const/16 v0, -0x7f

    const/4 v2, 0x7

    aput-byte v0, v3, v2

    invoke-static {v1, v3}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v5}, Lcom/google/gson/JsonElement;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct/range {p0 .. p0}, Lcom/github/catvod/spider/appysv2/b/F;->l()Ljava/util/Map;

    move-result-object v2

    invoke-static {v0, v1, v2}, Lcom/github/catvod/spider/appysv2/n/c;->g(Ljava/lang/String;Ljava/lang/String;Ljava/util/Map;)Lcom/github/catvod/spider/appysv2/n/e;
    :try_end_5a6
    .catch Ljava/lang/Exception; {:try_start_12 .. :try_end_5a6} :catch_5a7

    goto :goto_5be

    :catch_5a7
    move-exception v0

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/16 v2, 0xd

    new-array v2, v2, [B

    fill-array-data v2, :array_5c0

    const/16 v3, 0x8

    new-array v3, v3, [B

    fill-array-data v3, :array_5cc

    .line 3
    invoke-static {v2, v3, v1, v0}, Lcom/github/catvod/spider/appysv2/b/y;->b([B[BLjava/lang/StringBuilder;Ljava/lang/Exception;)V

    :goto_5be
    return-void

    nop

    :array_5c0
    .array-data 1
        -0x49t
        -0x56t
        0x11t
        -0x7dt
        -0x3dt
        -0x58t
        0x27t
        -0x35t
        -0x49t
        -0x1bt
        0x4t
        -0x78t
        -0x10t
    .end array-data

    nop

    :array_5cc
    .array-data 1
        -0x2ct
        -0x3bt
        0x61t
        -0x6t
        -0x7et
        -0x25t
        0x5et
        -0x5bt
    .end array-data
.end method

.method public static synthetic b(Lcom/github/catvod/spider/appysv2/b/F;)V
    .registers 2

    const/4 v0, 0x0

    iput-boolean v0, p0, Lcom/github/catvod/spider/appysv2/b/F;->c:Z

    return-void
.end method

.method public static c(Lcom/github/catvod/spider/appysv2/b/F;Landroid/widget/EditText;Landroid/widget/EditText;)V
    .registers 4

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1
    invoke-virtual {p1}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p2}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object p2

    invoke-virtual {p2}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p2

    .line 2
    invoke-direct {p0}, Lcom/github/catvod/spider/appysv2/b/F;->i()V

    new-instance v0, Lcom/github/catvod/spider/appysv2/b/D;

    invoke-direct {v0, p0, p1, p2}, Lcom/github/catvod/spider/appysv2/b/D;-><init>(Lcom/github/catvod/spider/appysv2/b/F;Ljava/lang/String;Ljava/lang/String;)V

    invoke-static {v0}, Lcom/github/catvod/spider/Init;->execute(Ljava/lang/Runnable;)V

    return-void
.end method

.method public static synthetic d(Lcom/github/catvod/spider/appysv2/b/F;Ljava/lang/String;Ljava/lang/String;)V
    .registers 16

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0x8

    .line 1
    :try_start_5
    new-instance v1, Lorg/json/JSONObject;

    invoke-direct {v1}, Lorg/json/JSONObject;-><init>()V

    new-array v2, v0, [B

    const/16 v3, -0x58

    const/4 v4, 0x0

    aput-byte v3, v2, v4

    const/16 v3, 0x68

    const/4 v5, 0x1

    aput-byte v3, v2, v5

    const/16 v3, -0x6f

    const/4 v6, 0x2

    aput-byte v3, v2, v6

    const/16 v3, 0x20

    const/4 v7, 0x3

    aput-byte v3, v2, v7

    const/16 v3, 0x77

    const/4 v8, 0x4

    aput-byte v3, v2, v8

    const/16 v3, 0x6a

    const/4 v9, 0x5

    aput-byte v3, v2, v9

    const/16 v3, -0x5b

    const/4 v10, 0x6

    aput-byte v3, v2, v10

    const/16 v3, -0x52

    const/4 v11, 0x7

    aput-byte v3, v2, v11

    new-array v3, v0, [B

    const/16 v12, -0x23

    aput-byte v12, v3, v4

    const/16 v12, 0x1b

    aput-byte v12, v3, v5

    const/16 v12, -0xc

    aput-byte v12, v3, v6

    const/16 v12, 0x52

    aput-byte v12, v3, v7

    const/16 v12, 0x19

    aput-byte v12, v3, v8

    const/16 v12, 0xb

    aput-byte v12, v3, v9

    const/16 v12, -0x38

    aput-byte v12, v3, v10

    const/16 v12, -0x35

    aput-byte v12, v3, v11

    invoke-static {v2, v3}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2, p1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    new-array p1, v0, [B

    const/16 v2, -0x64

    aput-byte v2, p1, v4

    const/16 v2, 0x1e

    aput-byte v2, p1, v5

    const/4 v2, -0x1

    aput-byte v2, p1, v6

    aput-byte v5, p1, v7

    const/16 v2, -0x9

    aput-byte v2, p1, v8

    const/16 v2, 0x7c

    aput-byte v2, p1, v9

    aput-byte v4, p1, v10

    const/4 v2, -0x3

    aput-byte v2, p1, v11

    new-array v2, v0, [B

    const/16 v3, -0x14

    aput-byte v3, v2, v4

    const/16 v3, 0x7f

    aput-byte v3, v2, v5

    const/16 v3, -0x74

    aput-byte v3, v2, v6

    const/16 v3, 0x72

    aput-byte v3, v2, v7

    const/16 v4, -0x80

    aput-byte v4, v2, v8

    const/16 v4, 0x13

    aput-byte v4, v2, v9

    aput-byte v3, v2, v10

    const/16 v3, -0x67

    aput-byte v3, v2, v11

    invoke-static {p1, v2}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v1, p1, p2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    sget-object p1, Lcom/github/catvod/spider/appysv2/b/F;->f:Ljava/lang/String;

    invoke-virtual {v1}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object p2

    invoke-static {p1, p2}, Lcom/github/catvod/spider/appysv2/p/C;->u(Ljava/lang/String;Ljava/lang/String;)V

    invoke-direct {p0, v5}, Lcom/github/catvod/spider/appysv2/b/F;->q(Z)Z

    move-result p1

    if-nez p1, :cond_c8

    invoke-virtual {p0}, Lcom/github/catvod/spider/appysv2/b/F;->o()V
    :try_end_b2
    .catch Ljava/lang/Exception; {:try_start_5 .. :try_end_b2} :catch_b3

    goto :goto_c8

    :catch_b3
    move-exception p0

    new-instance p1, Ljava/lang/StringBuilder;

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const/16 p2, 0x10

    new-array p2, p2, [B

    fill-array-data p2, :array_ca

    new-array v0, v0, [B

    fill-array-data v0, :array_d6

    .line 2
    invoke-static {p2, v0, p1, p0}, Lcom/github/catvod/spider/appysv2/b/y;->b([B[BLjava/lang/StringBuilder;Ljava/lang/Exception;)V

    :cond_c8
    :goto_c8
    return-void

    nop

    :array_ca
    .array-data 1
        0x6et
        -0x53t
        0x53t
        0x2dt
        -0x5at
        -0x4dt
        0x5ft
        0x4bt
        0x77t
        -0x5at
        0x23t
        0x27t
        -0x59t
        -0x58t
        0x11t
        0x2t
    .end array-data

    :array_d6
    .array-data 1
        0x1t
        -0x3dt
        0x3t
        0x42t
        -0x2bt
        -0x26t
        0x2bt
        0x22t
    .end array-data
.end method

.method public static synthetic e(Lcom/github/catvod/spider/appysv2/b/F;)V
    .registers 21

    move-object/from16 v0, p0

    invoke-virtual/range {p0 .. p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    :goto_5
    :try_start_5
    iget-boolean v1, v0, Lcom/github/catvod/spider/appysv2/b/F;->c:Z

    if-eqz v1, :cond_163

    sget-object v1, Lcom/github/catvod/spider/appysv2/b/F;->f:Ljava/lang/String;

    invoke-static {v1}, Lcom/github/catvod/spider/appysv2/p/C;->q(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/16 v3, 0xa

    new-array v4, v3, [B

    const/16 v5, -0x44

    const/4 v6, 0x0

    aput-byte v5, v4, v6

    const/16 v7, 0x78

    const/4 v8, 0x1

    aput-byte v7, v4, v8

    const/16 v7, -0x3e

    const/4 v9, 0x2

    aput-byte v7, v4, v9

    const/16 v7, -0x76

    const/4 v10, 0x3

    aput-byte v7, v4, v10

    const/16 v7, 0x3d

    const/4 v11, 0x4

    aput-byte v7, v4, v11

    const/16 v7, -0x19

    const/4 v12, 0x5

    aput-byte v7, v4, v12

    const/16 v7, 0x64

    const/4 v13, 0x6

    aput-byte v7, v4, v13

    const/4 v7, 0x7

    const/16 v14, -0x3c

    aput-byte v14, v4, v7

    const/16 v15, -0xd

    const/16 v14, 0x8

    aput-byte v15, v4, v14

    const/16 v15, 0x2b

    const/16 v16, 0x9

    aput-byte v15, v4, v16

    new-array v15, v14, [B

    const/16 v17, -0x37

    aput-byte v17, v15, v6

    const/16 v17, 0xb

    aput-byte v17, v15, v8

    const/16 v18, -0x59

    aput-byte v18, v15, v9

    const/16 v18, -0x8

    aput-byte v18, v15, v10

    const/16 v18, 0x74

    aput-byte v18, v15, v11

    const/16 v18, -0x77

    aput-byte v18, v15, v12

    aput-byte v9, v15, v13

    const/16 v18, -0x55

    aput-byte v18, v15, v7

    invoke-static {v4, v15}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Lcom/github/catvod/crawler/SpiderDebug;->log(Ljava/lang/String;)V

    invoke-static {v1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_157

    const/16 v1, 0x23

    new-array v1, v1, [B

    const/16 v2, 0x45

    aput-byte v2, v1, v6

    const/16 v2, 0x1c

    aput-byte v2, v1, v8

    aput-byte v16, v1, v9

    const/16 v4, 0x26

    aput-byte v4, v1, v10

    const/16 v4, 0x14

    aput-byte v4, v1, v11

    const/16 v15, -0x47

    aput-byte v15, v1, v12

    const/16 v15, -0x2e

    aput-byte v15, v1, v13

    const/16 v15, -0x23

    aput-byte v15, v1, v7

    const/16 v15, 0x32

    aput-byte v15, v1, v14

    const/16 v19, 0x60

    aput-byte v19, v1, v16

    const/16 v16, 0x38

    aput-byte v16, v1, v3

    const/16 v3, 0x5c

    aput-byte v3, v1, v17

    const/16 v3, -0x7b

    const/16 v16, 0xc

    aput-byte v3, v1, v16

    const/16 v17, 0xd

    aput-byte v16, v1, v17

    const/16 v16, 0xe

    const/16 v17, -0x24

    aput-byte v17, v1, v16

    const/16 v16, 0xf

    const/16 v17, -0x6

    aput-byte v17, v1, v16

    const/16 v16, 0x10

    const/16 v17, 0x15

    aput-byte v17, v1, v16

    const/16 v16, 0x11

    const/16 v19, 0x6c

    aput-byte v19, v1, v16

    const/16 v16, 0x12

    aput-byte v15, v1, v16

    const/16 v15, 0x13

    const/16 v16, 0x43

    aput-byte v16, v1, v15

    const/16 v15, 0x4c

    aput-byte v15, v1, v4

    aput-byte v18, v1, v17

    const/16 v4, 0x16

    const/16 v15, -0x72

    aput-byte v15, v1, v4

    const/16 v4, 0x17

    aput-byte v5, v1, v4

    const/16 v5, 0x25

    const/16 v15, 0x18

    aput-byte v5, v1, v15

    const/16 v5, 0x19

    aput-byte v14, v1, v5

    const/16 v16, 0x1a

    const/16 v17, 0x54

    aput-byte v17, v1, v16

    const/16 v16, 0x1b

    const/16 v17, 0x55

    aput-byte v17, v1, v16

    aput-byte v5, v1, v2

    const/16 v2, 0x1d

    const/16 v5, -0x3c

    aput-byte v5, v1, v2

    const/16 v2, 0x1e

    const/16 v5, -0x75

    aput-byte v5, v1, v2

    const/16 v2, 0x1f

    const/16 v5, -0x32

    aput-byte v5, v1, v2

    const/16 v2, 0x20

    const/16 v5, 0x44

    aput-byte v5, v1, v2

    const/16 v2, 0x21

    aput-byte v15, v1, v2

    const/16 v2, 0x22

    aput-byte v4, v1, v2

    new-array v2, v14, [B

    const/16 v4, -0x5e

    aput-byte v4, v2, v6

    aput-byte v3, v2, v8

    const/16 v3, -0x4e

    aput-byte v3, v2, v9

    const/16 v3, -0x3d

    aput-byte v3, v2, v10

    const/16 v3, -0x57

    aput-byte v3, v2, v11

    const/16 v3, 0x2c

    aput-byte v3, v2, v12

    const/16 v3, 0x34

    aput-byte v3, v2, v13

    aput-byte v17, v2, v7

    invoke-static {v1, v2}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Lcom/github/catvod/spider/appysv2/p/j;->b(Ljava/lang/String;)V

    invoke-direct {v0, v6}, Lcom/github/catvod/spider/appysv2/b/F;->q(Z)Z

    iget-object v0, v0, Lcom/github/catvod/spider/appysv2/b/F;->b:Landroid/app/AlertDialog;

    invoke-virtual {v0}, Landroid/app/Dialog;->dismiss()V

    goto :goto_163

    :cond_157
    const-wide/16 v1, 0x3e8

    invoke-static {v1, v2}, Ljava/lang/Thread;->sleep(J)V
    :try_end_15c
    .catch Ljava/lang/InterruptedException; {:try_start_5 .. :try_end_15c} :catch_15e

    goto/16 :goto_5

    :catch_15e
    const-string v0, ""

    invoke-static {v0}, Lcom/github/catvod/crawler/SpiderDebug;->log(Ljava/lang/String;)V

    :cond_163
    :goto_163
    return-void
.end method

.method public static synthetic f(Lcom/github/catvod/spider/appysv2/b/F;)V
    .registers 1

    invoke-direct {p0}, Lcom/github/catvod/spider/appysv2/b/F;->i()V

    return-void
.end method

.method public static g(Ljava/lang/String;)J
    .registers 5

    const/4 v0, 0x6

    new-array v0, v0, [B

    fill-array-data v0, :array_60

    const/16 v1, 0x8

    new-array v2, v1, [B

    fill-array-data v2, :array_68

    invoke-static {v0, v2}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x5

    new-array v2, v2, [B

    fill-array-data v2, :array_70

    new-array v3, v1, [B

    fill-array-data v3, :array_78

    invoke-static {v2, v3}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {p0, v0, v2}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object p0

    new-instance v0, Ljava/text/SimpleDateFormat;

    const/16 v2, 0x1a

    new-array v2, v2, [B

    fill-array-data v2, :array_80

    new-array v3, v1, [B

    fill-array-data v3, :array_92

    invoke-static {v2, v3}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-direct {v0, v2}, Ljava/text/SimpleDateFormat;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x3

    new-array v2, v2, [B

    fill-array-data v2, :array_9a

    new-array v1, v1, [B

    fill-array-data v1, :array_a0

    invoke-static {v2, v1}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Ljava/util/TimeZone;->getTimeZone(Ljava/lang/String;)Ljava/util/TimeZone;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/text/DateFormat;->setTimeZone(Ljava/util/TimeZone;)V

    :try_start_4f
    invoke-virtual {v0, p0}, Ljava/text/DateFormat;->parse(Ljava/lang/String;)Ljava/util/Date;

    move-result-object p0

    invoke-virtual {p0}, Ljava/util/Date;->getTime()J

    move-result-wide v0
    :try_end_57
    .catch Ljava/lang/Exception; {:try_start_4f .. :try_end_57} :catch_58

    return-wide v0

    :catch_58
    move-exception p0

    invoke-virtual {p0}, Ljava/lang/Throwable;->printStackTrace()V

    const-wide/16 v0, 0x0

    return-wide v0

    nop

    :array_60
    .array-data 1
        -0x30t
        0x56t
        0x4ct
        -0x41t
        0x16t
        -0xft
    .end array-data

    nop

    :array_68
    .array-data 1
        -0x5t
        0x66t
        0x74t
        -0x7bt
        0x26t
        -0x3ft
        -0x76t
        -0x6t
    .end array-data

    :array_70
    .array-data 1
        -0x5at
        0x36t
        0x6t
        0x53t
        0x3t
    .end array-data

    nop

    :array_78
    .array-data 1
        -0x73t
        0x6t
        0x3et
        0x63t
        0x33t
        0x32t
        -0x66t
        -0x2ft
    .end array-data

    :array_80
    .array-data 1
        0x31t
        0x25t
        -0x77t
        0x49t
        0x44t
        -0x5at
        0x1t
        -0x37t
        0x2ct
        0x38t
        -0x29t
        0x64t
        0x4et
        -0x5dt
        0x4t
        -0x22t
        0x25t
        0x31t
        -0x36t
        0x43t
        0x1at
        -0x4ft
        0x16t
        -0x42t
        0x12t
        0x6t
    .end array-data

    nop

    :array_92
    .array-data 1
        0x48t
        0x5ct
        -0x10t
        0x30t
        0x69t
        -0x15t
        0x4ct
        -0x1ct
    .end array-data

    :array_9a
    .array-data 1
        -0x79t
        -0xct
        0x7ft
    .end array-data

    :array_a0
    .array-data 1
        -0x2et
        -0x60t
        0x3ct
        0x68t
        0x4ft
        -0x66t
        -0x1dt
        0x46t
    .end array-data
.end method

.method private h(I)V
    .registers 30

    const/16 v1, 0x10

    const/16 v2, 0x8

    :try_start_4
    invoke-static {}, Lcom/github/catvod/spider/appysv2/p/C;->j()J

    move-result-wide v3

    new-instance v5, Lcom/google/gson/JsonArray;

    invoke-direct {v5}, Lcom/google/gson/JsonArray;-><init>()V

    new-instance v6, Lcom/google/gson/Gson;

    invoke-direct {v6}, Lcom/google/gson/Gson;-><init>()V

    :goto_12
    new-instance v7, Ljava/lang/StringBuilder;

    invoke-direct {v7}, Ljava/lang/StringBuilder;-><init>()V

    const/16 v8, 0x3b

    new-array v8, v8, [B

    const/16 v9, 0xa

    const/4 v10, 0x0

    aput-byte v9, v8, v10

    const/16 v11, -0x43

    const/4 v12, 0x1

    aput-byte v11, v8, v12

    const/16 v11, -0x2e

    const/4 v13, 0x2

    aput-byte v11, v8, v13

    const/16 v11, -0x24

    const/4 v14, 0x3

    aput-byte v11, v8, v14

    const/4 v11, -0x8

    const/4 v15, 0x4

    aput-byte v11, v8, v15

    const/4 v11, 0x5

    aput-byte v15, v8, v11

    const/16 v11, 0x5b

    const/16 v16, 0x6

    aput-byte v11, v8, v16

    const/4 v11, -0x2

    const/4 v15, 0x7

    aput-byte v11, v8, v15

    const/16 v11, 0x15

    aput-byte v11, v8, v2

    const/16 v11, -0x42

    const/16 v18, 0x9

    aput-byte v11, v8, v18

    const/16 v11, -0x2f

    aput-byte v11, v8, v9

    const/16 v9, -0x7e

    const/16 v11, 0xb

    aput-byte v9, v8, v11

    const/16 v9, -0x46

    const/16 v18, 0xc

    aput-byte v9, v8, v18

    const/16 v9, 0xd

    aput-byte v18, v8, v9

    const/16 v19, 0x47

    const/16 v20, 0xe

    aput-byte v19, v8, v20

    const/16 v19, -0x5f

    const/16 v21, 0xf

    aput-byte v19, v8, v21

    aput-byte v14, v8, v1

    const/16 v1, -0x59

    const/16 v19, 0x11

    aput-byte v1, v8, v19

    const/16 v1, 0x12

    const/16 v19, -0x78

    aput-byte v19, v8, v1

    const/16 v1, 0x13

    const/16 v19, -0x31

    aput-byte v19, v8, v1

    const/16 v1, -0x1c

    const/16 v19, 0x14

    aput-byte v1, v8, v19

    const/16 v1, 0x15

    const/16 v22, 0x53

    aput-byte v22, v8, v1

    const/16 v1, 0x16

    const/16 v22, 0x5b

    aput-byte v22, v8, v1

    const/16 v1, 0x17

    const/16 v22, -0x4d

    aput-byte v22, v8, v1

    const/16 v1, 0x18

    const/16 v22, 0x4d

    aput-byte v22, v8, v1

    const/16 v1, -0x58

    const/16 v22, 0x19

    aput-byte v1, v8, v22

    const/16 v1, 0x1a

    const/16 v23, -0x2a

    aput-byte v23, v8, v1

    const/16 v1, 0x1b

    const/16 v23, -0x3b

    aput-byte v23, v8, v1

    const/16 v1, 0x1c

    const/16 v23, -0x5c

    aput-byte v23, v8, v1

    const/16 v1, 0x58

    const/16 v23, 0x1d

    aput-byte v1, v8, v23

    const/16 v1, 0x1e

    aput-byte v23, v8, v1

    const/16 v1, 0x1f

    const/16 v24, -0x43

    aput-byte v24, v8, v1

    const/16 v1, 0x20

    aput-byte v15, v8, v1

    const/16 v1, 0x21

    const/16 v24, -0x1a

    aput-byte v24, v8, v1

    const/16 v1, 0x22

    const/16 v24, -0x36

    aput-byte v24, v8, v1

    const/16 v1, 0x23

    const/16 v24, -0x3b

    aput-byte v24, v8, v1

    const/16 v1, 0x24

    const/16 v24, -0x8

    aput-byte v24, v8, v1

    const/16 v1, 0x25

    const/16 v24, 0x4a

    aput-byte v24, v8, v1

    const/16 v1, 0x26

    const/16 v24, 0x5b

    aput-byte v24, v8, v1

    const/16 v1, 0x27

    const/16 v24, -0x41

    aput-byte v24, v8, v1

    const/16 v1, 0x28

    aput-byte v15, v8, v1

    const/16 v1, 0x29

    const/16 v24, -0x42

    aput-byte v24, v8, v1

    const/16 v1, 0x2a

    const/16 v24, -0x67

    aput-byte v24, v8, v1

    const/16 v1, 0x2b

    const/16 v24, -0x38

    aput-byte v24, v8, v1

    const/16 v1, 0x2c

    const/16 v24, -0x7

    aput-byte v24, v8, v1

    const/16 v1, 0x2d

    const/16 v24, 0x57

    aput-byte v24, v8, v1

    const/16 v1, 0x2e

    aput-byte v13, v8, v1

    const/16 v1, 0x2f

    const/16 v24, -0x4c

    aput-byte v24, v8, v1

    const/16 v1, 0x30

    const/16 v24, 0x2b

    aput-byte v24, v8, v1

    const/16 v1, 0x31

    const/16 v24, -0x53

    aput-byte v24, v8, v1

    const/16 v1, 0x32

    const/16 v24, -0x65

    aput-byte v24, v8, v1

    const/16 v1, 0x33

    const/16 v24, -0x64

    aput-byte v24, v8, v1

    const/16 v1, 0x34

    const/16 v24, -0x53

    aput-byte v24, v8, v1

    const/16 v1, 0x35

    const/16 v24, 0x52

    aput-byte v24, v8, v1

    const/16 v1, 0x36

    aput-byte v23, v8, v1

    const/16 v1, 0x37

    const/16 v24, -0x44

    aput-byte v24, v8, v1

    const/16 v1, 0x38

    aput-byte v11, v8, v1

    const/16 v1, -0x43

    const/16 v24, 0x39

    aput-byte v1, v8, v24

    const/16 v1, 0x3a

    const/16 v25, -0x65

    aput-byte v25, v8, v1

    new-array v1, v2, [B

    const/16 v25, 0x62

    aput-byte v25, v1, v10

    const/16 v25, -0x37

    aput-byte v25, v1, v12

    const/16 v25, -0x5a

    aput-byte v25, v1, v13

    const/16 v25, -0x54

    aput-byte v25, v1, v14

    const/16 v25, -0x75

    const/16 v17, 0x4

    aput-byte v25, v1, v17

    const/16 v25, 0x3e

    const/16 v26, 0x5

    aput-byte v25, v1, v26

    const/16 v25, 0x74

    aput-byte v25, v1, v16

    const/16 v25, -0x2f

    aput-byte v25, v1, v15

    invoke-static {v8, v1}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v7, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v1, 0x64

    invoke-virtual {v7, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/16 v1, 0x3d

    new-array v1, v1, [B

    const/16 v8, 0x27

    aput-byte v8, v1, v10

    const/16 v8, 0x53

    aput-byte v8, v1, v12

    const/16 v8, 0x35

    aput-byte v8, v1, v13

    const/16 v8, 0x25

    aput-byte v8, v1, v14

    const/16 v8, -0x4e

    const/16 v17, 0x4

    aput-byte v8, v1, v17

    const/16 v8, -0x56

    const/16 v25, 0x5

    aput-byte v8, v1, v25

    const/16 v8, 0x77

    aput-byte v8, v1, v16

    const/16 v8, -0x69

    aput-byte v8, v1, v15

    const/16 v8, 0x6e

    aput-byte v8, v1, v2

    const/16 v8, 0x4f

    const/16 v25, 0x9

    aput-byte v8, v1, v25

    const/16 v8, 0x34

    const/16 v25, 0xa

    aput-byte v8, v1, v25

    const/16 v8, 0x38

    aput-byte v8, v1, v11

    const/16 v8, -0x4c

    aput-byte v8, v1, v18

    const/16 v8, -0x2b

    aput-byte v8, v1, v9

    const/16 v8, 0x3e

    aput-byte v8, v1, v20

    const/16 v8, -0x74

    aput-byte v8, v1, v21

    const/16 v8, 0x74

    const/16 v25, 0x10

    aput-byte v8, v1, v25

    const/16 v8, 0x4d

    const/16 v25, 0x11

    aput-byte v8, v1, v25

    const/16 v8, 0x12

    const/16 v25, 0x34

    aput-byte v25, v1, v8

    const/16 v8, 0x13

    const/16 v25, 0x3c

    aput-byte v25, v1, v8

    const/16 v8, -0x4e

    aput-byte v8, v1, v19

    const/16 v8, 0x15

    const/16 v25, -0xe

    aput-byte v25, v1, v8

    const/16 v8, 0x16

    const/16 v25, 0x18

    aput-byte v25, v1, v8

    const/16 v8, 0x17

    const/16 v25, -0x3b

    aput-byte v25, v1, v8

    const/16 v8, 0x18

    const/16 v25, 0x68

    aput-byte v25, v1, v8

    const/16 v8, 0x50

    aput-byte v8, v1, v22

    const/16 v8, 0x1a

    const/16 v25, 0x35

    aput-byte v25, v1, v8

    const/16 v8, 0x1b

    const/16 v25, 0x7b

    aput-byte v25, v1, v8

    const/16 v8, 0x1c

    const/16 v25, -0x57

    aput-byte v25, v1, v8

    const/16 v8, -0x1b

    aput-byte v8, v1, v23

    const/16 v8, 0x1e

    const/16 v25, 0x23

    aput-byte v25, v1, v8

    const/16 v8, 0x1f

    const/16 v25, -0x2c

    aput-byte v25, v1, v8

    const/16 v8, 0x20

    const/16 v25, 0x73

    aput-byte v25, v1, v8

    const/16 v8, 0x21

    const/16 v25, 0x79

    aput-byte v25, v1, v8

    const/16 v8, 0x22

    aput-byte v24, v1, v8

    const/16 v8, 0x23

    const/16 v25, 0x2f

    aput-byte v25, v1, v8

    const/16 v8, 0x24

    const/16 v25, -0x5d

    aput-byte v25, v1, v8

    const/16 v8, 0x25

    const/16 v25, -0xc

    aput-byte v25, v1, v8

    const/16 v8, 0x26

    const/16 v25, 0x33

    aput-byte v25, v1, v8

    const/16 v8, 0x27

    const/16 v25, -0x28

    aput-byte v25, v1, v8

    const/16 v8, 0x28

    const/16 v25, 0x6e

    aput-byte v25, v1, v8

    const/16 v8, 0x29

    const/16 v25, 0x53

    aput-byte v25, v1, v8

    const/16 v8, 0x2a

    const/16 v25, 0x6d

    aput-byte v25, v1, v8

    const/16 v8, 0x2b

    aput-byte v24, v1, v8

    const/16 v8, 0x2c

    const/16 v25, -0x5d

    aput-byte v25, v1, v8

    const/16 v8, 0x2d

    const/16 v25, -0x1c

    aput-byte v25, v1, v8

    const/16 v8, 0x2e

    const/16 v25, 0x24

    aput-byte v25, v1, v8

    const/16 v8, 0x2f

    const/16 v25, -0x69

    aput-byte v25, v1, v8

    const/16 v8, 0x30

    const/16 v25, 0x71

    aput-byte v25, v1, v8

    const/16 v8, 0x31

    const/16 v25, 0x5c

    aput-byte v25, v1, v8

    const/16 v8, 0x32

    const/16 v25, 0x22

    aput-byte v25, v1, v8

    const/16 v8, 0x33

    const/16 v25, 0x38

    aput-byte v25, v1, v8

    const/16 v8, 0x34

    const/16 v25, -0x58

    aput-byte v25, v1, v8

    const/16 v8, 0x35

    const/16 v25, -0x1d

    aput-byte v25, v1, v8

    const/16 v8, 0x36

    aput-byte v12, v1, v8

    const/16 v8, 0x37

    const/16 v25, -0x28

    aput-byte v25, v1, v8

    const/16 v8, 0x38

    const/16 v25, 0x6d

    aput-byte v25, v1, v8

    const/16 v8, 0x58

    aput-byte v8, v1, v24

    const/16 v8, 0x3a

    aput-byte v22, v1, v8

    const/16 v8, 0x3b

    aput-byte v24, v1, v8

    const/16 v8, 0x3c

    const/16 v25, -0x5

    aput-byte v25, v1, v8

    new-array v8, v2, [B

    aput-byte v12, v8, v10

    const/16 v25, 0x3d

    aput-byte v25, v8, v12

    const/16 v25, 0x50

    aput-byte v25, v8, v13

    const/16 v25, 0x5d

    aput-byte v25, v8, v14

    const/16 v25, -0x3a

    const/16 v17, 0x4

    aput-byte v25, v8, v17

    const/16 v25, -0x69

    const/16 v26, 0x5

    aput-byte v25, v8, v26

    const/16 v25, 0x47

    aput-byte v25, v8, v16

    const/16 v25, -0x4f

    aput-byte v25, v8, v15

    invoke-static {v1, v8}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v7, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move/from16 v1, p1

    invoke-virtual {v7, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/16 v8, 0x20

    new-array v8, v8, [B

    const/16 v25, 0x1e

    aput-byte v25, v8, v10

    const/16 v25, 0x47

    aput-byte v25, v8, v12

    const/16 v25, -0x7d

    aput-byte v25, v8, v13

    aput-byte v19, v8, v14

    const/16 v25, -0x44

    const/16 v17, 0x4

    aput-byte v25, v8, v17

    const/16 v25, -0x6c

    const/16 v26, 0x5

    aput-byte v25, v8, v26

    const/16 v25, -0x68

    aput-byte v25, v8, v16

    const/16 v25, -0x3d

    aput-byte v25, v8, v15

    aput-byte v26, v8, v2

    const/16 v25, 0x55

    const/16 v26, 0x9

    aput-byte v25, v8, v26

    const/16 v25, -0x70

    const/16 v26, 0xa

    aput-byte v25, v8, v26

    aput-byte v22, v8, v11

    const/16 v25, -0x44

    aput-byte v25, v8, v18

    const/16 v18, -0x67

    aput-byte v18, v8, v9

    const/16 v18, -0x25

    aput-byte v18, v8, v20

    const/16 v18, -0xc

    aput-byte v18, v8, v21

    const/16 v18, 0x5d

    const/16 v25, 0x10

    aput-byte v18, v8, v25

    const/16 v18, 0x52

    const/16 v25, 0x11

    aput-byte v18, v8, v25

    const/16 v18, 0x12

    const/16 v25, -0x7d

    aput-byte v25, v8, v18

    const/16 v18, 0x13

    const/16 v25, 0x16

    aput-byte v25, v8, v18

    const/16 v18, -0x59

    aput-byte v18, v8, v19

    const/16 v18, 0x15

    const/16 v25, -0x48

    aput-byte v25, v8, v18

    const/16 v18, 0x16

    const/16 v25, -0x64

    aput-byte v25, v8, v18

    const/16 v18, 0x17

    const/16 v25, -0x2d

    aput-byte v25, v8, v18

    const/16 v18, 0x18

    const/16 v25, 0x59

    aput-byte v25, v8, v18

    aput-byte v20, v8, v22

    const/16 v18, 0x1a

    const/16 v25, -0x29

    aput-byte v25, v8, v18

    const/16 v18, 0x1b

    const/16 v25, 0x25

    aput-byte v25, v8, v18

    const/16 v18, 0x1c

    const/16 v25, -0x52

    aput-byte v25, v8, v18

    const/16 v18, -0x65

    aput-byte v18, v8, v23

    const/16 v18, 0x1e

    const/16 v25, -0x68

    aput-byte v25, v8, v18

    const/16 v18, 0x1f

    const/16 v25, -0x66

    aput-byte v25, v8, v18

    new-array v9, v2, [B

    const/16 v25, 0x38

    aput-byte v25, v9, v10

    const/16 v25, 0x33

    aput-byte v25, v9, v12

    const/16 v25, -0xf

    aput-byte v25, v9, v13

    const/16 v25, 0x75

    aput-byte v25, v9, v14

    const/16 v25, -0x31

    const/16 v17, 0x4

    aput-byte v25, v9, v17

    const/16 v25, -0x4

    const/16 v26, 0x5

    aput-byte v25, v9, v26

    const/16 v25, -0x3

    aput-byte v25, v9, v16

    const/16 v25, -0x59

    aput-byte v25, v9, v15

    invoke-static {v8, v9}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v7, v12}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/16 v8, 0x35

    new-array v8, v8, [B

    const/16 v9, -0x3e

    aput-byte v9, v8, v10

    const/16 v9, -0xd

    aput-byte v9, v8, v12

    const/16 v9, 0x52

    aput-byte v9, v8, v13

    const/16 v9, 0x10

    aput-byte v9, v8, v14

    const/16 v9, -0x35

    const/16 v17, 0x4

    aput-byte v9, v8, v17

    const/4 v9, 0x5

    aput-byte v19, v8, v9

    const/16 v9, -0x1e

    aput-byte v9, v8, v16

    const/16 v9, -0x7c

    aput-byte v9, v8, v15

    const/16 v9, -0x75

    aput-byte v9, v8, v2

    const/4 v9, -0x5

    const/16 v25, 0x9

    aput-byte v9, v8, v25

    const/16 v9, 0x41

    const/16 v25, 0xa

    aput-byte v9, v8, v25

    aput-byte v24, v8, v11

    const/16 v9, -0x34

    const/16 v25, 0xc

    aput-byte v9, v8, v25

    const/16 v9, 0x13

    const/16 v18, 0xd

    aput-byte v9, v8, v18

    const/16 v9, -0x55

    aput-byte v9, v8, v20

    const/16 v9, -0x56

    aput-byte v9, v8, v21

    const/16 v9, -0x73

    const/16 v25, 0x10

    aput-byte v9, v8, v25

    const/4 v9, -0x6

    const/16 v25, 0x11

    aput-byte v9, v8, v25

    const/16 v9, 0x12

    const/16 v25, 0x41

    aput-byte v25, v8, v9

    const/16 v9, 0x13

    const/16 v25, 0x53

    aput-byte v25, v8, v9

    const/16 v9, -0x36

    aput-byte v9, v8, v19

    const/16 v9, 0x15

    const/16 v25, 0x10

    aput-byte v25, v8, v9

    const/16 v9, 0x16

    const/16 v25, -0x46

    aput-byte v25, v8, v9

    const/16 v9, 0x17

    const/16 v25, -0x62

    aput-byte v25, v8, v9

    const/16 v9, 0x18

    const/16 v25, -0x7b

    aput-byte v25, v8, v9

    const/16 v9, -0x1e

    aput-byte v9, v8, v22

    const/16 v9, 0x1a

    const/16 v25, 0x41

    aput-byte v25, v8, v9

    const/16 v9, 0x1b

    const/16 v25, 0x21

    aput-byte v25, v8, v9

    const/16 v9, 0x1c

    const/16 v25, -0x24

    aput-byte v25, v8, v9

    const/16 v9, 0x10

    aput-byte v9, v8, v23

    const/16 v9, 0x1e

    const/16 v25, -0x46

    aput-byte v25, v8, v9

    const/16 v9, 0x1f

    const/16 v25, -0x2f

    aput-byte v25, v8, v9

    const/16 v9, 0x20

    const/16 v25, -0x2b

    aput-byte v25, v8, v9

    const/16 v9, 0x21

    const/16 v25, -0x50

    aput-byte v25, v8, v9

    const/16 v9, 0x22

    const/16 v25, 0x4d

    aput-byte v25, v8, v9

    const/16 v9, 0x23

    const/16 v25, 0x1b

    aput-byte v25, v8, v9

    const/16 v9, 0x24

    const/16 v25, -0x1f

    aput-byte v25, v8, v9

    const/16 v9, 0x25

    const/16 v25, 0x9

    aput-byte v25, v8, v9

    const/16 v9, 0x26

    const/16 v25, -0x53

    aput-byte v25, v8, v9

    const/16 v9, 0x27

    const/16 v25, -0x77

    aput-byte v25, v8, v9

    const/16 v9, 0x28

    const/16 v25, -0x79

    aput-byte v25, v8, v9

    const/16 v9, 0x29

    const/16 v25, -0x1e

    aput-byte v25, v8, v9

    const/16 v9, 0x2a

    const/16 v25, 0x77

    aput-byte v25, v8, v9

    const/16 v9, 0x2b

    const/16 v25, 0x5

    aput-byte v25, v8, v9

    const/16 v9, 0x2c

    const/16 v25, -0x3c

    aput-byte v25, v8, v9

    const/16 v9, 0x2d

    aput-byte v14, v8, v9

    const/16 v9, 0x2e

    const/16 v25, -0x46

    aput-byte v25, v8, v9

    const/16 v9, 0x2f

    const/16 v25, -0x2f

    aput-byte v25, v8, v9

    const/16 v9, 0x30

    const/16 v25, -0x7e

    aput-byte v25, v8, v9

    const/16 v9, 0x31

    const/16 v25, -0x9

    aput-byte v25, v8, v9

    const/16 v9, 0x32

    const/16 v25, 0x48

    aput-byte v25, v8, v9

    const/16 v9, 0x33

    aput-byte v16, v8, v9

    const/16 v9, 0x34

    const/16 v25, -0x40

    aput-byte v25, v8, v9

    new-array v9, v2, [B

    const/16 v25, -0x1c

    aput-byte v25, v9, v10

    const/16 v25, -0x6a

    aput-byte v25, v9, v12

    const/16 v25, 0x24

    aput-byte v25, v9, v13

    const/16 v25, 0x75

    aput-byte v25, v9, v14

    const/16 v25, -0x5b

    const/16 v17, 0x4

    aput-byte v25, v9, v17

    const/16 v25, 0x60

    const/16 v26, 0x5

    aput-byte v25, v9, v26

    const/16 v25, -0x21

    aput-byte v25, v9, v16

    const/16 v25, -0x14

    aput-byte v25, v9, v15

    invoke-static {v8, v9}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v7

    invoke-direct/range {p0 .. p0}, Lcom/github/catvod/spider/appysv2/b/F;->l()Ljava/util/Map;

    move-result-object v8

    invoke-static {v7, v8}, Lcom/github/catvod/spider/appysv2/n/c;->m(Ljava/lang/String;Ljava/util/Map;)Ljava/lang/String;

    move-result-object v7

    invoke-static {v7}, Lcom/github/catvod/spider/appysv2/j/c;->b(Ljava/lang/String;)Lcom/github/catvod/spider/appysv2/j/c;

    move-result-object v7

    invoke-virtual {v7}, Lcom/github/catvod/spider/appysv2/j/c;->a()Lcom/github/catvod/spider/appysv2/j/a;

    move-result-object v8

    invoke-virtual {v8}, Lcom/github/catvod/spider/appysv2/j/a;->a()Ljava/util/List;

    move-result-object v8

    invoke-interface {v8}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v8

    :cond_53a
    :goto_53a
    invoke-interface {v8}, Ljava/util/Iterator;->hasNext()Z

    move-result v9

    if-eqz v9, :cond_55e

    invoke-interface {v8}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v9

    check-cast v9, Lcom/github/catvod/spider/appysv2/j/b;

    invoke-virtual {v9}, Lcom/github/catvod/spider/appysv2/j/b;->b()Ljava/lang/String;

    move-result-object v25

    invoke-static/range {v25 .. v25}, Lcom/github/catvod/spider/appysv2/b/F;->g(Ljava/lang/String;)J

    move-result-wide v25

    cmp-long v27, v25, v3

    if-gez v27, :cond_53a

    invoke-virtual {v6, v9}, Lcom/google/gson/Gson;->toJsonTree(Ljava/lang/Object;)Lcom/google/gson/JsonElement;

    move-result-object v9

    invoke-virtual {v9}, Lcom/google/gson/JsonElement;->getAsJsonObject()Lcom/google/gson/JsonObject;

    move-result-object v9

    invoke-virtual {v5, v9}, Lcom/google/gson/JsonArray;->add(Lcom/google/gson/JsonElement;)V

    goto :goto_53a

    :cond_55e
    invoke-virtual {v7}, Lcom/github/catvod/spider/appysv2/j/c;->a()Lcom/github/catvod/spider/appysv2/j/a;

    move-result-object v7

    invoke-virtual {v7}, Lcom/github/catvod/spider/appysv2/j/a;->b()I

    move-result v7

    const/16 v8, 0x64

    if-ge v7, v8, :cond_910

    invoke-virtual {v5}, Lcom/google/gson/JsonArray;->size()I

    move-result v1

    if-nez v1, :cond_571

    return-void

    :cond_571
    new-instance v1, Lcom/google/gson/JsonObject;

    invoke-direct {v1}, Lcom/google/gson/JsonObject;-><init>()V

    new-array v3, v15, [B

    const/4 v4, -0x1

    aput-byte v4, v3, v10

    const/16 v4, -0x79

    aput-byte v4, v3, v12

    const/16 v4, 0x6d

    aput-byte v4, v3, v13

    const/16 v4, -0x54

    aput-byte v4, v3, v14

    const/16 v4, 0x6e

    const/4 v6, 0x4

    aput-byte v4, v3, v6

    const/16 v4, -0xd

    const/4 v6, 0x5

    aput-byte v4, v3, v6

    const/16 v4, -0x19

    aput-byte v4, v3, v16

    new-array v4, v2, [B

    const/16 v6, -0x65

    aput-byte v6, v4, v10

    const/16 v6, -0xb

    aput-byte v6, v4, v12

    const/4 v6, 0x4

    aput-byte v6, v4, v13

    const/16 v7, -0x26

    aput-byte v7, v4, v14

    aput-byte v11, v4, v6

    const/16 v6, -0x46

    const/4 v7, 0x5

    aput-byte v6, v4, v7

    const/16 v6, -0x7d

    aput-byte v6, v4, v16

    aput-byte v23, v4, v15

    invoke-static {v3, v4}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v3

    invoke-static {v10}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    invoke-virtual {v1, v3, v4}, Lcom/google/gson/JsonObject;->addProperty(Ljava/lang/String;Ljava/lang/Number;)V

    const/16 v3, 0x9

    new-array v3, v3, [B

    const/4 v4, -0x7

    aput-byte v4, v3, v10

    const/16 v4, 0x69

    aput-byte v4, v3, v12

    const/16 v4, -0x77

    aput-byte v4, v3, v13

    const/16 v4, -0x41

    aput-byte v4, v3, v14

    const/16 v4, 0x75

    const/4 v6, 0x4

    aput-byte v4, v3, v6

    const/16 v4, -0x19

    const/4 v6, 0x5

    aput-byte v4, v3, v6

    aput-byte v24, v3, v16

    aput-byte v2, v3, v15

    const/4 v4, -0x8

    aput-byte v4, v3, v2

    new-array v4, v2, [B

    const/16 v6, -0x6a

    aput-byte v6, v4, v10

    aput-byte v22, v4, v12

    const/16 v6, -0x14

    aput-byte v6, v4, v13

    const/16 v6, -0x33

    aput-byte v6, v4, v14

    const/4 v6, 0x4

    aput-byte v19, v4, v6

    const/16 v6, -0x6d

    const/4 v7, 0x5

    aput-byte v6, v4, v7

    const/16 v6, 0x50

    aput-byte v6, v4, v16

    const/16 v6, 0x67

    aput-byte v6, v4, v15

    invoke-static {v3, v4}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v3

    sget-object v4, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    invoke-virtual {v1, v3, v4}, Lcom/google/gson/JsonObject;->addProperty(Ljava/lang/String;Ljava/lang/Boolean;)V

    const/4 v3, 0x5

    new-array v3, v3, [B

    const/16 v4, -0x6d

    aput-byte v4, v3, v10

    const/16 v4, 0x2d

    aput-byte v4, v3, v12

    const/16 v4, 0x27

    aput-byte v4, v3, v13

    const/16 v4, 0x3b

    aput-byte v4, v3, v14

    const/16 v4, -0x31

    const/4 v6, 0x4

    aput-byte v4, v3, v6

    new-array v4, v2, [B

    const/16 v6, -0xa

    aput-byte v6, v4, v10

    const/16 v6, 0x5b

    aput-byte v6, v4, v12

    const/16 v6, 0x42

    aput-byte v6, v4, v13

    const/16 v6, 0x55

    aput-byte v6, v4, v14

    const/16 v6, -0x45

    const/4 v7, 0x4

    aput-byte v6, v4, v7

    const/16 v6, -0x6f

    const/4 v7, 0x5

    aput-byte v6, v4, v7

    const/16 v6, 0x71

    aput-byte v6, v4, v16

    aput-byte v2, v4, v15

    invoke-static {v3, v4}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v3

    new-array v4, v11, [B

    const/16 v6, 0x1a

    aput-byte v6, v4, v10

    const/16 v6, -0x54

    aput-byte v6, v4, v12

    const/16 v6, 0x29

    aput-byte v6, v4, v13

    const/16 v6, -0x47

    aput-byte v6, v4, v14

    const/16 v6, -0x9

    const/4 v7, 0x4

    aput-byte v6, v4, v7

    const/16 v6, -0x3e

    const/4 v7, 0x5

    aput-byte v6, v4, v7

    const/16 v6, -0x5b

    aput-byte v6, v4, v16

    const/16 v6, 0x3c

    aput-byte v6, v4, v15

    const/16 v6, 0x10

    aput-byte v6, v4, v2

    const/16 v6, -0x52

    const/16 v7, 0x9

    aput-byte v6, v4, v7

    const/16 v6, 0x38

    const/16 v7, 0xa

    aput-byte v6, v4, v7

    new-array v6, v2, [B

    const/16 v7, 0x73

    aput-byte v7, v6, v10

    const/16 v7, -0x3e

    aput-byte v7, v6, v12

    const/16 v7, 0x5d

    aput-byte v7, v6, v13

    const/16 v7, -0x2a

    aput-byte v7, v6, v14

    const/16 v7, -0x5b

    const/4 v8, 0x4

    aput-byte v7, v6, v8

    const/16 v7, -0x59

    const/4 v8, 0x5

    aput-byte v7, v6, v8

    const/16 v7, -0x3a

    aput-byte v7, v6, v16

    const/16 v7, 0x45

    aput-byte v7, v6, v15

    invoke-static {v4, v6}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v1, v3, v4}, Lcom/google/gson/JsonObject;->addProperty(Ljava/lang/String;Ljava/lang/String;)V

    const/16 v3, 0xc

    new-array v3, v3, [B

    const/16 v4, 0x6f

    aput-byte v4, v3, v10

    const/16 v4, 0x37

    aput-byte v4, v3, v12

    const/16 v4, -0x65

    aput-byte v4, v3, v13

    aput-byte v21, v3, v14

    const/16 v4, 0x38

    const/4 v6, 0x4

    aput-byte v4, v3, v6

    const/16 v4, -0x4e

    const/4 v6, 0x5

    aput-byte v4, v3, v6

    const/16 v4, 0x5c

    aput-byte v4, v3, v16

    const/16 v4, 0x7a

    aput-byte v4, v3, v15

    const/16 v4, 0x6c

    aput-byte v4, v3, v2

    const/16 v4, 0x26

    const/16 v6, 0x9

    aput-byte v4, v3, v6

    const/16 v4, -0x63

    const/16 v6, 0xa

    aput-byte v4, v3, v6

    const/16 v4, 0x18

    aput-byte v4, v3, v11

    new-array v4, v2, [B

    aput-byte v10, v4, v10

    const/16 v6, 0x47

    aput-byte v6, v4, v12

    const/4 v6, -0x2

    aput-byte v6, v4, v13

    const/16 v6, 0x7d

    aput-byte v6, v4, v14

    const/16 v6, 0x59

    const/4 v7, 0x4

    aput-byte v6, v4, v7

    const/16 v6, -0x3a

    const/4 v7, 0x5

    aput-byte v6, v4, v7

    aput-byte v24, v4, v16

    const/16 v6, 0x2a

    aput-byte v6, v4, v15

    invoke-static {v3, v4}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v3

    invoke-static {v12}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    invoke-virtual {v1, v3, v4}, Lcom/google/gson/JsonObject;->addProperty(Ljava/lang/String;Ljava/lang/Number;)V

    const/16 v3, 0x11

    new-array v3, v3, [B

    const/16 v4, 0x62

    aput-byte v4, v3, v10

    const/16 v4, -0x47

    aput-byte v4, v3, v12

    aput-byte v16, v3, v13

    const/4 v4, -0x6

    aput-byte v4, v3, v14

    const/16 v4, 0x65

    const/4 v6, 0x4

    aput-byte v4, v3, v6

    const/16 v4, -0x35

    const/4 v6, 0x5

    aput-byte v4, v3, v6

    const/16 v4, -0x5a

    aput-byte v4, v3, v16

    const/16 v4, -0x19

    aput-byte v4, v3, v15

    const/16 v4, 0x6c

    aput-byte v4, v3, v2

    const/16 v4, -0x67

    const/16 v6, 0x9

    aput-byte v4, v3, v6

    const/16 v4, 0xa

    const/4 v6, 0x4

    aput-byte v6, v3, v4

    const/4 v4, -0x7

    aput-byte v4, v3, v11

    const/16 v4, 0x5e

    const/16 v6, 0xc

    aput-byte v4, v3, v6

    const/16 v4, -0xb

    const/16 v6, 0xd

    aput-byte v4, v3, v6

    const/16 v4, -0x52

    aput-byte v4, v3, v20

    const/16 v4, -0x19

    aput-byte v4, v3, v21

    const/16 v4, 0x70

    const/16 v6, 0x10

    aput-byte v4, v3, v6

    new-array v4, v2, [B

    const/4 v6, 0x4

    aput-byte v6, v4, v10

    const/16 v6, -0x30

    aput-byte v6, v4, v12

    const/16 v6, 0x6a

    aput-byte v6, v4, v13

    const/16 v6, -0x61

    aput-byte v6, v4, v14

    const/16 v6, 0x31

    const/4 v7, 0x4

    aput-byte v6, v4, v7

    const/16 v6, -0x47

    const/4 v7, 0x5

    aput-byte v6, v4, v7

    const/16 v6, -0x39

    aput-byte v6, v4, v16

    const/16 v6, -0x6c

    aput-byte v6, v4, v15

    invoke-static {v3, v4}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v1, v3, v5}, Lcom/google/gson/JsonObject;->add(Ljava/lang/String;Lcom/google/gson/JsonElement;)V

    const/16 v3, 0x27

    new-array v3, v3, [B

    const/16 v4, -0x7b

    aput-byte v4, v3, v10

    const/16 v4, -0x3b

    aput-byte v4, v3, v12

    const/16 v4, -0x26

    aput-byte v4, v3, v13

    const/16 v4, -0x7b

    aput-byte v4, v3, v14

    const/4 v4, -0x3

    const/4 v5, 0x4

    aput-byte v4, v3, v5

    const/16 v4, -0x39

    const/4 v5, 0x5

    aput-byte v4, v3, v5

    const/16 v4, 0x44

    aput-byte v4, v3, v16

    const/16 v4, -0x80

    aput-byte v4, v3, v15

    const/16 v4, -0x66

    aput-byte v4, v3, v2

    const/16 v4, -0x3a

    const/16 v5, 0x9

    aput-byte v4, v3, v5

    const/16 v4, -0x27

    const/16 v5, 0xa

    aput-byte v4, v3, v5

    const/16 v4, -0x25

    aput-byte v4, v3, v11

    const/16 v4, -0x41

    const/16 v5, 0xc

    aput-byte v4, v3, v5

    const/16 v4, -0x31

    const/16 v5, 0xd

    aput-byte v4, v3, v5

    const/16 v4, 0x58

    aput-byte v4, v3, v20

    const/16 v4, -0x21

    aput-byte v4, v3, v21

    const/16 v4, -0x74

    const/16 v5, 0x10

    aput-byte v4, v3, v5

    const/16 v4, -0x21

    const/16 v5, 0x11

    aput-byte v4, v3, v5

    const/16 v4, 0x12

    const/16 v5, -0x80

    aput-byte v5, v3, v4

    const/16 v4, 0x13

    const/16 v5, -0x6a

    aput-byte v5, v3, v4

    const/16 v4, -0x1f

    aput-byte v4, v3, v19

    const/16 v4, 0x15

    const/16 v5, -0x70

    aput-byte v5, v3, v4

    const/16 v4, 0x16

    const/16 v5, 0x44

    aput-byte v5, v3, v4

    const/16 v4, 0x17

    const/16 v5, -0x33

    aput-byte v5, v3, v4

    const/16 v4, 0x18

    const/16 v5, -0x3e

    aput-byte v5, v3, v4

    const/16 v4, -0x30

    aput-byte v4, v3, v22

    const/16 v4, 0x1a

    const/16 v5, -0x22

    aput-byte v5, v3, v4

    const/16 v4, 0x1b

    const/16 v5, -0x64

    aput-byte v5, v3, v4

    const/16 v4, 0x1c

    const/16 v5, -0x5f

    aput-byte v5, v3, v4

    const/16 v4, -0x65

    aput-byte v4, v3, v23

    const/16 v4, 0x1e

    aput-byte v13, v3, v4

    const/16 v4, 0x1f

    const/16 v5, -0x3d

    aput-byte v5, v3, v4

    const/16 v4, 0x20

    const/16 v5, -0x78

    aput-byte v5, v3, v4

    const/16 v4, 0x21

    const/16 v5, -0x62

    aput-byte v5, v3, v4

    const/16 v4, 0x22

    const/16 v5, -0x26

    aput-byte v5, v3, v4

    const/16 v4, 0x23

    const/16 v5, -0x79

    aput-byte v5, v3, v4

    const/16 v4, 0x24

    const/16 v5, -0x11

    aput-byte v5, v3, v4

    const/16 v4, 0x25

    const/16 v5, -0x72

    aput-byte v5, v3, v4

    const/16 v4, 0x26

    aput-byte v14, v3, v4

    new-array v4, v2, [B

    const/16 v5, -0x13

    aput-byte v5, v4, v10

    const/16 v5, -0x4f

    aput-byte v5, v4, v12

    const/16 v5, -0x52

    aput-byte v5, v4, v13

    const/16 v5, -0xb

    aput-byte v5, v4, v14

    const/16 v5, -0x72

    const/4 v6, 0x4

    aput-byte v5, v4, v6

    const/4 v5, -0x3

    const/4 v6, 0x5

    aput-byte v5, v4, v6

    const/16 v5, 0x6b

    aput-byte v5, v4, v16

    const/16 v5, -0x51

    aput-byte v5, v4, v15

    invoke-static {v3, v4}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v1}, Lcom/google/gson/JsonElement;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct/range {p0 .. p0}, Lcom/github/catvod/spider/appysv2/b/F;->l()Ljava/util/Map;

    move-result-object v4

    invoke-static {v3, v1, v4}, Lcom/github/catvod/spider/appysv2/n/c;->g(Ljava/lang/String;Ljava/lang/String;Ljava/util/Map;)Lcom/github/catvod/spider/appysv2/n/e;

    move-result-object v1

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const/16 v4, 0x11

    new-array v4, v4, [B

    const/16 v5, 0x42

    aput-byte v5, v4, v10

    const/16 v5, 0x66

    aput-byte v5, v4, v12

    const/16 v5, -0x73

    aput-byte v5, v4, v13

    const/16 v5, 0x60

    aput-byte v5, v4, v14

    const/16 v5, -0x7a

    const/4 v6, 0x4

    aput-byte v5, v4, v6

    const/16 v5, -0x48

    const/4 v6, 0x5

    aput-byte v5, v4, v6

    const/16 v5, -0x22

    aput-byte v5, v4, v16

    const/16 v5, 0x7d

    aput-byte v5, v4, v15

    const/16 v5, 0x43

    aput-byte v5, v4, v2

    const/16 v5, 0x6e

    const/16 v6, 0x9

    aput-byte v5, v4, v6

    const/16 v5, -0x6e

    const/16 v6, 0xa

    aput-byte v5, v4, v6

    const/16 v5, 0x25

    aput-byte v5, v4, v11

    const/16 v5, -0x80

    const/16 v6, 0xc

    aput-byte v5, v4, v6

    const/16 v5, -0x48

    const/16 v6, 0xd

    aput-byte v5, v4, v6

    const/16 v5, -0x1c

    aput-byte v5, v4, v20

    const/16 v5, 0x33

    aput-byte v5, v4, v21

    const/16 v5, 0x10

    aput-byte v16, v4, v5

    new-array v5, v2, [B

    const/16 v6, 0x26

    aput-byte v6, v5, v10

    aput-byte v14, v5, v12

    const/16 v6, -0x1f

    aput-byte v6, v5, v13

    const/4 v6, 0x5

    aput-byte v6, v5, v14

    const/16 v7, -0xe

    const/4 v8, 0x4

    aput-byte v7, v5, v8

    const/16 v7, -0x23

    aput-byte v7, v5, v6

    const/16 v6, -0x69

    aput-byte v6, v5, v16

    const/16 v6, 0x9

    aput-byte v6, v5, v15

    invoke-static {v4, v5}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Lcom/github/catvod/crawler/SpiderDebug;->log(Ljava/lang/String;)V
    :try_end_90f
    .catch Ljava/lang/Exception; {:try_start_4 .. :try_end_90f} :catch_916

    goto :goto_92c

    :cond_910
    const/16 v7, 0x10

    const/16 v1, 0x10

    goto/16 :goto_12

    :catch_916
    move-exception v0

    move-object v1, v0

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const/16 v4, 0x10

    new-array v4, v4, [B

    fill-array-data v4, :array_92e

    new-array v2, v2, [B

    fill-array-data v2, :array_93a

    .line 1
    invoke-static {v4, v2, v3, v1}, Lcom/github/catvod/spider/appysv2/b/y;->b([B[BLjava/lang/StringBuilder;Ljava/lang/Exception;)V

    :goto_92c
    return-void

    nop

    :array_92e
    .array-data 1
        0x4bt
        -0x7ft
        -0x54t
        -0x79t
        0x52t
        -0x55t
        -0x76t
        0x17t
        0x4at
        -0x77t
        -0x4ct
        -0x3et
        0x43t
        -0x44t
        -0x4ft
        0x59t
    .end array-data

    :array_93a
    .array-data 1
        0x2ft
        -0x1ct
        -0x39t
        -0x1et
        0x26t
        -0x32t
        -0x3dt
        0x63t
    .end array-data
.end method

.method private i()V
    .registers 2

    const/4 v0, 0x0

    :try_start_1
    iput-boolean v0, p0, Lcom/github/catvod/spider/appysv2/b/F;->c:Z

    iget-object v0, p0, Lcom/github/catvod/spider/appysv2/b/F;->b:Landroid/app/AlertDialog;

    if-eqz v0, :cond_a

    invoke-virtual {v0}, Landroid/app/Dialog;->dismiss()V
    :try_end_a
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_a} :catch_a

    :catch_a
    :cond_a
    return-void
.end method

.method public static j()Lcom/github/catvod/spider/appysv2/b/F;
    .registers 1

    sget-object v0, Lcom/github/catvod/spider/appysv2/b/E;->a:Lcom/github/catvod/spider/appysv2/b/F;

    return-object v0
.end method

.method private k(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    .registers 26

    const/4 v1, 0x0

    const/4 v0, 0x0

    :goto_2
    const/16 v4, -0x29

    const/16 v5, -0xd

    const/16 v6, -0x4f

    const/16 v7, 0xf

    const/16 v8, 0x8

    const/4 v9, 0x7

    const/4 v10, 0x6

    const/4 v11, 0x5

    const/4 v12, 0x3

    const/4 v13, 0x4

    const/4 v14, 0x1

    const/4 v15, 0x2

    if-ge v0, v15, :cond_6a1

    add-int/lit8 v2, v0, 0x1

    :try_start_17
    new-instance v0, Lcom/google/gson/JsonObject;

    invoke-direct {v0}, Lcom/google/gson/JsonObject;-><init>()V

    new-array v3, v10, [B

    aput-byte v6, v3, v1

    const/16 v6, -0xf

    aput-byte v6, v3, v14

    const/16 v6, -0x63

    aput-byte v6, v3, v15

    const/16 v6, -0x6a

    aput-byte v6, v3, v12

    const/16 v6, 0x7f

    aput-byte v6, v3, v13

    const/16 v6, -0x60

    aput-byte v6, v3, v11

    new-array v6, v8, [B

    aput-byte v4, v6, v1

    const/16 v4, -0x68

    aput-byte v4, v6, v14

    const/16 v4, -0xf

    aput-byte v4, v6, v15

    aput-byte v5, v6, v12

    const/16 v4, 0x36

    aput-byte v4, v6, v13

    const/16 v4, -0x3c

    aput-byte v4, v6, v11

    const/16 v4, -0x67

    aput-byte v4, v6, v10

    const/16 v4, -0x19

    aput-byte v4, v6, v9

    invoke-static {v3, v6}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v3
    :try_end_56
    .catch Ljava/lang/Exception; {:try_start_17 .. :try_end_56} :catch_65f

    move-object/from16 v4, p1

    :try_start_58
    invoke-virtual {v0, v3, v4}, Lcom/google/gson/JsonObject;->addProperty(Ljava/lang/String;Ljava/lang/String;)V

    new-array v3, v8, [B

    const/16 v6, 0x69

    aput-byte v6, v3, v1

    const/16 v6, 0x6c

    aput-byte v6, v3, v14

    const/16 v6, -0x2a

    aput-byte v6, v3, v15

    const/16 v6, -0x7f

    aput-byte v6, v3, v12

    const/16 v6, -0x48

    aput-byte v6, v3, v13

    const/16 v6, -0x5c

    aput-byte v6, v3, v11

    aput-byte v5, v3, v10

    const/16 v5, 0x71

    aput-byte v5, v3, v9

    new-array v5, v8, [B

    aput-byte v7, v5, v1

    aput-byte v11, v5, v14

    const/16 v6, -0x46

    aput-byte v6, v5, v15

    const/16 v6, -0x1c

    aput-byte v6, v5, v12

    const/16 v6, -0xa

    aput-byte v6, v5, v13

    const/16 v6, -0x3b

    aput-byte v6, v5, v11

    const/16 v6, -0x62

    aput-byte v6, v5, v10

    const/16 v6, 0x14

    aput-byte v6, v5, v9

    invoke-static {v3, v5}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v3
    :try_end_9d
    .catch Ljava/lang/Exception; {:try_start_58 .. :try_end_9d} :catch_659

    move-object/from16 v5, p2

    :try_start_9f
    invoke-virtual {v0, v3, v5}, Lcom/google/gson/JsonObject;->addProperty(Ljava/lang/String;Ljava/lang/String;)V

    new-array v3, v13, [B

    const/16 v6, -0x2c

    aput-byte v6, v3, v1

    const/16 v6, -0x3c

    aput-byte v6, v3, v14

    const/16 v6, -0x24

    aput-byte v6, v3, v15

    const/16 v6, -0x60

    aput-byte v6, v3, v12

    new-array v6, v8, [B

    const/16 v7, -0x4f

    aput-byte v7, v6, v1

    const/16 v7, -0x50

    aput-byte v7, v6, v14

    const/16 v7, -0x43

    aput-byte v7, v6, v15

    const/16 v7, -0x39

    aput-byte v7, v6, v12

    const/16 v7, -0x7c

    aput-byte v7, v6, v13

    const/16 v7, 0x7b

    aput-byte v7, v6, v11

    const/16 v7, 0x22

    aput-byte v7, v6, v10

    const/16 v7, 0x39

    aput-byte v7, v6, v9

    invoke-static {v3, v6}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v3
    :try_end_da
    .catch Ljava/lang/Exception; {:try_start_9f .. :try_end_da} :catch_653

    move-object/from16 v6, p3

    :try_start_dc
    invoke-virtual {v0, v3, v6}, Lcom/google/gson/JsonObject;->addProperty(Ljava/lang/String;Ljava/lang/String;)V

    const/16 v3, 0x9

    new-array v3, v3, [B

    const/16 v7, 0x4c

    aput-byte v7, v3, v1

    const/16 v7, -0xa

    aput-byte v7, v3, v14

    const/16 v7, -0x4b

    aput-byte v7, v3, v15

    const/16 v7, 0x74

    aput-byte v7, v3, v12

    const/16 v7, -0x69

    aput-byte v7, v3, v13

    const/16 v7, -0x2d

    aput-byte v7, v3, v11

    const/16 v7, 0x75

    aput-byte v7, v3, v10

    const/16 v7, 0x37

    aput-byte v7, v3, v9

    const/16 v7, 0x58

    aput-byte v7, v3, v8

    new-array v7, v8, [B

    const/16 v16, 0x3f

    aput-byte v16, v7, v1

    const/16 v16, -0x3b

    aput-byte v16, v7, v14

    const/16 v16, -0x22

    aput-byte v16, v7, v15

    const/16 v16, 0x11

    aput-byte v16, v7, v12

    const/16 v16, -0x12

    aput-byte v16, v7, v13

    const/16 v16, -0x6b

    aput-byte v16, v7, v11

    const/16 v16, 0x19

    aput-byte v16, v7, v10

    const/16 v16, 0x56

    aput-byte v16, v7, v9

    invoke-static {v3, v7}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v3
    :try_end_12d
    .catch Ljava/lang/Exception; {:try_start_dc .. :try_end_12d} :catch_64d

    move-object/from16 v7, p4

    :try_start_12f
    invoke-virtual {v0, v3, v7}, Lcom/google/gson/JsonObject;->addProperty(Ljava/lang/String;Ljava/lang/String;)V

    new-array v3, v13, [B

    aput-byte v11, v3, v1

    const/16 v16, 0x35

    aput-byte v16, v3, v14

    const/16 v16, 0x23

    aput-byte v16, v3, v15

    const/16 v16, -0x4

    aput-byte v16, v3, v12

    new-array v9, v8, [B

    const/16 v17, 0x76

    aput-byte v17, v9, v1

    const/16 v17, 0x5c

    aput-byte v17, v9, v14

    const/16 v17, 0x59

    aput-byte v17, v9, v15

    const/16 v17, -0x67

    aput-byte v17, v9, v12

    const/16 v17, -0x71

    aput-byte v17, v9, v13

    const/16 v17, 0x33

    aput-byte v17, v9, v11

    const/16 v17, 0x4e

    aput-byte v17, v9, v10

    const/16 v17, -0x3c

    const/4 v8, 0x7

    aput-byte v17, v9, v8

    invoke-static {v3, v9}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v3
    :try_end_169
    .catch Ljava/lang/Exception; {:try_start_12f .. :try_end_169} :catch_647

    move-object/from16 v9, p5

    :try_start_16b
    invoke-virtual {v0, v3, v9}, Lcom/google/gson/JsonObject;->addProperty(Ljava/lang/String;Ljava/lang/String;)V

    new-array v3, v8, [B

    const/16 v8, -0x43

    aput-byte v8, v3, v1

    const/16 v8, 0x4f

    aput-byte v8, v3, v14

    const/16 v8, 0x5e

    aput-byte v8, v3, v15

    const/4 v8, -0x4

    aput-byte v8, v3, v12

    const/16 v8, 0x42

    aput-byte v8, v3, v13

    const/16 v8, -0x5b

    aput-byte v8, v3, v11

    const/16 v8, 0x6c

    aput-byte v8, v3, v10

    const/16 v8, 0x8

    new-array v10, v8, [B

    const/16 v8, -0x27

    aput-byte v8, v10, v1

    const/16 v8, 0x3d

    aput-byte v8, v10, v14

    const/16 v8, 0x37

    aput-byte v8, v10, v15

    const/16 v8, -0x76

    aput-byte v8, v10, v12

    const/16 v8, 0x27

    aput-byte v8, v10, v13

    const/16 v8, -0x14

    aput-byte v8, v10, v11

    const/16 v8, 0x8

    const/16 v17, 0x6

    aput-byte v8, v10, v17

    const/16 v8, 0x4a

    const/16 v16, 0x7

    aput-byte v8, v10, v16

    invoke-static {v3, v10}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v3

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v8

    invoke-virtual {v0, v3, v8}, Lcom/google/gson/JsonObject;->addProperty(Ljava/lang/String;Ljava/lang/Number;)V

    const/16 v3, 0x2f

    new-array v3, v3, [B

    const/16 v8, 0x29

    aput-byte v8, v3, v1

    const/16 v8, 0x5b

    aput-byte v8, v3, v14

    const/16 v8, 0x48

    aput-byte v8, v3, v15

    const/16 v8, 0x69

    aput-byte v8, v3, v12

    const/16 v8, -0x13

    aput-byte v8, v3, v13

    const/16 v8, 0x52

    aput-byte v8, v3, v11

    const/16 v8, 0x66

    const/4 v10, 0x6

    aput-byte v8, v3, v10

    const/16 v8, -0x4c

    const/4 v10, 0x7

    aput-byte v8, v3, v10

    const/16 v8, 0x36

    const/16 v10, 0x8

    aput-byte v8, v3, v10

    const/16 v8, 0x58

    const/16 v10, 0x9

    aput-byte v8, v3, v10

    const/16 v8, 0x4b

    const/16 v10, 0xa

    aput-byte v8, v3, v10

    const/16 v8, 0xb

    const/16 v10, 0x37

    aput-byte v10, v3, v8

    const/16 v8, -0x51

    const/16 v10, 0xc

    aput-byte v8, v3, v10

    const/16 v8, 0x5a

    const/16 v10, 0xd

    aput-byte v8, v3, v10

    const/16 v8, 0x7a

    const/16 v10, 0xe

    aput-byte v8, v3, v10

    const/16 v8, -0x15

    const/16 v10, 0xf

    aput-byte v8, v3, v10

    const/16 v8, 0x10

    const/16 v10, 0x20

    aput-byte v10, v3, v8

    const/16 v8, 0x41

    const/16 v10, 0x11

    aput-byte v8, v3, v10

    const/16 v8, 0x12

    const/16 v10, 0x12

    aput-byte v10, v3, v8

    const/16 v8, 0x13

    const/16 v10, 0x7a

    aput-byte v10, v3, v8

    const/16 v8, 0x14

    const/16 v10, -0xf

    aput-byte v10, v3, v8

    const/16 v8, 0x15

    aput-byte v11, v3, v8

    const/16 v8, 0x16

    const/16 v10, 0x66

    aput-byte v10, v3, v8

    const/16 v8, 0x17

    const/4 v10, -0x7

    aput-byte v10, v3, v8

    const/16 v8, 0x18

    const/16 v10, 0x6e

    aput-byte v10, v3, v8

    const/16 v8, 0x19

    const/16 v10, 0x4e

    aput-byte v10, v3, v8

    const/16 v8, 0x1a

    const/16 v10, 0x4c

    aput-byte v10, v3, v8

    const/16 v8, 0x1b

    const/16 v10, 0x70

    aput-byte v10, v3, v8

    const/16 v8, 0x1c

    const/16 v10, -0x4f

    aput-byte v10, v3, v8

    const/16 v8, 0x1d

    const/16 v10, 0xe

    aput-byte v10, v3, v8

    const/16 v8, 0x1e

    const/16 v10, 0x20

    aput-byte v10, v3, v8

    const/16 v8, 0x1f

    const/16 v10, -0x9

    aput-byte v10, v3, v8

    const/16 v8, 0x20

    const/16 v10, 0x24

    aput-byte v10, v3, v8

    const/16 v8, 0x21

    aput-byte v1, v3, v8

    const/16 v8, 0x22

    const/16 v10, 0x58

    aput-byte v10, v3, v8

    const/16 v8, 0x23

    const/16 v10, 0x76

    aput-byte v10, v3, v8

    const/16 v8, 0x24

    const/16 v10, -0x17

    aput-byte v10, v3, v8

    const/16 v8, 0x25

    const/4 v10, 0x6

    aput-byte v10, v3, v8

    const/16 v8, 0x26

    const/16 v10, 0x25

    aput-byte v10, v3, v8

    const/16 v8, 0x27

    const/16 v10, -0xc

    aput-byte v10, v3, v8

    const/16 v8, 0x28

    const/16 v10, 0x20

    aput-byte v10, v3, v8

    const/16 v8, 0x29

    const/16 v10, 0x4b

    aput-byte v10, v3, v8

    const/16 v8, 0x2a

    const/16 v10, 0x63

    aput-byte v10, v3, v8

    const/16 v8, 0x2b

    const/16 v10, 0x70

    aput-byte v10, v3, v8

    const/16 v8, 0x2c

    const/16 v10, -0x10

    aput-byte v10, v3, v8

    const/16 v8, 0x2d

    const/16 v10, 0xe

    aput-byte v10, v3, v8

    const/16 v8, 0x2e

    const/16 v10, 0x26

    aput-byte v10, v3, v8

    const/16 v8, 0x8

    new-array v10, v8, [B

    const/16 v8, 0x41

    aput-byte v8, v10, v1

    const/16 v8, 0x2f

    aput-byte v8, v10, v14

    const/16 v8, 0x3c

    aput-byte v8, v10, v15

    const/16 v8, 0x19

    aput-byte v8, v10, v12

    const/16 v8, -0x62

    aput-byte v8, v10, v13

    const/16 v8, 0x68

    aput-byte v8, v10, v11

    const/16 v8, 0x49

    const/16 v17, 0x6

    aput-byte v8, v10, v17

    const/16 v8, -0x65

    const/16 v16, 0x7

    aput-byte v8, v10, v16

    invoke-static {v3, v10}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v0}, Lcom/google/gson/JsonElement;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-direct/range {p0 .. p0}, Lcom/github/catvod/spider/appysv2/b/F;->l()Ljava/util/Map;

    move-result-object v8

    invoke-static {v3, v0, v8}, Lcom/github/catvod/spider/appysv2/n/c;->g(Ljava/lang/String;Ljava/lang/String;Ljava/util/Map;)Lcom/github/catvod/spider/appysv2/n/e;

    move-result-object v0

    new-instance v3, Lorg/json/JSONObject;

    invoke-virtual {v0}, Lcom/github/catvod/spider/appysv2/n/e;->a()Ljava/lang/String;

    move-result-object v0

    invoke-direct {v3, v0}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    new-array v0, v13, [B

    const/16 v8, -0x33

    aput-byte v8, v0, v1

    const/16 v8, -0xb

    aput-byte v8, v0, v14

    const/16 v8, -0x78

    aput-byte v8, v0, v15

    const/16 v8, -0x6a

    aput-byte v8, v0, v12

    const/16 v8, 0x8

    new-array v10, v8, [B

    const/16 v8, -0x52

    aput-byte v8, v10, v1

    const/16 v8, -0x66

    aput-byte v8, v10, v14

    const/16 v8, -0x14

    aput-byte v8, v10, v15

    const/16 v8, -0xd

    aput-byte v8, v10, v12

    const/16 v8, 0x3d

    aput-byte v8, v10, v13

    const/16 v8, 0x3f

    aput-byte v8, v10, v11

    const/16 v8, 0x55

    const/16 v17, 0x6

    aput-byte v8, v10, v17

    const/16 v8, -0x74

    const/16 v16, 0x7

    aput-byte v8, v10, v16

    invoke-static {v0, v10}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v3, v0}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;)I

    move-result v0

    if-nez v0, :cond_3f8

    new-array v0, v13, [B

    const/16 v8, -0x6a

    aput-byte v8, v0, v1

    const/16 v8, -0x59

    aput-byte v8, v0, v14

    const/16 v8, 0x2d

    aput-byte v8, v0, v15

    const/4 v8, -0x2

    aput-byte v8, v0, v12

    const/16 v8, 0x8

    new-array v10, v8, [B

    const/16 v8, -0xe

    aput-byte v8, v10, v1

    const/16 v8, -0x3a

    aput-byte v8, v10, v14

    const/16 v8, 0x59

    aput-byte v8, v10, v15

    const/16 v8, -0x61

    aput-byte v8, v10, v12

    const/16 v8, -0x36

    aput-byte v8, v10, v13

    const/16 v8, 0x12

    aput-byte v8, v10, v11

    const/16 v8, -0x62

    const/16 v17, 0x6

    aput-byte v8, v10, v17

    const/16 v8, 0x32

    const/16 v16, 0x7

    aput-byte v8, v10, v16

    invoke-static {v0, v10}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v3, v0}, Lorg/json/JSONObject;->optJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v0

    const/16 v3, 0xb

    new-array v3, v3, [B

    const/16 v8, 0x1e

    aput-byte v8, v3, v1

    const/16 v8, -0x77

    aput-byte v8, v3, v14

    const/16 v8, 0x5c

    aput-byte v8, v3, v15

    const/16 v8, -0x31

    aput-byte v8, v3, v12

    const/16 v8, -0x13

    aput-byte v8, v3, v13

    const/16 v8, 0x63

    aput-byte v8, v3, v11

    const/16 v8, -0x7c

    const/4 v10, 0x6

    aput-byte v8, v3, v10

    const/16 v8, 0x54

    const/4 v10, 0x7

    aput-byte v8, v3, v10

    const/16 v8, 0xf

    const/16 v10, 0x8

    aput-byte v8, v3, v10

    const/16 v8, -0x6c

    const/16 v18, 0x9

    aput-byte v8, v3, v18

    const/16 v8, 0x47

    const/16 v18, 0xa

    aput-byte v8, v3, v18

    new-array v8, v10, [B

    const/16 v10, 0x5a

    aput-byte v10, v8, v1

    const/16 v10, -0x1a

    aput-byte v10, v8, v14

    const/16 v10, 0x2b

    aput-byte v10, v8, v15

    const/16 v10, -0x5f

    aput-byte v10, v8, v12

    const/16 v10, -0x7f

    aput-byte v10, v8, v13

    const/16 v10, 0xc

    aput-byte v10, v8, v11

    const/16 v10, -0x1b

    const/16 v17, 0x6

    aput-byte v10, v8, v17

    const/16 v10, 0x30

    const/16 v16, 0x7

    aput-byte v10, v8, v16

    invoke-static {v3, v8}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v0, v3}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0
    :try_end_3f4
    .catch Ljava/lang/Exception; {:try_start_16b .. :try_end_3f4} :catch_643

    move-object/from16 v8, p0

    goto/16 :goto_6a5

    :cond_3f8
    const/16 v8, 0x191

    if-ne v0, v8, :cond_543

    move-object/from16 v8, p0

    :try_start_3fe
    invoke-direct {v8, v14}, Lcom/github/catvod/spider/appysv2/b/F;->q(Z)Z

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/16 v3, 0x8

    new-array v10, v3, [B

    const/16 v3, 0x65

    aput-byte v3, v10, v1

    const/16 v3, -0x7b

    aput-byte v3, v10, v14

    const/16 v3, -0x12

    aput-byte v3, v10, v15

    const/16 v3, -0x41

    aput-byte v3, v10, v12

    const/16 v3, -0x4a

    aput-byte v3, v10, v13

    const/16 v3, 0x46

    aput-byte v3, v10, v11

    const/16 v3, -0x1b

    const/16 v17, 0x6

    aput-byte v3, v10, v17

    const/16 v3, 0x1d

    const/16 v16, 0x7

    aput-byte v3, v10, v16

    const/16 v3, 0x8

    new-array v11, v3, [B

    const/16 v3, 0x24

    aput-byte v3, v11, v1

    const/16 v3, -0xf

    aput-byte v3, v11, v14

    const/16 v3, -0x66

    aput-byte v3, v11, v15

    const/16 v3, -0x26

    aput-byte v3, v11, v12

    const/16 v3, -0x25

    aput-byte v3, v11, v13

    const/16 v3, 0x36

    const/16 v16, 0x5

    aput-byte v3, v11, v16

    const/16 v3, -0x6f

    const/16 v17, 0x6

    aput-byte v3, v11, v17

    const/16 v3, 0x3d

    const/16 v19, 0x7

    aput-byte v3, v11, v19

    invoke-static {v10, v11}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/16 v3, 0x1e

    new-array v3, v3, [B

    const/16 v10, -0x1c

    aput-byte v10, v3, v1

    const/16 v10, -0x3d

    aput-byte v10, v3, v14

    const/16 v10, -0x1d

    aput-byte v10, v3, v15

    const/16 v10, 0x21

    aput-byte v10, v3, v12

    const/16 v10, -0x54

    aput-byte v10, v3, v13

    const/16 v10, 0x64

    const/4 v11, 0x5

    aput-byte v10, v3, v11

    const/4 v10, -0x7

    const/4 v11, 0x6

    aput-byte v10, v3, v11

    const/16 v10, -0x62

    const/4 v11, 0x7

    aput-byte v10, v3, v11

    const/16 v10, -0x4f

    const/16 v11, 0x8

    aput-byte v10, v3, v11

    const/16 v10, -0x6f

    const/16 v11, 0x9

    aput-byte v10, v3, v11

    const/16 v10, -0x21

    const/16 v11, 0xa

    aput-byte v10, v3, v11

    const/16 v10, 0xb

    const/16 v11, 0x35

    aput-byte v11, v3, v10

    const/16 v10, -0x58

    const/16 v11, 0xc

    aput-byte v10, v3, v11

    const/16 v10, 0x75

    const/16 v11, 0xd

    aput-byte v10, v3, v11

    const/16 v10, -0x5f

    const/16 v11, 0xe

    aput-byte v10, v3, v11

    const/16 v10, -0x2a

    const/16 v11, 0xf

    aput-byte v10, v3, v11

    const/16 v10, 0x10

    const/16 v11, -0x54

    aput-byte v11, v3, v10

    const/16 v10, -0x7a

    const/16 v11, 0x11

    aput-byte v10, v3, v11

    const/16 v10, 0x12

    const/16 v11, -0x65

    aput-byte v11, v3, v10

    const/16 v10, 0x13

    const/16 v11, 0x23

    aput-byte v11, v3, v10

    const/16 v10, 0x14

    const/16 v11, -0x5e

    aput-byte v11, v3, v10

    const/16 v10, 0x15

    const/16 v11, 0x76

    aput-byte v11, v3, v10

    const/16 v10, 0x16

    const/16 v11, -0x16

    aput-byte v11, v3, v10

    const/16 v10, 0x17

    const/16 v11, -0x61

    aput-byte v11, v3, v10

    const/16 v10, 0x18

    const/16 v11, -0x50

    aput-byte v11, v3, v10

    const/16 v10, 0x19

    const/16 v11, -0x7c

    aput-byte v11, v3, v10

    const/16 v10, 0x1a

    const/16 v11, -0x6a

    aput-byte v11, v3, v10

    const/16 v10, 0x1b

    const/16 v11, 0x26

    aput-byte v11, v3, v10

    const/16 v10, 0x1c

    const/16 v11, -0x5d

    aput-byte v11, v3, v10

    const/16 v10, 0x1d

    const/16 v11, 0x3f

    aput-byte v11, v3, v10

    const/16 v10, 0x8

    new-array v10, v10, [B

    const/16 v11, -0x22

    aput-byte v11, v10, v1

    const/16 v11, -0x1d

    aput-byte v11, v10, v14

    const/16 v11, -0x4a

    aput-byte v11, v10, v15

    const/16 v11, 0x4f

    aput-byte v11, v10, v12

    const/16 v11, -0x33

    aput-byte v11, v10, v13

    const/16 v11, 0x11

    const/4 v12, 0x5

    aput-byte v11, v10, v12

    const/16 v11, -0x73

    const/4 v12, 0x6

    aput-byte v11, v10, v12

    const/16 v11, -0xa

    const/4 v12, 0x7

    aput-byte v11, v10, v12

    invoke-static {v3, v10}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lcom/github/catvod/crawler/SpiderDebug;->log(Ljava/lang/String;)V

    goto/16 :goto_69e

    :cond_543
    move-object/from16 v8, p0

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/16 v10, 0x8

    new-array v11, v10, [B

    const/4 v10, 0x7

    aput-byte v10, v11, v1

    const/16 v10, -0x19

    aput-byte v10, v11, v14

    const/16 v10, 0x37

    aput-byte v10, v11, v15

    const/16 v10, -0x21

    aput-byte v10, v11, v12

    const/16 v10, -0x2b

    aput-byte v10, v11, v13

    const/16 v10, 0x59

    const/16 v16, 0x5

    aput-byte v10, v11, v16

    const/16 v10, 0x10

    const/16 v17, 0x6

    aput-byte v10, v11, v17

    const/16 v10, 0xf

    const/16 v17, 0x7

    aput-byte v10, v11, v17

    const/16 v10, 0x8

    new-array v13, v10, [B

    const/16 v10, 0x46

    aput-byte v10, v13, v1

    const/16 v10, -0x6d

    aput-byte v10, v13, v14

    const/16 v10, 0x43

    aput-byte v10, v13, v15

    const/16 v10, -0x46

    aput-byte v10, v13, v12

    const/16 v10, -0x48

    const/16 v17, 0x4

    aput-byte v10, v13, v17

    const/16 v10, 0x29

    const/16 v16, 0x5

    aput-byte v10, v13, v16

    const/16 v10, 0x64

    const/16 v19, 0x6

    aput-byte v10, v13, v19

    const/16 v10, 0x2f

    const/16 v19, 0x7

    aput-byte v10, v13, v19

    invoke-static {v11, v13}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v0, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    new-array v10, v15, [B

    const/16 v11, 0x6e

    aput-byte v11, v10, v1

    const/16 v11, 0x11

    aput-byte v11, v10, v14

    const/16 v11, 0x8

    new-array v11, v11, [B

    const/16 v13, 0x54

    aput-byte v13, v11, v1

    const/16 v13, 0x31

    aput-byte v13, v11, v14

    const/16 v13, 0xe

    aput-byte v13, v11, v15

    const/16 v13, -0x76

    aput-byte v13, v11, v12

    const/16 v13, 0x71

    const/16 v17, 0x4

    aput-byte v13, v11, v17

    const/16 v13, 0xd

    const/16 v16, 0x5

    aput-byte v13, v11, v16

    const/4 v13, -0x8

    const/16 v18, 0x6

    aput-byte v13, v11, v18

    const/16 v13, -0x67

    const/4 v12, 0x7

    aput-byte v13, v11, v12

    invoke-static {v10, v11}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v0, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    new-array v10, v12, [B

    const/16 v11, 0x45

    aput-byte v11, v10, v1

    const/16 v11, -0x29

    aput-byte v11, v10, v14

    const/16 v11, 0x15

    aput-byte v11, v10, v15

    const/4 v11, 0x5

    const/4 v12, 0x3

    aput-byte v11, v10, v12

    const/16 v12, 0x5a

    const/4 v13, 0x4

    aput-byte v12, v10, v13

    const/16 v12, 0x58

    aput-byte v12, v10, v11

    const/16 v11, -0x4e

    const/4 v12, 0x6

    aput-byte v11, v10, v12

    const/16 v11, 0x8

    new-array v11, v11, [B

    const/16 v12, 0x28

    aput-byte v12, v11, v1

    const/16 v12, -0x4e

    aput-byte v12, v11, v14

    const/16 v12, 0x66

    aput-byte v12, v11, v15

    const/16 v12, 0x76

    const/4 v13, 0x3

    aput-byte v12, v11, v13

    const/16 v12, 0x3b

    const/4 v13, 0x4

    aput-byte v12, v11, v13

    const/16 v12, 0x3f

    const/4 v13, 0x5

    aput-byte v12, v11, v13

    const/16 v12, -0x29

    const/4 v13, 0x6

    aput-byte v12, v11, v13

    const/16 v12, 0x34

    const/4 v13, 0x7

    aput-byte v12, v11, v13

    invoke-static {v10, v11}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v3, v10}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lcom/github/catvod/crawler/SpiderDebug;->log(Ljava/lang/String;)V
    :try_end_63f
    .catch Ljava/lang/Exception; {:try_start_3fe .. :try_end_63f} :catch_641

    goto/16 :goto_6a3

    :catch_641
    move-exception v0

    goto :goto_665

    :catch_643
    move-exception v0

    move-object/from16 v8, p0

    goto :goto_665

    :catch_647
    move-exception v0

    move-object/from16 v8, p0

    :goto_64a
    move-object/from16 v9, p5

    goto :goto_665

    :catch_64d
    move-exception v0

    move-object/from16 v8, p0

    :goto_650
    move-object/from16 v7, p4

    goto :goto_64a

    :catch_653
    move-exception v0

    move-object/from16 v8, p0

    :goto_656
    move-object/from16 v6, p3

    goto :goto_650

    :catch_659
    move-exception v0

    move-object/from16 v8, p0

    :goto_65c
    move-object/from16 v5, p2

    goto :goto_656

    :catch_65f
    move-exception v0

    move-object/from16 v8, p0

    move-object/from16 v4, p1

    goto :goto_65c

    :goto_665
    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const/16 v10, 0x11

    new-array v10, v10, [B

    fill-array-data v10, :array_b30

    const/16 v11, 0x8

    new-array v12, v11, [B

    fill-array-data v12, :array_b3e

    invoke-static {v10, v12}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v3, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    new-array v10, v15, [B

    fill-array-data v10, :array_b46

    new-array v11, v11, [B

    fill-array-data v11, :array_b4c

    .line 1
    invoke-static {v10, v11, v3, v0}, Lcom/github/catvod/spider/appysv2/b/y;->b([B[BLjava/lang/StringBuilder;Ljava/lang/Exception;)V

    if-ge v2, v15, :cond_69e

    const-wide/16 v10, 0x3e8

    .line 2
    :try_start_693
    invoke-static {v10, v11}, Ljava/lang/Thread;->sleep(J)V
    :try_end_696
    .catch Ljava/lang/InterruptedException; {:try_start_693 .. :try_end_696} :catch_697

    goto :goto_69e

    :catch_697
    invoke-static {}, Ljava/lang/Thread;->currentThread()Ljava/lang/Thread;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Thread;->interrupt()V

    :cond_69e
    :goto_69e
    move v0, v2

    goto/16 :goto_2

    :cond_6a1
    move-object/from16 v8, p0

    :goto_6a3
    const-string v0, ""

    :goto_6a5
    invoke-virtual {v0}, Ljava/lang/String;->isEmpty()Z

    move-result v2

    if-eqz v2, :cond_6e5

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/16 v1, 0x26

    new-array v1, v1, [B

    fill-array-data v1, :array_b54

    const/16 v2, 0x8

    new-array v3, v2, [B

    fill-array-data v3, :array_b6c

    invoke-static {v1, v3}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, v15}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/16 v1, 0xa

    new-array v1, v1, [B

    fill-array-data v1, :array_b74

    new-array v2, v2, [B

    fill-array-data v2, :array_b7e

    invoke-static {v1, v2}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lcom/github/catvod/crawler/SpiderDebug;->log(Ljava/lang/String;)V

    const-string v0, ""

    return-object v0

    :cond_6e5
    :try_start_6e5
    new-instance v2, Ljava/net/URL;

    invoke-direct {v2, v0}, Ljava/net/URL;-><init>(Ljava/lang/String;)V

    invoke-virtual {v2}, Ljava/net/URL;->getQuery()Ljava/lang/String;

    move-result-object v2

    new-array v3, v14, [B

    const/16 v4, -0x16

    aput-byte v4, v3, v1

    const/16 v4, 0x8

    new-array v4, v4, [B

    const/16 v5, -0x34

    aput-byte v5, v4, v1

    const/4 v5, -0x5

    aput-byte v5, v4, v14

    const/16 v5, -0xd

    aput-byte v5, v4, v15

    const/16 v5, -0x68

    const/4 v6, 0x3

    aput-byte v5, v4, v6

    const/16 v5, -0x29

    const/4 v6, 0x4

    aput-byte v5, v4, v6

    const/16 v5, -0xf

    const/4 v6, 0x5

    aput-byte v5, v4, v6

    const/16 v5, -0x7d

    const/4 v6, 0x6

    aput-byte v5, v4, v6

    const/16 v5, 0x37

    const/4 v6, 0x7

    aput-byte v5, v4, v6

    invoke-static {v3, v4}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v2

    const/4 v3, 0x0

    array-length v4, v2

    const/4 v5, 0x0

    :goto_727
    if-ge v5, v4, :cond_7da

    aget-object v6, v2, v5

    const/4 v7, 0x7

    new-array v7, v7, [B

    const/16 v9, 0x7c

    aput-byte v9, v7, v1

    const/16 v9, 0xc

    aput-byte v9, v7, v14

    const/16 v9, -0x65

    aput-byte v9, v7, v15

    const/16 v9, 0x2a

    const/4 v10, 0x3

    aput-byte v9, v7, v10

    const/4 v9, -0x4

    const/4 v10, 0x4

    aput-byte v9, v7, v10

    const/16 v9, 0x22

    const/4 v10, 0x5

    aput-byte v9, v7, v10

    const/4 v9, 0x6

    aput-byte v10, v7, v9

    const/16 v9, 0x8

    new-array v9, v9, [B

    const/16 v10, 0xc

    aput-byte v10, v9, v1

    const/16 v10, 0x6d

    aput-byte v10, v9, v14

    const/16 v10, -0x17

    aput-byte v10, v9, v15

    const/16 v10, 0x4b

    const/4 v11, 0x3

    aput-byte v10, v9, v11

    const/16 v10, -0x6f

    const/4 v11, 0x4

    aput-byte v10, v9, v11

    const/16 v10, 0x51

    const/4 v11, 0x5

    aput-byte v10, v9, v11

    const/16 v10, 0x38

    const/4 v11, 0x6

    aput-byte v10, v9, v11

    const/16 v10, -0xb

    const/4 v11, 0x7

    aput-byte v10, v9, v11

    invoke-static {v7, v9}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v6, v7}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v7

    if-eqz v7, :cond_7d6

    new-array v2, v11, [B

    const/16 v3, 0xd

    aput-byte v3, v2, v1

    const/16 v3, 0x74

    aput-byte v3, v2, v14

    const/16 v3, 0x2e

    aput-byte v3, v2, v15

    const/16 v3, 0x39

    const/4 v4, 0x3

    aput-byte v3, v2, v4

    const/16 v3, 0x64

    const/4 v4, 0x4

    aput-byte v3, v2, v4

    const/16 v3, 0x52

    const/4 v4, 0x5

    aput-byte v3, v2, v4

    const/16 v3, -0x4c

    const/4 v4, 0x6

    aput-byte v3, v2, v4

    const/16 v3, 0x8

    new-array v3, v3, [B

    const/16 v4, 0x7d

    aput-byte v4, v3, v1

    const/16 v4, 0x15

    aput-byte v4, v3, v14

    const/16 v4, 0x5c

    aput-byte v4, v3, v15

    const/16 v4, 0x58

    const/4 v5, 0x3

    aput-byte v4, v3, v5

    const/16 v4, 0x9

    const/4 v5, 0x4

    aput-byte v4, v3, v5

    const/16 v4, 0x21

    const/4 v5, 0x5

    aput-byte v4, v3, v5

    const/16 v4, -0x77

    const/4 v5, 0x6

    aput-byte v4, v3, v5

    const/16 v4, 0x11

    const/4 v5, 0x7

    aput-byte v4, v3, v5

    invoke-static {v2, v3}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/String;->length()I

    move-result v2

    invoke-virtual {v6, v2}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v3

    goto :goto_7da

    :cond_7d6
    add-int/lit8 v5, v5, 0x1

    goto/16 :goto_727

    :cond_7da
    :goto_7da
    invoke-static {v3, v1}, Landroid/util/Base64;->decode(Ljava/lang/String;I)[B

    move-result-object v2

    new-instance v3, Ljava/lang/String;

    sget-object v4, Ljava/nio/charset/StandardCharsets;->UTF_8:Ljava/nio/charset/Charset;

    invoke-direct {v3, v2, v4}, Ljava/lang/String;-><init>([BLjava/nio/charset/Charset;)V

    new-instance v2, Lokhttp3/Request$Builder;

    invoke-direct {v2}, Lokhttp3/Request$Builder;-><init>()V

    invoke-virtual {v2, v3}, Lokhttp3/Request$Builder;->url(Ljava/lang/String;)Lokhttp3/Request$Builder;

    move-result-object v2

    const/4 v3, 0x7

    new-array v3, v3, [B

    const/16 v4, -0x20

    aput-byte v4, v3, v1

    const/16 v4, -0x2c

    aput-byte v4, v3, v14

    const/16 v4, -0xc

    aput-byte v4, v3, v15

    const/16 v4, -0x29

    const/4 v5, 0x3

    aput-byte v4, v3, v5

    const/16 v4, 0x56

    const/4 v5, 0x4

    aput-byte v4, v3, v5

    const/16 v4, -0x75

    const/4 v5, 0x5

    aput-byte v4, v3, v5

    const/16 v4, -0x75

    const/4 v5, 0x6

    aput-byte v4, v3, v5

    const/16 v4, 0x8

    new-array v4, v4, [B

    const/16 v5, -0x4e

    aput-byte v5, v4, v1

    const/16 v5, -0x4f

    aput-byte v5, v4, v14

    const/16 v5, -0x6e

    aput-byte v5, v4, v15

    const/16 v5, -0x4e

    const/4 v6, 0x3

    aput-byte v5, v4, v6

    const/16 v5, 0x24

    const/4 v6, 0x4

    aput-byte v5, v4, v6

    const/16 v5, -0x12

    const/4 v6, 0x5

    aput-byte v5, v4, v6

    const/4 v5, -0x7

    const/4 v6, 0x6

    aput-byte v5, v4, v6

    const/16 v5, 0xf

    const/4 v6, 0x7

    aput-byte v5, v4, v6

    invoke-static {v3, v4}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v3

    const/16 v4, 0x17

    new-array v4, v4, [B

    const/16 v5, 0x20

    aput-byte v5, v4, v1

    const/16 v5, 0x36

    aput-byte v5, v4, v14

    const/16 v5, -0x30

    aput-byte v5, v4, v15

    const/16 v5, 0x61

    const/4 v6, 0x3

    aput-byte v5, v4, v6

    const/16 v5, -0x46

    const/4 v6, 0x4

    aput-byte v5, v4, v6

    const/16 v5, 0xa

    const/4 v6, 0x5

    aput-byte v5, v4, v6

    const/16 v5, -0x62

    const/4 v6, 0x6

    aput-byte v5, v4, v6

    const/16 v5, 0x52

    const/4 v6, 0x7

    aput-byte v5, v4, v6

    const/16 v5, 0x3f

    const/16 v6, 0x8

    aput-byte v5, v4, v6

    const/16 v5, 0x35

    const/16 v6, 0x9

    aput-byte v5, v4, v6

    const/16 v5, -0x2d

    const/16 v6, 0xa

    aput-byte v5, v4, v6

    const/16 v5, 0xb

    const/16 v6, 0x3f

    aput-byte v6, v4, v5

    const/4 v5, -0x8

    const/16 v6, 0xc

    aput-byte v5, v4, v6

    const/16 v5, 0xd

    aput-byte v15, v4, v5

    const/16 v6, -0x7e

    const/16 v7, 0xe

    aput-byte v6, v4, v7

    const/16 v6, 0xf

    aput-byte v5, v4, v6

    const/16 v5, 0x10

    const/16 v6, 0x29

    aput-byte v6, v4, v5

    const/16 v5, 0x2c

    const/16 v6, 0x11

    aput-byte v5, v4, v6

    const/16 v5, 0x12

    const/16 v6, -0x76

    aput-byte v6, v4, v5

    const/16 v5, 0x13

    const/16 v6, 0x72

    aput-byte v6, v4, v5

    const/16 v5, 0x14

    const/16 v6, -0x5a

    aput-byte v6, v4, v5

    const/16 v5, 0x15

    const/16 v6, 0x5d

    aput-byte v6, v4, v5

    const/16 v5, 0x16

    const/16 v6, -0x62

    aput-byte v6, v4, v5

    const/16 v5, 0x8

    new-array v5, v5, [B

    const/16 v6, 0x48

    aput-byte v6, v5, v1

    const/16 v6, 0x42

    aput-byte v6, v5, v14

    const/16 v6, -0x5c

    aput-byte v6, v5, v15

    const/16 v6, 0x11

    const/4 v7, 0x3

    aput-byte v6, v5, v7

    const/16 v6, -0x37

    const/4 v7, 0x4

    aput-byte v6, v5, v7

    const/16 v6, 0x30

    const/4 v7, 0x5

    aput-byte v6, v5, v7

    const/16 v6, -0x4f

    const/4 v7, 0x6

    aput-byte v6, v5, v7

    const/16 v6, 0x7d

    const/4 v7, 0x7

    aput-byte v6, v5, v7

    invoke-static {v4, v5}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v2, v3, v4}, Lokhttp3/Request$Builder;->addHeader(Ljava/lang/String;Ljava/lang/String;)Lokhttp3/Request$Builder;

    move-result-object v2

    invoke-virtual {v2}, Lokhttp3/Request$Builder;->build()Lokhttp3/Request;

    move-result-object v2

    invoke-static {}, Lcom/github/catvod/spider/appysv2/n/c;->a()Lokhttp3/OkHttpClient;

    move-result-object v3

    invoke-virtual {v3, v2}, Lokhttp3/OkHttpClient;->newCall(Lokhttp3/Request;)Lokhttp3/Call;

    move-result-object v2

    invoke-interface {v2}, Lokhttp3/Call;->execute()Lokhttp3/Response;

    move-result-object v2

    invoke-virtual {v2}, Lokhttp3/Response;->isSuccessful()Z

    move-result v3

    if-eqz v3, :cond_9c5

    invoke-virtual {v2}, Lokhttp3/Response;->body()Lokhttp3/ResponseBody;

    move-result-object v2

    invoke-virtual {v2}, Lokhttp3/ResponseBody;->string()Ljava/lang/String;

    move-result-object v2

    new-instance v3, Lorg/json/JSONObject;

    invoke-direct {v3, v2}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x4

    new-array v4, v2, [B

    const/16 v2, -0x1f

    aput-byte v2, v4, v1

    const/16 v2, -0x55

    aput-byte v2, v4, v14

    const/16 v2, -0x5f

    aput-byte v2, v4, v15

    const/16 v2, -0x29

    const/4 v5, 0x3

    aput-byte v2, v4, v5

    const/16 v2, 0x8

    new-array v2, v2, [B

    const/16 v5, -0x7b

    aput-byte v5, v2, v1

    const/16 v5, -0x36

    aput-byte v5, v2, v14

    const/16 v5, -0x2b

    aput-byte v5, v2, v15

    const/16 v5, -0x4a

    const/4 v6, 0x3

    aput-byte v5, v2, v6

    const/16 v5, 0x26

    const/4 v6, 0x4

    aput-byte v5, v2, v6

    const/16 v5, 0x39

    const/4 v6, 0x5

    aput-byte v5, v2, v6

    const/16 v5, -0x10

    const/4 v6, 0x6

    aput-byte v5, v2, v6

    const/16 v5, -0x43

    const/4 v6, 0x7

    aput-byte v5, v2, v6

    invoke-static {v4, v2}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v3, v2}, Lorg/json/JSONObject;->optJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v2

    const/16 v3, 0xc

    new-array v3, v3, [B

    const/16 v4, 0x7d

    aput-byte v4, v3, v1

    const/4 v4, -0x6

    aput-byte v4, v3, v14

    const/16 v4, 0x51

    aput-byte v4, v3, v15

    const/16 v4, 0x6f

    const/4 v5, 0x3

    aput-byte v4, v3, v5

    const/16 v4, -0x55

    const/4 v5, 0x4

    aput-byte v4, v3, v5

    const/16 v4, -0x46

    const/4 v5, 0x5

    aput-byte v4, v3, v5

    const/16 v4, -0x70

    const/4 v5, 0x6

    aput-byte v4, v3, v5

    const/16 v4, -0x3c

    const/4 v5, 0x7

    aput-byte v4, v3, v5

    const/16 v4, 0x50

    const/16 v5, 0x8

    aput-byte v4, v3, v5

    const/16 v4, -0x16

    const/16 v5, 0x9

    aput-byte v4, v3, v5

    const/16 v4, 0x47

    const/16 v5, 0xa

    aput-byte v4, v3, v5

    const/16 v4, 0xb

    const/16 v5, 0x6a

    aput-byte v5, v3, v4

    const/16 v4, 0x8

    new-array v4, v4, [B

    const/16 v5, 0xf

    aput-byte v5, v4, v1

    const/16 v1, -0x61

    aput-byte v1, v4, v14

    const/16 v1, 0x35

    aput-byte v1, v4, v15

    const/4 v1, 0x6

    const/4 v5, 0x3

    aput-byte v1, v4, v5

    const/16 v5, -0x27

    const/4 v6, 0x4

    aput-byte v5, v4, v6

    const/16 v5, -0x21

    const/4 v6, 0x5

    aput-byte v5, v4, v6

    const/16 v5, -0xd

    aput-byte v5, v4, v1

    const/16 v1, -0x50

    const/4 v5, 0x7

    aput-byte v1, v4, v5

    invoke-static {v3, v4}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v2, v1}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    goto/16 :goto_b2f

    :cond_9c5
    invoke-virtual {v2}, Lokhttp3/Response;->code()I

    move-result v3

    const/16 v4, 0x12e

    if-ne v3, v4, :cond_a25

    const/16 v3, 0x8

    new-array v3, v3, [B

    aput-byte v1, v3, v1

    aput-byte v15, v3, v14

    const/16 v4, -0x4f

    aput-byte v4, v3, v15

    const/16 v4, -0x1c

    const/4 v5, 0x3

    aput-byte v4, v3, v5

    const/16 v4, -0x65

    const/4 v5, 0x4

    aput-byte v4, v3, v5

    const/16 v4, 0x5e

    const/4 v5, 0x5

    aput-byte v4, v3, v5

    const/16 v4, 0x33

    const/4 v5, 0x6

    aput-byte v4, v3, v5

    const/16 v4, -0x75

    const/4 v5, 0x7

    aput-byte v4, v3, v5

    const/16 v4, 0x8

    new-array v4, v4, [B

    const/16 v5, 0x4c

    aput-byte v5, v4, v1

    const/16 v1, 0x6d

    aput-byte v1, v4, v14

    const/16 v1, -0x2e

    aput-byte v1, v4, v15

    const/16 v1, -0x7b

    const/4 v5, 0x3

    aput-byte v1, v4, v5

    const/16 v1, -0x11

    const/4 v5, 0x4

    aput-byte v1, v4, v5

    const/16 v1, 0x37

    const/4 v5, 0x5

    aput-byte v1, v4, v5

    const/16 v1, 0x5c

    const/4 v5, 0x6

    aput-byte v1, v4, v5

    const/16 v1, -0x1b

    const/4 v5, 0x7

    aput-byte v1, v4, v5

    invoke-static {v3, v4}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v2, v1}, Lokhttp3/Response;->header(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    goto/16 :goto_b2f

    :cond_a25
    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const/16 v4, 0x23

    new-array v4, v4, [B

    const/16 v5, -0x28

    aput-byte v5, v4, v1

    const/16 v5, 0x28

    aput-byte v5, v4, v14

    const/16 v5, -0x2f

    aput-byte v5, v4, v15

    const/16 v5, 0x71

    const/4 v6, 0x3

    aput-byte v5, v4, v6

    const/16 v5, -0x1c

    const/4 v6, 0x4

    aput-byte v5, v4, v6

    const/16 v5, 0x68

    const/4 v6, 0x5

    aput-byte v5, v4, v6

    const/16 v5, 0x7e

    const/4 v6, 0x6

    aput-byte v5, v4, v6

    const/16 v5, -0x4d

    const/4 v6, 0x7

    aput-byte v5, v4, v6

    const/16 v5, -0x14

    const/16 v6, 0x8

    aput-byte v5, v4, v6

    const/16 v5, 0x2c

    const/16 v6, 0x9

    aput-byte v5, v4, v6

    const/16 v5, -0x37

    const/16 v6, 0xa

    aput-byte v5, v4, v6

    const/16 v5, 0xb

    const/16 v6, 0x68

    aput-byte v6, v4, v5

    const/16 v5, -0x1c

    const/16 v6, 0xc

    aput-byte v5, v4, v6

    const/16 v6, 0x7f

    const/16 v7, 0xd

    aput-byte v6, v4, v7

    const/16 v6, 0x2a

    const/16 v7, 0xe

    aput-byte v6, v4, v7

    const/16 v6, 0xf

    aput-byte v5, v4, v6

    const/16 v5, 0x10

    const/16 v6, -0x1d

    aput-byte v6, v4, v5

    const/16 v5, 0x39

    const/16 v6, 0x11

    aput-byte v5, v4, v6

    const/16 v5, 0x12

    const/16 v6, -0x38

    aput-byte v6, v4, v5

    const/16 v5, 0x13

    const/16 v6, 0x24

    aput-byte v6, v4, v5

    const/16 v5, 0x14

    const/16 v6, -0xd

    aput-byte v6, v4, v5

    const/16 v5, 0x15

    const/16 v6, 0x7e

    aput-byte v6, v4, v5

    const/16 v5, 0x16

    const/16 v6, 0x79

    aput-byte v6, v4, v5

    const/16 v5, 0x17

    const/16 v6, -0x1d

    aput-byte v6, v4, v5

    const/16 v5, 0x18

    const/16 v6, -0x1b

    aput-byte v6, v4, v5

    const/16 v5, 0x19

    const/16 v6, 0x23

    aput-byte v6, v4, v5

    const/16 v5, 0x1a

    const/16 v6, -0x2d

    aput-byte v6, v4, v5

    const/16 v5, 0x1b

    const/16 v6, 0x61

    aput-byte v6, v4, v5

    const/16 v5, 0x1c

    const/16 v6, -0x5f

    aput-byte v6, v4, v5

    const/16 v5, 0x1d

    const/16 v6, 0x78

    aput-byte v6, v4, v5

    const/16 v5, 0x1e

    const/16 v6, 0x65

    aput-byte v6, v4, v5

    const/16 v5, 0x1f

    const/16 v6, -0x9

    aput-byte v6, v4, v5

    const/16 v5, 0x20

    const/16 v6, -0x11

    aput-byte v6, v4, v5

    const/16 v5, 0x21

    const/16 v6, 0x77

    aput-byte v6, v4, v5

    const/16 v5, 0x22

    const/16 v6, -0x80

    aput-byte v6, v4, v5

    const/16 v5, 0x8

    new-array v5, v5, [B

    const/16 v6, -0x76

    aput-byte v6, v5, v1

    const/16 v1, 0x4d

    aput-byte v1, v5, v14

    const/16 v1, -0x60

    aput-byte v1, v5, v15

    const/4 v1, 0x3

    const/4 v6, 0x4

    aput-byte v6, v5, v1

    const/16 v1, -0x7f

    aput-byte v1, v5, v6

    const/16 v1, 0x1b

    const/4 v6, 0x5

    aput-byte v1, v5, v6

    const/16 v1, 0xa

    const/4 v6, 0x6

    aput-byte v1, v5, v6

    const/16 v1, -0x6d

    const/4 v6, 0x7

    aput-byte v1, v5, v6

    invoke-static {v4, v5}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Lokhttp3/Response;->code()I

    move-result v1

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Lcom/github/catvod/crawler/SpiderDebug;->log(Ljava/lang/String;)V
    :try_end_b2f
    .catch Ljava/lang/Exception; {:try_start_6e5 .. :try_end_b2f} :catch_b2f

    :catch_b2f
    :goto_b2f
    return-object v0

    :array_b30
    .array-data 1
        0x5at
        0x7t
        -0x75t
        0x44t
        -0x31t
        0x66t
        -0x63t
        0x72t
        0x3ft
        0x14t
        -0x73t
        0x5ft
        -0x28t
        0x2bt
        -0x7et
        0x68t
        0x3ft
    .end array-data

    nop

    :array_b3e
    .array-data 1
        0x1ft
        0x75t
        -0x7t
        0x2bt
        -0x43t
        0x46t
        -0xet
        0x1ct
    .end array-data

    :array_b46
    .array-data 1
        0x3ft
        -0x46t
    .end array-data

    nop

    :array_b4c
    .array-data 1
        0x5t
        -0x66t
        -0x6at
        -0x69t
        -0x3ft
        0xbt
        0x66t
        -0x4bt
    .end array-data

    :array_b54
    .array-data 1
        0x66t
        0x50t
        -0x3dt
        -0x20t
        -0x1dt
        0x76t
        -0x64t
        -0x23t
        0x4ft
        0x11t
        -0x28t
        -0x17t
        -0xet
        0x60t
        -0x2bt
        -0x34t
        0x56t
        0x54t
        -0x76t
        -0x18t
        -0x17t
        0x65t
        -0x2et
        -0x3bt
        0x4ft
        0x50t
        -0x32t
        -0x54t
        -0x2dt
        0x40t
        -0x10t
        -0x77t
        0x41t
        0x57t
        -0x22t
        -0x17t
        -0xct
        0x32t
    .end array-data

    nop

    :array_b6c
    .array-data 1
        0x20t
        0x31t
        -0x56t
        -0x74t
        -0x7at
        0x12t
        -0x44t
        -0x57t
    .end array-data

    :array_b74
    .array-data 1
        -0xbt
        0x5bt
        0x3et
        0x56t
        -0x67t
        -0x4ft
        -0x5at
        -0xbt
        -0x5at
        0x14t
    .end array-data

    nop

    :array_b7e
    .array-data 1
        -0x2bt
        0x3at
        0x4at
        0x22t
        -0x4t
        -0x24t
        -0x2at
        -0x7ft
    .end array-data
.end method

.method private l()Ljava/util/Map;
    .registers 8
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    new-instance v0, Ljava/util/HashMap;

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    const/4 v1, 0x6

    new-array v1, v1, [B

    fill-array-data v1, :array_de

    const/16 v2, 0x8

    new-array v3, v2, [B

    fill-array-data v3, :array_e6

    invoke-static {v1, v3}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v1

    sget-object v3, Lcom/github/catvod/spider/appysv2/b/F;->e:Ljava/lang/String;

    invoke-virtual {v0, v1, v3}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v1, 0x7

    new-array v3, v1, [B

    fill-array-data v3, :array_ee

    new-array v4, v2, [B

    fill-array-data v4, :array_f6

    invoke-static {v3, v4}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v3

    const/16 v4, 0x17

    new-array v4, v4, [B

    fill-array-data v4, :array_fe

    new-array v5, v2, [B

    fill-array-data v5, :array_10e

    invoke-static {v4, v5}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v0, v3, v4}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/16 v3, 0xa

    new-array v3, v3, [B

    fill-array-data v3, :array_116

    new-array v4, v2, [B

    fill-array-data v4, :array_120

    invoke-static {v3, v4}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v3

    const/16 v4, 0x18

    new-array v4, v4, [B

    fill-array-data v4, :array_128

    new-array v5, v2, [B

    fill-array-data v5, :array_138

    invoke-static {v4, v5}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v0, v3, v4}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    new-array v3, v2, [B

    fill-array-data v3, :array_140

    new-array v4, v2, [B

    fill-array-data v4, :array_148

    invoke-static {v3, v4}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v3

    new-array v4, v1, [B

    fill-array-data v4, :array_150

    new-array v5, v2, [B

    fill-array-data v5, :array_158

    invoke-static {v4, v5}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v0, v3, v4}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/16 v3, 0xb

    new-array v3, v3, [B

    fill-array-data v3, :array_160

    new-array v4, v2, [B

    fill-array-data v4, :array_16a

    invoke-static {v3, v4}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v3

    const/4 v4, 0x1

    new-array v4, v4, [B

    const/4 v5, 0x0

    const/16 v6, 0x6b

    aput-byte v6, v4, v5

    new-array v5, v2, [B

    fill-array-data v5, :array_172

    invoke-static {v4, v5}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v0, v3, v4}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    iget-object v3, p0, Lcom/github/catvod/spider/appysv2/b/F;->a:Ljava/lang/String;

    invoke-static {v3}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v3

    if-nez v3, :cond_dd

    const/16 v3, 0xd

    new-array v3, v3, [B

    fill-array-data v3, :array_17a

    new-array v4, v2, [B

    fill-array-data v4, :array_186

    invoke-static {v3, v4}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v3

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    new-array v1, v1, [B

    fill-array-data v1, :array_18e

    new-array v2, v2, [B

    fill-array-data v2, :array_196

    invoke-static {v1, v2}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v4, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, Lcom/github/catvod/spider/appysv2/b/F;->a:Ljava/lang/String;

    invoke-virtual {v4, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v3, v1}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_dd
    return-object v0

    :array_de
    .array-data 1
        -0x3ft
        0x4dt
        0x33t
        -0x2bt
        0x38t
        0x5ct
    .end array-data

    nop

    :array_e6
    .array-data 1
        -0x52t
        0x3ft
        0x5at
        -0x4et
        0x51t
        0x32t
        0x58t
        -0x54t
    .end array-data

    :array_ee
    .array-data 1
        0x18t
        0x3bt
        0x4at
        0x56t
        -0x12t
        -0x17t
        0x33t
    .end array-data

    :array_f6
    .array-data 1
        0x6at
        0x5et
        0x2ct
        0x33t
        -0x64t
        -0x74t
        0x41t
        -0x63t
    .end array-data

    :array_fe
    .array-data 1
        0xat
        -0x1at
        -0x1dt
        0x2bt
        -0x61t
        -0x31t
        0x5dt
        -0xft
        0x15t
        -0x1bt
        -0x20t
        0x75t
        -0x23t
        -0x39t
        0x41t
        -0x52t
        0x3t
        -0x4t
        -0x47t
        0x38t
        -0x7dt
        -0x68t
        0x5dt
    .end array-data

    :array_10e
    .array-data 1
        0x62t
        -0x6et
        -0x69t
        0x5bt
        -0x14t
        -0xbt
        0x72t
        -0x22t
    .end array-data

    :array_116
    .array-data 1
        0xft
        -0x27t
        -0x30t
        -0x20t
        -0x19t
        -0x2dt
        -0x20t
        0x54t
        0x14t
        -0x22t
    .end array-data

    nop

    :array_120
    .array-data 1
        0x7at
        -0x56t
        -0x4bt
        -0x6et
        -0x36t
        -0x4et
        -0x79t
        0x31t
    .end array-data

    :array_128
    .array-data 1
        0x43t
        0x77t
        0x75t
        0x39t
        0x4ct
        0x66t
        0x4dt
        0x29t
        0x3et
        0x3et
        0x63t
        0x2ct
        0x11t
        0x20t
        0x59t
        0x71t
        0x68t
        0x3ft
        0x2at
        0x2ct
        0xft
        0x3dt
        0x10t
        0x6ct
    .end array-data

    :array_138
    .array-data 1
        0x7t
        0x16t
        0x7t
        0x4dt
        0x63t
        0x54t
        0x63t
        0x18t
    .end array-data

    :array_140
    .array-data 1
        0x5bt
        -0x9t
        0x19t
        -0x78t
        0x17t
        -0x72t
        0x71t
        0x1ct
    .end array-data

    :array_148
    .array-data 1
        0x2bt
        -0x65t
        0x78t
        -0x4t
        0x71t
        -0x1ft
        0x3t
        0x71t
    .end array-data

    :array_150
    .array-data 1
        -0x22t
        -0x76t
        0x49t
        -0x2et
        0x59t
        0x45t
        0x13t
    .end array-data

    :array_158
    .array-data 1
        -0x41t
        -0x1ct
        0x2dt
        -0x60t
        0x36t
        0x2ct
        0x77t
        -0x74t
    .end array-data

    :array_160
    .array-data 1
        0x66t
        -0x54t
        -0x36t
        0x64t
        0x3t
        0x66t
        0x2et
        0x43t
        0x6et
        -0x4dt
        -0x2ct
    .end array-data

    :array_16a
    .array-data 1
        0x7t
        -0x24t
        -0x46t
        0x49t
        0x75t
        0x3t
        0x5ct
        0x30t
    .end array-data

    :array_172
    .array-data 1
        0x58t
        -0x37t
        0x20t
        -0x2ft
        0x4bt
        -0x2ct
        0x3ft
        0xat
    .end array-data

    :array_17a
    .array-data 1
        0xdt
        -0x12t
        -0x73t
        0x2dt
        -0x6dt
        -0x50t
        0x0t
        -0x71t
        0x2dt
        -0x11t
        -0x70t
        0x2at
        -0x6et
    .end array-data

    nop

    :array_186
    .array-data 1
        0x4ct
        -0x65t
        -0x7t
        0x45t
        -0x4t
        -0x3et
        0x69t
        -0xbt
    .end array-data

    :array_18e
    .array-data 1
        -0x1t
        -0x19t
        0x2t
        -0x5t
        0xct
        -0x11t
        0x11t
    .end array-data

    :array_196
    .array-data 1
        -0x43t
        -0x7et
        0x63t
        -0x77t
        0x69t
        -0x63t
        0x31t
        -0x5ct
    .end array-data
.end method

.method private m()I
    .registers 23

    const/4 v1, 0x0

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    const/4 v2, 0x0

    :goto_6
    const/4 v3, 0x2

    if-gt v2, v3, :cond_5c2

    const/16 v4, 0x8

    :try_start_b
    new-instance v5, Lcom/google/gson/JsonObject;

    invoke-direct {v5}, Lcom/google/gson/JsonObject;-><init>()V

    const/4 v6, 0x7

    new-array v7, v6, [B

    const/16 v8, -0x59

    aput-byte v8, v7, v1

    const/16 v8, -0x50

    const/4 v9, 0x1

    aput-byte v8, v7, v9

    const/16 v8, -0x32

    aput-byte v8, v7, v3

    const/16 v8, -0x4c

    const/4 v10, 0x3

    aput-byte v8, v7, v10

    const/16 v8, -0x9

    const/4 v11, 0x4

    aput-byte v8, v7, v11

    const/16 v8, 0x54

    const/4 v12, 0x5

    aput-byte v8, v7, v12

    const/16 v8, -0x31

    const/4 v13, 0x6

    aput-byte v8, v7, v13

    new-array v8, v4, [B

    const/16 v14, -0x3d

    aput-byte v14, v8, v1

    const/16 v15, -0x3e

    aput-byte v15, v8, v9

    const/16 v15, -0x59

    aput-byte v15, v8, v3

    const/16 v15, -0x3e

    aput-byte v15, v8, v10

    const/16 v15, -0x6e

    aput-byte v15, v8, v11

    const/16 v15, 0x1d

    aput-byte v15, v8, v12

    const/16 v15, -0x55

    aput-byte v15, v8, v13

    const/16 v15, 0x72

    aput-byte v15, v8, v6

    invoke-static {v7, v8}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v5, v7, v0}, Lcom/google/gson/JsonObject;->addProperty(Ljava/lang/String;Ljava/lang/Number;)V

    new-array v7, v4, [B

    const/16 v8, -0x12

    aput-byte v8, v7, v1

    const/16 v8, -0x71

    aput-byte v8, v7, v9

    const/16 v8, -0x3f

    aput-byte v8, v7, v3

    const/16 v8, 0x62

    aput-byte v8, v7, v10

    const/16 v8, 0x16

    aput-byte v8, v7, v11

    const/16 v8, -0x55

    aput-byte v8, v7, v12

    const/16 v8, -0x9

    aput-byte v8, v7, v13

    const/16 v8, 0x45

    aput-byte v8, v7, v6

    new-array v8, v4, [B

    const/16 v15, -0x78

    aput-byte v15, v8, v1

    const/16 v15, -0x1a

    aput-byte v15, v8, v9

    const/16 v15, -0x53

    aput-byte v15, v8, v3

    aput-byte v6, v8, v10

    const/16 v15, 0x58

    aput-byte v15, v8, v11

    const/16 v15, -0x36

    aput-byte v15, v8, v12

    const/16 v15, -0x66

    aput-byte v15, v8, v13

    const/16 v15, 0x20

    aput-byte v15, v8, v6

    invoke-static {v7, v8}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v7

    const/16 v8, 0xc

    new-array v8, v8, [B

    const/16 v15, -0x49

    aput-byte v15, v8, v1

    const/16 v15, -0x13

    aput-byte v15, v8, v9

    aput-byte v10, v8, v3

    const/16 v15, 0x6f

    aput-byte v15, v8, v10

    aput-byte v14, v8, v11

    const/16 v15, -0x4d

    aput-byte v15, v8, v12

    const/16 v15, -0x24

    aput-byte v15, v8, v13

    const/4 v15, -0x3

    aput-byte v15, v8, v6

    const/16 v15, -0x4b

    aput-byte v15, v8, v4

    const/4 v15, -0x8

    const/16 v16, 0x9

    aput-byte v15, v8, v16

    const/16 v15, 0xa

    aput-byte v1, v8, v15

    const/16 v16, 0x78

    const/16 v17, 0xb

    aput-byte v16, v8, v17

    new-array v15, v4, [B

    aput-byte v14, v15, v1

    const/16 v17, -0x74

    aput-byte v17, v15, v9

    const/16 v17, 0x6d

    aput-byte v17, v15, v3

    aput-byte v4, v15, v10

    const/16 v17, -0x50

    aput-byte v17, v15, v11

    const/16 v17, -0x2e

    aput-byte v17, v15, v12

    const/16 v17, -0x4e

    aput-byte v17, v15, v13

    const/16 v17, -0x77

    aput-byte v17, v15, v6

    invoke-static {v8, v15}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v5, v7, v8}, Lcom/google/gson/JsonObject;->addProperty(Ljava/lang/String;Ljava/lang/String;)V

    const/16 v7, 0xc

    new-array v7, v7, [B

    const/16 v8, -0x1f

    aput-byte v8, v7, v1

    const/16 v15, -0x51

    aput-byte v15, v7, v9

    const/16 v15, 0x5e

    aput-byte v15, v7, v3

    const/16 v15, -0xd

    aput-byte v15, v7, v10

    const/16 v15, 0x17

    aput-byte v15, v7, v11

    const/16 v15, -0x6c

    aput-byte v15, v7, v12

    const/16 v15, -0x2c

    aput-byte v15, v7, v13

    const/16 v15, 0x1b

    aput-byte v15, v7, v6

    const/4 v15, -0x3

    aput-byte v15, v7, v4

    const/16 v15, -0x55

    const/16 v17, 0x9

    aput-byte v15, v7, v17

    const/16 v15, 0x65

    const/16 v16, 0xa

    aput-byte v15, v7, v16

    const/16 v15, -0xe

    const/16 v17, 0xb

    aput-byte v15, v7, v17

    new-array v15, v4, [B

    const/16 v17, -0x6f

    aput-byte v17, v15, v1

    const/16 v17, -0x32

    aput-byte v17, v15, v9

    const/16 v17, 0x2c

    aput-byte v17, v15, v3

    const/16 v17, -0x6a

    aput-byte v17, v15, v10

    const/16 v17, 0x79

    aput-byte v17, v15, v11

    const/16 v17, -0x20

    aput-byte v17, v15, v12

    const/16 v18, -0x6e

    aput-byte v18, v15, v13

    const/16 v18, 0x72

    aput-byte v18, v15, v6

    invoke-static {v7, v15}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v5, v7, v0}, Lcom/google/gson/JsonObject;->addProperty(Ljava/lang/String;Ljava/lang/Number;)V

    new-array v7, v11, [B

    const/16 v15, -0x43

    aput-byte v15, v7, v1

    const/16 v15, 0x4d

    aput-byte v15, v7, v9

    const/4 v15, -0x7

    aput-byte v15, v7, v3

    const/16 v15, 0x57

    aput-byte v15, v7, v10

    new-array v15, v4, [B

    const/16 v18, -0x32

    aput-byte v18, v15, v1

    const/16 v18, 0x24

    aput-byte v18, v15, v9

    const/16 v18, -0x7d

    aput-byte v18, v15, v3

    const/16 v19, 0x32

    aput-byte v19, v15, v10

    const/16 v19, 0x30

    aput-byte v19, v15, v11

    const/16 v19, 0x15

    aput-byte v19, v15, v12

    const/16 v20, -0x44

    aput-byte v20, v15, v13

    const/16 v20, 0x2e

    aput-byte v20, v15, v6

    invoke-static {v7, v15}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v5, v7, v0}, Lcom/google/gson/JsonObject;->addProperty(Ljava/lang/String;Ljava/lang/Number;)V

    new-array v7, v11, [B

    const/16 v15, -0x24

    aput-byte v15, v7, v1

    const/16 v15, -0x46

    aput-byte v15, v7, v9

    const/16 v15, -0x3c

    aput-byte v15, v7, v3

    aput-byte v11, v7, v10

    new-array v15, v4, [B

    const/16 v21, -0x58

    aput-byte v21, v15, v1

    aput-byte v14, v15, v9

    const/16 v14, -0x4c

    aput-byte v14, v15, v3

    const/16 v14, 0x61

    aput-byte v14, v15, v10

    const/16 v14, 0x36

    aput-byte v14, v15, v11

    const/16 v14, -0x6f

    aput-byte v14, v15, v12

    const/16 v14, -0x26

    aput-byte v14, v15, v13

    const/16 v14, 0x1f

    aput-byte v14, v15, v6

    invoke-static {v7, v15}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v7

    invoke-static {v9}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v14

    invoke-virtual {v5, v7, v14}, Lcom/google/gson/JsonObject;->addProperty(Ljava/lang/String;Ljava/lang/Number;)V

    const/16 v7, 0x9

    new-array v7, v7, [B

    const/16 v14, 0x18

    aput-byte v14, v7, v1

    const/16 v14, 0x29

    aput-byte v14, v7, v9

    const/16 v14, 0x3e

    aput-byte v14, v7, v3

    const/16 v14, -0x33

    aput-byte v14, v7, v10

    const/16 v14, -0x64

    aput-byte v14, v7, v11

    const/16 v14, -0x72

    aput-byte v14, v7, v12

    const/16 v14, 0x6a

    aput-byte v14, v7, v13

    const/16 v14, 0x44

    aput-byte v14, v7, v6

    const/16 v14, 0x19

    aput-byte v14, v7, v4

    new-array v14, v4, [B

    const/16 v15, 0x7c

    aput-byte v15, v14, v1

    const/16 v15, 0x5c

    aput-byte v15, v14, v9

    const/16 v15, 0x4e

    aput-byte v15, v14, v3

    const/16 v15, -0x5f

    aput-byte v15, v14, v10

    const/16 v15, -0xb

    aput-byte v15, v14, v11

    const/16 v15, -0x13

    aput-byte v15, v14, v12

    const/16 v15, 0xb

    aput-byte v15, v14, v13

    const/16 v15, 0x30

    aput-byte v15, v14, v6

    invoke-static {v7, v14}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v5, v7, v0}, Lcom/google/gson/JsonObject;->addProperty(Ljava/lang/String;Ljava/lang/Number;)V

    new-array v7, v4, [B

    const/16 v14, 0x4f

    aput-byte v14, v7, v1

    const/4 v14, -0x4

    aput-byte v14, v7, v9

    const/16 v14, -0x68

    aput-byte v14, v7, v3

    const/16 v14, 0x47

    aput-byte v14, v7, v10

    const/4 v14, -0x4

    aput-byte v14, v7, v11

    aput-byte v20, v7, v12

    aput-byte v18, v7, v13

    const/16 v14, 0x2c

    aput-byte v14, v7, v6

    new-array v14, v4, [B

    aput-byte v9, v14, v1

    const/16 v15, -0x6d

    aput-byte v15, v14, v9

    const/16 v15, -0x14

    aput-byte v15, v14, v3

    aput-byte v19, v14, v10

    const/16 v15, -0x67

    aput-byte v15, v14, v11

    const/16 v15, 0x5b

    aput-byte v15, v14, v12

    const/16 v15, -0x10

    aput-byte v15, v14, v13

    const/16 v15, 0x49

    aput-byte v15, v14, v6

    invoke-static {v7, v14}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v7

    sget-object v14, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    invoke-virtual {v5, v7, v14}, Lcom/google/gson/JsonObject;->addProperty(Ljava/lang/String;Ljava/lang/Boolean;)V

    new-array v7, v12, [B

    const/16 v14, -0x53

    aput-byte v14, v7, v1

    aput-byte v17, v7, v9

    const/16 v14, 0x1d

    aput-byte v14, v7, v3

    const/16 v14, -0x40

    aput-byte v14, v7, v10

    const/16 v14, 0x50

    aput-byte v14, v7, v11

    new-array v14, v4, [B

    const/16 v15, -0x38

    aput-byte v15, v14, v1

    const/16 v15, -0x6a

    aput-byte v15, v14, v9

    const/16 v15, 0x78

    aput-byte v15, v14, v3

    const/16 v15, -0x52

    aput-byte v15, v14, v10

    const/16 v15, 0x24

    aput-byte v15, v14, v11

    const/16 v15, -0x53

    aput-byte v15, v14, v12

    const/16 v15, 0x53

    aput-byte v15, v14, v13

    const/16 v15, 0x4d

    aput-byte v15, v14, v6

    invoke-static {v7, v14}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v7

    const/16 v14, 0xf

    new-array v14, v14, [B

    const/16 v15, -0x1d

    aput-byte v15, v14, v1

    const/16 v15, -0x18

    aput-byte v15, v14, v9

    const/16 v15, -0x22

    aput-byte v15, v14, v3

    const/16 v15, -0x6b

    aput-byte v15, v14, v10

    const/16 v15, -0x23

    aput-byte v15, v14, v11

    aput-byte v8, v14, v12

    const/16 v15, -0x37

    aput-byte v15, v14, v13

    const/16 v15, 0x5a

    aput-byte v15, v14, v6

    const/16 v15, -0x18

    aput-byte v15, v14, v4

    const/16 v15, -0x35

    const/16 v21, 0x9

    aput-byte v15, v14, v21

    const/16 v15, -0x3a

    const/16 v16, 0xa

    aput-byte v15, v14, v16

    const/16 v15, -0x46

    const/16 v21, 0xb

    aput-byte v15, v14, v21

    const/16 v15, -0x35

    const/16 v21, 0xc

    aput-byte v15, v14, v21

    const/16 v15, 0xd

    aput-byte v8, v14, v15

    const/16 v15, 0xe

    const/16 v21, -0x26

    aput-byte v21, v14, v15

    new-array v15, v4, [B

    const/16 v21, -0x73

    aput-byte v21, v15, v1

    const/16 v21, -0x73

    aput-byte v21, v15, v9

    const/16 v21, -0x57

    aput-byte v21, v15, v3

    const/16 v21, -0x2a

    aput-byte v21, v15, v10

    const/16 v21, -0x51

    aput-byte v21, v15, v11

    const/16 v21, -0x7c

    aput-byte v21, v15, v12

    const/16 v21, -0x58

    aput-byte v21, v15, v13

    aput-byte v20, v15, v6

    invoke-static {v14, v15}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v14

    invoke-virtual {v5, v7, v14}, Lcom/google/gson/JsonObject;->addProperty(Ljava/lang/String;Ljava/lang/String;)V

    const/16 v7, 0xb

    new-array v7, v7, [B

    const/16 v14, 0x2d

    aput-byte v14, v7, v1

    const/16 v14, 0x14

    aput-byte v14, v7, v9

    const/16 v14, 0x35

    aput-byte v14, v7, v3

    const/16 v14, 0x47

    aput-byte v14, v7, v10

    const/16 v14, 0x3c

    aput-byte v14, v7, v11

    const/16 v14, -0x6e

    aput-byte v14, v7, v12

    const/16 v14, 0x3f

    aput-byte v14, v7, v13

    const/16 v14, 0x3f

    aput-byte v14, v7, v6

    const/16 v14, 0x3b

    aput-byte v14, v7, v4

    const/16 v14, 0x14

    const/16 v15, 0x9

    aput-byte v14, v7, v15

    const/16 v14, 0x35

    const/16 v15, 0xa

    aput-byte v14, v7, v15

    new-array v14, v4, [B

    const/16 v15, 0x42

    aput-byte v15, v14, v1

    const/16 v15, 0x64

    aput-byte v15, v14, v9

    const/16 v15, 0x50

    aput-byte v15, v14, v3

    const/16 v15, 0x35

    aput-byte v15, v14, v10

    const/16 v15, 0x5d

    aput-byte v15, v14, v11

    const/16 v15, -0x1a

    aput-byte v15, v14, v12

    const/16 v15, 0x5a

    aput-byte v15, v14, v13

    const/16 v15, 0x6b

    aput-byte v15, v14, v6

    invoke-static {v7, v14}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v7

    invoke-static {v9}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v14

    invoke-virtual {v5, v7, v14}, Lcom/google/gson/JsonObject;->addProperty(Ljava/lang/String;Ljava/lang/Number;)V

    const/16 v7, 0x30

    new-array v7, v7, [B

    const/16 v14, 0x14

    aput-byte v14, v7, v1

    const/16 v14, 0x65

    aput-byte v14, v7, v9

    const/16 v14, 0x3a

    aput-byte v14, v7, v3

    const/16 v14, 0x4e

    aput-byte v14, v7, v10

    const/16 v14, -0x1b

    aput-byte v14, v7, v11

    aput-byte v18, v7, v12

    const/16 v14, -0x46

    aput-byte v14, v7, v13

    const/16 v14, -0x42

    aput-byte v14, v7, v6

    const/16 v14, 0xb

    aput-byte v14, v7, v4

    const/16 v15, 0x66

    const/16 v21, 0x9

    aput-byte v15, v7, v21

    const/16 v15, 0x39

    const/16 v16, 0xa

    aput-byte v15, v7, v16

    const/16 v15, 0x10

    aput-byte v15, v7, v14

    const/16 v14, -0x59

    const/16 v15, 0xc

    aput-byte v14, v7, v15

    const/16 v14, 0xd

    const/16 v15, -0x75

    aput-byte v15, v7, v14

    const/16 v14, 0xe

    const/16 v15, -0x5a

    aput-byte v15, v7, v14

    const/16 v14, 0xf

    aput-byte v8, v7, v14

    const/16 v8, 0x10

    const/16 v14, 0x1d

    aput-byte v14, v7, v8

    const/16 v8, 0x11

    const/16 v14, 0x7f

    aput-byte v14, v7, v8

    const/16 v8, 0x12

    const/16 v14, 0x60

    aput-byte v14, v7, v8

    const/16 v8, 0x13

    const/16 v14, 0x5d

    aput-byte v14, v7, v8

    const/16 v8, 0x14

    const/4 v14, -0x7

    aput-byte v14, v7, v8

    const/16 v8, -0x2c

    aput-byte v8, v7, v19

    const/16 v8, 0x16

    const/16 v14, -0x46

    aput-byte v14, v7, v8

    const/16 v8, 0x17

    const/16 v14, -0xd

    aput-byte v14, v7, v8

    const/16 v8, 0x18

    const/16 v14, 0x53

    aput-byte v14, v7, v8

    const/16 v8, 0x19

    const/16 v14, 0x70

    aput-byte v14, v7, v8

    const/16 v8, 0x1a

    const/16 v14, 0x3e

    aput-byte v14, v7, v8

    const/16 v8, 0x1b

    const/16 v14, 0x57

    aput-byte v14, v7, v8

    const/16 v8, 0x1c

    const/16 v14, -0x47

    aput-byte v14, v7, v8

    const/16 v8, -0x21

    const/16 v14, 0x1d

    aput-byte v8, v7, v14

    const/16 v8, 0x1e

    const/4 v14, -0x4

    aput-byte v14, v7, v8

    const/16 v8, 0x1f

    const/4 v14, -0x3

    aput-byte v14, v7, v8

    const/16 v8, 0x20

    const/16 v14, 0x19

    aput-byte v14, v7, v8

    const/16 v8, 0x21

    const/16 v14, 0x3e

    aput-byte v14, v7, v8

    const/16 v8, 0x22

    const/16 v14, 0x3b

    aput-byte v14, v7, v8

    const/16 v8, 0x23

    const/16 v14, 0x4e

    aput-byte v14, v7, v8

    const/16 v8, 0x24

    const/4 v14, -0x6

    aput-byte v14, v7, v8

    const/16 v8, 0x25

    const/16 v14, -0x2a

    aput-byte v14, v7, v8

    const/16 v8, 0x26

    const/16 v14, -0xc

    aput-byte v14, v7, v8

    const/16 v8, 0x27

    const/16 v14, -0xb

    aput-byte v14, v7, v8

    const/16 v8, 0x28

    const/16 v14, 0x23

    aput-byte v14, v7, v8

    const/16 v8, 0x29

    const/16 v14, 0x63

    aput-byte v14, v7, v8

    const/16 v8, 0x2a

    const/16 v14, 0x2b

    aput-byte v14, v7, v8

    const/16 v8, 0x2b

    const/16 v14, 0x4f

    aput-byte v14, v7, v8

    const/16 v8, 0x2c

    const/16 v14, -0x1d

    aput-byte v14, v7, v8

    const/16 v8, 0x2d

    const/16 v14, -0x24

    aput-byte v14, v7, v8

    const/16 v8, -0x1a

    aput-byte v8, v7, v20

    const/16 v8, 0x2f

    const/16 v14, -0x1b

    aput-byte v14, v7, v8

    new-array v8, v4, [B

    const/16 v14, 0x7c

    aput-byte v14, v8, v1

    const/16 v14, 0x11

    aput-byte v14, v8, v9

    const/16 v14, 0x4e

    aput-byte v14, v8, v3

    const/16 v14, 0x3e

    aput-byte v14, v8, v10

    const/16 v14, -0x6a

    aput-byte v14, v8, v11

    const/16 v14, -0x47

    aput-byte v14, v8, v12

    const/16 v14, -0x6b

    aput-byte v14, v8, v13

    const/16 v14, -0x6f

    aput-byte v14, v8, v6

    invoke-static {v7, v8}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v5}, Lcom/google/gson/JsonElement;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-direct/range {p0 .. p0}, Lcom/github/catvod/spider/appysv2/b/F;->l()Ljava/util/Map;

    move-result-object v8

    invoke-static {v7, v5, v8}, Lcom/github/catvod/spider/appysv2/n/c;->g(Ljava/lang/String;Ljava/lang/String;Ljava/util/Map;)Lcom/github/catvod/spider/appysv2/n/e;

    move-result-object v5

    new-instance v7, Lorg/json/JSONObject;

    invoke-virtual {v5}, Lcom/github/catvod/spider/appysv2/n/e;->a()Ljava/lang/String;

    move-result-object v5

    invoke-direct {v7, v5}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    new-array v5, v11, [B

    const/16 v8, 0x5b

    aput-byte v8, v5, v1

    const/16 v8, -0x9

    aput-byte v8, v5, v9

    aput-byte v17, v5, v3

    const/16 v8, 0x31

    aput-byte v8, v5, v10

    new-array v8, v4, [B

    const/16 v14, 0x38

    aput-byte v14, v8, v1

    const/16 v14, -0x68

    aput-byte v14, v8, v9

    const/16 v14, -0x7c

    aput-byte v14, v8, v3

    const/16 v14, 0x54

    aput-byte v14, v8, v10

    const/16 v14, -0x22

    aput-byte v14, v8, v11

    const/16 v14, 0x1f

    aput-byte v14, v8, v12

    const/16 v14, 0x6a

    aput-byte v14, v8, v13

    const/16 v14, -0x78

    aput-byte v14, v8, v6

    invoke-static {v5, v8}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v7, v5}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;)I

    move-result v5
    :try_end_4e8
    .catch Ljava/lang/Exception; {:try_start_b .. :try_end_4e8} :catch_5aa

    const/16 v8, 0x191

    if-ne v5, v8, :cond_4f5

    move-object/from16 v5, p0

    :try_start_4ee
    invoke-direct {v5, v9}, Lcom/github/catvod/spider/appysv2/b/F;->q(Z)Z

    add-int/lit8 v2, v2, 0x1

    goto/16 :goto_6

    :cond_4f5
    move-object/from16 v5, p0

    new-array v0, v11, [B

    const/16 v2, -0x5c

    aput-byte v2, v0, v1

    const/16 v2, 0x12

    aput-byte v2, v0, v9

    const/16 v2, -0x7c

    aput-byte v2, v0, v3

    const/16 v2, 0x54

    aput-byte v2, v0, v10

    new-array v2, v4, [B

    const/16 v8, -0x40

    aput-byte v8, v2, v1

    const/16 v8, 0x73

    aput-byte v8, v2, v9

    const/16 v8, -0x10

    aput-byte v8, v2, v3

    const/16 v8, 0x35

    aput-byte v8, v2, v10

    const/16 v8, 0x71

    aput-byte v8, v2, v11

    const/16 v8, 0x70

    aput-byte v8, v2, v12

    const/16 v8, 0x22

    aput-byte v8, v2, v13

    aput-byte v18, v2, v6

    invoke-static {v0, v2}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v7, v0}, Lorg/json/JSONObject;->optJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v0

    new-array v2, v11, [B

    const/16 v7, -0x70

    aput-byte v7, v2, v1

    const/16 v7, -0x14

    aput-byte v7, v2, v9

    const/16 v7, -0x4c

    aput-byte v7, v2, v3

    aput-byte v17, v2, v10

    new-array v7, v4, [B

    const/16 v8, -0x27

    aput-byte v8, v7, v1

    const/16 v8, -0x7e

    aput-byte v8, v7, v9

    const/16 v8, -0x2e

    aput-byte v8, v7, v3

    const/16 v8, -0x71

    aput-byte v8, v7, v10

    const/16 v8, 0x3d

    aput-byte v8, v7, v11

    const/16 v8, -0x68

    aput-byte v8, v7, v12

    const/16 v8, 0x7c

    aput-byte v8, v7, v13

    const/16 v8, 0x16

    aput-byte v8, v7, v6

    invoke-static {v2, v7}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Lorg/json/JSONObject;->optJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v0

    new-array v2, v13, [B

    const/16 v7, 0x64

    aput-byte v7, v2, v1

    const/16 v7, 0x7c

    aput-byte v7, v2, v9

    const/16 v7, -0x5c

    aput-byte v7, v2, v3

    aput-byte v13, v2, v10

    const/16 v7, 0x55

    aput-byte v7, v2, v11

    const/16 v7, 0x67

    aput-byte v7, v2, v12

    new-array v7, v4, [B

    const/16 v8, 0x22

    aput-byte v8, v7, v1

    aput-byte v19, v7, v9

    const/16 v8, -0x38

    aput-byte v8, v7, v3

    const/16 v3, 0x63

    aput-byte v3, v7, v10

    const/16 v3, 0x1c

    aput-byte v3, v7, v11

    aput-byte v10, v7, v12

    aput-byte v19, v7, v13

    const/16 v3, 0x19

    aput-byte v3, v7, v6

    invoke-static {v2, v7}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;)I

    move-result v0
    :try_end_5a7
    .catch Ljava/lang/Exception; {:try_start_4ee .. :try_end_5a7} :catch_5a8

    return v0

    :catch_5a8
    move-exception v0

    goto :goto_5ad

    :catch_5aa
    move-exception v0

    move-object/from16 v5, p0

    :goto_5ad
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/16 v3, 0x17

    new-array v3, v3, [B

    fill-array-data v3, :array_5c6

    new-array v4, v4, [B

    fill-array-data v4, :array_5d6

    .line 1
    invoke-static {v3, v4, v2, v0}, Lcom/github/catvod/spider/appysv2/b/y;->b([B[BLjava/lang/StringBuilder;Ljava/lang/Exception;)V

    goto :goto_5c4

    :cond_5c2
    move-object/from16 v5, p0

    :goto_5c4
    return v1

    nop

    :array_5c6
    .array-data 1
        -0x60t
        -0x1at
        -0x58t
        -0x3bt
        0x4ct
        -0x4ct
        -0x22t
        -0x29t
        -0x52t
        -0xft
        -0x66t
        -0x2t
        0x4ft
        -0x42t
        -0x32t
        -0x26t
        -0x5dt
        -0x5dt
        -0x47t
        -0x1bt
        0x51t
        -0x1ft
        -0x76t
    .end array-data

    :array_5d6
    .array-data 1
        -0x39t
        -0x7dt
        -0x24t
        -0x69t
        0x23t
        -0x25t
        -0x56t
        -0x6dt
    .end array-data
.end method

.method private p(Ljava/lang/String;Lcom/github/catvod/spider/appysv2/j/b;Ljava/util/List;)V
    .registers 16
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Lcom/github/catvod/spider/appysv2/j/b;",
            "Ljava/util/List<",
            "Lcom/github/catvod/spider/appysv2/j/b;",
            ">;)V"
        }
    .end annotation

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    const/4 v2, 0x1

    const/4 v3, 0x1

    :goto_c
    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const/16 v5, 0x2d

    new-array v5, v5, [B

    fill-array-data v5, :array_140

    const/16 v6, 0x8

    new-array v7, v6, [B

    fill-array-data v7, :array_15c

    invoke-static {v5, v7}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v5, 0x64

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v5, 0x6

    new-array v7, v5, [B

    fill-array-data v7, :array_164

    new-array v8, v6, [B

    fill-array-data v8, :array_16c

    invoke-static {v7, v8}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v4, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/16 v7, 0x3a

    new-array v7, v7, [B

    fill-array-data v7, :array_174

    new-array v8, v6, [B

    fill-array-data v8, :array_196

    invoke-static {v7, v8}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v4, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p2}, Lcom/github/catvod/spider/appysv2/j/b;->d()Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v4, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v7, 0xa

    new-array v7, v7, [B

    fill-array-data v7, :array_19e

    new-array v8, v6, [B

    fill-array-data v8, :array_1a8

    .line 1
    invoke-static {v7, v8, v4, p1}, Lcom/github/catvod/spider/appysv2/b/v;->c([B[BLjava/lang/StringBuilder;Ljava/lang/String;)V

    const/16 v7, 0x9

    new-array v7, v7, [B

    .line 2
    fill-array-data v7, :array_1b0

    new-array v8, v6, [B

    fill-array-data v8, :array_1ba

    .line 3
    invoke-static {v7, v8, v4}, Lcom/github/catvod/spider/appysv2/b/t;->a([B[BLjava/lang/StringBuilder;)Ljava/lang/String;

    move-result-object v4

    .line 4
    invoke-direct {p0}, Lcom/github/catvod/spider/appysv2/b/F;->l()Ljava/util/Map;

    move-result-object v7

    invoke-static {v4, v7}, Lcom/github/catvod/spider/appysv2/n/c;->m(Ljava/lang/String;Ljava/util/Map;)Ljava/lang/String;

    move-result-object v4

    .line 5
    const-class v7, Lcom/github/catvod/spider/appysv2/j/c;

    .line 6
    invoke-static {v4, v7}, Lcom/github/catvod/spider/appysv2/b/s;->a(Ljava/lang/String;Ljava/lang/Class;)Ljava/lang/Object;

    move-result-object v4

    .line 7
    check-cast v4, Lcom/github/catvod/spider/appysv2/j/c;

    .line 8
    invoke-virtual {v4}, Lcom/github/catvod/spider/appysv2/j/c;->a()Lcom/github/catvod/spider/appysv2/j/a;

    move-result-object v7

    invoke-virtual {v7}, Lcom/github/catvod/spider/appysv2/j/a;->a()Ljava/util/List;

    move-result-object v7

    invoke-interface {v7}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v7

    :cond_95
    :goto_95
    invoke-interface {v7}, Ljava/util/Iterator;->hasNext()Z

    move-result v8

    const/4 v9, 0x2

    if-eqz v8, :cond_c7

    invoke-interface {v7}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v8

    check-cast v8, Lcom/github/catvod/spider/appysv2/j/b;

    invoke-virtual {v8}, Lcom/github/catvod/spider/appysv2/j/b;->a()I

    move-result v10

    if-nez v10, :cond_ac

    invoke-virtual {v0, v8}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_95

    :cond_ac
    invoke-virtual {v8}, Lcom/github/catvod/spider/appysv2/j/b;->a()I

    move-result v10

    if-ne v10, v9, :cond_95

    invoke-virtual {p2}, Lcom/github/catvod/spider/appysv2/j/b;->e()Ljava/lang/String;

    move-result-object v9

    invoke-static {v9}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v9

    if-nez v9, :cond_c3

    invoke-virtual {p2}, Lcom/github/catvod/spider/appysv2/j/b;->e()Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v8, v9}, Lcom/github/catvod/spider/appysv2/j/b;->j(Ljava/lang/String;)V

    :cond_c3
    invoke-interface {v1, v8}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    goto :goto_95

    :cond_c7
    invoke-interface {p3, v1}, Ljava/util/List;->addAll(Ljava/util/Collection;)Z

    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    :try_start_cf
    invoke-virtual {v4}, Lcom/github/catvod/spider/appysv2/j/c;->a()Lcom/github/catvod/spider/appysv2/j/a;

    move-result-object v7

    invoke-virtual {v7}, Lcom/github/catvod/spider/appysv2/j/a;->a()Ljava/util/List;

    move-result-object v7

    invoke-interface {v7}, Ljava/util/List;->isEmpty()Z

    move-result v7

    if-nez v7, :cond_12a

    invoke-virtual {v4}, Lcom/github/catvod/spider/appysv2/j/c;->a()Lcom/github/catvod/spider/appysv2/j/a;

    move-result-object v4

    invoke-virtual {v4}, Lcom/github/catvod/spider/appysv2/j/a;->c()Ljava/lang/String;

    move-result-object v4

    new-array v7, v9, [B

    const/16 v8, -0x55

    const/4 v10, 0x0

    aput-byte v8, v7, v10

    const/16 v8, -0x7c

    aput-byte v8, v7, v2

    new-array v6, v6, [B

    const/16 v8, -0x7a

    aput-byte v8, v6, v10

    const/16 v11, -0x4b

    aput-byte v11, v6, v2

    const/16 v11, 0x57

    aput-byte v11, v6, v9

    const/4 v9, 0x3

    aput-byte v8, v6, v9

    const/4 v8, 0x4

    const/16 v9, -0x72

    aput-byte v9, v6, v8

    const/4 v8, 0x5

    const/16 v9, -0x25

    aput-byte v9, v6, v8

    const/16 v8, 0x15

    aput-byte v8, v6, v5

    const/4 v5, 0x7

    const/16 v8, -0x9

    aput-byte v8, v6, v5

    invoke-static {v7, v6}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v5

    if-eq v4, v5, :cond_122

    if-eqz v4, :cond_123

    invoke-virtual {v4, v5}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v4
    :try_end_120
    .catch Ljava/lang/Exception; {:try_start_cf .. :try_end_120} :catch_12a

    if-eqz v4, :cond_123

    :cond_122
    const/4 v10, 0x1

    :cond_123
    if-eqz v10, :cond_126

    goto :goto_12a

    :cond_126
    add-int/lit8 v3, v3, 0x1

    goto/16 :goto_c

    :catch_12a
    :cond_12a
    :goto_12a
    invoke-virtual {v0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object p2

    :goto_12e
    invoke-interface {p2}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_13e

    invoke-interface {p2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/github/catvod/spider/appysv2/j/b;

    invoke-direct {p0, p1, v0, p3}, Lcom/github/catvod/spider/appysv2/b/F;->p(Ljava/lang/String;Lcom/github/catvod/spider/appysv2/j/b;Ljava/util/List;)V

    goto :goto_12e

    :cond_13e
    return-void

    nop

    :array_140
    .array-data 1
        -0x55t
        -0x64t
        -0x62t
        0x41t
        -0x25t
        0x2ft
        -0x26t
        0x20t
        -0x4ct
        -0x61t
        -0x63t
        0x1ft
        -0x67t
        0x27t
        -0x3at
        0x7ft
        -0x5et
        -0x7at
        -0x3ct
        0x52t
        -0x39t
        0x78t
        -0x26t
        0x6dt
        -0x14t
        -0x77t
        -0x66t
        0x58t
        -0x79t
        0x66t
        -0x63t
        0x6et
        -0x4ft
        -0x73t
        -0x3bt
        0x56t
        -0x33t
        0x61t
        -0x36t
        0x63t
        -0x56t
        -0x7bt
        -0x7dt
        0x45t
        -0x6bt
    .end array-data

    nop

    :array_15c
    .array-data 1
        -0x3dt
        -0x18t
        -0x16t
        0x31t
        -0x58t
        0x15t
        -0xbt
        0xft
    .end array-data

    :array_164
    .array-data 1
        0x59t
        0xft
        0x68t
        -0x27t
        -0x12t
        -0x4bt
    .end array-data

    nop

    :array_16c
    .array-data 1
        0x7ft
        0x5ft
        0x9t
        -0x42t
        -0x75t
        -0x78t
        0x30t
        0x40t
    .end array-data

    :array_174
    .array-data 1
        -0x61t
        0x65t
        -0x75t
        0x63t
        -0x73t
        -0x17t
        0x33t
        -0x16t
        -0x2at
        0x79t
        -0x76t
        0x7et
        -0x75t
        -0x6at
        0x7at
        -0xft
        -0x21t
        0x62t
        -0x7et
        0x7et
        -0x5at
        -0x46t
        0x62t
        -0x5ft
        -0x24t
        0x2dt
        -0x7ft
        0x69t
        -0x63t
        -0x4ft
        0x71t
        -0x78t
        -0x30t
        0x79t
        -0x75t
        0x78t
        -0x73t
        -0x43t
        0x6ct
        -0x5et
        -0x7ct
        0x6at
        -0x63t
        0x78t
        -0x21t
        -0x5ct
        0x62t
        -0x42t
        -0x24t
        0x65t
        -0x66t
        0x5dt
        -0x70t
        -0x48t
        0x66t
        -0x7bt
        -0x23t
        0x36t
    .end array-data

    nop

    :array_196
    .array-data 1
        -0x47t
        0xbt
        -0x12t
        0x1bt
        -0x7t
        -0x2ct
        0x3t
        -0x34t
    .end array-data

    :array_19e
    .array-data 1
        -0x21t
        0x6bt
        0x75t
        -0x4et
        0x20t
        -0x34t
        -0x47t
        0x5t
        -0x80t
        0x25t
    .end array-data

    nop

    :array_1a8
    .array-data 1
        -0x7t
        0x18t
        0x1dt
        -0x2dt
        0x52t
        -0x57t
        -0xet
        0x60t
    .end array-data

    :array_1b0
    .array-data 1
        -0x3at
        0x2dt
        -0x45t
        -0x5bt
        0x70t
        0x7bt
        0x74t
        0x4ft
        -0x7ct
    .end array-data

    nop

    :array_1ba
    .array-data 1
        -0x20t
        0x7et
        -0x2dt
        -0x3ct
        0x2t
        0x1et
        0x24t
        0x38t
    .end array-data
.end method

.method private q(Z)Z
    .registers 28

    move-object/from16 v1, p0

    const/16 v2, 0x8

    const/4 v3, 0x0

    :try_start_5
    sget-object v0, Lcom/github/catvod/spider/appysv2/b/F;->f:Ljava/lang/String;

    invoke-static {v0}, Lcom/github/catvod/spider/appysv2/p/C;->q(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-static {v4}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v5

    if-eqz v5, :cond_12

    return v3

    :cond_12
    new-instance v5, Lorg/json/JSONObject;

    invoke-direct {v5, v4}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    new-array v4, v2, [B

    const/16 v6, -0xc

    aput-byte v6, v4, v3

    const/16 v6, 0x7f

    const/4 v7, 0x1

    aput-byte v6, v4, v7

    const/16 v6, -0x73

    const/4 v8, 0x2

    aput-byte v6, v4, v8

    const/16 v9, 0x3e

    const/4 v10, 0x3

    aput-byte v9, v4, v10

    const/4 v9, 0x4

    aput-byte v6, v4, v9

    const/16 v6, -0x23

    const/4 v11, 0x5

    aput-byte v6, v4, v11

    const/16 v6, -0x16

    const/4 v12, 0x6

    aput-byte v6, v4, v12

    const/16 v6, -0x43

    const/4 v13, 0x7

    aput-byte v6, v4, v13

    new-array v6, v2, [B

    const/16 v14, -0x7f

    aput-byte v14, v6, v3

    const/16 v14, 0xc

    aput-byte v14, v6, v7

    const/16 v15, -0x18

    aput-byte v15, v6, v8

    const/16 v15, 0x4c

    aput-byte v15, v6, v10

    const/16 v16, -0x1d

    aput-byte v16, v6, v9

    const/16 v16, -0x44

    aput-byte v16, v6, v11

    const/16 v16, -0x79

    aput-byte v16, v6, v12

    const/16 v16, -0x28

    aput-byte v16, v6, v13

    invoke-static {v4, v6}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v5, v4}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    new-array v6, v2, [B

    const/16 v16, -0xd

    aput-byte v16, v6, v3

    const/16 v16, 0x58

    aput-byte v16, v6, v7

    const/16 v16, -0x12

    aput-byte v16, v6, v8

    const/16 v16, 0x72

    aput-byte v16, v6, v10

    const/16 v16, 0x37

    aput-byte v16, v6, v9

    const/16 v16, 0x59

    aput-byte v16, v6, v11

    const/16 v17, -0x3b

    aput-byte v17, v6, v12

    const/16 v17, 0x64

    aput-byte v17, v6, v13

    new-array v15, v2, [B

    const/16 v18, -0x7d

    aput-byte v18, v15, v3

    const/16 v19, 0x39

    aput-byte v19, v15, v7

    const/16 v19, -0x63

    aput-byte v19, v15, v8

    aput-byte v7, v15, v10

    const/16 v20, 0x40

    aput-byte v20, v15, v9

    const/16 v20, 0x36

    aput-byte v20, v15, v11

    const/16 v20, -0x49

    aput-byte v20, v15, v12

    aput-byte v3, v15, v13

    invoke-static {v6, v15}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v5, v6}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    new-array v14, v14, [B

    const/16 v15, 0x2b

    aput-byte v15, v14, v3

    const/16 v20, -0x80

    aput-byte v20, v14, v7

    const/16 v20, -0x53

    aput-byte v20, v14, v8

    const/16 v20, 0x5c

    aput-byte v20, v14, v10

    const/16 v20, 0x22

    aput-byte v20, v14, v9

    const/16 v20, -0x6e

    aput-byte v20, v14, v11

    const/16 v20, 0x48

    aput-byte v20, v14, v12

    const/16 v20, 0x5b

    aput-byte v20, v14, v13

    const/16 v20, 0x25

    aput-byte v20, v14, v2

    const/16 v20, -0x78

    const/16 v21, 0x9

    aput-byte v20, v14, v21

    const/16 v20, 0xa

    const/16 v21, -0x55

    aput-byte v21, v14, v20

    const/16 v20, 0x57

    const/16 v21, 0xb

    aput-byte v20, v14, v21

    new-array v15, v2, [B

    const/16 v22, 0x4a

    aput-byte v22, v15, v3

    const/16 v23, -0x1d

    aput-byte v23, v15, v7

    const/16 v23, -0x32

    aput-byte v23, v15, v8

    const/16 v24, 0x39

    aput-byte v24, v15, v10

    const/16 v24, 0x51

    aput-byte v24, v15, v9

    const/16 v24, -0x1f

    aput-byte v24, v15, v11

    const/16 v24, 0x17

    aput-byte v24, v15, v12

    const/16 v24, 0x2f

    aput-byte v24, v15, v13

    invoke-static {v14, v15}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v13

    invoke-virtual {v5, v13}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v13

    iput-object v13, v1, Lcom/github/catvod/spider/appysv2/b/F;->a:Ljava/lang/String;

    invoke-static {v13}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v13

    if-nez v13, :cond_11d

    if-nez p1, :cond_11d

    return v7

    :cond_11d
    new-instance v13, Lcom/google/gson/JsonObject;

    invoke-direct {v13}, Lcom/google/gson/JsonObject;-><init>()V

    invoke-static {v4}, Lcom/github/catvod/spider/appysv2/p/C;->m(Ljava/lang/String;)Z

    move-result v14

    if-eqz v14, :cond_1eb

    new-array v14, v9, [B

    const/16 v15, 0x12

    aput-byte v15, v14, v3

    const/16 v15, -0x40

    aput-byte v15, v14, v7

    const/16 v15, 0x79

    aput-byte v15, v14, v8

    const/16 v15, -0x4a

    aput-byte v15, v14, v10

    new-array v15, v2, [B

    const/16 v24, 0x7f

    aput-byte v24, v15, v3

    const/16 v24, -0x5f

    aput-byte v24, v15, v7

    const/16 v24, 0x10

    aput-byte v24, v15, v8

    const/16 v24, -0x26

    aput-byte v24, v15, v10

    const/16 v24, -0x1a

    aput-byte v24, v15, v9

    const/16 v24, -0x5a

    aput-byte v24, v15, v11

    const/16 v24, -0x4

    aput-byte v24, v15, v12

    const/16 v24, -0x46

    const/16 v25, 0x7

    aput-byte v24, v15, v25

    invoke-static {v14, v15}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v14

    invoke-virtual {v13, v14, v4}, Lcom/google/gson/JsonObject;->addProperty(Ljava/lang/String;Ljava/lang/String;)V

    new-array v4, v2, [B

    const/16 v14, 0x1c

    aput-byte v14, v4, v3

    const/16 v14, 0x2b

    aput-byte v14, v4, v7

    const/16 v14, -0x12

    aput-byte v14, v4, v8

    const/16 v14, -0x36

    aput-byte v14, v4, v10

    const/16 v14, 0x21

    aput-byte v14, v4, v9

    aput-byte v22, v4, v11

    const/16 v14, -0x26

    aput-byte v14, v4, v12

    const/16 v14, 0x2d

    const/4 v15, 0x7

    aput-byte v14, v4, v15

    new-array v14, v2, [B

    const/16 v15, 0x6c

    aput-byte v15, v14, v3

    aput-byte v22, v14, v7

    aput-byte v19, v14, v8

    const/16 v15, -0x47

    aput-byte v15, v14, v10

    const/16 v15, 0x56

    aput-byte v15, v14, v9

    const/16 v15, 0x25

    aput-byte v15, v14, v11

    const/16 v15, -0x58

    aput-byte v15, v14, v12

    const/16 v15, 0x49

    const/16 v19, 0x7

    aput-byte v15, v14, v19

    invoke-static {v4, v14}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v13, v4, v6}, Lcom/google/gson/JsonObject;->addProperty(Ljava/lang/String;Ljava/lang/String;)V

    new-array v4, v9, [B

    const/16 v6, 0x61

    aput-byte v6, v4, v3

    const/16 v6, -0x16

    aput-byte v6, v4, v7

    const/16 v6, 0x2f

    aput-byte v6, v4, v8

    const/4 v6, -0x3

    aput-byte v6, v4, v10

    new-array v6, v2, [B

    const/16 v14, 0x15

    aput-byte v14, v6, v3

    const/16 v14, -0x6d

    aput-byte v14, v6, v7

    const/16 v14, 0x5f

    aput-byte v14, v6, v8

    const/16 v14, -0x68

    aput-byte v14, v6, v10

    const/4 v14, -0x7

    aput-byte v14, v6, v9

    const/16 v14, -0x4d

    aput-byte v14, v6, v11

    aput-byte v2, v6, v12

    const/16 v14, -0x67

    const/4 v15, 0x7

    aput-byte v14, v6, v15

    invoke-static {v4, v6}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-static {v8}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v6

    invoke-virtual {v13, v4, v6}, Lcom/google/gson/JsonObject;->addProperty(Ljava/lang/String;Ljava/lang/Number;)V

    goto/16 :goto_2c9

    :cond_1eb
    new-array v14, v2, [B

    const/16 v15, 0x7b

    aput-byte v15, v14, v3

    const/16 v15, 0x42

    aput-byte v15, v14, v7

    const/16 v15, -0xa

    aput-byte v15, v14, v8

    const/16 v15, 0x4c

    aput-byte v15, v14, v10

    aput-byte v18, v14, v9

    aput-byte v9, v14, v11

    const/16 v15, 0x56

    aput-byte v15, v14, v12

    const/16 v15, 0x70

    const/16 v22, 0x7

    aput-byte v15, v14, v22

    new-array v15, v2, [B

    aput-byte v21, v15, v3

    const/16 v22, 0x23

    aput-byte v22, v15, v7

    const/16 v22, -0x7b

    aput-byte v22, v15, v8

    const/16 v22, 0x3f

    aput-byte v22, v15, v10

    const/16 v22, -0xd

    aput-byte v22, v15, v9

    const/16 v22, 0x6b

    aput-byte v22, v15, v11

    const/16 v22, 0x24

    aput-byte v22, v15, v12

    const/16 v22, 0x7

    aput-byte v9, v15, v22

    invoke-static {v14, v15}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v14

    invoke-virtual {v13, v14, v4}, Lcom/google/gson/JsonObject;->addProperty(Ljava/lang/String;Ljava/lang/String;)V

    new-array v4, v2, [B

    const/16 v14, -0x13

    aput-byte v14, v4, v3

    const/16 v14, -0x72

    aput-byte v14, v4, v7

    const/16 v14, -0x77

    aput-byte v14, v4, v8

    const/16 v14, -0x5d

    aput-byte v14, v4, v10

    const/16 v14, -0x58

    aput-byte v14, v4, v9

    const/16 v14, -0x39

    aput-byte v14, v4, v11

    const/16 v14, -0x21

    aput-byte v14, v4, v12

    const/16 v14, -0x4c

    const/4 v15, 0x7

    aput-byte v14, v4, v15

    new-array v14, v2, [B

    aput-byte v19, v14, v3

    const/16 v15, -0x11

    aput-byte v15, v14, v7

    const/4 v15, -0x6

    aput-byte v15, v14, v8

    const/16 v15, -0x30

    aput-byte v15, v14, v10

    const/16 v15, -0x21

    aput-byte v15, v14, v9

    const/16 v15, -0x58

    aput-byte v15, v14, v11

    const/16 v15, -0x53

    aput-byte v15, v14, v12

    const/16 v15, -0x30

    const/16 v19, 0x7

    aput-byte v15, v14, v19

    invoke-static {v4, v14}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v13, v4, v6}, Lcom/google/gson/JsonObject;->addProperty(Ljava/lang/String;Ljava/lang/String;)V

    new-array v4, v2, [B

    const/16 v6, 0x5a

    aput-byte v6, v4, v3

    const/4 v6, -0x5

    aput-byte v6, v4, v7

    const/16 v6, 0x74

    aput-byte v6, v4, v8

    const/16 v6, -0x3f

    aput-byte v6, v4, v10

    const/16 v6, 0x42

    aput-byte v6, v4, v9

    aput-byte v23, v4, v11

    const/16 v6, -0x7e

    aput-byte v6, v4, v12

    const/16 v6, -0x41

    const/4 v14, 0x7

    aput-byte v6, v4, v14

    new-array v6, v2, [B

    const/16 v14, 0x28

    aput-byte v14, v6, v3

    const/16 v14, -0x62

    aput-byte v14, v6, v7

    const/16 v14, 0x19

    aput-byte v14, v6, v8

    const/16 v14, -0x5c

    aput-byte v14, v6, v10

    const/16 v14, 0x2f

    aput-byte v14, v6, v9

    const/16 v14, -0x54

    aput-byte v14, v6, v11

    const/16 v14, -0x19

    aput-byte v14, v6, v12

    const/16 v14, -0x33

    const/4 v15, 0x7

    aput-byte v14, v6, v15

    invoke-static {v4, v6}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v4

    sget-object v6, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    invoke-virtual {v13, v4, v6}, Lcom/google/gson/JsonObject;->addProperty(Ljava/lang/String;Ljava/lang/Boolean;)V

    :goto_2c9
    invoke-direct/range {p0 .. p0}, Lcom/github/catvod/spider/appysv2/b/F;->l()Ljava/util/Map;

    move-result-object v4

    new-array v6, v2, [B

    const/16 v14, -0x2c

    aput-byte v14, v6, v3

    const/16 v14, 0x2c

    aput-byte v14, v6, v7

    const/16 v14, -0x1e

    aput-byte v14, v6, v8

    aput-byte v16, v6, v10

    const/16 v14, 0x53

    aput-byte v14, v6, v9

    const/16 v14, -0x34

    aput-byte v14, v6, v11

    const/16 v14, 0x66

    aput-byte v14, v6, v12

    const/16 v14, 0x76

    const/4 v15, 0x7

    aput-byte v14, v6, v15

    new-array v14, v2, [B

    const/16 v15, -0x5c

    aput-byte v15, v14, v3

    const/16 v15, 0x40

    aput-byte v15, v14, v7

    aput-byte v18, v14, v8

    const/16 v15, 0x2d

    aput-byte v15, v14, v10

    const/16 v15, 0x35

    aput-byte v15, v14, v9

    const/16 v15, -0x5d

    aput-byte v15, v14, v11

    const/16 v15, 0x14

    aput-byte v15, v14, v12

    const/16 v15, 0x1b

    const/16 v18, 0x7

    aput-byte v15, v14, v18

    invoke-static {v6, v14}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v6

    new-array v14, v10, [B

    const/16 v15, 0x6f

    aput-byte v15, v14, v3

    const/16 v15, -0x57

    aput-byte v15, v14, v7

    const/16 v15, -0x47

    aput-byte v15, v14, v8

    new-array v15, v2, [B

    const/16 v18, 0x18

    aput-byte v18, v15, v3

    const/16 v18, -0x34

    aput-byte v18, v15, v7

    const/16 v18, -0x25

    aput-byte v18, v15, v8

    const/16 v18, 0x51

    aput-byte v18, v15, v10

    const/16 v18, -0x7

    aput-byte v18, v15, v9

    const/16 v18, 0x5c

    aput-byte v18, v15, v11

    const/16 v18, -0x79

    aput-byte v18, v15, v12

    const/16 v18, -0x6e

    const/16 v19, 0x7

    aput-byte v18, v15, v19

    invoke-static {v14, v15}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v14

    move-object v15, v4

    check-cast v15, Ljava/util/HashMap;

    invoke-virtual {v15, v6, v14}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v6, Lcom/github/catvod/spider/appysv2/b/F;->d:Ljava/lang/String;

    invoke-virtual {v13}, Lcom/google/gson/JsonElement;->toString()Ljava/lang/String;

    move-result-object v13

    invoke-static {v6, v13, v4}, Lcom/github/catvod/spider/appysv2/n/c;->g(Ljava/lang/String;Ljava/lang/String;Ljava/util/Map;)Lcom/github/catvod/spider/appysv2/n/e;

    move-result-object v4

    new-instance v6, Lorg/json/JSONObject;

    invoke-virtual {v4}, Lcom/github/catvod/spider/appysv2/n/e;->a()Ljava/lang/String;

    move-result-object v4

    invoke-direct {v6, v4}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    new-array v4, v9, [B

    const/16 v13, 0x15

    aput-byte v13, v4, v3

    const/16 v13, 0x10

    aput-byte v13, v4, v7

    const/16 v13, -0x68

    aput-byte v13, v4, v8

    const/16 v13, -0x4c

    aput-byte v13, v4, v10

    new-array v13, v2, [B

    const/16 v14, 0x76

    aput-byte v14, v13, v3

    const/16 v14, 0x7f

    aput-byte v14, v13, v7

    const/4 v14, -0x4

    aput-byte v14, v13, v8

    const/16 v14, -0x2f

    aput-byte v14, v13, v10

    const/16 v14, -0x13

    aput-byte v14, v13, v9

    const/16 v14, 0x11

    aput-byte v14, v13, v11

    const/16 v14, 0x69

    aput-byte v14, v13, v12

    const/16 v14, 0x7b

    const/4 v15, 0x7

    aput-byte v14, v13, v15

    invoke-static {v4, v13}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v6, v4}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;)I

    move-result v4

    const/16 v13, 0xc8

    if-ne v4, v13, :cond_487

    new-array v4, v9, [B

    const/16 v13, -0x25

    aput-byte v13, v4, v3

    const/16 v13, -0x3f

    aput-byte v13, v4, v7

    const/16 v13, 0x45

    aput-byte v13, v4, v8

    const/16 v13, -0x73

    aput-byte v13, v4, v10

    new-array v13, v2, [B

    const/16 v14, -0x41

    aput-byte v14, v13, v3

    const/16 v14, -0x60

    aput-byte v14, v13, v7

    const/16 v14, 0x31

    aput-byte v14, v13, v8

    const/16 v14, -0x14

    aput-byte v14, v13, v10

    const/16 v14, 0x78

    aput-byte v14, v13, v9

    const/16 v14, 0x52

    aput-byte v14, v13, v11

    const/16 v14, -0xa

    aput-byte v14, v13, v12

    const/4 v14, 0x7

    aput-byte v23, v13, v14

    invoke-static {v4, v13}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v6, v4}, Lorg/json/JSONObject;->optJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v4

    new-array v6, v11, [B

    aput-byte v12, v6, v3

    const/16 v13, -0x5c

    aput-byte v13, v6, v7

    const/16 v13, -0x7a

    aput-byte v13, v6, v8

    aput-byte v3, v6, v10

    const/16 v13, -0x4c

    aput-byte v13, v6, v9

    new-array v13, v2, [B

    const/16 v14, 0x72

    aput-byte v14, v13, v3

    const/16 v14, -0x35

    aput-byte v14, v13, v7

    const/16 v14, -0x13

    aput-byte v14, v13, v8

    const/16 v14, 0x65

    aput-byte v14, v13, v10

    const/16 v14, -0x26

    aput-byte v14, v13, v9

    const/16 v14, 0x4c

    aput-byte v14, v13, v11

    const/16 v14, -0x7b

    aput-byte v14, v13, v12

    const/4 v14, 0x7

    aput-byte v21, v13, v14

    invoke-static {v6, v13}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v4, v6}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    iput-object v4, v1, Lcom/github/catvod/spider/appysv2/b/F;->a:Ljava/lang/String;

    const/16 v4, 0xc

    new-array v4, v4, [B

    const/16 v6, 0x22

    aput-byte v6, v4, v3

    const/16 v6, -0x7b

    aput-byte v6, v4, v7

    const/16 v6, -0x3c

    aput-byte v6, v4, v8

    const/16 v6, -0x80

    aput-byte v6, v4, v10

    const/16 v6, -0x76

    aput-byte v6, v4, v9

    const/16 v6, 0x10

    aput-byte v6, v4, v11

    const/16 v6, -0x37

    aput-byte v6, v4, v12

    const/16 v6, 0x17

    const/4 v13, 0x7

    aput-byte v6, v4, v13

    const/16 v6, 0x2c

    aput-byte v6, v4, v2

    const/16 v6, 0x9

    const/16 v13, -0x73

    aput-byte v13, v4, v6

    const/16 v6, 0xa

    const/16 v13, -0x3e

    aput-byte v13, v4, v6

    const/16 v6, -0x75

    aput-byte v6, v4, v21

    new-array v6, v2, [B

    const/16 v13, 0x43

    aput-byte v13, v6, v3

    const/16 v13, -0x1a

    aput-byte v13, v6, v7

    const/16 v13, -0x59

    aput-byte v13, v6, v8

    const/16 v8, -0x1b

    aput-byte v8, v6, v10

    const/4 v8, -0x7

    aput-byte v8, v6, v9

    const/16 v8, 0x63

    aput-byte v8, v6, v11

    const/16 v8, -0x6a

    aput-byte v8, v6, v12

    const/16 v8, 0x63

    const/4 v9, 0x7

    aput-byte v8, v6, v9

    invoke-static {v4, v6}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v4

    iget-object v6, v1, Lcom/github/catvod/spider/appysv2/b/F;->a:Ljava/lang/String;

    invoke-virtual {v5, v4, v6}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    invoke-virtual {v5}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-static {v0, v4}, Lcom/github/catvod/spider/appysv2/p/C;->u(Ljava/lang/String;Ljava/lang/String;)V

    return v7

    :cond_487
    invoke-static {v0}, Lcom/github/catvod/spider/appysv2/p/C;->c(Ljava/lang/String;)V

    const/4 v0, 0x7

    new-array v0, v0, [B

    const/16 v4, 0x41

    aput-byte v4, v0, v3

    const/16 v4, 0x4e

    aput-byte v4, v0, v7

    const/16 v4, 0x3a

    aput-byte v4, v0, v8

    const/16 v4, -0x6d

    aput-byte v4, v0, v10

    const/16 v4, -0x44

    aput-byte v4, v0, v9

    aput-byte v16, v0, v11

    aput-byte v10, v0, v12

    new-array v4, v2, [B

    const/16 v5, 0x2c

    aput-byte v5, v4, v3

    const/16 v5, 0x2b

    aput-byte v5, v4, v7

    const/16 v5, 0x49

    aput-byte v5, v4, v8

    const/16 v5, -0x20

    aput-byte v5, v4, v10

    const/16 v5, -0x23

    aput-byte v5, v4, v9

    const/16 v5, 0x3e

    aput-byte v5, v4, v11

    const/16 v5, 0x66

    aput-byte v5, v4, v12

    const/16 v5, 0x2e

    const/4 v13, 0x7

    aput-byte v5, v4, v13

    invoke-static {v0, v4}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v6, v0}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lcom/github/catvod/spider/appysv2/p/j;->b(Ljava/lang/String;)V

    new-instance v0, Ljava/lang/Exception;

    new-array v4, v13, [B

    const/16 v5, 0x71

    aput-byte v5, v4, v3

    const/16 v5, -0x71

    aput-byte v5, v4, v7

    const/16 v5, -0x61

    aput-byte v5, v4, v8

    const/16 v5, -0x2f

    aput-byte v5, v4, v10

    aput-byte v2, v4, v9

    aput-byte v9, v4, v11

    const/16 v5, -0x2e

    aput-byte v5, v4, v12

    new-array v5, v2, [B

    const/16 v13, 0x1c

    aput-byte v13, v5, v3

    const/16 v13, -0x16

    aput-byte v13, v5, v7

    const/16 v7, -0x14

    aput-byte v7, v5, v8

    const/16 v7, -0x5e

    aput-byte v7, v5, v10

    const/16 v7, 0x69

    aput-byte v7, v5, v9

    const/16 v7, 0x63

    aput-byte v7, v5, v11

    const/16 v7, -0x49

    aput-byte v7, v5, v12

    const/16 v7, -0x50

    const/4 v8, 0x7

    aput-byte v7, v5, v8

    invoke-static {v4, v5}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v6, v4}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-direct {v0, v4}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V

    throw v0
    :try_end_51e
    .catch Ljava/lang/Exception; {:try_start_5 .. :try_end_51e} :catch_51e

    :catch_51e
    move-exception v0

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const/16 v5, 0x9

    new-array v5, v5, [B

    fill-array-data v5, :array_534

    new-array v2, v2, [B

    fill-array-data v2, :array_53e

    .line 1
    invoke-static {v5, v2, v4, v0}, Lcom/github/catvod/spider/appysv2/b/y;->b([B[BLjava/lang/StringBuilder;Ljava/lang/Exception;)V

    return v3

    :array_534
    .array-data 1
        -0x26t
        -0x7ct
        -0x7bt
        0x48t
        0x54t
        -0x18t
        0x66t
        0x7dt
        -0x6at
    .end array-data

    nop

    :array_53e
    .array-data 1
        -0x4at
        -0x15t
        -0x1et
        0x21t
        0x3at
        -0x38t
        0x3t
        0x47t
    .end array-data
.end method


# virtual methods
.method public final n(Ljava/lang/String;Ljava/lang/String;)Lcom/github/catvod/spider/appysv2/c/k;
    .registers 15

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    new-instance v1, Lcom/github/catvod/spider/appysv2/j/b;

    invoke-direct {v1}, Lcom/github/catvod/spider/appysv2/j/b;-><init>()V

    invoke-direct {p0, p1, v1, v0}, Lcom/github/catvod/spider/appysv2/b/F;->p(Ljava/lang/String;Lcom/github/catvod/spider/appysv2/j/b;Ljava/util/List;)V

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v1

    const/4 v2, 0x1

    if-ge v1, v2, :cond_19

    invoke-static {}, Lcom/github/catvod/spider/appysv2/p/C;->e()Lcom/github/catvod/spider/appysv2/c/k;

    move-result-object p1

    return-object p1

    :cond_19
    const/16 v1, 0x9

    new-array v3, v1, [B

    fill-array-data v3, :array_1f2

    const/16 v4, 0x8

    new-array v5, v4, [B

    fill-array-data v5, :array_1fc

    invoke-static {v3, v5}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v3

    invoke-static {v3}, Ljava/util/Collections;->singletonList(Ljava/lang/Object;)Ljava/util/List;

    move-result-object v3

    new-instance v5, Ljava/util/ArrayList;

    invoke-direct {v5}, Ljava/util/ArrayList;-><init>()V

    new-instance v6, Ljava/util/ArrayList;

    invoke-direct {v6}, Ljava/util/ArrayList;-><init>()V

    invoke-virtual {v0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_3d
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v7

    const-string v8, ""

    const/4 v9, 0x0

    if-eqz v7, :cond_176

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Lcom/github/catvod/spider/appysv2/j/b;

    invoke-virtual {v7}, Lcom/github/catvod/spider/appysv2/j/b;->f()Ljava/lang/String;

    move-result-object v10

    invoke-static {v10}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v10

    if-eqz v10, :cond_57

    goto :goto_87

    :cond_57
    new-instance v8, Ljava/lang/StringBuilder;

    invoke-direct {v8}, Ljava/lang/StringBuilder;-><init>()V

    new-array v10, v2, [B

    const/4 v11, -0x5

    aput-byte v11, v10, v9

    new-array v11, v4, [B

    fill-array-data v11, :array_204

    invoke-static {v10, v11}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v8, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v7}, Lcom/github/catvod/spider/appysv2/j/b;->f()Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v10}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v8, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    new-array v10, v2, [B

    const/16 v11, -0x66

    aput-byte v11, v10, v9

    new-array v11, v4, [B

    fill-array-data v11, :array_20c

    .line 1
    invoke-static {v10, v11, v8}, Lcom/github/catvod/spider/appysv2/b/t;->a([B[BLjava/lang/StringBuilder;)Ljava/lang/String;

    move-result-object v8

    .line 2
    :goto_87
    invoke-static {v8}, Lcom/github/catvod/spider/appysv2/b/t;->b(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    .line 3
    invoke-virtual {v7}, Lcom/github/catvod/spider/appysv2/j/b;->e()Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v8, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v7}, Lcom/github/catvod/spider/appysv2/j/b;->i()Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v8, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    new-array v10, v2, [B

    const/16 v11, 0x14

    aput-byte v11, v10, v9

    new-array v11, v4, [B

    fill-array-data v11, :array_214

    .line 4
    invoke-static {v10, v11, v8, p1}, Lcom/github/catvod/spider/appysv2/b/v;->c([B[BLjava/lang/StringBuilder;Ljava/lang/String;)V

    new-array v10, v2, [B

    const/16 v11, -0x48

    aput-byte v11, v10, v9

    new-array v11, v4, [B

    .line 5
    fill-array-data v11, :array_21c

    invoke-static {v10, v11}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v8, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v7}, Lcom/github/catvod/spider/appysv2/j/b;->d()Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v8, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    new-array v10, v2, [B

    const/16 v11, 0x20

    aput-byte v11, v10, v9

    new-array v11, v4, [B

    fill-array-data v11, :array_224

    invoke-static {v10, v11}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v8, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v7}, Lcom/github/catvod/spider/appysv2/j/b;->e()Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v8, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    new-array v10, v2, [B

    const/16 v11, -0x76

    aput-byte v11, v10, v9

    new-array v11, v4, [B

    fill-array-data v11, :array_22c

    invoke-static {v10, v11}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v8, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v7}, Lcom/github/catvod/spider/appysv2/j/b;->c()Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v8, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    new-array v10, v2, [B

    const/16 v11, 0x3a

    aput-byte v11, v10, v9

    new-array v11, v4, [B

    fill-array-data v11, :array_234

    invoke-static {v10, v11}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v8, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v7}, Lcom/github/catvod/spider/appysv2/j/b;->g()Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v8, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    new-array v10, v2, [B

    const/4 v11, -0x7

    aput-byte v11, v10, v9

    new-array v11, v4, [B

    fill-array-data v11, :array_23c

    invoke-static {v10, v11}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v8, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v7}, Lcom/github/catvod/spider/appysv2/j/b;->h()J

    move-result-wide v10

    invoke-virtual {v8, v10, v11}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    invoke-virtual {v8}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v8

    invoke-static {p2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v10

    if-nez v10, :cond_171

    const/4 v10, 0x4

    new-array v10, v10, [B

    fill-array-data v10, :array_244

    new-array v11, v4, [B

    fill-array-data v11, :array_24a

    invoke-static {v10, v11}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v10

    invoke-virtual {p2, v10}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v10

    if-nez v10, :cond_171

    .line 6
    invoke-static {v8}, Lcom/github/catvod/spider/appysv2/b/t;->b(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    new-array v10, v2, [B

    const/16 v11, -0xe

    aput-byte v11, v10, v9

    new-array v11, v4, [B

    .line 7
    fill-array-data v11, :array_252

    .line 8
    invoke-static {v10, v11, v8, p2}, Lcom/github/catvod/spider/appysv2/b/v;->c([B[BLjava/lang/StringBuilder;Ljava/lang/String;)V

    new-array v10, v2, [B

    const/16 v11, 0x17

    aput-byte v11, v10, v9

    new-array v9, v4, [B

    .line 9
    fill-array-data v9, :array_25a

    invoke-static {v10, v9}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v7}, Lcom/github/catvod/spider/appysv2/j/b;->e()Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v8, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v8}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v8

    :cond_171
    invoke-virtual {v5, v8}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto/16 :goto_3d

    :cond_176
    const/4 p2, 0x0

    :goto_177
    invoke-interface {v3}, Ljava/util/List;->size()I

    move-result v0

    if-ge p2, v0, :cond_196

    new-array v0, v2, [B

    const/16 v7, 0x43

    aput-byte v7, v0, v9

    new-array v7, v4, [B

    fill-array-data v7, :array_262

    invoke-static {v0, v7}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0, v5}, Landroid/text/TextUtils;->join(Ljava/lang/CharSequence;Ljava/lang/Iterable;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v6, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/lit8 p2, p2, 0x1

    goto :goto_177

    :cond_196
    new-instance p2, Lcom/github/catvod/spider/appysv2/c/k;

    invoke-direct {p2}, Lcom/github/catvod/spider/appysv2/c/k;-><init>()V

    invoke-virtual {p2, p1}, Lcom/github/catvod/spider/appysv2/c/k;->g(Ljava/lang/String;)V

    invoke-virtual {p2, p1}, Lcom/github/catvod/spider/appysv2/c/k;->e(Ljava/lang/String;)V

    invoke-virtual {p2, v8}, Lcom/github/catvod/spider/appysv2/c/k;->i(Ljava/lang/String;)V

    const/4 p1, 0x3

    new-array v0, p1, [B

    fill-array-data v0, :array_26a

    new-array v2, v4, [B

    fill-array-data v2, :array_270

    invoke-static {v0, v2}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p2, v0}, Lcom/github/catvod/spider/appysv2/c/k;->h(Ljava/lang/String;)V

    new-array v0, p1, [B

    fill-array-data v0, :array_278

    new-array v2, v4, [B

    fill-array-data v2, :array_27e

    invoke-static {v0, v2}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0, v6}, Landroid/text/TextUtils;->join(Ljava/lang/CharSequence;Ljava/lang/Iterable;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p2, v0}, Lcom/github/catvod/spider/appysv2/c/k;->k(Ljava/lang/String;)V

    new-array p1, p1, [B

    fill-array-data p1, :array_286

    new-array v0, v4, [B

    fill-array-data v0, :array_28c

    invoke-static {p1, v0}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object p1

    invoke-static {p1, v3}, Landroid/text/TextUtils;->join(Ljava/lang/CharSequence;Ljava/lang/Iterable;)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p2, p1}, Lcom/github/catvod/spider/appysv2/c/k;->j(Ljava/lang/String;)V

    new-array p1, v1, [B

    fill-array-data p1, :array_294

    new-array v0, v4, [B

    fill-array-data v0, :array_29e

    invoke-static {p1, v0}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p2, p1}, Lcom/github/catvod/spider/appysv2/c/k;->b(Ljava/lang/String;)V

    return-object p2

    :array_1f2
    .array-data 1
        -0x5et
        0x7dt
        -0x65t
        -0xbt
        0x4at
        0x1dt
        -0x63t
        0x6et
        0x28t
    .end array-data

    nop

    :array_1fc
    .array-data 1
        -0x6dt
        0x4ft
        -0x58t
        0x10t
        -0x3ct
        -0x7et
        0x7at
        -0x6t
    .end array-data

    :array_204
    .array-data 1
        -0x60t
        0x7at
        0x55t
        0x3ft
        -0x3t
        -0x4ft
        -0x31t
        -0x12t
    .end array-data

    :array_20c
    .array-data 1
        -0x39t
        0x12t
        0x12t
        0x2at
        -0x45t
        -0x70t
        0xct
        0x30t
    .end array-data

    :array_214
    .array-data 1
        0x30t
        0x4bt
        0x23t
        0x5t
        0x2ct
        -0x6t
        0x2ft
        -0x7ct
    .end array-data

    :array_21c
    .array-data 1
        -0x6dt
        -0x28t
        -0x7ct
        -0x7ct
        -0x1t
        0x41t
        0x71t
        -0x68t
    .end array-data

    :array_224
    .array-data 1
        0xbt
        -0x22t
        0x75t
        -0x49t
        0x44t
        -0x35t
        -0x2ct
        0x63t
    .end array-data

    :array_22c
    .array-data 1
        -0x5ft
        0x7ft
        0x37t
        0x7ct
        -0x35t
        0x3et
        -0x61t
        0x1ft
    .end array-data

    :array_234
    .array-data 1
        0x11t
        0x6ft
        -0x34t
        -0x1t
        -0x13t
        -0x34t
        -0x5at
        0x29t
    .end array-data

    :array_23c
    .array-data 1
        -0x2et
        -0x1ct
        0x6dt
        -0x3dt
        0x5ct
        -0x16t
        -0x3ft
        -0x3ct
    .end array-data

    :array_244
    .array-data 1
        -0x3bt
        -0x24t
        0x4dt
        0x14t
    .end array-data

    :array_24a
    .array-data 1
        -0x53t
        -0x58t
        0x39t
        0x64t
        0x7ct
        -0x60t
        -0x3at
        0x65t
    .end array-data

    :array_252
    .array-data 1
        -0x27t
        0x3dt
        -0x39t
        0x69t
        -0x51t
        0x42t
        0x40t
        -0x33t
    .end array-data

    :array_25a
    .array-data 1
        0x3ct
        -0x51t
        -0x68t
        -0x32t
        0x7t
        0x71t
        -0x3bt
        -0x71t
    .end array-data

    :array_262
    .array-data 1
        0x60t
        -0x28t
        0x72t
        -0x44t
        -0x43t
        0x43t
        0x73t
        0x6t
    .end array-data

    :array_26a
    .array-data 1
        0x7ct
        0x78t
        -0x2bt
    .end array-data

    :array_270
    .array-data 1
        0x4dt
        0x4at
        -0x1at
        -0x6ct
        0x44t
        0xet
        -0x5dt
        0x4t
    .end array-data

    :array_278
    .array-data 1
        0xft
        0xct
        0x22t
    .end array-data

    :array_27e
    .array-data 1
        0x2bt
        0x28t
        0x6t
        -0x1at
        -0x7dt
        -0x68t
        0x3ct
        -0x51t
    .end array-data

    :array_286
    .array-data 1
        -0x6at
        0x72t
        -0x4et
    .end array-data

    :array_28c
    .array-data 1
        -0x4et
        0x56t
        -0x6at
        0x5ft
        -0x36t
        -0x78t
        -0x39t
        -0x7ct
    .end array-data

    :array_294
    .array-data 1
        0x27t
        -0x22t
        -0x4at
        0x6bt
        -0x1bt
        0x3at
        0x1ct
        -0x23t
        -0x72t
    .end array-data

    nop

    :array_29e
    .array-data 1
        0x16t
        -0x14t
        -0x7bt
        -0x74t
        0x58t
        -0x55t
        -0x5t
        0x46t
    .end array-data
.end method

.method public final o()V
    .registers 18

    move-object/from16 v1, p0

    const-wide/16 v2, 0x190

    const/4 v4, 0x1

    :try_start_5
    invoke-static {v2, v3}, Landroid/os/SystemClock;->sleep(J)V

    .line 1
    new-instance v0, Lcom/github/catvod/spider/appysv2/b/b;

    invoke-direct {v0, v1, v4}, Lcom/github/catvod/spider/appysv2/b/b;-><init>(Ljava/lang/Object;I)V

    invoke-static {v0}, Lcom/github/catvod/spider/Init;->run(Ljava/lang/Runnable;)V

    .line 2
    new-instance v0, Lcom/github/catvod/spider/appysv2/b/f;

    invoke-direct {v0, v1, v4}, Lcom/github/catvod/spider/appysv2/b/f;-><init>(Ljava/lang/Object;I)V

    invoke-static {v0}, Lcom/github/catvod/spider/Init;->run(Ljava/lang/Runnable;)V
    :try_end_18
    .catch Ljava/lang/Exception; {:try_start_5 .. :try_end_18} :catch_27
    .catchall {:try_start_5 .. :try_end_18} :catchall_24

    .line 3
    :goto_18
    iget-object v0, v1, Lcom/github/catvod/spider/appysv2/b/F;->a:Ljava/lang/String;

    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    if-eqz v0, :cond_ca

    invoke-static {v2, v3}, Landroid/os/SystemClock;->sleep(J)V

    goto :goto_18

    :catchall_24
    move-exception v0

    goto/16 :goto_cb

    :catch_27
    move-exception v0

    .line 4
    :try_start_28
    new-instance v5, Lcom/github/catvod/spider/appysv2/b/b;

    invoke-direct {v5, v1, v4}, Lcom/github/catvod/spider/appysv2/b/b;-><init>(Ljava/lang/Object;I)V

    invoke-static {v5}, Lcom/github/catvod/spider/Init;->run(Ljava/lang/Runnable;)V

    .line 5
    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    const/16 v6, 0x10

    new-array v6, v6, [B

    const/16 v7, -0xb

    const/4 v8, 0x0

    aput-byte v7, v6, v8

    const/16 v9, 0x5c

    aput-byte v9, v6, v4

    const/16 v9, 0x7d

    const/4 v10, 0x2

    aput-byte v9, v6, v10

    const/16 v9, -0x9

    const/4 v11, 0x3

    aput-byte v9, v6, v11

    const/16 v9, 0x2e

    const/4 v12, 0x4

    aput-byte v9, v6, v12

    const/4 v9, 0x5

    aput-byte v11, v6, v9

    const/16 v13, 0x4c

    const/4 v14, 0x6

    aput-byte v13, v6, v14

    const/16 v13, -0x5a

    const/4 v15, 0x7

    aput-byte v13, v6, v15

    const/4 v13, -0x8

    const/16 v2, 0x8

    aput-byte v13, v6, v2

    const/16 v3, 0x4f

    const/16 v13, 0x9

    aput-byte v3, v6, v13

    const/16 v3, 0xa

    const/16 v16, 0x5a

    aput-byte v16, v6, v3

    const/16 v3, 0xb

    const/16 v16, -0x3

    aput-byte v16, v6, v3

    const/16 v3, 0xc

    const/16 v16, 0x24

    aput-byte v16, v6, v3

    const/16 v3, 0xd

    aput-byte v13, v6, v3

    const/16 v3, 0xe

    const/16 v13, 0x23

    aput-byte v13, v6, v3

    const/16 v3, 0xf

    aput-byte v7, v6, v3

    new-array v2, v2, [B

    const/16 v3, -0x63

    aput-byte v3, v2, v8

    const/16 v3, 0x3d

    aput-byte v3, v2, v4

    const/16 v3, 0x13

    aput-byte v3, v2, v10

    const/16 v3, -0x6d

    aput-byte v3, v2, v11

    const/16 v3, 0x42

    aput-byte v3, v2, v12

    const/16 v3, 0x66

    aput-byte v3, v2, v9

    const/16 v3, 0x19

    aput-byte v3, v2, v14

    const/16 v3, -0x2b

    aput-byte v3, v2, v15

    invoke-static {v6, v2}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v5, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lcom/github/catvod/crawler/SpiderDebug;->log(Ljava/lang/String;)V
    :try_end_bc
    .catchall {:try_start_28 .. :try_end_bc} :catchall_24

    :goto_bc
    iget-object v0, v1, Lcom/github/catvod/spider/appysv2/b/F;->a:Ljava/lang/String;

    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    if-eqz v0, :cond_ca

    const-wide/16 v2, 0x190

    invoke-static {v2, v3}, Landroid/os/SystemClock;->sleep(J)V

    goto :goto_bc

    :cond_ca
    return-void

    :goto_cb
    iget-object v2, v1, Lcom/github/catvod/spider/appysv2/b/F;->a:Ljava/lang/String;

    invoke-static {v2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v2

    if-eqz v2, :cond_d9

    const-wide/16 v2, 0x190

    invoke-static {v2, v3}, Landroid/os/SystemClock;->sleep(J)V

    goto :goto_cb

    :cond_d9
    goto :goto_db

    :goto_da
    throw v0

    :goto_db
    goto :goto_da
.end method

.method public final r([Ljava/lang/String;)Ljava/lang/String;
    .registers 11

    iget-object v0, p0, Lcom/github/catvod/spider/appysv2/b/F;->a:Ljava/lang/String;

    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    if-eqz v0, :cond_12

    const/4 v0, 0x0

    invoke-direct {p0, v0}, Lcom/github/catvod/spider/appysv2/b/F;->q(Z)Z

    move-result v0

    if-nez v0, :cond_12

    invoke-virtual {p0}, Lcom/github/catvod/spider/appysv2/b/F;->o()V

    :cond_12
    new-instance v0, Ljava/lang/Thread;

    new-instance v1, Lcom/github/catvod/spider/appysv2/b/i;

    const/4 v2, 0x1

    invoke-direct {v1, p0, p1, v2}, Lcom/github/catvod/spider/appysv2/b/i;-><init>(Ljava/lang/Object;Ljava/lang/Object;I)V

    invoke-direct {v0, v1}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;)V

    invoke-virtual {v0}, Ljava/lang/Thread;->start()V

    aget-object v4, p1, v2

    const/4 v0, 0x2

    aget-object v5, p1, v0

    const/4 v0, 0x3

    aget-object v6, p1, v0

    const/4 v1, 0x4

    aget-object v7, p1, v1

    const/4 v2, 0x5

    aget-object v8, p1, v2

    move-object v3, p0

    invoke-direct/range {v3 .. v8}, Lcom/github/catvod/spider/appysv2/b/F;->k(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    invoke-static {}, Lcom/github/catvod/spider/Proxy;->getUrl()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v4, 0x12

    new-array v4, v4, [B

    fill-array-data v4, :array_9a

    const/16 v5, 0x8

    new-array v6, v5, [B

    fill-array-data v6, :array_a8

    invoke-static {v4, v6}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    aget-object v0, p1, v0

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v0, 0xa

    new-array v0, v0, [B

    fill-array-data v0, :array_b0

    new-array v4, v5, [B

    fill-array-data v4, :array_ba

    invoke-static {v0, v4}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    aget-object p1, p1, v1

    invoke-virtual {v3, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    new-array p1, v5, [B

    fill-array-data p1, :array_c2

    new-array v0, v5, [B

    fill-array-data v0, :array_ca

    .line 1
    invoke-static {p1, v0, v3}, Lcom/github/catvod/spider/appysv2/b/t;->a([B[BLjava/lang/StringBuilder;)Ljava/lang/String;

    move-result-object p1

    .line 2
    new-instance v0, Lcom/github/catvod/spider/appysv2/c/h;

    invoke-direct {v0}, Lcom/github/catvod/spider/appysv2/c/h;-><init>()V

    .line 3
    invoke-virtual {v0, v2}, Lcom/github/catvod/spider/appysv2/c/h;->y(Ljava/lang/String;)Lcom/github/catvod/spider/appysv2/c/h;

    invoke-virtual {v0, p1}, Lcom/github/catvod/spider/appysv2/c/h;->a(Ljava/lang/String;)Lcom/github/catvod/spider/appysv2/c/h;

    invoke-virtual {v0}, Lcom/github/catvod/spider/appysv2/c/h;->j()Lcom/github/catvod/spider/appysv2/c/h;

    invoke-direct {p0}, Lcom/github/catvod/spider/appysv2/b/F;->l()Ljava/util/Map;

    move-result-object p1

    invoke-virtual {v0, p1}, Lcom/github/catvod/spider/appysv2/c/h;->f(Ljava/util/Map;)Lcom/github/catvod/spider/appysv2/c/h;

    .line 4
    invoke-virtual {v0}, Lcom/github/catvod/spider/appysv2/c/h;->toString()Ljava/lang/String;

    move-result-object p1

    return-object p1

    nop

    :array_9a
    .array-data 1
        -0x28t
        -0x66t
        0x57t
        -0x42t
        -0x7et
        -0x1at
        -0x51t
        0x66t
        -0x6et
        -0x28t
        0x4et
        -0x14t
        -0x7et
        -0x37t
        -0x60t
        0x66t
        -0x7et
        -0x3dt
    .end array-data

    nop

    :array_a8
    .array-data 1
        -0x19t
        -0x2t
        0x38t
        -0x7dt
        -0x1at
        -0x79t
        -0x3ft
        0xbt
    .end array-data

    :array_b0
    .array-data 1
        -0x33t
        -0x10t
        0x40t
        -0x4ct
        0x79t
        0x19t
        -0x4ft
        0x39t
        -0x6dt
        -0x45t
    .end array-data

    nop

    :array_ba
    .array-data 1
        -0x15t
        -0x7at
        0x2ft
        -0x30t
        0x30t
        0x77t
        -0x2bt
        0x5ct
    .end array-data

    :array_c2
    .array-data 1
        -0x2et
        -0xbt
        0x52t
        0x2bt
        0x73t
        0x6ft
        -0x51t
        0x37t
    .end array-data

    :array_ca
    .array-data 1
        -0xct
        -0x7dt
        0x3dt
        0x4ft
        0x26t
        0x1dt
        -0x3dt
        0xat
    .end array-data
.end method

.method public final s()V
    .registers 49

    move-object/from16 v1, p0

    const/16 v2, 0xf

    const/16 v3, 0x8

    :try_start_6
    invoke-static {}, Lcom/github/catvod/spider/Init;->getActivity()Landroid/app/Activity;

    move-result-object v0

    new-instance v4, Landroid/widget/LinearLayout;

    invoke-direct {v4, v0}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    const/4 v5, 0x0

    invoke-virtual {v4, v5}, Landroid/widget/LinearLayout;->setOrientation(I)V

    const/16 v6, 0x10

    invoke-virtual {v4, v6, v6, v6, v6}, Landroid/view/View;->setPadding(IIII)V

    const/4 v7, -0x1

    invoke-virtual {v4, v7}, Landroid/view/View;->setBackgroundColor(I)V

    new-instance v8, Landroid/widget/ImageView;

    invoke-static {}, Lcom/github/catvod/spider/Init;->getActivity()Landroid/app/Activity;

    move-result-object v0

    invoke-direct {v8, v0}, Landroid/widget/ImageView;-><init>(Landroid/content/Context;)V

    const/16 v0, 0x78

    invoke-static {v0}, Lcom/github/catvod/spider/appysv2/a/a;->b(I)I

    move-result v0

    new-instance v9, Landroid/widget/LinearLayout$LayoutParams;

    invoke-direct {v9, v0, v0}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v8, v9}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    const/16 v9, 0x9

    new-array v10, v9, [B

    const/16 v11, 0x22

    aput-byte v11, v10, v5

    const/4 v12, 0x1

    const/16 v13, 0x40

    aput-byte v13, v10, v12

    const/4 v14, 0x2

    const/16 v15, -0x5b

    aput-byte v15, v10, v14

    const/16 v16, 0x45

    const/16 v17, 0x3

    aput-byte v16, v10, v17

    const/16 v16, 0x4

    const/16 v18, 0x14

    aput-byte v18, v10, v16

    const/16 v19, 0x68

    const/16 v20, 0x5

    aput-byte v19, v10, v20

    const/16 v19, 0x6

    aput-byte v6, v10, v19

    const/16 v21, -0x5a

    const/16 v22, 0x7

    aput-byte v21, v10, v22

    const/16 v21, 0x47

    aput-byte v21, v10, v3

    new-array v7, v3, [B

    const/16 v23, -0x3a

    aput-byte v23, v7, v5

    const/16 v23, -0x6

    aput-byte v23, v7, v12

    const/16 v23, 0x29

    aput-byte v23, v7, v14

    const/16 v24, -0x5e

    aput-byte v24, v7, v17

    const/16 v24, -0x51

    aput-byte v24, v7, v16

    const/16 v24, -0x24

    aput-byte v24, v7, v20

    const/16 v24, -0x9

    aput-byte v24, v7, v19

    aput-byte v19, v7, v22

    invoke-static {v10, v7}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v8, v7}, Landroid/view/View;->setContentDescription(Ljava/lang/CharSequence;)V

    invoke-static {}, Lcom/github/catvod/spider/Init;->context()Landroid/app/Application;

    move-result-object v7

    invoke-static {v7}, Lcom/github/catvod/spider/appysv2/p/C;->g(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v7

    const/16 v10, 0x20

    new-array v13, v10, [B

    const/16 v25, -0x10

    aput-byte v25, v13, v5

    const/16 v25, 0x7d

    aput-byte v25, v13, v12

    const/16 v25, -0x56

    aput-byte v25, v13, v14

    const/16 v25, -0x80

    aput-byte v25, v13, v17

    const/16 v25, -0x60

    aput-byte v25, v13, v16

    const/16 v25, 0x2c

    aput-byte v25, v13, v20

    const/16 v26, 0x6b

    aput-byte v26, v13, v19

    const/16 v27, 0xa

    aput-byte v27, v13, v22

    const/16 v28, -0x15

    aput-byte v28, v13, v3

    const/16 v28, 0x33

    aput-byte v28, v13, v9

    const/16 v29, -0x19

    aput-byte v29, v13, v27

    const/16 v29, -0x37

    const/16 v30, 0xb

    aput-byte v29, v13, v30

    const/16 v29, 0xc

    const/16 v31, -0x53

    aput-byte v31, v13, v29

    const/16 v32, 0xd

    const/16 v33, 0x3b

    aput-byte v33, v13, v32

    const/16 v34, 0xe

    aput-byte v26, v13, v34

    const/16 v35, 0x5f

    aput-byte v35, v13, v2

    const/16 v35, -0x16

    aput-byte v35, v13, v6

    const/16 v35, 0x11

    const/16 v36, 0x66

    aput-byte v36, v13, v35

    const/16 v35, -0x5a

    const/16 v36, 0x12

    aput-byte v35, v13, v36

    const/16 v35, 0x13

    const/16 v37, -0x77

    aput-byte v37, v13, v35

    aput-byte v15, v13, v18

    const/16 v35, 0x67

    const/16 v37, 0x15

    aput-byte v35, v13, v37

    const/16 v35, 0x2b

    const/16 v38, 0x16

    aput-byte v35, v13, v38

    const/16 v35, 0x17

    aput-byte v36, v13, v35

    const/16 v35, -0x18

    const/16 v39, 0x18

    aput-byte v35, v13, v39

    const/16 v40, 0x7c

    const/16 v41, 0x19

    aput-byte v40, v13, v41

    const/16 v40, 0x1a

    aput-byte v31, v13, v40

    const/16 v42, -0x68

    const/16 v43, 0x1b

    aput-byte v42, v13, v43

    const/16 v44, 0x1c

    const/16 v45, -0xd

    aput-byte v45, v13, v44

    const/16 v44, 0x1d

    const/16 v45, 0x6d

    aput-byte v45, v13, v44

    const/16 v44, 0x1e

    aput-byte v11, v13, v44

    const/16 v45, 0x1f

    const/16 v24, 0x40

    aput-byte v24, v13, v45

    new-array v11, v3, [B

    aput-byte v42, v11, v5

    aput-byte v9, v11, v12

    const/16 v46, -0x22

    aput-byte v46, v11, v14

    const/16 v46, -0x10

    aput-byte v46, v11, v17

    const/16 v46, -0x66

    aput-byte v46, v11, v16

    aput-byte v17, v11, v20

    const/16 v46, 0x44

    aput-byte v46, v11, v19

    const/16 v46, 0x2f

    aput-byte v46, v11, v22

    invoke-static {v13, v11}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v11

    new-array v13, v12, [Ljava/lang/Object;

    aput-object v7, v13, v5

    invoke-static {v11, v13}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v7
    :try_end_15a
    .catch Ljava/lang/Exception; {:try_start_6 .. :try_end_15a} :catch_406

    :try_start_15a
    invoke-static {v7, v0}, Lcom/github/catvod/spider/appysv2/B/l;->e(Ljava/lang/String;I)Landroid/graphics/Bitmap;

    move-result-object v0

    invoke-virtual {v8, v0}, Landroid/widget/ImageView;->setImageBitmap(Landroid/graphics/Bitmap;)V
    :try_end_161
    .catch Ljava/lang/Exception; {:try_start_15a .. :try_end_161} :catch_162

    goto :goto_166

    :catch_162
    move-exception v0

    :try_start_163
    invoke-virtual {v0}, Ljava/lang/Throwable;->printStackTrace()V

    :goto_166
    new-instance v0, Landroid/widget/LinearLayout;

    invoke-static {}, Lcom/github/catvod/spider/Init;->getActivity()Landroid/app/Activity;

    move-result-object v7

    invoke-direct {v0, v7}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    invoke-virtual {v0, v12}, Landroid/widget/LinearLayout;->setOrientation(I)V

    invoke-virtual {v0, v6, v5, v5, v5}, Landroid/view/View;->setPadding(IIII)V

    new-instance v7, Landroid/widget/LinearLayout$LayoutParams;

    const/high16 v11, 0x3f800000  # 1.0f

    const/4 v13, -0x2

    invoke-direct {v7, v5, v13, v11}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    invoke-virtual {v0, v7}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    new-instance v7, Landroid/widget/EditText;

    invoke-static {}, Lcom/github/catvod/spider/Init;->getActivity()Landroid/app/Activity;

    move-result-object v11

    invoke-direct {v7, v11}, Landroid/widget/EditText;-><init>(Landroid/content/Context;)V

    new-array v11, v2, [B

    const/16 v46, 0x5d

    aput-byte v46, v11, v5

    const/16 v46, 0x4f

    aput-byte v46, v11, v12

    const/16 v46, 0x5f

    aput-byte v46, v11, v14

    const/16 v46, -0x26

    aput-byte v46, v11, v17

    const/16 v46, -0x1a

    aput-byte v46, v11, v16

    aput-byte v14, v11, v20

    const/16 v46, 0x46

    aput-byte v46, v11, v19

    const/16 v46, 0x6d

    aput-byte v46, v11, v22

    aput-byte v6, v11, v3

    aput-byte v3, v11, v9

    const/16 v46, 0x5c

    aput-byte v46, v11, v27

    const/16 v46, -0x6c

    aput-byte v46, v11, v30

    const/16 v46, -0x43

    aput-byte v46, v11, v29

    aput-byte v44, v11, v32

    aput-byte v18, v11, v34

    new-array v15, v3, [B

    const/16 v47, -0x4b

    aput-byte v47, v15, v5

    const/16 v47, -0x20

    aput-byte v47, v15, v12

    aput-byte v35, v15, v14

    const/16 v47, 0x32

    aput-byte v47, v15, v17

    const/16 v47, 0x58

    aput-byte v47, v15, v16

    const/16 v47, -0x6f

    aput-byte v47, v15, v20

    const/16 v47, -0x5d

    aput-byte v47, v15, v19

    aput-byte v35, v15, v22

    invoke-static {v11, v15}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v11

    invoke-virtual {v7, v11}, Landroid/widget/TextView;->setHint(Ljava/lang/CharSequence;)V

    new-instance v11, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v15, -0x1

    invoke-direct {v11, v15, v13}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v7, v11}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    new-instance v11, Landroid/widget/EditText;

    invoke-static {}, Lcom/github/catvod/spider/Init;->getActivity()Landroid/app/Activity;

    move-result-object v15

    invoke-direct {v11, v15}, Landroid/widget/EditText;-><init>(Landroid/content/Context;)V

    new-array v15, v2, [B

    const/16 v35, -0x45

    aput-byte v35, v15, v5

    const/16 v35, -0x7f

    aput-byte v35, v15, v12

    const/16 v35, 0x6c

    aput-byte v35, v15, v14

    const/16 v35, -0x37

    aput-byte v35, v15, v17

    const/16 v35, -0x48

    aput-byte v35, v15, v16

    aput-byte v33, v15, v20

    const/16 v35, -0x69

    aput-byte v35, v15, v19

    aput-byte v37, v15, v22

    const/16 v35, -0xa

    aput-byte v35, v15, v3

    const/16 v35, -0x35

    aput-byte v35, v15, v9

    const/16 v35, 0x74

    aput-byte v35, v15, v27

    const/16 v35, -0x59

    aput-byte v35, v15, v30

    const/16 v35, -0x1f

    aput-byte v35, v15, v29

    aput-byte v3, v15, v32

    const/16 v35, -0xd

    aput-byte v35, v15, v34

    new-array v10, v3, [B

    const/16 v47, 0x53

    aput-byte v47, v10, v5

    const/16 v47, 0x2e

    aput-byte v47, v10, v12

    const/16 v47, -0x25

    aput-byte v47, v10, v14

    const/16 v47, 0x21

    aput-byte v47, v10, v17

    aput-byte v19, v10, v16

    const/16 v47, -0x58

    aput-byte v47, v10, v20

    const/16 v47, 0x72

    aput-byte v47, v10, v19

    const/16 v47, -0x70

    aput-byte v47, v10, v22

    invoke-static {v15, v10}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v11, v10}, Landroid/widget/TextView;->setHint(Ljava/lang/CharSequence;)V

    new-instance v10, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v15, -0x1

    invoke-direct {v10, v15, v13}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v11, v10}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    invoke-virtual {v0, v7}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    invoke-virtual {v0, v11}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    invoke-virtual {v4, v8}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    invoke-virtual {v4, v0}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    new-instance v0, Landroid/app/AlertDialog$Builder;

    invoke-static {}, Lcom/github/catvod/spider/Init;->getActivity()Landroid/app/Activity;

    move-result-object v8

    invoke-direct {v0, v8}, Landroid/app/AlertDialog$Builder;-><init>(Landroid/content/Context;)V

    const/16 v8, 0x45

    new-array v8, v8, [B

    const/16 v10, -0x69

    aput-byte v10, v8, v5

    const/16 v10, 0x3c

    aput-byte v10, v8, v12

    const/16 v10, -0x6d

    aput-byte v10, v8, v14

    const/16 v10, 0x39

    aput-byte v10, v8, v17

    aput-byte v40, v8, v16

    const/16 v10, 0x39

    aput-byte v10, v8, v20

    aput-byte v41, v8, v19

    aput-byte v26, v8, v22

    const/16 v10, -0x26

    aput-byte v10, v8, v3

    const/16 v10, -0x5e

    aput-byte v10, v8, v9

    aput-byte v38, v8, v27

    const/16 v10, -0x1e

    aput-byte v10, v8, v30

    const/16 v10, 0x40

    aput-byte v10, v8, v29

    aput-byte v6, v8, v32

    const/16 v10, 0x6d

    aput-byte v10, v8, v34

    aput-byte v9, v8, v2

    const/16 v9, -0x1c

    aput-byte v9, v8, v6

    const/16 v6, 0x11

    aput-byte v30, v8, v6

    const/16 v6, -0x3d

    aput-byte v6, v8, v36

    const/16 v6, 0x13

    const/16 v9, 0x4b

    aput-byte v9, v8, v6

    const/16 v6, 0x20

    aput-byte v6, v8, v18

    const/16 v6, 0x4f

    aput-byte v6, v8, v37

    const/16 v6, 0x53

    aput-byte v6, v8, v38

    const/16 v6, 0x17

    const/16 v9, 0x68

    aput-byte v9, v8, v6

    aput-byte v42, v8, v39

    aput-byte v28, v8, v41

    const/16 v6, -0x5b

    aput-byte v6, v8, v40

    const/16 v6, 0x37

    aput-byte v6, v8, v43

    const/16 v6, 0x1c

    aput-byte v25, v8, v6

    const/16 v6, 0x1d

    const/16 v9, 0x3c

    aput-byte v9, v8, v6

    aput-byte v18, v8, v44

    const/16 v6, 0x1f

    const/16 v9, 0x6e

    aput-byte v9, v8, v6

    const/4 v6, -0x6

    const/16 v9, 0x20

    aput-byte v6, v8, v9

    const/16 v6, 0x21

    const/16 v9, 0x75

    aput-byte v9, v8, v6

    const/16 v6, 0x22

    aput-byte v31, v8, v6

    const/16 v6, 0x23

    const/16 v9, 0x7a

    aput-byte v9, v8, v6

    const/16 v6, 0x24

    const/16 v9, 0x42

    aput-byte v9, v8, v6

    const/16 v6, 0x25

    const/16 v9, 0x25

    aput-byte v9, v8, v6

    const/16 v6, 0x26

    const/16 v9, 0x73

    aput-byte v9, v8, v6

    const/16 v6, 0x27

    aput-byte v27, v8, v6

    const/16 v6, 0x28

    const/16 v9, -0x39

    aput-byte v9, v8, v6

    aput-byte v39, v8, v23

    const/16 v6, 0x2a

    const/16 v9, -0x33

    aput-byte v9, v8, v6

    const/16 v6, 0x2b

    const/16 v9, 0x4c

    aput-byte v9, v8, v6

    aput-byte v19, v8, v25

    const/16 v6, 0x2d

    const/16 v9, 0x4d

    aput-byte v9, v8, v6

    const/16 v6, 0x2e

    const/16 v9, 0x66

    aput-byte v9, v8, v6

    const/16 v6, 0x2f

    const/16 v9, 0x6a

    aput-byte v9, v8, v6

    const/16 v6, 0x30

    const/16 v9, -0x65

    aput-byte v9, v8, v6

    const/16 v6, 0x31

    aput-byte v23, v8, v6

    const/16 v6, 0x32

    const/16 v9, -0x58

    aput-byte v9, v8, v6

    const/16 v6, 0x36

    aput-byte v6, v8, v28

    const/16 v6, 0x34

    const/16 v9, 0x1f

    aput-byte v9, v8, v6

    const/16 v6, 0x35

    aput-byte v44, v8, v6

    const/16 v6, 0x36

    aput-byte v43, v8, v6

    const/16 v6, 0x37

    const/16 v9, 0x4e

    aput-byte v9, v8, v6

    const/16 v6, 0x38

    aput-byte v13, v8, v6

    const/16 v6, 0x39

    const/16 v9, 0x7b

    aput-byte v9, v8, v6

    const/16 v6, 0x3a

    const/16 v9, -0x65

    aput-byte v9, v8, v6

    const/16 v6, 0x4a

    aput-byte v6, v8, v33

    const/16 v6, 0x3c

    const/16 v9, 0x4c

    aput-byte v9, v8, v6

    const/16 v6, 0x3d

    aput-byte v30, v8, v6

    const/16 v6, 0x3e

    const/16 v9, 0x70

    aput-byte v9, v8, v6

    const/16 v6, 0x3f

    aput-byte v30, v8, v6

    const/16 v6, -0x22

    const/16 v9, 0x40

    aput-byte v6, v8, v9

    const/16 v6, 0x41

    const/16 v9, 0x38

    aput-byte v9, v8, v6

    const/16 v6, 0x42

    const/16 v9, -0x3f

    aput-byte v9, v8, v6

    const/16 v6, 0x43

    const/16 v9, 0x57

    aput-byte v9, v8, v6

    const/16 v6, 0x44

    const/16 v9, 0x3d

    aput-byte v9, v8, v6

    new-array v6, v3, [B

    const/16 v9, 0x7f

    aput-byte v9, v6, v5

    const/16 v9, -0x6d

    aput-byte v9, v6, v12

    const/16 v9, 0x24

    aput-byte v9, v6, v14

    const/16 v9, -0x2f

    aput-byte v9, v6, v17

    const/16 v9, -0x5c

    aput-byte v9, v6, v16

    const/16 v9, -0x56

    aput-byte v9, v6, v20

    const/4 v9, -0x4

    aput-byte v9, v6, v19

    const/16 v9, -0x12

    aput-byte v9, v6, v22

    invoke-static {v8, v6}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v0, v6}, Landroid/app/AlertDialog$Builder;->setTitle(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    move-result-object v0

    invoke-virtual {v0, v4}, Landroid/app/AlertDialog$Builder;->setView(Landroid/view/View;)Landroid/app/AlertDialog$Builder;

    move-result-object v0

    const/high16 v4, 0x1040000

    new-instance v6, Lcom/github/catvod/spider/appysv2/b/B;

    invoke-direct {v6, v1, v5}, Lcom/github/catvod/spider/appysv2/b/B;-><init>(Ljava/lang/Object;I)V

    invoke-virtual {v0, v4, v6}, Landroid/app/AlertDialog$Builder;->setNegativeButton(ILandroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object v0

    const v4, 0x104000a

    new-instance v6, Lcom/github/catvod/spider/appysv2/b/C;

    invoke-direct {v6, v1, v7, v11, v5}, Lcom/github/catvod/spider/appysv2/b/C;-><init>(Ljava/lang/Object;Landroid/widget/EditText;Landroid/widget/EditText;I)V

    invoke-virtual {v0, v4, v6}, Landroid/app/AlertDialog$Builder;->setPositiveButton(ILandroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object v0

    invoke-virtual {v0}, Landroid/app/AlertDialog$Builder;->show()Landroid/app/AlertDialog;

    move-result-object v0

    iput-object v0, v1, Lcom/github/catvod/spider/appysv2/b/F;->b:Landroid/app/AlertDialog;

    iput-boolean v12, v1, Lcom/github/catvod/spider/appysv2/b/F;->c:Z

    .line 1
    new-instance v0, Ljava/lang/Thread;

    new-instance v4, Lcom/github/catvod/spider/appysv2/b/c;

    invoke-direct {v4, v1, v12}, Lcom/github/catvod/spider/appysv2/b/c;-><init>(Ljava/lang/Object;I)V

    invoke-direct {v0, v4}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;)V

    invoke-virtual {v0}, Ljava/lang/Thread;->start()V
    :try_end_405
    .catch Ljava/lang/Exception; {:try_start_163 .. :try_end_405} :catch_406

    goto :goto_431

    :catch_406
    move-exception v0

    .line 2
    invoke-direct/range {p0 .. p0}, Lcom/github/catvod/spider/appysv2/b/F;->i()V

    invoke-virtual {v0}, Ljava/lang/Throwable;->printStackTrace()V

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    new-array v2, v2, [B

    fill-array-data v2, :array_432

    new-array v3, v3, [B

    fill-array-data v3, :array_43e

    invoke-static {v2, v3}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lcom/github/catvod/crawler/SpiderDebug;->log(Ljava/lang/String;)V

    :goto_431
    return-void

    :array_432
    .array-data 1
        0x2et
        -0x1dt
        0x16t
        -0x78t
        -0x5dt
        -0x8t
        -0x5et
        -0x63t
        0x29t
        -0x47t
        0x59t
        -0x66t
        -0x6et
        -0x54t
        -0xet
    .end array-data

    :array_43e
    .array-data 1
        0x5dt
        -0x75t
        0x79t
        -0x1t
        -0x16t
        -0x6at
        -0x2et
        -0x18t
    .end array-data
.end method
