.class final Lcom/github/catvod/spider/appysv2/b/L;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field static volatile a:Lcom/github/catvod/spider/appysv2/b/M;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    new-instance v0, Lcom/github/catvod/spider/appysv2/b/M;

    invoke-direct {v0}, Lcom/github/catvod/spider/appysv2/b/M;-><init>()V

    sput-object v0, Lcom/github/catvod/spider/appysv2/b/L;->a:Lcom/github/catvod/spider/appysv2/b/M;

    return-void
.end method
