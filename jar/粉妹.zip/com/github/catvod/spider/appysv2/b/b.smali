.class public final synthetic Lcom/github/catvod/spider/appysv2/b/b;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(Ljava/lang/Object;I)V
    .registers 3

    iput p2, p0, Lcom/github/catvod/spider/appysv2/b/b;->a:I

    iput-object p1, p0, Lcom/github/catvod/spider/appysv2/b/b;->b:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 2

    iget v0, p0, Lcom/github/catvod/spider/appysv2/b/b;->a:I

    packed-switch v0, :pswitch_data_36

    goto :goto_2e

    :pswitch_6  #0x4
    iget-object v0, p0, Lcom/github/catvod/spider/appysv2/b/b;->b:Ljava/lang/Object;

    check-cast v0, Lcom/github/catvod/spider/Config;

    invoke-static {v0}, Lcom/github/catvod/spider/Config;->b(Lcom/github/catvod/spider/Config;)V

    return-void

    :pswitch_e  #0x3
    iget-object v0, p0, Lcom/github/catvod/spider/appysv2/b/b;->b:Ljava/lang/Object;

    check-cast v0, Lcom/github/catvod/debug/MainActivity;

    invoke-virtual {v0}, Lcom/github/catvod/debug/MainActivity;->i()V

    return-void

    :pswitch_16  #0x2
    iget-object v0, p0, Lcom/github/catvod/spider/appysv2/b/b;->b:Ljava/lang/Object;

    check-cast v0, Lcom/github/catvod/spider/appysv2/b/U;

    invoke-virtual {v0}, Lcom/github/catvod/spider/appysv2/b/U;->R()V

    return-void

    :pswitch_1e  #0x1
    iget-object v0, p0, Lcom/github/catvod/spider/appysv2/b/b;->b:Ljava/lang/Object;

    check-cast v0, Lcom/github/catvod/spider/appysv2/b/F;

    invoke-static {v0}, Lcom/github/catvod/spider/appysv2/b/F;->f(Lcom/github/catvod/spider/appysv2/b/F;)V

    return-void

    :pswitch_26  #0x0
    iget-object v0, p0, Lcom/github/catvod/spider/appysv2/b/b;->b:Ljava/lang/Object;

    check-cast v0, Lcom/github/catvod/spider/appysv2/b/x;

    invoke-static {v0}, Lcom/github/catvod/spider/appysv2/b/x;->b(Lcom/github/catvod/spider/appysv2/b/x;)V

    return-void

    :goto_2e
    iget-object v0, p0, Lcom/github/catvod/spider/appysv2/b/b;->b:Ljava/lang/Object;

    check-cast v0, Lcom/github/catvod/spider/JSDemo;

    invoke-static {v0}, Lcom/github/catvod/spider/JSDemo;->b(Lcom/github/catvod/spider/JSDemo;)V

    return-void

    :pswitch_data_36
    .packed-switch 0x0
        :pswitch_26  #00000000
        :pswitch_1e  #00000001
        :pswitch_16  #00000002
        :pswitch_e  #00000003
        :pswitch_6  #00000004
    .end packed-switch
.end method
