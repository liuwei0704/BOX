.class public final synthetic Lcom/github/catvod/spider/appysv2/b/o;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/content/DialogInterface$OnClickListener;


# instance fields
.field public final synthetic a:Lcom/github/catvod/spider/appysv2/b/x;


# direct methods
.method public synthetic constructor <init>(Lcom/github/catvod/spider/appysv2/b/x;)V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/github/catvod/spider/appysv2/b/o;->a:Lcom/github/catvod/spider/appysv2/b/x;

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/content/DialogInterface;I)V
    .registers 3

    iget-object p1, p0, Lcom/github/catvod/spider/appysv2/b/o;->a:Lcom/github/catvod/spider/appysv2/b/x;

    invoke-static {p1}, Lcom/github/catvod/spider/appysv2/b/x;->f(Lcom/github/catvod/spider/appysv2/b/x;)V

    return-void
.end method
