.class public final Lcom/github/catvod/spider/appysv2/b/A;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field private static c:Landroid/graphics/Bitmap;

.field private static d:Ljava/lang/String;

.field private static final e:Ljava/lang/String;


# instance fields
.field private a:Ljava/lang/String;

.field private final b:Ljava/util/HashMap;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;>;"
        }
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .registers 2

    const/4 v0, 0x6

    new-array v0, v0, [B

    fill-array-data v0, :array_14

    const/16 v1, 0x8

    new-array v1, v1, [B

    fill-array-data v1, :array_1c

    invoke-static {v0, v1}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lcom/github/catvod/spider/appysv2/b/A;->e:Ljava/lang/String;

    return-void

    :array_14
    .array-data 1
        -0x39t
        0x4t
        -0x6ct
        -0x6dt
        0x73t
        -0x80t
    .end array-data

    nop

    :array_1c
    .array-data 1
        -0x18t
        0x70t
        -0x1et
        -0x19t
        0x1et
        -0x10t
        0x2at
        -0x63t
    .end array-data
.end method

.method public constructor <init>()V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Ljava/util/HashMap;

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    iput-object v0, p0, Lcom/github/catvod/spider/appysv2/b/A;->b:Ljava/util/HashMap;

    return-void
.end method

.method private a(Ljava/lang/String;Z)Lcom/github/catvod/spider/appysv2/c/e;
    .registers 51
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Z)",
            "Lcom/github/catvod/spider/appysv2/c/e<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    move-object/from16 v1, p0

    move-object/from16 v2, p1

    new-instance v3, Lcom/github/catvod/spider/appysv2/c/e;

    invoke-direct {v3}, Lcom/github/catvod/spider/appysv2/c/e;-><init>()V

    const/4 v4, 0x0

    invoke-virtual {v3, v4}, Lcom/github/catvod/spider/appysv2/c/e;->e(I)V

    const/16 v5, 0x8

    const/4 v6, 0x1

    :try_start_10
    invoke-direct {v1, v6}, Lcom/github/catvod/spider/appysv2/b/A;->b(Z)Z

    iget-object v7, v1, Lcom/github/catvod/spider/appysv2/b/A;->a:Ljava/lang/String;

    const/4 v8, 0x7

    new-array v9, v8, [B

    const/16 v10, -0x7c

    aput-byte v10, v9, v4

    const/16 v10, -0x4a

    aput-byte v10, v9, v6

    const/4 v11, 0x2

    const/16 v12, 0x39

    aput-byte v12, v9, v11

    const/4 v13, 0x3

    const/4 v14, 0x5

    aput-byte v14, v9, v13

    const/4 v15, 0x4

    const/16 v16, -0x2e

    aput-byte v16, v9, v15

    const/16 v17, 0x2b

    aput-byte v17, v9, v14

    const/4 v12, 0x6

    aput-byte v16, v9, v12

    new-array v8, v5, [B

    const/16 v19, -0x9

    aput-byte v19, v8, v4

    const/16 v20, -0x22

    aput-byte v20, v8, v6

    const/16 v21, 0x58

    aput-byte v21, v8, v11

    const/16 v22, 0x77

    aput-byte v22, v8, v13

    const/16 v22, -0x49

    aput-byte v22, v8, v15

    const/16 v22, 0x42

    aput-byte v22, v8, v14

    aput-byte v10, v8, v12

    const/16 v18, 0x7

    aput-byte v19, v8, v18

    invoke-static {v9, v8}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v8

    invoke-direct {v1, v7, v8}, Lcom/github/catvod/spider/appysv2/b/A;->m(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    iget-object v8, v1, Lcom/github/catvod/spider/appysv2/b/A;->a:Ljava/lang/String;

    new-array v9, v11, [B

    const/16 v22, -0x80

    aput-byte v22, v9, v4

    const/16 v23, -0x1e

    aput-byte v23, v9, v6

    new-array v10, v5, [B

    const/16 v24, -0xb

    aput-byte v24, v10, v4

    const/16 v25, -0x77

    aput-byte v25, v10, v6

    const/16 v26, 0x27

    aput-byte v26, v10, v11

    const/16 v27, -0x6c

    aput-byte v27, v10, v13

    aput-byte v4, v10, v15

    const/16 v27, -0x32

    aput-byte v27, v10, v14

    const/16 v27, -0x54

    aput-byte v27, v10, v12

    const/16 v28, -0xe

    const/16 v18, 0x7

    aput-byte v28, v10, v18

    invoke-static {v9, v10}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v9

    invoke-direct {v1, v8, v9}, Lcom/github/catvod/spider/appysv2/b/A;->m(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    iget-object v9, v1, Lcom/github/catvod/spider/appysv2/b/A;->a:Ljava/lang/String;

    new-array v10, v14, [B

    aput-byte v27, v10, v4

    const/16 v28, -0x13

    aput-byte v28, v10, v6

    const/16 v28, -0x6e

    aput-byte v28, v10, v11

    const/16 v29, 0x6d

    aput-byte v29, v10, v13

    const/16 v29, 0x7c

    aput-byte v29, v10, v15

    new-array v12, v5, [B

    const/16 v30, -0x21

    aput-byte v30, v12, v4

    const/16 v31, -0x78

    aput-byte v31, v12, v6

    const/16 v32, -0x7

    aput-byte v32, v12, v11

    aput-byte v5, v12, v13

    aput-byte v14, v12, v15

    const/16 v32, 0x4d

    aput-byte v32, v12, v14

    const/16 v32, 0x59

    const/16 v29, 0x6

    aput-byte v32, v12, v29

    const/16 v32, -0x1c

    const/16 v18, 0x7

    aput-byte v32, v12, v18

    invoke-static {v10, v12}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v10

    invoke-direct {v1, v9, v10}, Lcom/github/catvod/spider/appysv2/b/A;->m(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    new-instance v10, Ljava/lang/StringBuilder;

    invoke-direct {v10}, Ljava/lang/StringBuilder;-><init>()V

    const/16 v12, 0x2d

    new-array v12, v12, [B

    const/16 v32, -0x6d

    aput-byte v32, v12, v4

    const/16 v32, 0x3c

    aput-byte v32, v12, v6

    const/16 v32, -0x6f

    aput-byte v32, v12, v11

    const/16 v32, -0x11

    aput-byte v32, v12, v13

    const/16 v32, 0x20

    aput-byte v32, v12, v15

    const/16 v32, 0xe

    aput-byte v32, v12, v14

    const/16 v33, -0x32

    const/16 v29, 0x6

    aput-byte v33, v12, v29

    const/16 v33, -0x75

    const/16 v18, 0x7

    aput-byte v33, v12, v18

    aput-byte v33, v12, v5

    const/16 v34, 0x29

    const/16 v35, 0x9

    aput-byte v34, v12, v35

    const/16 v34, 0xa

    aput-byte v33, v12, v34

    const/16 v36, -0x4f

    const/16 v37, 0xb

    aput-byte v36, v12, v37

    const/16 v36, 0x31

    const/16 v38, 0xc

    aput-byte v36, v12, v38

    const/16 v36, 0x55

    const/16 v39, 0xd

    aput-byte v36, v12, v39

    aput-byte v31, v12, v32

    const/16 v40, -0x40

    const/16 v14, 0xf

    aput-byte v40, v12, v14

    const/16 v40, 0x10

    const/16 v42, -0x72

    aput-byte v42, v12, v40

    const/16 v40, 0x66

    const/16 v42, 0x11

    aput-byte v40, v12, v42

    const/16 v40, -0x7a

    const/16 v43, 0x12

    aput-byte v40, v12, v43

    const/16 v40, 0x13

    const/16 v44, -0x10

    aput-byte v44, v12, v40

    const/16 v40, 0x14

    const/16 v44, 0x3e

    aput-byte v44, v12, v40

    const/16 v40, 0x1b

    const/16 v44, 0x15

    aput-byte v40, v12, v44

    const/16 v40, 0x16

    aput-byte v28, v12, v40

    const/16 v40, -0x34

    const/16 v45, 0x17

    aput-byte v40, v12, v45

    const/16 v40, 0x18

    const/16 v46, -0x66

    aput-byte v46, v12, v40

    const/16 v40, 0x19

    const/16 v46, 0x3a

    aput-byte v46, v12, v40

    const/16 v40, 0x1a

    aput-byte v22, v12, v40

    const/16 v40, 0x1b

    const/16 v46, -0x50

    aput-byte v46, v12, v40

    const/16 v40, 0x1c

    aput-byte v26, v12, v40

    const/16 v40, 0x1d

    const/16 v46, 0x46

    aput-byte v46, v12, v40

    const/16 v40, 0x1e

    aput-byte v22, v12, v40

    const/16 v40, 0x1f

    const/16 v46, -0x36

    aput-byte v46, v12, v40

    const/16 v40, 0x20

    aput-byte v31, v12, v40

    const/16 v40, 0x21

    const/16 v46, 0x2e

    aput-byte v46, v12, v40

    const/16 v40, 0x22

    aput-byte v22, v12, v40

    const/16 v40, 0x23

    const/16 v46, -0x13

    aput-byte v46, v12, v40

    const/16 v40, 0x24

    const/16 v46, 0x6c

    aput-byte v46, v12, v40

    const/16 v40, 0x25

    const/16 v46, 0x47

    aput-byte v46, v12, v40

    const/16 v40, 0x26

    aput-byte v25, v12, v40

    const/16 v40, -0x3b

    aput-byte v40, v12, v26

    const/16 v40, 0x28

    aput-byte v25, v12, v40

    const/16 v40, 0x29

    const/16 v46, 0x2d

    aput-byte v46, v12, v40

    const/16 v40, -0x74

    const/16 v46, 0x2a

    aput-byte v40, v12, v46

    const/16 v40, 0x2b

    const/16 v47, -0x5

    aput-byte v47, v12, v40

    const/16 v40, 0x2c

    const/16 v47, 0x6e

    aput-byte v47, v12, v40

    new-array v14, v5, [B

    const/16 v47, -0x5

    aput-byte v47, v14, v4

    const/16 v47, 0x48

    aput-byte v47, v14, v6

    const/16 v47, -0x1b

    aput-byte v47, v14, v11

    const/16 v47, -0x61

    aput-byte v47, v14, v13

    const/16 v47, 0x53

    aput-byte v47, v14, v15

    const/16 v47, 0x34

    const/16 v41, 0x5

    aput-byte v47, v14, v41

    const/16 v47, -0x1f

    const/16 v29, 0x6

    aput-byte v47, v14, v29

    const/16 v47, -0x5c

    const/16 v18, 0x7

    aput-byte v47, v14, v18

    invoke-static {v12, v14}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v12

    invoke-virtual {v10, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v10, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x6

    new-array v12, v7, [B

    const/16 v7, 0x67

    aput-byte v7, v12, v4

    const/16 v7, -0x33

    aput-byte v7, v12, v6

    aput-byte v46, v12, v11

    const/16 v7, -0x1c

    aput-byte v7, v12, v13

    aput-byte v5, v12, v15

    const/16 v7, 0x78

    const/4 v14, 0x5

    aput-byte v7, v12, v14

    new-array v7, v5, [B

    const/16 v14, 0x41

    aput-byte v14, v7, v4

    const/16 v14, -0x55

    aput-byte v14, v7, v6

    aput-byte v21, v7, v11

    aput-byte v33, v7, v13

    const/16 v14, 0x65

    aput-byte v14, v7, v15

    const/16 v14, 0x45

    const/16 v33, 0x5

    aput-byte v14, v7, v33

    const/16 v14, -0x57

    const/16 v29, 0x6

    aput-byte v14, v7, v29

    const/16 v14, 0x56

    const/4 v5, 0x7

    aput-byte v14, v7, v5

    invoke-static {v12, v7}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v10, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v10, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    new-array v7, v5, [B

    const/4 v5, -0x8

    aput-byte v5, v7, v4

    const/16 v5, -0x49

    aput-byte v5, v7, v6

    aput-byte v22, v7, v11

    aput-byte v24, v7, v13

    const/16 v5, 0x2c

    aput-byte v5, v7, v15

    const/16 v5, -0x69

    const/4 v8, 0x5

    aput-byte v5, v7, v8

    const/16 v5, 0x32

    const/4 v8, 0x6

    aput-byte v5, v7, v8

    const/16 v5, 0x8

    new-array v8, v5, [B

    aput-byte v20, v8, v4

    const/16 v5, -0x3c

    aput-byte v5, v8, v6

    const/16 v5, -0x1b

    aput-byte v5, v8, v11

    const/16 v5, -0x62

    aput-byte v5, v8, v13

    const/16 v5, 0x49

    aput-byte v5, v8, v15

    const/16 v5, -0x12

    const/4 v12, 0x5

    aput-byte v5, v8, v12

    const/16 v5, 0xf

    const/4 v12, 0x6

    aput-byte v5, v8, v12

    const/16 v5, -0x4d

    const/4 v12, 0x7

    aput-byte v5, v8, v12

    invoke-static {v7, v8}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v10, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v10, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v5, 0x3a

    new-array v5, v5, [B

    const/4 v7, -0x8

    aput-byte v7, v5, v4

    const/16 v7, 0x1f

    aput-byte v7, v5, v6

    aput-byte v30, v5, v11

    const/16 v7, -0x2a

    aput-byte v7, v5, v13

    const/16 v7, -0x24

    aput-byte v7, v5, v15

    const/16 v7, 0x72

    const/4 v8, 0x5

    aput-byte v7, v5, v8

    const/16 v7, 0x7e

    const/4 v8, 0x6

    aput-byte v7, v5, v8

    const/4 v7, 0x7

    aput-byte v21, v5, v7

    const/16 v8, -0x45

    const/16 v9, 0x8

    aput-byte v8, v5, v9

    aput-byte v7, v5, v35

    aput-byte v16, v5, v34

    const/16 v7, -0x23

    aput-byte v7, v5, v37

    const/16 v7, -0x27

    aput-byte v7, v5, v38

    const/16 v7, 0x7b

    aput-byte v7, v5, v39

    const/16 v7, 0x65

    aput-byte v7, v5, v32

    const/16 v7, 0x57

    const/16 v8, 0xf

    aput-byte v7, v5, v8

    const/16 v7, 0x10

    const/16 v8, -0x53

    aput-byte v8, v5, v7

    aput-byte v35, v5, v42

    aput-byte v30, v5, v43

    const/16 v7, 0x13

    const/16 v8, -0x2f

    aput-byte v8, v5, v7

    const/16 v7, 0x14

    const/16 v8, -0x6c

    aput-byte v8, v5, v7

    const/16 v7, 0x33

    aput-byte v7, v5, v44

    const/16 v7, 0x16

    const/16 v8, 0x65

    aput-byte v8, v5, v7

    aput-byte v36, v5, v45

    const/16 v7, 0x18

    const/16 v8, -0x4a

    aput-byte v8, v5, v7

    const/16 v7, 0x19

    aput-byte v42, v5, v7

    const/16 v7, 0x1a

    aput-byte v30, v5, v7

    const/16 v7, 0x1b

    const/16 v8, -0x24

    aput-byte v8, v5, v7

    const/16 v7, 0x1c

    const/16 v8, -0x34

    aput-byte v8, v5, v7

    const/16 v7, 0x1d

    const/16 v8, 0x6e

    aput-byte v8, v5, v7

    const/16 v7, 0x1e

    const/16 v8, 0x7e

    aput-byte v8, v5, v7

    const/16 v7, 0x1f

    aput-byte v36, v5, v7

    const/16 v7, 0x20

    const/16 v8, -0x4a

    aput-byte v8, v5, v7

    const/16 v7, 0x21

    const/4 v8, 0x5

    aput-byte v8, v5, v7

    const/16 v7, 0x22

    aput-byte v30, v5, v7

    const/16 v7, 0x23

    aput-byte v20, v5, v7

    const/16 v7, 0x24

    const/16 v8, -0x34

    aput-byte v8, v5, v7

    const/16 v7, 0x25

    const/16 v8, 0x6b

    aput-byte v8, v5, v7

    const/16 v7, 0x26

    const/16 v8, 0x65

    aput-byte v8, v5, v7

    const/16 v7, 0x41

    aput-byte v7, v5, v26

    const/16 v7, 0x28

    const/16 v8, -0x45

    aput-byte v8, v5, v7

    const/16 v7, 0x29

    aput-byte v43, v5, v7

    const/16 v7, -0x74

    aput-byte v7, v5, v46

    const/16 v7, 0x2b

    const/16 v8, -0x7d

    aput-byte v8, v5, v7

    const/16 v7, 0x2c

    const/16 v8, -0x71

    aput-byte v8, v5, v7

    const/16 v7, 0x2d

    const/16 v8, 0x63

    aput-byte v8, v5, v7

    const/16 v7, 0x2e

    const/16 v8, 0x33

    aput-byte v8, v5, v7

    const/16 v7, 0x2f

    const/16 v8, 0x46

    aput-byte v8, v5, v7

    const/16 v7, 0x30

    const/16 v8, -0x7f

    aput-byte v8, v5, v7

    const/16 v7, 0x31

    const/16 v8, 0x19

    aput-byte v8, v5, v7

    const/16 v7, 0x32

    const/16 v8, -0x2b

    aput-byte v8, v5, v7

    const/16 v7, 0x33

    const/16 v8, -0x71

    aput-byte v8, v5, v7

    const/16 v7, 0x34

    const/16 v8, -0x65

    aput-byte v8, v5, v7

    const/16 v7, 0x35

    const/16 v8, 0x37

    aput-byte v8, v5, v7

    const/16 v7, 0x36

    const/16 v8, 0x73

    aput-byte v8, v5, v7

    const/16 v7, 0x37

    aput-byte v13, v5, v7

    const/16 v7, 0x38

    const/16 v8, -0x14

    aput-byte v8, v5, v7

    const/16 v7, 0x48

    const/16 v8, 0x39

    aput-byte v7, v5, v8

    const/16 v7, 0x8

    new-array v8, v7, [B

    aput-byte v20, v8, v4

    const/16 v7, 0x70

    aput-byte v7, v8, v6

    const/16 v7, -0x4f

    aput-byte v7, v8, v11

    const/16 v7, -0x4e

    aput-byte v7, v8, v13

    const/16 v7, -0x57

    aput-byte v7, v8, v15

    const/4 v7, 0x5

    aput-byte v11, v8, v7

    const/16 v7, 0x43

    const/4 v9, 0x6

    aput-byte v7, v8, v9

    const/16 v7, 0x36

    const/4 v9, 0x7

    aput-byte v7, v8, v9

    invoke-static {v5, v8}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v10, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v10}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    new-instance v7, Ljava/util/HashMap;

    invoke-direct {v7}, Ljava/util/HashMap;-><init>()V

    new-instance v8, Ljava/util/ArrayList;

    invoke-direct {v8}, Ljava/util/ArrayList;-><init>()V

    invoke-virtual {v8, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    const/16 v9, 0x8

    new-array v10, v9, [B

    const/16 v9, 0x6e

    aput-byte v9, v10, v4

    const/16 v9, 0x4e

    aput-byte v9, v10, v6

    aput-byte v16, v10, v11

    aput-byte v31, v10, v13

    const/16 v9, -0x58

    aput-byte v9, v10, v15

    const/16 v9, -0x62

    const/4 v12, 0x5

    aput-byte v9, v10, v12

    const/16 v9, -0x63

    const/4 v12, 0x6

    aput-byte v9, v10, v12

    const/16 v9, 0x6a

    const/4 v12, 0x7

    aput-byte v9, v10, v12

    const/16 v9, 0x8

    new-array v12, v9, [B

    aput-byte v9, v12, v4

    const/16 v9, 0x3d

    aput-byte v9, v12, v6

    const/16 v9, -0x45

    aput-byte v9, v12, v11

    const/16 v9, -0x14

    aput-byte v9, v12, v13

    const/16 v9, -0x3c

    aput-byte v9, v12, v15

    const/4 v9, 0x5

    aput-byte v19, v12, v9

    const/16 v9, -0x12

    const/4 v14, 0x6

    aput-byte v9, v12, v14

    const/16 v9, 0x1e

    const/4 v14, 0x7

    aput-byte v9, v12, v14

    invoke-static {v10, v12}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v8}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v7, v9, v8}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    new-array v8, v15, [B

    const/16 v9, 0x66

    aput-byte v9, v8, v4

    const/16 v9, 0x5c

    aput-byte v9, v8, v6

    const/4 v9, 0x6

    aput-byte v9, v8, v11

    const/16 v9, 0x39

    aput-byte v9, v8, v13

    const/16 v9, 0x8

    new-array v10, v9, [B

    const/16 v9, 0x16

    aput-byte v9, v10, v4

    const/16 v9, 0x3d

    aput-byte v9, v10, v6

    const/16 v9, 0x72

    aput-byte v9, v10, v11

    const/16 v9, 0x51

    aput-byte v9, v10, v13

    const/16 v9, 0x61

    aput-byte v9, v10, v15

    const/4 v9, 0x5

    aput-byte v11, v10, v9

    const/16 v9, -0x10

    const/4 v12, 0x6

    aput-byte v9, v10, v12

    const/4 v9, 0x7

    aput-byte v34, v10, v9

    invoke-static {v8, v10}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v8

    sget-object v9, Lcom/github/catvod/spider/appysv2/b/A;->e:Ljava/lang/String;

    invoke-virtual {v7, v8, v9}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    new-instance v8, Lorg/json/JSONObject;

    invoke-direct/range {p0 .. p0}, Lcom/github/catvod/spider/appysv2/b/A;->f()Ljava/util/Map;

    move-result-object v9

    invoke-static {v5, v7, v9}, Lcom/github/catvod/spider/appysv2/n/c;->h(Ljava/lang/String;Ljava/util/Map;Ljava/util/Map;)Lcom/github/catvod/spider/appysv2/n/e;

    move-result-object v5

    invoke-virtual {v5}, Lcom/github/catvod/spider/appysv2/n/e;->a()Ljava/lang/String;

    move-result-object v5

    invoke-direct {v8, v5}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x5

    new-array v7, v5, [B

    const/4 v5, -0x4

    aput-byte v5, v7, v4

    const/16 v5, 0x6e

    aput-byte v5, v7, v6

    const/16 v5, -0x35

    aput-byte v5, v7, v11

    const/16 v5, -0x70

    aput-byte v5, v7, v13

    const/16 v5, 0x67

    aput-byte v5, v7, v15

    const/16 v5, 0x8

    new-array v9, v5, [B

    const/16 v5, -0x67

    aput-byte v5, v9, v4

    const/16 v5, 0x1c

    aput-byte v5, v9, v6

    const/16 v5, -0x47

    aput-byte v5, v9, v11

    const/4 v5, -0x2

    aput-byte v5, v9, v13

    const/16 v5, 0x8

    aput-byte v5, v9, v15

    const/16 v5, 0x59

    const/4 v10, 0x5

    aput-byte v5, v9, v10

    const/16 v5, 0x40

    const/4 v10, 0x6

    aput-byte v5, v9, v10

    const/16 v5, 0x2c

    const/4 v10, 0x7

    aput-byte v5, v9, v10

    invoke-static {v7, v9}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v8, v5}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;)I

    move-result v5

    if-nez v5, :cond_584

    const/4 v5, 0x5

    new-array v7, v5, [B

    const/16 v5, 0x5c

    aput-byte v5, v7, v4

    aput-byte v4, v7, v6

    const/16 v5, 0x4d

    aput-byte v5, v7, v11

    const/16 v5, -0x1a

    aput-byte v5, v7, v13

    const/16 v5, -0xd

    aput-byte v5, v7, v15

    const/16 v5, 0x8

    new-array v9, v5, [B

    const/16 v5, 0x39

    aput-byte v5, v9, v4

    const/16 v10, 0x78

    aput-byte v10, v9, v6

    aput-byte v5, v9, v11

    const/16 v5, -0x6c

    aput-byte v5, v9, v13

    aput-byte v28, v9, v15

    const/16 v5, -0x7d

    const/4 v10, 0x5

    aput-byte v5, v9, v10

    const/16 v5, -0x7e

    const/4 v10, 0x6

    aput-byte v5, v9, v10

    const/16 v5, 0x49

    const/4 v10, 0x7

    aput-byte v5, v9, v10

    invoke-static {v7, v9}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v8, v5}, Lorg/json/JSONObject;->optJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v5

    new-array v7, v15, [B

    aput-byte v19, v7, v4

    const/16 v8, 0x7e

    aput-byte v8, v7, v6

    const/16 v8, 0x4e

    aput-byte v8, v7, v11

    const/16 v8, 0x7d

    aput-byte v8, v7, v13

    const/16 v8, 0x8

    new-array v9, v8, [B

    const/16 v8, -0x65

    aput-byte v8, v9, v4

    aput-byte v45, v9, v6

    const/16 v8, 0x3d

    aput-byte v8, v9, v11

    aput-byte v35, v9, v13

    aput-byte v24, v9, v15

    const/16 v8, -0x37

    const/4 v10, 0x5

    aput-byte v8, v9, v10

    const/4 v8, 0x6

    aput-byte v43, v9, v8

    const/16 v8, -0x5b

    const/4 v10, 0x7

    aput-byte v8, v9, v10

    invoke-static {v7, v9}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v5, v7}, Lorg/json/JSONObject;->optJSONArray(Ljava/lang/String;)Lorg/json/JSONArray;

    move-result-object v5

    invoke-virtual {v5, v4}, Lorg/json/JSONArray;->optJSONObject(I)Lorg/json/JSONObject;

    move-result-object v5

    new-array v7, v11, [B

    const/16 v8, -0x29

    aput-byte v8, v7, v4

    const/16 v8, -0x79

    aput-byte v8, v7, v6

    const/16 v8, 0x8

    new-array v9, v8, [B

    const/16 v8, -0x5d

    aput-byte v8, v9, v4

    const/16 v8, -0x18

    aput-byte v8, v9, v6

    const/16 v6, -0x3a

    aput-byte v6, v9, v11

    const/16 v6, 0x39

    aput-byte v6, v9, v13

    const/16 v6, -0x7d

    aput-byte v6, v9, v15

    const/4 v6, 0x5

    aput-byte v19, v9, v6

    const/16 v6, 0x62

    const/4 v8, 0x6

    aput-byte v6, v9, v8

    const/16 v6, 0x4f

    const/4 v8, 0x7

    aput-byte v6, v9, v8

    invoke-static {v7, v9}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v5, v6}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    invoke-static {v5}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v6

    if-eqz v6, :cond_57f

    if-eqz p2, :cond_57f

    invoke-direct {v1, v2, v4}, Lcom/github/catvod/spider/appysv2/b/A;->a(Ljava/lang/String;Z)Lcom/github/catvod/spider/appysv2/c/e;

    move-result-object v2

    return-object v2

    :cond_57f
    invoke-virtual {v3, v5}, Lcom/github/catvod/spider/appysv2/c/e;->f(Ljava/lang/Object;)V

    goto/16 :goto_845

    :cond_584
    const/4 v2, 0x5

    new-array v5, v2, [B

    aput-byte v21, v5, v4

    const/16 v2, -0x60

    aput-byte v2, v5, v6

    const/16 v2, -0x3b

    aput-byte v2, v5, v11

    const/16 v2, 0x41

    aput-byte v2, v5, v13

    const/16 v2, 0x3a

    aput-byte v2, v5, v15

    const/16 v2, 0x8

    new-array v7, v2, [B

    const/16 v2, 0x3d

    aput-byte v2, v7, v4

    aput-byte v16, v7, v6

    const/16 v2, -0x49

    aput-byte v2, v7, v11

    const/16 v2, 0x2f

    aput-byte v2, v7, v13

    aput-byte v36, v7, v15

    const/16 v2, -0x7e

    const/4 v9, 0x5

    aput-byte v2, v7, v9

    const/4 v2, 0x6

    aput-byte v46, v7, v2

    const/16 v2, -0x1a

    const/4 v9, 0x7

    aput-byte v2, v7, v9

    invoke-static {v5, v7}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v8, v2}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;)I

    move-result v2

    if-ne v2, v11, :cond_779

    const/16 v2, 0x8

    new-array v5, v2, [B

    const/16 v2, -0x55

    aput-byte v2, v5, v4

    const/16 v2, 0x38

    aput-byte v2, v5, v6

    const/16 v2, -0x20

    aput-byte v2, v5, v11

    const/16 v2, 0x78

    aput-byte v2, v5, v13

    const/16 v2, 0x47

    aput-byte v2, v5, v15

    const/16 v2, 0x38

    const/4 v7, 0x5

    aput-byte v2, v5, v7

    const/16 v2, 0x4d

    const/4 v7, 0x6

    aput-byte v2, v5, v7

    const/16 v2, -0x27

    const/4 v7, 0x7

    aput-byte v2, v5, v7

    const/16 v2, 0x8

    new-array v7, v2, [B

    const/16 v2, -0x28

    aput-byte v2, v7, v4

    const/16 v2, 0x50

    aput-byte v2, v7, v6

    const/16 v2, -0x71

    aput-byte v2, v7, v11

    const/16 v2, 0xf

    aput-byte v2, v7, v13

    const/16 v2, 0x18

    aput-byte v2, v7, v15

    const/4 v2, 0x5

    aput-byte v36, v7, v2

    const/16 v2, 0x3e

    const/4 v9, 0x6

    aput-byte v2, v7, v9

    const/16 v2, -0x42

    const/4 v9, 0x7

    aput-byte v2, v7, v9

    invoke-static {v5, v7}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v8, v2}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v3, v2}, Lcom/github/catvod/spider/appysv2/c/e;->g(Ljava/lang/String;)V

    const/16 v2, 0x8

    new-array v5, v2, [B

    aput-byte v4, v5, v4

    const/4 v2, -0x1

    aput-byte v2, v5, v6

    const/16 v2, 0x63

    aput-byte v2, v5, v11

    const/16 v2, 0x24

    aput-byte v2, v5, v13

    const/16 v2, 0x60

    aput-byte v2, v5, v15

    const/16 v2, -0x2b

    const/4 v7, 0x5

    aput-byte v2, v5, v7

    const/16 v2, -0x7b

    const/4 v7, 0x6

    aput-byte v2, v5, v7

    const/4 v2, 0x7

    aput-byte v28, v5, v2

    const/16 v2, 0x8

    new-array v7, v2, [B

    const/16 v2, 0x73

    aput-byte v2, v7, v4

    const/16 v2, -0x69

    aput-byte v2, v7, v6

    aput-byte v38, v7, v11

    const/16 v2, 0x53

    aput-byte v2, v7, v13

    const/16 v2, 0x3f

    aput-byte v2, v7, v15

    const/16 v2, -0x48

    const/4 v9, 0x5

    aput-byte v2, v7, v9

    const/16 v2, -0xa

    const/4 v9, 0x6

    aput-byte v2, v7, v9

    const/4 v2, 0x7

    aput-byte v24, v7, v2

    invoke-static {v5, v7}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v8, v2}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    const/16 v5, 0xf

    new-array v7, v5, [B

    const/16 v5, -0xf

    aput-byte v5, v7, v4

    aput-byte v27, v7, v6

    const/16 v5, -0x5d

    aput-byte v5, v7, v11

    aput-byte v46, v7, v13

    aput-byte v13, v7, v15

    const/16 v5, -0x44

    const/4 v8, 0x5

    aput-byte v5, v7, v8

    const/16 v5, -0x4e

    const/4 v8, 0x6

    aput-byte v5, v7, v8

    const/16 v5, -0x3a

    const/4 v8, 0x7

    aput-byte v5, v7, v8

    const/16 v5, -0x5b

    const/16 v8, 0x8

    aput-byte v5, v7, v8

    aput-byte v30, v7, v35

    aput-byte v25, v7, v34

    const/16 v5, 0x56

    aput-byte v5, v7, v37

    const/16 v5, 0x5d

    aput-byte v5, v7, v38

    const/16 v5, -0x6a

    aput-byte v5, v7, v39

    const/4 v5, -0x1

    aput-byte v5, v7, v32

    const/16 v5, 0x8

    new-array v8, v5, [B

    aput-byte v45, v8, v4

    const/16 v5, 0x3a

    aput-byte v5, v8, v6

    const/16 v5, 0x24

    aput-byte v5, v8, v11

    const/16 v5, -0x32

    aput-byte v5, v8, v13

    const/16 v5, -0x48

    aput-byte v5, v8, v15

    const/4 v5, 0x5

    aput-byte v34, v8, v5

    const/16 v5, 0x57

    const/4 v9, 0x6

    aput-byte v5, v8, v9

    const/16 v5, 0x71

    const/4 v9, 0x7

    aput-byte v5, v8, v9

    invoke-static {v7, v8}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v2, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_774

    const/16 v2, 0x1b

    new-array v2, v2, [B

    const/16 v5, -0x30

    aput-byte v5, v2, v4

    const/16 v5, -0xd

    aput-byte v5, v2, v6

    const/16 v5, 0x64

    aput-byte v5, v2, v11

    const/16 v5, 0x1c

    aput-byte v5, v2, v13

    aput-byte v42, v2, v15

    const/16 v5, -0x33

    const/4 v7, 0x5

    aput-byte v5, v2, v7

    const/16 v5, -0x2d

    const/4 v7, 0x6

    aput-byte v5, v2, v7

    const/16 v5, -0x5a

    const/4 v7, 0x7

    aput-byte v5, v2, v7

    const/16 v5, -0x4b

    const/16 v7, 0x8

    aput-byte v5, v2, v7

    aput-byte v27, v2, v35

    const/16 v5, 0x75

    aput-byte v5, v2, v34

    const/16 v5, 0x71

    aput-byte v5, v2, v37

    const/16 v5, 0x6d

    aput-byte v5, v2, v38

    const/16 v5, -0x1b

    aput-byte v5, v2, v39

    const/16 v5, -0x61

    aput-byte v5, v2, v32

    const/16 v5, -0x31

    const/16 v7, 0xf

    aput-byte v5, v2, v7

    const/16 v5, 0x10

    const/16 v7, -0x7d

    aput-byte v7, v2, v5

    const/4 v5, -0x6

    aput-byte v5, v2, v42

    aput-byte v32, v2, v43

    const/16 v5, 0x13

    const/16 v7, 0x60

    aput-byte v7, v2, v5

    const/16 v5, 0x14

    aput-byte v6, v2, v5

    const/16 v5, -0x79

    aput-byte v5, v2, v44

    const/16 v5, 0x16

    const/16 v7, -0x43

    aput-byte v7, v2, v5

    aput-byte v27, v2, v45

    const/16 v5, 0x18

    const/16 v7, -0x30

    aput-byte v7, v2, v5

    const/16 v5, 0x19

    const/16 v7, -0xf

    aput-byte v7, v2, v5

    const/16 v5, 0x1a

    const/16 v7, 0x42

    aput-byte v7, v2, v5

    const/16 v5, 0x8

    new-array v7, v5, [B

    const/16 v5, 0x34

    aput-byte v5, v7, v4

    const/16 v4, 0x4b

    aput-byte v4, v7, v6

    const/16 v4, -0x17

    aput-byte v4, v7, v11

    const/4 v4, -0x6

    aput-byte v4, v7, v13

    const/16 v4, -0x7b

    aput-byte v4, v7, v15

    const/16 v4, 0x62

    const/4 v5, 0x5

    aput-byte v4, v7, v5

    const/16 v4, 0x35

    const/4 v5, 0x6

    aput-byte v4, v7, v5

    const/4 v4, 0x7

    aput-byte v46, v7, v4

    invoke-static {v2, v7}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v3, v2}, Lcom/github/catvod/spider/appysv2/c/e;->g(Ljava/lang/String;)V

    :cond_774
    invoke-virtual {v3, v11}, Lcom/github/catvod/spider/appysv2/c/e;->e(I)V

    goto/16 :goto_845

    :cond_779
    const/4 v2, 0x5

    new-array v5, v2, [B

    const/16 v2, 0x64

    aput-byte v2, v5, v4

    const/16 v2, -0x59

    aput-byte v2, v5, v6

    const/16 v2, 0x67

    aput-byte v2, v5, v11

    const/16 v2, 0x6a

    aput-byte v2, v5, v13

    const/16 v2, 0x5a

    aput-byte v2, v5, v15

    const/16 v2, 0x8

    new-array v7, v2, [B

    aput-byte v6, v7, v4

    const/16 v2, -0x2b

    aput-byte v2, v7, v6

    aput-byte v44, v7, v11

    aput-byte v15, v7, v13

    const/16 v2, 0x35

    aput-byte v2, v7, v15

    const/16 v2, -0x19

    const/4 v9, 0x5

    aput-byte v2, v7, v9

    const/16 v2, -0x5f

    const/4 v9, 0x6

    aput-byte v2, v7, v9

    const/16 v2, 0xf

    const/4 v9, 0x7

    aput-byte v2, v7, v9

    invoke-static {v5, v7}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v8, v2}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;)I

    move-result v2

    invoke-virtual {v3, v2}, Lcom/github/catvod/spider/appysv2/c/e;->e(I)V

    const/16 v2, 0x8

    new-array v5, v2, [B

    const/16 v2, -0xc

    aput-byte v2, v5, v4

    const/16 v2, 0x54

    aput-byte v2, v5, v6

    const/16 v2, -0x6f

    aput-byte v2, v5, v11

    const/16 v2, 0x28

    aput-byte v2, v5, v13

    const/16 v2, -0x72

    aput-byte v2, v5, v15

    const/16 v2, 0x22

    const/4 v7, 0x5

    aput-byte v2, v5, v7

    const/4 v2, 0x6

    aput-byte v4, v5, v2

    const/4 v7, 0x7

    aput-byte v2, v5, v7

    const/16 v2, 0x8

    new-array v7, v2, [B

    const/16 v2, -0x79

    aput-byte v2, v7, v4

    const/16 v2, 0x3c

    aput-byte v2, v7, v6

    const/4 v2, -0x2

    aput-byte v2, v7, v11

    const/16 v2, 0x5f

    aput-byte v2, v7, v13

    const/16 v2, -0x2f

    aput-byte v2, v7, v15

    const/16 v2, 0x4f

    const/4 v4, 0x5

    aput-byte v2, v7, v4

    const/16 v2, 0x73

    const/4 v4, 0x6

    aput-byte v2, v7, v4

    const/16 v2, 0x61

    const/4 v4, 0x7

    aput-byte v2, v7, v4

    invoke-static {v5, v7}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v8, v2}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v3, v2}, Lcom/github/catvod/spider/appysv2/c/e;->g(Ljava/lang/String;)V
    :try_end_810
    .catch Ljava/lang/Exception; {:try_start_10 .. :try_end_810} :catch_811

    goto :goto_845

    :catch_811
    move-exception v0

    move-object v2, v0

    const/16 v4, 0x1f4

    invoke-virtual {v3, v4}, Lcom/github/catvod/spider/appysv2/c/e;->e(I)V

    invoke-virtual {v2}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Lcom/github/catvod/spider/appysv2/c/e;->g(Ljava/lang/String;)V

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const/16 v5, 0x8

    new-array v6, v5, [B

    fill-array-data v6, :array_846

    new-array v5, v5, [B

    fill-array-data v5, :array_84e

    invoke-static {v6, v5}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Lcom/github/catvod/crawler/SpiderDebug;->log(Ljava/lang/String;)V

    :goto_845
    return-object v3

    :array_846
    .array-data 1
        -0x6ft
        0x48t
        -0x47t
        -0x80t
        -0x5ft
        0x41t
        -0x34t
        0x3ft
    .end array-data

    :array_84e
    .array-data 1
        -0xet
        0x27t
        -0x37t
        -0x7t
        -0x7ft
        0x24t
        -0x42t
        0x4dt
    .end array-data
.end method

.method private b(Z)Z
    .registers 41

    const/16 v0, 0xc

    const/16 v1, 0x8

    const/4 v2, 0x0

    :try_start_5
    invoke-direct/range {p0 .. p0}, Lcom/github/catvod/spider/appysv2/b/A;->n()Lcom/github/catvod/spider/appysv2/f/a;

    const/16 v3, 0x75

    new-array v3, v3, [B

    const/16 v4, 0x52

    aput-byte v4, v3, v2

    const/16 v4, -0x54

    const/4 v5, 0x1

    aput-byte v4, v3, v5

    const/16 v4, -0x16

    const/4 v6, 0x2

    aput-byte v4, v3, v6

    const/4 v4, 0x3

    const/16 v7, 0x5d

    aput-byte v7, v3, v4

    const/16 v8, -0x1e

    const/4 v9, 0x4

    aput-byte v8, v3, v9

    const/4 v8, 0x5

    const/16 v10, 0x5e

    aput-byte v10, v3, v8

    const/4 v11, 0x6

    const/16 v12, 0x17

    aput-byte v12, v3, v11

    const/4 v13, 0x7

    const/16 v14, 0x2b

    aput-byte v14, v3, v13

    const/16 v15, 0x4a

    aput-byte v15, v3, v1

    const/16 v16, -0x47

    const/16 v17, 0x9

    aput-byte v16, v3, v17

    const/16 v16, 0xa

    const/16 v18, -0x10

    aput-byte v18, v3, v16

    const/16 v16, 0xb

    aput-byte v4, v3, v16

    const/16 v18, -0xd

    aput-byte v18, v3, v0

    const/16 v18, 0xd

    aput-byte v8, v3, v18

    const/16 v19, 0xe

    const/16 v20, 0x51

    aput-byte v20, v3, v19

    const/16 v19, 0xf

    const/16 v20, 0x60

    aput-byte v20, v3, v19

    const/16 v19, 0x10

    const/16 v21, 0x4f

    aput-byte v21, v3, v19

    const/16 v22, 0x11

    const/16 v23, -0xa

    aput-byte v23, v3, v22

    const/16 v22, 0x12

    const/16 v23, -0x3

    aput-byte v23, v3, v22

    const/16 v22, 0x42

    const/16 v23, 0x13

    aput-byte v22, v3, v23

    const/16 v22, -0x4

    const/16 v24, 0x14

    aput-byte v22, v3, v24

    const/16 v22, 0x15

    const/16 v25, 0x4b

    aput-byte v25, v3, v22

    const/16 v22, 0x16

    const/16 v25, 0x59

    aput-byte v25, v3, v22

    const/16 v22, 0x74

    aput-byte v22, v3, v12

    const/16 v26, 0x18

    const/16 v27, 0x53

    aput-byte v27, v3, v26

    const/16 v26, 0x19

    const/16 v27, -0x9

    aput-byte v27, v3, v26

    const/16 v26, 0x1a

    const/16 v27, -0xe

    aput-byte v27, v3, v26

    const/16 v26, 0x1b

    const/16 v27, 0x44

    aput-byte v27, v3, v26

    const/16 v26, 0x1c

    const/16 v27, -0x1e

    aput-byte v27, v3, v26

    const/16 v26, 0x1d

    aput-byte v19, v3, v26

    const/16 v26, 0x1e

    aput-byte v13, v3, v26

    const/16 v27, 0x1f

    const/16 v28, 0x67

    aput-byte v28, v3, v27

    const/16 v27, 0x20

    const/16 v29, 0x56

    aput-byte v29, v3, v27

    const/16 v27, 0x21

    const/16 v29, -0x4f

    aput-byte v29, v3, v27

    const/16 v27, 0x22

    const/16 v29, -0x5

    aput-byte v29, v3, v27

    const/16 v27, 0x23

    const/16 v29, 0x43

    aput-byte v29, v3, v27

    const/16 v27, 0x24

    const/16 v29, -0x1b

    aput-byte v29, v3, v27

    const/16 v27, 0x25

    aput-byte v19, v3, v27

    const/16 v27, 0x26

    const/16 v29, 0x41

    aput-byte v29, v3, v27

    const/16 v27, 0x27

    aput-byte v22, v3, v27

    const/16 v27, 0x28

    const/16 v30, 0x5f

    aput-byte v30, v3, v27

    const/16 v27, 0x29

    const/16 v30, -0x1b

    aput-byte v30, v3, v27

    const/16 v27, 0x2a

    const/16 v30, -0x52

    aput-byte v30, v3, v27

    aput-byte v16, v3, v14

    const/16 v14, 0x2c

    const/16 v27, -0x10

    aput-byte v27, v3, v14

    const/16 v14, 0x2d

    aput-byte v24, v3, v14

    const/16 v27, 0x2e

    const/16 v30, 0x48

    aput-byte v30, v3, v27

    const/16 v27, 0x2f

    const/16 v31, 0x5b

    aput-byte v31, v3, v27

    const/16 v27, 0x30

    const/16 v31, 0x53

    aput-byte v31, v3, v27

    const/16 v27, 0x31

    const/16 v31, -0x44

    aput-byte v31, v3, v27

    const/16 v27, -0x5d

    const/16 v31, 0x32

    aput-byte v27, v3, v31

    const/16 v27, 0x33

    const/16 v32, 0x1f

    aput-byte v32, v3, v27

    const/16 v27, 0x34

    const/16 v32, -0x5c

    aput-byte v32, v3, v27

    const/16 v27, 0x35

    const/16 v32, 0x54

    aput-byte v32, v3, v27

    const/16 v27, 0x36

    aput-byte v18, v3, v27

    const/16 v33, 0x37

    aput-byte v27, v3, v33

    const/16 v33, 0x38

    aput-byte v6, v3, v33

    const/16 v34, -0x2

    const/16 v35, 0x39

    aput-byte v34, v3, v35

    const/16 v34, 0x3a

    const/16 v36, -0x17

    aput-byte v36, v3, v34

    const/16 v34, 0x3b

    aput-byte v30, v3, v34

    const/16 v34, 0x3c

    const/16 v36, -0xd

    aput-byte v36, v3, v34

    const/16 v34, 0x3d

    aput-byte v25, v3, v34

    const/16 v34, 0x3e

    aput-byte v17, v3, v34

    const/16 v34, 0x3f

    const/16 v36, 0x22

    aput-byte v36, v3, v34

    const/16 v34, 0x40

    aput-byte v10, v3, v34

    const/16 v34, -0x58

    aput-byte v34, v3, v29

    const/16 v34, 0x42

    const/16 v36, -0x4d

    aput-byte v36, v3, v34

    const/16 v34, 0x43

    aput-byte v29, v3, v34

    const/16 v34, 0x44

    const/16 v36, -0x2

    aput-byte v36, v3, v34

    const/16 v34, 0x45

    aput-byte v4, v3, v34

    const/16 v36, 0x46

    const/16 v37, 0x51

    aput-byte v37, v3, v36

    const/16 v36, 0x47

    aput-byte v20, v3, v36

    aput-byte v13, v3, v30

    const/16 v36, 0x49

    const/16 v37, -0x2

    aput-byte v37, v3, v36

    const/16 v36, -0xf

    aput-byte v36, v3, v15

    const/16 v36, 0x4b

    const/16 v37, 0x5f

    aput-byte v37, v3, v36

    const/16 v36, 0x4c

    const/16 v37, -0xb

    aput-byte v37, v3, v36

    const/16 v36, 0x4d

    aput-byte v5, v3, v36

    const/16 v36, 0x4e

    aput-byte v15, v3, v36

    aput-byte v35, v3, v21

    const/16 v36, 0x50

    const/16 v37, 0x4e

    aput-byte v37, v3, v36

    const/16 v36, 0x51

    const/16 v37, -0x4f

    aput-byte v37, v3, v36

    const/16 v36, 0x52

    const/16 v37, -0xd

    aput-byte v37, v3, v36

    const/16 v36, 0x53

    aput-byte v30, v3, v36

    const/16 v36, -0x49

    aput-byte v36, v3, v32

    const/16 v36, 0x55

    aput-byte v2, v3, v36

    const/16 v36, 0x56

    aput-byte v7, v3, v36

    const/16 v36, 0x57

    const/16 v37, 0x77

    aput-byte v37, v3, v36

    const/16 v36, 0x58

    aput-byte v25, v3, v36

    const/16 v36, -0x1b

    aput-byte v36, v3, v25

    const/16 v36, 0x5a

    const/16 v38, -0x51

    aput-byte v38, v3, v36

    const/16 v36, 0x5b

    aput-byte v16, v3, v36

    const/16 v36, 0x5c

    const/16 v38, -0xb

    aput-byte v38, v3, v36

    aput-byte v18, v3, v7

    aput-byte v15, v3, v10

    const/16 v7, 0x5f

    aput-byte v35, v3, v7

    const/16 v7, 0x15

    aput-byte v7, v3, v20

    const/16 v7, 0x61

    const/16 v10, -0x54

    aput-byte v10, v3, v7

    const/16 v7, 0x62

    const/16 v10, -0x18

    aput-byte v10, v3, v7

    const/16 v7, 0x63

    aput-byte v25, v3, v7

    const/16 v7, 0x64

    const/4 v10, -0x4

    aput-byte v10, v3, v7

    const/16 v7, 0x65

    aput-byte v24, v3, v7

    const/16 v7, 0x66

    aput-byte v26, v3, v7

    const/16 v10, 0x6a

    aput-byte v10, v3, v28

    const/16 v15, 0x68

    aput-byte v21, v3, v15

    const/16 v15, 0x69

    const/16 v25, -0x4b

    aput-byte v25, v3, v15

    const/16 v15, -0x5d

    aput-byte v15, v3, v10

    const/16 v15, 0x6b

    const/16 v25, 0x1c

    aput-byte v25, v3, v15

    const/16 v15, 0x6c

    const/16 v25, -0x5f

    aput-byte v25, v3, v15

    const/16 v15, 0x6d

    aput-byte v32, v3, v15

    const/16 v15, 0x6e

    aput-byte v26, v3, v15

    const/16 v15, 0x6f

    aput-byte v22, v3, v15

    const/16 v15, 0x70

    const/16 v25, 0x5b

    aput-byte v25, v3, v15

    const/16 v15, 0x71

    const/16 v25, -0x41

    aput-byte v25, v3, v15

    const/16 v15, 0x72

    const/16 v25, -0x5

    aput-byte v25, v3, v15

    const/16 v15, 0x73

    aput-byte v19, v3, v15

    const/16 v15, -0x60

    aput-byte v15, v3, v22

    new-array v15, v1, [B

    const/16 v25, 0x3a

    aput-byte v25, v15, v2

    const/16 v25, -0x28

    aput-byte v25, v15, v5

    const/16 v25, -0x62

    aput-byte v25, v15, v6

    aput-byte v14, v15, v4

    const/16 v25, -0x6f

    aput-byte v25, v15, v9

    const/16 v25, 0x64

    aput-byte v25, v15, v8

    aput-byte v33, v15, v11

    aput-byte v9, v15, v13

    invoke-static {v3, v15}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v3

    invoke-direct/range {p0 .. p0}, Lcom/github/catvod/spider/appysv2/b/A;->f()Ljava/util/Map;

    move-result-object v15

    invoke-static {v3, v15}, Lcom/github/catvod/spider/appysv2/n/c;->m(Ljava/lang/String;Ljava/util/Map;)Ljava/lang/String;

    move-result-object v3

    invoke-static {v3}, Lcom/github/catvod/spider/appysv2/f/b;->e(Ljava/lang/String;)Lcom/github/catvod/spider/appysv2/f/b;

    move-result-object v3

    new-instance v15, Ljava/util/ArrayList;

    invoke-direct {v15}, Ljava/util/ArrayList;-><init>()V

    invoke-virtual {v3}, Lcom/github/catvod/spider/appysv2/f/b;->a()I

    move-result v25

    if-nez v25, :cond_2a9

    invoke-virtual {v3}, Lcom/github/catvod/spider/appysv2/f/b;->b()Ljava/util/List;

    move-result-object v3

    invoke-interface {v3}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v3

    :goto_293
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    move-result v25

    if-eqz v25, :cond_2a9

    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v25

    check-cast v25, Lcom/github/catvod/spider/appysv2/f/a;

    invoke-virtual/range {v25 .. v25}, Lcom/github/catvod/spider/appysv2/f/a;->c()Ljava/lang/String;

    move-result-object v14

    invoke-virtual {v15, v14}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    const/16 v14, 0x2d

    goto :goto_293

    :cond_2a9
    invoke-virtual {v15}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v3

    if-nez v3, :cond_4ea

    invoke-virtual {v15}, Ljava/util/ArrayList;->size()I

    move-result v3

    if-ge v3, v4, :cond_2b7

    goto/16 :goto_4ea

    :cond_2b7
    const/16 v3, 0x50

    new-array v3, v3, [B

    const/16 v14, 0x7b

    aput-byte v14, v3, v2

    const/16 v14, 0x50

    aput-byte v14, v3, v5

    const/16 v14, 0x7d

    aput-byte v14, v3, v6

    aput-byte v20, v3, v4

    const/16 v25, 0x71

    aput-byte v25, v3, v9

    const/16 v25, 0x6d

    aput-byte v25, v3, v8

    const/16 v25, -0x22

    aput-byte v25, v3, v11

    aput-byte v35, v3, v13

    const/16 v25, 0x63

    aput-byte v25, v3, v1

    aput-byte v34, v3, v17

    const/16 v25, 0xa

    aput-byte v28, v3, v25

    const/16 v25, 0x3e

    aput-byte v25, v3, v16

    aput-byte v20, v3, v0

    aput-byte v27, v3, v18

    const/16 v0, 0xe

    const/16 v18, -0x68

    aput-byte v18, v3, v0

    const/16 v0, 0xf

    const/16 v18, 0x72

    aput-byte v18, v3, v0

    aput-byte v7, v3, v19

    const/16 v0, 0x11

    const/16 v18, 0xa

    aput-byte v18, v3, v0

    const/16 v0, 0x12

    aput-byte v10, v3, v0

    const/16 v0, 0x7f

    aput-byte v0, v3, v23

    const/16 v18, 0x6f

    aput-byte v18, v3, v24

    const/16 v18, 0x15

    const/16 v25, 0x78

    aput-byte v25, v3, v18

    const/16 v18, 0x16

    const/16 v25, -0x70

    aput-byte v25, v3, v18

    aput-byte v7, v3, v12

    const/16 v12, 0x18

    const/16 v18, 0x7a

    aput-byte v18, v3, v12

    const/16 v12, 0x19

    aput-byte v16, v3, v12

    const/16 v12, 0x1a

    const/16 v16, 0x6f

    aput-byte v16, v3, v12

    const/16 v12, 0x1b

    const/16 v16, 0x79

    aput-byte v16, v3, v12

    const/16 v12, 0x1c

    const/16 v16, 0x6e

    aput-byte v16, v3, v12

    const/16 v12, 0x1d

    aput-byte v31, v3, v12

    const/16 v12, -0x64

    aput-byte v12, v3, v26

    const/16 v12, 0x1f

    aput-byte v37, v3, v12

    const/16 v12, 0x20

    aput-byte v14, v3, v12

    const/16 v12, 0x21

    aput-byte v34, v3, v12

    const/16 v12, 0x22

    const/16 v16, 0x6e

    aput-byte v16, v3, v12

    const/16 v12, 0x23

    const/16 v16, 0x75

    aput-byte v16, v3, v12

    const/16 v12, 0x24

    const/16 v16, 0x70

    aput-byte v16, v3, v12

    const/16 v12, 0x25

    const/16 v16, 0x68

    aput-byte v16, v3, v12

    const/16 v12, 0x26

    aput-byte v25, v3, v12

    const/16 v12, 0x27

    const/16 v16, 0x65

    aput-byte v16, v3, v12

    const/16 v12, 0x28

    aput-byte v10, v3, v12

    const/16 v12, 0x29

    const/16 v16, 0x4a

    aput-byte v16, v3, v12

    const/16 v12, 0x2a

    aput-byte v10, v3, v12

    const/16 v10, 0x2b

    const/16 v12, 0x2d

    aput-byte v12, v3, v10

    const/16 v10, 0x2c

    const/16 v16, 0x30

    aput-byte v16, v3, v10

    const/16 v10, 0x71

    aput-byte v10, v3, v12

    const/16 v10, 0x2e

    const/16 v12, -0x62

    aput-byte v12, v3, v10

    const/16 v10, 0x2f

    const/16 v12, 0x78

    aput-byte v12, v3, v10

    const/16 v10, 0x30

    aput-byte v14, v3, v10

    const/16 v10, 0x31

    aput-byte v29, v3, v10

    const/16 v10, 0x7a

    aput-byte v10, v3, v31

    const/16 v10, 0x33

    const/16 v12, 0x64

    aput-byte v12, v3, v10

    const/16 v10, 0x34

    const/16 v12, 0x3f

    aput-byte v12, v3, v10

    const/16 v10, 0x35

    const/16 v12, 0x31

    aput-byte v12, v3, v10

    aput-byte v25, v3, v27

    const/16 v10, 0x37

    aput-byte v0, v3, v10

    aput-byte v0, v3, v33

    aput-byte v6, v3, v35

    const/16 v10, 0x3a

    aput-byte v7, v3, v10

    const/16 v10, 0x3b

    aput-byte v20, v3, v10

    const/16 v10, 0x3c

    aput-byte v28, v3, v10

    const/16 v10, 0x3d

    const/16 v12, 0x25

    aput-byte v12, v3, v10

    const/16 v10, 0x3e

    aput-byte v25, v3, v10

    const/16 v10, 0x3f

    const/16 v12, 0x2b

    aput-byte v12, v3, v10

    const/16 v10, 0x40

    aput-byte v37, v3, v10

    aput-byte v29, v3, v29

    const/16 v10, 0x42

    const/16 v12, 0x65

    aput-byte v12, v3, v10

    const/16 v10, 0x43

    const/16 v12, 0x75

    aput-byte v12, v3, v10

    const/16 v10, 0x44

    const/16 v12, 0x76

    aput-byte v12, v3, v10

    aput-byte v31, v3, v34

    const/16 v10, 0x46

    const/16 v12, -0x29

    aput-byte v12, v3, v10

    const/16 v10, 0x47

    aput-byte v22, v3, v10

    aput-byte v37, v3, v30

    const/16 v10, 0x49

    const/16 v12, 0x57

    aput-byte v12, v3, v10

    const/16 v10, 0x4a

    aput-byte v14, v3, v10

    const/16 v10, 0x4b

    aput-byte v0, v3, v10

    const/16 v0, 0x4c

    const/16 v10, 0x69

    aput-byte v10, v3, v0

    const/16 v0, 0x4d

    aput-byte v31, v3, v0

    const/16 v0, 0x4e

    const/16 v10, -0x61

    aput-byte v10, v3, v0

    const/16 v0, 0x2b

    aput-byte v0, v3, v21

    new-array v0, v1, [B

    aput-byte v23, v0, v2

    const/16 v10, 0x24

    aput-byte v10, v0, v5

    aput-byte v17, v0, v6

    aput-byte v19, v0, v4

    aput-byte v6, v0, v9

    const/16 v10, 0x57

    aput-byte v10, v0, v8

    const/16 v10, -0xf

    aput-byte v10, v0, v11

    const/16 v10, 0x16

    aput-byte v10, v0, v13

    invoke-static {v3, v0}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v0

    new-instance v3, Ljava/util/HashMap;

    invoke-direct {v3}, Ljava/util/HashMap;-><init>()V

    new-array v10, v1, [B

    const/16 v12, -0x6c

    aput-byte v12, v10, v2

    aput-byte v24, v10, v5

    const/16 v12, -0x80

    aput-byte v12, v10, v6

    const/16 v12, -0x73

    aput-byte v12, v10, v4

    aput-byte v32, v10, v9

    aput-byte v26, v10, v8

    const/16 v12, -0x69

    aput-byte v12, v10, v11

    const/16 v12, 0x12

    aput-byte v12, v10, v13

    new-array v12, v1, [B

    const/16 v16, -0xe

    aput-byte v16, v12, v2

    aput-byte v14, v12, v5

    const/16 v14, -0x14

    aput-byte v14, v12, v6

    const/16 v14, -0x18

    aput-byte v14, v12, v4

    aput-byte v33, v12, v9

    aput-byte v37, v12, v8

    const/16 v14, -0x1c

    aput-byte v14, v12, v11

    aput-byte v7, v12, v13

    invoke-static {v10, v12}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v7

    new-instance v10, Lorg/json/JSONArray;

    invoke-direct {v10, v15}, Lorg/json/JSONArray;-><init>(Ljava/util/Collection;)V

    invoke-virtual {v10}, Lorg/json/JSONArray;->toString()Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v3, v7, v10}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    new-instance v7, Lorg/json/JSONObject;

    invoke-direct/range {p0 .. p0}, Lcom/github/catvod/spider/appysv2/b/A;->f()Ljava/util/Map;

    move-result-object v10

    invoke-static {v0, v3, v10}, Lcom/github/catvod/spider/appysv2/n/c;->h(Ljava/lang/String;Ljava/util/Map;Ljava/util/Map;)Lcom/github/catvod/spider/appysv2/n/e;

    move-result-object v0

    invoke-virtual {v0}, Lcom/github/catvod/spider/appysv2/n/e;->a()Ljava/lang/String;

    move-result-object v0

    invoke-direct {v7, v0}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    new-array v0, v11, [B

    const/16 v3, -0x17

    aput-byte v3, v0, v2

    const/16 v3, -0x35

    aput-byte v3, v0, v5

    const/16 v3, -0x42

    aput-byte v3, v0, v6

    const/16 v3, 0x78

    aput-byte v3, v0, v4

    const/16 v3, -0x6d

    aput-byte v3, v0, v9

    aput-byte v34, v0, v8

    new-array v3, v1, [B

    const/16 v10, -0x63

    aput-byte v10, v3, v2

    const/16 v10, -0x56

    aput-byte v10, v3, v5

    const/16 v10, -0x33

    aput-byte v10, v3, v6

    aput-byte v23, v3, v4

    const/4 v4, -0x6

    aput-byte v4, v3, v9

    const/16 v4, 0x21

    aput-byte v4, v3, v8

    aput-byte v8, v3, v11

    const/16 v4, -0x6a

    aput-byte v4, v3, v13

    invoke-static {v0, v3}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v7, v0}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0
    :try_end_4da
    .catch Ljava/lang/Exception; {:try_start_5 .. :try_end_4da} :catch_4ed

    if-eqz v0, :cond_4e7

    if-eqz p1, :cond_4e7

    move-object/from16 v3, p0

    :try_start_4e0
    invoke-direct {v3, v2}, Lcom/github/catvod/spider/appysv2/b/A;->b(Z)Z

    move-result v0
    :try_end_4e4
    .catch Ljava/lang/Exception; {:try_start_4e0 .. :try_end_4e4} :catch_4e5

    return v0

    :catch_4e5
    move-exception v0

    goto :goto_4f0

    :cond_4e7
    move-object/from16 v3, p0

    return v5

    :cond_4ea
    :goto_4ea
    move-object/from16 v3, p0

    return v5

    :catch_4ed
    move-exception v0

    move-object/from16 v3, p0

    :goto_4f0
    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const/16 v5, 0xc

    new-array v5, v5, [B

    fill-array-data v5, :array_506

    new-array v1, v1, [B

    fill-array-data v1, :array_510

    .line 1
    invoke-static {v5, v1, v4, v0}, Lcom/github/catvod/spider/appysv2/b/y;->b([B[BLjava/lang/StringBuilder;Ljava/lang/Exception;)V

    return v2

    nop

    :array_506
    .array-data 1
        -0x31t
        -0x52t
        0x3bt
        0xct
        -0x5dt
        -0x6dt
        -0x4at
        -0x70t
        -0x27t
        -0x47t
        0x6dt
        0x49t
    .end array-data

    :array_510
    .array-data 1
        -0x55t
        -0x35t
        0x57t
        0x69t
        -0x29t
        -0xat
        -0x6at
        -0xbt
    .end array-data
.end method

.method private c(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/util/List;Ljava/lang/String;)V
    .registers 55
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/util/List<",
            "Lcom/github/catvod/spider/appysv2/f/a;",
            ">;",
            "Ljava/lang/String;",
            ")V"
        }
    .end annotation

    move-object/from16 v0, p1

    :try_start_2
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/16 v2, 0x38

    new-array v2, v2, [B

    const/16 v3, -0xf

    const/4 v4, 0x0

    aput-byte v3, v2, v4

    const/16 v3, -0x77

    const/4 v5, 0x1

    aput-byte v3, v2, v5

    const/16 v3, -0x19

    const/4 v6, 0x2

    aput-byte v3, v2, v6

    const/16 v3, -0x3f

    const/4 v7, 0x3

    aput-byte v3, v2, v7

    const/16 v3, -0x11

    const/4 v8, 0x4

    aput-byte v3, v2, v8

    const/16 v3, 0x6a

    const/4 v9, 0x5

    aput-byte v3, v2, v9

    const/16 v3, -0x44

    const/4 v10, 0x6

    aput-byte v3, v2, v10

    const/16 v3, 0x4c

    const/4 v11, 0x7

    aput-byte v3, v2, v11

    const/16 v3, -0x17

    const/16 v12, 0x8

    aput-byte v3, v2, v12

    const/16 v3, -0x64

    const/16 v13, 0x9

    aput-byte v3, v2, v13

    const/4 v3, -0x3

    const/16 v14, 0xa

    aput-byte v3, v2, v14

    const/16 v15, -0x61

    const/16 v16, 0xb

    aput-byte v15, v2, v16

    const/4 v15, -0x2

    const/16 v17, 0xc

    aput-byte v15, v2, v17

    const/16 v15, 0xd

    const/16 v18, 0x31

    aput-byte v18, v2, v15

    const/4 v15, -0x6

    const/16 v19, 0xe

    aput-byte v15, v2, v19

    const/16 v15, 0xf

    aput-byte v11, v2, v15

    const/16 v20, -0x14

    const/16 v21, 0x10

    aput-byte v20, v2, v21

    const/16 v20, 0x11

    const/16 v22, -0x2d

    aput-byte v22, v2, v20

    const/16 v20, 0x12

    const/16 v22, -0x10

    aput-byte v22, v2, v20

    const/16 v20, -0x22

    const/16 v22, 0x13

    aput-byte v20, v2, v22

    const/16 v20, -0xf

    const/16 v23, 0x14

    aput-byte v20, v2, v23

    const/16 v20, 0x15

    const/16 v24, 0x7f

    aput-byte v24, v2, v20

    const/16 v20, 0x16

    const/16 v24, -0x20

    aput-byte v24, v2, v20

    const/16 v25, 0x17

    aput-byte v16, v2, v25

    const/16 v26, -0x8

    const/16 v27, 0x18

    aput-byte v26, v2, v27

    const/16 v26, -0x71

    const/16 v28, 0x19

    aput-byte v26, v2, v28

    const/16 v26, -0xa

    const/16 v29, 0x1a

    aput-byte v26, v2, v29

    const/16 v26, -0x62

    const/16 v30, 0x1b

    aput-byte v26, v2, v30

    const/16 v26, 0x1c

    const/16 v31, -0x10

    aput-byte v31, v2, v26

    const/16 v26, 0x39

    const/16 v31, 0x1d

    aput-byte v26, v2, v31

    const/16 v26, 0x1e

    aput-byte v24, v2, v26

    const/16 v26, 0x1f

    aput-byte v25, v2, v26

    const/16 v32, -0x5a

    const/16 v33, 0x20

    aput-byte v32, v2, v33

    const/16 v32, -0x6c

    const/16 v34, 0x21

    aput-byte v32, v2, v34

    const/16 v35, 0x22

    aput-byte v24, v2, v35

    const/16 v36, 0x23

    const/16 v37, -0x12

    aput-byte v37, v2, v36

    const/16 v36, -0x6

    const/16 v37, 0x24

    aput-byte v36, v2, v37

    const/16 v36, 0x25

    aput-byte v35, v2, v36

    const/16 v38, 0x26

    const/16 v39, -0x4

    aput-byte v39, v2, v38

    const/16 v38, 0x27

    aput-byte v19, v2, v38

    const/16 v38, -0x3a

    const/16 v39, 0x28

    aput-byte v38, v2, v39

    const/16 v38, -0x76

    const/16 v40, 0x29

    aput-byte v38, v2, v40

    const/16 v38, 0x2a

    const/16 v41, -0xa

    aput-byte v41, v2, v38

    const/16 v38, 0x2b

    const/16 v41, -0x2d

    aput-byte v41, v2, v38

    const/16 v38, 0x2c

    const/16 v41, -0x5f

    aput-byte v41, v2, v38

    const/16 v38, 0x2d

    aput-byte v37, v2, v38

    const/16 v38, -0x1f

    const/16 v41, 0x2e

    aput-byte v38, v2, v41

    const/16 v38, 0x2f

    aput-byte v20, v2, v38

    const/16 v38, 0x30

    const/16 v42, -0x4

    aput-byte v42, v2, v38

    const/16 v38, -0x25

    aput-byte v38, v2, v18

    const/16 v38, 0x32

    aput-byte v24, v2, v38

    const/16 v38, 0x33

    const/16 v42, -0x2c

    aput-byte v42, v2, v38

    const/16 v38, 0x34

    const/16 v42, -0x9

    aput-byte v42, v2, v38

    const/16 v38, 0x35

    aput-byte v38, v2, v38

    const/16 v42, 0x36

    const/16 v43, -0x16

    aput-byte v43, v2, v42

    const/16 v42, 0x37

    const/16 v43, 0x5e

    aput-byte v43, v2, v42

    new-array v15, v12, [B

    const/16 v43, -0x67

    aput-byte v43, v15, v4

    aput-byte v3, v15, v5

    const/16 v43, -0x6d

    aput-byte v43, v15, v6

    const/16 v43, -0x4f

    aput-byte v43, v15, v7

    const/16 v43, -0x64

    aput-byte v43, v15, v8

    const/16 v43, 0x50

    aput-byte v43, v15, v9

    const/16 v43, -0x6d

    aput-byte v43, v15, v10

    const/16 v43, 0x63

    aput-byte v43, v15, v11

    invoke-static {v2, v15}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    new-array v2, v8, [B

    const/16 v15, -0x4b

    aput-byte v15, v2, v4

    const/16 v15, 0x68

    aput-byte v15, v2, v5

    const/16 v15, 0x70

    aput-byte v15, v2, v6

    const/16 v15, -0x77

    aput-byte v15, v2, v7

    new-array v15, v12, [B

    const/16 v43, -0x6d

    aput-byte v43, v15, v4

    aput-byte v31, v15, v5

    aput-byte v30, v15, v6

    const/16 v43, -0x4c

    aput-byte v43, v15, v7

    const/16 v43, 0x62

    aput-byte v43, v15, v8

    const/16 v43, -0x31

    aput-byte v43, v15, v9

    aput-byte v9, v15, v10

    aput-byte v41, v15, v11

    invoke-static {v2, v15}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-object/from16 v15, p2

    invoke-virtual {v1, v15}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    new-array v2, v13, [B

    const/16 v43, -0x34

    aput-byte v43, v2, v4

    aput-byte v25, v2, v5

    aput-byte v35, v2, v6

    const/16 v43, -0x36

    aput-byte v43, v2, v7

    const/16 v43, -0x5c

    aput-byte v43, v2, v8

    const/16 v43, -0x2f

    aput-byte v43, v2, v9

    const/16 v43, 0x6b

    aput-byte v43, v2, v10

    const/16 v43, 0x46

    aput-byte v43, v2, v11

    const/16 v43, -0x29

    aput-byte v43, v2, v12

    new-array v3, v12, [B

    const/16 v44, -0x16

    aput-byte v44, v3, v4

    const/16 v44, 0x64

    aput-byte v44, v3, v5

    const/16 v44, 0x4a

    aput-byte v44, v3, v6

    const/16 v44, -0x55

    aput-byte v44, v3, v7

    const/16 v44, -0x2a

    aput-byte v44, v3, v8

    const/16 v44, -0x4c

    aput-byte v44, v3, v9

    aput-byte v6, v3, v10

    aput-byte v35, v3, v11

    invoke-static {v2, v3}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-object/from16 v3, p3

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v2, 0x45

    new-array v2, v2, [B

    aput-byte v11, v2, v4

    const/16 v44, 0x2f

    aput-byte v44, v2, v5

    const/16 v44, -0x59

    aput-byte v44, v2, v6

    const/16 v44, 0x44

    aput-byte v44, v2, v7

    aput-byte v27, v2, v8

    const/16 v45, 0x43

    aput-byte v45, v2, v9

    const/16 v45, 0x7a

    aput-byte v45, v2, v10

    const/16 v45, -0x23

    aput-byte v45, v2, v11

    const/16 v45, 0x55

    aput-byte v45, v2, v12

    aput-byte v39, v2, v13

    const/16 v45, -0x50

    aput-byte v45, v2, v14

    const/16 v45, 0x52

    aput-byte v45, v2, v16

    const/16 v45, 0x5b

    aput-byte v45, v2, v17

    const/16 v45, 0xd

    const/16 v46, 0x55

    aput-byte v46, v2, v45

    aput-byte v35, v2, v19

    const/16 v45, -0x3f

    const/16 v42, 0xf

    aput-byte v45, v2, v42

    const/16 v45, 0x42

    aput-byte v45, v2, v21

    const/16 v45, 0x11

    const/16 v46, 0x7d

    aput-byte v46, v2, v45

    const/16 v45, 0x12

    const/16 v46, -0x1c

    aput-byte v46, v2, v45

    aput-byte v10, v2, v22

    aput-byte v19, v2, v23

    const/16 v45, 0x15

    const/16 v46, 0x59

    aput-byte v46, v2, v45

    aput-byte v39, v2, v20

    const/16 v45, -0x3b

    aput-byte v45, v2, v25

    aput-byte v44, v2, v27

    const/16 v45, 0x2d

    aput-byte v45, v2, v28

    const/16 v45, -0x5b

    aput-byte v45, v2, v29

    const/16 v45, 0x54

    aput-byte v45, v2, v30

    const/16 v45, 0x1c

    aput-byte v8, v2, v45

    aput-byte v17, v2, v31

    const/16 v45, 0x1e

    const/16 v46, 0x77

    aput-byte v46, v2, v45

    aput-byte v32, v2, v26

    const/16 v45, 0x57

    aput-byte v45, v2, v33

    aput-byte v40, v2, v34

    const/16 v45, -0x50

    aput-byte v45, v2, v35

    const/16 v45, 0x23

    const/16 v46, 0x57

    aput-byte v46, v2, v45

    aput-byte v35, v2, v37

    const/16 v45, 0x5c

    aput-byte v45, v2, v36

    const/16 v45, 0x26

    aput-byte v39, v2, v45

    const/16 v45, 0x27

    const/16 v46, -0x2a

    aput-byte v46, v2, v45

    aput-byte v44, v2, v39

    const/16 v45, 0x7d

    aput-byte v45, v2, v40

    const/16 v45, 0x2a

    const/16 v46, -0x1c

    aput-byte v46, v2, v45

    const/16 v45, 0x2b

    aput-byte v10, v2, v45

    const/16 v45, 0x2c

    aput-byte v14, v2, v45

    const/16 v45, 0x2d

    const/16 v46, 0x54

    aput-byte v46, v2, v45

    aput-byte v36, v2, v41

    const/16 v45, 0x2f

    const/16 v46, -0x71

    aput-byte v46, v2, v45

    const/16 v45, 0x30

    aput-byte v21, v2, v45

    const/16 v45, 0x66

    aput-byte v45, v2, v18

    const/16 v45, 0x32

    const/16 v46, -0x5b

    aput-byte v46, v2, v45

    const/16 v45, 0x33

    const/16 v46, 0x41

    aput-byte v46, v2, v45

    const/16 v45, 0x34

    aput-byte v29, v2, v45

    const/16 v45, 0x54

    aput-byte v45, v2, v38

    const/16 v45, 0x36

    const/16 v46, 0x7a

    aput-byte v46, v2, v45

    const/16 v45, 0x37

    const/16 v46, -0x7d

    aput-byte v46, v2, v45

    const/16 v45, 0x38

    aput-byte v11, v2, v45

    const/16 v45, 0x39

    aput-byte v41, v2, v45

    const/16 v45, 0x3a

    const/16 v46, -0x60

    aput-byte v46, v2, v45

    const/16 v45, 0x3b

    const/16 v46, 0x4d

    aput-byte v46, v2, v45

    const/16 v45, 0x3c

    const/16 v46, 0x40

    aput-byte v46, v2, v45

    const/16 v45, 0x3d

    aput-byte v4, v2, v45

    const/16 v45, 0x3e

    const/16 v47, 0x77

    aput-byte v47, v2, v45

    const/16 v45, 0x3f

    const/16 v47, -0x7e

    aput-byte v47, v2, v45

    aput-byte v11, v2, v46

    const/16 v45, 0x41

    aput-byte v37, v2, v45

    const/16 v45, 0x42

    const/16 v47, -0x44

    aput-byte v47, v2, v45

    const/16 v45, 0x43

    const/16 v47, 0x52

    aput-byte v47, v2, v45

    aput-byte v46, v2, v44

    new-array v14, v12, [B

    aput-byte v34, v14, v4

    aput-byte v46, v14, v5

    const/16 v47, -0x2b

    aput-byte v47, v14, v6

    aput-byte v33, v14, v7

    const/16 v47, 0x7d

    aput-byte v47, v14, v8

    aput-byte v18, v14, v9

    const/16 v47, 0x47

    aput-byte v47, v14, v10

    const/16 v47, -0x4e

    aput-byte v47, v14, v11

    invoke-static {v2, v14}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static/range {p4 .. p4}, Ljava/net/URLEncoder;->encode(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v2, 0x43

    new-array v2, v2, [B

    const/16 v14, -0x25

    aput-byte v14, v2, v4

    const/16 v14, 0x5d

    aput-byte v14, v2, v5

    aput-byte v30, v2, v6

    const/16 v14, 0x3f

    aput-byte v14, v2, v7

    const/16 v14, 0x73

    aput-byte v14, v2, v8

    aput-byte v7, v2, v9

    const/4 v14, -0x2

    aput-byte v14, v2, v10

    aput-byte v5, v2, v11

    const/16 v14, -0x38

    aput-byte v14, v2, v12

    aput-byte v28, v2, v13

    const/16 v13, 0xa

    aput-byte v20, v2, v13

    const/16 v13, 0x3e

    aput-byte v13, v2, v16

    const/16 v13, 0x64

    aput-byte v13, v2, v17

    const/16 v13, 0xd

    aput-byte v5, v2, v13

    const/4 v13, -0x5

    aput-byte v13, v2, v19

    const/16 v13, 0xf

    aput-byte v4, v2, v13

    const/16 v13, -0x37

    aput-byte v13, v2, v21

    const/16 v13, 0x11

    aput-byte v21, v2, v13

    const/16 v13, 0x12

    aput-byte v26, v2, v13

    const/16 v13, 0x3c

    aput-byte v13, v2, v22

    const/16 v13, 0x6b

    aput-byte v13, v2, v23

    const/16 v13, 0x15

    aput-byte v22, v2, v13

    const/16 v13, -0x55

    aput-byte v13, v2, v20

    const/16 v13, 0x5e

    aput-byte v13, v2, v25

    const/16 v13, -0x64

    aput-byte v13, v2, v27

    const/16 v13, 0x47

    aput-byte v13, v2, v28

    const/16 v13, 0x48

    aput-byte v13, v2, v29

    const/16 v13, 0x6a

    aput-byte v13, v2, v30

    const/16 v13, 0x1c

    aput-byte v18, v2, v13

    aput-byte v12, v2, v31

    const/16 v13, 0x1e

    const/16 v14, -0x55

    aput-byte v14, v2, v13

    const/16 v13, 0x5e

    aput-byte v13, v2, v26

    const/16 v13, -0x78

    aput-byte v13, v2, v33

    const/16 v13, 0x47

    aput-byte v13, v2, v34

    const/16 v13, 0x4a

    aput-byte v13, v2, v35

    const/16 v13, 0x23

    const/16 v14, 0x6a

    aput-byte v14, v2, v13

    const/16 v13, 0x34

    aput-byte v13, v2, v37

    aput-byte v22, v2, v36

    const/16 v13, 0x26

    const/16 v14, -0x41

    aput-byte v14, v2, v13

    const/16 v13, 0x27

    const/16 v14, 0x53

    aput-byte v14, v2, v13

    const/16 v13, -0x61

    aput-byte v13, v2, v39

    aput-byte v23, v2, v40

    const/16 v13, 0x2a

    aput-byte v25, v2, v13

    const/16 v13, 0x2b

    aput-byte v40, v2, v13

    const/16 v13, 0x2c

    const/16 v14, 0x3c

    aput-byte v14, v2, v13

    const/16 v13, 0x2d

    const/16 v14, 0x45

    aput-byte v14, v2, v13

    const/16 v13, -0x48

    aput-byte v13, v2, v41

    const/16 v13, 0x2f

    const/16 v14, 0x69

    aput-byte v14, v2, v13

    const/16 v13, 0x30

    aput-byte v32, v2, v13

    const/16 v13, 0x4d

    aput-byte v13, v2, v18

    const/16 v13, 0x32

    aput-byte v30, v2, v13

    const/16 v13, 0x33

    const/16 v14, 0x3d

    aput-byte v14, v2, v13

    const/16 v13, 0x34

    const/16 v14, 0x68

    aput-byte v14, v2, v13

    aput-byte v9, v2, v38

    const/16 v13, 0x36

    const/4 v14, -0x3

    aput-byte v14, v2, v13

    const/16 v13, 0x37

    aput-byte v8, v2, v13

    const/16 v13, 0x38

    const/16 v14, -0x3b

    aput-byte v14, v2, v13

    const/16 v13, 0x39

    const/16 v14, 0xf

    aput-byte v14, v2, v13

    const/16 v13, 0x3a

    aput-byte v44, v2, v13

    const/16 v13, 0x3b

    const/16 v14, 0x6b

    aput-byte v14, v2, v13

    const/16 v13, 0x3c

    aput-byte v41, v2, v13

    const/16 v13, 0x3d

    const/16 v14, 0x41

    aput-byte v14, v2, v13

    const/16 v13, 0x3e

    const/16 v14, -0x59

    aput-byte v14, v2, v13

    const/16 v13, 0x3f

    const/16 v14, 0x5d

    aput-byte v14, v2, v13

    const/16 v13, -0x68

    aput-byte v13, v2, v46

    const/16 v13, 0x41

    const/16 v14, 0x47

    aput-byte v14, v2, v13

    const/16 v13, 0x42

    aput-byte v30, v2, v13

    new-array v13, v12, [B

    const/4 v14, -0x3

    aput-byte v14, v13, v4

    aput-byte v40, v13, v5

    const/16 v14, 0x26

    aput-byte v14, v13, v6

    const/16 v14, 0xf

    aput-byte v14, v13, v7

    const/16 v14, 0x5d

    aput-byte v14, v13, v8

    aput-byte v38, v13, v9

    const/16 v14, -0x38

    aput-byte v14, v13, v10

    const/16 v14, 0x36

    aput-byte v14, v13, v11

    invoke-static {v2, v13}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct/range {p0 .. p0}, Lcom/github/catvod/spider/appysv2/b/A;->f()Ljava/util/Map;

    move-result-object v2

    new-array v13, v10, [B

    const/16 v14, 0x57

    aput-byte v14, v13, v4

    const/16 v14, 0x6c

    aput-byte v14, v13, v5

    aput-byte v32, v13, v6

    aput-byte v23, v13, v7

    const/16 v14, -0x77

    aput-byte v14, v13, v8

    const/16 v14, 0x7a

    aput-byte v14, v13, v9

    new-array v12, v12, [B

    aput-byte v23, v12, v4

    aput-byte v7, v12, v5

    const/4 v14, -0x5

    aput-byte v14, v12, v6

    const/16 v14, 0x7f

    aput-byte v14, v12, v7

    aput-byte v24, v12, v8

    aput-byte v26, v12, v9

    aput-byte v36, v12, v10

    const/16 v14, -0x50

    aput-byte v14, v12, v11

    invoke-static {v13, v12}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v12

    new-instance v13, Ljava/lang/StringBuilder;

    invoke-direct {v13}, Ljava/lang/StringBuilder;-><init>()V

    new-array v11, v11, [B

    const/16 v14, -0x1c

    aput-byte v14, v11, v4

    const/16 v14, -0x22

    aput-byte v14, v11, v5

    const/16 v14, -0x65

    aput-byte v14, v11, v6

    aput-byte v20, v11, v7

    const/16 v14, 0x27

    aput-byte v14, v11, v8

    const/16 v14, -0x3f

    aput-byte v14, v11, v9

    aput-byte v36, v11, v10

    const/16 v14, 0x8

    new-array v14, v14, [B

    const/16 v16, -0x5a

    aput-byte v16, v14, v4

    const/16 v4, -0x66

    aput-byte v4, v14, v5

    const/16 v4, -0x28

    aput-byte v4, v14, v6

    const/16 v4, 0x5a

    aput-byte v4, v14, v7

    const/16 v4, 0x69

    aput-byte v4, v14, v8

    const/16 v4, -0x7b

    aput-byte v4, v14, v9

    aput-byte v27, v14, v10

    const/16 v4, 0x4b

    const/4 v6, 0x7

    aput-byte v4, v14, v6

    invoke-static {v11, v14}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v13, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v13, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v13}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    move-object v6, v2

    check-cast v6, Ljava/util/HashMap;

    invoke-virtual {v6, v12, v4}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    invoke-static {v1, v2}, Lcom/github/catvod/spider/appysv2/n/c;->m(Ljava/lang/String;Ljava/util/Map;)Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Lcom/github/catvod/spider/appysv2/f/b;->e(Ljava/lang/String;)Lcom/github/catvod/spider/appysv2/f/b;

    move-result-object v1

    invoke-virtual {v1}, Lcom/github/catvod/spider/appysv2/f/b;->a()I

    move-result v2

    if-nez v2, :cond_575

    invoke-virtual {v1}, Lcom/github/catvod/spider/appysv2/f/b;->b()Ljava/util/List;

    move-result-object v8

    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    invoke-interface {v8}, Ljava/util/List;->size()I

    move-result v2

    sub-int/2addr v2, v5

    :goto_520
    if-ltz v2, :cond_549

    invoke-interface {v8, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Lcom/github/catvod/spider/appysv2/f/a;

    invoke-virtual {v4}, Lcom/github/catvod/spider/appysv2/f/a;->g()Z

    move-result v6

    if-eqz v6, :cond_539

    move-object/from16 v6, p6

    invoke-virtual {v4, v6}, Lcom/github/catvod/spider/appysv2/f/a;->j(Ljava/lang/String;)V

    move-object/from16 v9, p5

    invoke-interface {v9, v4}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    goto :goto_546

    :cond_539
    move-object/from16 v9, p5

    move-object/from16 v6, p6

    invoke-virtual {v4}, Lcom/github/catvod/spider/appysv2/f/a;->b()I

    move-result v7

    if-ne v7, v5, :cond_546

    invoke-virtual {v1, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_546
    :goto_546
    add-int/lit8 v2, v2, -0x1

    goto :goto_520

    :cond_549
    move-object/from16 v9, p5

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    sub-int/2addr v1, v5

    move v10, v1

    :goto_551
    if-ltz v10, :cond_575

    invoke-interface {v8, v10}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcom/github/catvod/spider/appysv2/f/a;

    invoke-virtual {v1}, Lcom/github/catvod/spider/appysv2/f/a;->c()Ljava/lang/String;

    move-result-object v5

    const-string v7, ""

    move-object/from16 v1, p0

    move-object/from16 v2, p1

    move-object/from16 v3, p2

    move-object/from16 v4, p3

    move-object/from16 v6, p5

    invoke-direct/range {v1 .. v7}, Lcom/github/catvod/spider/appysv2/b/A;->c(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/util/List;Ljava/lang/String;)V
    :try_end_56c
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_56c} :catch_571

    add-int/lit8 v10, v10, -0x1

    move-object/from16 v3, p3

    goto :goto_551

    :catch_571
    move-exception v0

    invoke-virtual {v0}, Ljava/lang/Throwable;->printStackTrace()V

    :cond_575
    return-void
.end method

.method public static e()Lcom/github/catvod/spider/appysv2/b/A;
    .registers 1

    sget-object v0, Lcom/github/catvod/spider/appysv2/b/z;->a:Lcom/github/catvod/spider/appysv2/b/A;

    return-object v0
.end method

.method private f()Ljava/util/Map;
    .registers 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    new-instance v0, Ljava/util/HashMap;

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    const/16 v1, 0xa

    new-array v1, v1, [B

    fill-array-data v1, :array_b2

    const/16 v2, 0x8

    new-array v3, v2, [B

    fill-array-data v3, :array_bc

    invoke-static {v1, v3}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v1

    const/16 v3, 0x7d

    new-array v3, v3, [B

    fill-array-data v3, :array_c4

    new-array v4, v2, [B

    fill-array-data v4, :array_108

    invoke-static {v3, v4}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v0, v1, v3}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v1, 0x6

    new-array v3, v1, [B

    fill-array-data v3, :array_110

    new-array v4, v2, [B

    fill-array-data v4, :array_118

    invoke-static {v3, v4}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v3

    const/16 v4, 0x1e

    new-array v4, v4, [B

    fill-array-data v4, :array_120

    new-array v5, v2, [B

    fill-array-data v5, :array_134

    invoke-static {v4, v5}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v0, v3, v4}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    invoke-virtual {p0}, Lcom/github/catvod/spider/appysv2/b/A;->g()Ljava/lang/String;

    move-result-object v3

    invoke-static {v3}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v3

    if-nez v3, :cond_6b

    new-array v1, v1, [B

    fill-array-data v1, :array_13c

    new-array v3, v2, [B

    fill-array-data v3, :array_144

    invoke-static {v1, v3}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {p0}, Lcom/github/catvod/spider/appysv2/b/A;->g()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v0, v1, v3}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_6b
    const/16 v1, 0xc

    new-array v1, v1, [B

    fill-array-data v1, :array_14c

    new-array v3, v2, [B

    fill-array-data v3, :array_156

    invoke-static {v1, v3}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v1

    const/16 v3, 0x30

    new-array v3, v3, [B

    fill-array-data v3, :array_15e

    new-array v4, v2, [B

    fill-array-data v4, :array_17a

    invoke-static {v3, v4}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v0, v1, v3}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v1, 0x7

    new-array v1, v1, [B

    fill-array-data v1, :array_182

    new-array v3, v2, [B

    fill-array-data v3, :array_18a

    invoke-static {v1, v3}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v1

    const/16 v3, 0x15

    new-array v3, v3, [B

    fill-array-data v3, :array_192

    new-array v2, v2, [B

    fill-array-data v2, :array_1a2

    invoke-static {v3, v2}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v1, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    return-object v0

    nop

    :array_b2
    .array-data 1
        -0x22t
        -0x20t
        0x6ft
        0x2t
        0x1ct
        0x55t
        -0x53t
        -0x39t
        -0x1bt
        -0x19t
    .end array-data

    nop

    :array_bc
    .array-data 1
        -0x75t
        -0x6dt
        0xat
        0x70t
        0x31t
        0x14t
        -0x36t
        -0x5et
    .end array-data

    :array_c4
    .array-data 1
        -0x7t
        -0x2bt
        -0x1t
        0x26t
        -0x17t
        -0x65t
        0x56t
        0x72t
        -0x7ft
        -0x6ct
        -0x4bt
        0x6ft
        -0x53t
        -0x60t
        0x5et
        0x33t
        -0x30t
        -0x2bt
        -0xet
        0x3ct
        -0x5bt
        -0x47t
        0x63t
        0x7dt
        -0x7bt
        -0x76t
        -0x55t
        0x7ft
        -0x42t
        -0x29t
        0x60t
        0x34t
        -0x26t
        -0x74t
        -0x4ft
        0x74t
        -0x5bt
        -0x71t
        0x1t
        0x69t
        -0x63t
        -0x66t
        -0x3ct
        0x3ft
        -0xbt
        -0x65t
        0x52t
        0xat
        -0x2ft
        -0x28t
        -0x32t
        0x26t
        -0xft
        -0x28t
        0x2t
        0x6et
        -0x7dt
        -0x6ct
        -0x4at
        0x79t
        -0x5bt
        -0x21t
        0x7ct
        0x15t
        -0x20t
        -0x9t
        -0x37t
        0x63t
        -0x5bt
        -0x65t
        0x5et
        0x36t
        -0x2ft
        -0x66t
        -0x3et
        0x2at
        -0x1at
        -0x64t
        0x58t
        0x74t
        -0x6ct
        -0x7t
        -0x13t
        0x3dt
        -0x16t
        -0x66t
        0x52t
        0x72t
        -0x7bt
        -0x77t
        -0x4ft
        0x61t
        -0x4bt
        -0x27t
        0x7t
        0x73t
        -0x7ct
        -0x66t
        -0x2at
        0x2et
        -0x1dt
        -0x6at
        0x45t
        0x34t
        -0x65t
        -0x71t
        -0x4at
        0x78t
        -0x55t
        -0x3ct
        0x1t
        0x7dt
        -0xft
        -0x22t
        -0x1et
        0x60t
        -0x4ct
        -0x3ct
        0x3t
        0x73t
        -0x7ct
        -0x6ct
        -0x4bt
        0x61t
        -0x4bt
    .end array-data

    nop

    :array_108
    .array-data 1
        -0x4ct
        -0x46t
        -0x7bt
        0x4ft
        -0x7bt
        -0x9t
        0x37t
        0x5dt
    .end array-data

    :array_110
    .array-data 1
        -0x4bt
        0x4bt
        -0xft
        -0x44t
        0x4at
        0x13t
    .end array-data

    nop

    :array_118
    .array-data 1
        -0xct
        0x28t
        -0x6et
        -0x27t
        0x3at
        0x67t
        -0x3ct
        -0x61t
    .end array-data

    :array_120
    .array-data 1
        -0x34t
        -0x6t
        0x26t
        0x6ct
        0x15t
        0x79t
        -0x11t
        0x47t
        -0x3ct
        -0x1bt
        0x38t
        0x2ft
        0x16t
        0x69t
        -0x1ft
        0x5dt
        -0x6at
        -0x17t
        0x3et
        0x61t
        0xet
        0x69t
        -0x15t
        0x47t
        -0x70t
        -0x21t
        0x2t
        0x46t
        0x51t
        0x22t
    .end array-data

    nop

    :array_134
    .array-data 1
        -0x53t
        -0x76t
        0x56t
        0x0t
        0x7ct
        0x1at
        -0x72t
        0x33t
    .end array-data

    :array_13c
    .array-data 1
        -0x74t
        0x13t
        -0xct
        -0x1at
        -0x4at
        -0xdt
    .end array-data

    nop

    :array_144
    .array-data 1
        -0x31t
        0x7ct
        -0x65t
        -0x73t
        -0x21t
        -0x6at
        0x5t
        0x64t
    .end array-data

    :array_14c
    .array-data 1
        0x5t
        -0x19t
        -0x5dt
        -0x1ft
        0x7ft
        -0xct
        -0x6at
        0x67t
        0x12t
        -0xft
        -0x43t
        -0x10t
    .end array-data

    :array_156
    .array-data 1
        0x46t
        -0x78t
        -0x33t
        -0x6bt
        0x1at
        -0x66t
        -0x1et
        0x4at
    .end array-data

    :array_15e
    .array-data 1
        -0x5at
        -0x67t
        0x1et
        0x60t
        -0x40t
        -0x13t
        0x77t
        0x11t
        -0x52t
        -0x7at
        0x0t
        0x23t
        -0x2ft
        -0x5dt
        0x61t
        0x12t
        -0x50t
        -0x3ct
        0x8t
        0x63t
        -0x25t
        -0x1dt
        0x3bt
        0x10t
        -0x4bt
        -0x7bt
        0xbt
        0x62t
        -0x36t
        -0x1ft
        0x72t
        0x0t
        -0x5dt
        -0x2et
        0x4et
        0x6ft
        -0x3ft
        -0x11t
        0x64t
        0x16t
        -0x5et
        -0x63t
        0x53t
        0x59t
        -0x3t
        -0x38t
        0x3bt
        0x5dt
    .end array-data

    :array_17a
    .array-data 1
        -0x39t
        -0x17t
        0x6et
        0xct
        -0x57t
        -0x72t
        0x16t
        0x65t
    .end array-data

    :array_182
    .array-data 1
        -0x27t
        0x79t
        0x33t
        0xdt
        -0x5et
        -0x14t
        0x27t
    .end array-data

    :array_18a
    .array-data 1
        -0x75t
        0x1ct
        0x55t
        0x68t
        -0x30t
        -0x77t
        0x55t
        0x17t
    .end array-data

    :array_192
    .array-data 1
        -0x1t
        0x51t
        0xft
        -0x16t
        -0x1ct
        -0x48t
        -0x55t
        -0x16t
        -0x19t
        0x44t
        0x15t
        -0x4ct
        -0xbt
        -0x1dt
        -0x13t
        -0x5ft
        -0x1et
        0xbt
        0x18t
        -0xbt
        -0x6t
    .end array-data

    nop

    :array_1a2
    .array-data 1
        -0x69t
        0x25t
        0x7bt
        -0x66t
        -0x69t
        -0x7et
        -0x7ct
        -0x3bt
    .end array-data
.end method

.method private i(Ljava/lang/String;)Ljava/lang/String;
    .registers 18

    move-object/from16 v0, p1

    if-eqz v0, :cond_13c

    :try_start_4
    invoke-virtual/range {p1 .. p1}, Ljava/lang/String;->isEmpty()Z

    move-result v1

    if-eqz v1, :cond_c

    goto/16 :goto_13c

    :cond_c
    const/4 v1, 0x2

    new-array v2, v1, [B

    const/16 v3, 0xc

    const/4 v4, 0x0

    aput-byte v3, v2, v4

    const/16 v3, 0x4e

    const/4 v5, 0x1

    aput-byte v3, v2, v5

    const/16 v3, 0x8

    new-array v6, v3, [B

    const/16 v7, 0x23

    aput-byte v7, v6, v4

    const/16 v7, 0x65

    aput-byte v7, v6, v5

    const/16 v7, -0x19

    aput-byte v7, v6, v1

    const/16 v7, -0x10

    const/4 v8, 0x3

    aput-byte v7, v6, v8

    const/16 v7, 0x3b

    const/4 v9, 0x4

    aput-byte v7, v6, v9

    const/16 v7, -0x34

    const/4 v10, 0x5

    aput-byte v7, v6, v10

    const/16 v7, 0x21

    const/4 v11, 0x6

    aput-byte v7, v6, v11

    const/16 v7, 0x32

    const/4 v12, 0x7

    aput-byte v7, v6, v12

    invoke-static {v2, v6}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v2

    new-instance v6, Ljava/util/ArrayList;

    invoke-static {v2}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v2

    invoke-direct {v6, v2}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    invoke-virtual {v6}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v2

    if-nez v2, :cond_67

    invoke-virtual {v6, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/String;

    invoke-virtual {v2}, Ljava/lang/String;->isEmpty()Z

    move-result v2

    if-eqz v2, :cond_67

    const/4 v2, 0x1

    goto :goto_68

    :cond_67
    const/4 v2, 0x0

    :goto_68
    invoke-virtual {v6}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v7

    if-eqz v7, :cond_71

    const-string v0, ""

    return-object v0

    :cond_71
    invoke-virtual {v6}, Ljava/util/ArrayList;->size()I

    move-result v7

    sub-int/2addr v7, v5

    if-ltz v7, :cond_7b

    invoke-virtual {v6, v7}, Ljava/util/ArrayList;->remove(I)Ljava/lang/Object;

    :cond_7b
    if-eqz v2, :cond_ba

    invoke-virtual {v6}, Ljava/util/ArrayList;->size()I

    move-result v7

    if-ne v7, v5, :cond_ba

    invoke-virtual {v6, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Ljava/lang/String;

    invoke-virtual {v7}, Ljava/lang/String;->isEmpty()Z

    move-result v7

    if-eqz v7, :cond_ba

    new-array v2, v5, [B

    const/16 v6, 0x5c

    aput-byte v6, v2, v4

    new-array v3, v3, [B

    const/16 v6, 0x73

    aput-byte v6, v3, v4

    const/16 v4, -0x65

    aput-byte v4, v3, v5

    aput-byte v4, v3, v1

    const/16 v1, 0x11

    aput-byte v1, v3, v8

    const/16 v1, -0x46

    aput-byte v1, v3, v9

    const/16 v1, 0x6b

    aput-byte v1, v3, v10

    const/16 v1, -0x72

    aput-byte v1, v3, v11

    const/16 v1, -0x7b

    aput-byte v1, v3, v12

    invoke-static {v2, v3}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v0

    return-object v0

    :cond_ba
    new-array v7, v5, [B

    const/16 v13, -0x7f

    aput-byte v13, v7, v4

    new-array v13, v3, [B

    const/16 v14, -0x52

    aput-byte v14, v13, v4

    aput-byte v10, v13, v5

    const/16 v14, -0x20

    aput-byte v14, v13, v1

    const/16 v14, -0x77

    aput-byte v14, v13, v8

    const/16 v14, 0x41

    aput-byte v14, v13, v9

    const/16 v14, 0x50

    aput-byte v14, v13, v10

    const/16 v15, -0x53

    aput-byte v15, v13, v11

    aput-byte v14, v13, v12

    invoke-static {v7, v13}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v7

    new-instance v13, Ljava/lang/StringBuilder;

    invoke-direct {v13}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v6}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v6

    invoke-interface {v6}, Ljava/util/Iterator;->hasNext()Z

    move-result v14

    if-eqz v14, :cond_104

    :goto_f1
    invoke-interface {v6}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v14

    check-cast v14, Ljava/lang/CharSequence;

    invoke-virtual {v13, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/CharSequence;)Ljava/lang/StringBuilder;

    invoke-interface {v6}, Ljava/util/Iterator;->hasNext()Z

    move-result v14

    if-eqz v14, :cond_104

    invoke-virtual {v13, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/CharSequence;)Ljava/lang/StringBuilder;

    goto :goto_f1

    :cond_104
    invoke-virtual {v13}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    if-eqz v2, :cond_13b

    invoke-virtual {v6}, Ljava/lang/String;->isEmpty()Z

    move-result v2

    if-eqz v2, :cond_13b

    new-array v2, v5, [B

    const/16 v6, -0x6a

    aput-byte v6, v2, v4

    new-array v3, v3, [B

    const/16 v6, -0x47

    aput-byte v6, v3, v4

    const/16 v4, -0x23

    aput-byte v4, v3, v5

    const/16 v4, 0x7e

    aput-byte v4, v3, v1

    const/4 v1, -0x5

    aput-byte v1, v3, v8

    const/16 v1, 0xd

    aput-byte v1, v3, v9

    const/16 v1, 0x31

    aput-byte v1, v3, v10

    const/16 v1, -0x32

    aput-byte v1, v3, v11

    const/16 v1, 0x3c

    aput-byte v1, v3, v12

    invoke-static {v2, v3}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v6
    :try_end_13b
    .catch Ljava/lang/Exception; {:try_start_4 .. :try_end_13b} :catch_13c

    :cond_13b
    return-object v6

    :catch_13c
    :cond_13c
    :goto_13c
    return-object v0
.end method

.method public static k()Z
    .registers 28

    const/16 v0, 0x40

    const/4 v1, 0x0

    :try_start_3
    new-array v0, v0, [B

    const/16 v2, 0x6b

    aput-byte v2, v0, v1

    const/16 v2, 0x6b

    const/4 v3, 0x1

    aput-byte v2, v0, v3

    const/16 v2, 0x31

    const/4 v4, 0x2

    aput-byte v2, v0, v4

    const/16 v5, 0x1a

    const/4 v6, 0x3

    aput-byte v5, v0, v6

    const/16 v5, 0x76

    const/4 v7, 0x4

    aput-byte v5, v0, v7

    const/16 v5, 0x43

    const/4 v8, 0x5

    aput-byte v5, v0, v8

    const/16 v5, 0x63

    const/4 v9, 0x6

    aput-byte v5, v0, v9

    const/16 v5, 0x22

    const/4 v10, 0x7

    aput-byte v5, v0, v10

    const/16 v11, 0x73

    const/16 v12, 0x8

    aput-byte v11, v0, v12

    const/16 v11, 0x9

    const/16 v13, 0x7e

    aput-byte v13, v0, v11

    const/16 v11, 0x36

    const/16 v13, 0xa

    aput-byte v11, v0, v13

    const/16 v11, 0x19

    const/16 v14, 0xb

    aput-byte v11, v0, v14

    const/16 v11, 0xc

    const/16 v15, 0x75

    aput-byte v15, v0, v11

    const/16 v11, 0x16

    const/16 v15, 0xd

    aput-byte v11, v0, v15

    const/16 v11, 0xe

    const/16 v16, 0x3e

    aput-byte v16, v0, v11

    const/16 v11, 0x79

    const/16 v16, 0xf

    aput-byte v11, v0, v16

    const/16 v11, 0x10

    const/16 v17, 0x2d

    aput-byte v17, v0, v11

    const/16 v11, 0x11

    const/16 v17, 0x7d

    aput-byte v17, v0, v11

    const/16 v11, 0x12

    const/16 v17, 0x24

    aput-byte v17, v0, v11

    const/16 v11, 0x13

    aput-byte v6, v0, v11

    const/16 v11, 0x14

    const/16 v18, 0x61

    aput-byte v18, v0, v11

    const/16 v11, 0x15

    const/16 v18, 0xc

    aput-byte v18, v0, v11

    const/16 v11, 0x16

    const/16 v18, 0x62

    aput-byte v18, v0, v11

    const/16 v11, 0x17

    const/16 v18, 0x6e

    aput-byte v18, v0, v11

    const/16 v11, 0x18

    const/16 v18, 0x6c

    aput-byte v18, v0, v11

    const/16 v11, 0x19

    const/16 v19, 0x72

    aput-byte v19, v0, v11

    const/16 v11, 0x1a

    const/16 v19, 0x6a

    aput-byte v19, v0, v11

    const/16 v11, 0x1b

    const/16 v19, 0x1c

    aput-byte v19, v0, v11

    const/16 v11, 0x1c

    const/16 v19, 0x37

    aput-byte v19, v0, v11

    const/16 v11, 0x1d

    const/16 v19, 0x56

    aput-byte v19, v0, v11

    const/16 v11, 0x1e

    const/16 v19, 0x2d

    aput-byte v19, v0, v11

    const/16 v11, 0x7d

    const/16 v19, 0x1f

    aput-byte v11, v0, v19

    const/16 v11, 0x20

    const/16 v20, 0x6a

    aput-byte v20, v0, v11

    const/16 v11, 0x21

    const/16 v20, 0x30

    aput-byte v20, v0, v11

    aput-byte v5, v0, v5

    const/16 v11, 0x23

    aput-byte v16, v0, v11

    const/16 v11, 0x71

    aput-byte v11, v0, v17

    const/16 v11, 0x25

    aput-byte v12, v0, v11

    const/16 v11, 0x26

    const/16 v21, 0x3e

    aput-byte v21, v0, v11

    const/16 v11, 0x27

    const/16 v21, 0x6e

    aput-byte v21, v0, v11

    const/16 v11, 0x28

    aput-byte v18, v0, v11

    const/16 v21, 0x29

    const/16 v22, 0x7b

    aput-byte v22, v0, v21

    const/16 v21, 0x2a

    const/16 v22, 0x20

    aput-byte v22, v0, v21

    const/16 v21, 0x2b

    const/16 v22, 0x55

    aput-byte v22, v0, v21

    const/16 v21, 0x2c

    const/16 v22, 0x69

    aput-byte v22, v0, v21

    const/16 v21, 0x2d

    const/16 v22, 0x9

    aput-byte v22, v0, v21

    const/16 v21, 0x2e

    const/16 v22, 0x71

    aput-byte v22, v0, v21

    const/16 v21, 0x2f

    const/16 v22, 0x7d

    aput-byte v22, v0, v21

    const/16 v21, 0x60

    aput-byte v21, v0, v20

    const/16 v21, 0x39

    aput-byte v21, v0, v2

    const/16 v21, 0x32

    const/16 v22, 0x34

    aput-byte v22, v0, v21

    const/16 v21, 0x33

    const/16 v22, 0x18

    aput-byte v22, v0, v21

    const/16 v21, 0x34

    const/16 v22, 0x69

    aput-byte v22, v0, v21

    const/16 v21, 0x35

    const/16 v22, 0x16

    aput-byte v22, v0, v21

    const/16 v21, 0x36

    const/16 v22, 0x2b

    aput-byte v22, v0, v21

    const/16 v21, 0x37

    const/16 v22, 0x64

    aput-byte v22, v0, v21

    const/16 v21, 0x38

    const/16 v22, 0x6d

    aput-byte v22, v0, v21

    const/16 v21, 0x39

    const/16 v22, 0x79

    aput-byte v22, v0, v21

    const/16 v21, 0x3a

    const/16 v22, 0x37

    aput-byte v22, v0, v21

    const/16 v21, 0x3b

    aput-byte v8, v0, v21

    const/16 v22, 0x3c

    const/16 v23, 0x68

    aput-byte v23, v0, v22

    const/16 v22, 0x3d

    const/16 v23, 0x44

    aput-byte v23, v0, v22

    const/16 v22, 0x3e

    const/16 v23, 0x3c

    aput-byte v23, v0, v22

    const/16 v22, 0x6e

    const/16 v23, 0x3f

    aput-byte v22, v0, v23

    new-array v2, v12, [B

    aput-byte v6, v2, v1

    aput-byte v19, v2, v3

    const/16 v24, 0x45

    aput-byte v24, v2, v4

    const/16 v24, 0x6a

    aput-byte v24, v2, v6

    aput-byte v8, v2, v7

    const/16 v24, 0x79

    aput-byte v24, v2, v8

    const/16 v24, 0x4c

    aput-byte v24, v2, v9

    aput-byte v15, v2, v10

    invoke-static {v0, v2}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v0

    new-instance v2, Ljava/util/HashMap;

    invoke-direct {v2}, Ljava/util/HashMap;-><init>()V

    new-array v5, v13, [B

    const/16 v25, 0x7d

    aput-byte v25, v5, v1

    aput-byte v12, v5, v3

    const/16 v25, -0x45

    aput-byte v25, v5, v4

    const/16 v25, -0x4d

    aput-byte v25, v5, v6

    const/16 v25, -0x77

    aput-byte v25, v5, v7

    const/16 v25, -0x64

    aput-byte v25, v5, v8

    const/16 v25, -0x9

    aput-byte v25, v5, v9

    const/16 v25, -0x37

    aput-byte v25, v5, v10

    const/16 v25, 0x46

    aput-byte v25, v5, v12

    const/16 v25, 0x9

    aput-byte v16, v5, v25

    new-array v15, v12, [B

    aput-byte v11, v15, v1

    const/16 v26, 0x7b

    aput-byte v26, v15, v3

    const/16 v26, -0x22

    aput-byte v26, v15, v4

    const/16 v26, -0x3f

    aput-byte v26, v15, v6

    const/16 v26, -0x5c

    aput-byte v26, v15, v7

    const/16 v26, -0x23

    aput-byte v26, v15, v8

    const/16 v26, -0x70

    aput-byte v26, v15, v9

    const/16 v26, -0x54

    aput-byte v26, v15, v10

    invoke-static {v5, v15}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v5

    const/16 v15, 0x6f

    new-array v15, v15, [B

    const/16 v26, -0x19

    aput-byte v26, v15, v1

    const/16 v26, -0x60

    aput-byte v26, v15, v3

    const/16 v26, 0x71

    aput-byte v26, v15, v4

    const/16 v26, 0x77

    aput-byte v26, v15, v6

    const/16 v26, 0x48

    aput-byte v26, v15, v7

    const/16 v26, 0x73

    aput-byte v26, v15, v8

    aput-byte v21, v15, v9

    const/16 v26, 0x49

    aput-byte v26, v15, v10

    const/16 v26, -0x61

    aput-byte v26, v15, v12

    const/16 v26, 0x9

    const/16 v27, -0x1f

    aput-byte v27, v15, v26

    aput-byte v21, v15, v13

    const/16 v26, 0x3e

    aput-byte v26, v15, v14

    const/16 v26, 0xc

    const/16 v27, 0xc

    aput-byte v27, v15, v26

    const/16 v26, 0x48

    const/16 v25, 0xd

    aput-byte v26, v15, v25

    const/16 v26, 0xe

    const/16 v27, 0x33

    aput-byte v27, v15, v26

    aput-byte v12, v15, v16

    const/16 v26, 0x10

    const/16 v27, -0x32

    aput-byte v27, v15, v26

    const/16 v26, 0x11

    const/16 v27, -0x60

    aput-byte v27, v15, v26

    const/16 v26, 0x12

    const/16 v27, 0x7c

    aput-byte v27, v15, v26

    const/16 v26, 0x13

    const/16 v27, 0x6d

    aput-byte v27, v15, v26

    const/16 v26, 0x14

    aput-byte v7, v15, v26

    const/16 v26, 0x15

    const/16 v27, 0x51

    aput-byte v27, v15, v26

    const/16 v26, 0x16

    const/16 v27, 0xe

    aput-byte v27, v15, v26

    const/16 v26, 0x17

    const/16 v27, 0x46

    aput-byte v27, v15, v26

    const/16 v26, 0x18

    const/16 v27, -0x65

    aput-byte v27, v15, v26

    const/16 v26, 0x19

    const/16 v27, -0x1

    aput-byte v27, v15, v26

    const/16 v26, 0x1a

    const/16 v27, 0x25

    aput-byte v27, v15, v26

    const/16 v26, 0x1b

    const/16 v27, 0x2e

    aput-byte v27, v15, v26

    const/16 v26, 0x1c

    aput-byte v19, v15, v26

    const/16 v26, 0x1d

    aput-byte v23, v15, v26

    const/16 v26, 0x1e

    const/16 v25, 0xd

    aput-byte v25, v15, v26

    aput-byte v16, v15, v19

    const/16 v26, 0x20

    const/16 v27, -0x3c

    aput-byte v27, v15, v26

    const/16 v26, 0x21

    const/16 v27, -0x7

    aput-byte v27, v15, v26

    const/16 v24, 0x22

    aput-byte v23, v15, v24

    const/16 v26, 0x23

    const/16 v27, 0x25

    aput-byte v27, v15, v26

    aput-byte v7, v15, v17

    const/16 v26, 0x25

    const/16 v27, 0x67

    aput-byte v27, v15, v26

    const/16 v26, 0x26

    aput-byte v18, v15, v26

    const/16 v26, 0x27

    const/16 v27, 0x52

    aput-byte v27, v15, v26

    const/16 v26, -0x7d

    aput-byte v26, v15, v11

    const/16 v26, 0x29

    const/16 v27, -0x11

    aput-byte v27, v15, v26

    const/16 v26, 0x2a

    const/16 v27, 0x4a

    aput-byte v27, v15, v26

    const/16 v26, 0x2b

    const/16 v27, 0x6e

    aput-byte v27, v15, v26

    const/16 v26, 0x2c

    const/16 v27, 0x54

    aput-byte v27, v15, v26

    const/16 v26, 0x2d

    const/16 v27, 0x73

    aput-byte v27, v15, v26

    const/16 v26, 0x2e

    aput-byte v23, v15, v26

    const/16 v26, 0x2f

    const/16 v22, 0x31

    aput-byte v22, v15, v26

    const/16 v26, -0x31

    aput-byte v26, v15, v20

    const/16 v26, -0x53

    aput-byte v26, v15, v22

    const/16 v26, 0x32

    const/16 v27, 0x40

    aput-byte v27, v15, v26

    const/16 v26, 0x33

    const/16 v27, 0x77

    aput-byte v27, v15, v26

    const/16 v26, 0x34

    const/16 v27, 0x50

    aput-byte v27, v15, v26

    const/16 v26, 0x35

    aput-byte v20, v15, v26

    const/16 v26, 0x36

    const/16 v27, 0x6f

    aput-byte v27, v15, v26

    const/16 v26, 0x37

    const/16 v27, 0x55

    aput-byte v27, v15, v26

    const/16 v26, 0x38

    const/16 v27, -0x63

    aput-byte v27, v15, v26

    const/16 v26, 0x39

    const/16 v27, -0x1f

    aput-byte v27, v15, v26

    const/16 v26, 0x3a

    const/16 v27, 0x38

    aput-byte v27, v15, v26

    aput-byte v11, v15, v21

    const/16 v26, 0x3c

    aput-byte v7, v15, v26

    const/16 v26, 0x3d

    const/16 v27, 0x37

    aput-byte v27, v15, v26

    const/16 v26, 0x3e

    const/16 v27, 0x11

    aput-byte v27, v15, v26

    const/16 v26, 0x2e

    aput-byte v26, v15, v23

    const/16 v26, 0x40

    const/16 v27, -0x2

    aput-byte v27, v15, v26

    const/16 v26, 0x41

    const/16 v27, -0x7e

    aput-byte v27, v15, v26

    const/16 v26, 0x42

    const/16 v27, 0x47

    aput-byte v27, v15, v26

    const/16 v26, 0x43

    const/16 v27, 0x32

    aput-byte v27, v15, v26

    const/16 v26, 0x44

    aput-byte v7, v15, v26

    const/16 v26, 0x45

    const/16 v27, 0x73

    aput-byte v27, v15, v26

    const/16 v26, 0x46

    const/16 v27, 0x33

    aput-byte v27, v15, v26

    const/16 v26, 0x47

    const/16 v25, 0xd

    aput-byte v25, v15, v26

    const/16 v26, 0x48

    const/16 v27, -0x31

    aput-byte v27, v15, v26

    const/16 v26, 0x49

    const/16 v27, -0x11

    aput-byte v27, v15, v26

    const/16 v26, 0x4a

    const/16 v27, 0x4c

    aput-byte v27, v15, v26

    const/16 v26, 0x4b

    const/16 v27, 0x7b

    aput-byte v27, v15, v26

    const/16 v26, 0x4c

    const/16 v27, 0x47

    aput-byte v27, v15, v26

    const/16 v26, 0x4d

    const/16 v27, 0x74

    aput-byte v27, v15, v26

    const/16 v26, 0x4e

    const/16 v27, 0x35

    aput-byte v27, v15, v26

    const/16 v26, 0x4f

    const/16 v27, 0x4f

    aput-byte v27, v15, v26

    const/16 v26, 0x50

    const/16 v27, -0x76

    aput-byte v27, v15, v26

    const/16 v26, 0x51

    const/16 v27, -0x74

    aput-byte v27, v15, v26

    const/16 v26, 0x52

    const/16 v27, 0x63

    aput-byte v27, v15, v26

    const/16 v26, 0x53

    aput-byte v18, v15, v26

    const/16 v26, 0x54

    const/16 v27, 0x4b

    aput-byte v27, v15, v26

    const/16 v26, 0x55

    const/16 v27, 0x72

    aput-byte v27, v15, v26

    const/16 v26, 0x56

    aput-byte v23, v15, v26

    const/16 v26, 0x57

    const/16 v27, 0x49

    aput-byte v27, v15, v26

    const/16 v26, 0x58

    const/16 v27, -0x65

    aput-byte v27, v15, v26

    const/16 v26, 0x59

    const/16 v27, -0x2

    aput-byte v27, v15, v26

    const/16 v26, 0x5a

    const/16 v27, 0x3c

    aput-byte v27, v15, v26

    const/16 v26, 0x5b

    aput-byte v20, v15, v26

    const/16 v26, 0x5c

    const/16 v27, 0x14

    aput-byte v27, v15, v26

    const/16 v26, 0x5d

    const/16 v22, 0x31

    aput-byte v22, v15, v26

    const/16 v26, 0x5e

    const/16 v27, 0x6a

    aput-byte v27, v15, v26

    const/16 v26, 0x5f

    const/16 v27, 0x48

    aput-byte v27, v15, v26

    const/16 v26, 0x60

    const/16 v27, -0x66

    aput-byte v27, v15, v26

    const/16 v26, 0x61

    const/16 v27, -0x11

    aput-byte v27, v15, v26

    const/16 v26, 0x62

    const/16 v27, 0x58

    aput-byte v27, v15, v26

    const/16 v26, 0x63

    const/16 v27, 0x7f

    aput-byte v27, v15, v26

    const/16 v26, 0x64

    const/16 v27, 0x42

    aput-byte v27, v15, v26

    const/16 v26, 0x65

    const/16 v27, 0x7e

    aput-byte v27, v15, v26

    const/16 v26, 0x66

    aput-byte v11, v15, v26

    const/16 v26, 0x67

    aput-byte v16, v15, v26

    const/16 v26, 0x68

    const/16 v27, -0x7b

    aput-byte v27, v15, v26

    const/16 v26, 0x69

    const/16 v27, -0x6

    aput-byte v27, v15, v26

    const/16 v26, 0x6a

    const/16 v27, 0x38

    aput-byte v27, v15, v26

    const/16 v26, 0x6b

    const/16 v27, 0x29

    aput-byte v27, v15, v26

    aput-byte v13, v15, v18

    const/16 v26, 0x6d

    const/16 v27, 0x2c

    aput-byte v27, v15, v26

    const/16 v26, 0x6e

    aput-byte v18, v15, v26

    new-array v11, v12, [B

    const/16 v27, -0x56

    aput-byte v27, v11, v1

    const/16 v27, -0x31

    aput-byte v27, v11, v3

    aput-byte v14, v11, v4

    const/16 v27, 0x1e

    aput-byte v27, v11, v6

    aput-byte v17, v11, v7

    aput-byte v19, v11, v8

    const/16 v27, 0x5a

    aput-byte v27, v11, v9

    const/16 v27, 0x66

    aput-byte v27, v11, v10

    invoke-static {v15, v11}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v11

    invoke-virtual {v2, v5, v11}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    new-array v5, v10, [B

    const/16 v11, 0x20

    aput-byte v11, v5, v1

    const/16 v11, -0x69

    aput-byte v11, v5, v3

    const/16 v11, -0x7c

    aput-byte v11, v5, v4

    const/16 v11, 0x15

    aput-byte v11, v5, v6

    const/4 v11, -0x8

    aput-byte v11, v5, v7

    aput-byte v6, v5, v8

    const/16 v11, 0x66

    aput-byte v11, v5, v9

    new-array v11, v12, [B

    const/16 v15, 0x72

    aput-byte v15, v11, v1

    const/16 v15, -0xe

    aput-byte v15, v11, v3

    const/16 v15, -0x1e

    aput-byte v15, v11, v4

    const/16 v15, 0x70

    aput-byte v15, v11, v6

    const/16 v15, -0x76

    aput-byte v15, v11, v7

    const/16 v15, 0x66

    aput-byte v15, v11, v8

    const/16 v15, 0x14

    aput-byte v15, v11, v9

    const/16 v15, 0x71

    aput-byte v15, v11, v10

    invoke-static {v5, v11}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v5

    const/16 v11, 0x16

    new-array v11, v11, [B

    const/16 v15, 0x22

    aput-byte v15, v11, v1

    const/16 v15, -0x4c

    aput-byte v15, v11, v3

    const/16 v15, -0x4f

    aput-byte v15, v11, v4

    const/16 v15, 0x6f

    aput-byte v15, v11, v6

    const/16 v15, 0x5c

    aput-byte v15, v11, v7

    const/16 v15, -0x60

    aput-byte v15, v11, v8

    const/16 v15, -0x6a

    aput-byte v15, v11, v9

    const/16 v15, -0x41

    aput-byte v15, v11, v10

    const/16 v15, 0x3a

    aput-byte v15, v11, v12

    const/16 v15, 0x9

    const/16 v27, -0x5f

    aput-byte v27, v11, v15

    const/16 v15, -0x55

    aput-byte v15, v11, v13

    const/16 v15, 0x31

    aput-byte v15, v11, v14

    const/16 v15, 0xc

    const/16 v27, 0x4d

    aput-byte v27, v11, v15

    const/4 v15, -0x5

    const/16 v25, 0xd

    aput-byte v15, v11, v25

    const/16 v15, 0xe

    const/16 v27, -0x30

    aput-byte v27, v11, v15

    const/16 v15, -0xc

    aput-byte v15, v11, v16

    const/16 v15, 0x10

    aput-byte v23, v11, v15

    const/16 v15, 0x11

    const/16 v23, -0x12

    aput-byte v23, v11, v15

    const/16 v15, 0x12

    const/16 v23, -0x5a

    aput-byte v23, v11, v15

    const/16 v15, 0x13

    const/16 v23, 0x70

    aput-byte v23, v11, v15

    const/16 v15, 0x14

    const/16 v23, 0x42

    aput-byte v23, v11, v15

    const/16 v15, 0x15

    const/16 v23, -0x4b

    aput-byte v23, v11, v15

    new-array v15, v12, [B

    const/16 v23, 0x4a

    aput-byte v23, v15, v1

    const/16 v23, -0x40

    aput-byte v23, v15, v3

    const/16 v23, -0x3b

    aput-byte v23, v15, v4

    aput-byte v19, v15, v6

    const/16 v23, 0x2f

    aput-byte v23, v15, v7

    const/16 v23, -0x66

    aput-byte v23, v15, v8

    const/16 v23, -0x47

    aput-byte v23, v15, v9

    const/16 v23, -0x70

    aput-byte v23, v15, v10

    invoke-static {v11, v15}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v11

    invoke-virtual {v2, v5, v11}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    new-instance v5, Lorg/json/JSONObject;

    invoke-static {v0, v2}, Lcom/github/catvod/spider/appysv2/n/c;->m(Ljava/lang/String;Ljava/util/Map;)Ljava/lang/String;

    move-result-object v0

    invoke-direct {v5, v0}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    invoke-virtual {v5}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lcom/github/catvod/crawler/SpiderDebug;->log(Ljava/lang/String;)V

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    new-array v2, v12, [B

    const/16 v11, -0x5a

    aput-byte v11, v2, v1

    const/4 v11, -0x4

    aput-byte v11, v2, v3

    const/16 v11, 0x5f

    aput-byte v11, v2, v4

    const/16 v11, -0x33

    aput-byte v11, v2, v6

    const/16 v11, 0x78

    aput-byte v11, v2, v7

    const/16 v11, 0x78

    aput-byte v11, v2, v8

    aput-byte v14, v2, v9

    const/16 v11, -0x34

    aput-byte v11, v2, v10

    new-array v11, v12, [B

    const/16 v15, -0x32

    aput-byte v15, v11, v1

    const/16 v15, -0x78

    aput-byte v15, v11, v3

    const/16 v15, 0x2b

    aput-byte v15, v11, v4

    const/16 v15, -0x43

    aput-byte v15, v11, v6

    aput-byte v14, v11, v7

    const/16 v15, 0x42

    aput-byte v15, v11, v8

    aput-byte v17, v11, v9

    const/16 v15, -0x1d

    aput-byte v15, v11, v10

    invoke-static {v2, v11}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    new-array v2, v9, [B

    const/16 v11, 0x23

    aput-byte v11, v2, v1

    const/16 v11, 0x43

    aput-byte v11, v2, v3

    const/16 v11, -0x71

    aput-byte v11, v2, v4

    const/16 v11, 0x78

    aput-byte v11, v2, v6

    const/16 v11, -0x13

    aput-byte v11, v2, v7

    const/16 v11, -0x24

    aput-byte v11, v2, v8

    new-array v11, v12, [B

    const/16 v15, 0x4a

    aput-byte v15, v11, v1

    const/16 v15, 0x2e

    aput-byte v15, v11, v3

    const/16 v15, -0x18

    aput-byte v15, v11, v4

    const/16 v15, 0xd

    aput-byte v15, v11, v6

    const/16 v15, -0x61

    aput-byte v15, v11, v7

    const/16 v15, -0x50

    aput-byte v15, v11, v8

    const/16 v15, 0x50

    aput-byte v15, v11, v9

    const/16 v15, -0x4c

    aput-byte v15, v11, v10

    invoke-static {v2, v11}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v5, v2}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v2, 0x3c

    new-array v2, v2, [B

    const/16 v11, -0x17

    aput-byte v11, v2, v1

    const/16 v11, -0x2a

    aput-byte v11, v2, v3

    const/16 v11, 0x6d

    aput-byte v11, v2, v4

    aput-byte v20, v2, v6

    const/16 v11, -0x4d

    aput-byte v11, v2, v7

    const/16 v11, 0x6b

    aput-byte v11, v2, v8

    const/16 v11, -0x22

    aput-byte v11, v2, v9

    const/16 v11, 0x26

    aput-byte v11, v2, v10

    const/16 v11, -0xe

    aput-byte v11, v2, v12

    const/16 v11, 0x9

    const/16 v15, -0x32

    aput-byte v15, v2, v11

    const/16 v11, 0x70

    aput-byte v11, v2, v13

    const/16 v11, 0x36

    aput-byte v11, v2, v14

    const/16 v11, 0xc

    const/16 v14, -0x80

    aput-byte v14, v2, v11

    const/16 v11, 0x6f

    const/16 v14, 0xd

    aput-byte v11, v2, v14

    const/16 v11, 0xe

    const/16 v14, -0x10

    aput-byte v14, v2, v11

    const/16 v11, 0x27

    aput-byte v11, v2, v16

    const/16 v11, 0x10

    const/16 v14, -0x16

    aput-byte v14, v2, v11

    const/16 v11, 0x11

    const/16 v14, -0x77

    aput-byte v14, v2, v11

    const/16 v11, 0x12

    const/16 v14, 0x43

    aput-byte v14, v2, v11

    const/16 v11, 0x13

    const/16 v14, 0x27

    aput-byte v14, v2, v11

    const/16 v11, 0x14

    const/16 v14, -0x80

    aput-byte v14, v2, v11

    const/16 v11, 0x15

    const/16 v14, 0x55

    aput-byte v14, v2, v11

    const/16 v11, 0x16

    const/16 v14, -0x2b

    aput-byte v14, v2, v11

    const/16 v11, 0x17

    const/16 v14, 0x2c

    aput-byte v14, v2, v11

    const/16 v11, 0x18

    const/16 v14, -0x58

    aput-byte v14, v2, v11

    const/16 v11, 0x19

    const/16 v14, -0x2d

    aput-byte v14, v2, v11

    const/16 v11, 0x1a

    aput-byte v18, v2, v11

    const/16 v11, 0x1b

    const/16 v14, 0x21

    aput-byte v14, v2, v11

    const/16 v11, 0x1c

    const/16 v14, -0x2a

    aput-byte v14, v2, v11

    const/16 v11, 0x1d

    const/16 v14, 0x55

    aput-byte v14, v2, v11

    const/16 v11, 0x1e

    const/16 v14, -0x78

    aput-byte v14, v2, v11

    const/16 v11, 0x74

    aput-byte v11, v2, v19

    const/16 v11, 0x20

    const/4 v14, -0x5

    aput-byte v14, v2, v11

    const/16 v11, 0x21

    const/16 v14, -0x78

    aput-byte v14, v2, v11

    const/16 v11, 0x22

    aput-byte v21, v2, v11

    const/16 v11, 0x23

    const/16 v14, 0x60

    aput-byte v14, v2, v11

    const/16 v11, -0x2d

    aput-byte v11, v2, v17

    const/16 v11, 0x25

    const/16 v14, 0x38

    aput-byte v14, v2, v11

    const/16 v11, 0x26

    const/16 v14, -0x77

    aput-byte v14, v2, v11

    const/16 v11, 0x27

    const/16 v14, 0x76

    aput-byte v14, v2, v11

    const/16 v11, -0x16

    const/16 v14, 0x28

    aput-byte v11, v2, v14

    const/16 v11, 0x29

    const/16 v14, -0x78

    aput-byte v14, v2, v11

    const/16 v11, 0x2a

    const/16 v14, 0x41

    aput-byte v14, v2, v11

    const/16 v11, 0x2b

    aput-byte v21, v2, v11

    const/16 v11, 0x2c

    const/16 v14, -0x74

    aput-byte v14, v2, v11

    const/16 v11, 0x2d

    const/16 v14, 0x6d

    aput-byte v14, v2, v11

    const/16 v11, 0x2e

    const/16 v14, -0x17

    aput-byte v14, v2, v11

    const/16 v11, 0x2f

    const/16 v14, 0x22

    aput-byte v14, v2, v11

    const/16 v11, -0x58

    aput-byte v11, v2, v20

    const/16 v11, -0x21

    const/16 v14, 0x31

    aput-byte v11, v2, v14

    const/16 v11, 0x32

    const/16 v14, 0x27

    aput-byte v14, v2, v11

    const/16 v11, 0x33

    const/16 v14, 0x64

    aput-byte v14, v2, v11

    const/16 v11, 0x34

    const/16 v14, -0x5e

    aput-byte v14, v2, v11

    const/16 v11, 0x35

    const/16 v14, 0x66

    aput-byte v14, v2, v11

    const/16 v11, 0x36

    const/16 v14, -0x2a

    aput-byte v14, v2, v11

    const/16 v11, 0x37

    aput-byte v17, v2, v11

    const/16 v11, 0x38

    const/16 v14, -0x5a

    aput-byte v14, v2, v11

    const/16 v11, 0x39

    const/16 v14, -0x2c

    aput-byte v14, v2, v11

    const/16 v11, 0x3a

    const/16 v14, 0x74

    aput-byte v14, v2, v11

    const/16 v11, 0x62

    aput-byte v11, v2, v21

    new-array v11, v12, [B

    const/16 v14, -0x31

    aput-byte v14, v11, v1

    const/16 v14, -0x46

    aput-byte v14, v11, v3

    aput-byte v4, v11, v4

    const/16 v14, 0x57

    aput-byte v14, v11, v6

    const/16 v14, -0x1d

    aput-byte v14, v11, v7

    aput-byte v13, v11, v8

    const/16 v13, -0x47

    aput-byte v13, v11, v9

    const/16 v13, 0x43

    aput-byte v13, v11, v10

    invoke-static {v2, v11}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    new-array v2, v7, [B

    const/4 v11, -0x3

    aput-byte v11, v2, v1

    const/16 v11, 0x45

    aput-byte v11, v2, v3

    const/16 v11, 0x56

    aput-byte v11, v2, v4

    const/16 v11, 0x58

    aput-byte v11, v2, v6

    new-array v11, v12, [B

    const/16 v12, -0x72

    aput-byte v12, v11, v1

    const/16 v12, 0x2c

    aput-byte v12, v11, v3

    const/16 v12, 0x31

    aput-byte v12, v11, v4

    const/16 v4, 0x36

    aput-byte v4, v11, v6

    const/16 v4, -0x45

    aput-byte v4, v11, v7

    const/16 v4, 0x28

    aput-byte v4, v11, v8

    aput-byte v8, v11, v9

    const/16 v4, 0x51

    aput-byte v4, v11, v10

    invoke-static {v2, v11}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v5, v2}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    sput-object v2, Lcom/github/catvod/spider/appysv2/b/A;->d:Ljava/lang/String;

    invoke-static {v0}, Lcom/github/catvod/spider/appysv2/n/c;->d(Ljava/lang/String;)Lokhttp3/Response;

    move-result-object v0

    invoke-virtual {v0}, Lokhttp3/Response;->body()Lokhttp3/ResponseBody;

    move-result-object v0

    invoke-virtual {v0}, Lokhttp3/ResponseBody;->bytes()[B

    move-result-object v0

    array-length v2, v0

    invoke-static {v0, v1, v2}, Landroid/graphics/BitmapFactory;->decodeByteArray([BII)Landroid/graphics/Bitmap;

    move-result-object v0

    sput-object v0, Lcom/github/catvod/spider/appysv2/b/A;->c:Landroid/graphics/Bitmap;

    sget-object v0, Lcom/github/catvod/spider/appysv2/b/A;->d:Ljava/lang/String;

    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0
    :try_end_777
    .catch Ljava/lang/Exception; {:try_start_3 .. :try_end_777} :catch_779

    xor-int/2addr v0, v3

    return v0

    :catch_779
    return v1
.end method

.method private m(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    .registers 4

    :try_start_0
    iget-object v0, p0, Lcom/github/catvod/spider/appysv2/b/A;->b:Ljava/util/HashMap;

    invoke-virtual {v0, p1}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/util/Map;

    invoke-interface {p1, p2}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/lang/String;
    :try_end_e
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_e} :catch_f

    return-object p1

    :catch_f
    move-exception p1

    invoke-virtual {p1}, Ljava/lang/Throwable;->printStackTrace()V

    const-string p1, ""

    return-object p1
.end method

.method private n()Lcom/github/catvod/spider/appysv2/f/a;
    .registers 29

    const/16 v1, 0x72

    :try_start_2
    new-array v1, v1, [B

    const/16 v2, 0x23

    const/4 v3, 0x0

    aput-byte v2, v1, v3

    const/16 v4, 0x36

    const/4 v5, 0x1

    aput-byte v4, v1, v5

    const/16 v4, -0x79

    const/4 v6, 0x2

    aput-byte v4, v1, v6

    const/16 v4, 0xf

    const/4 v7, 0x3

    aput-byte v4, v1, v7

    const/16 v4, 0x47

    const/4 v8, 0x4

    aput-byte v4, v1, v8

    const/16 v4, -0x3a

    const/4 v9, 0x5

    aput-byte v4, v1, v9

    const/16 v4, 0x79

    const/4 v10, 0x6

    aput-byte v4, v1, v10

    const/4 v4, 0x7

    aput-byte v2, v1, v4

    const/16 v11, 0x3b

    const/16 v12, 0x8

    aput-byte v11, v1, v12

    const/16 v11, 0x9

    aput-byte v2, v1, v11

    const/16 v11, 0xa

    const/16 v13, -0x63

    aput-byte v13, v1, v11

    const/16 v11, 0xb

    const/16 v13, 0x51

    aput-byte v13, v1, v11

    const/16 v11, 0x56

    const/16 v13, 0xc

    aput-byte v11, v1, v13

    const/16 v11, 0xd

    const/16 v14, -0x63

    aput-byte v14, v1, v11

    const/16 v11, 0xe

    const/16 v14, 0x3f

    aput-byte v14, v1, v11

    const/16 v11, 0xf

    const/16 v15, 0x68

    aput-byte v15, v1, v11

    const/16 v11, 0x10

    const/16 v15, 0x3e

    aput-byte v15, v1, v11

    const/16 v11, 0x11

    const/16 v15, 0x6c

    aput-byte v15, v1, v11

    const/16 v11, 0x12

    const/16 v15, -0x70

    aput-byte v15, v1, v11

    const/16 v11, 0x13

    const/16 v15, 0x10

    aput-byte v15, v1, v11

    const/16 v11, 0x14

    const/16 v15, 0x59

    aput-byte v15, v1, v11

    const/16 v11, 0x15

    const/16 v16, -0x2d

    aput-byte v16, v1, v11

    const/16 v11, 0x16

    const/16 v16, 0x37

    aput-byte v16, v1, v11

    const/16 v11, 0x17

    const/16 v16, 0x7c

    aput-byte v16, v1, v11

    const/16 v11, 0x18

    const/16 v16, 0x22

    aput-byte v16, v1, v11

    const/16 v11, 0x19

    const/16 v16, 0x6d

    aput-byte v16, v1, v11

    const/16 v11, 0x1a

    const/16 v17, -0x61

    aput-byte v17, v1, v11

    const/16 v11, 0x1b

    const/16 v17, 0x16

    aput-byte v17, v1, v11

    const/16 v11, 0x1c

    const/16 v17, 0x47

    aput-byte v17, v1, v11

    const/16 v11, 0x1d

    const/16 v17, -0x78

    aput-byte v17, v1, v11

    const/16 v11, 0x1e

    const/16 v17, 0x69

    aput-byte v17, v1, v11

    const/16 v11, 0x1f

    const/16 v17, 0x6f

    aput-byte v17, v1, v11

    const/16 v11, 0x20

    const/16 v17, 0x27

    aput-byte v17, v1, v11

    const/16 v11, 0x21

    const/16 v4, 0x2b

    aput-byte v4, v1, v11

    const/16 v11, 0x22

    const/16 v19, -0x6a

    aput-byte v19, v1, v11

    const/16 v11, 0x11

    aput-byte v11, v1, v2

    const/16 v11, 0x40

    const/16 v19, 0x24

    aput-byte v11, v1, v19

    const/16 v11, 0x25

    const/16 v20, -0x78

    aput-byte v20, v1, v11

    const/16 v11, 0x2f

    const/16 v20, 0x26

    aput-byte v11, v1, v20

    const/16 v11, 0x7c

    aput-byte v11, v1, v17

    const/16 v11, 0x28

    const/16 v21, 0x2e

    aput-byte v21, v1, v11

    const/16 v11, 0x7f

    const/16 v21, 0x29

    aput-byte v11, v1, v21

    const/16 v11, 0x2a

    const/16 v22, -0x3d

    aput-byte v22, v1, v11

    aput-byte v15, v1, v4

    const/16 v11, 0x2c

    const/16 v22, 0x55

    aput-byte v22, v1, v11

    const/16 v11, 0x2d

    const/16 v22, -0x74

    aput-byte v22, v1, v11

    const/16 v11, 0x2e

    aput-byte v20, v1, v11

    const/16 v11, 0x2f

    const/16 v22, 0x53

    aput-byte v22, v1, v11

    const/16 v11, 0x30

    const/16 v22, 0x22

    aput-byte v22, v1, v11

    const/16 v11, 0x31

    aput-byte v20, v1, v11

    const/16 v22, 0x32

    const/16 v23, -0x32

    aput-byte v23, v1, v22

    const/16 v22, 0x33

    const/16 v23, 0x4d

    aput-byte v23, v1, v22

    const/16 v22, 0x34

    aput-byte v5, v1, v22

    const/16 v22, 0x35

    const/16 v23, -0x34

    aput-byte v23, v1, v22

    const/16 v22, 0x36

    const/16 v23, 0x63

    aput-byte v23, v1, v22

    const/16 v22, 0x37

    const/16 v23, 0x3e

    aput-byte v23, v1, v22

    const/16 v22, 0x38

    const/16 v23, 0x73

    aput-byte v23, v1, v22

    const/16 v22, 0x39

    const/16 v23, 0x64

    aput-byte v23, v1, v22

    const/16 v22, 0x3a

    const/16 v24, -0x7c

    aput-byte v24, v1, v22

    const/16 v22, 0x3b

    const/16 v24, 0x1a

    aput-byte v24, v1, v22

    const/16 v22, 0x3c

    const/16 v24, 0x56

    aput-byte v24, v1, v22

    const/16 v22, 0x3d

    const/16 v24, -0x3f

    aput-byte v24, v1, v22

    const/16 v22, 0x3e

    const/16 v24, 0x67

    aput-byte v24, v1, v22

    const/16 v22, 0x2a

    aput-byte v22, v1, v14

    const/16 v22, 0x40

    const/16 v24, 0x2f

    aput-byte v24, v1, v22

    const/16 v22, 0x41

    const/16 v24, 0x32

    aput-byte v24, v1, v22

    const/16 v22, 0x42

    const/16 v24, -0x22

    aput-byte v24, v1, v22

    const/16 v22, 0x43

    const/16 v24, 0x13

    aput-byte v24, v1, v22

    const/16 v22, 0x44

    const/16 v24, 0x5b

    aput-byte v24, v1, v22

    const/16 v22, 0x45

    const/16 v24, -0x65

    aput-byte v24, v1, v22

    const/16 v22, 0x46

    aput-byte v14, v1, v22

    const/16 v22, 0x47

    const/16 v24, 0x68

    aput-byte v24, v1, v22

    const/16 v22, 0x48

    const/16 v24, 0x76

    aput-byte v24, v1, v22

    const/16 v22, 0x49

    aput-byte v23, v1, v22

    const/16 v22, 0x4a

    const/16 v24, -0x64

    aput-byte v24, v1, v22

    const/16 v22, 0x4b

    const/16 v24, 0xd

    aput-byte v24, v1, v22

    const/16 v22, 0x4c

    const/16 v24, 0x50

    aput-byte v24, v1, v22

    const/16 v22, 0x4d

    const/16 v24, -0x67

    aput-byte v24, v1, v22

    const/16 v22, 0x4e

    aput-byte v19, v1, v22

    const/16 v22, 0x4f

    aput-byte v11, v1, v22

    const/16 v22, 0x50

    aput-byte v14, v1, v22

    const/16 v22, 0x51

    aput-byte v4, v1, v22

    const/16 v22, 0x52

    const/16 v24, -0x62

    aput-byte v24, v1, v22

    const/16 v22, 0x53

    const/16 v24, 0x1a

    aput-byte v24, v1, v22

    const/16 v22, 0x54

    const/16 v24, 0x12

    aput-byte v24, v1, v22

    const/16 v22, 0x55

    const/16 v24, -0x68

    aput-byte v24, v1, v22

    const/16 v22, 0x56

    const/16 v24, 0x33

    aput-byte v24, v1, v22

    const/16 v22, 0x57

    const/16 v24, 0x7f

    aput-byte v24, v1, v22

    const/16 v22, 0x58

    const/16 v24, 0x28

    aput-byte v24, v1, v22

    const/16 v22, 0x7f

    aput-byte v22, v1, v15

    const/16 v22, 0x5a

    const/16 v24, -0x3e

    aput-byte v24, v1, v22

    const/16 v22, 0x5b

    aput-byte v15, v1, v22

    const/16 v22, 0x5c

    const/16 v24, 0x50

    aput-byte v24, v1, v22

    const/16 v22, 0x5d

    const/16 v24, -0x6b

    aput-byte v24, v1, v22

    const/16 v22, 0x5e

    aput-byte v19, v1, v22

    const/16 v22, 0x5f

    aput-byte v11, v1, v22

    const/16 v22, 0x60

    const/16 v24, 0x6e

    aput-byte v24, v1, v22

    const/16 v22, 0x61

    const/16 v25, 0x70

    aput-byte v25, v1, v22

    const/16 v22, 0x62

    const/16 v25, -0x4b

    aput-byte v25, v1, v22

    const/16 v22, 0x63

    aput-byte v15, v1, v22

    const/16 v22, 0x5a

    aput-byte v22, v1, v23

    const/16 v22, 0x65

    const/16 v25, -0x77

    aput-byte v25, v1, v22

    const/16 v22, 0x66

    const/16 v25, 0x3b

    aput-byte v25, v1, v22

    const/16 v22, 0x67

    aput-byte v11, v1, v22

    const/16 v22, 0x68

    const/16 v25, 0x7a

    aput-byte v25, v1, v22

    const/16 v22, 0x69

    const/16 v25, 0x72

    aput-byte v25, v1, v22

    const/16 v22, 0x6a

    const/16 v25, -0x3d

    aput-byte v25, v1, v22

    const/16 v22, 0x6b

    aput-byte v15, v1, v22

    const/16 v22, 0x6c

    const/16 v25, 0x44

    aput-byte v25, v1, v22

    const/16 v22, -0x63

    aput-byte v22, v1, v16

    aput-byte v11, v1, v24

    const/16 v22, 0x6f

    const/16 v25, 0x69

    aput-byte v25, v1, v22

    const/16 v22, 0x70

    const/16 v25, 0x76

    aput-byte v25, v1, v22

    const/16 v22, 0x71

    const/16 v25, 0x73

    aput-byte v25, v1, v22

    new-array v15, v12, [B

    const/16 v25, 0x4b

    aput-byte v25, v15, v3

    const/16 v25, 0x42

    aput-byte v25, v15, v5

    const/16 v25, -0xd

    aput-byte v25, v15, v6

    const/16 v25, 0x7f

    aput-byte v25, v15, v7

    const/16 v25, 0x34

    aput-byte v25, v15, v8

    const/16 v25, -0x4

    aput-byte v25, v15, v9

    const/16 v25, 0x56

    aput-byte v25, v15, v10

    const/16 v18, 0x7

    aput-byte v13, v15, v18

    invoke-static {v1, v15}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-direct/range {p0 .. p0}, Lcom/github/catvod/spider/appysv2/b/A;->f()Ljava/util/Map;

    move-result-object v15

    invoke-static {v1, v15}, Lcom/github/catvod/spider/appysv2/n/c;->m(Ljava/lang/String;Ljava/util/Map;)Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Lcom/github/catvod/spider/appysv2/f/b;->e(Ljava/lang/String;)Lcom/github/catvod/spider/appysv2/f/b;

    move-result-object v1

    invoke-virtual {v1}, Lcom/github/catvod/spider/appysv2/f/b;->a()I

    move-result v15

    if-nez v15, :cond_2d0

    invoke-virtual {v1}, Lcom/github/catvod/spider/appysv2/f/b;->b()Ljava/util/List;

    move-result-object v1

    invoke-interface {v1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_2b2
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v15

    if-eqz v15, :cond_2d0

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v15

    check-cast v15, Lcom/github/catvod/spider/appysv2/f/a;

    invoke-virtual {v15}, Lcom/github/catvod/spider/appysv2/f/a;->c()Ljava/lang/String;

    move-result-object v11

    sget-object v2, Lcom/github/catvod/spider/appysv2/b/A;->e:Ljava/lang/String;

    invoke-virtual {v11, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_2cb

    return-object v15

    :cond_2cb
    const/16 v2, 0x23

    const/16 v11, 0x31

    goto :goto_2b2

    :cond_2d0
    const/16 v1, 0x88

    new-array v1, v1, [B

    aput-byte v17, v1, v3

    const/16 v2, 0x7f

    aput-byte v2, v1, v5

    const/16 v2, -0x70

    aput-byte v2, v1, v6

    const/16 v2, -0x2e

    aput-byte v2, v1, v7

    const/16 v2, -0x38

    aput-byte v2, v1, v8

    const/16 v2, -0x1a

    aput-byte v2, v1, v9

    aput-byte v16, v1, v10

    const/16 v2, -0x6a

    const/4 v11, 0x7

    aput-byte v2, v1, v11

    aput-byte v14, v1, v12

    const/16 v2, 0x9

    const/16 v11, 0x6a

    aput-byte v11, v1, v2

    const/16 v2, 0xa

    const/16 v11, -0x76

    aput-byte v11, v1, v2

    const/16 v2, 0xb

    const/16 v11, -0x74

    aput-byte v11, v1, v2

    const/16 v2, -0x27

    aput-byte v2, v1, v13

    const/16 v2, 0xd

    const/16 v11, -0x43

    aput-byte v11, v1, v2

    const/16 v2, 0xe

    aput-byte v4, v1, v2

    const/16 v2, 0xf

    const/16 v11, -0x23

    aput-byte v11, v1, v2

    const/16 v2, 0x10

    const/16 v11, 0x3a

    aput-byte v11, v1, v2

    const/16 v2, 0x11

    const/16 v11, 0x25

    aput-byte v11, v1, v2

    const/16 v2, 0x12

    const/16 v11, -0x79

    aput-byte v11, v1, v2

    const/16 v2, 0x13

    const/16 v11, -0x33

    aput-byte v11, v1, v2

    const/16 v2, 0x14

    const/16 v11, -0x2a

    aput-byte v11, v1, v2

    const/16 v2, 0x15

    const/16 v11, -0xd

    aput-byte v11, v1, v2

    const/16 v2, 0x16

    const/16 v11, 0x23

    aput-byte v11, v1, v2

    const/16 v2, 0x17

    const/16 v11, -0x37

    aput-byte v11, v1, v2

    const/16 v2, 0x18

    aput-byte v20, v1, v2

    const/16 v2, 0x19

    aput-byte v19, v1, v2

    const/16 v2, 0x1a

    const/16 v11, -0x7d

    aput-byte v11, v1, v2

    const/16 v2, 0x1b

    const/16 v11, -0x39

    aput-byte v11, v1, v2

    const/16 v2, 0x1c

    const/16 v11, -0x31

    aput-byte v11, v1, v2

    const/16 v2, 0x1d

    const/16 v11, -0x58

    aput-byte v11, v1, v2

    const/16 v2, 0x1e

    aput-byte v17, v1, v2

    const/16 v2, 0x1f

    const/16 v11, -0x2c

    aput-byte v11, v1, v2

    const/16 v2, 0x20

    aput-byte v14, v1, v2

    const/16 v2, 0x21

    const/16 v11, 0x67

    aput-byte v11, v1, v2

    const/16 v2, 0x22

    const/16 v11, -0x7b

    aput-byte v11, v1, v2

    const/16 v2, -0x2a

    const/16 v11, 0x23

    aput-byte v2, v1, v11

    const/16 v2, -0x22

    aput-byte v2, v1, v19

    const/16 v2, 0x25

    const/16 v15, -0x56

    aput-byte v15, v1, v2

    aput-byte v11, v1, v20

    const/16 v2, -0x35

    aput-byte v2, v1, v17

    const/16 v2, 0x28

    aput-byte v20, v1, v2

    const/16 v2, 0x6a

    aput-byte v2, v1, v21

    const/16 v2, 0x2a

    const/16 v11, -0x7a

    aput-byte v11, v1, v2

    const/16 v2, -0x32

    aput-byte v2, v1, v4

    const/16 v2, 0x2c

    const/16 v11, -0x22

    aput-byte v11, v1, v2

    const/16 v2, 0x2d

    const/16 v11, -0x1d

    aput-byte v11, v1, v2

    const/16 v2, 0x2e

    const/16 v11, 0x21

    aput-byte v11, v1, v2

    const/16 v2, 0x2f

    const/16 v11, -0x2b

    aput-byte v11, v1, v2

    const/16 v2, 0x30

    aput-byte v20, v1, v2

    const/16 v2, 0x31

    aput-byte v24, v1, v2

    const/16 v2, 0x32

    const/16 v11, -0x76

    aput-byte v11, v1, v2

    const/16 v2, 0x33

    const/16 v11, -0x2a

    aput-byte v11, v1, v2

    const/16 v2, 0x34

    const/16 v11, -0x31

    aput-byte v11, v1, v2

    const/16 v2, 0x35

    const/16 v11, -0x5b

    aput-byte v11, v1, v2

    const/16 v2, 0x36

    const/16 v11, 0x32

    aput-byte v11, v1, v2

    const/16 v2, 0x37

    const/16 v11, -0x24

    aput-byte v11, v1, v2

    const/16 v2, 0x38

    const/16 v11, 0x72

    aput-byte v11, v1, v2

    const/16 v2, 0x39

    const/16 v11, 0x3b

    aput-byte v11, v1, v2

    const/16 v2, 0x3a

    const/16 v11, -0x3e

    aput-byte v11, v1, v2

    const/16 v2, 0x3b

    const/16 v11, -0x3d

    aput-byte v11, v1, v2

    const/16 v2, 0x3c

    const/16 v11, -0x35

    aput-byte v11, v1, v2

    const/16 v2, 0x3d

    const/16 v11, -0x54

    aput-byte v11, v1, v2

    const/16 v2, 0x3e

    const/16 v11, 0x1d

    aput-byte v11, v1, v2

    const/16 v2, -0x30

    aput-byte v2, v1, v14

    const/16 v2, 0x40

    aput-byte v4, v1, v2

    const/16 v2, 0x41

    const/16 v11, 0x36

    aput-byte v11, v1, v2

    const/16 v2, 0x42

    const/16 v11, -0x2a

    aput-byte v11, v1, v2

    const/16 v2, 0x43

    const/16 v11, -0x69

    aput-byte v11, v1, v2

    const/16 v2, 0x44

    const/16 v11, -0x75

    aput-byte v11, v1, v2

    const/16 v2, 0x45

    const/16 v11, -0x17

    aput-byte v11, v1, v2

    const/16 v2, 0x46

    const/16 v11, 0x70

    aput-byte v11, v1, v2

    const/16 v2, 0x47

    const/16 v11, -0x7f

    aput-byte v11, v1, v2

    const/16 v2, 0x48

    const/16 v11, 0x69

    aput-byte v11, v1, v2

    const/16 v2, 0x49

    const/16 v11, 0x7c

    aput-byte v11, v1, v2

    const/16 v2, 0x4a

    const/16 v11, -0x7f

    aput-byte v11, v1, v2

    const/16 v2, 0x4b

    const/16 v11, -0x40

    aput-byte v11, v1, v2

    const/16 v2, 0x4c

    const/16 v11, -0x7a

    aput-byte v11, v1, v2

    const/16 v2, 0x4d

    const/16 v11, -0x13

    aput-byte v11, v1, v2

    const/16 v2, 0x4e

    aput-byte v23, v1, v2

    const/16 v2, 0x4f

    const/16 v11, -0x21

    aput-byte v11, v1, v2

    const/16 v2, 0x50

    aput-byte v20, v1, v2

    const/16 v2, 0x51

    aput-byte v24, v1, v2

    const/16 v2, 0x52

    const/16 v11, -0x78

    aput-byte v11, v1, v2

    const/16 v2, 0x53

    const/16 v11, -0x3a

    aput-byte v11, v1, v2

    const/16 v2, 0x54

    const/16 v11, -0x38

    aput-byte v11, v1, v2

    const/16 v2, 0x55

    const/16 v11, -0x1f

    aput-byte v11, v1, v2

    const/16 v2, 0x56

    const/16 v11, 0x19

    aput-byte v11, v1, v2

    const/16 v2, 0x57

    const/16 v11, -0x65

    aput-byte v11, v1, v2

    const/16 v2, 0x58

    const/16 v11, 0x2d

    aput-byte v11, v1, v2

    const/16 v2, 0x6f

    const/16 v11, 0x59

    aput-byte v2, v1, v11

    const/16 v2, 0x5a

    const/16 v11, -0x69

    aput-byte v11, v1, v2

    const/16 v2, 0x5b

    const/16 v11, -0x2a

    aput-byte v11, v1, v2

    const/16 v2, 0x5c

    const/16 v11, -0x2c

    aput-byte v11, v1, v2

    const/16 v2, 0x5d

    const/16 v11, -0x49

    aput-byte v11, v1, v2

    const/16 v2, 0x5e

    aput-byte v17, v1, v2

    const/16 v2, 0x5f

    const/16 v11, -0x29

    aput-byte v11, v1, v2

    const/16 v2, 0x60

    aput-byte v16, v1, v2

    const/16 v2, 0x61

    aput-byte v17, v1, v2

    const/16 v2, 0x62

    const/16 v11, -0x3a

    aput-byte v11, v1, v2

    const/16 v2, 0x63

    const/16 v11, -0x2a

    aput-byte v11, v1, v2

    const/16 v2, -0x2c

    aput-byte v2, v1, v23

    const/16 v2, 0x65

    const/16 v11, -0x49

    aput-byte v11, v1, v2

    const/16 v2, 0x66

    aput-byte v17, v1, v2

    const/16 v2, 0x67

    const/16 v11, -0x29

    aput-byte v11, v1, v2

    const/16 v2, 0x68

    aput-byte v16, v1, v2

    const/16 v2, 0x69

    aput-byte v17, v1, v2

    const/16 v2, 0x6a

    const/16 v11, -0x3a

    aput-byte v11, v1, v2

    const/16 v2, 0x6b

    const/16 v11, -0x29

    aput-byte v11, v1, v2

    const/16 v2, 0x6c

    const/16 v11, -0x30

    aput-byte v11, v1, v2

    const/4 v2, -0x2

    aput-byte v2, v1, v16

    aput-byte v24, v1, v24

    const/16 v2, 0x6f

    const/16 v11, -0x65

    aput-byte v11, v1, v2

    const/16 v2, 0x70

    aput-byte v20, v1, v2

    const/16 v2, 0x71

    const/16 v11, 0x78

    aput-byte v11, v1, v2

    const/16 v2, 0x72

    const/16 v11, -0x80

    aput-byte v11, v1, v2

    const/16 v2, 0x73

    const/16 v11, -0x33

    aput-byte v11, v1, v2

    const/16 v2, 0x74

    const/16 v11, -0x28

    aput-byte v11, v1, v2

    const/16 v2, 0x75

    const/16 v11, -0x57

    aput-byte v11, v1, v2

    const/16 v2, 0x76

    const/16 v11, 0x31

    aput-byte v11, v1, v2

    const/16 v2, 0x77

    const/16 v11, -0x24

    aput-byte v11, v1, v2

    const/16 v2, 0x78

    const/16 v11, 0x3d

    aput-byte v11, v1, v2

    const/16 v2, 0x79

    aput-byte v21, v1, v2

    const/16 v2, 0x7a

    const/16 v11, -0x38

    aput-byte v11, v1, v2

    const/16 v2, 0x7b

    const/16 v11, -0x80

    aput-byte v11, v1, v2

    const/16 v2, 0x7c

    const/16 v11, -0x38

    aput-byte v11, v1, v2

    const/16 v2, 0x7d

    const/16 v11, -0x47

    aput-byte v11, v1, v2

    const/16 v2, 0x7e

    const/16 v11, 0x30

    aput-byte v11, v1, v2

    const/16 v2, 0x7f

    const/16 v11, -0x31

    aput-byte v11, v1, v2

    const/16 v2, 0x80

    const/16 v11, 0x2a

    aput-byte v11, v1, v2

    const/16 v2, 0x81

    const/16 v11, 0x79

    aput-byte v11, v1, v2

    const/16 v2, 0x82

    const/16 v11, -0x70

    aput-byte v11, v1, v2

    const/16 v2, 0x83

    const/16 v11, -0x35

    aput-byte v11, v1, v2

    const/16 v2, 0x84

    const/16 v11, -0x2a

    aput-byte v11, v1, v2

    const/16 v2, 0x85

    const/16 v11, -0x47

    aput-byte v11, v1, v2

    const/16 v2, 0x86

    const/16 v11, 0x60

    aput-byte v11, v1, v2

    const/16 v2, 0x87

    const/16 v11, -0x1c

    aput-byte v11, v1, v2

    new-array v2, v12, [B

    const/16 v11, 0x4f

    aput-byte v11, v2, v3

    const/16 v11, 0xb

    aput-byte v11, v2, v5

    const/16 v11, -0x1c

    aput-byte v11, v2, v6

    const/16 v11, -0x5e

    aput-byte v11, v2, v7

    const/16 v11, -0x45

    aput-byte v11, v2, v8

    const/16 v11, -0x24

    aput-byte v11, v2, v9

    const/16 v11, 0x42

    aput-byte v11, v2, v10

    const/16 v11, -0x47

    const/4 v15, 0x7

    aput-byte v11, v2, v15

    invoke-static {v1, v2}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-direct/range {p0 .. p0}, Lcom/github/catvod/spider/appysv2/b/A;->f()Ljava/util/Map;

    move-result-object v2

    invoke-static {v1, v2}, Lcom/github/catvod/spider/appysv2/n/c;->m(Ljava/lang/String;Ljava/util/Map;)Ljava/lang/String;

    move-result-object v1

    new-instance v2, Lorg/json/JSONObject;

    invoke-direct {v2, v1}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    new-array v1, v10, [B

    const/16 v11, -0x33

    aput-byte v11, v1, v3

    const/16 v11, 0x70

    aput-byte v11, v1, v5

    const/16 v11, -0x37

    aput-byte v11, v1, v6

    const/16 v11, -0xe

    aput-byte v11, v1, v7

    const/16 v11, -0x24

    aput-byte v11, v1, v8

    aput-byte v20, v1, v9

    new-array v11, v12, [B

    const/16 v15, -0x41

    aput-byte v15, v11, v3

    const/16 v15, 0x15

    aput-byte v15, v11, v5

    const/16 v15, -0x46

    aput-byte v15, v11, v6

    const/16 v15, -0x79

    aput-byte v15, v11, v7

    const/16 v15, -0x50

    aput-byte v15, v11, v8

    const/16 v15, 0x52

    aput-byte v15, v11, v9

    const/16 v15, 0x20

    aput-byte v15, v11, v10

    const/16 v15, -0x2c

    const/16 v18, 0x7

    aput-byte v15, v11, v18

    invoke-static {v1, v11}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v2, v1}, Lorg/json/JSONObject;->optJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v1

    new-array v2, v12, [B

    const/16 v11, -0x1a

    aput-byte v11, v2, v3

    const/16 v11, -0x2c

    aput-byte v11, v2, v5

    const/4 v11, -0x3

    aput-byte v11, v2, v6

    aput-byte v7, v2, v7

    const/16 v11, 0x5b

    aput-byte v11, v2, v8

    const/16 v11, -0x4c

    aput-byte v11, v2, v9

    const/16 v11, -0x72

    aput-byte v11, v2, v10

    const/16 v11, 0x36

    const/4 v15, 0x7

    aput-byte v11, v2, v15

    new-array v11, v12, [B

    const/16 v15, -0x7c

    aput-byte v15, v11, v3

    const/16 v15, -0x50

    aput-byte v15, v11, v5

    const/16 v15, -0x72

    aput-byte v15, v11, v6

    const/16 v15, 0x77

    aput-byte v15, v11, v7

    const/16 v15, 0x34

    aput-byte v15, v11, v8

    const/16 v15, -0x21

    aput-byte v15, v11, v9

    const/16 v15, -0x15

    aput-byte v15, v11, v10

    const/16 v15, 0x58

    const/16 v18, 0x7

    aput-byte v15, v11, v18

    invoke-static {v2, v11}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/16 v11, 0x33

    new-array v11, v11, [B

    const/16 v15, 0x7c

    aput-byte v15, v11, v3

    const/16 v15, 0x56

    aput-byte v15, v11, v5

    const/16 v15, -0x5b

    aput-byte v15, v11, v6

    const/16 v15, 0x9

    aput-byte v15, v11, v7

    aput-byte v23, v11, v8

    const/16 v15, 0x72

    aput-byte v15, v11, v9

    const/16 v15, -0x7b

    aput-byte v15, v11, v10

    const/16 v15, -0x79

    const/16 v18, 0x7

    aput-byte v15, v11, v18

    aput-byte v23, v11, v12

    const/16 v15, 0x9

    const/16 v27, 0x43

    aput-byte v27, v11, v15

    const/16 v15, 0xa

    const/16 v27, -0x41

    aput-byte v27, v11, v15

    const/16 v15, 0xb

    const/16 v27, 0x57

    aput-byte v27, v11, v15

    const/16 v15, 0x75

    aput-byte v15, v11, v13

    const/16 v15, 0xd

    aput-byte v21, v11, v15

    const/16 v15, 0xe

    const/16 v27, -0x3d

    aput-byte v27, v11, v15

    const/16 v15, 0xf

    const/16 v27, -0x34

    aput-byte v27, v11, v15

    const/16 v15, 0x10

    const/16 v27, 0x61

    aput-byte v27, v11, v15

    const/16 v15, 0x11

    aput-byte v13, v11, v15

    const/16 v15, 0x12

    const/16 v27, -0x4e

    aput-byte v27, v11, v15

    const/16 v15, 0x13

    const/16 v27, 0x16

    aput-byte v27, v11, v15

    const/16 v15, 0x14

    const/16 v27, 0x7a

    aput-byte v27, v11, v15

    const/16 v15, 0x15

    const/16 v27, 0x67

    aput-byte v27, v11, v15

    const/16 v15, 0x16

    const/16 v27, -0x35

    aput-byte v27, v11, v15

    const/16 v15, 0x17

    const/16 v27, -0x28

    aput-byte v27, v11, v15

    const/16 v15, 0x18

    const/16 v27, 0x7d

    aput-byte v27, v11, v15

    const/16 v15, 0x19

    const/16 v27, 0xd

    aput-byte v27, v11, v15

    const/16 v15, 0x1a

    const/16 v27, -0x4e

    aput-byte v27, v11, v15

    const/16 v15, 0x1b

    const/16 v27, 0xb

    aput-byte v27, v11, v15

    const/16 v15, 0x1c

    const/16 v27, 0x72

    aput-byte v27, v11, v15

    const/16 v15, 0x1d

    aput-byte v21, v11, v15

    const/16 v15, 0x1e

    const/16 v27, -0x22

    aput-byte v27, v11, v15

    const/16 v15, 0x1f

    const/16 v27, -0x33

    aput-byte v27, v11, v15

    const/16 v15, 0x20

    aput-byte v4, v11, v15

    const/16 v15, 0x21

    const/16 v27, 0x43

    aput-byte v27, v11, v15

    const/16 v15, 0x22

    const/16 v27, -0x14

    aput-byte v27, v11, v15

    const/16 v15, 0x1a

    const/16 v26, 0x23

    aput-byte v15, v11, v26

    const/16 v15, 0x78

    aput-byte v15, v11, v19

    const/16 v15, 0x25

    const/16 v27, 0x25

    aput-byte v27, v11, v15

    const/16 v15, -0x39

    aput-byte v15, v11, v20

    const/16 v15, -0x3f

    aput-byte v15, v11, v17

    const/16 v15, 0x28

    const/16 v27, 0x60

    aput-byte v27, v11, v15

    aput-byte v8, v11, v21

    const/16 v15, 0x2a

    const/16 v27, -0x4d

    aput-byte v27, v11, v15

    const/16 v15, 0x1d

    aput-byte v15, v11, v4

    const/16 v15, 0x2c

    aput-byte v23, v11, v15

    const/16 v15, 0x2d

    const/16 v27, 0x3c

    aput-byte v27, v11, v15

    const/16 v15, 0x2e

    const/16 v27, -0x3b

    aput-byte v27, v11, v15

    const/16 v15, 0x2f

    const/16 v27, -0x3d

    aput-byte v27, v11, v15

    const/16 v15, 0x30

    const/16 v27, 0x71

    aput-byte v27, v11, v15

    const/16 v15, 0x4c

    const/16 v25, 0x31

    aput-byte v15, v11, v25

    const/16 v15, 0x32

    const/16 v27, -0x14

    aput-byte v27, v11, v15

    new-array v15, v12, [B

    const/16 v27, 0x14

    aput-byte v27, v15, v3

    const/16 v27, 0x22

    aput-byte v27, v15, v5

    const/16 v27, -0x2f

    aput-byte v27, v15, v6

    const/16 v27, 0x79

    aput-byte v27, v15, v7

    const/16 v27, 0x17

    aput-byte v27, v15, v8

    const/16 v27, 0x48

    aput-byte v27, v15, v9

    const/16 v27, -0x56

    aput-byte v27, v15, v10

    const/16 v27, -0x58

    const/16 v18, 0x7

    aput-byte v27, v15, v18

    invoke-static {v11, v15}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v11

    invoke-virtual {v2, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    new-array v1, v4, [B

    const/16 v4, -0x62

    aput-byte v4, v1, v3

    const/16 v4, -0x3e

    aput-byte v4, v1, v5

    const/4 v4, -0x4

    aput-byte v4, v1, v6

    const/16 v4, 0x75

    aput-byte v4, v1, v7

    const/16 v4, 0x7c

    aput-byte v4, v1, v8

    const/16 v4, -0x62

    aput-byte v4, v1, v9

    const/16 v4, -0x77

    aput-byte v4, v1, v10

    const/16 v4, 0x49

    const/4 v11, 0x7

    aput-byte v4, v1, v11

    const/16 v4, -0x3f

    aput-byte v4, v1, v12

    const/16 v4, 0x9

    const/16 v11, -0x2f

    aput-byte v11, v1, v4

    const/16 v4, 0xa

    const/16 v11, -0xb

    aput-byte v11, v1, v4

    const/16 v4, 0xb

    const/16 v11, 0x21

    aput-byte v11, v1, v4

    aput-byte v21, v1, v13

    const/16 v4, 0xd

    const/16 v11, -0x2a

    aput-byte v11, v1, v4

    const/16 v4, 0xe

    const/16 v11, -0x64

    aput-byte v11, v1, v4

    const/16 v4, 0xf

    const/16 v11, 0x4d

    aput-byte v11, v1, v4

    const/16 v4, 0x10

    const/16 v11, -0x38

    aput-byte v11, v1, v4

    const/16 v4, 0x11

    const/4 v11, -0x2

    aput-byte v11, v1, v4

    const/16 v4, 0x12

    const/4 v11, -0x7

    aput-byte v11, v1, v4

    const/16 v4, 0x13

    const/16 v11, 0x78

    aput-byte v11, v1, v4

    const/16 v4, 0x14

    aput-byte v19, v1, v4

    const/16 v4, 0x15

    const/16 v11, -0x3e

    aput-byte v11, v1, v4

    const/16 v4, 0x16

    const/16 v11, -0x38

    aput-byte v11, v1, v4

    const/16 v4, 0x17

    const/16 v11, 0xd

    aput-byte v11, v1, v4

    const/16 v4, 0x18

    const/16 v11, -0x73

    aput-byte v11, v1, v4

    const/16 v4, 0x19

    const/16 v11, -0x6d

    aput-byte v11, v1, v4

    const/16 v4, 0x1a

    const/16 v11, -0x58

    aput-byte v11, v1, v4

    const/16 v4, 0x1b

    const/16 v11, 0x3a

    aput-byte v11, v1, v4

    const/16 v4, 0x1c

    aput-byte v24, v1, v4

    const/16 v4, 0x1d

    const/16 v11, -0x6b

    aput-byte v11, v1, v4

    const/16 v4, 0x1e

    const/16 v11, -0x61

    aput-byte v11, v1, v4

    const/16 v4, 0x1f

    aput-byte v3, v1, v4

    const/16 v4, 0x20

    const/16 v11, -0x77

    aput-byte v11, v1, v4

    const/16 v4, 0x21

    const/16 v11, -0x79

    aput-byte v11, v1, v4

    const/16 v4, 0x22

    const/16 v11, -0xc

    aput-byte v11, v1, v4

    const/16 v4, 0x6c

    const/16 v11, 0x23

    aput-byte v4, v1, v11

    const/16 v4, 0x34

    aput-byte v4, v1, v19

    const/16 v4, 0x25

    const/16 v11, -0x64

    aput-byte v11, v1, v4

    const/16 v4, -0x6e

    aput-byte v4, v1, v20

    const/16 v4, 0x5a

    aput-byte v4, v1, v17

    const/16 v4, 0x28

    const/16 v11, -0x2f

    aput-byte v11, v1, v4

    const/16 v4, -0x3b

    aput-byte v4, v1, v21

    const/16 v4, 0x2a

    const/16 v11, -0x53

    aput-byte v11, v1, v4

    new-array v4, v12, [B

    const/16 v11, -0x48

    aput-byte v11, v4, v3

    const/16 v11, -0x5f

    aput-byte v11, v4, v5

    const/16 v11, -0x70

    aput-byte v11, v4, v6

    const/16 v11, 0x1c

    aput-byte v11, v4, v7

    const/16 v11, 0x19

    aput-byte v11, v4, v8

    const/16 v11, -0x10

    aput-byte v11, v4, v9

    const/4 v11, -0x3

    aput-byte v11, v4, v10

    const/16 v11, 0x3d

    const/4 v15, 0x7

    aput-byte v11, v4, v15

    invoke-static {v1, v4}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    new-instance v2, Ljava/util/HashMap;

    invoke-direct {v2}, Ljava/util/HashMap;-><init>()V

    new-array v4, v8, [B

    const/16 v11, 0x1e

    aput-byte v11, v4, v3

    const/16 v11, -0x1d

    aput-byte v11, v4, v5

    const/16 v11, -0x25

    aput-byte v11, v4, v6

    const/16 v11, -0x50

    aput-byte v11, v4, v7

    new-array v11, v12, [B

    aput-byte v24, v11, v3

    const/16 v15, -0x7e

    aput-byte v15, v11, v5

    const/16 v15, -0x51

    aput-byte v15, v11, v6

    const/16 v15, -0x28

    aput-byte v15, v11, v7

    const/16 v15, 0x1e

    aput-byte v15, v11, v8

    const/16 v15, 0x11

    aput-byte v15, v11, v9

    const/16 v15, -0x62

    aput-byte v15, v11, v10

    const/4 v15, 0x7

    aput-byte v9, v11, v15

    invoke-static {v4, v11}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v4

    sget-object v11, Lcom/github/catvod/spider/appysv2/b/A;->e:Ljava/lang/String;

    invoke-virtual {v2, v4, v11}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    new-array v4, v9, [B

    const/16 v15, -0x7f

    aput-byte v15, v4, v3

    const/16 v15, -0x1f

    aput-byte v15, v4, v5

    const/16 v15, -0x4d

    aput-byte v15, v4, v6

    aput-byte v12, v4, v7

    const/16 v15, -0x72

    aput-byte v15, v4, v8

    new-array v15, v12, [B

    const/16 v17, -0x18

    aput-byte v17, v15, v3

    const/16 v17, -0x6e

    aput-byte v17, v15, v5

    const/16 v17, -0x29

    aput-byte v17, v15, v6

    const/16 v17, 0x61

    aput-byte v17, v15, v7

    const/16 v17, -0x4

    aput-byte v17, v15, v8

    const/16 v17, 0x70

    aput-byte v17, v15, v9

    const/16 v17, -0x63

    aput-byte v17, v15, v10

    const/16 v17, 0xe

    const/16 v18, 0x7

    aput-byte v17, v15, v18

    invoke-static {v4, v15}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v4

    new-array v15, v5, [B

    const/16 v17, -0x2f

    aput-byte v17, v15, v3

    new-array v14, v12, [B

    const/16 v19, -0x20

    aput-byte v19, v14, v3

    const/16 v19, -0x2d

    aput-byte v19, v14, v5

    const/16 v19, -0x27

    aput-byte v19, v14, v6

    const/16 v19, -0x18

    aput-byte v19, v14, v7

    aput-byte v3, v14, v8

    const/16 v19, 0x35

    aput-byte v19, v14, v9

    const/16 v19, 0x3e

    aput-byte v19, v14, v10

    const/16 v19, 0x7b

    const/16 v18, 0x7

    aput-byte v19, v14, v18

    invoke-static {v15, v14}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v14

    invoke-virtual {v2, v4, v14}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/16 v4, 0xa

    new-array v4, v4, [B

    const/16 v14, 0x7c

    aput-byte v14, v4, v3

    const/16 v14, 0x30

    aput-byte v14, v4, v5

    const/16 v14, 0x32

    aput-byte v14, v4, v6

    aput-byte v13, v4, v7

    const/16 v14, -0x48

    aput-byte v14, v4, v8

    aput-byte v9, v4, v9

    aput-byte v5, v4, v10

    const/16 v14, 0x65

    const/4 v15, 0x7

    aput-byte v14, v4, v15

    aput-byte v16, v4, v12

    const/16 v14, 0x9

    const/16 v15, 0x28

    aput-byte v15, v4, v14

    new-array v14, v12, [B

    const/16 v15, 0x1e

    aput-byte v15, v14, v3

    const/16 v15, 0x5c

    aput-byte v15, v14, v5

    const/16 v15, 0x5d

    aput-byte v15, v14, v6

    const/16 v15, 0x6f

    aput-byte v15, v14, v7

    const/16 v15, -0x2d

    aput-byte v15, v14, v8

    const/16 v15, 0x5a

    aput-byte v15, v14, v9

    aput-byte v16, v14, v10

    const/4 v15, 0x7

    aput-byte v13, v14, v15

    invoke-static {v4, v14}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v4

    new-array v14, v6, [B

    const/16 v15, -0x20

    aput-byte v15, v14, v3

    const/16 v15, 0x17

    aput-byte v15, v14, v5

    new-array v15, v12, [B

    const/16 v16, -0x45

    aput-byte v16, v15, v3

    const/16 v16, 0x4a

    aput-byte v16, v15, v5

    const/16 v16, 0x31

    aput-byte v16, v15, v6

    const/16 v16, 0x5d

    aput-byte v16, v15, v7

    const/16 v16, 0x23

    aput-byte v16, v15, v8

    const/16 v16, -0x39

    aput-byte v16, v15, v9

    const/16 v16, 0x5d

    aput-byte v16, v15, v10

    const/16 v16, -0x1c

    const/16 v18, 0x7

    aput-byte v16, v15, v18

    invoke-static {v14, v15}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v14

    invoke-virtual {v2, v4, v14}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    invoke-direct/range {p0 .. p0}, Lcom/github/catvod/spider/appysv2/b/A;->f()Ljava/util/Map;

    move-result-object v4

    invoke-static {v1, v2, v4}, Lcom/github/catvod/spider/appysv2/n/c;->h(Ljava/lang/String;Ljava/util/Map;Ljava/util/Map;)Lcom/github/catvod/spider/appysv2/n/e;

    move-result-object v1

    new-instance v2, Lorg/json/JSONObject;

    invoke-virtual {v1}, Lcom/github/catvod/spider/appysv2/n/e;->a()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v2, v1}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    new-instance v1, Lcom/github/catvod/spider/appysv2/f/a;

    invoke-direct {v1}, Lcom/github/catvod/spider/appysv2/f/a;-><init>()V

    new-array v4, v9, [B

    const/16 v14, 0x3f

    aput-byte v14, v4, v3

    const/16 v14, 0x49

    aput-byte v14, v4, v5

    aput-byte v13, v4, v6

    const/16 v13, -0x34

    aput-byte v13, v4, v7

    const/16 v13, -0x16

    aput-byte v13, v4, v8

    new-array v12, v12, [B

    const/16 v13, 0x59

    aput-byte v13, v12, v3

    const/16 v3, 0x3a

    aput-byte v3, v12, v5

    const/16 v3, 0x53

    aput-byte v3, v12, v6

    const/16 v3, -0x5b

    aput-byte v3, v12, v7

    const/16 v3, -0x72

    aput-byte v3, v12, v8

    aput-byte v23, v12, v9

    const/16 v3, -0x2d

    aput-byte v3, v12, v10

    const/16 v3, 0x7b

    const/4 v5, 0x7

    aput-byte v3, v12, v5

    invoke-static {v4, v12}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Lorg/json/JSONObject;->optLong(Ljava/lang/String;)J

    move-result-wide v2

    invoke-virtual {v1, v2, v3}, Lcom/github/catvod/spider/appysv2/f/a;->h(J)V

    invoke-virtual {v1, v11}, Lcom/github/catvod/spider/appysv2/f/a;->i(Ljava/lang/String;)V
    :try_end_a3a
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_a3a} :catch_a3b

    return-object v1

    :catch_a3b
    move-exception v0

    move-object v1, v0

    invoke-static {v1}, Lcom/github/catvod/crawler/SpiderDebug;->log(Ljava/lang/Throwable;)V

    const/4 v1, 0x0

    return-object v1
.end method

.method private r(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    .registers 5

    :try_start_0
    iget-object v0, p0, Lcom/github/catvod/spider/appysv2/b/A;->b:Ljava/util/HashMap;

    invoke-virtual {v0, p1}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/util/Map;

    if-nez v0, :cond_f

    new-instance v0, Ljava/util/HashMap;

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    :cond_f
    invoke-interface {v0, p2, p3}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    iget-object p2, p0, Lcom/github/catvod/spider/appysv2/b/A;->b:Ljava/util/HashMap;

    invoke-virtual {p2, p1, v0}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_17
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_17} :catch_18

    goto :goto_1c

    :catch_18
    move-exception p1

    invoke-virtual {p1}, Ljava/lang/Throwable;->printStackTrace()V

    :goto_1c
    return-void
.end method

.method public static s()Z
    .registers 47

    const/4 v1, 0x0

    :try_start_1
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/16 v3, 0x36

    new-array v3, v3, [B

    const/16 v4, 0x29

    aput-byte v4, v3, v1

    const/16 v5, 0x7a

    const/4 v6, 0x1

    aput-byte v5, v3, v6

    const/4 v5, 0x2

    const/16 v7, 0x35

    aput-byte v7, v3, v5

    const/16 v8, -0x24

    const/4 v9, 0x3

    aput-byte v8, v3, v9

    const/16 v8, 0x7c

    const/4 v10, 0x4

    aput-byte v8, v3, v10

    const/4 v8, 0x5

    const/16 v11, 0x17

    aput-byte v11, v3, v8

    const/16 v12, 0x9

    const/4 v13, 0x6

    aput-byte v12, v3, v13

    const/16 v14, -0x48

    const/4 v15, 0x7

    aput-byte v14, v3, v15

    const/16 v14, 0x31

    const/16 v15, 0x8

    aput-byte v14, v3, v15

    const/16 v14, 0x6f

    aput-byte v14, v3, v12

    const/16 v14, 0xa

    const/16 v17, 0x32

    aput-byte v17, v3, v14

    const/16 v18, -0x21

    const/16 v19, 0xb

    aput-byte v18, v3, v19

    const/16 v18, 0x7f

    const/16 v20, 0xc

    aput-byte v18, v3, v20

    const/16 v18, 0x42

    const/16 v12, 0xd

    aput-byte v18, v3, v12

    const/16 v18, 0x54

    const/16 v22, 0xe

    aput-byte v18, v3, v22

    const/16 v18, -0x1d

    const/16 v23, 0xf

    aput-byte v18, v3, v23

    const/16 v18, 0x6f

    const/16 v24, 0x10

    aput-byte v18, v3, v24

    const/16 v18, 0x6c

    const/16 v25, 0x11

    aput-byte v18, v3, v25

    const/16 v18, 0x12

    const/16 v26, 0x20

    aput-byte v26, v3, v18

    const/16 v27, -0x3b

    const/16 v28, 0x13

    aput-byte v27, v3, v28

    const/16 v27, 0x6b

    const/16 v29, 0x14

    aput-byte v27, v3, v29

    const/16 v27, 0x15

    const/16 v30, 0x58

    aput-byte v30, v3, v27

    const/16 v31, 0x16

    aput-byte v15, v3, v31

    const/16 v31, -0xc

    aput-byte v31, v3, v11

    const/16 v31, 0x18

    const/16 v32, 0x2e

    aput-byte v32, v3, v31

    const/16 v31, 0x63

    const/16 v32, 0x19

    aput-byte v31, v3, v32

    const/16 v31, 0x6e

    const/16 v33, 0x1a

    aput-byte v31, v3, v33

    const/16 v34, -0x31

    const/16 v35, 0x1b

    aput-byte v34, v3, v35

    const/16 v36, 0x1c

    const/16 v37, 0x67

    aput-byte v37, v3, v36

    const/16 v36, 0x1d

    const/16 v37, 0x4c

    aput-byte v37, v3, v36

    const/16 v36, 0x48

    const/16 v37, 0x1e

    aput-byte v36, v3, v37

    const/16 v36, 0x1f

    const/16 v38, -0x7

    aput-byte v38, v3, v36

    const/16 v36, 0x24

    aput-byte v36, v3, v26

    const/16 v38, 0x21

    const/16 v39, 0x62

    aput-byte v39, v3, v38

    const/16 v38, 0x22

    aput-byte v31, v3, v38

    const/16 v39, -0x27

    const/16 v40, 0x23

    aput-byte v39, v3, v40

    const/16 v39, 0x61

    aput-byte v39, v3, v36

    const/16 v39, 0x25

    const/16 v41, 0x44

    aput-byte v41, v3, v39

    const/16 v39, 0x26

    const/16 v41, 0x45

    aput-byte v41, v3, v39

    const/16 v39, 0x27

    const/16 v41, -0xa

    aput-byte v41, v3, v39

    const/16 v39, 0x28

    aput-byte v17, v3, v39

    const/16 v39, 0x7a

    aput-byte v39, v3, v4

    const/16 v39, 0x7e

    const/16 v41, 0x2a

    aput-byte v39, v3, v41

    const/16 v39, 0x2b

    aput-byte v34, v3, v39

    const/16 v39, 0x2c

    const/16 v42, 0x67

    aput-byte v42, v3, v39

    const/16 v39, 0x2d

    const/16 v42, 0x4c

    aput-byte v42, v3, v39

    const/16 v39, 0x2e

    const/16 v42, 0x48

    aput-byte v42, v3, v39

    const/16 v39, 0x2f

    const/16 v42, -0x7

    aput-byte v42, v3, v39

    const/16 v39, 0x30

    aput-byte v36, v3, v39

    const/16 v39, 0x31

    const/16 v42, 0x62

    aput-byte v42, v3, v39

    aput-byte v37, v3, v17

    const/16 v39, 0x33

    const/16 v42, -0x3b

    aput-byte v42, v3, v39

    const/16 v39, 0x34

    const/16 v42, 0x6b

    aput-byte v42, v3, v39

    aput-byte v24, v3, v7

    new-array v7, v15, [B

    const/16 v42, 0x41

    aput-byte v42, v7, v1

    aput-byte v22, v7, v6

    aput-byte v42, v7, v5

    const/16 v43, -0x54

    aput-byte v43, v7, v9

    aput-byte v23, v7, v10

    const/16 v43, 0x2d

    aput-byte v43, v7, v8

    const/16 v43, 0x26

    aput-byte v43, v7, v13

    const/16 v43, -0x69

    const/16 v16, 0x7

    aput-byte v43, v7, v16

    invoke-static {v3, v7}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    sget-object v3, Lcom/github/catvod/spider/appysv2/b/A;->d:Ljava/lang/String;

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    new-instance v3, Ljava/util/HashMap;

    invoke-direct {v3}, Ljava/util/HashMap;-><init>()V

    new-array v7, v14, [B

    const/16 v43, -0x4f

    aput-byte v43, v7, v1

    const/16 v43, -0x42

    aput-byte v43, v7, v6

    const/16 v43, -0x55

    aput-byte v43, v7, v5

    const/16 v43, -0x43

    aput-byte v43, v7, v9

    const/16 v43, -0x66

    aput-byte v43, v7, v10

    aput-byte v6, v7, v8

    const/16 v43, 0x74

    aput-byte v43, v7, v13

    const/16 v43, -0x4d

    const/16 v16, 0x7

    aput-byte v43, v7, v16

    const/16 v43, -0x76

    aput-byte v43, v7, v15

    const/16 v43, -0x47

    const/16 v21, 0x9

    aput-byte v43, v7, v21

    new-array v11, v15, [B

    const/16 v44, -0x1c

    aput-byte v44, v11, v1

    const/16 v44, -0x33

    aput-byte v44, v11, v6

    const/16 v44, -0x32

    aput-byte v44, v11, v5

    aput-byte v34, v11, v9

    const/16 v44, -0x49

    aput-byte v44, v11, v10

    const/16 v45, 0x40

    aput-byte v45, v11, v8

    aput-byte v28, v11, v13

    const/16 v45, -0x2a

    const/16 v16, 0x7

    aput-byte v45, v11, v16

    invoke-static {v7, v11}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v7

    const/16 v11, 0x6f

    new-array v11, v11, [B

    const/16 v45, -0x6c

    aput-byte v45, v11, v1

    const/16 v45, -0x27

    aput-byte v45, v11, v6

    const/16 v45, 0x63

    aput-byte v45, v11, v5

    const/16 v45, -0x2

    aput-byte v45, v11, v9

    const/16 v45, 0x1d

    aput-byte v45, v11, v10

    aput-byte v14, v11, v8

    const/16 v45, -0x69

    aput-byte v45, v11, v13

    const/16 v45, -0x61

    const/16 v16, 0x7

    aput-byte v45, v11, v16

    const/16 v45, -0x14

    aput-byte v45, v11, v15

    const/16 v45, -0x68

    const/16 v21, 0x9

    aput-byte v45, v11, v21

    aput-byte v4, v11, v14

    aput-byte v44, v11, v19

    const/16 v45, 0x59

    aput-byte v45, v11, v20

    const/16 v45, 0x31

    aput-byte v45, v11, v12

    const/16 v45, -0x61

    aput-byte v45, v11, v22

    const/16 v45, -0x22

    aput-byte v45, v11, v23

    const/16 v45, -0x43

    aput-byte v45, v11, v24

    const/16 v45, -0x27

    aput-byte v45, v11, v25

    aput-byte v31, v11, v18

    const/16 v45, -0x1c

    aput-byte v45, v11, v28

    const/16 v45, 0x51

    aput-byte v45, v11, v29

    const/16 v45, 0x28

    aput-byte v45, v11, v27

    const/16 v45, 0x16

    const/16 v46, -0x5e

    aput-byte v46, v11, v45

    const/16 v45, -0x70

    const/16 v43, 0x17

    aput-byte v45, v11, v43

    const/16 v45, 0x18

    const/16 v46, -0x18

    aput-byte v46, v11, v45

    const/16 v45, -0x7a

    aput-byte v45, v11, v32

    const/16 v45, 0x37

    aput-byte v45, v11, v33

    const/16 v45, -0x59

    aput-byte v45, v11, v35

    const/16 v45, 0x1c

    const/16 v46, 0x4a

    aput-byte v46, v11, v45

    const/16 v45, 0x1d

    const/16 v46, 0x46

    aput-byte v46, v11, v45

    const/16 v45, -0x5f

    aput-byte v45, v11, v37

    const/16 v45, 0x1f

    const/16 v46, -0x27

    aput-byte v46, v11, v45

    aput-byte v44, v11, v26

    const/16 v45, 0x21

    const/16 v46, -0x80

    aput-byte v46, v11, v45

    const/16 v45, 0x2d

    aput-byte v45, v11, v38

    const/16 v45, -0x54

    aput-byte v45, v11, v40

    const/16 v45, 0x51

    aput-byte v45, v11, v36

    const/16 v45, 0x25

    aput-byte v37, v11, v45

    const/16 v45, 0x26

    const/16 v46, -0x40

    aput-byte v46, v11, v45

    const/16 v45, 0x27

    const/16 v46, -0x7c

    aput-byte v46, v11, v45

    const/16 v45, 0x28

    const/16 v46, -0x10

    aput-byte v46, v11, v45

    const/16 v45, -0x6a

    aput-byte v45, v11, v4

    aput-byte v30, v11, v41

    const/16 v45, 0x2b

    const/16 v46, -0x19

    aput-byte v46, v11, v45

    const/16 v45, 0x2c

    aput-byte v6, v11, v45

    const/16 v45, 0x2d

    aput-byte v14, v11, v45

    const/16 v45, 0x2e

    const/16 v46, -0x6d

    aput-byte v46, v11, v45

    const/16 v45, 0x2f

    const/16 v46, -0x19

    aput-byte v46, v11, v45

    const/16 v45, 0x30

    const/16 v46, -0x44

    aput-byte v46, v11, v45

    const/16 v45, 0x31

    const/16 v46, -0x2c

    aput-byte v46, v11, v45

    const/16 v45, 0x52

    aput-byte v45, v11, v17

    const/16 v45, 0x33

    const/16 v46, -0x2

    aput-byte v46, v11, v45

    const/16 v45, 0x34

    aput-byte v8, v11, v45

    const/16 v45, 0x49

    const/16 v39, 0x35

    aput-byte v45, v11, v39

    const/16 v45, 0x36

    const/16 v46, -0x3d

    aput-byte v46, v11, v45

    const/16 v45, 0x37

    const/16 v46, -0x7d

    aput-byte v46, v11, v45

    const/16 v45, 0x38

    const/16 v46, -0x12

    aput-byte v46, v11, v45

    const/16 v45, 0x39

    const/16 v46, -0x68

    aput-byte v46, v11, v45

    const/16 v45, 0x3a

    aput-byte v41, v11, v45

    const/16 v45, 0x3b

    const/16 v46, -0x5f

    aput-byte v46, v11, v45

    const/16 v45, 0x3c

    const/16 v46, 0x51

    aput-byte v46, v11, v45

    const/16 v45, 0x3d

    const/16 v46, 0x4e

    aput-byte v46, v11, v45

    const/16 v45, 0x3e

    const/16 v46, -0x43

    aput-byte v46, v11, v45

    const/16 v45, 0x3f

    const/16 v46, -0x8

    aput-byte v46, v11, v45

    const/16 v45, 0x40

    const/16 v46, -0x73

    aput-byte v46, v11, v45

    const/16 v45, -0x5

    aput-byte v45, v11, v42

    const/16 v45, 0x42

    const/16 v46, 0x55

    aput-byte v46, v11, v45

    const/16 v45, 0x43

    const/16 v46, -0x45

    aput-byte v46, v11, v45

    const/16 v45, 0x44

    const/16 v46, 0x51

    aput-byte v46, v11, v45

    const/16 v45, 0x45

    aput-byte v14, v11, v45

    const/16 v45, 0x46

    const/16 v46, -0x61

    aput-byte v46, v11, v45

    const/16 v45, 0x47

    const/16 v46, -0x25

    aput-byte v46, v11, v45

    const/16 v45, 0x48

    const/16 v46, -0x44

    aput-byte v46, v11, v45

    const/16 v45, 0x49

    const/16 v46, -0x6a

    aput-byte v46, v11, v45

    const/16 v45, 0x4a

    const/16 v46, 0x5e

    aput-byte v46, v11, v45

    const/16 v45, 0x4b

    const/16 v46, -0xe

    aput-byte v46, v11, v45

    const/16 v45, 0x4c

    aput-byte v18, v11, v45

    const/16 v45, 0x4d

    aput-byte v12, v11, v45

    const/16 v45, 0x4e

    const/16 v46, -0x67

    aput-byte v46, v11, v45

    const/16 v45, 0x4f

    const/16 v46, -0x67

    aput-byte v46, v11, v45

    const/16 v45, 0x50

    const/16 v46, -0x7

    aput-byte v46, v11, v45

    const/16 v45, 0x51

    const/16 v46, -0xb

    aput-byte v46, v11, v45

    const/16 v45, 0x52

    const/16 v46, 0x71

    aput-byte v46, v11, v45

    const/16 v45, 0x53

    const/16 v46, -0x1b

    aput-byte v46, v11, v45

    const/16 v45, 0x54

    aput-byte v37, v11, v45

    const/16 v45, 0x55

    aput-byte v19, v11, v45

    const/16 v45, 0x56

    const/16 v46, -0x6d

    aput-byte v46, v11, v45

    const/16 v45, 0x57

    const/16 v46, -0x61

    aput-byte v46, v11, v45

    const/16 v45, -0x18

    aput-byte v45, v11, v30

    const/16 v45, 0x59

    const/16 v46, -0x79

    aput-byte v46, v11, v45

    const/16 v45, 0x5a

    const/16 v46, 0x2e

    aput-byte v46, v11, v45

    const/16 v45, 0x5b

    const/16 v46, -0x47

    aput-byte v46, v11, v45

    const/16 v45, 0x5c

    aput-byte v42, v11, v45

    const/16 v45, 0x5d

    const/16 v46, 0x48

    aput-byte v46, v11, v45

    const/16 v45, 0x5e

    const/16 v46, -0x3a

    aput-byte v46, v11, v45

    const/16 v45, 0x5f

    const/16 v46, -0x62

    aput-byte v46, v11, v45

    const/16 v45, 0x60

    const/16 v46, -0x17

    aput-byte v46, v11, v45

    const/16 v45, 0x61

    const/16 v46, -0x6a

    aput-byte v46, v11, v45

    const/16 v45, 0x62

    const/16 v46, 0x4a

    aput-byte v46, v11, v45

    const/16 v45, 0x63

    const/16 v46, -0xa

    aput-byte v46, v11, v45

    const/16 v45, 0x64

    const/16 v43, 0x17

    aput-byte v43, v11, v45

    const/16 v45, 0x65

    const/16 v16, 0x7

    aput-byte v16, v11, v45

    const/16 v45, 0x66

    const/16 v46, -0x7c

    aput-byte v46, v11, v45

    const/16 v45, 0x67

    const/16 v46, -0x27

    aput-byte v46, v11, v45

    const/16 v45, 0x68

    const/16 v46, -0xa

    aput-byte v46, v11, v45

    const/16 v45, 0x69

    const/16 v46, -0x7d

    aput-byte v46, v11, v45

    const/16 v45, 0x6a

    aput-byte v41, v11, v45

    const/16 v45, 0x6b

    const/16 v46, -0x60

    aput-byte v46, v11, v45

    const/16 v45, 0x6c

    const/16 v46, 0x5f

    aput-byte v46, v11, v45

    const/16 v45, 0x6d

    const/16 v46, 0x55

    aput-byte v46, v11, v45

    const/16 v45, -0x40

    aput-byte v45, v11, v31

    new-array v4, v15, [B

    const/16 v46, -0x27

    aput-byte v46, v4, v1

    const/16 v46, -0x4a

    aput-byte v46, v4, v6

    aput-byte v32, v4, v5

    const/16 v46, -0x69

    aput-byte v46, v4, v9

    const/16 v46, 0x71

    aput-byte v46, v4, v10

    const/16 v46, 0x66

    aput-byte v46, v4, v8

    const/16 v46, -0xa

    aput-byte v46, v4, v13

    const/16 v46, -0x50

    const/4 v12, 0x7

    aput-byte v46, v4, v12

    invoke-static {v11, v4}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v7, v4}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    new-array v4, v12, [B

    aput-byte v28, v4, v1

    const/16 v7, -0x62

    aput-byte v7, v4, v6

    const/16 v7, 0x35

    aput-byte v7, v4, v5

    const/16 v7, 0x2b

    aput-byte v7, v4, v9

    const/16 v7, 0x69

    aput-byte v7, v4, v10

    const/4 v7, -0x2

    aput-byte v7, v4, v8

    const/4 v7, -0x6

    aput-byte v7, v4, v13

    new-array v7, v15, [B

    aput-byte v42, v7, v1

    const/4 v11, -0x5

    aput-byte v11, v7, v6

    const/16 v11, 0x53

    aput-byte v11, v7, v5

    const/16 v11, 0x4e

    aput-byte v11, v7, v9

    aput-byte v35, v7, v10

    const/16 v11, -0x65

    aput-byte v11, v7, v8

    const/16 v11, -0x78

    aput-byte v11, v7, v13

    const/16 v11, -0x16

    const/4 v12, 0x7

    aput-byte v11, v7, v12

    invoke-static {v4, v7}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v4

    const/16 v7, 0x16

    new-array v7, v7, [B

    const/16 v11, 0x76

    aput-byte v11, v7, v1

    aput-byte v17, v7, v6

    const/4 v11, -0x4

    aput-byte v11, v7, v5

    const/16 v11, 0x65

    aput-byte v11, v7, v9

    const/16 v11, 0x7e

    aput-byte v11, v7, v10

    aput-byte v30, v7, v8

    const/16 v11, -0xf

    aput-byte v11, v7, v13

    const/4 v11, -0x6

    const/4 v12, 0x7

    aput-byte v11, v7, v12

    aput-byte v31, v7, v15

    const/16 v11, 0x27

    const/16 v12, 0x9

    aput-byte v11, v7, v12

    const/16 v11, -0x1a

    aput-byte v11, v7, v14

    const/16 v11, 0x3b

    aput-byte v11, v7, v19

    const/16 v11, 0x6f

    aput-byte v11, v7, v20

    const/16 v11, 0xd

    aput-byte v9, v7, v11

    aput-byte v44, v7, v22

    const/16 v11, -0x4f

    aput-byte v11, v7, v23

    const/16 v11, 0x6b

    aput-byte v11, v7, v24

    const/16 v11, 0x68

    aput-byte v11, v7, v25

    const/16 v11, -0x15

    aput-byte v11, v7, v18

    const/16 v11, 0x7a

    aput-byte v11, v7, v28

    const/16 v11, 0x60

    aput-byte v11, v7, v29

    const/16 v11, 0x4d

    aput-byte v11, v7, v27

    new-array v11, v15, [B

    aput-byte v37, v11, v1

    const/16 v12, 0x46

    aput-byte v12, v11, v6

    const/16 v12, -0x78

    aput-byte v12, v11, v5

    aput-byte v27, v11, v9

    const/16 v12, 0xd

    aput-byte v12, v11, v10

    const/16 v12, 0x62

    aput-byte v12, v11, v8

    const/16 v12, -0x22

    aput-byte v12, v11, v13

    const/16 v12, -0x2b

    const/16 v16, 0x7

    aput-byte v12, v11, v16

    invoke-static {v7, v11}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v3, v4, v7}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    new-instance v4, Lorg/json/JSONObject;

    invoke-static {v2, v3}, Lcom/github/catvod/spider/appysv2/n/c;->m(Ljava/lang/String;Ljava/util/Map;)Ljava/lang/String;

    move-result-object v2

    invoke-direct {v4, v2}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    invoke-virtual {v4}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Lcom/github/catvod/crawler/SpiderDebug;->log(Ljava/lang/String;)V

    new-array v2, v8, [B

    const/16 v7, 0x46

    aput-byte v7, v2, v1

    aput-byte v38, v2, v6

    aput-byte v28, v2, v5

    const/16 v7, -0x6f

    aput-byte v7, v2, v9

    const/16 v7, 0x7d

    aput-byte v7, v2, v10

    new-array v7, v15, [B

    aput-byte v40, v7, v1

    const/16 v11, 0x50

    aput-byte v11, v7, v6

    const/16 v11, 0x61

    aput-byte v11, v7, v5

    const/4 v11, -0x1

    aput-byte v11, v7, v9

    aput-byte v18, v7, v10

    const/16 v11, -0x78

    aput-byte v11, v7, v8

    aput-byte v38, v7, v13

    const/16 v11, 0x30

    const/4 v12, 0x7

    aput-byte v11, v7, v12

    invoke-static {v2, v7}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v4, v2}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;)I

    move-result v2

    if-nez v2, :cond_bf2

    new-instance v2, Lorg/json/JSONObject;

    const/16 v7, 0x9

    new-array v11, v7, [B

    const/4 v7, -0x3

    aput-byte v7, v11, v1

    const/16 v7, -0x7d

    aput-byte v7, v11, v6

    aput-byte v1, v11, v5

    const/16 v7, -0x52

    aput-byte v7, v11, v9

    const/16 v7, -0x7d

    aput-byte v7, v11, v10

    const/16 v7, -0x15

    aput-byte v7, v11, v8

    const/16 v7, -0x46

    aput-byte v7, v11, v13

    const/4 v7, 0x7

    aput-byte v9, v11, v7

    const/16 v7, -0x18

    aput-byte v7, v11, v15

    new-array v7, v15, [B

    const/16 v12, -0x62

    aput-byte v12, v7, v1

    const/16 v12, -0x15

    aput-byte v12, v7, v6

    const/16 v12, 0x61

    aput-byte v12, v7, v5

    const/16 v12, -0x40

    aput-byte v12, v7, v9

    const/16 v12, -0x13

    aput-byte v12, v7, v10

    const/16 v12, -0x72

    aput-byte v12, v7, v8

    const/16 v12, -0x2a

    aput-byte v12, v7, v13

    const/16 v12, 0x5c

    const/16 v16, 0x7

    aput-byte v12, v7, v16

    invoke-static {v11, v7}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v4, v7}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-direct {v2, v4}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    invoke-virtual {v2}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-static {v4}, Lcom/github/catvod/crawler/SpiderDebug;->log(Ljava/lang/String;)V

    new-array v4, v13, [B

    const/16 v7, 0x63

    aput-byte v7, v4, v1

    const/16 v7, 0x5d

    aput-byte v7, v4, v6

    const/4 v7, -0x1

    aput-byte v7, v4, v5

    const/16 v7, -0x4f

    aput-byte v7, v4, v9

    const/16 v7, 0x21

    aput-byte v7, v4, v10

    aput-byte v29, v4, v8

    new-array v7, v15, [B

    aput-byte v24, v7, v1

    const/16 v11, 0x29

    aput-byte v11, v7, v6

    const/16 v11, -0x62

    aput-byte v11, v7, v5

    const/16 v11, -0x3b

    aput-byte v11, v7, v9

    const/16 v11, 0x54

    aput-byte v11, v7, v10

    const/16 v11, 0x67

    aput-byte v11, v7, v8

    const/16 v11, 0x78

    aput-byte v11, v7, v13

    const/16 v11, -0x7b

    const/4 v12, 0x7

    aput-byte v11, v7, v12

    invoke-static {v4, v7}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v2, v4}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;)I

    move-result v4

    if-nez v4, :cond_bf2

    new-array v4, v6, [B

    const/16 v7, -0x3c

    aput-byte v7, v4, v1

    new-array v7, v15, [B

    const/16 v11, -0x4e

    aput-byte v11, v7, v1

    const/16 v11, 0x72

    aput-byte v11, v7, v6

    const/16 v11, 0x3e

    aput-byte v11, v7, v5

    const/16 v11, 0x4e

    aput-byte v11, v7, v9

    const/16 v11, -0x38

    aput-byte v11, v7, v10

    const/16 v11, 0x5a

    aput-byte v11, v7, v8

    const/16 v11, -0x5b

    aput-byte v11, v7, v13

    const/16 v11, 0x3f

    const/4 v12, 0x7

    aput-byte v11, v7, v12

    invoke-static {v4, v7}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v2, v4}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const/16 v7, 0x38

    new-array v7, v7, [B

    const/16 v11, -0x5c

    aput-byte v11, v7, v1

    const/4 v11, 0x7

    aput-byte v11, v7, v6

    const/16 v11, -0x5a

    aput-byte v11, v7, v5

    aput-byte v30, v7, v9

    const/16 v11, -0x4b

    aput-byte v11, v7, v10

    const/16 v11, -0x14

    aput-byte v11, v7, v8

    const/16 v11, -0x4b

    aput-byte v11, v7, v13

    const/16 v11, -0x34

    const/4 v12, 0x7

    aput-byte v11, v7, v12

    const/16 v11, -0x44

    aput-byte v11, v7, v15

    const/16 v11, 0x9

    aput-byte v18, v7, v11

    const/16 v11, -0x5f

    aput-byte v11, v7, v14

    const/16 v11, 0x5b

    aput-byte v11, v7, v19

    const/16 v11, -0x4a

    aput-byte v11, v7, v20

    const/16 v11, -0x47

    const/16 v12, 0xd

    aput-byte v11, v7, v12

    const/16 v11, -0x18

    aput-byte v11, v7, v22

    const/16 v11, -0x69

    aput-byte v11, v7, v23

    const/16 v11, -0x1e

    aput-byte v11, v7, v24

    aput-byte v25, v7, v25

    const/16 v11, -0x4d

    aput-byte v11, v7, v18

    aput-byte v42, v7, v28

    const/16 v11, -0x5e

    aput-byte v11, v7, v29

    const/16 v11, -0x5d

    aput-byte v11, v7, v27

    const/16 v11, 0x16

    const/16 v12, -0x4c

    aput-byte v12, v7, v11

    const/16 v11, -0x80

    const/16 v12, 0x17

    aput-byte v11, v7, v12

    const/16 v11, 0x18

    const/16 v12, -0x5d

    aput-byte v12, v7, v11

    aput-byte v37, v7, v32

    const/4 v11, -0x3

    aput-byte v11, v7, v33

    const/16 v11, 0x5e

    aput-byte v11, v7, v35

    const/16 v11, 0x1c

    const/16 v12, -0xb

    aput-byte v12, v7, v11

    const/16 v11, 0x1d

    const/4 v12, -0x7

    aput-byte v12, v7, v11

    const/16 v11, -0xa

    aput-byte v11, v7, v37

    const/16 v11, 0x1f

    const/16 v12, -0x74

    aput-byte v12, v7, v11

    const/16 v11, -0x55

    aput-byte v11, v7, v26

    const/16 v11, 0x21

    aput-byte v33, v7, v11

    const/16 v11, -0x44

    aput-byte v11, v7, v38

    const/4 v11, 0x7

    aput-byte v11, v7, v40

    const/16 v11, -0x55

    aput-byte v11, v7, v36

    const/16 v11, 0x25

    aput-byte v44, v7, v11

    const/16 v11, 0x26

    const/16 v12, -0xd

    aput-byte v12, v7, v11

    const/16 v11, 0x27

    const/16 v12, -0x73

    aput-byte v12, v7, v11

    const/16 v11, 0x28

    const/16 v12, -0x1d

    aput-byte v12, v7, v11

    const/16 v11, 0x29

    aput-byte v5, v7, v11

    const/16 v11, -0x60

    aput-byte v11, v7, v41

    const/16 v11, 0x2b

    const/16 v12, 0x4a

    aput-byte v12, v7, v11

    const/16 v11, 0x2c

    const/16 v12, -0x5e

    aput-byte v12, v7, v11

    const/16 v11, 0x2d

    const/16 v12, -0x5d

    aput-byte v12, v7, v11

    const/16 v11, 0x2e

    const/16 v12, -0x17

    aput-byte v12, v7, v11

    const/16 v11, 0x2f

    const/16 v12, -0x70

    aput-byte v12, v7, v11

    const/16 v11, 0x30

    const/16 v12, -0x60

    aput-byte v12, v7, v11

    const/16 v11, 0x31

    const/16 v12, 0x1c

    aput-byte v12, v7, v11

    const/16 v11, -0x4b

    aput-byte v11, v7, v17

    const/16 v11, 0x33

    aput-byte v42, v7, v11

    const/16 v11, 0x34

    const/16 v12, -0x58

    aput-byte v12, v7, v11

    const/16 v11, -0x17

    const/16 v12, 0x35

    aput-byte v11, v7, v12

    const/16 v11, 0x36

    const/16 v12, -0x14

    aput-byte v12, v7, v11

    const/16 v11, 0x37

    const/16 v12, -0x22

    aput-byte v12, v7, v11

    new-array v11, v15, [B

    const/16 v12, -0x34

    aput-byte v12, v11, v1

    const/16 v12, 0x73

    aput-byte v12, v11, v6

    const/16 v12, -0x2e

    aput-byte v12, v11, v5

    const/16 v12, 0x28

    aput-byte v12, v11, v9

    const/16 v12, -0x3a

    aput-byte v12, v11, v10

    const/16 v12, -0x2a

    aput-byte v12, v11, v8

    const/16 v12, -0x66

    aput-byte v12, v11, v13

    const/16 v12, -0x1d

    const/4 v14, 0x7

    aput-byte v12, v11, v14

    invoke-static {v7, v11}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v4, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v11

    invoke-virtual {v4, v11, v12}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    new-array v7, v14, [B

    const/16 v11, -0x14

    aput-byte v11, v7, v1

    const/16 v11, -0x47

    aput-byte v11, v7, v6

    const/16 v11, -0x55

    aput-byte v11, v7, v5

    const/16 v11, 0x3d

    aput-byte v11, v7, v9

    const/16 v11, 0x49

    aput-byte v11, v7, v10

    const/16 v11, 0x69

    aput-byte v11, v7, v8

    const/16 v11, -0x33

    aput-byte v11, v7, v13

    new-array v11, v15, [B

    const/16 v12, -0x36

    aput-byte v12, v11, v1

    const/16 v12, -0x25

    aput-byte v12, v11, v6

    aput-byte v34, v11, v5

    const/16 v12, 0x48

    aput-byte v12, v11, v9

    const/16 v12, 0x3a

    aput-byte v12, v11, v10

    aput-byte v33, v11, v8

    const/16 v12, -0x10

    aput-byte v12, v11, v13

    const/16 v12, -0x1d

    const/4 v14, 0x7

    aput-byte v12, v11, v14

    invoke-static {v7, v11}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v4, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    new-instance v4, Ljava/util/HashMap;

    invoke-direct {v4}, Ljava/util/HashMap;-><init>()V

    invoke-static {v2, v3}, Lcom/github/catvod/spider/appysv2/n/c;->b(Ljava/lang/String;Ljava/util/Map;)Lcom/github/catvod/spider/appysv2/n/e;

    move-result-object v2

    invoke-virtual {v2}, Lcom/github/catvod/spider/appysv2/n/e;->c()Ljava/util/Map;

    move-result-object v2

    const/16 v4, 0xa

    new-array v7, v4, [B

    const/16 v4, 0x45

    aput-byte v4, v7, v1

    const/16 v4, -0x19

    aput-byte v4, v7, v6

    const/16 v4, -0x4b

    aput-byte v4, v7, v5

    aput-byte v30, v7, v9

    const/16 v4, 0x6f

    aput-byte v4, v7, v10

    const/16 v4, 0x2c

    aput-byte v4, v7, v8

    const/16 v4, -0x35

    aput-byte v4, v7, v13

    const/4 v4, 0x7

    aput-byte v41, v7, v4

    const/16 v4, 0x5f

    aput-byte v4, v7, v15

    const/16 v4, -0x19

    const/16 v11, 0x9

    aput-byte v4, v7, v11

    new-array v4, v15, [B

    const/16 v11, 0x36

    aput-byte v11, v4, v1

    const/16 v11, -0x7e

    aput-byte v11, v4, v6

    const/16 v11, -0x3f

    aput-byte v11, v4, v5

    const/16 v11, 0x75

    aput-byte v11, v4, v9

    aput-byte v20, v4, v10

    const/16 v11, 0x43

    aput-byte v11, v4, v8

    const/16 v11, -0x5c

    aput-byte v11, v4, v13

    const/4 v11, 0x7

    aput-byte v42, v4, v11

    invoke-static {v7, v4}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-interface {v2, v4}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/util/List;

    const-string v4, ""

    const-string v7, ""

    invoke-interface {v2}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :cond_7c6
    :goto_7c6
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v11

    if-eqz v11, :cond_8e7

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v11

    check-cast v11, Ljava/lang/String;

    invoke-static {v7}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v12

    if-eqz v12, :cond_805

    new-array v7, v6, [B

    const/16 v12, -0x3e

    aput-byte v12, v7, v1

    new-array v12, v15, [B

    const/4 v14, -0x7

    aput-byte v14, v12, v1

    const/16 v14, -0x52

    aput-byte v14, v12, v6

    const/16 v14, 0x4e

    aput-byte v14, v12, v5

    aput-byte v20, v12, v9

    const/16 v14, 0x65

    aput-byte v14, v12, v10

    const/16 v14, 0x48

    aput-byte v14, v12, v8

    aput-byte v18, v12, v13

    const/4 v14, 0x7

    aput-byte v41, v12, v14

    invoke-static {v7, v12}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v11, v7}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v7

    aget-object v7, v7, v1

    goto :goto_873

    :cond_805
    new-instance v12, Ljava/lang/StringBuilder;

    invoke-direct {v12}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v12, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    new-array v7, v6, [B

    const/16 v14, -0x17

    aput-byte v14, v7, v1

    new-array v14, v15, [B

    const/16 v21, -0x2e

    aput-byte v21, v14, v1

    const/16 v21, -0x79

    aput-byte v21, v14, v6

    const/16 v21, 0x39

    aput-byte v21, v14, v5

    aput-byte v34, v14, v9

    aput-byte v25, v14, v10

    const/16 v21, -0x7b

    aput-byte v21, v14, v8

    aput-byte v44, v14, v13

    const/16 v21, 0x39

    const/16 v16, 0x7

    aput-byte v21, v14, v16

    invoke-static {v7, v14}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v12, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    new-array v7, v6, [B

    const/16 v14, -0x7b

    aput-byte v14, v7, v1

    new-array v14, v15, [B

    const/16 v21, -0x42

    aput-byte v21, v14, v1

    const/16 v21, -0x43

    aput-byte v21, v14, v6

    const/16 v21, -0x54

    aput-byte v21, v14, v5

    const/16 v21, -0x3c

    aput-byte v21, v14, v9

    const/16 v21, -0x3

    aput-byte v21, v14, v10

    const/16 v21, 0x7a

    aput-byte v21, v14, v8

    const/16 v21, -0x57

    aput-byte v21, v14, v13

    const/16 v21, 0x39

    const/16 v16, 0x7

    aput-byte v21, v14, v16

    invoke-static {v7, v14}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v11, v7}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v7

    aget-object v7, v7, v1

    invoke-virtual {v12, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v12}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v7

    :goto_873
    new-array v12, v13, [B

    const/16 v14, -0x58

    aput-byte v14, v12, v1

    const/16 v14, -0x33

    aput-byte v14, v12, v6

    const/16 v14, -0x4e

    aput-byte v14, v12, v5

    const/16 v14, -0x5b

    aput-byte v14, v12, v9

    const/16 v14, -0x1c

    aput-byte v14, v12, v10

    const/16 v14, -0x15

    aput-byte v14, v12, v8

    new-array v14, v15, [B

    const/16 v21, -0x16

    aput-byte v21, v14, v1

    const/16 v21, -0x77

    aput-byte v21, v14, v6

    const/16 v21, -0x19

    aput-byte v21, v14, v5

    const/16 v21, -0xa

    aput-byte v21, v14, v9

    aput-byte v44, v14, v10

    const/16 v21, -0x2a

    aput-byte v21, v14, v8

    const/16 v21, 0x6a

    aput-byte v21, v14, v13

    const/16 v21, -0x50

    const/16 v16, 0x7

    aput-byte v21, v14, v16

    invoke-static {v12, v14}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v12

    invoke-virtual {v11, v12}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v12

    if-eqz v12, :cond_7c6

    new-array v4, v6, [B

    aput-byte v44, v4, v1

    new-array v12, v15, [B

    const/16 v14, -0x74

    aput-byte v14, v12, v1

    const/16 v14, 0x4c

    aput-byte v14, v12, v6

    const/16 v14, 0x60

    aput-byte v14, v12, v5

    const/16 v14, -0x60

    aput-byte v14, v12, v9

    const/16 v14, -0x72

    aput-byte v14, v12, v10

    aput-byte v40, v12, v8

    const/4 v14, -0x3

    aput-byte v14, v12, v13

    const/4 v14, 0x7

    aput-byte v20, v12, v14

    invoke-static {v4, v12}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v11, v4}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v4

    aget-object v4, v4, v1

    goto/16 :goto_7c6

    :cond_8e7
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/16 v11, 0xd

    new-array v12, v11, [B

    const/16 v11, -0x63

    aput-byte v11, v12, v1

    const/16 v11, -0x6c

    aput-byte v11, v12, v6

    aput-byte v42, v12, v5

    const/16 v11, -0x3d

    aput-byte v11, v12, v9

    aput-byte v27, v12, v10

    const/16 v11, 0x51

    aput-byte v11, v12, v8

    const/16 v11, 0x57

    aput-byte v11, v12, v13

    const/16 v11, -0x4a

    const/4 v14, 0x7

    aput-byte v11, v12, v14

    const/16 v11, -0x80

    aput-byte v11, v12, v15

    const/16 v11, -0x6c

    const/16 v14, 0x9

    aput-byte v11, v12, v14

    const/16 v11, 0x5f

    const/16 v14, 0xa

    aput-byte v11, v12, v14

    const/16 v11, -0x77

    aput-byte v11, v12, v19

    const/16 v11, 0x76

    aput-byte v11, v12, v20

    new-array v11, v15, [B

    const/16 v14, -0x17

    aput-byte v14, v11, v1

    const/16 v14, -0xf

    aput-byte v14, v11, v6

    const/16 v14, 0x2c

    aput-byte v14, v11, v5

    const/16 v14, -0x4d

    aput-byte v14, v11, v9

    const/16 v14, 0x56

    aput-byte v14, v11, v10

    const/16 v14, 0x3e

    aput-byte v14, v11, v8

    const/16 v14, 0x38

    aput-byte v14, v11, v13

    const/16 v14, -0x23

    const/16 v16, 0x7

    aput-byte v14, v11, v16

    invoke-static {v12, v11}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v11

    invoke-virtual {v2, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Lcom/github/catvod/crawler/SpiderDebug;->log(Ljava/lang/String;)V

    new-array v2, v13, [B

    const/16 v11, -0xc

    aput-byte v11, v2, v1

    const/16 v11, -0x63

    aput-byte v11, v2, v6

    const/16 v11, -0x4b

    aput-byte v11, v2, v5

    aput-byte v34, v2, v9

    const/16 v11, 0x59

    aput-byte v11, v2, v10

    const/16 v11, -0x40

    aput-byte v11, v2, v8

    new-array v11, v15, [B

    aput-byte v44, v11, v1

    const/16 v12, -0xe

    aput-byte v12, v11, v6

    const/16 v12, -0x26

    aput-byte v12, v11, v5

    const/16 v12, -0x5c

    aput-byte v12, v11, v9

    const/16 v12, 0x30

    aput-byte v12, v11, v10

    const/16 v12, -0x5b

    aput-byte v12, v11, v8

    const/16 v12, -0x4a

    aput-byte v12, v11, v13

    const/16 v12, -0x18

    const/4 v14, 0x7

    aput-byte v12, v11, v14

    invoke-static {v2, v11}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v3, v2, v7}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/16 v2, 0x2d

    new-array v2, v2, [B

    const/16 v7, 0x2f

    aput-byte v7, v2, v1

    const/16 v7, 0x6d

    aput-byte v7, v2, v6

    const/16 v7, -0x2a

    aput-byte v7, v2, v5

    const/16 v7, -0x2a

    aput-byte v7, v2, v9

    const/16 v7, 0x50

    aput-byte v7, v2, v10

    const/16 v7, -0x55

    aput-byte v7, v2, v8

    const/16 v7, 0x75

    aput-byte v7, v2, v13

    const/16 v7, -0x75

    const/4 v11, 0x7

    aput-byte v7, v2, v11

    const/16 v7, 0x37

    aput-byte v7, v2, v15

    const/16 v7, 0x78

    const/16 v11, 0x9

    aput-byte v7, v2, v11

    const/16 v7, -0x34

    const/16 v11, 0xa

    aput-byte v7, v2, v11

    const/16 v7, -0x78

    aput-byte v7, v2, v19

    aput-byte v42, v2, v20

    const/16 v7, -0x10

    const/16 v11, 0xd

    aput-byte v7, v2, v11

    const/16 v7, 0x33

    aput-byte v7, v2, v22

    const/16 v7, -0x40

    aput-byte v7, v2, v23

    aput-byte v17, v2, v24

    const/16 v7, 0x37

    aput-byte v7, v2, v25

    const/16 v7, -0x3f

    aput-byte v7, v2, v18

    const/16 v7, -0x37

    aput-byte v7, v2, v28

    const/16 v7, 0x4e

    aput-byte v7, v2, v29

    const/16 v7, -0x42

    aput-byte v7, v2, v27

    const/16 v7, 0x16

    const/16 v11, 0x3e

    aput-byte v11, v2, v7

    const/16 v7, -0x33

    const/16 v11, 0x17

    aput-byte v7, v2, v11

    const/16 v7, 0x18

    const/16 v11, 0x34

    aput-byte v11, v2, v7

    const/16 v7, 0x72

    aput-byte v7, v2, v32

    const/16 v7, -0x73

    aput-byte v7, v2, v33

    const/16 v7, -0x35

    aput-byte v7, v2, v35

    const/16 v7, 0x1c

    const/16 v11, 0x42

    aput-byte v11, v2, v7

    const/16 v7, 0x1d

    const/4 v11, -0x8

    aput-byte v11, v2, v7

    const/16 v7, 0x34

    aput-byte v7, v2, v37

    const/16 v7, 0x1f

    const/16 v11, -0x65

    aput-byte v11, v2, v7

    const/16 v7, 0x21

    aput-byte v7, v2, v26

    const/16 v7, 0x21

    const/16 v11, 0x6b

    aput-byte v11, v2, v7

    const/16 v7, -0x33

    aput-byte v7, v2, v38

    const/16 v7, -0x35

    aput-byte v7, v2, v40

    aput-byte v37, v2, v36

    const/16 v7, 0x25

    const/4 v11, -0x7

    aput-byte v11, v2, v7

    const/16 v7, 0x26

    const/16 v11, 0x35

    aput-byte v11, v2, v7

    const/16 v7, 0x27

    const/16 v11, -0x37

    aput-byte v11, v2, v7

    const/16 v7, 0x28

    aput-byte v38, v2, v7

    const/16 v7, 0x5f

    const/16 v11, 0x29

    aput-byte v7, v2, v11

    const/16 v7, -0x32

    aput-byte v7, v2, v41

    const/16 v7, 0x2b

    const/16 v11, -0x37

    aput-byte v11, v2, v7

    const/16 v7, 0x2c

    const/16 v11, 0x54

    aput-byte v11, v2, v7

    new-array v7, v15, [B

    const/16 v11, 0x47

    aput-byte v11, v7, v1

    aput-byte v32, v7, v6

    const/16 v11, -0x5e

    aput-byte v11, v7, v5

    const/16 v11, -0x5a

    aput-byte v11, v7, v9

    aput-byte v40, v7, v10

    const/16 v11, -0x6f

    aput-byte v11, v7, v8

    const/16 v11, 0x5a

    aput-byte v11, v7, v13

    const/16 v11, -0x5c

    const/4 v12, 0x7

    aput-byte v11, v7, v12

    invoke-static {v2, v7}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-static {v2, v3}, Lcom/github/catvod/spider/appysv2/n/c;->c(Ljava/lang/String;Ljava/util/Map;)Ljava/lang/String;

    move-result-object v2

    invoke-static {v2, v3}, Lcom/github/catvod/spider/appysv2/n/c;->c(Ljava/lang/String;Ljava/util/Map;)Ljava/lang/String;

    move-result-object v2

    invoke-static {}, Lcom/github/catvod/spider/appysv2/n/c;->f()Lokhttp3/OkHttpClient;

    move-result-object v7

    new-instance v11, Ljava/util/HashMap;

    invoke-direct {v11}, Ljava/util/HashMap;-><init>()V

    invoke-static {v7, v2, v11, v3}, Lcom/github/catvod/spider/appysv2/n/c;->k(Lokhttp3/OkHttpClient;Ljava/lang/String;Ljava/util/Map;Ljava/util/Map;)Lcom/github/catvod/spider/appysv2/n/e;

    move-result-object v2

    invoke-virtual {v2}, Lcom/github/catvod/spider/appysv2/n/e;->c()Ljava/util/Map;

    move-result-object v2

    const/16 v3, 0xa

    new-array v3, v3, [B

    aput-byte v41, v3, v1

    aput-byte v27, v3, v6

    const/16 v7, 0x64

    aput-byte v7, v3, v5

    const/16 v7, 0x3e

    aput-byte v7, v3, v9

    const/16 v7, -0x2f

    aput-byte v7, v3, v10

    aput-byte v36, v3, v8

    const/16 v7, 0x7c

    aput-byte v7, v3, v13

    const/16 v7, -0x7d

    const/4 v11, 0x7

    aput-byte v7, v3, v11

    const/16 v7, 0x30

    aput-byte v7, v3, v15

    const/16 v7, 0x9

    aput-byte v27, v3, v7

    new-array v7, v15, [B

    const/16 v11, 0x59

    aput-byte v11, v7, v1

    const/16 v11, 0x70

    aput-byte v11, v7, v6

    aput-byte v24, v7, v5

    aput-byte v28, v7, v9

    const/16 v11, -0x4e

    aput-byte v11, v7, v10

    const/16 v11, 0x4b

    aput-byte v11, v7, v8

    aput-byte v28, v7, v13

    const/16 v11, -0x18

    const/4 v12, 0x7

    aput-byte v11, v7, v12

    invoke-static {v3, v7}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v3

    invoke-interface {v2, v3}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/util/List;

    invoke-interface {v2}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :cond_af9
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_bae

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/lang/String;

    const/4 v7, 0x7

    new-array v11, v7, [B

    aput-byte v38, v11, v1

    aput-byte v31, v11, v6

    const/16 v7, 0x69

    aput-byte v7, v11, v5

    aput-byte v38, v11, v9

    const/16 v7, -0x69

    aput-byte v7, v11, v10

    const/16 v7, 0x72

    aput-byte v7, v11, v8

    const/16 v7, 0x74

    aput-byte v7, v11, v13

    new-array v7, v15, [B

    const/16 v12, 0x71

    aput-byte v12, v7, v1

    const/16 v12, 0x3a

    aput-byte v12, v7, v6

    const/16 v12, 0x26

    aput-byte v12, v7, v5

    const/16 v12, 0x69

    aput-byte v12, v7, v9

    const/16 v12, -0x2e

    aput-byte v12, v7, v10

    const/16 v12, 0x3c

    aput-byte v12, v7, v8

    const/16 v12, 0x49

    aput-byte v12, v7, v13

    const/16 v12, -0x71

    const/4 v14, 0x7

    aput-byte v12, v7, v14

    invoke-static {v11, v7}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v3, v7}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v7

    if-eqz v7, :cond_af9

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    new-array v4, v6, [B

    aput-byte v26, v4, v1

    new-array v7, v15, [B

    aput-byte v35, v7, v1

    aput-byte v8, v7, v6

    const/16 v11, -0x14

    aput-byte v11, v7, v5

    aput-byte v25, v7, v9

    const/16 v11, 0x54

    aput-byte v11, v7, v10

    aput-byte v13, v7, v8

    const/16 v11, -0x78

    aput-byte v11, v7, v13

    const/16 v11, -0x5a

    const/4 v12, 0x7

    aput-byte v11, v7, v12

    invoke-static {v4, v7}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    new-array v4, v6, [B

    const/16 v7, 0x53

    aput-byte v7, v4, v1

    new-array v7, v15, [B

    const/16 v11, 0x68

    aput-byte v11, v7, v1

    aput-byte v36, v7, v6

    const/4 v11, -0x6

    aput-byte v11, v7, v5

    aput-byte v5, v7, v9

    const/16 v11, 0x6d

    aput-byte v11, v7, v10

    const/16 v11, -0x4a

    aput-byte v11, v7, v8

    const/16 v11, -0x7b

    aput-byte v11, v7, v13

    const/16 v11, -0x3b

    const/4 v12, 0x7

    aput-byte v11, v7, v12

    invoke-static {v4, v7}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v3

    aget-object v3, v3, v1

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    :cond_bae
    new-array v2, v13, [B

    const/16 v3, 0x6d

    aput-byte v3, v2, v1

    const/16 v3, -0x74

    aput-byte v3, v2, v6

    const/4 v3, -0x1

    aput-byte v3, v2, v5

    const/16 v3, 0x1c

    aput-byte v3, v2, v9

    const/16 v3, -0x37

    aput-byte v3, v2, v10

    const/16 v3, -0x17

    aput-byte v3, v2, v8

    new-array v3, v15, [B

    const/16 v7, 0x43

    aput-byte v7, v3, v1

    const/16 v7, -0x12

    aput-byte v7, v3, v6

    const/16 v7, -0x62

    aput-byte v7, v3, v5

    const/16 v5, 0x75

    aput-byte v5, v3, v9

    const/16 v5, -0x53

    aput-byte v5, v3, v10

    const/16 v5, -0x64

    aput-byte v5, v3, v8

    const/16 v5, -0x4a

    aput-byte v5, v3, v13

    const/16 v5, 0x52

    const/4 v7, 0x7

    aput-byte v5, v3, v7

    invoke-static {v2, v3}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-static {v2, v4}, Lcom/github/catvod/spider/appysv2/p/C;->u(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_bf1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_bf1} :catch_bf3

    return v6

    :cond_bf2
    return v1

    :catch_bf3
    move-exception v0

    move-object v2, v0

    invoke-virtual {v2}, Ljava/lang/Throwable;->printStackTrace()V

    return v1
.end method


# virtual methods
.method public final d(Ljava/lang/String;Ljava/lang/String;Ljava/util/List;)V
    .registers 44
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/util/List<",
            "Lcom/github/catvod/spider/appysv2/f/a;",
            ">;)V"
        }
    .end annotation

    move-object/from16 v8, p0

    move-object/from16 v0, p1

    :try_start_4
    invoke-virtual/range {p0 .. p2}, Lcom/github/catvod/spider/appysv2/b/A;->l(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    invoke-static {v9}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    if-eqz v1, :cond_f

    return-void

    :cond_f
    const/4 v10, 0x5

    new-array v1, v10, [B

    const/4 v11, 0x0

    const/4 v12, 0x1

    aput-byte v12, v1, v11

    const/16 v2, 0x5c

    aput-byte v2, v1, v12

    const/16 v3, 0x77

    const/4 v13, 0x2

    aput-byte v3, v1, v13

    const/16 v3, 0x1c

    const/4 v14, 0x3

    aput-byte v3, v1, v14

    const/16 v4, 0x3a

    const/4 v15, 0x4

    aput-byte v4, v1, v15

    const/16 v7, 0x8

    new-array v5, v7, [B

    const/16 v6, 0x72

    aput-byte v6, v5, v11

    const/16 v6, 0x39

    aput-byte v6, v5, v12

    aput-byte v3, v5, v13

    const/16 v16, 0x79

    aput-byte v16, v5, v14

    const/16 v16, 0x43

    aput-byte v16, v5, v15

    const/16 v16, -0x4d

    aput-byte v16, v5, v10

    const/16 v16, -0x18

    const/4 v6, 0x6

    aput-byte v16, v5, v6

    const/16 v16, -0xb

    const/4 v2, 0x7

    aput-byte v16, v5, v2

    invoke-static {v1, v5}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-direct {v8, v0, v1, v9}, Lcom/github/catvod/spider/appysv2/b/A;->r(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/16 v5, 0x6a

    new-array v5, v5, [B

    const/16 v18, -0x29

    aput-byte v18, v5, v11

    const/16 v19, -0x77

    aput-byte v19, v5, v12

    const/16 v19, -0x6e

    aput-byte v19, v5, v13

    const/16 v19, -0x7c

    aput-byte v19, v5, v14

    aput-byte v4, v5, v15

    const/16 v19, 0x3e

    aput-byte v19, v5, v10

    const/16 v20, 0x55

    aput-byte v20, v5, v6

    const/16 v21, -0x7

    aput-byte v21, v5, v2

    const/16 v21, -0x31

    aput-byte v21, v5, v7

    const/16 v22, -0x64

    const/16 v23, 0x9

    aput-byte v22, v5, v23

    const/16 v22, 0xa

    const/16 v24, -0x78

    aput-byte v24, v5, v22

    const/16 v22, -0x26

    const/16 v24, 0xb

    aput-byte v22, v5, v24

    const/16 v22, 0xc

    const/16 v25, 0x2b

    aput-byte v25, v5, v22

    const/16 v26, 0xd

    const/16 v27, 0x65

    aput-byte v27, v5, v26

    const/16 v26, 0xe

    const/16 v27, 0x13

    aput-byte v27, v5, v26

    const/16 v26, 0xf

    const/16 v27, -0x4e

    aput-byte v27, v5, v26

    const/16 v26, 0x10

    const/16 v27, -0x36

    aput-byte v27, v5, v26

    const/16 v26, 0x11

    const/16 v27, -0x2d

    aput-byte v27, v5, v26

    const/16 v26, 0x12

    const/16 v27, -0x7b

    aput-byte v27, v5, v26

    const/16 v26, 0x13

    const/16 v27, -0x65

    aput-byte v27, v5, v26

    const/16 v26, 0x14

    const/16 v27, 0x24

    aput-byte v27, v5, v26

    const/16 v26, 0x15

    aput-byte v25, v5, v26

    const/16 v28, 0x16

    aput-byte v23, v5, v28

    const/16 v28, -0x42

    const/16 v29, 0x17

    aput-byte v28, v5, v29

    const/16 v28, 0x18

    const/16 v30, -0x22

    aput-byte v30, v5, v28

    const/16 v28, 0x19

    const/16 v30, -0x71

    aput-byte v30, v5, v28

    const/16 v28, 0x1a

    const/16 v30, -0x7d

    aput-byte v30, v5, v28

    const/16 v28, 0x1b

    const/16 v30, -0x25

    aput-byte v30, v5, v28

    const/16 v28, 0x25

    aput-byte v28, v5, v3

    const/16 v30, 0x1d

    const/16 v31, 0x6d

    aput-byte v31, v5, v30

    const/16 v30, 0x1e

    aput-byte v23, v5, v30

    const/16 v30, 0x1f

    const/16 v31, -0x5e

    aput-byte v31, v5, v30

    const/16 v30, 0x20

    const/16 v31, -0x80

    aput-byte v31, v5, v30

    const/16 v30, 0x21

    const/16 v31, -0x76

    aput-byte v31, v5, v30

    const/16 v30, 0x22

    const/16 v31, -0x7d

    aput-byte v31, v5, v30

    const/16 v30, 0x23

    const/16 v31, -0x6a

    aput-byte v31, v5, v30

    const/16 v30, 0x74

    aput-byte v30, v5, v27

    const/16 v30, 0x31

    aput-byte v30, v5, v28

    const/16 v31, 0x26

    const/16 v17, 0x5c

    aput-byte v17, v5, v31

    const/16 v31, 0x27

    const/16 v32, -0x49

    aput-byte v32, v5, v31

    const/16 v31, 0x28

    aput-byte v21, v5, v31

    const/16 v31, 0x29

    const/16 v32, -0x73

    aput-byte v32, v5, v31

    const/16 v31, 0x2a

    const/16 v32, -0x47

    aput-byte v32, v5, v31

    const/16 v31, -0x63

    aput-byte v31, v5, v25

    const/16 v31, 0x2c

    const/16 v32, 0x2d

    aput-byte v32, v5, v31

    const/16 v31, 0x39

    aput-byte v31, v5, v32

    const/16 v31, 0x2e

    const/16 v33, 0x48

    aput-byte v33, v5, v31

    const/16 v31, 0x2f

    const/16 v33, -0x1d

    aput-byte v33, v5, v31

    const/16 v31, -0x71

    const/16 v33, 0x30

    aput-byte v31, v5, v33

    const/16 v31, -0x38

    aput-byte v31, v5, v30

    const/16 v31, 0x32

    const/16 v34, -0x2c

    aput-byte v34, v5, v31

    const/16 v31, 0x33

    const/16 v34, -0x34

    aput-byte v34, v5, v31

    const/16 v31, 0x34

    const/16 v34, 0x6f

    aput-byte v34, v5, v31

    const/16 v31, 0x60

    const/16 v35, 0x35

    aput-byte v31, v5, v35

    const/16 v31, 0x36

    const/16 v36, 0x1f

    aput-byte v36, v5, v31

    const/16 v31, 0x37

    const/16 v36, -0x5b

    aput-byte v36, v5, v31

    const/16 v31, -0x24

    const/16 v36, 0x38

    aput-byte v31, v5, v36

    const/16 v31, -0x40

    const/16 v37, 0x39

    aput-byte v31, v5, v37

    aput-byte v18, v5, v4

    const/16 v31, 0x3b

    const/16 v37, -0x2e

    aput-byte v37, v5, v31

    const/16 v31, 0x3c

    aput-byte v4, v5, v31

    const/16 v4, 0x3d

    const/16 v31, 0x6c

    aput-byte v31, v5, v4

    aput-byte v26, v5, v19

    const/16 v4, 0x3f

    const/16 v31, -0x5f

    aput-byte v31, v5, v4

    const/16 v4, 0x40

    const/16 v31, -0x26

    aput-byte v31, v5, v4

    const/16 v4, 0x41

    const/16 v31, -0x70

    aput-byte v31, v5, v4

    const/16 v4, 0x42

    const/16 v37, -0x6a

    aput-byte v37, v5, v4

    const/16 v4, 0x43

    const/16 v37, -0x80

    aput-byte v37, v5, v4

    const/16 v4, 0x44

    aput-byte v33, v5, v4

    const/16 v4, 0x45

    const/16 v37, 0x39

    aput-byte v37, v5, v4

    const/16 v4, 0x46

    const/16 v37, 0x4a

    aput-byte v37, v5, v4

    const/16 v4, 0x47

    const/16 v37, -0x10

    aput-byte v37, v5, v4

    const/16 v4, 0x48

    aput-byte v21, v5, v4

    const/16 v4, 0x49

    const/16 v21, -0x64

    aput-byte v21, v5, v4

    const/16 v4, 0x4a

    const/16 v21, -0x7f

    aput-byte v21, v5, v4

    const/16 v4, 0x4b

    const/16 v21, -0x6f

    aput-byte v21, v5, v4

    const/16 v4, 0x4c

    const/16 v21, 0x74

    aput-byte v21, v5, v4

    const/16 v4, 0x4d

    aput-byte v35, v5, v4

    const/16 v4, 0x4e

    const/16 v17, 0x5c

    aput-byte v17, v5, v4

    const/16 v4, 0x4f

    const/16 v21, -0x48

    aput-byte v21, v5, v4

    const/16 v4, -0x36

    const/16 v21, 0x50

    aput-byte v4, v5, v21

    const/16 v4, 0x51

    aput-byte v31, v5, v4

    const/16 v4, 0x52

    const/16 v37, -0x25

    aput-byte v37, v5, v4

    const/16 v4, 0x53

    const/16 v37, -0x3a

    aput-byte v37, v5, v4

    const/16 v4, 0x54

    const/16 v37, 0x79

    aput-byte v37, v5, v4

    const/16 v4, 0x22

    aput-byte v4, v5, v20

    const/16 v4, 0x56

    aput-byte v26, v5, v4

    const/16 v4, 0x57

    const/16 v37, -0x5c

    aput-byte v37, v5, v4

    const/16 v4, 0x58

    const/16 v37, -0x25

    aput-byte v37, v5, v4

    const/16 v4, 0x59

    const/16 v37, -0x68

    aput-byte v37, v5, v4

    const/16 v4, 0x5a

    const/16 v37, -0x6c

    aput-byte v37, v5, v4

    const/16 v4, -0x37

    const/16 v37, 0x5b

    aput-byte v4, v5, v37

    const/16 v4, 0x3d

    const/16 v17, 0x5c

    aput-byte v4, v5, v17

    const/16 v4, 0x5d

    const/16 v38, 0x6d

    aput-byte v38, v5, v4

    const/16 v4, 0x5e

    aput-byte v29, v5, v4

    const/16 v4, 0x5f

    const/16 v38, -0x4d

    aput-byte v38, v5, v4

    const/16 v4, 0x60

    const/16 v38, -0x67

    aput-byte v38, v5, v4

    const/16 v4, 0x61

    const/16 v38, -0x72

    aput-byte v38, v5, v4

    const/16 v4, 0x62

    const/16 v38, -0x72

    aput-byte v38, v5, v4

    const/16 v4, 0x63

    const/16 v38, -0x65

    aput-byte v38, v5, v4

    const/16 v4, 0x64

    const/16 v38, 0x3b

    aput-byte v38, v5, v4

    const/16 v4, 0x65

    const/16 v38, 0x70

    aput-byte v38, v5, v4

    const/16 v4, 0x66

    const/16 v38, 0xf

    aput-byte v38, v5, v4

    const/16 v4, 0x67

    const/16 v38, -0x5c

    aput-byte v38, v5, v4

    const/16 v4, 0x68

    const/16 v38, -0x2d

    aput-byte v38, v5, v4

    const/16 v4, 0x69

    const/16 v38, -0x40

    aput-byte v38, v5, v4

    new-array v4, v7, [B

    const/16 v38, -0x41

    aput-byte v38, v4, v11

    const/16 v38, -0x3

    aput-byte v38, v4, v12

    const/16 v38, -0x1a

    aput-byte v38, v4, v13

    const/16 v38, -0xc

    aput-byte v38, v4, v14

    const/16 v38, 0x49

    aput-byte v38, v4, v15

    aput-byte v15, v4, v10

    const/16 v38, 0x7a

    aput-byte v38, v4, v6

    const/16 v39, -0x2a

    aput-byte v39, v4, v2

    invoke-static {v5, v4}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v4, 0x33

    new-array v4, v4, [B

    aput-byte v33, v4, v11

    const/16 v5, -0x7d

    aput-byte v5, v4, v12

    const/16 v5, 0x56

    aput-byte v5, v4, v13

    const/16 v5, 0x33

    aput-byte v5, v4, v14

    const/16 v5, 0x78

    aput-byte v5, v4, v15

    const/16 v5, 0x5e

    aput-byte v5, v4, v10

    const/16 v5, 0x6b

    aput-byte v5, v4, v6

    const/16 v5, -0x23

    aput-byte v5, v4, v2

    const/16 v5, 0x60

    aput-byte v5, v4, v7

    const/16 v5, -0x68

    aput-byte v5, v4, v23

    const/16 v5, 0xa

    const/16 v17, 0x5c

    aput-byte v17, v4, v5

    aput-byte v25, v4, v24

    const/16 v5, 0x53

    aput-byte v5, v4, v22

    const/16 v5, 0xd

    const/16 v39, 0xe

    aput-byte v39, v4, v5

    const/16 v5, 0xe

    aput-byte v35, v4, v5

    const/16 v5, 0xf

    const/16 v39, -0x61

    aput-byte v39, v4, v5

    const/16 v5, 0x10

    const/16 v39, 0x73

    aput-byte v39, v4, v5

    const/16 v5, 0x11

    const/16 v39, -0x34

    aput-byte v39, v4, v5

    const/16 v5, 0x12

    aput-byte v7, v4, v5

    const/16 v5, 0x13

    aput-byte v38, v4, v5

    const/16 v5, 0x14

    aput-byte v34, v4, v5

    aput-byte v24, v4, v26

    const/16 v5, 0x16

    const/16 v26, 0x3b

    aput-byte v26, v4, v5

    const/16 v5, -0x6b

    aput-byte v5, v4, v29

    const/16 v5, 0x18

    const/16 v26, 0x78

    aput-byte v26, v4, v5

    const/16 v5, 0x19

    const/16 v26, -0x6c

    aput-byte v26, v4, v5

    const/16 v5, 0x1a

    aput-byte v20, v4, v5

    const/16 v5, 0x1b

    const/16 v20, 0x61

    aput-byte v20, v4, v5

    aput-byte v34, v4, v3

    const/16 v3, 0x1d

    aput-byte v24, v4, v3

    const/16 v3, 0x1e

    const/16 v5, 0x2f

    aput-byte v5, v4, v3

    const/16 v3, 0x1f

    const/16 v5, -0x6b

    aput-byte v5, v4, v3

    const/16 v3, 0x20

    aput-byte v38, v4, v3

    const/16 v3, 0x21

    const/16 v5, -0x6c

    aput-byte v5, v4, v3

    const/16 v3, 0x22

    aput-byte v21, v4, v3

    const/16 v3, 0x23

    aput-byte v38, v4, v3

    const/16 v3, 0x7b

    aput-byte v3, v4, v27

    aput-byte v6, v4, v28

    const/16 v3, 0x26

    aput-byte v36, v4, v3

    const/16 v3, 0x27

    const/16 v5, -0x3a

    aput-byte v5, v4, v3

    const/16 v3, 0x28

    const/16 v5, 0x27

    aput-byte v5, v4, v3

    const/16 v3, 0x29

    aput-byte v18, v4, v3

    const/16 v3, 0x2a

    aput-byte v37, v4, v3

    aput-byte v36, v4, v25

    const/16 v3, 0x2c

    const/16 v5, 0x7f

    aput-byte v5, v4, v3

    aput-byte v29, v4, v32

    const/16 v3, 0x2e

    aput-byte v35, v4, v3

    const/16 v3, 0x2f

    aput-byte v31, v4, v3

    const/16 v3, 0x73

    aput-byte v3, v4, v33

    const/16 v3, -0x61

    aput-byte v3, v4, v30

    const/16 v3, 0x32

    aput-byte v15, v4, v3

    new-array v3, v7, [B

    const/16 v5, 0x16

    aput-byte v5, v3, v11

    const/16 v5, -0xf

    aput-byte v5, v3, v12

    const/16 v5, 0x39

    aput-byte v5, v3, v13

    const/16 v5, 0x5c

    aput-byte v5, v3, v14

    aput-byte v22, v3, v15

    const/16 v5, 0x63

    aput-byte v5, v3, v10

    const/16 v5, 0x5a

    aput-byte v5, v3, v6

    const/4 v5, -0x5

    aput-byte v5, v3, v2

    invoke-static {v4, v3}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct/range {p0 .. p0}, Lcom/github/catvod/spider/appysv2/b/A;->f()Ljava/util/Map;

    move-result-object v3

    new-array v4, v6, [B

    const/16 v5, -0x32

    aput-byte v5, v4, v11

    const/16 v5, -0x23

    aput-byte v5, v4, v12

    const/16 v5, -0x68

    aput-byte v5, v4, v13

    const/16 v5, -0x3f

    aput-byte v5, v4, v14

    const/16 v5, 0x18

    aput-byte v5, v4, v15

    const/16 v5, -0x4c

    aput-byte v5, v4, v10

    new-array v5, v7, [B

    const/16 v17, -0x73

    aput-byte v17, v5, v11

    const/16 v17, -0x4e

    aput-byte v17, v5, v12

    const/16 v17, -0x9

    aput-byte v17, v5, v13

    const/16 v17, -0x56

    aput-byte v17, v5, v14

    const/16 v17, 0x71

    aput-byte v17, v5, v15

    const/16 v17, -0x2f

    aput-byte v17, v5, v10

    const/16 v17, 0x69

    aput-byte v17, v5, v6

    const/16 v17, -0x61

    aput-byte v17, v5, v2

    invoke-static {v4, v5}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v4

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    new-array v7, v2, [B

    const/16 v18, -0x6d

    aput-byte v18, v7, v11

    aput-byte v13, v7, v12

    const/16 v18, -0x8

    aput-byte v18, v7, v13

    const/16 v18, -0x17

    aput-byte v18, v7, v14

    aput-byte v10, v7, v15

    const/16 v18, -0x57

    aput-byte v18, v7, v10

    const/16 v18, -0x4a

    aput-byte v18, v7, v6

    const/16 v2, 0x8

    new-array v6, v2, [B

    const/16 v2, -0x2f

    aput-byte v2, v6, v11

    const/16 v2, 0x46

    aput-byte v2, v6, v12

    const/16 v2, -0x45

    aput-byte v2, v6, v13

    const/16 v2, -0x5b

    aput-byte v2, v6, v14

    const/16 v2, 0x4b

    aput-byte v2, v6, v15

    const/16 v2, -0x13

    aput-byte v2, v6, v10

    const/16 v2, -0x75

    const/16 v20, 0x6

    aput-byte v2, v6, v20

    const/16 v2, 0x6e

    const/16 v18, 0x7

    aput-byte v2, v6, v18

    invoke-static {v7, v6}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v5, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    move-object v5, v3

    check-cast v5, Ljava/util/HashMap;

    invoke-virtual {v5, v4, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    invoke-static {v1, v3}, Lcom/github/catvod/spider/appysv2/n/c;->m(Ljava/lang/String;Ljava/util/Map;)Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Lcom/github/catvod/spider/appysv2/f/b;->e(Ljava/lang/String;)Lcom/github/catvod/spider/appysv2/f/b;

    move-result-object v1

    invoke-virtual {v1}, Lcom/github/catvod/spider/appysv2/f/b;->a()I

    move-result v2

    if-nez v2, :cond_69f

    const/4 v2, 0x7

    new-array v3, v2, [B

    const/16 v2, 0x39

    aput-byte v2, v3, v11

    const/16 v2, -0x58

    aput-byte v2, v3, v12

    const/16 v2, -0x23

    aput-byte v2, v3, v13

    const/4 v2, -0x3

    aput-byte v2, v3, v14

    aput-byte v22, v3, v15

    const/16 v2, 0x6b

    aput-byte v2, v3, v10

    const/16 v2, 0x2a

    const/4 v4, 0x6

    aput-byte v2, v3, v4

    const/16 v2, 0x8

    new-array v4, v2, [B

    const/16 v2, 0x4a

    aput-byte v2, v4, v11

    const/16 v2, -0x40

    aput-byte v2, v4, v12

    const/16 v2, -0x44

    aput-byte v2, v4, v13

    const/16 v2, -0x71

    aput-byte v2, v4, v14

    const/16 v2, 0x69

    aput-byte v2, v4, v15

    aput-byte v13, v4, v10

    const/16 v2, 0x4e

    const/4 v5, 0x6

    aput-byte v2, v4, v5

    const/16 v2, -0x3e

    const/4 v5, 0x7

    aput-byte v2, v4, v5

    invoke-static {v3, v4}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1}, Lcom/github/catvod/spider/appysv2/f/b;->c()Ljava/lang/String;

    move-result-object v3

    invoke-direct {v8, v0, v2, v3}, Lcom/github/catvod/spider/appysv2/b/A;->r(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    new-array v2, v13, [B

    const/16 v3, -0x49

    aput-byte v3, v2, v11

    const/16 v3, 0x4f

    aput-byte v3, v2, v12

    const/16 v3, 0x8

    new-array v4, v3, [B

    const/16 v5, -0x3e

    aput-byte v5, v4, v11

    aput-byte v27, v4, v12

    aput-byte v3, v4, v13

    const/16 v3, 0x6d

    aput-byte v3, v4, v14

    const/16 v3, 0x10

    aput-byte v3, v4, v15

    aput-byte v30, v4, v10

    const/4 v3, 0x6

    aput-byte v32, v4, v3

    const/16 v3, -0x5e

    const/4 v5, 0x7

    aput-byte v3, v4, v5

    invoke-static {v2, v4}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1}, Lcom/github/catvod/spider/appysv2/f/b;->d()Ljava/lang/String;

    move-result-object v3

    invoke-direct {v8, v0, v2, v3}, Lcom/github/catvod/spider/appysv2/b/A;->r(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    invoke-virtual {v1}, Lcom/github/catvod/spider/appysv2/f/b;->b()Ljava/util/List;

    move-result-object v7

    invoke-interface {v7}, Ljava/util/List;->size()I

    move-result v1

    sub-int/2addr v1, v12

    move v6, v1

    :goto_503
    if-ltz v6, :cond_6a9

    invoke-interface {v7, v6}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcom/github/catvod/spider/appysv2/f/a;

    invoke-virtual {v1}, Lcom/github/catvod/spider/appysv2/f/a;->g()Z

    move-result v2

    if-eqz v2, :cond_517

    move-object/from16 v5, p3

    invoke-interface {v5, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    goto :goto_519

    :cond_517
    move-object/from16 v5, p3

    :goto_519
    invoke-virtual {v1}, Lcom/github/catvod/spider/appysv2/f/a;->b()I

    move-result v2

    if-ne v2, v12, :cond_68a

    new-array v2, v13, [B

    const/4 v3, 0x6

    aput-byte v3, v2, v11

    const/16 v3, -0x73

    aput-byte v3, v2, v12

    const/16 v3, 0x8

    new-array v4, v3, [B

    const/16 v3, 0x73

    aput-byte v3, v4, v11

    const/16 v3, -0x1a

    aput-byte v3, v4, v12

    const/16 v3, 0x4e

    aput-byte v3, v4, v13

    const/16 v3, 0x36

    aput-byte v3, v4, v14

    const/16 v3, -0x3e

    aput-byte v3, v4, v15

    const/16 v3, -0x2a

    aput-byte v3, v4, v10

    const/16 v3, -0x21

    const/16 v20, 0x6

    aput-byte v3, v4, v20

    const/4 v3, 0x7

    aput-byte v38, v4, v3

    invoke-static {v2, v4}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-direct {v8, v0, v2}, Lcom/github/catvod/spider/appysv2/b/A;->m(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    new-array v2, v3, [B

    const/16 v3, 0x56

    aput-byte v3, v2, v11

    const/16 v3, -0x1e

    aput-byte v3, v2, v12

    const/16 v3, -0x4f

    aput-byte v3, v2, v13

    aput-byte v16, v2, v14

    aput-byte v36, v2, v15

    const/16 v3, -0x33

    aput-byte v3, v2, v10

    const/16 v3, -0x76

    const/16 v20, 0x6

    aput-byte v3, v2, v20

    const/16 v3, 0x8

    new-array v10, v3, [B

    aput-byte v28, v10, v11

    const/16 v3, -0x76

    aput-byte v3, v10, v12

    const/16 v3, -0x30

    aput-byte v3, v10, v13

    const/16 v3, -0x79

    aput-byte v3, v10, v14

    const/16 v3, 0x5d

    aput-byte v3, v10, v15

    const/16 v3, -0x5c

    const/16 v22, 0x5

    aput-byte v3, v10, v22

    const/16 v3, -0x12

    const/16 v20, 0x6

    aput-byte v3, v10, v20

    const/4 v3, 0x7

    aput-byte v11, v10, v3

    invoke-static {v2, v10}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-direct {v8, v0, v2}, Lcom/github/catvod/spider/appysv2/b/A;->m(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/16 v3, 0xa

    new-array v3, v3, [B

    const/16 v22, 0x47

    aput-byte v22, v3, v11

    const/16 v22, -0x7a

    aput-byte v22, v3, v12

    const/16 v22, -0x53

    aput-byte v22, v3, v13

    const/16 v22, 0x11

    aput-byte v22, v3, v14

    const/16 v22, -0x5f

    aput-byte v22, v3, v15

    const/16 v22, 0x5

    aput-byte v19, v3, v22

    const/16 v22, -0x5f

    const/16 v20, 0x6

    aput-byte v22, v3, v20

    const/16 v18, 0x7

    aput-byte v34, v3, v18

    const/16 v15, 0x8

    aput-byte v20, v3, v15

    const/16 v17, -0x62

    aput-byte v17, v3, v23

    new-array v14, v15, [B

    const/16 v15, 0x68

    aput-byte v15, v14, v11

    aput-byte v16, v14, v12

    const/16 v15, -0x3b

    aput-byte v15, v14, v13

    const/16 v15, 0x70

    const/16 v24, 0x3

    aput-byte v15, v14, v24

    const/16 v15, -0x2d

    const/16 v22, 0x4

    aput-byte v15, v14, v22

    const/4 v15, 0x5

    aput-byte v37, v14, v15

    const/16 v15, -0x33

    const/16 v20, 0x6

    aput-byte v15, v14, v20

    const/4 v15, 0x7

    aput-byte v20, v14, v15

    invoke-static {v3, v14}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    new-array v3, v12, [B

    aput-byte v38, v3, v11

    const/16 v14, 0x8

    new-array v15, v14, [B

    const/16 v14, 0x57

    aput-byte v14, v15, v11

    aput-byte v21, v15, v12

    const/16 v14, 0x71

    aput-byte v14, v15, v13

    const/16 v14, -0x2b

    const/16 v24, 0x3

    aput-byte v14, v15, v24

    const/16 v14, 0x7d

    const/16 v22, 0x4

    aput-byte v14, v15, v22

    const/4 v14, 0x5

    aput-byte v11, v15, v14

    const/16 v14, 0x57

    const/16 v20, 0x6

    aput-byte v14, v15, v20

    const/4 v14, 0x7

    aput-byte v21, v15, v14

    invoke-static {v3, v15}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Lcom/github/catvod/spider/appysv2/f/a;->a()J

    move-result-wide v14

    invoke-virtual {v2, v14, v15}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    new-array v3, v12, [B

    const/16 v14, -0x44

    aput-byte v14, v3, v11

    const/16 v14, 0x8

    new-array v15, v14, [B

    const/16 v17, -0x6d

    aput-byte v17, v15, v11

    const/16 v17, -0x11

    aput-byte v17, v15, v12

    aput-byte v37, v15, v13

    const/16 v17, 0x3

    aput-byte v29, v15, v17

    const/16 v24, 0x4c

    const/16 v22, 0x4

    aput-byte v24, v15, v22

    const/16 v24, 0x5

    aput-byte v31, v15, v24

    const/16 v20, 0x6

    aput-byte v36, v15, v20

    const/16 v18, 0x7

    aput-byte v37, v15, v18

    invoke-static {v3, v15}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Lcom/github/catvod/spider/appysv2/f/a;->e()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v15

    invoke-virtual {v1}, Lcom/github/catvod/spider/appysv2/f/a;->e()Ljava/lang/String;

    move-result-object v25

    move-object/from16 v1, p0

    move-object v2, v9

    move-object v3, v4

    move-object v4, v10

    move-object v5, v15

    move v10, v6

    const/4 v15, 0x6

    move-object/from16 v6, p3

    move-object v14, v7

    const/16 v20, 0x8

    move-object/from16 v7, v25

    invoke-direct/range {v1 .. v7}, Lcom/github/catvod/spider/appysv2/b/A;->c(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/util/List;Ljava/lang/String;)V

    goto :goto_697

    :cond_68a
    move v10, v6

    move-object v14, v7

    const/4 v15, 0x6

    const/16 v17, 0x3

    const/16 v18, 0x7

    const/16 v20, 0x8

    const/16 v22, 0x4

    const/16 v24, 0x5

    :goto_697
    add-int/lit8 v6, v10, -0x1

    move-object v7, v14

    const/4 v10, 0x5

    const/4 v14, 0x3

    const/4 v15, 0x4

    goto/16 :goto_503

    :cond_69f
    const-string v0, ""

    invoke-static {v0}, Lcom/github/catvod/spider/appysv2/p/j;->b(Ljava/lang/String;)V
    :try_end_6a4
    .catch Ljava/lang/Exception; {:try_start_4 .. :try_end_6a4} :catch_6a5

    goto :goto_6a9

    :catch_6a5
    move-exception v0

    invoke-virtual {v0}, Ljava/lang/Throwable;->printStackTrace()V

    :cond_6a9
    :goto_6a9
    return-void
.end method

.method public final g()Ljava/lang/String;
    .registers 3

    const/4 v0, 0x6

    new-array v0, v0, [B

    fill-array-data v0, :array_16

    const/16 v1, 0x8

    new-array v1, v1, [B

    fill-array-data v1, :array_1e

    invoke-static {v0, v1}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lcom/github/catvod/spider/appysv2/p/C;->q(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    return-object v0

    :array_16
    .array-data 1
        -0x62t
        0x7t
        -0x2dt
        -0x5ft
        -0x59t
        0x17t
    .end array-data

    nop

    :array_1e
    .array-data 1
        -0x50t
        0x65t
        -0x4et
        -0x38t
        -0x3dt
        0x62t
        0x6ft
        0xbt
    .end array-data
.end method

.method public final h(Ljava/lang/String;)Lcom/github/catvod/spider/appysv2/c/e;
    .registers 32
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            ")",
            "Lcom/github/catvod/spider/appysv2/c/e<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    new-instance v1, Lcom/github/catvod/spider/appysv2/c/e;

    invoke-direct {v1}, Lcom/github/catvod/spider/appysv2/c/e;-><init>()V

    const/4 v0, 0x1

    move-object/from16 v2, p0

    move-object/from16 v3, p1

    :try_start_a
    invoke-direct {v2, v3, v0}, Lcom/github/catvod/spider/appysv2/b/A;->a(Ljava/lang/String;Z)Lcom/github/catvod/spider/appysv2/c/e;

    move-result-object v1

    invoke-virtual {v1}, Lcom/github/catvod/spider/appysv2/c/e;->b()I

    move-result v3

    if-nez v3, :cond_71f

    invoke-virtual {v1}, Lcom/github/catvod/spider/appysv2/c/e;->c()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/lang/CharSequence;

    invoke-static {v3}, Lcom/github/catvod/spider/appysv2/D/h;->c(Ljava/lang/CharSequence;)Z

    move-result v3

    if-eqz v3, :cond_22

    goto/16 :goto_71f

    :cond_22
    invoke-virtual {v1}, Lcom/github/catvod/spider/appysv2/c/e;->c()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/lang/String;

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const/16 v5, 0x19

    new-array v5, v5, [B

    const/4 v6, -0x2

    const/4 v7, 0x0

    aput-byte v6, v5, v7

    const/16 v6, 0x2c

    aput-byte v6, v5, v0

    const/16 v6, 0x63

    const/4 v8, 0x2

    aput-byte v6, v5, v8

    const/16 v6, -0x6b

    const/4 v9, 0x3

    aput-byte v6, v5, v9

    const/16 v6, -0x19

    const/4 v10, 0x4

    aput-byte v6, v5, v10

    const/16 v6, -0x7d

    const/4 v11, 0x5

    aput-byte v6, v5, v11

    const/16 v6, -0x35

    const/4 v12, 0x6

    aput-byte v6, v5, v12

    const/16 v6, 0x5d

    const/4 v13, 0x7

    aput-byte v6, v5, v13

    const/16 v6, -0xa

    const/16 v14, 0x8

    aput-byte v6, v5, v14

    const/16 v6, 0x28

    const/16 v15, 0x9

    aput-byte v6, v5, v15

    const/16 v6, 0x73

    const/16 v15, 0xa

    aput-byte v6, v5, v15

    const/16 v6, -0x7c

    const/16 v16, 0xb

    aput-byte v6, v5, v16

    const/4 v6, -0x6

    const/16 v15, 0xc

    aput-byte v6, v5, v15

    const/16 v6, -0x68

    const/16 v18, 0xd

    aput-byte v6, v5, v18

    const/16 v6, -0x7b

    const/16 v19, 0xe

    aput-byte v6, v5, v19

    const/16 v6, 0x72

    const/16 v20, 0xf

    aput-byte v6, v5, v20

    const/16 v6, -0xa

    const/16 v21, 0x10

    aput-byte v6, v5, v21

    const/16 v6, 0x39

    const/16 v22, 0x11

    aput-byte v6, v5, v22

    const/16 v6, 0x6e

    const/16 v23, 0x12

    aput-byte v6, v5, v23

    const/16 v6, 0x13

    const/16 v24, -0xf

    aput-byte v24, v5, v6

    const/4 v6, -0x6

    const/16 v24, 0x14

    aput-byte v6, v5, v24

    const/16 v6, 0x15

    const/16 v25, -0x6f

    aput-byte v25, v5, v6

    const/16 v6, 0x16

    const/16 v25, -0x2a

    aput-byte v25, v5, v6

    const/16 v6, 0x2b

    const/16 v25, 0x17

    aput-byte v6, v5, v25

    const/16 v6, 0x18

    const/16 v26, -0x47

    aput-byte v26, v5, v6

    new-array v6, v14, [B

    const/16 v26, -0x67

    aput-byte v26, v6, v7

    const/16 v26, 0x49

    aput-byte v26, v6, v0

    aput-byte v25, v6, v8

    const/16 v27, -0x2f

    aput-byte v27, v6, v9

    const/16 v27, -0x78

    aput-byte v27, v6, v10

    const/16 v27, -0xc

    aput-byte v27, v6, v11

    const/16 v27, -0x5b

    aput-byte v27, v6, v12

    aput-byte v22, v6, v13

    invoke-static {v5, v6}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-static {v4}, Lcom/github/catvod/crawler/SpiderDebug;->log(Ljava/lang/String;)V

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const/16 v5, 0x3f

    new-array v5, v5, [B

    const/16 v6, 0x9

    aput-byte v6, v5, v7

    aput-byte v23, v5, v0

    const/16 v6, -0x9

    aput-byte v6, v5, v8

    const/16 v6, -0x70

    aput-byte v6, v5, v9

    const/16 v6, 0x41

    aput-byte v6, v5, v10

    const/16 v6, -0x52

    aput-byte v6, v5, v11

    const/16 v6, 0x13

    aput-byte v6, v5, v12

    const/16 v6, 0x79

    aput-byte v6, v5, v13

    aput-byte v22, v5, v14

    const/16 v6, 0x9

    aput-byte v13, v5, v6

    const/16 v6, -0x13

    const/16 v17, 0xa

    aput-byte v6, v5, v17

    const/16 v6, -0x32

    aput-byte v6, v5, v16

    const/16 v6, 0x50

    aput-byte v6, v5, v15

    const/16 v6, -0xb

    aput-byte v6, v5, v18

    const/16 v6, 0x55

    aput-byte v6, v5, v19

    const/16 v6, 0x32

    aput-byte v6, v5, v20

    aput-byte v24, v5, v21

    const/16 v6, 0x48

    aput-byte v6, v5, v22

    const/16 v6, -0x20

    aput-byte v6, v5, v23

    const/16 v6, 0x13

    const/16 v27, -0x71

    aput-byte v27, v5, v6

    const/16 v6, 0x5f

    aput-byte v6, v5, v24

    const/16 v6, 0x15

    const/16 v27, -0x45

    aput-byte v27, v5, v6

    const/16 v6, 0x16

    const/16 v27, 0x5d

    aput-byte v27, v5, v6

    const/16 v6, 0x26

    aput-byte v6, v5, v25

    const/16 v6, 0x18

    aput-byte v14, v5, v6

    const/16 v6, 0x19

    aput-byte v26, v5, v6

    const/16 v6, 0x1a

    const/16 v27, -0x12

    aput-byte v27, v5, v6

    const/16 v6, 0x1b

    const/16 v27, -0x7b

    aput-byte v27, v5, v6

    const/16 v6, 0x1c

    const/16 v27, 0x56

    aput-byte v27, v5, v6

    const/16 v6, 0x1d

    const/16 v27, -0x3

    aput-byte v27, v5, v6

    const/16 v6, 0x1e

    const/16 v27, 0x5d

    aput-byte v27, v5, v6

    const/16 v6, 0x1f

    const/16 v27, 0x3f

    aput-byte v27, v5, v6

    const/16 v6, 0x20

    aput-byte v20, v5, v6

    const/16 v6, 0x21

    aput-byte v7, v5, v6

    const/16 v6, 0x22

    const/16 v27, -0x14

    aput-byte v27, v5, v6

    const/16 v6, 0x23

    const/16 v27, -0x21

    aput-byte v27, v5, v6

    const/16 v6, 0x24

    const/16 v27, 0x46

    aput-byte v27, v5, v6

    const/16 v6, 0x25

    const/16 v27, -0x13

    aput-byte v27, v5, v6

    const/16 v6, 0x26

    const/16 v27, 0x4c

    aput-byte v27, v5, v6

    const/16 v6, 0x27

    const/16 v27, 0x33

    aput-byte v27, v5, v6

    const/16 v6, 0x28

    const/16 v27, 0x5c

    aput-byte v27, v5, v6

    const/16 v6, 0x29

    const/16 v27, 0x2b

    aput-byte v27, v5, v6

    const/16 v6, 0x2a

    const/16 v27, -0x50

    aput-byte v27, v5, v6

    const/16 v6, 0x2b

    const/16 v27, -0x4b

    aput-byte v27, v5, v6

    const/16 v6, 0x2c

    const/16 v17, 0xa

    aput-byte v17, v5, v6

    const/16 v6, 0x2d

    const/16 v27, -0x35

    aput-byte v27, v5, v6

    const/16 v6, 0x2e

    const/16 v27, 0x7a

    aput-byte v27, v5, v6

    const/16 v6, 0x2f

    const/16 v27, 0x1a

    aput-byte v27, v5, v6

    const/16 v6, 0x30

    const/16 v27, 0x37

    aput-byte v27, v5, v6

    const/16 v6, 0x31

    const/16 v27, 0x39

    aput-byte v27, v5, v6

    const/16 v6, 0x32

    const/16 v27, -0x4f

    aput-byte v27, v5, v6

    const/16 v6, 0x33

    const/16 v27, -0x2a

    aput-byte v27, v5, v6

    const/16 v6, 0x34

    aput-byte v12, v5, v6

    const/16 v6, 0x35

    const/16 v27, -0x35

    aput-byte v27, v5, v6

    const/16 v6, 0x36

    aput-byte v14, v5, v6

    const/16 v6, 0x37

    const/16 v27, 0x6e

    aput-byte v27, v5, v6

    const/16 v6, 0x38

    const/16 v27, 0x51

    aput-byte v27, v5, v6

    const/16 v6, 0x39

    const/16 v27, 0x40

    aput-byte v27, v5, v6

    const/16 v6, 0x3a

    const/16 v27, -0xd

    aput-byte v27, v5, v6

    const/16 v6, 0x3b

    const/16 v27, -0x7f

    aput-byte v27, v5, v6

    const/16 v6, 0x3c

    const/16 v27, 0x46

    aput-byte v27, v5, v6

    const/16 v6, 0x3d

    const/16 v27, -0x4

    aput-byte v27, v5, v6

    const/16 v6, 0x3e

    aput-byte v0, v5, v6

    new-array v6, v14, [B

    const/16 v27, 0x61

    aput-byte v27, v6, v7

    const/16 v27, 0x66

    aput-byte v27, v6, v0

    const/16 v27, -0x7d

    aput-byte v27, v6, v8

    const/16 v27, -0x20

    aput-byte v27, v6, v9

    const/16 v27, 0x32

    aput-byte v27, v6, v10

    const/16 v27, -0x6c

    aput-byte v27, v6, v11

    const/16 v27, 0x3c

    aput-byte v27, v6, v12

    const/16 v27, 0x56

    aput-byte v27, v6, v13

    invoke-static {v5, v6}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static {v3}, Ljava/net/URLEncoder;->encode(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v3, 0x1a

    new-array v3, v3, [B

    const/16 v5, 0x27

    aput-byte v5, v3, v7

    const/4 v5, -0x2

    aput-byte v5, v3, v0

    const/16 v5, -0x3c

    aput-byte v5, v3, v8

    const/16 v5, -0x38

    aput-byte v5, v3, v9

    const/16 v5, -0x57

    aput-byte v5, v3, v10

    const/16 v5, -0x6d

    aput-byte v5, v3, v11

    const/16 v5, -0x34

    aput-byte v5, v3, v12

    const/16 v5, 0x44

    aput-byte v5, v3, v13

    const/16 v5, 0x78

    aput-byte v5, v3, v14

    const/16 v5, -0x13

    const/16 v6, 0x9

    aput-byte v5, v3, v6

    const/16 v5, -0x33

    const/16 v6, 0xa

    aput-byte v5, v3, v6

    const/16 v5, -0x64

    aput-byte v5, v3, v16

    const/16 v5, -0xc

    aput-byte v5, v3, v15

    const/16 v5, -0x33

    aput-byte v5, v3, v18

    const/16 v5, -0x62

    aput-byte v5, v3, v19

    const/16 v5, 0x5f

    aput-byte v5, v3, v20

    const/16 v5, 0x73

    aput-byte v5, v3, v21

    const/16 v5, -0xc

    aput-byte v5, v3, v22

    const/16 v5, -0x31

    aput-byte v5, v3, v23

    const/16 v5, 0x13

    const/16 v6, -0x38

    aput-byte v6, v3, v5

    const/16 v5, -0x5e

    aput-byte v5, v3, v24

    const/16 v5, 0x15

    const/16 v6, -0x40

    aput-byte v6, v3, v5

    const/16 v5, 0x16

    const/16 v6, -0x24

    aput-byte v6, v3, v5

    const/16 v5, 0x5c

    aput-byte v5, v3, v25

    const/16 v5, 0x18

    const/16 v6, 0x6f

    aput-byte v6, v3, v5

    const/16 v5, 0x19

    const/4 v6, -0x4

    aput-byte v6, v3, v5

    new-array v5, v14, [B

    aput-byte v0, v5, v7

    const/16 v6, -0x63

    aput-byte v6, v5, v0

    const/16 v6, -0x58

    aput-byte v6, v5, v8

    const/16 v6, -0x5f

    aput-byte v6, v5, v9

    const/16 v6, -0x34

    aput-byte v6, v5, v10

    const/4 v6, -0x3

    aput-byte v6, v5, v11

    const/16 v6, -0x48

    aput-byte v6, v5, v12

    const/16 v6, 0x30

    aput-byte v6, v5, v13

    invoke-static {v3, v5}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    new-instance v4, Ljava/util/HashMap;

    invoke-direct {v4}, Ljava/util/HashMap;-><init>()V

    const/16 v5, 0xa

    new-array v6, v5, [B

    const/16 v5, 0x3e

    aput-byte v5, v6, v7

    const/16 v5, -0x19

    aput-byte v5, v6, v0

    const/16 v5, 0x60

    aput-byte v5, v6, v8

    const/16 v5, -0x5e

    aput-byte v5, v6, v9

    const/16 v5, -0x6b

    aput-byte v5, v6, v10

    const/16 v5, -0x6e

    aput-byte v5, v6, v11

    const/16 v5, 0x61

    aput-byte v5, v6, v12

    const/16 v5, -0x30

    aput-byte v5, v6, v13

    aput-byte v11, v6, v14

    const/16 v5, -0x20

    const/16 v27, 0x9

    aput-byte v5, v6, v27

    new-array v5, v14, [B

    const/16 v27, 0x6b

    aput-byte v27, v5, v7

    const/16 v27, -0x6c

    aput-byte v27, v5, v0

    aput-byte v11, v5, v8

    const/16 v27, -0x30

    aput-byte v27, v5, v9

    const/16 v27, -0x48

    aput-byte v27, v5, v10

    const/16 v27, -0x2d

    aput-byte v27, v5, v11

    aput-byte v12, v5, v12

    const/16 v27, -0x4b

    aput-byte v27, v5, v13

    invoke-static {v6, v5}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v5

    const/16 v6, 0x4c

    new-array v6, v6, [B

    const/16 v27, 0x55

    aput-byte v27, v6, v7

    const/16 v27, -0x30

    aput-byte v27, v6, v0

    aput-byte v25, v6, v8

    const/16 v27, -0x49

    aput-byte v27, v6, v9

    aput-byte v26, v6, v10

    const/16 v27, -0x11

    aput-byte v27, v6, v11

    const/16 v27, -0x64

    aput-byte v27, v6, v12

    const/16 v27, 0x3c

    aput-byte v27, v6, v13

    const/16 v17, 0xa

    aput-byte v17, v6, v14

    const/16 v27, -0x65

    const/16 v28, 0x9

    aput-byte v27, v6, v28

    const/16 v27, 0x57

    aput-byte v27, v6, v17

    const/16 v27, -0x3

    aput-byte v27, v6, v16

    aput-byte v23, v6, v15

    const/16 v27, -0x59

    aput-byte v27, v6, v18

    const/16 v27, -0x3b

    aput-byte v27, v6, v19

    const/16 v27, 0x35

    aput-byte v27, v6, v20

    aput-byte v16, v6, v21

    const/16 v27, -0x79

    aput-byte v27, v6, v22

    const/16 v27, 0x52

    aput-byte v27, v6, v23

    const/16 v27, 0x13

    const/16 v28, -0x1f

    aput-byte v28, v6, v27

    aput-byte v22, v6, v24

    const/16 v27, 0x15

    const/16 v28, -0x53

    aput-byte v28, v6, v27

    const/16 v27, 0x16

    const/16 v28, -0x5b

    aput-byte v28, v6, v27

    const/16 v27, 0x44

    aput-byte v27, v6, v25

    const/16 v27, 0x18

    aput-byte v7, v6, v27

    const/16 v27, 0x19

    const/16 v28, -0x2c

    aput-byte v28, v6, v27

    const/16 v27, 0x1a

    aput-byte v18, v6, v27

    const/16 v27, 0x1b

    const/16 v28, -0x49

    aput-byte v28, v6, v27

    const/16 v27, 0x1c

    const/16 v28, 0x52

    aput-byte v28, v6, v27

    const/16 v27, 0x1d

    const/16 v28, -0xd

    aput-byte v28, v6, v27

    const/16 v27, 0x1e

    const/16 v28, -0x62

    aput-byte v28, v6, v27

    const/16 v27, 0x1f

    const/16 v28, 0x63

    aput-byte v28, v6, v27

    const/16 v27, 0x20

    const/16 v28, 0x16

    aput-byte v28, v6, v27

    const/16 v27, 0x21

    const/16 v28, -0x2c

    aput-byte v28, v6, v27

    const/16 v27, 0x22

    aput-byte v18, v6, v27

    const/16 v27, 0x23

    const/16 v28, -0x49

    aput-byte v28, v6, v27

    const/16 v27, 0x24

    const/16 v28, 0x52

    aput-byte v28, v6, v27

    const/16 v27, 0x25

    const/16 v28, -0xd

    aput-byte v28, v6, v27

    const/16 v27, 0x26

    const/16 v28, -0x62

    aput-byte v28, v6, v27

    const/16 v27, 0x27

    const/16 v28, 0x63

    aput-byte v28, v6, v27

    const/16 v27, 0x28

    aput-byte v7, v6, v27

    const/16 v27, 0x29

    const/16 v28, -0x7c

    aput-byte v28, v6, v27

    const/16 v27, 0x2a

    const/16 v28, 0x51

    aput-byte v28, v6, v27

    const/16 v27, 0x2b

    const/16 v28, -0x18

    aput-byte v28, v6, v27

    const/16 v27, 0x2c

    const/16 v28, 0x6a

    aput-byte v28, v6, v27

    const/16 v27, 0x2d

    const/16 v28, -0x31

    aput-byte v28, v6, v27

    const/16 v27, 0x2e

    const/16 v28, -0x6b

    aput-byte v28, v6, v27

    const/16 v27, 0x2f

    const/16 v28, 0x75

    aput-byte v28, v6, v27

    const/16 v27, 0x30

    const/16 v28, 0x52

    aput-byte v28, v6, v27

    const/16 v27, 0x31

    const/16 v28, -0x2f

    aput-byte v28, v6, v27

    const/16 v27, 0x32

    aput-byte v10, v6, v27

    const/16 v27, 0x33

    const/16 v28, -0x4a

    aput-byte v28, v6, v27

    const/16 v27, 0x34

    aput-byte v24, v6, v27

    const/16 v27, 0x35

    const/16 v28, -0x4e

    aput-byte v28, v6, v27

    const/16 v27, 0x36

    const/16 v28, -0x3d

    aput-byte v28, v6, v27

    const/16 v27, 0x37

    const/16 v28, 0x29

    aput-byte v28, v6, v27

    const/16 v27, 0x38

    aput-byte v16, v6, v27

    const/16 v27, 0x39

    const/16 v28, -0x72

    aput-byte v28, v6, v27

    const/16 v27, 0x3a

    const/16 v28, 0x9

    aput-byte v28, v6, v27

    const/16 v27, 0x3b

    const/16 v28, -0x44

    aput-byte v28, v6, v27

    const/16 v27, 0x3c

    aput-byte v26, v6, v27

    const/16 v27, 0x3d

    const/16 v28, -0xe

    aput-byte v28, v6, v27

    const/16 v27, 0x3e

    const/16 v28, -0x7d

    aput-byte v28, v6, v27

    const/16 v27, 0x3f

    const/16 v28, 0x45

    aput-byte v28, v6, v27

    const/16 v27, 0x40

    aput-byte v26, v6, v27

    const/16 v27, 0x41

    const/16 v28, -0x24

    aput-byte v28, v6, v27

    const/16 v27, 0x42

    aput-byte v13, v6, v27

    const/16 v27, 0x43

    const/16 v28, -0x4c

    aput-byte v28, v6, v27

    const/16 v27, 0x44

    const/16 v28, 0x45

    aput-byte v28, v6, v27

    const/16 v27, 0x45

    const/16 v28, -0x59

    aput-byte v28, v6, v27

    const/16 v27, 0x46

    const/16 v28, -0x3a

    aput-byte v28, v6, v27

    const/16 v27, 0x47

    const/16 v28, 0x29

    aput-byte v28, v6, v27

    const/16 v27, 0x48

    const/16 v17, 0xa

    aput-byte v17, v6, v27

    const/16 v27, -0x65

    aput-byte v27, v6, v26

    const/16 v27, 0x4a

    const/16 v28, 0x53

    aput-byte v28, v6, v27

    const/16 v27, 0x4b

    const/16 v28, -0x18

    aput-byte v28, v6, v27

    new-array v15, v14, [B

    const/16 v28, 0x3b

    aput-byte v28, v15, v7

    const/16 v28, -0x4b

    aput-byte v28, v15, v0

    const/16 v28, 0x63

    aput-byte v28, v15, v8

    const/16 v28, -0x2d

    aput-byte v28, v15, v9

    const/16 v28, 0x20

    aput-byte v28, v15, v10

    const/16 v28, -0x64

    aput-byte v28, v15, v11

    const/16 v28, -0x9

    aput-byte v28, v15, v12

    aput-byte v13, v15, v13

    invoke-static {v6, v15}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v4, v5, v6}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    new-array v5, v12, [B

    aput-byte v21, v5, v7

    const/16 v6, 0x3d

    aput-byte v6, v5, v0

    const/16 v6, -0x34

    aput-byte v6, v5, v8

    const/16 v6, -0x25

    aput-byte v6, v5, v9

    aput-byte v24, v5, v10

    const/16 v6, 0x5b

    aput-byte v6, v5, v11

    new-array v6, v14, [B

    const/16 v15, 0x53

    aput-byte v15, v6, v7

    const/16 v15, 0x52

    aput-byte v15, v6, v0

    const/16 v15, -0x5d

    aput-byte v15, v6, v8

    const/16 v15, -0x50

    aput-byte v15, v6, v9

    const/16 v15, 0x7d

    aput-byte v15, v6, v10

    const/16 v15, 0x3e

    aput-byte v15, v6, v11

    const/16 v15, -0x58

    aput-byte v15, v6, v12

    const/16 v15, -0x2d

    aput-byte v15, v6, v13

    invoke-static {v5, v6}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-virtual/range {p0 .. p0}, Lcom/github/catvod/spider/appysv2/b/A;->g()Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v4, v5, v6}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    invoke-static {v3, v4}, Lcom/github/catvod/spider/appysv2/n/c;->m(Ljava/lang/String;Ljava/util/Map;)Ljava/lang/String;

    move-result-object v3

    new-instance v5, Lorg/json/JSONObject;

    invoke-direct {v5, v3}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    new-array v3, v10, [B

    const/16 v6, -0x54

    aput-byte v6, v3, v7

    const/16 v6, 0x5a

    aput-byte v6, v3, v0

    const/16 v6, -0x70

    aput-byte v6, v3, v8

    aput-byte v9, v3, v9

    new-array v6, v14, [B

    const/16 v15, -0x3b

    aput-byte v15, v6, v7

    const/16 v15, 0x34

    aput-byte v15, v6, v0

    const/16 v15, -0xa

    aput-byte v15, v6, v8

    const/16 v15, 0x6c

    aput-byte v15, v6, v9

    const/16 v15, -0xd

    aput-byte v15, v6, v10

    const/16 v15, -0x2f

    aput-byte v15, v6, v11

    const/16 v15, 0x28

    aput-byte v15, v6, v12

    const/16 v15, 0x21

    aput-byte v15, v6, v13

    invoke-static {v3, v6}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v5, v3}, Lorg/json/JSONObject;->optJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v3

    new-array v6, v11, [B

    const/16 v15, -0x2c

    aput-byte v15, v6, v7

    const/16 v15, 0x34

    aput-byte v15, v6, v0

    const/16 v15, 0x15

    aput-byte v15, v6, v8

    const/16 v15, 0x27

    aput-byte v15, v6, v9

    const/16 v15, -0x3c

    aput-byte v15, v6, v10

    new-array v15, v14, [B

    const/16 v28, -0x50

    aput-byte v28, v15, v7

    const/16 v28, 0x58

    aput-byte v28, v15, v0

    const/16 v28, 0x7c

    aput-byte v28, v15, v8

    aput-byte v26, v15, v9

    const/16 v28, -0x51

    aput-byte v28, v15, v10

    const/16 v28, -0x22

    aput-byte v28, v15, v11

    const/16 v28, -0x2b

    aput-byte v28, v15, v12

    aput-byte v26, v15, v13

    invoke-static {v6, v15}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v3, v6}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    const/16 v15, 0x1a

    new-array v15, v15, [B

    const/16 v28, -0x8

    aput-byte v28, v15, v7

    const/16 v28, 0x5e

    aput-byte v28, v15, v0

    const/16 v28, -0x76

    aput-byte v28, v15, v8

    const/16 v28, 0x29

    aput-byte v28, v15, v9

    const/16 v28, -0x80

    aput-byte v28, v15, v10

    aput-byte v12, v15, v11

    const/16 v28, -0x2e

    aput-byte v28, v15, v12

    const/16 v28, -0x3b

    aput-byte v28, v15, v13

    const/16 v28, -0x10

    aput-byte v28, v15, v14

    const/16 v28, 0x5a

    const/16 v29, 0x9

    aput-byte v28, v15, v29

    const/16 v28, -0x66

    const/16 v17, 0xa

    aput-byte v28, v15, v17

    const/16 v28, 0x38

    aput-byte v28, v15, v16

    const/16 v28, -0x63

    const/16 v27, 0xc

    aput-byte v28, v15, v27

    const/16 v28, 0x1d

    aput-byte v28, v15, v18

    const/16 v18, -0x64

    aput-byte v18, v15, v19

    const/16 v18, -0x13

    aput-byte v18, v15, v20

    const/16 v18, -0xd

    aput-byte v18, v15, v21

    const/16 v18, 0x52

    aput-byte v18, v15, v22

    const/16 v18, -0x70

    aput-byte v18, v15, v23

    const/16 v18, 0x13

    aput-byte v12, v15, v18

    const/16 v18, -0x31

    aput-byte v18, v15, v24

    const/16 v18, 0x15

    aput-byte v9, v15, v18

    const/16 v18, 0x16

    const/16 v20, -0x27

    aput-byte v20, v15, v18

    const/16 v18, -0x6

    aput-byte v18, v15, v25

    const/16 v18, 0x18

    const/16 v20, -0x5b

    aput-byte v20, v15, v18

    const/16 v18, 0x19

    const/16 v20, 0x1b

    aput-byte v20, v15, v18

    new-array v13, v14, [B

    const/16 v20, -0x61

    aput-byte v20, v13, v7

    const/16 v20, 0x3b

    aput-byte v20, v13, v0

    const/16 v20, -0x2

    aput-byte v20, v13, v8

    const/16 v20, 0x6d

    aput-byte v20, v13, v9

    const/16 v20, -0x11

    aput-byte v20, v13, v10

    const/16 v20, 0x71

    aput-byte v20, v13, v11

    const/16 v20, -0x44

    aput-byte v20, v13, v12

    const/16 v20, -0x77

    const/16 v18, 0x7

    aput-byte v20, v13, v18

    invoke-static {v15, v13}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v13

    invoke-virtual {v6, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v6, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    invoke-static {v6}, Lcom/github/catvod/crawler/SpiderDebug;->log(Ljava/lang/String;)V

    invoke-static {v3}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v6

    if-eqz v6, :cond_717

    new-array v6, v11, [B

    const/16 v13, 0x74

    aput-byte v13, v6, v7

    const/16 v13, 0x74

    aput-byte v13, v6, v0

    const/16 v13, 0x5d

    aput-byte v13, v6, v8

    const/16 v13, -0x3c

    aput-byte v13, v6, v9

    const/16 v13, 0x31

    aput-byte v13, v6, v10

    new-array v13, v14, [B

    aput-byte v22, v13, v7

    aput-byte v12, v13, v0

    const/16 v15, 0x2f

    aput-byte v15, v13, v8

    const/16 v15, -0x56

    aput-byte v15, v13, v9

    const/16 v15, 0x5e

    aput-byte v15, v13, v10

    aput-byte v26, v13, v11

    const/16 v15, -0x45

    aput-byte v15, v13, v12

    const/16 v15, -0x39

    const/16 v18, 0x7

    aput-byte v15, v13, v18

    invoke-static {v6, v13}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v5, v6}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;)I

    move-result v5

    invoke-virtual {v1, v5}, Lcom/github/catvod/spider/appysv2/c/e;->e(I)V

    const/16 v5, 0xc

    new-array v5, v5, [B

    const/16 v6, 0x5f

    aput-byte v6, v5, v7

    const/16 v6, -0x44

    aput-byte v6, v5, v0

    const/16 v6, -0x3e

    aput-byte v6, v5, v8

    const/16 v6, 0x43

    aput-byte v6, v5, v9

    const/16 v6, -0xf

    aput-byte v6, v5, v10

    const/16 v6, 0x3a

    aput-byte v6, v5, v11

    aput-byte v19, v5, v12

    const/16 v6, -0x63

    const/4 v13, 0x7

    aput-byte v6, v5, v13

    const/16 v6, -0x7f

    aput-byte v6, v5, v14

    const/16 v6, 0x37

    const/16 v13, 0x9

    aput-byte v6, v5, v13

    const/16 v6, 0xa

    aput-byte v8, v5, v6

    const/16 v6, -0x69

    aput-byte v6, v5, v16

    new-array v6, v14, [B

    const/16 v13, 0x3b

    aput-byte v13, v6, v7

    const/16 v7, -0x30

    aput-byte v7, v6, v0

    const/16 v0, -0x55

    aput-byte v0, v6, v8

    const/16 v0, 0x2d

    aput-byte v0, v6, v9

    const/16 v0, -0x66

    aput-byte v0, v6, v10

    const/16 v0, 0x1a

    aput-byte v0, v6, v11

    const/16 v0, -0x16

    aput-byte v0, v6, v12

    const/16 v0, 0x25

    const/4 v7, 0x7

    aput-byte v0, v6, v7

    invoke-static {v5, v6}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v1, v0}, Lcom/github/catvod/spider/appysv2/c/e;->f(Ljava/lang/Object;)V

    :cond_717
    invoke-static {v3, v4}, Lcom/github/catvod/spider/appysv2/n/c;->c(Ljava/lang/String;Ljava/util/Map;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v1, v0}, Lcom/github/catvod/spider/appysv2/c/e;->f(Ljava/lang/Object;)V
    :try_end_71e
    .catch Ljava/lang/Exception; {:try_start_a .. :try_end_71e} :catch_720

    goto :goto_72d

    :cond_71f
    :goto_71f
    return-object v1

    :catch_720
    move-exception v0

    const/16 v3, 0x1f4

    invoke-virtual {v1, v3}, Lcom/github/catvod/spider/appysv2/c/e;->e(I)V

    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v1, v0}, Lcom/github/catvod/spider/appysv2/c/e;->f(Ljava/lang/Object;)V

    :goto_72d
    return-object v1
.end method

.method public final j()Landroid/graphics/Bitmap;
    .registers 2

    sget-object v0, Lcom/github/catvod/spider/appysv2/b/A;->c:Landroid/graphics/Bitmap;

    return-object v0
.end method

.method public final l(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    .registers 27

    const-string v0, ""

    :try_start_2
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/16 v2, 0x25

    new-array v2, v2, [B

    const/16 v3, 0x7f

    const/4 v4, 0x0

    aput-byte v3, v2, v4

    const/16 v3, -0x32

    const/4 v5, 0x1

    aput-byte v3, v2, v5

    const/16 v6, 0x21

    const/4 v7, 0x2

    aput-byte v6, v2, v7

    const/16 v8, 0x7c

    const/4 v9, 0x3

    aput-byte v8, v2, v9

    const/16 v8, 0x11

    const/4 v10, 0x4

    aput-byte v8, v2, v10

    const/16 v11, 0x62

    const/4 v12, 0x5

    aput-byte v11, v2, v12

    const/4 v13, 0x7

    const/4 v14, 0x6

    aput-byte v13, v2, v14

    const/16 v15, 0x2d

    aput-byte v15, v2, v13

    const/16 v15, 0x67

    const/16 v3, 0x8

    aput-byte v15, v2, v3

    const/16 v15, 0x9

    const/16 v16, -0x25

    aput-byte v16, v2, v15

    const/16 v15, 0x3b

    const/16 v17, 0xa

    aput-byte v15, v2, v17

    const/16 v15, 0x22

    const/16 v18, 0xb

    aput-byte v15, v2, v18

    const/16 v15, 0xc

    aput-byte v4, v2, v15

    const/16 v15, 0xd

    const/16 v19, 0x39

    aput-byte v19, v2, v15

    const/16 v15, 0xe

    const/16 v19, 0x41

    aput-byte v19, v2, v15

    const/16 v15, 0xf

    const/16 v19, 0x66

    aput-byte v19, v2, v15

    const/16 v15, 0x10

    aput-byte v11, v2, v15

    const/16 v15, -0x6c

    aput-byte v15, v2, v8

    const/16 v15, 0x12

    const/16 v19, 0x36

    aput-byte v19, v2, v15

    const/16 v15, 0x13

    const/16 v19, 0x63

    aput-byte v19, v2, v15

    const/16 v15, 0xf

    const/16 v19, 0x14

    aput-byte v15, v2, v19

    const/16 v15, 0x15

    const/16 v20, 0x77

    aput-byte v20, v2, v15

    const/16 v15, 0x16

    const/16 v20, 0x5b

    aput-byte v20, v2, v15

    const/16 v15, 0x17

    const/16 v20, 0x6a

    aput-byte v20, v2, v15

    const/16 v15, 0x18

    const/16 v20, 0x76

    aput-byte v20, v2, v15

    const/16 v15, 0x19

    const/16 v20, -0x38

    aput-byte v20, v2, v15

    const/16 v15, 0x1a

    const/16 v20, 0x30

    aput-byte v20, v2, v15

    const/16 v15, 0x1b

    const/16 v20, 0x23

    aput-byte v20, v2, v15

    const/16 v15, 0x1c

    aput-byte v19, v2, v15

    const/16 v15, 0x1d

    const/16 v20, 0x3d

    aput-byte v20, v2, v15

    const/16 v15, 0x1e

    const/16 v20, 0x5a

    aput-byte v20, v2, v15

    const/16 v15, 0x1f

    const/16 v20, 0x6b

    aput-byte v20, v2, v15

    const/16 v15, 0x71

    const/16 v20, 0x20

    aput-byte v15, v2, v20

    const/16 v15, -0x3d

    aput-byte v15, v2, v6

    const/16 v15, 0x22

    const/16 v21, 0x6a

    aput-byte v21, v2, v15

    const/16 v15, 0x23

    const/16 v21, 0x78

    aput-byte v21, v2, v15

    const/16 v15, 0x24

    const/16 v22, 0x5f

    aput-byte v22, v2, v15

    new-array v15, v3, [B

    const/16 v22, 0x17

    aput-byte v22, v15, v4

    const/16 v22, -0x46

    aput-byte v22, v15, v5

    const/16 v22, 0x55

    aput-byte v22, v15, v7

    const/16 v22, 0xc

    aput-byte v22, v15, v9

    aput-byte v11, v15, v10

    const/16 v22, 0x58

    aput-byte v22, v15, v12

    const/16 v22, 0x28

    aput-byte v22, v15, v14

    aput-byte v7, v15, v13

    invoke-static {v2, v15}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v11

    invoke-virtual {v1, v11, v12}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    new-array v11, v14, [B

    const/16 v12, -0x76

    aput-byte v12, v11, v4

    aput-byte v10, v11, v5

    const/16 v12, -0x1b

    aput-byte v12, v11, v7

    const/16 v12, -0x71

    aput-byte v12, v11, v9

    aput-byte v19, v11, v10

    const/16 v12, -0x6a

    const/4 v15, 0x5

    aput-byte v12, v11, v15

    new-array v12, v3, [B

    const/16 v22, -0x54

    aput-byte v22, v12, v4

    const/16 v22, 0x77

    aput-byte v22, v12, v5

    const/16 v22, -0x70

    aput-byte v22, v12, v7

    const/16 v22, -0x3

    aput-byte v22, v12, v9

    aput-byte v21, v12, v10

    const/16 v22, -0x55

    const/4 v15, 0x5

    aput-byte v22, v12, v15

    const/16 v22, -0x2d

    aput-byte v22, v12, v14

    const/16 v22, -0x8

    aput-byte v22, v12, v13

    invoke-static {v11, v12}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v11

    invoke-virtual {v1, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-object/from16 v11, p1

    invoke-virtual {v1, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v11, 0x2e

    new-array v11, v11, [B

    const/16 v12, -0x18

    aput-byte v12, v11, v4

    const/16 v12, 0x5d

    aput-byte v12, v11, v5

    const/16 v12, -0x79

    aput-byte v12, v11, v7

    const/16 v12, -0x2f

    aput-byte v12, v11, v9

    const/16 v12, -0x16

    aput-byte v12, v11, v10

    const/16 v22, -0x29

    const/4 v15, 0x5

    aput-byte v22, v11, v15

    const/16 v22, -0x7b

    aput-byte v22, v11, v14

    const/16 v22, 0x34

    aput-byte v22, v11, v13

    const/16 v22, -0xd

    aput-byte v22, v11, v3

    const/16 v22, 0x9

    const/16 v23, 0x5d

    aput-byte v23, v11, v22

    const/16 v22, -0x79

    aput-byte v22, v11, v17

    const/16 v22, -0x3b

    aput-byte v22, v11, v18

    const/16 v22, 0xc

    aput-byte v12, v11, v22

    const/16 v22, 0xd

    const/16 v23, -0x2b

    aput-byte v23, v11, v22

    const/16 v22, 0xe

    const/16 v23, -0x7b

    aput-byte v23, v11, v22

    const/16 v22, 0xf

    const/16 v23, 0x31

    aput-byte v23, v11, v22

    const/16 v22, 0x10

    const/16 v23, -0x18

    aput-byte v23, v11, v22

    const/16 v22, 0x49

    aput-byte v22, v11, v8

    const/16 v8, 0x12

    const/16 v22, -0x76

    aput-byte v22, v11, v8

    const/16 v8, 0x13

    const/16 v22, -0x2e

    aput-byte v22, v11, v8

    const/16 v8, -0x47

    aput-byte v8, v11, v19

    const/16 v8, 0x15

    const/16 v22, -0x78

    aput-byte v22, v11, v8

    const/16 v8, 0x16

    const/16 v22, -0x3a

    aput-byte v22, v11, v8

    const/16 v8, 0x17

    const/16 v22, 0x39

    aput-byte v22, v11, v8

    const/16 v8, 0x18

    const/16 v22, -0x42

    aput-byte v22, v11, v8

    const/16 v8, 0x19

    const/16 v22, 0x4e

    aput-byte v22, v11, v8

    const/16 v8, 0x1a

    const/16 v22, -0x50

    aput-byte v22, v11, v8

    const/16 v8, 0x1b

    const/16 v22, -0x27

    aput-byte v22, v11, v8

    const/16 v8, 0x1c

    const/16 v22, -0x20

    aput-byte v22, v11, v8

    const/16 v8, 0x1d

    const/16 v22, -0x7c

    aput-byte v22, v11, v8

    const/16 v8, 0x1e

    const/16 v23, -0x2e

    aput-byte v23, v11, v8

    const/16 v8, 0x1f

    const/16 v23, 0x6d

    aput-byte v23, v11, v8

    const/4 v8, -0x2

    aput-byte v8, v11, v20

    aput-byte v18, v11, v6

    const/16 v6, 0x22

    const/16 v8, -0x23

    aput-byte v8, v11, v6

    const/16 v6, 0x23

    const/16 v8, -0x78

    aput-byte v8, v11, v6

    const/16 v6, 0x24

    const/16 v8, -0x5e

    aput-byte v8, v11, v6

    const/16 v6, 0x25

    aput-byte v16, v11, v6

    const/16 v6, 0x26

    aput-byte v22, v11, v6

    const/16 v6, 0x27

    const/16 v8, 0x2b

    aput-byte v8, v11, v6

    const/16 v6, 0x28

    const/16 v8, -0x46

    aput-byte v8, v11, v6

    const/16 v6, 0x29

    const/16 v8, 0x51

    aput-byte v8, v11, v6

    const/16 v6, 0x2a

    aput-byte v22, v11, v6

    const/16 v6, 0x2b

    const/16 v8, -0x2b

    aput-byte v8, v11, v6

    const/16 v6, 0x2c

    aput-byte v12, v11, v6

    const/16 v6, 0x2d

    aput-byte v22, v11, v6

    new-array v6, v3, [B

    const/16 v8, -0x32

    aput-byte v8, v6, v4

    const/16 v8, 0x3e

    aput-byte v8, v6, v5

    const/16 v8, -0x11

    aput-byte v8, v6, v7

    const/16 v8, -0x50

    aput-byte v8, v6, v9

    aput-byte v22, v6, v10

    const/16 v8, -0x47

    const/4 v15, 0x5

    aput-byte v8, v6, v15

    const/16 v8, -0x20

    aput-byte v8, v6, v14

    const/16 v8, 0x58

    aput-byte v8, v6, v13

    invoke-static {v11, v6}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v1, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    new-instance v6, Ljava/util/HashMap;

    invoke-direct {v6}, Ljava/util/HashMap;-><init>()V

    new-array v8, v9, [B

    const/16 v11, 0x3e

    aput-byte v11, v8, v4

    const/16 v11, -0x56

    aput-byte v11, v8, v5

    const/16 v11, -0x29

    aput-byte v11, v8, v7

    new-array v11, v3, [B

    const/16 v18, 0x4e

    aput-byte v18, v11, v4

    const/16 v18, -0x23

    aput-byte v18, v11, v5

    const/16 v18, -0x4d

    aput-byte v18, v11, v7

    const/16 v18, -0x79

    aput-byte v18, v11, v9

    aput-byte v9, v11, v10

    const/16 v18, 0x33

    const/4 v15, 0x5

    aput-byte v18, v11, v15

    const/16 v18, -0x33

    aput-byte v18, v11, v14

    const/16 v18, 0x35

    aput-byte v18, v11, v13

    invoke-static {v8, v11}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v8

    move-object/from16 v11, p2

    invoke-virtual {v6, v8, v11}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    new-instance v8, Lorg/json/JSONObject;

    invoke-direct/range {p0 .. p0}, Lcom/github/catvod/spider/appysv2/b/A;->f()Ljava/util/Map;

    move-result-object v11

    invoke-static {v1, v6, v11}, Lcom/github/catvod/spider/appysv2/n/c;->h(Ljava/lang/String;Ljava/util/Map;Ljava/util/Map;)Lcom/github/catvod/spider/appysv2/n/e;

    move-result-object v1

    invoke-virtual {v1}, Lcom/github/catvod/spider/appysv2/n/e;->a()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v8, v1}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    const/4 v1, 0x5

    new-array v6, v1, [B

    const/16 v1, -0x51

    aput-byte v1, v6, v4

    const/16 v1, -0x4d

    aput-byte v1, v6, v5

    aput-byte v21, v6, v7

    aput-byte v16, v6, v9

    const/16 v1, -0x5f

    aput-byte v1, v6, v10

    new-array v1, v3, [B

    const/16 v11, -0x36

    aput-byte v11, v1, v4

    const/16 v11, -0x3f

    aput-byte v11, v1, v5

    aput-byte v17, v1, v7

    const/16 v11, -0x4b

    aput-byte v11, v1, v9

    const/16 v11, -0x32

    aput-byte v11, v1, v10

    const/4 v11, 0x5

    aput-byte v12, v1, v11

    const/16 v11, -0x66

    aput-byte v11, v1, v14

    aput-byte v21, v1, v13

    invoke-static {v6, v1}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v8, v1}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;)I

    move-result v1

    if-nez v1, :cond_32a

    new-array v1, v14, [B

    const/16 v6, 0x6f

    aput-byte v6, v1, v4

    const/16 v2, 0x62

    aput-byte v2, v1, v5

    const/16 v2, 0xd

    aput-byte v2, v1, v7

    const/16 v2, -0x34

    aput-byte v2, v1, v9

    const/16 v2, 0x2b

    aput-byte v2, v1, v10

    const/16 v2, 0x1f

    const/4 v6, 0x5

    aput-byte v2, v1, v6

    new-array v2, v3, [B

    const/16 v3, 0x1d

    aput-byte v3, v2, v4

    aput-byte v9, v2, v5

    const/16 v3, 0x63

    aput-byte v3, v2, v7

    const/16 v3, -0x58

    aput-byte v3, v2, v9

    const/16 v3, 0x58

    aput-byte v3, v2, v10

    const/16 v3, 0x74

    const/4 v4, 0x5

    aput-byte v3, v2, v4

    const/16 v3, 0x74

    aput-byte v3, v2, v14

    const/16 v3, -0x42

    aput-byte v3, v2, v13

    invoke-static {v1, v2}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v8, v1}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    return-object v0

    :cond_32a
    new-array v1, v13, [B

    const/16 v2, 0x71

    aput-byte v2, v1, v4

    const/16 v2, 0x52

    aput-byte v2, v1, v5

    const/16 v2, 0x52

    aput-byte v2, v1, v7

    const/4 v2, -0x5

    aput-byte v2, v1, v9

    const/16 v2, 0x75

    aput-byte v2, v1, v10

    const/4 v2, 0x5

    aput-byte v16, v1, v2

    const/16 v2, 0x32

    aput-byte v2, v1, v14

    new-array v2, v3, [B

    aput-byte v19, v2, v4

    aput-byte v20, v2, v5

    aput-byte v20, v2, v7

    const/16 v3, -0x5c

    aput-byte v3, v2, v9

    const/16 v3, 0x18

    aput-byte v3, v2, v10

    const/16 v3, -0x58

    const/4 v4, 0x5

    aput-byte v3, v2, v4

    const/16 v3, 0x55

    aput-byte v3, v2, v14

    const/16 v3, 0x34

    aput-byte v3, v2, v13

    invoke-static {v1, v2}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v8, v1}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;)I

    invoke-static {v0}, Lcom/github/catvod/spider/appysv2/p/j;->b(Ljava/lang/String;)V
    :try_end_36d
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_36d} :catch_36d

    :catch_36d
    return-object v0
.end method

.method public final o(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lcom/github/catvod/spider/appysv2/c/k;
    .registers 42

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move-object/from16 v2, p3

    new-instance v3, Lcom/github/catvod/spider/appysv2/c/k;

    invoke-direct {v3}, Lcom/github/catvod/spider/appysv2/c/k;-><init>()V

    :try_start_b
    new-instance v4, Ljava/util/ArrayList;

    invoke-direct {v4}, Ljava/util/ArrayList;-><init>()V

    move-object/from16 v5, p2

    invoke-virtual {v0, v1, v5, v4}, Lcom/github/catvod/spider/appysv2/b/A;->d(Ljava/lang/String;Ljava/lang/String;Ljava/util/List;)V

    const/16 v5, 0xa

    new-array v6, v5, [B

    const/4 v7, 0x3

    const/4 v8, 0x0

    aput-byte v7, v6, v8

    const/16 v9, -0x38

    const/4 v10, 0x1

    aput-byte v9, v6, v10

    const/16 v9, 0x7f

    const/4 v11, 0x2

    aput-byte v9, v6, v11

    const/16 v9, -0x12

    aput-byte v9, v6, v7

    const/16 v9, 0x3c

    const/4 v12, 0x4

    aput-byte v9, v6, v12

    const/16 v13, 0x3e

    const/4 v14, 0x5

    aput-byte v13, v6, v14

    const/16 v13, -0x5a

    const/4 v15, 0x6

    aput-byte v13, v6, v15

    const/16 v16, 0x6d

    const/16 v17, 0x7

    aput-byte v16, v6, v17

    const/16 v16, -0x2b

    const/16 v9, 0x8

    aput-byte v16, v6, v9

    const/16 v16, -0x6a

    const/16 v18, 0x9

    aput-byte v16, v6, v18

    new-array v5, v9, [B

    const/16 v19, 0x41

    aput-byte v19, v5, v8

    const/16 v19, 0x2d

    aput-byte v19, v5, v10

    const/16 v20, -0x3b

    aput-byte v20, v5, v11

    const/16 v21, 0x48

    aput-byte v21, v5, v7

    const/16 v22, -0x27

    aput-byte v22, v5, v12

    const/16 v22, -0x50

    aput-byte v22, v5, v14

    const/16 v22, 0x39

    aput-byte v22, v5, v15

    const/16 v22, -0x76

    aput-byte v22, v5, v17

    invoke-static {v6, v5}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-static {v5}, Ljava/util/Collections;->singletonList(Ljava/lang/Object;)Ljava/util/List;

    move-result-object v5

    new-instance v6, Ljava/util/ArrayList;

    invoke-direct {v6}, Ljava/util/ArrayList;-><init>()V

    new-instance v13, Ljava/util/ArrayList;

    invoke-direct {v13}, Ljava/util/ArrayList;-><init>()V

    invoke-virtual {v4}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v24

    :goto_84
    invoke-interface/range {v24 .. v24}, Ljava/util/Iterator;->hasNext()Z

    move-result v25
    :try_end_88
    .catch Ljava/lang/Exception; {:try_start_b .. :try_end_88} :catch_3ea

    const-string v15, ""

    const/16 v27, 0x27

    const/16 v28, 0x56

    const/16 v29, -0x65

    const/16 v30, 0xb

    const/16 v31, -0x6

    const/16 v32, 0x2e

    const/16 v33, 0x58

    if-eqz v25, :cond_26b

    :try_start_9a
    invoke-interface/range {v24 .. v24}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v25

    check-cast v25, Lcom/github/catvod/spider/appysv2/f/a;

    invoke-virtual/range {v25 .. v25}, Lcom/github/catvod/spider/appysv2/f/a;->d()Ljava/lang/String;

    move-result-object v34

    invoke-static/range {v34 .. v34}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v34

    const/16 v35, 0x45

    if-eqz v34, :cond_ad

    goto :goto_125

    :cond_ad
    new-instance v15, Ljava/lang/StringBuilder;

    invoke-direct {v15}, Ljava/lang/StringBuilder;-><init>()V

    new-array v14, v10, [B

    const/16 v36, 0x33

    aput-byte v36, v14, v8

    new-array v12, v9, [B

    const/16 v37, 0x68

    aput-byte v37, v12, v8

    const/16 v37, -0x5c

    aput-byte v37, v12, v10

    const/16 v37, -0x2e

    aput-byte v37, v12, v11

    aput-byte v31, v12, v7

    const/16 v31, -0x2a

    const/16 v36, 0x4

    aput-byte v31, v12, v36

    const/16 v31, -0x7f

    const/16 v34, 0x5

    aput-byte v31, v12, v34

    const/16 v26, 0x6

    aput-byte v35, v12, v26

    const/16 v23, -0x5a

    aput-byte v23, v12, v17

    invoke-static {v14, v12}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v12

    invoke-virtual {v15, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual/range {v25 .. v25}, Lcom/github/catvod/spider/appysv2/f/a;->d()Ljava/lang/String;

    move-result-object v12

    invoke-virtual {v12}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v12

    invoke-virtual {v15, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    new-array v12, v10, [B

    aput-byte v27, v12, v8

    new-array v14, v9, [B

    const/16 v31, 0x7a

    aput-byte v31, v14, v8

    const/16 v31, 0x5

    aput-byte v31, v14, v10

    const/16 v31, -0x49

    aput-byte v31, v14, v11

    const/16 v31, 0x7d

    aput-byte v31, v14, v7

    const/16 v31, -0x42

    const/16 v36, 0x4

    aput-byte v31, v14, v36

    const/16 v31, 0x60

    const/16 v34, 0x5

    aput-byte v31, v14, v34

    const/16 v31, 0x35

    const/16 v26, 0x6

    aput-byte v31, v14, v26

    const/16 v31, 0x78

    aput-byte v31, v14, v17

    invoke-static {v12, v14}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v12

    invoke-virtual {v15, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v15}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v15

    :goto_125
    new-instance v12, Ljava/lang/StringBuilder;

    invoke-direct {v12}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v12, v15}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual/range {v25 .. v25}, Lcom/github/catvod/spider/appysv2/f/a;->e()Ljava/lang/String;

    move-result-object v14

    invoke-virtual {v12, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual/range {v25 .. v25}, Lcom/github/catvod/spider/appysv2/f/a;->f()Ljava/lang/String;

    move-result-object v14

    invoke-virtual {v12, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    new-array v14, v10, [B

    const/16 v15, -0x32

    aput-byte v15, v14, v8

    new-array v15, v9, [B

    const/16 v31, -0x16

    aput-byte v31, v15, v8

    aput-byte v29, v15, v10

    const/16 v29, 0x10

    aput-byte v29, v15, v11

    aput-byte v21, v15, v7

    const/16 v29, 0x4

    aput-byte v30, v15, v29

    const/16 v29, -0x6f

    const/16 v30, 0x5

    aput-byte v29, v15, v30

    const/16 v29, -0x67

    const/16 v26, 0x6

    aput-byte v29, v15, v26

    const/16 v29, 0x1b

    aput-byte v29, v15, v17

    invoke-static {v14, v15}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v14

    invoke-virtual {v12, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v12, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    new-array v14, v10, [B

    const/16 v15, 0x73

    aput-byte v15, v14, v8

    new-array v15, v9, [B

    aput-byte v33, v15, v8

    const/16 v29, -0x3

    aput-byte v29, v15, v10

    const/16 v29, -0x4e

    aput-byte v29, v15, v11

    const/16 v29, 0x16

    aput-byte v29, v15, v7

    const/16 v29, -0x3a

    const/16 v30, 0x4

    aput-byte v29, v15, v30

    const/16 v29, 0x5

    aput-byte v32, v15, v29

    const/16 v29, 0x26

    const/16 v26, 0x6

    aput-byte v29, v15, v26

    const/16 v29, -0x29

    aput-byte v29, v15, v17

    invoke-static {v14, v15}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v14

    invoke-virtual {v12, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual/range {v25 .. v25}, Lcom/github/catvod/spider/appysv2/f/a;->a()J

    move-result-wide v14

    invoke-virtual {v12, v14, v15}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    invoke-virtual {v12}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v12

    invoke-static/range {p3 .. p3}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v14

    if-nez v14, :cond_263

    const/4 v14, 0x4

    new-array v15, v14, [B

    aput-byte v19, v15, v8

    const/16 v14, 0x38

    aput-byte v14, v15, v10

    const/16 v14, 0x37

    aput-byte v14, v15, v11

    const/16 v14, -0x35

    aput-byte v14, v15, v7

    new-array v14, v9, [B

    aput-byte v35, v14, v8

    const/16 v29, 0x4c

    aput-byte v29, v14, v10

    const/16 v29, 0x43

    aput-byte v29, v14, v11

    const/16 v29, -0x45

    aput-byte v29, v14, v7

    const/16 v29, 0x4

    aput-byte v19, v14, v29

    const/16 v29, 0x1e

    const/16 v30, 0x5

    aput-byte v29, v14, v30

    const/16 v29, 0x1c

    const/16 v26, 0x6

    aput-byte v29, v14, v26

    const/16 v29, -0x40

    aput-byte v29, v14, v17

    invoke-static {v15, v14}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v14

    invoke-virtual {v2, v14}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v14

    if-nez v14, :cond_263

    new-instance v14, Ljava/lang/StringBuilder;

    invoke-direct {v14}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v14, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    new-array v12, v10, [B

    const/4 v15, -0x4

    aput-byte v15, v12, v8

    new-array v15, v9, [B

    const/16 v29, -0x29

    aput-byte v29, v15, v8

    const/16 v29, 0x7e

    aput-byte v29, v15, v10

    aput-byte v28, v15, v11

    const/16 v28, -0x26

    aput-byte v28, v15, v7

    const/16 v28, 0x36

    const/16 v29, 0x4

    aput-byte v28, v15, v29

    const/16 v28, 0x5

    aput-byte v22, v15, v28

    const/16 v26, 0x6

    aput-byte v8, v15, v26

    const/16 v28, 0x37

    aput-byte v28, v15, v17

    invoke-static {v12, v15}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v12

    invoke-virtual {v14, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v14, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    new-array v12, v10, [B

    const/16 v15, -0x4a

    aput-byte v15, v12, v8

    new-array v15, v9, [B

    const/16 v28, -0x63

    aput-byte v28, v15, v8

    const/16 v28, -0x43

    aput-byte v28, v15, v10

    const/16 v28, -0x6f

    aput-byte v28, v15, v11

    const/16 v28, -0x4b

    aput-byte v28, v15, v7

    const/16 v26, 0x6

    const/16 v28, 0x4

    aput-byte v26, v15, v28

    const/16 v28, 0x5

    aput-byte v27, v15, v28

    const/16 v27, -0x79

    aput-byte v27, v15, v26

    const/16 v27, -0x18

    aput-byte v27, v15, v17

    invoke-static {v12, v15}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v12

    invoke-virtual {v14, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual/range {v25 .. v25}, Lcom/github/catvod/spider/appysv2/f/a;->e()Ljava/lang/String;

    move-result-object v12

    invoke-virtual {v14, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v14}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v12

    :cond_263
    invoke-virtual {v6, v12}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    const/4 v12, 0x4

    const/4 v14, 0x5

    const/4 v15, 0x6

    goto/16 :goto_84

    :cond_26b
    invoke-virtual {v6}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v2

    const/16 v12, -0x57

    const/16 v14, 0x5b

    const/16 v19, 0x5c

    const/16 v21, -0x23

    if-eqz v2, :cond_322

    const/16 v2, 0x1a

    new-array v2, v2, [B

    aput-byte v19, v2, v8

    aput-byte v21, v2, v10

    const/16 v22, 0x52

    aput-byte v22, v2, v11

    const/16 v22, 0x25

    aput-byte v22, v2, v7

    const/16 v22, 0x40

    const/16 v24, 0x4

    aput-byte v22, v2, v24

    const/16 v22, -0x1b

    const/16 v24, 0x5

    aput-byte v22, v2, v24

    const/16 v22, 0x6

    aput-byte v14, v2, v22

    const/16 v22, 0x3a

    aput-byte v22, v2, v17

    aput-byte v17, v2, v9

    const/16 v22, -0x4d

    aput-byte v22, v2, v18

    const/16 v18, 0x5a

    const/16 v16, 0xa

    aput-byte v18, v2, v16

    const/16 v16, 0x64

    aput-byte v16, v2, v30

    const/16 v16, 0x12

    const/16 v18, 0xc

    aput-byte v16, v2, v18

    const/16 v22, 0xd

    const/16 v24, -0x17

    aput-byte v24, v2, v22

    const/16 v22, 0xe

    const/16 v24, 0x11

    aput-byte v24, v2, v22

    const/16 v22, 0xf

    const/16 v25, 0x4f

    aput-byte v25, v2, v22

    const/16 v22, 0x10

    aput-byte v27, v2, v22

    aput-byte v20, v2, v24

    const/16 v20, 0x31

    aput-byte v20, v2, v16

    const/16 v16, 0x13

    const/16 v20, 0x65

    aput-byte v20, v2, v16

    const/16 v16, 0x14

    const/16 v20, 0x4b

    aput-byte v20, v2, v16

    const/16 v16, 0x15

    const/16 v20, -0x5a

    aput-byte v20, v2, v16

    const/16 v16, 0x16

    const/16 v20, 0x6

    aput-byte v20, v2, v16

    const/16 v16, 0x17

    aput-byte v18, v2, v16

    const/16 v16, 0x18

    const/16 v18, -0x63

    aput-byte v18, v2, v16

    const/16 v16, 0x19

    const/16 v18, 0x65

    aput-byte v18, v2, v16

    new-array v14, v9, [B

    const/16 v16, -0x47

    aput-byte v16, v14, v8

    const/16 v16, 0x55

    aput-byte v16, v14, v10

    const/16 v16, -0x2c

    aput-byte v16, v14, v11

    const/16 v16, -0x3f

    aput-byte v16, v14, v7

    const/16 v16, 0x4

    aput-byte v31, v14, v16

    const/16 v16, 0x4e

    const/16 v18, 0x5

    aput-byte v16, v14, v18

    const/16 v16, -0x4e

    const/16 v18, 0x6

    aput-byte v16, v14, v18

    aput-byte v12, v14, v17

    invoke-static {v2, v14}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v6, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_322
    const/4 v2, 0x0

    :goto_323
    invoke-interface {v5}, Ljava/util/List;->size()I

    move-result v14

    if-ge v2, v14, :cond_35d

    new-array v14, v10, [B

    aput-byte v33, v14, v8

    new-array v12, v9, [B

    const/16 v18, 0x7b

    aput-byte v18, v12, v8

    const/16 v18, 0x51

    aput-byte v18, v12, v10

    aput-byte v32, v12, v11

    aput-byte v28, v12, v7

    const/16 v16, -0x57

    const/16 v18, 0x4

    aput-byte v16, v12, v18

    const/16 v18, 0x5

    aput-byte v8, v12, v18

    const/16 v18, 0x79

    const/16 v20, 0x6

    aput-byte v18, v12, v20

    aput-byte v18, v12, v17

    invoke-static {v14, v12}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v12

    invoke-static {v12, v6}, Landroid/text/TextUtils;->join(Ljava/lang/CharSequence;Ljava/lang/Iterable;)Ljava/lang/String;

    move-result-object v12

    invoke-virtual {v13, v12}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/lit8 v2, v2, 0x1

    const/16 v12, -0x57

    goto :goto_323

    :cond_35d
    invoke-virtual {v3, v1}, Lcom/github/catvod/spider/appysv2/c/k;->g(Ljava/lang/String;)V

    invoke-virtual {v3, v1}, Lcom/github/catvod/spider/appysv2/c/k;->e(Ljava/lang/String;)V

    invoke-virtual {v3, v15}, Lcom/github/catvod/spider/appysv2/c/k;->i(Ljava/lang/String;)V

    invoke-virtual {v4, v8}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcom/github/catvod/spider/appysv2/f/a;

    invoke-virtual {v1}, Lcom/github/catvod/spider/appysv2/f/a;->c()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Lcom/github/catvod/spider/appysv2/b/A;->i(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v3, v1}, Lcom/github/catvod/spider/appysv2/c/k;->h(Ljava/lang/String;)V

    new-array v1, v7, [B

    const/16 v2, -0x53

    aput-byte v2, v1, v8

    aput-byte v29, v1, v10

    const/16 v2, 0x6a

    aput-byte v2, v1, v11

    new-array v2, v9, [B

    const/16 v4, -0x77

    aput-byte v4, v2, v8

    const/16 v4, -0x41

    aput-byte v4, v2, v10

    const/16 v4, 0x4e

    aput-byte v4, v2, v11

    aput-byte v19, v2, v7

    const/4 v4, 0x4

    aput-byte v21, v2, v4

    const/16 v4, 0x3c

    const/4 v6, 0x5

    aput-byte v4, v2, v6

    const/4 v4, 0x6

    aput-byte v28, v2, v4

    const/4 v4, -0x3

    aput-byte v4, v2, v17

    invoke-static {v1, v2}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-static {v1, v13}, Landroid/text/TextUtils;->join(Ljava/lang/CharSequence;Ljava/lang/Iterable;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v3, v1}, Lcom/github/catvod/spider/appysv2/c/k;->k(Ljava/lang/String;)V

    new-array v1, v7, [B

    const/16 v2, -0x58

    aput-byte v2, v1, v8

    const/16 v2, 0x30

    aput-byte v2, v1, v10

    const/16 v2, -0x20

    aput-byte v2, v1, v11

    new-array v2, v9, [B

    const/16 v4, -0x74

    aput-byte v4, v2, v8

    const/16 v4, 0x14

    aput-byte v4, v2, v10

    const/16 v4, -0x3c

    aput-byte v4, v2, v11

    const/16 v4, 0x44

    aput-byte v4, v2, v7

    const/16 v4, 0x76

    const/4 v6, 0x4

    aput-byte v4, v2, v6

    const/16 v4, 0x4f

    const/4 v6, 0x5

    aput-byte v4, v2, v6

    const/16 v4, 0x5b

    const/4 v6, 0x6

    aput-byte v4, v2, v6

    const/16 v4, -0x7a

    aput-byte v4, v2, v17

    invoke-static {v1, v2}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-static {v1, v5}, Landroid/text/TextUtils;->join(Ljava/lang/CharSequence;Ljava/lang/Iterable;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v3, v1}, Lcom/github/catvod/spider/appysv2/c/k;->j(Ljava/lang/String;)V
    :try_end_3ea
    .catch Ljava/lang/Exception; {:try_start_9a .. :try_end_3ea} :catch_3ea

    :catch_3ea
    return-object v3
.end method

.method public final p()Z
    .registers 3

    const/4 v0, 0x6

    new-array v0, v0, [B

    fill-array-data v0, :array_1c

    const/16 v1, 0x8

    new-array v1, v1, [B

    fill-array-data v1, :array_24

    invoke-static {v0, v1}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lcom/github/catvod/spider/appysv2/p/C;->q(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    xor-int/lit8 v0, v0, 0x1

    return v0

    :array_1c
    .array-data 1
        0x22t
        0x63t
        -0x5ct
        -0x73t
        0x32t
        -0x75t
    .end array-data

    nop

    :array_24
    .array-data 1
        0xct
        0x1t
        -0x3bt
        -0x1ct
        0x56t
        -0x2t
        -0xct
        0x5bt
    .end array-data
.end method

.method public final q([Ljava/lang/String;)Ljava/lang/String;
    .registers 47

    move-object/from16 v1, p0

    move-object/from16 v0, p1

    :try_start_4
    invoke-virtual/range {p0 .. p0}, Lcom/github/catvod/spider/appysv2/b/A;->p()Z

    move-result v2

    const/16 v7, 0xb

    const/16 v8, 0x9

    const/16 v9, 0xa

    const/16 v10, 0x8

    const/4 v11, 0x7

    const/4 v12, 0x6

    const/4 v13, 0x5

    const/4 v14, 0x0

    const/4 v15, 0x4

    const/16 v16, 0x1

    const/4 v3, 0x3

    const/4 v5, 0x2

    const/16 v19, 0x18

    const/16 v20, -0x40

    const/16 v21, 0x17

    const/16 v22, 0x2a

    const/16 v23, 0x13

    const/16 v24, 0x3f

    const/16 v25, 0x2b

    const/16 v26, 0x40

    const/16 v27, -0x11

    const/16 v4, 0x23

    const/16 v29, 0x11

    const/16 v30, 0x60

    const/16 v31, 0x46

    const/16 v32, 0x1d

    const/16 v33, 0x24

    const/16 v34, -0x2c

    const/16 v35, 0xe

    const/16 v36, 0x19

    const/16 v37, -0x70

    const/16 v6, 0x12

    const/16 v39, 0x14

    if-nez v2, :cond_1c3

    new-array v0, v4, [B

    const/16 v2, 0x62

    aput-byte v2, v0, v14

    aput-byte v27, v0, v16

    const/16 v2, -0x5f

    aput-byte v2, v0, v5

    aput-byte v26, v0, v3

    aput-byte v34, v0, v15

    const/16 v2, -0x43

    aput-byte v2, v0, v13

    const/16 v2, -0x6f

    aput-byte v2, v0, v12

    const/16 v2, -0x67

    aput-byte v2, v0, v11

    aput-byte v29, v0, v10

    const/16 v2, 0x5f

    aput-byte v2, v0, v8

    aput-byte v25, v0, v9

    const/16 v2, 0x4f

    aput-byte v2, v0, v7

    const/16 v2, -0x1e

    const/16 v26, 0xc

    aput-byte v2, v0, v26

    const/16 v2, -0x4f

    const/16 v26, 0xd

    aput-byte v2, v0, v26

    const/16 v2, -0x6f

    aput-byte v2, v0, v35

    const/16 v2, -0x56

    const/16 v18, 0xf

    aput-byte v2, v0, v18

    const/16 v2, 0x10

    aput-byte v24, v0, v2

    const/16 v2, -0x66

    aput-byte v2, v0, v29

    const/16 v2, -0x72

    aput-byte v2, v0, v6

    aput-byte v22, v0, v23

    const/16 v2, -0x56

    aput-byte v2, v0, v39

    const/16 v2, 0x15

    const/16 v22, -0x45

    aput-byte v22, v0, v2

    const/16 v2, 0x16

    const/16 v22, -0x26

    aput-byte v22, v0, v2

    aput-byte v20, v0, v21

    const/16 v2, 0x3c

    aput-byte v2, v0, v19

    const/16 v2, -0x22

    aput-byte v2, v0, v36

    const/16 v2, 0x1a

    const/16 v20, -0x12

    aput-byte v20, v0, v2

    const/16 v2, 0x1b

    aput-byte v19, v0, v2

    const/16 v2, 0x1c

    const/16 v20, -0x32

    aput-byte v20, v0, v2

    const/16 v2, -0x12

    aput-byte v2, v0, v32

    const/16 v2, 0x1e

    const/16 v20, -0x26

    aput-byte v20, v0, v2

    const/16 v2, 0x1f

    const/16 v20, -0x66

    aput-byte v20, v0, v2

    const/16 v2, 0x20

    const/16 v20, 0x63

    aput-byte v20, v0, v2

    const/16 v2, 0x21

    const/16 v20, -0x32

    aput-byte v20, v0, v2

    const/16 v2, 0x22

    const/16 v20, -0x5b

    aput-byte v20, v0, v2

    new-array v2, v10, [B

    const/16 v20, -0x7c

    aput-byte v20, v2, v14

    const/16 v20, 0x73

    aput-byte v20, v2, v16

    aput-byte v7, v2, v5

    const/16 v20, -0x59

    aput-byte v20, v2, v3

    const/16 v20, 0x4d

    aput-byte v20, v2, v15

    aput-byte v12, v2, v13

    const/16 v20, 0x74

    aput-byte v20, v2, v12

    aput-byte v33, v2, v11

    invoke-static {v0, v2}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lcom/github/catvod/spider/appysv2/p/j;->b(Ljava/lang/String;)V

    new-array v0, v4, [B

    aput-byte v14, v0, v14

    const/16 v2, -0x29

    aput-byte v2, v0, v16

    const/16 v2, 0x34

    aput-byte v2, v0, v5

    const/16 v2, 0x26

    aput-byte v2, v0, v3

    aput-byte v31, v0, v15

    const/16 v2, -0x64

    aput-byte v2, v0, v13

    aput-byte v30, v0, v12

    const/16 v2, -0x23

    aput-byte v2, v0, v11

    const/16 v2, 0x73

    aput-byte v2, v0, v10

    const/16 v2, 0x67

    aput-byte v2, v0, v8

    const/16 v2, -0x42

    aput-byte v2, v0, v9

    const/16 v2, 0x29

    aput-byte v2, v0, v7

    const/16 v2, 0x70

    const/16 v4, 0xc

    aput-byte v2, v0, v4

    const/16 v2, 0xd

    aput-byte v37, v0, v2

    aput-byte v30, v0, v35

    const/16 v2, -0x12

    const/16 v4, 0xf

    aput-byte v2, v0, v4

    const/16 v2, 0x5d

    const/16 v4, 0x10

    aput-byte v2, v0, v4

    const/16 v2, -0x5e

    aput-byte v2, v0, v29

    const/16 v2, 0x1b

    aput-byte v2, v0, v6

    const/16 v2, 0x4c

    aput-byte v2, v0, v23

    const/16 v2, 0x38

    aput-byte v2, v0, v39

    const/16 v2, 0x15

    const/16 v4, -0x66

    aput-byte v4, v0, v2

    const/16 v2, 0x16

    aput-byte v25, v0, v2

    const/16 v2, -0x7c

    aput-byte v2, v0, v21

    const/16 v2, 0x5e

    aput-byte v2, v0, v19

    const/16 v2, -0x1a

    aput-byte v2, v0, v36

    const/16 v2, 0x1a

    const/16 v4, 0x7b

    aput-byte v4, v0, v2

    const/16 v2, 0x1b

    const/16 v4, 0x7e

    aput-byte v4, v0, v2

    const/16 v2, 0x1c

    const/16 v4, 0x5c

    aput-byte v4, v0, v2

    const/16 v2, -0x31

    aput-byte v2, v0, v32

    const/16 v2, 0x1e

    aput-byte v25, v0, v2

    const/16 v2, 0x1f

    const/16 v4, -0x22

    aput-byte v4, v0, v2

    const/16 v2, 0x20

    aput-byte v16, v0, v2

    const/16 v2, 0x21

    const/16 v4, -0xa

    aput-byte v4, v0, v2

    const/16 v2, 0x22

    const/16 v4, 0x30

    aput-byte v4, v0, v2

    new-array v2, v10, [B

    const/16 v4, -0x1a

    aput-byte v4, v2, v14

    const/16 v4, 0x4b

    aput-byte v4, v2, v16

    const/16 v4, -0x62

    aput-byte v4, v2, v5

    const/16 v4, -0x3f

    aput-byte v4, v2, v3

    const/16 v3, -0x21

    aput-byte v3, v2, v15

    const/16 v3, 0x27

    aput-byte v3, v2, v13

    const/16 v3, -0x7b

    aput-byte v3, v2, v12

    aput-byte v30, v2, v11

    invoke-static {v0, v2}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lcom/github/catvod/spider/appysv2/c/h;->n(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    return-object v0

    :cond_1c3
    aget-object v2, v0, v14

    iput-object v2, v1, Lcom/github/catvod/spider/appysv2/b/A;->a:Ljava/lang/String;

    aget-object v2, v0, v16

    invoke-virtual {v1, v2}, Lcom/github/catvod/spider/appysv2/b/A;->h(Ljava/lang/String;)Lcom/github/catvod/spider/appysv2/c/e;

    move-result-object v2

    invoke-virtual {v2}, Lcom/github/catvod/spider/appysv2/c/e;->b()I

    move-result v40

    if-eqz v40, :cond_1dc

    invoke-virtual {v2}, Lcom/github/catvod/spider/appysv2/c/e;->d()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lcom/github/catvod/spider/appysv2/c/h;->n(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    return-object v0

    :cond_1dc
    invoke-virtual {v2}, Lcom/github/catvod/spider/appysv2/c/e;->c()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/String;

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const/16 v6, 0xd

    new-array v7, v6, [B

    const/16 v6, 0x28

    aput-byte v6, v7, v14

    const/16 v6, -0x77

    aput-byte v6, v7, v16

    const/16 v6, 0x70

    aput-byte v6, v7, v5

    const/16 v6, -0x3f

    aput-byte v6, v7, v3

    aput-byte v33, v7, v15

    const/16 v6, 0x7f

    aput-byte v6, v7, v13

    const/16 v6, -0x34

    aput-byte v6, v7, v12

    aput-byte v23, v7, v11

    aput-byte v36, v7, v10

    const/16 v6, -0x6c

    aput-byte v6, v7, v8

    const/16 v43, 0x6b

    aput-byte v43, v7, v9

    const/16 v43, -0x6b

    const/16 v42, 0xb

    aput-byte v43, v7, v42

    const/16 v43, 0x68

    const/16 v38, 0xc

    aput-byte v43, v7, v38

    new-array v6, v10, [B

    const/16 v44, 0x4c

    aput-byte v44, v6, v14

    const/16 v44, -0x1a

    aput-byte v44, v6, v16

    aput-byte v11, v6, v5

    const/16 v44, -0x51

    aput-byte v44, v6, v3

    const/16 v44, 0x48

    aput-byte v44, v6, v15

    const/16 v17, 0x10

    aput-byte v17, v6, v13

    const/16 v44, -0x53

    aput-byte v44, v6, v12

    const/16 v44, 0x77

    aput-byte v44, v6, v11

    invoke-static {v7, v6}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v4, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-static {v4}, Lcom/github/catvod/crawler/SpiderDebug;->log(Ljava/lang/String;)V

    invoke-direct/range {p0 .. p0}, Lcom/github/catvod/spider/appysv2/b/A;->f()Ljava/util/Map;

    move-result-object v4

    new-array v6, v9, [B

    const/16 v7, -0x42

    aput-byte v7, v6, v14

    aput-byte v36, v6, v16

    const/16 v7, -0x5c

    aput-byte v7, v6, v5

    const/16 v7, -0x65

    aput-byte v7, v6, v3

    const/16 v7, 0x6b

    aput-byte v7, v6, v15

    const/16 v7, 0x2f

    aput-byte v7, v6, v13

    const/16 v7, -0x65

    aput-byte v7, v6, v12

    const/16 v7, -0x37

    aput-byte v7, v6, v11

    const/16 v7, -0x7b

    aput-byte v7, v6, v10

    const/16 v7, 0x1e

    aput-byte v7, v6, v8

    new-array v7, v10, [B

    const/16 v44, -0x15

    aput-byte v44, v7, v14

    const/16 v44, 0x6a

    aput-byte v44, v7, v16

    const/16 v44, -0x3f

    aput-byte v44, v7, v5

    const/16 v44, -0x17

    aput-byte v44, v7, v3

    aput-byte v31, v7, v15

    const/16 v44, 0x6e

    aput-byte v44, v7, v13

    const/16 v44, -0x4

    aput-byte v44, v7, v12

    const/16 v44, -0x54

    aput-byte v44, v7, v11

    invoke-static {v6, v7}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v6

    const/16 v7, 0x4c

    new-array v7, v7, [B

    const/16 v44, 0x73

    aput-byte v44, v7, v14

    const/16 v43, -0x6c

    aput-byte v43, v7, v16

    const/16 v44, -0x51

    aput-byte v44, v7, v5

    const/16 v44, -0x61

    aput-byte v44, v7, v3

    const/16 v18, 0xf

    aput-byte v18, v7, v15

    aput-byte v33, v7, v13

    const/16 v44, -0x2a

    aput-byte v44, v7, v12

    aput-byte v27, v7, v11

    const/16 v44, 0x2c

    aput-byte v44, v7, v10

    const/16 v44, -0x21

    aput-byte v44, v7, v8

    aput-byte v27, v7, v9

    const/16 v44, -0x2b

    const/16 v42, 0xb

    aput-byte v44, v7, v42

    const/16 v44, 0x54

    const/16 v38, 0xc

    aput-byte v44, v7, v38

    const/16 v44, 0x6c

    const/16 v28, 0xd

    aput-byte v44, v7, v28

    const/16 v44, -0x71

    aput-byte v44, v7, v35

    const/16 v44, -0x1a

    const/16 v18, 0xf

    aput-byte v44, v7, v18

    const/16 v44, 0x2d

    const/16 v17, 0x10

    aput-byte v44, v7, v17

    const/16 v17, -0x3d

    aput-byte v17, v7, v29

    const/16 v17, -0x16

    const/16 v41, 0x12

    aput-byte v17, v7, v41

    const/16 v17, -0x37

    aput-byte v17, v7, v23

    const/16 v17, 0x57

    aput-byte v17, v7, v39

    const/16 v17, 0x15

    const/16 v23, 0x66

    aput-byte v23, v7, v17

    const/16 v17, 0x16

    aput-byte v27, v7, v17

    const/16 v17, -0x69

    aput-byte v17, v7, v21

    const/16 v17, 0x26

    aput-byte v17, v7, v19

    aput-byte v37, v7, v36

    const/16 v17, 0x1a

    const/16 v19, -0x4b

    aput-byte v19, v7, v17

    const/16 v17, 0x1b

    const/16 v19, -0x61

    aput-byte v19, v7, v17

    const/16 v17, 0x1c

    aput-byte v39, v7, v17

    const/16 v17, 0x38

    aput-byte v17, v7, v32

    const/16 v17, 0x1e

    aput-byte v34, v7, v17

    const/16 v17, 0x1f

    const/16 v19, -0x50

    aput-byte v19, v7, v17

    const/16 v17, 0x20

    const/16 v19, 0x30

    aput-byte v19, v7, v17

    const/16 v17, 0x21

    aput-byte v37, v7, v17

    const/16 v17, 0x22

    const/16 v19, -0x4b

    aput-byte v19, v7, v17

    const/16 v17, -0x61

    const/16 v19, 0x23

    aput-byte v17, v7, v19

    aput-byte v39, v7, v33

    const/16 v17, 0x25

    const/16 v19, 0x38

    aput-byte v19, v7, v17

    const/16 v17, 0x26

    aput-byte v34, v7, v17

    const/16 v17, 0x27

    const/16 v19, -0x50

    aput-byte v19, v7, v17

    const/16 v17, 0x28

    const/16 v19, 0x26

    aput-byte v19, v7, v17

    const/16 v17, 0x29

    aput-byte v20, v7, v17

    const/16 v17, -0x17

    aput-byte v17, v7, v22

    aput-byte v20, v7, v25

    const/16 v17, 0x2c

    const/16 v19, 0x2c

    aput-byte v19, v7, v17

    const/16 v17, 0x2d

    aput-byte v15, v7, v17

    const/16 v17, 0x2e

    const/16 v19, -0x21

    aput-byte v19, v7, v17

    const/16 v17, 0x2f

    const/16 v19, -0x5a

    aput-byte v19, v7, v17

    const/16 v17, 0x30

    const/16 v19, 0x74

    aput-byte v19, v7, v17

    const/16 v17, 0x31

    const/16 v19, -0x6b

    aput-byte v19, v7, v17

    const/16 v17, 0x32

    const/16 v19, -0x44

    aput-byte v19, v7, v17

    const/16 v17, 0x33

    const/16 v19, -0x62

    aput-byte v19, v7, v17

    const/16 v17, 0x34

    const/16 v19, 0x52

    aput-byte v19, v7, v17

    const/16 v17, 0x35

    const/16 v19, 0x79

    aput-byte v19, v7, v17

    const/16 v17, 0x36

    const/16 v19, -0x77

    aput-byte v19, v7, v17

    const/16 v17, 0x37

    const/16 v19, -0x6

    aput-byte v19, v7, v17

    const/16 v17, 0x38

    const/16 v19, 0x2d

    aput-byte v19, v7, v17

    const/16 v17, 0x39

    const/16 v19, -0x36

    aput-byte v19, v7, v17

    const/16 v17, 0x3a

    const/16 v19, -0x4f

    aput-byte v19, v7, v17

    const/16 v17, 0x3b

    const/16 v19, -0x6c

    aput-byte v19, v7, v17

    const/16 v17, 0x3c

    const/16 v18, 0xf

    aput-byte v18, v7, v17

    const/16 v17, 0x3d

    const/16 v19, 0x39

    aput-byte v19, v7, v17

    const/16 v17, 0x3e

    const/16 v19, -0x37

    aput-byte v19, v7, v17

    const/16 v17, -0x6a

    aput-byte v17, v7, v24

    const/16 v17, 0x6f

    aput-byte v17, v7, v26

    const/16 v17, 0x41

    const/16 v19, -0x68

    aput-byte v19, v7, v17

    const/16 v17, 0x42

    const/16 v19, -0x41

    aput-byte v19, v7, v17

    const/16 v17, 0x43

    const/16 v19, -0x64

    aput-byte v19, v7, v17

    const/16 v17, 0x44

    aput-byte v3, v7, v17

    const/16 v17, 0x45

    const/16 v19, 0x6c

    aput-byte v19, v7, v17

    const/16 v17, -0x74

    aput-byte v17, v7, v31

    const/16 v17, 0x47

    const/16 v19, -0x6

    aput-byte v19, v7, v17

    const/16 v17, 0x48

    const/16 v19, 0x2c

    aput-byte v19, v7, v17

    const/16 v17, 0x49

    const/16 v19, -0x21

    aput-byte v19, v7, v17

    const/16 v17, 0x4a

    const/16 v19, -0x15

    aput-byte v19, v7, v17

    const/16 v17, 0x4b

    aput-byte v20, v7, v17

    new-array v9, v10, [B

    aput-byte v32, v9, v14

    const/16 v19, -0xf

    aput-byte v19, v9, v16

    const/16 v19, -0x25

    aput-byte v19, v9, v5

    const/16 v19, -0x5

    aput-byte v19, v9, v3

    const/16 v19, 0x66

    aput-byte v19, v9, v15

    const/16 v19, 0x57

    aput-byte v19, v9, v13

    const/16 v19, -0x43

    aput-byte v19, v9, v12

    aput-byte v34, v9, v11

    invoke-static {v7, v9}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v7

    move-object v9, v4

    check-cast v9, Ljava/util/HashMap;

    invoke-virtual {v9, v6, v7}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    invoke-static {}, Lcom/github/catvod/spider/appysv2/p/m;->b()Ljava/lang/Boolean;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v6

    if-eqz v6, :cond_596

    const/16 v6, 0x190

    const/16 v7, 0xc

    invoke-static {v2, v7, v6}, Lcom/github/catvod/spider/appysv2/p/m;->d(Ljava/lang/String;II)Ljava/lang/String;

    move-result-object v2

    array-length v6, v0

    if-le v6, v3, :cond_584

    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    invoke-static {}, Lcom/github/catvod/spider/Proxy;->getUrl()Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v7, 0x12

    new-array v9, v7, [B

    const/16 v7, 0x79

    aput-byte v7, v9, v14

    const/16 v7, 0x1c

    aput-byte v7, v9, v16

    const/4 v7, -0x5

    aput-byte v7, v9, v5

    aput-byte v35, v9, v3

    const/16 v7, 0x51

    aput-byte v7, v9, v15

    const/16 v7, -0x32

    aput-byte v7, v9, v13

    aput-byte v15, v9, v12

    aput-byte v26, v9, v11

    const/16 v7, 0x33

    aput-byte v7, v9, v10

    const/16 v7, 0x5e

    aput-byte v7, v9, v8

    const/16 v7, -0x1e

    const/16 v17, 0xa

    aput-byte v7, v9, v17

    const/16 v7, 0x5c

    const/16 v19, 0xb

    aput-byte v7, v9, v19

    const/16 v7, 0x51

    const/16 v20, 0xc

    aput-byte v7, v9, v20

    const/16 v7, -0x1f

    const/16 v20, 0xd

    aput-byte v7, v9, v20

    aput-byte v19, v9, v35

    const/16 v7, 0xf

    aput-byte v26, v9, v7

    const/16 v7, 0x10

    const/16 v18, 0x23

    aput-byte v18, v9, v7

    const/16 v7, 0x45

    aput-byte v7, v9, v29

    new-array v7, v10, [B

    aput-byte v31, v7, v14

    const/16 v18, 0x78

    aput-byte v18, v7, v16

    const/16 v18, -0x6c

    aput-byte v18, v7, v5

    const/16 v18, 0x33

    aput-byte v18, v7, v3

    const/16 v18, 0x35

    aput-byte v18, v7, v15

    const/16 v18, -0x51

    aput-byte v18, v7, v13

    const/16 v18, 0x6a

    aput-byte v18, v7, v12

    const/16 v18, 0x2d

    aput-byte v18, v7, v11

    invoke-static {v9, v7}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    aget-object v7, v0, v5

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v7, 0xa

    new-array v9, v7, [B

    const/16 v7, -0x4e

    aput-byte v7, v9, v14

    const/16 v7, -0x25

    aput-byte v7, v9, v16

    const/16 v7, 0x12

    aput-byte v7, v9, v5

    const/16 v7, -0x15

    aput-byte v7, v9, v3

    aput-byte v22, v9, v15

    const/16 v7, -0x43

    aput-byte v7, v9, v13

    aput-byte v37, v9, v12

    aput-byte v13, v9, v11

    const/16 v7, -0x14

    aput-byte v7, v9, v10

    aput-byte v37, v9, v8

    new-array v7, v10, [B

    const/16 v8, -0x6c

    aput-byte v8, v7, v14

    const/16 v8, -0x53

    aput-byte v8, v7, v16

    const/16 v8, 0x7d

    aput-byte v8, v7, v5

    const/16 v8, -0x71

    aput-byte v8, v7, v3

    const/16 v8, 0x63

    aput-byte v8, v7, v15

    const/16 v8, -0x2d

    aput-byte v8, v7, v13

    const/16 v8, -0xc

    aput-byte v8, v7, v12

    aput-byte v30, v7, v11

    invoke-static {v9, v7}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    aget-object v0, v0, v3

    invoke-virtual {v6, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    new-array v0, v10, [B

    const/16 v7, -0x4a

    aput-byte v7, v0, v14

    aput-byte v3, v0, v16

    const/16 v7, 0x29

    aput-byte v7, v0, v5

    aput-byte v30, v0, v3

    const/16 v7, 0x5f

    aput-byte v7, v0, v15

    const/16 v7, 0x65

    aput-byte v7, v0, v13

    const/16 v7, -0x35

    aput-byte v7, v0, v12

    const/16 v7, 0x47

    aput-byte v7, v0, v11

    new-array v7, v10, [B

    aput-byte v37, v7, v14

    const/16 v8, 0x75

    aput-byte v8, v7, v16

    aput-byte v31, v7, v5

    aput-byte v15, v7, v3

    const/16 v3, 0xa

    aput-byte v3, v7, v15

    aput-byte v21, v7, v13

    const/16 v3, -0x59

    aput-byte v3, v7, v12

    const/16 v3, 0x7a

    aput-byte v3, v7, v11

    invoke-static {v0, v7}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v6, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {}, Lcom/github/catvod/spider/appysv2/c/h;->e()Lcom/github/catvod/spider/appysv2/c/h;

    move-result-object v3

    invoke-virtual {v3, v2}, Lcom/github/catvod/spider/appysv2/c/h;->y(Ljava/lang/String;)Lcom/github/catvod/spider/appysv2/c/h;

    invoke-virtual {v3, v0}, Lcom/github/catvod/spider/appysv2/c/h;->a(Ljava/lang/String;)Lcom/github/catvod/spider/appysv2/c/h;

    invoke-virtual {v3}, Lcom/github/catvod/spider/appysv2/c/h;->j()Lcom/github/catvod/spider/appysv2/c/h;

    invoke-virtual {v3, v4}, Lcom/github/catvod/spider/appysv2/c/h;->f(Ljava/util/Map;)Lcom/github/catvod/spider/appysv2/c/h;

    invoke-virtual {v3}, Lcom/github/catvod/spider/appysv2/c/h;->o()Ljava/lang/String;

    move-result-object v0

    return-object v0

    :cond_584
    invoke-static {}, Lcom/github/catvod/spider/appysv2/c/h;->e()Lcom/github/catvod/spider/appysv2/c/h;

    move-result-object v0

    invoke-virtual {v0, v2}, Lcom/github/catvod/spider/appysv2/c/h;->y(Ljava/lang/String;)Lcom/github/catvod/spider/appysv2/c/h;

    invoke-virtual {v0}, Lcom/github/catvod/spider/appysv2/c/h;->j()Lcom/github/catvod/spider/appysv2/c/h;

    invoke-virtual {v0, v4}, Lcom/github/catvod/spider/appysv2/c/h;->f(Ljava/util/Map;)Lcom/github/catvod/spider/appysv2/c/h;

    invoke-virtual {v0}, Lcom/github/catvod/spider/appysv2/c/h;->o()Ljava/lang/String;

    move-result-object v0

    return-object v0

    :cond_596
    invoke-static {}, Lcom/github/catvod/spider/appysv2/p/m;->g()Ljava/lang/String;

    move-result-object v6

    invoke-static {v6}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v6

    if-nez v6, :cond_6f1

    array-length v6, v0

    if-le v6, v5, :cond_6d7

    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    invoke-static {}, Lcom/github/catvod/spider/Proxy;->getUrl()Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v7, 0x12

    new-array v9, v7, [B

    const/16 v7, -0x51

    aput-byte v7, v9, v14

    aput-byte v24, v9, v16

    const/16 v7, 0x72

    aput-byte v7, v9, v5

    const/16 v7, -0x17

    aput-byte v7, v9, v3

    aput-byte v39, v9, v15

    const/16 v7, -0x67

    aput-byte v7, v9, v13

    const/16 v7, 0x36

    aput-byte v7, v9, v12

    const/16 v7, -0x47

    aput-byte v7, v9, v11

    const/16 v7, -0x1b

    aput-byte v7, v9, v10

    const/16 v7, 0x7d

    aput-byte v7, v9, v8

    const/16 v7, 0x6b

    const/16 v17, 0xa

    aput-byte v7, v9, v17

    const/16 v7, -0x45

    const/16 v19, 0xb

    aput-byte v7, v9, v19

    const/16 v7, 0xc

    aput-byte v39, v9, v7

    const/16 v7, -0x4a

    const/16 v19, 0xd

    aput-byte v7, v9, v19

    const/16 v7, 0x39

    aput-byte v7, v9, v35

    const/16 v7, -0x47

    const/16 v18, 0xf

    aput-byte v7, v9, v18

    const/16 v7, -0xb

    const/16 v18, 0x10

    aput-byte v7, v9, v18

    const/16 v7, 0x66

    aput-byte v7, v9, v29

    new-array v7, v10, [B

    aput-byte v37, v7, v14

    const/16 v18, 0x5b

    aput-byte v18, v7, v16

    aput-byte v32, v7, v5

    aput-byte v34, v7, v3

    const/16 v18, 0x70

    aput-byte v18, v7, v15

    const/16 v18, -0x8

    aput-byte v18, v7, v13

    const/16 v18, 0x58

    aput-byte v18, v7, v12

    aput-byte v34, v7, v11

    invoke-static {v9, v7}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    aget-object v7, v0, v16

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v7, 0xa

    new-array v7, v7, [B

    const/16 v9, 0x32

    aput-byte v9, v7, v14

    const/16 v9, -0x4c

    aput-byte v9, v7, v16

    const/16 v9, 0x31

    aput-byte v9, v7, v5

    const/16 v9, 0x6d

    aput-byte v9, v7, v3

    const/4 v9, -0x3

    aput-byte v9, v7, v15

    const/16 v9, 0x12

    aput-byte v9, v7, v13

    const/16 v9, -0xc

    aput-byte v9, v7, v12

    aput-byte v22, v7, v11

    const/16 v9, 0x6c

    aput-byte v9, v7, v10

    const/4 v9, -0x1

    aput-byte v9, v7, v8

    new-array v9, v10, [B

    aput-byte v39, v9, v14

    const/16 v17, -0x3e

    aput-byte v17, v9, v16

    const/16 v17, 0x5e

    aput-byte v17, v9, v5

    aput-byte v8, v9, v3

    const/16 v8, -0x4c

    aput-byte v8, v9, v15

    const/16 v8, 0x7c

    aput-byte v8, v9, v13

    aput-byte v37, v9, v12

    const/16 v8, 0x4f

    aput-byte v8, v9, v11

    invoke-static {v7, v9}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    aget-object v0, v0, v5

    invoke-virtual {v6, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    new-array v0, v10, [B

    const/16 v7, -0x80

    aput-byte v7, v0, v14

    const/16 v7, 0x44

    aput-byte v7, v0, v16

    const/16 v7, 0x3c

    aput-byte v7, v0, v5

    const/16 v7, 0x45

    aput-byte v7, v0, v3

    aput-byte v5, v0, v15

    const/16 v7, 0x25

    aput-byte v7, v0, v13

    aput-byte v24, v0, v12

    aput-byte v33, v0, v11

    new-array v7, v10, [B

    const/16 v8, -0x5a

    aput-byte v8, v7, v14

    const/16 v8, 0x32

    aput-byte v8, v7, v16

    const/16 v8, 0x53

    aput-byte v8, v7, v5

    const/16 v5, 0x21

    aput-byte v5, v7, v3

    const/16 v3, 0x57

    aput-byte v3, v7, v15

    const/16 v3, 0x57

    aput-byte v3, v7, v13

    const/16 v3, 0x53

    aput-byte v3, v7, v12

    aput-byte v36, v7, v11

    invoke-static {v0, v7}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v6, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {}, Lcom/github/catvod/spider/appysv2/c/h;->e()Lcom/github/catvod/spider/appysv2/c/h;

    move-result-object v3

    invoke-static {v2}, Lcom/github/catvod/spider/appysv2/p/m;->e(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v3, v2}, Lcom/github/catvod/spider/appysv2/c/h;->y(Ljava/lang/String;)Lcom/github/catvod/spider/appysv2/c/h;

    invoke-virtual {v3, v0}, Lcom/github/catvod/spider/appysv2/c/h;->a(Ljava/lang/String;)Lcom/github/catvod/spider/appysv2/c/h;

    invoke-virtual {v3}, Lcom/github/catvod/spider/appysv2/c/h;->j()Lcom/github/catvod/spider/appysv2/c/h;

    invoke-virtual {v3, v4}, Lcom/github/catvod/spider/appysv2/c/h;->f(Ljava/util/Map;)Lcom/github/catvod/spider/appysv2/c/h;

    invoke-virtual {v3}, Lcom/github/catvod/spider/appysv2/c/h;->o()Ljava/lang/String;

    move-result-object v0

    return-object v0

    :cond_6d7
    invoke-static {}, Lcom/github/catvod/spider/appysv2/c/h;->e()Lcom/github/catvod/spider/appysv2/c/h;

    move-result-object v0

    invoke-static {v2}, Lcom/github/catvod/spider/appysv2/p/m;->e(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Lcom/github/catvod/spider/appysv2/c/h;->y(Ljava/lang/String;)Lcom/github/catvod/spider/appysv2/c/h;

    invoke-virtual {v0}, Lcom/github/catvod/spider/appysv2/c/h;->j()Lcom/github/catvod/spider/appysv2/c/h;

    invoke-virtual {v0, v4}, Lcom/github/catvod/spider/appysv2/c/h;->f(Ljava/util/Map;)Lcom/github/catvod/spider/appysv2/c/h;

    invoke-virtual {v0}, Lcom/github/catvod/spider/appysv2/c/h;->o()Ljava/lang/String;

    move-result-object v0
    :try_end_6ec
    .catch Ljava/lang/Exception; {:try_start_4 .. :try_end_6ec} :catch_6ed

    return-object v0

    :catch_6ed
    move-exception v0

    invoke-virtual {v0}, Ljava/lang/Throwable;->printStackTrace()V

    :cond_6f1
    const-string v0, ""

    return-object v0
.end method
