.class public final synthetic Lcom/github/catvod/spider/appysv2/b/f;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(Ljava/lang/Object;I)V
    .registers 3

    iput p2, p0, Lcom/github/catvod/spider/appysv2/b/f;->a:I

    iput-object p1, p0, Lcom/github/catvod/spider/appysv2/b/f;->b:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 93

    move-object/from16 v0, p0

    iget v1, v0, Lcom/github/catvod/spider/appysv2/b/f;->a:I

    packed-switch v1, :pswitch_data_5b6

    goto/16 :goto_5ad

    :pswitch_9  #0x4
    iget-object v1, v0, Lcom/github/catvod/spider/appysv2/b/f;->b:Ljava/lang/Object;

    check-cast v1, Lcom/github/catvod/spider/JSDemo;

    invoke-static {v1}, Lcom/github/catvod/spider/JSDemo;->a(Lcom/github/catvod/spider/JSDemo;)V

    return-void

    :pswitch_11  #0x3
    iget-object v1, v0, Lcom/github/catvod/spider/appysv2/b/f;->b:Ljava/lang/Object;

    check-cast v1, Lcom/github/catvod/spider/appysv2/b/U;

    invoke-static {v1}, Lcom/github/catvod/spider/appysv2/b/U;->c(Lcom/github/catvod/spider/appysv2/b/U;)V

    return-void

    :pswitch_19  #0x2
    iget-object v1, v0, Lcom/github/catvod/spider/appysv2/b/f;->b:Ljava/lang/Object;

    check-cast v1, Lcom/github/catvod/spider/appysv2/b/M;

    sget v2, Lcom/github/catvod/spider/appysv2/b/M;->k:I

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v2, 0x48

    :try_start_24
    new-array v2, v2, [B

    const/4 v3, 0x0

    const/16 v4, 0x14

    aput-byte v4, v2, v3

    const/4 v5, 0x1

    const/16 v6, -0x71

    aput-byte v6, v2, v5

    const/4 v7, 0x2

    const/16 v8, -0x40

    aput-byte v8, v2, v7

    const/4 v9, 0x3

    const/16 v10, 0xe

    aput-byte v10, v2, v9

    const/4 v11, 0x4

    const/16 v12, -0x4d

    aput-byte v12, v2, v11

    const/4 v13, 0x5

    const/16 v14, 0x5f

    aput-byte v14, v2, v13

    const/16 v15, -0x31

    const/16 v16, 0x6

    aput-byte v15, v2, v16

    const/4 v15, 0x7

    const/16 v17, 0x2a

    aput-byte v17, v2, v15

    const/16 v6, 0x8

    const/16 v19, 0x9

    aput-byte v19, v2, v6

    const/16 v20, -0x6c

    aput-byte v20, v2, v19

    const/16 v20, -0x3c

    const/16 v21, 0xa

    aput-byte v20, v2, v21

    const/16 v20, 0x50

    const/16 v22, 0xb

    aput-byte v20, v2, v22

    const/16 v23, -0x4f

    const/16 v24, 0xc

    aput-byte v23, v2, v24

    const/16 v23, 0xd

    const/16 v25, 0x10

    aput-byte v25, v2, v23

    const/16 v26, -0x7f

    aput-byte v26, v2, v10

    const/16 v26, 0x77

    const/16 v27, 0xf

    aput-byte v26, v2, v27

    const/16 v26, 0x17

    aput-byte v26, v2, v25

    const/16 v28, -0x2b

    const/16 v29, 0x11

    aput-byte v28, v2, v29

    const/16 v30, -0x29

    const/16 v31, 0x12

    aput-byte v30, v2, v31

    const/16 v32, 0x13

    aput-byte v25, v2, v32

    const/16 v33, -0x11

    aput-byte v33, v2, v4

    const/16 v33, 0x15

    aput-byte v16, v2, v33

    const/16 v34, -0x7f

    const/16 v35, 0x16

    aput-byte v34, v2, v35

    const/16 v34, 0x76

    aput-byte v34, v2, v26

    const/16 v34, 0x53

    const/16 v36, 0x18

    aput-byte v34, v2, v36

    const/16 v34, -0x66

    const/16 v37, 0x19

    aput-byte v34, v2, v37

    const/16 v34, -0x22

    const/16 v38, 0x1a

    aput-byte v34, v2, v38

    const/16 v34, 0x1f

    const/16 v39, 0x1b

    aput-byte v34, v2, v39

    const/16 v40, -0x48

    const/16 v41, 0x1c

    aput-byte v40, v2, v41

    const/16 v40, 0x4a

    const/16 v42, 0x1d

    aput-byte v40, v2, v42

    const/16 v40, -0x79

    const/16 v43, 0x1e

    aput-byte v40, v2, v43

    const/16 v40, 0x60

    aput-byte v40, v2, v34

    const/16 v40, 0x20

    aput-byte v6, v2, v40

    const/16 v44, 0x21

    const/16 v45, -0x51

    aput-byte v45, v2, v44

    const/16 v46, -0x25

    const/16 v14, 0x22

    aput-byte v46, v2, v14

    const/16 v46, 0x23

    aput-byte v33, v2, v46

    const/16 v48, 0x24

    const/16 v49, -0x5b

    aput-byte v49, v2, v48

    const/16 v48, 0x25

    aput-byte v22, v2, v48

    const/16 v50, -0x5a

    const/16 v51, 0x26

    aput-byte v50, v2, v51

    const/16 v52, 0x27

    const/16 v53, 0x6a

    aput-byte v53, v2, v52

    const/16 v52, 0x28

    aput-byte v10, v2, v52

    const/16 v53, 0x29

    const/16 v54, -0x56

    aput-byte v54, v2, v53

    const/16 v53, -0x3a

    aput-byte v53, v2, v17

    const/16 v54, 0x2b

    aput-byte v42, v2, v54

    const/16 v55, 0x2c

    aput-byte v45, v2, v55

    const/16 v56, 0x2d

    aput-byte v5, v2, v56

    const/16 v56, -0x7b

    const/16 v57, 0x2e

    aput-byte v56, v2, v57

    const/16 v56, 0x2f

    const/16 v58, 0x49

    aput-byte v58, v2, v56

    const/16 v56, 0x30

    aput-byte v32, v2, v56

    const/16 v58, -0x64

    const/16 v59, 0x31

    aput-byte v58, v2, v59

    const/16 v60, 0x32

    const/16 v61, -0x23

    aput-byte v61, v2, v60

    const/16 v60, 0x33

    aput-byte v25, v2, v60

    const/16 v60, -0x1

    const/16 v61, 0x34

    aput-byte v60, v2, v61

    const/16 v60, 0x35

    aput-byte v16, v2, v60

    const/16 v60, -0x74

    const/16 v62, 0x36

    aput-byte v60, v2, v62

    const/16 v60, 0x6c

    const/16 v63, 0x37

    aput-byte v60, v2, v63

    const/16 v60, 0x38

    aput-byte v37, v2, v60

    const/16 v64, -0x6b

    const/16 v65, 0x39

    aput-byte v64, v2, v65

    const/16 v64, 0x3a

    aput-byte v8, v2, v64

    const/16 v64, 0x3b

    aput-byte v44, v2, v64

    const/16 v66, 0x3c

    const/16 v67, -0x57

    aput-byte v67, v2, v66

    const/16 v66, 0x3d

    aput-byte v5, v2, v66

    const/16 v66, -0x23

    const/16 v67, 0x3e

    aput-byte v66, v2, v67

    const/16 v66, 0x3f

    aput-byte v56, v2, v66

    const/16 v68, 0x4f

    const/16 v69, 0x40

    aput-byte v68, v2, v69

    const/16 v68, -0x37

    const/16 v70, 0x41

    aput-byte v68, v2, v70

    const/16 v71, -0x6e

    const/16 v72, 0x42

    aput-byte v71, v2, v72

    const/16 v71, 0x43

    aput-byte v6, v2, v71

    const/16 v71, 0x44

    const/16 v73, -0x3

    aput-byte v73, v2, v71

    const/16 v71, 0x54

    const/16 v74, 0x45

    aput-byte v71, v2, v74

    const/16 v75, -0x32

    const/16 v76, 0x46

    aput-byte v75, v2, v76

    const/16 v75, 0x47

    aput-byte v63, v2, v75

    new-array v10, v6, [B

    const/16 v78, 0x7c

    aput-byte v78, v10, v3

    const/16 v78, -0x5

    aput-byte v78, v10, v5

    const/16 v78, -0x4c

    aput-byte v78, v10, v7

    const/16 v79, 0x7e

    aput-byte v79, v10, v9

    aput-byte v8, v10, v11

    const/16 v8, 0x65

    aput-byte v8, v10, v13

    const/16 v80, -0x20

    aput-byte v80, v10, v16

    aput-byte v13, v10, v15

    .line 1
    invoke-static {v2, v10}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v2

    new-instance v10, Lorg/json/JSONObject;

    const/4 v14, 0x0

    .line 2
    invoke-static {v2, v14}, Lcom/github/catvod/spider/appysv2/n/c;->m(Ljava/lang/String;Ljava/util/Map;)Ljava/lang/String;

    move-result-object v2

    .line 3
    invoke-direct {v10, v2}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    new-array v2, v11, [B

    const/16 v14, -0x39

    aput-byte v14, v2, v3

    const/16 v81, -0x2e

    aput-byte v81, v2, v5

    aput-byte v72, v2, v7

    const/16 v82, -0x74

    aput-byte v82, v2, v9

    new-array v14, v6, [B

    const/16 v83, -0x5d

    aput-byte v83, v14, v3

    aput-byte v12, v14, v5

    aput-byte v62, v14, v7

    const/16 v83, -0x13

    aput-byte v83, v14, v9

    const/16 v84, 0x52

    aput-byte v84, v14, v11

    aput-byte v64, v14, v13

    const/16 v84, -0x60

    aput-byte v84, v14, v16

    aput-byte v20, v14, v15

    invoke-static {v2, v14}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v10, v2}, Lorg/json/JSONObject;->optJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v2

    new-array v10, v15, [B

    const/16 v14, -0x28

    aput-byte v14, v10, v3

    aput-byte v4, v10, v5

    aput-byte v79, v10, v7

    const/16 v84, -0x1e

    aput-byte v84, v10, v9

    const/16 v84, 0x4d

    aput-byte v84, v10, v11

    const/16 v85, -0x5c

    aput-byte v85, v10, v13

    aput-byte v55, v10, v16

    new-array v14, v6, [B

    const/16 v86, -0x4b

    aput-byte v86, v14, v3

    const/16 v86, 0x71

    aput-byte v86, v14, v5

    aput-byte v32, v14, v7

    const/16 v86, -0x80

    aput-byte v86, v14, v9

    aput-byte v52, v14, v11

    const/16 v86, -0x2a

    aput-byte v86, v14, v13

    const/16 v47, 0x5f

    aput-byte v47, v14, v16

    aput-byte v27, v14, v15

    invoke-static {v10, v14}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v2, v10}, Lorg/json/JSONObject;->optJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v2

    new-array v10, v13, [B

    const/16 v14, -0x65

    aput-byte v14, v10, v3

    aput-byte v68, v10, v5

    const/16 v14, -0x7d

    aput-byte v14, v10, v7

    const/16 v14, -0x4a

    aput-byte v14, v10, v9

    const/4 v14, -0x2

    aput-byte v14, v10, v11

    new-array v14, v6, [B

    const/16 v87, -0x11

    aput-byte v87, v14, v3

    aput-byte v50, v14, v5

    const/16 v87, -0x18

    aput-byte v87, v14, v7

    const/16 v87, -0x2d

    aput-byte v87, v14, v9

    const/16 v88, -0x70

    aput-byte v88, v14, v11

    aput-byte v8, v14, v13

    aput-byte v74, v14, v16

    aput-byte v84, v14, v15

    invoke-static {v10, v14}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v2, v10}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    new-instance v10, Ljava/lang/StringBuilder;

    invoke-direct {v10}, Ljava/lang/StringBuilder;-><init>()V

    const/16 v14, 0x22

    new-array v12, v14, [B

    aput-byte v67, v12, v3

    const/16 v14, -0x4f

    aput-byte v14, v12, v5

    const/16 v14, 0x7f

    aput-byte v14, v12, v7

    const/16 v89, -0x77

    aput-byte v89, v12, v9

    const/16 v89, 0x6f

    aput-byte v89, v12, v11

    aput-byte v58, v12, v13

    aput-byte v81, v12, v16

    const/16 v89, -0x5f

    aput-byte v89, v12, v15

    aput-byte v48, v12, v6

    const/16 v90, -0x50

    aput-byte v90, v12, v19

    aput-byte v48, v12, v21

    const/16 v90, -0x78

    aput-byte v90, v12, v22

    const/16 v90, 0x69

    aput-byte v90, v12, v24

    const/16 v82, -0x39

    aput-byte v82, v12, v23

    const/16 v18, 0xe

    const/16 v77, -0x71

    aput-byte v77, v12, v18

    const/16 v90, -0x1b

    aput-byte v90, v12, v27

    const/16 v90, 0x78

    aput-byte v90, v12, v25

    aput-byte v50, v12, v29

    aput-byte v8, v12, v31

    aput-byte v86, v12, v32

    aput-byte v52, v12, v4

    const/4 v8, -0x7

    aput-byte v8, v12, v33

    const/16 v8, -0x68

    aput-byte v8, v12, v35

    const/16 v8, -0x3d

    aput-byte v8, v12, v26

    aput-byte v43, v12, v36

    const/16 v8, -0x79

    aput-byte v8, v12, v37

    aput-byte v70, v12, v38

    aput-byte v53, v12, v39

    const/16 v8, 0x68

    aput-byte v8, v12, v41

    aput-byte v68, v12, v42

    const/16 v8, -0x6a

    aput-byte v8, v12, v43

    const/16 v8, -0x15

    aput-byte v8, v12, v34

    aput-byte v60, v12, v40

    const/4 v8, -0x8

    aput-byte v8, v12, v44

    new-array v8, v6, [B

    const/16 v90, 0x56

    aput-byte v90, v8, v3

    const/16 v90, -0x3b

    aput-byte v90, v8, v5

    aput-byte v22, v8, v7

    const/16 v91, -0x7

    aput-byte v91, v8, v9

    aput-byte v41, v8, v11

    aput-byte v50, v8, v13

    aput-byte v73, v8, v16

    const/16 v91, -0x72

    aput-byte v91, v8, v15

    invoke-static {v12, v8}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v10, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v10, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v8, 0x82

    new-array v8, v8, [B

    aput-byte v78, v8, v3

    const/16 v12, -0x19

    aput-byte v12, v8, v5

    const/16 v12, -0x10

    aput-byte v12, v8, v7

    aput-byte v39, v8, v9

    const/16 v91, -0x4

    aput-byte v91, v8, v11

    const/16 v91, -0x45

    aput-byte v91, v8, v13

    const/16 v91, 0x66

    aput-byte v91, v8, v16

    aput-byte v68, v8, v15

    const/16 v68, -0x5

    aput-byte v68, v8, v6

    const/16 v68, -0x20

    aput-byte v68, v8, v19

    aput-byte v89, v8, v21

    aput-byte v75, v8, v22

    const/16 v19, -0x56

    aput-byte v19, v8, v24

    const/16 v19, -0x19

    aput-byte v19, v8, v23

    const/16 v19, 0xe

    aput-byte v61, v8, v19

    const/16 v19, -0x1b

    aput-byte v19, v8, v27

    const/16 v19, -0x1f

    aput-byte v19, v8, v25

    const/16 v19, -0x1a

    aput-byte v19, v8, v29

    aput-byte v89, v8, v31

    aput-byte v13, v8, v32

    const/16 v19, -0x4

    aput-byte v19, v8, v4

    const/16 v19, -0x49

    aput-byte v19, v8, v33

    aput-byte v79, v8, v35

    const/16 v19, -0x7

    aput-byte v19, v8, v26

    const/16 v19, -0xb

    aput-byte v19, v8, v36

    aput-byte v83, v8, v37

    const/16 v19, -0xe

    aput-byte v19, v8, v38

    aput-byte v71, v8, v39

    const/16 v19, -0x14

    aput-byte v19, v8, v41

    const/16 v19, -0x4a

    aput-byte v19, v8, v42

    aput-byte v84, v8, v43

    const/16 v19, -0x1a

    aput-byte v19, v8, v34

    const/16 v19, -0xd

    aput-byte v19, v8, v40

    const/16 v19, -0xa

    aput-byte v19, v8, v44

    const/16 v19, 0x22

    aput-byte v73, v8, v19

    aput-byte v34, v8, v46

    const/16 v19, 0x24

    aput-byte v53, v8, v19

    aput-byte v50, v8, v48

    aput-byte v91, v8, v51

    const/16 v19, 0x27

    const/16 v21, -0x1c

    aput-byte v21, v8, v19

    aput-byte v45, v8, v52

    const/16 v19, 0x29

    const/16 v21, -0x5e

    aput-byte v21, v8, v19

    const/16 v19, -0x17

    aput-byte v19, v8, v17

    aput-byte v29, v8, v54

    aput-byte v53, v8, v55

    const/16 v17, 0x2d

    const/16 v19, -0x49

    aput-byte v19, v8, v17

    const/16 v17, 0x7b

    aput-byte v17, v8, v57

    const/16 v17, 0x2f

    const/16 v19, -0x14

    aput-byte v19, v8, v17

    const/16 v17, -0x33

    aput-byte v17, v8, v56

    const/16 v19, -0x9

    aput-byte v19, v8, v59

    const/16 v19, 0x32

    const/16 v22, -0x18

    aput-byte v22, v8, v19

    const/16 v19, 0x33

    aput-byte v3, v8, v19

    aput-byte v85, v8, v61

    const/16 v19, 0x35

    const/16 v22, -0x7a

    aput-byte v22, v8, v19

    aput-byte v63, v8, v62

    aput-byte v49, v8, v63

    aput-byte v87, v8, v60

    const/16 v19, -0x19

    aput-byte v19, v8, v65

    const/16 v19, 0x3a

    const/16 v22, -0x17

    aput-byte v22, v8, v19

    aput-byte v5, v8, v64

    const/16 v19, 0x3c

    aput-byte v83, v8, v19

    const/16 v19, 0x3d

    const/16 v22, -0x46

    aput-byte v22, v8, v19

    aput-byte v14, v8, v67

    const/16 v19, -0x4d

    aput-byte v19, v8, v66

    aput-byte v49, v8, v69

    const/16 v19, -0x39

    aput-byte v19, v8, v70

    aput-byte v87, v8, v72

    const/16 v19, 0x43

    const/16 v22, 0x22

    aput-byte v22, v8, v19

    const/16 v19, 0x44

    aput-byte v17, v8, v19

    aput-byte v12, v8, v74

    aput-byte v44, v8, v76

    aput-byte v30, v8, v75

    const/16 v19, 0x48

    const/16 v22, -0x3f

    aput-byte v22, v8, v19

    const/16 v19, 0x49

    aput-byte v90, v8, v19

    const/16 v19, 0x4a

    const/16 v22, -0x32

    aput-byte v22, v8, v19

    const/16 v19, 0x4b

    aput-byte v63, v8, v19

    const/16 v19, 0x4c

    const/16 v22, -0x28

    aput-byte v22, v8, v19

    aput-byte v12, v8, v84

    const/16 v19, 0x4e

    aput-byte v51, v8, v19

    const/16 v19, 0x4f

    aput-byte v50, v8, v19

    aput-byte v21, v8, v20

    const/16 v19, 0x51

    aput-byte v89, v8, v19

    const/16 v19, 0x52

    const/16 v20, -0x55

    aput-byte v20, v8, v19

    const/16 v19, 0x53

    aput-byte v59, v8, v19

    aput-byte v86, v8, v71

    const/16 v19, 0x55

    const/16 v20, -0x7b

    aput-byte v20, v8, v19

    const/16 v19, 0x56

    aput-byte v76, v8, v19

    const/16 v19, 0x57

    const/16 v20, -0x4d

    aput-byte v20, v8, v19

    const/16 v19, 0x58

    aput-byte v89, v8, v19

    const/16 v19, 0x59

    aput-byte v90, v8, v19

    const/16 v19, 0x5a

    aput-byte v28, v8, v19

    const/16 v19, 0x5b

    aput-byte v66, v8, v19

    const/16 v19, 0x5c

    const/16 v20, -0x2c

    aput-byte v20, v8, v19

    const/16 v19, 0x5d

    const/16 v20, -0x70

    aput-byte v20, v8, v19

    const/16 v19, 0x5e

    aput-byte v69, v8, v19

    const/16 v19, 0x5f

    aput-byte v90, v8, v19

    const/16 v19, 0x60

    const/16 v20, -0x25

    aput-byte v20, v8, v19

    const/16 v19, 0x61

    aput-byte v81, v8, v19

    const/16 v19, 0x62

    const/16 v20, -0x27

    aput-byte v20, v8, v19

    const/16 v19, 0x63

    const/16 v20, 0x57

    aput-byte v20, v8, v19

    const/16 v19, 0x64

    const/16 v20, -0x53

    aput-byte v20, v8, v19

    const/16 v19, -0x1b

    const/16 v20, 0x65

    aput-byte v19, v8, v20

    aput-byte v46, v8, v91

    const/16 v19, 0x67

    const/16 v20, -0x4d

    aput-byte v20, v8, v19

    const/16 v19, 0x68

    aput-byte v49, v8, v19

    const/16 v19, 0x69

    const/16 v20, -0x39

    aput-byte v20, v8, v19

    const/16 v19, 0x6a

    aput-byte v87, v8, v19

    const/16 v19, 0x6b

    const/16 v20, 0x22

    aput-byte v20, v8, v19

    const/16 v19, 0x6c

    aput-byte v17, v8, v19

    const/16 v19, 0x6d

    aput-byte v12, v8, v19

    const/16 v12, 0x6e

    aput-byte v44, v8, v12

    const/16 v12, 0x6f

    aput-byte v30, v8, v12

    const/16 v12, 0x70

    const/16 v19, -0x30

    aput-byte v19, v8, v12

    const/16 v12, 0x71

    aput-byte v90, v8, v12

    const/16 v12, 0x72

    const/16 v19, -0x21

    aput-byte v19, v8, v12

    const/16 v12, 0x73

    aput-byte v65, v8, v12

    const/16 v12, 0x74

    aput-byte v53, v8, v12

    const/16 v12, 0x75

    const/16 v19, -0x69

    aput-byte v19, v8, v12

    const/16 v12, 0x76

    aput-byte v76, v8, v12

    const/16 v12, 0x77

    const/16 v19, -0x28

    aput-byte v19, v8, v12

    const/16 v12, 0x78

    aput-byte v17, v8, v12

    const/16 v12, 0x79

    aput-byte v30, v8, v12

    const/16 v12, 0x7a

    const/16 v19, -0x38

    aput-byte v19, v8, v12

    const/16 v12, 0x7b

    aput-byte v54, v8, v12

    const/16 v12, 0x7c

    aput-byte v28, v8, v12

    const/16 v12, 0x7d

    const/16 v19, -0x70

    aput-byte v19, v8, v12

    aput-byte v63, v8, v79

    aput-byte v21, v8, v14

    const/16 v12, 0x80

    aput-byte v21, v8, v12

    const/16 v12, 0x81

    aput-byte v78, v8, v12

    new-array v12, v6, [B

    const/16 v19, -0x6e

    aput-byte v19, v12, v3

    const/16 v19, -0x7c

    aput-byte v19, v12, v5

    aput-byte v58, v12, v7

    const/16 v19, 0x72

    aput-byte v19, v12, v9

    const/16 v19, -0x67

    aput-byte v19, v12, v11

    aput-byte v28, v12, v13

    aput-byte v31, v12, v16

    const/16 v19, -0x6a

    aput-byte v19, v12, v15

    invoke-static {v8, v12}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v10, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v10}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v8

    new-instance v10, Lorg/json/JSONObject;

    invoke-direct {v10}, Lorg/json/JSONObject;-><init>()V

    new-array v12, v9, [B

    const/16 v19, 0x6b

    aput-byte v19, v12, v3

    aput-byte v4, v12, v5

    const/16 v4, -0x2f

    aput-byte v4, v12, v7

    new-array v4, v6, [B

    aput-byte v43, v4, v3

    aput-byte v91, v4, v5

    const/16 v19, -0x43

    aput-byte v19, v4, v7

    const/16 v19, 0x70

    aput-byte v19, v4, v9

    aput-byte v43, v4, v11

    aput-byte v57, v4, v13

    const/16 v19, -0x65

    aput-byte v19, v4, v16

    const/16 v19, -0x12

    aput-byte v19, v4, v15

    invoke-static {v12, v4}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v10, v4, v8}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    new-array v4, v13, [B

    const/4 v8, -0x4

    aput-byte v8, v4, v3

    aput-byte v21, v4, v5

    aput-byte v85, v4, v7

    aput-byte v85, v4, v9

    const/16 v8, -0x7a

    aput-byte v8, v4, v11

    new-array v6, v6, [B

    const/16 v8, -0x78

    aput-byte v8, v6, v3

    aput-byte v17, v6, v5

    const/16 v3, -0x31

    aput-byte v3, v6, v7

    const/16 v3, -0x3f

    aput-byte v3, v6, v9

    const/16 v3, -0x18

    aput-byte v3, v6, v11

    const/16 v3, -0x71

    aput-byte v3, v6, v13

    aput-byte v58, v6, v16

    aput-byte v14, v6, v15

    invoke-static {v4, v6}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v10, v3, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    new-instance v2, Lcom/github/catvod/spider/appysv2/b/j;

    invoke-direct {v2, v1, v10, v5}, Lcom/github/catvod/spider/appysv2/b/j;-><init>(Ljava/lang/Object;Ljava/lang/Object;I)V

    invoke-static {v2}, Lcom/github/catvod/spider/Init;->run(Ljava/lang/Runnable;)V
    :try_end_59c
    .catch Ljava/lang/Exception; {:try_start_24 .. :try_end_59c} :catch_59c

    :catch_59c
    return-void

    .line 4
    :pswitch_59d  #0x1
    iget-object v1, v0, Lcom/github/catvod/spider/appysv2/b/f;->b:Ljava/lang/Object;

    check-cast v1, Lcom/github/catvod/spider/appysv2/b/F;

    invoke-virtual {v1}, Lcom/github/catvod/spider/appysv2/b/F;->s()V

    return-void

    :pswitch_5a5  #0x0
    iget-object v1, v0, Lcom/github/catvod/spider/appysv2/b/f;->b:Ljava/lang/Object;

    check-cast v1, Lcom/github/catvod/spider/appysv2/b/x;

    invoke-static {v1}, Lcom/github/catvod/spider/appysv2/b/x;->b(Lcom/github/catvod/spider/appysv2/b/x;)V

    return-void

    :goto_5ad
    iget-object v1, v0, Lcom/github/catvod/spider/appysv2/b/f;->b:Ljava/lang/Object;

    check-cast v1, Lcom/github/catvod/spider/appysv2/p/B;

    invoke-static {v1}, Lcom/github/catvod/spider/appysv2/p/B;->e(Lcom/github/catvod/spider/appysv2/p/B;)V

    return-void

    nop

    :pswitch_data_5b6
    .packed-switch 0x0
        :pswitch_5a5  #00000000
        :pswitch_59d  #00000001
        :pswitch_19  #00000002
        :pswitch_11  #00000003
        :pswitch_9  #00000004
    .end packed-switch
.end method
