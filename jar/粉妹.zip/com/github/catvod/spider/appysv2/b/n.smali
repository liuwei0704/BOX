.class public final synthetic Lcom/github/catvod/spider/appysv2/b/n;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/content/DialogInterface$OnClickListener;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Ljava/lang/Object;

.field public final synthetic c:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(Ljava/lang/Object;Ljava/lang/Object;I)V
    .registers 4

    iput p3, p0, Lcom/github/catvod/spider/appysv2/b/n;->a:I

    iput-object p1, p0, Lcom/github/catvod/spider/appysv2/b/n;->b:Ljava/lang/Object;

    iput-object p2, p0, Lcom/github/catvod/spider/appysv2/b/n;->c:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/content/DialogInterface;I)V
    .registers 6

    iget p1, p0, Lcom/github/catvod/spider/appysv2/b/n;->a:I

    packed-switch p1, :pswitch_data_60

    goto :goto_12

    :pswitch_6  #0x0
    iget-object p1, p0, Lcom/github/catvod/spider/appysv2/b/n;->b:Ljava/lang/Object;

    check-cast p1, Lcom/github/catvod/spider/appysv2/b/x;

    iget-object p2, p0, Lcom/github/catvod/spider/appysv2/b/n;->c:Ljava/lang/Object;

    check-cast p2, Landroid/widget/EditText;

    invoke-static {p1, p2}, Lcom/github/catvod/spider/appysv2/b/x;->h(Lcom/github/catvod/spider/appysv2/b/x;Landroid/widget/EditText;)V

    return-void

    :goto_12
    iget-object p1, p0, Lcom/github/catvod/spider/appysv2/b/n;->b:Ljava/lang/Object;

    check-cast p1, Lcom/github/catvod/spider/appysv2/p/B;

    iget-object p2, p0, Lcom/github/catvod/spider/appysv2/b/n;->c:Ljava/lang/Object;

    check-cast p2, Ljava/util/Map;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v0, 0x5

    new-array v0, v0, [B

    fill-array-data v0, :array_66

    const/16 v1, 0x8

    new-array v2, v1, [B

    fill-array-data v2, :array_6e

    invoke-static {v0, v2}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v0

    const-string v2, ""

    invoke-interface {p2, v0, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v0, 0x4

    new-array v0, v0, [B

    fill-array-data v0, :array_76

    new-array v2, v1, [B

    fill-array-data v2, :array_7c

    invoke-static {v0, v2}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v0

    const/16 v2, 0x1e

    new-array v2, v2, [B

    fill-array-data v2, :array_84

    new-array v1, v1, [B

    fill-array-data v1, :array_98

    invoke-static {v2, v1}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-interface {p2, v0, v1}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    new-instance v0, Lcom/github/catvod/spider/appysv2/p/y;

    const/4 v1, 0x1

    invoke-direct {v0, p1, p2, v1}, Lcom/github/catvod/spider/appysv2/p/y;-><init>(Lcom/github/catvod/spider/appysv2/p/B;Ljava/util/Map;I)V

    invoke-static {v0}, Lcom/github/catvod/spider/Init;->execute(Ljava/lang/Runnable;)V

    return-void

    nop

    :pswitch_data_60
    .packed-switch 0x0
        :pswitch_6  #00000000
    .end packed-switch

    :array_66
    .array-data 1
        0x4t
        0x46t
        -0x13t
        -0x29t
        0x5t
    .end array-data

    nop

    :array_6e
    .array-data 1
        0x69t
        0x29t
        -0x77t
        -0x4et
        0x69t
        0x7ft
        0x59t
        -0x4t
    .end array-data

    :array_76
    .array-data 1
        -0x6ct
        -0x28t
        0x40t
        -0x17t
    .end array-data

    :array_7c
    .array-data 1
        -0xet
        -0x4ct
        0x21t
        -0x72t
        -0x22t
        0x4ft
        0x11t
        0x7et
    .end array-data

    :array_84
    .array-data 1
        -0x7at
        -0xat
        0x64t
        0x19t
        -0x29t
        -0x1dt
        0x41t
        0x13t
        -0x35t
        0x68t
        -0x1ft
        -0x3et
        -0x73t
        -0x36t
        0x35t
        0x71t
        -0xbt
        -0x3ft
        0x3bt
        0x45t
        -0x31t
        -0x6bt
        0x2bt
        0x21t
        -0x75t
        -0xat
        0x55t
        0x16t
        -0x37t
        -0xft
    .end array-data

    nop

    :array_98
    .array-data 1
        0x6et
        0x59t
        -0x2dt
        -0xft
        0x69t
        0x70t
        -0x5ct
        -0x6at
    .end array-data
.end method
