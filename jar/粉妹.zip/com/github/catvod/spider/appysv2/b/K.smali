.class public final synthetic Lcom/github/catvod/spider/appysv2/b/K;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Ljava/lang/Object;

.field public final synthetic c:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(Ljava/lang/Object;Ljava/lang/Object;I)V
    .registers 4

    iput p3, p0, Lcom/github/catvod/spider/appysv2/b/K;->a:I

    iput-object p1, p0, Lcom/github/catvod/spider/appysv2/b/K;->b:Ljava/lang/Object;

    iput-object p2, p0, Lcom/github/catvod/spider/appysv2/b/K;->c:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 5

    iget v0, p0, Lcom/github/catvod/spider/appysv2/b/K;->a:I

    packed-switch v0, :pswitch_data_56

    goto :goto_49

    :pswitch_6  #0x2
    iget-object v0, p0, Lcom/github/catvod/spider/appysv2/b/K;->b:Ljava/lang/Object;

    check-cast v0, Lcom/github/catvod/spider/appysv2/p/h;

    iget-object v1, p0, Lcom/github/catvod/spider/appysv2/b/K;->c:Ljava/lang/Object;

    check-cast v1, Ljava/io/PipedOutputStream;

    invoke-static {v0, v1}, Lcom/github/catvod/spider/appysv2/p/h;->a(Lcom/github/catvod/spider/appysv2/p/h;Ljava/io/PipedOutputStream;)V

    return-void

    :pswitch_12  #0x1
    iget-object v0, p0, Lcom/github/catvod/spider/appysv2/b/K;->b:Ljava/lang/Object;

    check-cast v0, Lcom/github/catvod/spider/appysv2/b/U;

    iget-object v1, p0, Lcom/github/catvod/spider/appysv2/b/K;->c:Ljava/lang/Object;

    check-cast v1, Lorg/json/JSONObject;

    invoke-static {v0, v1}, Lcom/github/catvod/spider/appysv2/b/U;->l(Lcom/github/catvod/spider/appysv2/b/U;Lorg/json/JSONObject;)V

    return-void

    :pswitch_1e  #0x0
    iget-object v0, p0, Lcom/github/catvod/spider/appysv2/b/K;->b:Ljava/lang/Object;

    check-cast v0, Lcom/github/catvod/spider/appysv2/b/M;

    iget-object v1, p0, Lcom/github/catvod/spider/appysv2/b/K;->c:Ljava/lang/Object;

    check-cast v1, Ljava/lang/String;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v2, 0x4

    new-array v2, v2, [B

    .line 1
    fill-array-data v2, :array_60

    const/16 v3, 0x8

    new-array v3, v3, [B

    fill-array-data v3, :array_66

    invoke-static {v2, v3}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_45

    const/4 v2, 0x0

    .line 2
    invoke-static {v1, v2}, Lcom/github/catvod/spider/appysv2/n/c;->m(Ljava/lang/String;Ljava/util/Map;)Ljava/lang/String;

    move-result-object v1

    .line 3
    :cond_45
    invoke-virtual {v0, v1}, Lcom/github/catvod/spider/appysv2/b/M;->L(Ljava/lang/String;)V

    return-void

    .line 4
    :goto_49
    iget-object v0, p0, Lcom/github/catvod/spider/appysv2/b/K;->b:Ljava/lang/Object;

    check-cast v0, Lcom/github/catvod/spider/appysv2/p/B;

    iget-object v1, p0, Lcom/github/catvod/spider/appysv2/b/K;->c:Ljava/lang/Object;

    check-cast v1, Ljava/util/Map;

    .line 5
    invoke-virtual {v0, v1}, Lcom/github/catvod/spider/appysv2/p/B;->x(Ljava/util/Map;)V

    return-void

    nop

    :pswitch_data_56
    .packed-switch 0x0
        :pswitch_1e  #00000000
        :pswitch_12  #00000001
        :pswitch_6  #00000002
    .end packed-switch

    :array_60
    .array-data 1
        -0x7ft
        -0xat
        0x6dt
        -0x69t
    .end array-data

    :array_66
    .array-data 1
        -0x17t
        -0x7et
        0x19t
        -0x19t
        0x4at
        -0x24t
        0x4dt
        0x10t
    .end array-data
.end method
