.class public final Lcom/github/catvod/spider/appysv2/b/U;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field private static final i:Ljava/lang/String;

.field private static j:Ljava/util/HashMap;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Lcom/github/catvod/spider/appysv2/l/e;",
            ">;"
        }
    .end annotation
.end field


# instance fields
.field private a:Ljava/lang/String;

.field private b:Lorg/json/JSONObject;

.field private c:Ljava/util/concurrent/ScheduledExecutorService;

.field private d:Ljava/lang/String;

.field private e:Lcom/github/catvod/spider/appysv2/l/e;

.field private f:Landroid/app/AlertDialog;

.field private final g:Ljava/util/HashMap;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field h:Ljava/lang/String;


# direct methods
.method static constructor <clinit>()V
    .registers 2

    const/16 v0, 0xbe

    new-array v0, v0, [B

    fill-array-data v0, :array_16

    const/16 v1, 0x8

    new-array v1, v1, [B

    fill-array-data v1, :array_7a

    invoke-static {v0, v1}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lcom/github/catvod/spider/appysv2/b/U;->i:Ljava/lang/String;

    return-void

    nop

    :array_16
    .array-data 1
        0x68t
        0x3bt
        -0x5at
        -0x71t
        -0x30t
        -0x5dt
        -0x5t
        -0x59t
        0x10t
        0x7at
        -0x14t
        -0x3at
        -0x6ct
        -0x68t
        -0xdt
        -0x1at
        0x41t
        0x3bt
        -0x55t
        -0x6bt
        -0x64t
        -0x7ft
        -0x32t
        -0x58t
        0x14t
        0x64t
        -0xet
        -0x2at
        -0x79t
        -0x11t
        -0x33t
        -0x1ft
        0x4bt
        0x62t
        -0x18t
        -0x23t
        -0x64t
        -0x49t
        -0x54t
        -0x44t
        0xct
        0x74t
        -0x63t
        -0x6at
        -0x34t
        -0x5dt
        -0x1t
        -0x21t
        0x40t
        0x36t
        -0x69t
        -0x71t
        -0x38t
        -0x20t
        -0x51t
        -0x45t
        0x12t
        0x7at
        -0x11t
        -0x30t
        -0x64t
        -0x19t
        -0x2ft
        -0x40t
        0x71t
        0x19t
        -0x70t
        -0x36t
        -0x64t
        -0x5dt
        -0xdt
        -0x1dt
        0x40t
        0x74t
        -0x65t
        -0x7dt
        -0x21t
        -0x5ct
        -0xbt
        -0x5ft
        0x5t
        0x21t
        -0x41t
        -0x35t
        -0x21t
        -0x5dt
        -0xbt
        -0x3t
        0x41t
        0x79t
        -0x48t
        -0x6ct
        -0x2bt
        -0x47t
        -0x1t
        -0x59t
        0x14t
        0x7at
        -0x1ct
        -0x38t
        -0x77t
        -0x11t
        -0x27t
        -0x20t
        0x57t
        0x3bt
        -0x4ft
        -0x7dt
        -0x6dt
        -0x2t
        -0x56t
        -0x48t
        0xbt
        0x64t
        -0xet
        -0x2et
        -0x7ct
        -0xat
        -0x54t
        -0x5at
        0x14t
        0x62t
        -0x14t
        -0x3at
        -0x7t
        -0x5dt
        -0x1t
        -0x15t
        0x51t
        0x26t
        -0x4dt
        -0x78t
        -0x6dt
        -0x2t
        -0x5et
        -0x5at
        0x16t
        0x7at
        -0x17t
        -0x38t
        -0x73t
        -0x7t
        -0x49t
        -0x16t
        0x13t
        0x66t
        -0x41t
        -0x80t
        -0x7bt
        -0x54t
        -0x51t
        -0x48t
        0x41t
        0x74t
        -0x71t
        -0x79t
        -0x26t
        -0x52t
        -0x18t
        -0x1ft
        0xat
        0x61t
        -0x11t
        -0x2ft
        -0x6et
        -0x4t
        -0x54t
        -0x58t
        0x66t
        0x3ct
        -0x43t
        -0x78t
        -0x2et
        -0x56t
        -0xat
        -0x59t
        0x50t
        0x37t
        -0x54t
        -0x79t
        -0x2et
        -0x70t
        -0xbt
        -0x4t
        0x4dt
        0x31t
        -0x52t
        -0x47t
        -0x21t
        -0x59t
    .end array-data

    nop

    :array_7a
    .array-data 1
        0x25t
        0x54t
        -0x24t
        -0x1at
        -0x44t
        -0x31t
        -0x66t
        -0x78t
    .end array-data
.end method

.method constructor <init>()V
    .registers 7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    invoke-static {}, Lcom/github/catvod/spider/Init;->checkPermission()V

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    new-instance v0, Ljava/util/HashMap;

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    iput-object v0, p0, Lcom/github/catvod/spider/appysv2/b/U;->g:Ljava/util/HashMap;

    const/4 v1, 0x2

    new-array v2, v1, [B

    fill-array-data v2, :array_f2

    const/16 v3, 0x8

    new-array v4, v3, [B

    fill-array-data v4, :array_f8

    invoke-static {v2, v4}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v2

    new-array v4, v1, [B

    fill-array-data v4, :array_100

    new-array v5, v3, [B

    fill-array-data v5, :array_106

    invoke-static {v4, v5}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v0, v2, v4}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    new-array v2, v1, [B

    fill-array-data v2, :array_10e

    new-array v4, v3, [B

    fill-array-data v4, :array_114

    invoke-static {v2, v4}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v2

    new-array v1, v1, [B

    fill-array-data v1, :array_11c

    new-array v4, v3, [B

    fill-array-data v4, :array_122

    invoke-static {v1, v4}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v2, v1}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v1, 0x5

    new-array v1, v1, [B

    fill-array-data v1, :array_12a

    new-array v2, v3, [B

    fill-array-data v2, :array_132

    invoke-static {v1, v2}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v1

    const/4 v2, 0x6

    new-array v4, v2, [B

    fill-array-data v4, :array_13a

    new-array v5, v3, [B

    fill-array-data v5, :array_142

    invoke-static {v4, v5}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v0, v1, v4}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v1, 0x4

    new-array v1, v1, [B

    fill-array-data v1, :array_14a

    new-array v4, v3, [B

    fill-array-data v4, :array_150

    invoke-static {v1, v4}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v1

    new-array v4, v2, [B

    fill-array-data v4, :array_158

    new-array v5, v3, [B

    fill-array-data v5, :array_160

    invoke-static {v4, v5}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v0, v1, v4}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v1, 0x3

    new-array v1, v1, [B

    fill-array-data v1, :array_168

    new-array v4, v3, [B

    fill-array-data v4, :array_16e

    invoke-static {v1, v4}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v1

    new-array v4, v2, [B

    fill-array-data v4, :array_176

    new-array v5, v3, [B

    fill-array-data v5, :array_17e

    invoke-static {v4, v5}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v0, v1, v4}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    new-array v1, v2, [B

    fill-array-data v1, :array_186

    new-array v4, v3, [B

    fill-array-data v4, :array_18e

    invoke-static {v1, v4}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v1

    new-array v2, v2, [B

    fill-array-data v2, :array_196

    new-array v4, v3, [B

    fill-array-data v4, :array_19e

    invoke-static {v2, v4}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v1, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    new-instance v0, Ljava/util/HashMap;

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    sput-object v0, Lcom/github/catvod/spider/appysv2/b/U;->j:Ljava/util/HashMap;

    invoke-direct {p0}, Lcom/github/catvod/spider/appysv2/b/U;->E()Ljava/lang/String;

    const/16 v0, 0xa

    new-array v0, v0, [B

    fill-array-data v0, :array_1a6

    new-array v1, v3, [B

    fill-array-data v1, :array_1b0

    invoke-static {v0, v1}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lcom/github/catvod/crawler/SpiderDebug;->log(Ljava/lang/String;)V

    return-void

    nop

    :array_f2
    .array-data 1
        -0x64t
        -0x3ft
    .end array-data

    nop

    :array_f8
    .array-data 1
        -0x58t
        -0x56t
        0x46t
        -0x4at
        -0x32t
        0x5ct
        0x33t
        -0x2t
    .end array-data

    :array_100
    .array-data 1
        0x10t
        -0x3dt
    .end array-data

    nop

    :array_106
    .array-data 1
        0x24t
        -0x78t
        0x72t
        -0xct
        -0x53t
        -0x1ft
        0x16t
        0x71t
    .end array-data

    :array_10e
    .array-data 1
        -0x38t
        0x2at
    .end array-data

    nop

    :array_114
    .array-data 1
        -0x6t
        0x41t
        0x6bt
        0x66t
        -0x37t
        -0x70t
        -0x2at
        -0x41t
    .end array-data

    :array_11c
    .array-data 1
        -0x5t
        -0x19t
    .end array-data

    nop

    :array_122
    .array-data 1
        -0x37t
        -0x54t
        0x42t
        0x6dt
        0x6et
        -0x7bt
        0x6ft
        0x1ct
    .end array-data

    :array_12a
    .array-data 1
        -0x5t
        -0x67t
        0x52t
        -0x44t
        0x66t
    .end array-data

    nop

    :array_132
    .array-data 1
        -0x78t
        -0x14t
        0x22t
        -0x27t
        0x14t
        0x48t
        0x10t
        -0x80t
    .end array-data

    :array_13a
    .array-data 1
        -0x70t
        -0x3et
        -0x2dt
        0x54t
        0x30t
        0x50t
    .end array-data

    nop

    :array_142
    .array-data 1
        0x78t
        0x74t
        0x56t
        -0x4et
        -0x78t
        -0x2bt
        -0x15t
        0x40t
    .end array-data

    :array_14a
    .array-data 1
        0x7et
        -0xdt
        -0x6ct
        0x2ft
    .end array-data

    :array_150
    .array-data 1
        0x16t
        -0x66t
        -0xdt
        0x47t
        0x1dt
        0x66t
        -0x1at
        0x67t
    .end array-data

    :array_158
    .array-data 1
        0x51t
        -0x72t
        0x30t
        -0x39t
        0x77t
        -0x3at
    .end array-data

    nop

    :array_160
    .array-data 1
        -0x48t
        0x25t
        -0x58t
        0x21t
        -0x31t
        0x43t
        -0x5t
        0x43t
    .end array-data

    :array_168
    .array-data 1
        0xdt
        0x6ct
        -0x30t
    .end array-data

    :array_16e
    .array-data 1
        0x61t
        0x3t
        -0x59t
        0x6t
        0x28t
        -0xft
        0x4et
        0xft
    .end array-data

    :array_176
    .array-data 1
        0x24t
        0x5t
        -0x23t
        0x53t
        -0x4ct
        -0x2ct
    .end array-data

    nop

    :array_17e
    .array-data 1
        -0x3et
        -0x50t
        0x5ct
        -0x4ct
        0x21t
        0x51t
        -0x1et
        -0x25t
    .end array-data

    :array_186
    .array-data 1
        0x4bt
        0x2dt
        0x51t
        0x22t
        0x57t
        0x66t
    .end array-data

    nop

    :array_18e
    .array-data 1
        0x25t
        0x42t
        0x23t
        0x4ft
        0x36t
        0xat
        -0x76t
        -0x1ft
    .end array-data

    :array_196
    .array-data 1
        -0x41t
        -0x44t
        0x7et
        -0x30t
        -0x15t
        0x40t
    .end array-data

    nop

    :array_19e
    .array-data 1
        0x5bt
        0x4t
        -0x2t
        0x38t
        0x63t
        -0x14t
        -0x21t
        -0x11t
    .end array-data

    :array_1a6
    .array-data 1
        0x25t
        0x1t
        -0x44t
        0x78t
        0x1bt
        0x73t
        -0x57t
        0x37t
        0x19t
        0x16t
    .end array-data

    nop

    :array_1b0
    .array-data 1
        0x70t
        0x62t
        -0x1bt
        0xdt
        0x75t
        0x53t
        -0x20t
        0x59t
    .end array-data
.end method

.method private B()V
    .registers 26

    move-object/from16 v1, p0

    const/16 v2, 0xd

    const/16 v3, 0x8

    :try_start_6
    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v5

    invoke-virtual {v4, v5, v6}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const-string v5, ""

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    iput-object v4, v1, Lcom/github/catvod/spider/appysv2/b/U;->h:Ljava/lang/String;

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const/16 v5, 0x47

    new-array v5, v5, [B

    const/16 v6, 0x5a

    const/4 v7, 0x0

    aput-byte v6, v5, v7

    const/16 v6, 0x71

    const/4 v8, 0x1

    aput-byte v6, v5, v8

    const/4 v6, 0x7

    const/4 v9, 0x2

    aput-byte v6, v5, v9

    const/16 v10, -0x6c

    const/4 v11, 0x3

    aput-byte v10, v5, v11

    const/4 v10, 0x4

    aput-byte v2, v5, v10

    const/16 v12, -0x1d

    const/4 v13, 0x5

    aput-byte v12, v5, v13

    const/16 v12, -0x30

    const/4 v14, 0x6

    aput-byte v12, v5, v14

    const/16 v12, -0x7d

    aput-byte v12, v5, v6

    const/16 v12, 0x53

    aput-byte v12, v5, v3

    const/16 v12, 0x75

    const/16 v15, 0x9

    aput-byte v12, v5, v15

    const/16 v12, 0x1a

    const/16 v15, 0xa

    aput-byte v12, v5, v15

    const/16 v15, -0x36

    const/16 v16, 0xb

    aput-byte v15, v5, v16

    const/16 v15, 0x11

    const/16 v14, 0xc

    aput-byte v15, v5, v14

    const/16 v18, -0x57

    aput-byte v18, v5, v2

    const/16 v2, -0x66

    const/16 v18, 0xe

    aput-byte v2, v5, v18

    const/16 v2, 0xf

    const/16 v19, -0x3e

    aput-byte v19, v5, v2

    const/16 v2, 0x1c

    const/16 v19, 0x10

    aput-byte v2, v5, v19

    const/16 v20, 0x70

    aput-byte v20, v5, v15

    const/16 v20, 0x12

    aput-byte v19, v5, v20

    const/16 v21, -0x36

    const/16 v22, 0x13

    aput-byte v21, v5, v22

    const/16 v21, 0x14

    const/16 v23, 0x1d

    aput-byte v23, v5, v21

    const/16 v21, 0x15

    const/16 v23, -0x49

    aput-byte v23, v5, v21

    const/16 v21, 0x16

    const/16 v23, -0x30

    aput-byte v23, v5, v21

    const/16 v21, -0x31

    const/16 v23, 0x17

    aput-byte v21, v5, v23

    const/16 v21, 0x18

    const/16 v24, 0x53

    aput-byte v24, v5, v21

    const/16 v21, 0x19

    const/16 v24, 0x76

    aput-byte v24, v5, v21

    const/16 v21, 0x5c

    aput-byte v21, v5, v12

    const/16 v12, 0x1b

    const/16 v21, -0x7b

    aput-byte v21, v5, v12

    const/16 v12, 0x14

    aput-byte v12, v5, v2

    const/16 v12, 0x1d

    const/16 v21, -0x48

    aput-byte v21, v5, v12

    const/16 v12, 0x1e

    const/16 v21, -0x79

    aput-byte v21, v5, v12

    const/16 v12, 0x1f

    const/16 v21, -0x7d

    aput-byte v21, v5, v12

    const/16 v12, 0x20

    const/16 v21, 0x55

    aput-byte v21, v5, v12

    const/16 v12, 0x21

    const/16 v21, 0x60

    aput-byte v21, v5, v12

    const/16 v12, 0x22

    aput-byte v6, v5, v12

    const/16 v12, 0x23

    const/16 v21, -0x50

    aput-byte v21, v5, v12

    const/16 v12, 0x24

    aput-byte v15, v5, v12

    const/16 v12, 0x25

    const/16 v21, -0x4e

    aput-byte v21, v5, v12

    const/16 v12, 0x26

    const/16 v21, -0x66

    aput-byte v21, v5, v12

    const/16 v12, 0x27

    const/16 v21, -0x3e

    aput-byte v21, v5, v12

    const/16 v12, 0x28

    const/16 v21, 0x74

    aput-byte v21, v5, v12

    const/16 v12, 0x29

    const/16 v21, 0x6a

    aput-byte v21, v5, v12

    const/16 v12, 0x2a

    aput-byte v8, v5, v12

    const/16 v12, 0x2b

    const/16 v21, -0x4b

    aput-byte v21, v5, v12

    const/16 v12, 0x2c

    aput-byte v14, v5, v12

    const/16 v12, 0x2d

    const/16 v21, -0x46

    aput-byte v21, v5, v12

    const/16 v12, 0x2e

    const/16 v21, -0x70

    aput-byte v21, v5, v12

    const/16 v12, 0x2f

    const/16 v21, -0x38

    aput-byte v21, v5, v12

    const/16 v12, 0x30

    const/16 v21, 0x57

    aput-byte v21, v5, v12

    const/16 v12, 0x31

    const/16 v21, 0x49

    aput-byte v21, v5, v12

    const/16 v12, 0x32

    aput-byte v2, v5, v12

    const/16 v12, 0x33

    const/16 v21, -0x7d

    aput-byte v21, v5, v12

    const/16 v12, 0x34

    aput-byte v23, v5, v12

    const/16 v12, 0x35

    const/16 v21, -0x49

    aput-byte v21, v5, v12

    const/16 v12, 0x36

    const/16 v21, -0x40

    aput-byte v21, v5, v12

    const/16 v12, 0x37

    const/16 v21, -0xd

    aput-byte v21, v5, v12

    const/16 v12, 0x38

    const/16 v21, 0x6d

    aput-byte v21, v5, v12

    const/16 v12, 0x39

    const/16 v21, 0x61

    aput-byte v21, v5, v12

    const/16 v12, 0x3a

    aput-byte v6, v5, v12

    const/16 v12, 0x3b

    const/16 v21, -0x27

    aput-byte v21, v5, v12

    const/16 v12, 0x3c

    const/16 v21, 0x48

    aput-byte v21, v5, v12

    const/16 v12, 0x3d

    const/16 v21, -0x13

    aput-byte v21, v5, v12

    const/16 v12, 0x3e

    const/16 v21, -0x32

    aput-byte v21, v5, v12

    const/16 v12, 0x3f

    const/16 v21, -0x62

    aput-byte v21, v5, v12

    const/16 v12, 0x40

    aput-byte v6, v5, v12

    const/16 v12, 0x41

    const/16 v21, 0x31

    aput-byte v21, v5, v12

    const/16 v12, 0x42

    const/16 v21, 0x55

    aput-byte v21, v5, v12

    const/16 v12, 0x43

    const/16 v21, -0x45

    aput-byte v21, v5, v12

    const/16 v12, 0x44

    const/16 v21, 0x21

    aput-byte v21, v5, v12

    const/16 v12, 0x45

    const/16 v21, -0x53

    aput-byte v21, v5, v12

    const/16 v12, 0x46

    const/16 v21, -0x3e

    aput-byte v21, v5, v12

    new-array v12, v3, [B

    const/16 v21, 0x32

    aput-byte v21, v12, v7

    aput-byte v13, v12, v8

    const/16 v21, 0x73

    aput-byte v21, v12, v9

    const/16 v21, -0x1c

    aput-byte v21, v12, v11

    const/16 v21, 0x7e

    aput-byte v21, v12, v10

    const/16 v21, -0x27

    aput-byte v21, v12, v13

    const/16 v21, -0x1

    const/16 v17, 0x6

    aput-byte v21, v12, v17

    const/16 v21, -0x54

    aput-byte v21, v12, v6

    invoke-static {v5, v12}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v5, v1, Lcom/github/catvod/spider/appysv2/b/U;->h:Ljava/lang/String;

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    new-instance v5, Ljava/util/HashMap;

    invoke-direct {v5}, Ljava/util/HashMap;-><init>()V

    const/4 v12, 0x6

    new-array v2, v12, [B

    const/16 v12, -0xd

    aput-byte v12, v2, v7

    const/16 v12, -0x39

    aput-byte v12, v2, v8

    const/16 v12, 0x78

    aput-byte v12, v2, v9

    const/16 v12, -0x42

    aput-byte v12, v2, v11

    const/16 v12, 0x7b

    aput-byte v12, v2, v10

    const/16 v12, 0x3e

    aput-byte v12, v2, v13

    new-array v12, v3, [B

    const/16 v23, -0x4e

    aput-byte v23, v12, v7

    const/16 v23, -0x5c

    aput-byte v23, v12, v8

    const/16 v23, 0x1b

    aput-byte v23, v12, v9

    const/16 v23, -0x25

    aput-byte v23, v12, v11

    aput-byte v16, v12, v10

    const/16 v23, 0x4a

    aput-byte v23, v12, v13

    const/16 v17, 0x6

    aput-byte v13, v12, v17

    const/16 v23, 0x4b

    aput-byte v23, v12, v6

    invoke-static {v2, v12}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v2

    const/16 v12, 0x21

    new-array v12, v12, [B

    const/16 v23, -0xc

    aput-byte v23, v12, v7

    const/16 v23, 0xd

    aput-byte v23, v12, v8

    const/16 v23, -0x3f

    aput-byte v23, v12, v9

    const/16 v23, -0x3f

    aput-byte v23, v12, v11

    const/16 v23, 0x65

    aput-byte v23, v12, v10

    const/16 v23, -0x27

    aput-byte v23, v12, v13

    const/16 v23, -0x1b

    const/16 v17, 0x6

    aput-byte v23, v12, v17

    const/16 v23, 0x79

    aput-byte v23, v12, v6

    const/4 v6, -0x4

    aput-byte v6, v12, v3

    const/16 v6, 0x9

    aput-byte v20, v12, v6

    const/16 v6, -0x21

    const/16 v23, 0xa

    aput-byte v6, v12, v23

    const/16 v6, -0x7e

    aput-byte v6, v12, v16

    const/16 v6, 0x66

    aput-byte v6, v12, v14

    const/16 v6, -0x37

    const/16 v23, 0xd

    aput-byte v6, v12, v23

    const/16 v6, -0x15

    aput-byte v6, v12, v18

    const/16 v6, 0xf

    const/16 v23, 0x63

    aput-byte v23, v12, v6

    const/16 v6, -0x47

    aput-byte v6, v12, v19

    const/16 v6, 0x5d

    aput-byte v6, v12, v15

    const/16 v6, -0x3b

    aput-byte v6, v12, v20

    const/16 v6, -0x38

    aput-byte v6, v12, v22

    const/16 v6, 0x14

    const/16 v23, 0x74

    aput-byte v23, v12, v6

    const/16 v6, 0x15

    const/16 v23, -0x32

    aput-byte v23, v12, v6

    const/16 v6, 0x16

    const/16 v23, -0x55

    aput-byte v23, v12, v6

    const/16 v6, 0x7d

    const/16 v23, 0x17

    aput-byte v6, v12, v23

    const/16 v6, 0x18

    const/16 v23, -0x7

    aput-byte v23, v12, v6

    const/16 v6, 0x19

    const/16 v21, 0x1c

    aput-byte v21, v12, v6

    const/16 v6, -0x28

    const/16 v23, 0x1a

    aput-byte v6, v12, v23

    const/16 v6, 0x1b

    const/16 v23, -0x3d

    aput-byte v23, v12, v6

    const/16 v6, 0x20

    aput-byte v6, v12, v21

    const/16 v6, 0x1d

    const/16 v23, -0x66

    aput-byte v23, v12, v6

    const/16 v6, 0x1e

    const/16 v23, -0x52

    aput-byte v23, v12, v6

    const/16 v6, 0x1f

    const/16 v23, 0x22

    aput-byte v23, v12, v6

    const/16 v6, 0x20

    const/16 v23, -0x41

    aput-byte v23, v12, v6

    new-array v6, v3, [B

    const/16 v23, -0x6b

    aput-byte v23, v6, v7

    const/16 v23, 0x7d

    aput-byte v23, v6, v8

    const/16 v23, -0x4f

    aput-byte v23, v6, v9

    const/16 v23, -0x53

    aput-byte v23, v6, v11

    aput-byte v14, v6, v10

    const/16 v23, -0x46

    aput-byte v23, v6, v13

    const/16 v23, -0x7c

    const/16 v17, 0x6

    aput-byte v23, v6, v17

    const/16 v23, 0xd

    const/16 v24, 0x7

    aput-byte v23, v6, v24

    invoke-static {v12, v6}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v5, v2, v6}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    new-array v2, v14, [B

    const/16 v6, -0x1a

    aput-byte v6, v2, v7

    aput-byte v8, v2, v8

    const/16 v6, -0x7e

    aput-byte v6, v2, v9

    const/16 v6, -0x25

    aput-byte v6, v2, v11

    const/16 v6, 0x55

    aput-byte v6, v2, v10

    const/16 v6, -0x28

    aput-byte v6, v2, v13

    const/16 v6, 0x4e

    const/4 v12, 0x6

    aput-byte v6, v2, v12

    const/16 v6, 0x71

    const/4 v12, 0x7

    aput-byte v6, v2, v12

    const/16 v6, -0xf

    aput-byte v6, v2, v3

    const/16 v6, 0x17

    const/16 v12, 0x9

    aput-byte v6, v2, v12

    const/16 v6, -0x64

    const/16 v12, 0xa

    aput-byte v6, v2, v12

    const/16 v6, -0x36

    aput-byte v6, v2, v16

    new-array v6, v3, [B

    const/16 v12, -0x5b

    aput-byte v12, v6, v7

    const/16 v12, 0x6e

    aput-byte v12, v6, v8

    const/16 v12, -0x14

    aput-byte v12, v6, v9

    const/16 v12, -0x51

    aput-byte v12, v6, v11

    const/16 v12, 0x30

    aput-byte v12, v6, v10

    const/16 v12, -0x4a

    aput-byte v12, v6, v13

    const/16 v12, 0x3a

    const/16 v17, 0x6

    aput-byte v12, v6, v17

    const/16 v12, 0x5c

    const/16 v23, 0x7

    aput-byte v12, v6, v23

    invoke-static {v2, v6}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v2

    const/16 v6, 0x21

    new-array v6, v6, [B

    const/16 v12, 0x37

    aput-byte v12, v6, v7

    const/16 v12, 0x53

    aput-byte v12, v6, v8

    const/16 v12, -0x41

    aput-byte v12, v6, v9

    const/16 v12, 0x74

    aput-byte v12, v6, v11

    const/16 v12, -0x22

    aput-byte v12, v6, v10

    const/16 v12, 0x54

    aput-byte v12, v6, v13

    const/16 v12, 0x26

    const/16 v17, 0x6

    aput-byte v12, v6, v17

    const/16 v12, 0x73

    const/16 v23, 0x7

    aput-byte v12, v6, v23

    const/16 v12, 0x3f

    aput-byte v12, v6, v3

    const/16 v12, 0x4c

    const/16 v23, 0x9

    aput-byte v12, v6, v23

    const/16 v12, -0x5f

    const/16 v23, 0xa

    aput-byte v12, v6, v23

    const/16 v12, 0x37

    aput-byte v12, v6, v16

    const/16 v12, -0x31

    aput-byte v12, v6, v14

    const/16 v12, 0x1a

    const/16 v14, 0xd

    aput-byte v12, v6, v14

    const/16 v12, 0x30

    aput-byte v12, v6, v18

    const/16 v12, 0xf

    const/16 v14, 0x70

    aput-byte v14, v6, v12

    const/16 v12, 0x21

    aput-byte v12, v6, v19

    aput-byte v18, v6, v15

    const/16 v12, -0x57

    aput-byte v12, v6, v20

    const/16 v12, 0x77

    aput-byte v12, v6, v22

    const/16 v12, 0x14

    const/16 v14, -0x3b

    aput-byte v14, v6, v12

    const/16 v12, 0x15

    const/16 v14, 0x5a

    aput-byte v14, v6, v12

    const/16 v12, 0x16

    const/16 v14, 0x6a

    aput-byte v14, v6, v12

    const/16 v12, 0x72

    const/16 v14, 0x17

    aput-byte v12, v6, v14

    const/16 v12, 0x18

    const/16 v14, 0x24

    aput-byte v14, v6, v12

    const/16 v12, 0x19

    const/16 v14, 0x4f

    aput-byte v14, v6, v12

    const/16 v12, -0x56

    const/16 v14, 0x1a

    aput-byte v12, v6, v14

    const/16 v12, 0x1b

    const/16 v14, 0x76

    aput-byte v14, v6, v12

    const/16 v12, -0x2c

    const/16 v14, 0x1c

    aput-byte v12, v6, v14

    const/16 v12, 0x1d

    const/16 v14, 0x58

    aput-byte v14, v6, v12

    const/16 v12, 0x1e

    const/16 v14, 0x23

    aput-byte v14, v6, v12

    const/16 v12, 0x1f

    const/16 v14, 0x62

    aput-byte v14, v6, v12

    const/16 v12, 0x20

    const/16 v14, 0x32

    aput-byte v14, v6, v12

    new-array v12, v3, [B

    const/16 v14, 0x56

    aput-byte v14, v12, v7

    const/16 v14, 0x23

    aput-byte v14, v12, v8

    const/16 v14, -0x31

    aput-byte v14, v12, v9

    const/16 v14, 0x18

    aput-byte v14, v12, v11

    const/16 v14, -0x49

    aput-byte v14, v12, v10

    const/16 v14, 0x37

    aput-byte v14, v12, v13

    const/16 v14, 0x47

    const/16 v17, 0x6

    aput-byte v14, v12, v17

    const/4 v14, 0x7

    aput-byte v14, v12, v14

    invoke-static {v6, v12}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v5, v2, v6}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/16 v2, 0xa

    new-array v2, v2, [B

    const/16 v6, -0x5b

    aput-byte v6, v2, v7

    const/16 v6, 0x25

    aput-byte v6, v2, v8

    const/16 v6, 0x75

    aput-byte v6, v2, v9

    const/16 v6, 0x63

    aput-byte v6, v2, v11

    const/16 v6, -0x2a

    aput-byte v6, v2, v10

    const/16 v6, 0x37

    aput-byte v6, v2, v13

    const/16 v6, 0x64

    const/4 v12, 0x6

    aput-byte v6, v2, v12

    const/4 v6, 0x7

    aput-byte v3, v2, v6

    const/16 v6, -0x62

    aput-byte v6, v2, v3

    const/16 v6, 0x22

    const/16 v12, 0x9

    aput-byte v6, v2, v12

    new-array v6, v3, [B

    const/16 v12, -0x10

    aput-byte v12, v6, v7

    const/16 v12, 0x56

    aput-byte v12, v6, v8

    aput-byte v19, v6, v9

    aput-byte v15, v6, v11

    const/4 v12, -0x5

    aput-byte v12, v6, v10

    const/16 v12, 0x76

    aput-byte v12, v6, v13

    const/4 v12, 0x6

    aput-byte v11, v6, v12

    const/16 v12, 0x6d

    const/4 v14, 0x7

    aput-byte v12, v6, v14

    invoke-static {v2, v6}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v2

    sget-object v6, Lcom/github/catvod/spider/appysv2/b/U;->i:Ljava/lang/String;

    invoke-virtual {v5, v2, v6}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    new-array v2, v14, [B

    const/16 v6, 0x43

    aput-byte v6, v2, v7

    const/16 v6, 0x69

    aput-byte v6, v2, v8

    const/16 v6, -0x21

    aput-byte v6, v2, v9

    const/16 v6, 0x1c

    aput-byte v6, v2, v11

    const/16 v6, 0x3a

    aput-byte v6, v2, v10

    const/16 v6, -0x19

    aput-byte v6, v2, v13

    const/4 v6, 0x6

    aput-byte v11, v2, v6

    new-array v6, v3, [B

    aput-byte v15, v6, v7

    const/16 v12, 0xc

    aput-byte v12, v6, v8

    const/16 v12, -0x47

    aput-byte v12, v6, v9

    const/16 v12, 0x79

    aput-byte v12, v6, v11

    const/16 v12, 0x48

    aput-byte v12, v6, v10

    const/16 v12, -0x7e

    aput-byte v12, v6, v13

    const/16 v12, 0x71

    const/4 v14, 0x6

    aput-byte v12, v6, v14

    const/16 v12, -0x2c

    const/4 v14, 0x7

    aput-byte v12, v6, v14

    invoke-static {v2, v6}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v2

    const/16 v6, 0x17

    new-array v6, v6, [B

    const/16 v12, 0x34

    aput-byte v12, v6, v7

    const/16 v12, 0x3d

    aput-byte v12, v6, v8

    const/16 v12, 0x2f

    aput-byte v12, v6, v9

    const/4 v12, -0x8

    aput-byte v12, v6, v11

    const/16 v12, -0x31

    aput-byte v12, v6, v10

    const/16 v12, 0x4b

    aput-byte v12, v6, v13

    const/16 v12, -0x15

    const/4 v14, 0x6

    aput-byte v12, v6, v14

    const/16 v12, 0x7a

    const/4 v14, 0x7

    aput-byte v12, v6, v14

    const/16 v12, 0x3e

    aput-byte v12, v6, v3

    const/16 v12, 0x3b

    const/16 v14, 0x9

    aput-byte v12, v6, v14

    const/16 v12, 0x34

    const/16 v14, 0xa

    aput-byte v12, v6, v14

    const/16 v12, -0x15

    aput-byte v12, v6, v16

    const/16 v12, -0x21

    const/16 v14, 0xc

    aput-byte v12, v6, v14

    const/16 v12, 0x1e

    const/16 v14, 0xd

    aput-byte v12, v6, v14

    const/16 v12, -0x58

    aput-byte v12, v6, v18

    const/16 v12, 0xf

    const/16 v14, 0x3c

    aput-byte v14, v6, v12

    const/16 v12, 0x72

    aput-byte v12, v6, v19

    const/16 v12, 0x3c

    aput-byte v12, v6, v15

    const/16 v12, 0x38

    aput-byte v12, v6, v20

    const/16 v12, -0x5a

    aput-byte v12, v6, v22

    const/16 v12, 0x14

    const/16 v14, -0x21

    aput-byte v14, v6, v12

    const/16 v12, 0x15

    const/16 v14, 0x1f

    aput-byte v14, v6, v12

    const/16 v12, 0x16

    const/16 v14, -0x15

    aput-byte v14, v6, v12

    new-array v12, v3, [B

    const/16 v14, 0x5c

    aput-byte v14, v12, v7

    const/16 v14, 0x49

    aput-byte v14, v12, v8

    const/16 v14, 0x5b

    aput-byte v14, v12, v9

    const/16 v14, -0x78

    aput-byte v14, v12, v11

    const/16 v14, -0x44

    aput-byte v14, v12, v10

    const/16 v14, 0x71

    aput-byte v14, v12, v13

    const/16 v14, -0x3c

    const/16 v17, 0x6

    aput-byte v14, v12, v17

    const/16 v14, 0x55

    const/16 v23, 0x7

    aput-byte v14, v12, v23

    invoke-static {v6, v12}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v5, v2, v6}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    new-instance v2, Ljava/util/HashMap;

    invoke-direct {v2}, Ljava/util/HashMap;-><init>()V

    const/16 v6, 0x9

    new-array v6, v6, [B

    const/16 v12, -0x16

    aput-byte v12, v6, v7

    const/16 v12, 0xc

    aput-byte v12, v6, v8

    const/16 v12, -0x4f

    aput-byte v12, v6, v9

    const/16 v12, -0x50

    aput-byte v12, v6, v11

    aput-byte v22, v6, v10

    const/16 v12, 0x30

    aput-byte v12, v6, v13

    const/16 v12, 0x51

    const/4 v14, 0x6

    aput-byte v12, v6, v14

    const/16 v12, 0x78

    const/4 v14, 0x7

    aput-byte v12, v6, v14

    const/16 v12, -0x13

    aput-byte v12, v6, v3

    new-array v12, v3, [B

    const/16 v14, -0x77

    aput-byte v14, v12, v7

    const/16 v14, 0x60

    aput-byte v14, v12, v8

    const/16 v14, -0x28

    aput-byte v14, v12, v9

    const/16 v14, -0x2b

    aput-byte v14, v12, v11

    const/16 v14, 0x7d

    aput-byte v14, v12, v10

    const/16 v14, 0x44

    aput-byte v14, v12, v13

    const/4 v14, 0x6

    aput-byte v18, v12, v14

    const/4 v14, 0x7

    aput-byte v15, v12, v14

    invoke-static {v6, v12}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v6

    new-array v12, v11, [B

    const/16 v14, 0x68

    aput-byte v14, v12, v7

    const/16 v14, -0x32

    aput-byte v14, v12, v8

    const/16 v14, -0x1c

    aput-byte v14, v12, v9

    new-array v14, v3, [B

    const/16 v23, 0x5b

    aput-byte v23, v14, v7

    const/16 v23, -0xa

    aput-byte v23, v14, v8

    const/16 v23, -0x2b

    aput-byte v23, v14, v9

    const/16 v23, 0x5c

    aput-byte v23, v14, v11

    const/16 v23, -0x3e

    aput-byte v23, v14, v10

    const/16 v23, 0x79

    aput-byte v23, v14, v13

    const/16 v23, -0x37

    const/16 v17, 0x6

    aput-byte v23, v14, v17

    const/16 v23, 0x55

    const/16 v24, 0x7

    aput-byte v23, v14, v24

    invoke-static {v12, v14}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v12

    invoke-virtual {v2, v6, v12}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    new-array v6, v8, [B

    const/16 v12, 0x6c

    aput-byte v12, v6, v7

    new-array v12, v3, [B

    const/16 v14, 0x1a

    aput-byte v14, v12, v7

    const/16 v14, -0x67

    aput-byte v14, v12, v8

    const/16 v14, 0x51

    aput-byte v14, v12, v9

    const/16 v14, 0x36

    aput-byte v14, v12, v11

    const/16 v14, 0x35

    aput-byte v14, v12, v10

    const/16 v14, -0xd

    aput-byte v14, v12, v13

    const/16 v14, -0x61

    const/16 v17, 0x6

    aput-byte v14, v12, v17

    const/16 v14, -0xb

    const/16 v23, 0x7

    aput-byte v14, v12, v23

    invoke-static {v6, v12}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v6

    new-array v12, v11, [B

    const/16 v14, 0x7d

    aput-byte v14, v12, v7

    const/16 v14, 0x23

    aput-byte v14, v12, v8

    aput-byte v9, v12, v9

    new-array v14, v3, [B

    const/16 v23, 0x4c

    aput-byte v23, v14, v7

    const/16 v23, 0xd

    aput-byte v23, v14, v8

    const/16 v23, 0x30

    aput-byte v23, v14, v9

    const/16 v23, -0x25

    aput-byte v23, v14, v11

    const/16 v23, 0x39

    aput-byte v23, v14, v10

    const/16 v23, 0x35

    aput-byte v23, v14, v13

    const/16 v23, -0x55

    const/16 v17, 0x6

    aput-byte v23, v14, v17

    const/16 v23, 0x21

    const/16 v24, 0x7

    aput-byte v23, v14, v24

    invoke-static {v12, v14}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v12

    invoke-virtual {v2, v6, v12}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/16 v6, 0xa

    new-array v6, v6, [B

    const/16 v12, -0x55

    aput-byte v12, v6, v7

    const/4 v12, 0x7

    aput-byte v12, v6, v8

    const/16 v12, 0x56

    aput-byte v12, v6, v9

    const/16 v12, -0x36

    aput-byte v12, v6, v11

    const/16 v12, 0x69

    aput-byte v12, v6, v10

    aput-byte v3, v6, v13

    const/16 v12, -0x44

    const/4 v14, 0x6

    aput-byte v12, v6, v14

    const/16 v12, 0x22

    const/16 v17, 0x7

    aput-byte v12, v6, v17

    const/16 v12, -0x50

    aput-byte v12, v6, v3

    const/16 v12, 0x9

    aput-byte v14, v6, v12

    new-array v12, v3, [B

    const/16 v14, -0x27

    aput-byte v14, v12, v7

    const/16 v14, 0x62

    aput-byte v14, v12, v8

    const/16 v14, 0x27

    aput-byte v14, v12, v9

    const/16 v14, -0x41

    aput-byte v14, v12, v11

    const/16 v14, 0xc

    aput-byte v14, v12, v10

    const/16 v14, 0x7b

    aput-byte v14, v12, v13

    const/16 v14, -0x38

    const/16 v17, 0x6

    aput-byte v14, v12, v17

    const/16 v14, 0x7d

    const/16 v23, 0x7

    aput-byte v14, v12, v23

    invoke-static {v6, v12}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v6

    iget-object v12, v1, Lcom/github/catvod/spider/appysv2/b/U;->h:Ljava/lang/String;

    invoke-virtual {v2, v6, v12}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    invoke-static {v4, v2, v5}, Lcom/github/catvod/spider/appysv2/n/c;->h(Ljava/lang/String;Ljava/util/Map;Ljava/util/Map;)Lcom/github/catvod/spider/appysv2/n/e;

    move-result-object v2

    new-instance v4, Lorg/json/JSONObject;

    invoke-virtual {v2}, Lcom/github/catvod/spider/appysv2/n/e;->a()Ljava/lang/String;

    move-result-object v2

    invoke-direct {v4, v2}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    new-array v2, v10, [B

    const/16 v5, -0x18

    aput-byte v5, v2, v7

    const/16 v5, 0x72

    aput-byte v5, v2, v8

    const/16 v5, 0x71

    aput-byte v5, v2, v9

    const/16 v5, -0xa

    aput-byte v5, v2, v11

    new-array v5, v3, [B

    const/16 v6, -0x74

    aput-byte v6, v5, v7

    aput-byte v22, v5, v8

    aput-byte v13, v5, v9

    const/16 v6, -0x69

    aput-byte v6, v5, v11

    const/16 v6, -0x63

    aput-byte v6, v5, v10

    const/16 v6, 0x20

    aput-byte v6, v5, v13

    const/16 v6, 0x60

    const/4 v12, 0x6

    aput-byte v6, v5, v12

    const/16 v6, 0x75

    const/4 v12, 0x7

    aput-byte v6, v5, v12

    invoke-static {v2, v5}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v4, v2}, Lorg/json/JSONObject;->optJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v2

    new-array v4, v12, [B

    const/16 v5, 0x65

    aput-byte v5, v4, v7

    const/16 v5, -0x11

    aput-byte v5, v4, v8

    const/16 v5, 0x17

    aput-byte v5, v4, v9

    const/16 v5, -0xd

    aput-byte v5, v4, v11

    const/16 v5, 0x62

    aput-byte v5, v4, v10

    const/4 v5, -0x3

    aput-byte v5, v4, v13

    const/16 v5, -0x13

    const/4 v6, 0x6

    aput-byte v5, v4, v6

    new-array v5, v3, [B

    aput-byte v3, v5, v7

    const/16 v6, -0x76

    aput-byte v6, v5, v8

    const/16 v6, 0x7a

    aput-byte v6, v5, v9

    const/16 v6, -0x6f

    aput-byte v6, v5, v11

    const/4 v6, 0x7

    aput-byte v6, v5, v10

    const/16 v12, -0x71

    aput-byte v12, v5, v13

    const/16 v12, -0x62

    const/4 v14, 0x6

    aput-byte v12, v5, v14

    const/16 v12, -0x2c

    aput-byte v12, v5, v6

    invoke-static {v4, v5}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v2, v4}, Lorg/json/JSONObject;->optJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v2

    new-array v4, v13, [B

    const/16 v5, -0x7b

    aput-byte v5, v4, v7

    const/16 v5, 0x46

    aput-byte v5, v4, v8

    const/16 v5, 0x7d

    aput-byte v5, v4, v9

    const/16 v5, 0x2a

    aput-byte v5, v4, v11

    const/16 v5, -0x3e

    aput-byte v5, v4, v10

    new-array v5, v3, [B

    const/16 v6, -0xf

    aput-byte v6, v5, v7

    const/16 v6, 0x29

    aput-byte v6, v5, v8

    const/16 v6, 0x16

    aput-byte v6, v5, v9

    const/16 v6, 0x4f

    aput-byte v6, v5, v11

    const/16 v6, -0x54

    aput-byte v6, v5, v10

    const/16 v6, -0x45

    aput-byte v6, v5, v13

    const/16 v6, -0x26

    const/4 v12, 0x6

    aput-byte v6, v5, v12

    const/16 v6, -0x73

    const/4 v12, 0x7

    aput-byte v6, v5, v12

    invoke-static {v4, v5}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v2, v4}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const/16 v5, 0x5f

    new-array v5, v5, [B

    const/16 v6, 0xc

    aput-byte v6, v5, v7

    const/16 v6, 0x2f

    aput-byte v6, v5, v8

    const/16 v6, 0x31

    aput-byte v6, v5, v9

    const/16 v6, -0x3b

    aput-byte v6, v5, v11

    const/16 v6, 0x53

    aput-byte v6, v5, v10

    const/16 v6, -0x4d

    aput-byte v6, v5, v13

    const/16 v6, -0x79

    const/4 v12, 0x6

    aput-byte v6, v5, v12

    const/16 v6, -0x71

    const/4 v12, 0x7

    aput-byte v6, v5, v12

    const/16 v6, 0x17

    aput-byte v6, v5, v3

    const/16 v6, 0x2e

    const/16 v12, 0x9

    aput-byte v6, v5, v12

    const/16 v6, 0x6b

    const/16 v12, 0xa

    aput-byte v6, v5, v12

    const/16 v6, -0x40

    aput-byte v6, v5, v16

    const/16 v6, 0x43

    const/16 v12, 0xc

    aput-byte v6, v5, v12

    const/16 v6, -0x59

    const/16 v12, 0xd

    aput-byte v6, v5, v12

    const/16 v6, -0x35

    aput-byte v6, v5, v18

    const/16 v6, 0xf

    const/16 v12, -0x32

    aput-byte v12, v5, v6

    const/16 v6, 0x4b

    aput-byte v6, v5, v19

    const/16 v6, 0x6a

    aput-byte v6, v5, v15

    const/16 v6, 0x1a

    aput-byte v6, v5, v20

    const/16 v6, -0x25

    aput-byte v6, v5, v22

    const/16 v6, 0x14

    aput-byte v19, v5, v6

    const/16 v6, 0x15

    const/16 v12, -0x2d

    aput-byte v12, v5, v6

    const/16 v6, 0x16

    const/16 v12, -0x15

    aput-byte v12, v5, v6

    const/16 v6, -0x2a

    const/16 v12, 0x17

    aput-byte v6, v5, v12

    const/16 v6, 0x18

    const/16 v12, 0x5b

    aput-byte v12, v5, v6

    const/16 v6, 0x19

    const/16 v12, 0x2e

    aput-byte v12, v5, v6

    const/16 v6, 0x26

    const/16 v12, 0x1a

    aput-byte v6, v5, v12

    const/16 v6, 0x1b

    const/16 v12, -0x16

    aput-byte v12, v5, v6

    const/16 v6, 0x50

    const/16 v12, 0x1c

    aput-byte v6, v5, v12

    const/16 v6, 0x1d

    const/16 v12, -0x18

    aput-byte v12, v5, v6

    const/16 v6, 0x1e

    const/16 v12, -0x26

    aput-byte v12, v5, v6

    const/16 v6, 0x1f

    const/16 v12, -0x3f

    aput-byte v12, v5, v6

    const/16 v6, 0x20

    const/16 v12, 0x9

    aput-byte v12, v5, v6

    const/16 v6, 0x21

    aput-byte v10, v5, v6

    const/16 v6, 0x22

    const/16 v12, 0x36

    aput-byte v12, v5, v6

    const/16 v6, 0x23

    const/16 v12, -0x3f

    aput-byte v12, v5, v6

    const/16 v6, 0x24

    const/16 v12, 0x52

    aput-byte v12, v5, v6

    const/16 v6, 0x25

    const/16 v12, -0x4c

    aput-byte v12, v5, v6

    const/16 v6, 0x26

    const/16 v12, -0x34

    aput-byte v12, v5, v6

    const/16 v6, 0x27

    const/16 v12, -0x2d

    aput-byte v12, v5, v6

    const/16 v6, 0x28

    aput-byte v7, v5, v6

    const/16 v6, 0x29

    const/16 v12, 0x35

    aput-byte v12, v5, v6

    const/16 v6, 0x2a

    const/16 v12, 0x23

    aput-byte v12, v5, v6

    const/16 v6, 0x2b

    const/16 v12, -0x39

    aput-byte v12, v5, v6

    const/16 v6, 0x2c

    const/16 v12, 0x50

    aput-byte v12, v5, v6

    const/16 v6, 0x2d

    const/16 v12, -0x11

    aput-byte v12, v5, v6

    const/16 v6, 0x2e

    const/16 v12, -0x36

    aput-byte v12, v5, v6

    const/16 v6, 0x2f

    const/16 v12, -0x37

    aput-byte v12, v5, v6

    const/16 v6, 0x30

    aput-byte v20, v5, v6

    const/16 v6, 0x31

    const/16 v12, 0x3e

    aput-byte v12, v5, v6

    const/16 v6, 0x32

    const/16 v12, 0x36

    aput-byte v12, v5, v6

    const/16 v6, 0x33

    const/16 v12, -0x3a

    aput-byte v12, v5, v6

    const/16 v6, 0x34

    const/16 v12, 0x43

    aput-byte v12, v5, v6

    const/16 v6, 0x35

    const/4 v12, -0x7

    aput-byte v12, v5, v6

    const/16 v6, 0x36

    const/16 v12, -0x31

    aput-byte v12, v5, v6

    const/16 v6, 0x37

    const/16 v12, -0x37

    aput-byte v12, v5, v6

    const/16 v6, 0x38

    const/16 v12, 0x9

    aput-byte v12, v5, v6

    const/16 v6, 0x39

    const/16 v12, 0x32

    aput-byte v12, v5, v6

    const/16 v6, 0x3a

    const/16 v12, 0x27

    aput-byte v12, v5, v6

    const/16 v6, 0x3b

    const/16 v12, -0x3f

    aput-byte v12, v5, v6

    const/16 v6, 0x3c

    const/16 v12, 0x42

    aput-byte v12, v5, v6

    const/16 v6, 0x3d

    const/16 v12, -0x1c

    aput-byte v12, v5, v6

    const/16 v6, 0x3e

    const/16 v12, -0x3a

    aput-byte v12, v5, v6

    const/16 v6, 0x3f

    const/16 v12, -0x37

    aput-byte v12, v5, v6

    const/16 v6, 0x40

    aput-byte v18, v5, v6

    const/16 v6, 0x41

    const/16 v12, 0x39

    aput-byte v12, v5, v6

    const/16 v6, 0x42

    const/16 v12, 0x29

    aput-byte v12, v5, v6

    const/16 v6, 0x43

    const/16 v12, -0x2c

    aput-byte v12, v5, v6

    const/16 v6, 0x44

    const/16 v12, 0x55

    aput-byte v12, v5, v6

    const/16 v6, 0x45

    const/4 v12, -0x7

    aput-byte v12, v5, v6

    const/16 v6, 0x46

    const/16 v12, -0x23

    aput-byte v12, v5, v6

    const/16 v6, 0x47

    const/16 v12, -0x2c

    aput-byte v12, v5, v6

    const/16 v6, 0x48

    aput-byte v16, v5, v6

    const/16 v6, 0x49

    const/16 v12, 0x3c

    aput-byte v12, v5, v6

    const/16 v6, 0x4a

    const/16 v12, 0x35

    aput-byte v12, v5, v6

    const/16 v6, 0x4b

    const/16 v12, -0x24

    aput-byte v12, v5, v6

    const/16 v6, 0x4c

    const/16 v12, 0x4e

    aput-byte v12, v5, v6

    const/16 v6, 0x4d

    const/4 v12, -0x3

    aput-byte v12, v5, v6

    const/16 v6, 0x4e

    const/16 v12, -0x3a

    aput-byte v12, v5, v6

    const/16 v6, 0x4f

    const/16 v12, -0x29

    aput-byte v12, v5, v6

    const/16 v6, 0x50

    const/16 v12, 0xf

    aput-byte v12, v5, v6

    const/16 v6, 0x51

    const/16 v12, 0x2f

    aput-byte v12, v5, v6

    const/16 v6, 0x52

    const/16 v12, 0x35

    aput-byte v12, v5, v6

    const/16 v6, 0x53

    const/16 v12, -0x39

    aput-byte v12, v5, v6

    const/16 v6, 0x54

    const/16 v12, 0x43

    aput-byte v12, v5, v6

    const/16 v6, 0x55

    const/16 v12, -0x1f

    aput-byte v12, v5, v6

    const/16 v6, 0x56

    const/16 v12, -0x3b

    aput-byte v12, v5, v6

    const/16 v6, 0x57

    const/16 v12, -0x2c

    aput-byte v12, v5, v6

    const/16 v6, 0x58

    const/16 v12, 0x42

    aput-byte v12, v5, v6

    const/16 v6, 0x59

    const/16 v12, 0x2f

    aput-byte v12, v5, v6

    const/16 v6, 0x5a

    const/16 v12, 0x2a

    aput-byte v12, v5, v6

    const/16 v6, 0x5b

    const/16 v12, -0x22

    aput-byte v12, v5, v6

    const/16 v6, 0x5c

    const/16 v12, 0x45

    aput-byte v12, v5, v6

    const/16 v6, 0x5d

    const/16 v12, -0x19

    aput-byte v12, v5, v6

    const/16 v6, 0x5e

    const/16 v12, -0x6b

    aput-byte v12, v5, v6

    new-array v6, v3, [B

    const/16 v12, 0x64

    aput-byte v12, v6, v7

    const/16 v12, 0x5b

    aput-byte v12, v6, v8

    const/16 v12, 0x45

    aput-byte v12, v6, v9

    const/16 v12, -0x4b

    aput-byte v12, v6, v11

    const/16 v12, 0x20

    aput-byte v12, v6, v10

    const/16 v12, -0x77

    aput-byte v12, v6, v13

    const/16 v12, -0x58

    const/4 v14, 0x6

    aput-byte v12, v6, v14

    const/16 v12, -0x60

    const/4 v14, 0x7

    aput-byte v12, v6, v14

    invoke-static {v5, v6}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v5, 0x37

    new-array v5, v5, [B

    const/16 v6, 0x33

    aput-byte v6, v5, v7

    const/16 v6, 0x7b

    aput-byte v6, v5, v8

    const/16 v6, 0x2a

    aput-byte v6, v5, v9

    const/16 v6, -0xc

    aput-byte v6, v5, v11

    const/16 v6, -0x29

    aput-byte v6, v5, v10

    const/16 v6, -0xd

    aput-byte v6, v5, v13

    const/16 v6, 0x53

    const/4 v12, 0x6

    aput-byte v6, v5, v12

    const/16 v6, 0x5f

    const/4 v12, 0x7

    aput-byte v6, v5, v12

    const/16 v6, 0x7c

    aput-byte v6, v5, v3

    const/16 v6, 0x7c

    const/16 v12, 0x9

    aput-byte v6, v5, v12

    const/16 v6, 0x7b

    const/16 v12, 0xa

    aput-byte v6, v5, v12

    const/16 v6, -0x52

    aput-byte v6, v5, v16

    const/16 v6, -0x76

    const/16 v12, 0xc

    aput-byte v6, v5, v12

    const/16 v6, -0x54

    const/16 v12, 0xd

    aput-byte v6, v5, v12

    aput-byte v8, v5, v18

    const/16 v6, 0xf

    const/16 v12, 0x75

    aput-byte v12, v5, v6

    const/16 v6, 0x76

    aput-byte v6, v5, v19

    const/16 v6, 0x47

    aput-byte v6, v5, v15

    const/16 v6, 0x24

    aput-byte v6, v5, v20

    const/16 v6, -0xc

    aput-byte v6, v5, v22

    const/16 v6, 0x14

    const/16 v12, -0x38

    aput-byte v12, v5, v6

    const/16 v6, 0x15

    const/16 v12, -0x3e

    aput-byte v12, v5, v6

    const/16 v6, 0x16

    const/16 v12, 0x54

    aput-byte v12, v5, v6

    const/16 v6, 0x74

    const/16 v12, 0x17

    aput-byte v6, v5, v12

    const/16 v6, 0x18

    const/16 v12, 0x67

    aput-byte v12, v5, v6

    const/16 v6, 0x19

    const/16 v12, 0x25

    aput-byte v12, v5, v6

    const/16 v6, 0x15

    const/16 v12, 0x1a

    aput-byte v6, v5, v12

    const/16 v6, 0x1b

    const/16 v12, -0x48

    aput-byte v12, v5, v6

    const/16 v6, -0x7f

    const/16 v12, 0x1c

    aput-byte v6, v5, v12

    const/16 v6, 0x1d

    const/16 v12, -0x24

    aput-byte v12, v5, v6

    const/16 v6, 0x1e

    const/16 v12, 0x44

    aput-byte v12, v5, v6

    const/16 v6, 0x1f

    const/16 v12, 0x75

    aput-byte v12, v5, v6

    const/16 v6, 0x20

    const/16 v12, 0x66

    aput-byte v12, v5, v6

    const/16 v6, 0x21

    const/16 v12, 0x6c

    aput-byte v12, v5, v6

    const/16 v6, 0x22

    const/16 v12, 0x29

    aput-byte v12, v5, v6

    const/16 v6, 0x23

    const/16 v12, -0x10

    aput-byte v12, v5, v6

    const/16 v6, 0x24

    const/16 v12, -0x69

    aput-byte v12, v5, v6

    const/16 v6, 0x25

    const/16 v12, -0x56

    aput-byte v12, v5, v6

    const/16 v6, 0x26

    const/16 v12, 0x64

    aput-byte v12, v5, v6

    const/16 v6, 0x27

    const/16 v12, 0x43

    aput-byte v12, v5, v6

    const/16 v6, 0x28

    const/16 v12, 0x30

    aput-byte v12, v5, v6

    const/16 v6, 0x29

    const/16 v12, 0x2b

    aput-byte v12, v5, v6

    const/16 v6, 0x2a

    const/4 v12, 0x7

    aput-byte v12, v5, v6

    const/16 v6, 0x2b

    const/16 v12, -0x17

    aput-byte v12, v5, v6

    const/16 v6, 0x2c

    const/16 v12, -0x25

    aput-byte v12, v5, v6

    const/16 v6, 0x2d

    const/16 v12, -0x17

    aput-byte v12, v5, v6

    const/16 v6, 0x2e

    const/16 v12, 0x4b

    aput-byte v12, v5, v6

    const/16 v6, 0x2f

    const/16 v12, 0x65

    aput-byte v12, v5, v6

    const/16 v6, 0x30

    const/16 v12, 0x77

    aput-byte v12, v5, v6

    const/16 v6, 0x31

    const/16 v12, 0x79

    aput-byte v12, v5, v6

    const/16 v6, 0x32

    const/16 v12, 0x34

    aput-byte v12, v5, v6

    const/16 v6, 0x33

    const/16 v12, -0x3e

    aput-byte v12, v5, v6

    const/16 v6, 0x34

    const/16 v12, -0x2c

    aput-byte v12, v5, v6

    const/16 v6, 0x35

    const/16 v12, -0xc

    aput-byte v12, v5, v6

    const/16 v6, 0x36

    const/16 v12, 0x5f

    aput-byte v12, v5, v6

    new-array v6, v3, [B

    const/16 v12, 0x15

    aput-byte v12, v6, v7

    const/16 v12, 0x18

    aput-byte v12, v6, v8

    const/16 v12, 0x46

    aput-byte v12, v6, v9

    const/16 v12, -0x63

    aput-byte v12, v6, v11

    const/16 v12, -0x4e

    aput-byte v12, v6, v10

    const/16 v12, -0x63

    aput-byte v12, v6, v13

    const/16 v12, 0x27

    const/4 v14, 0x6

    aput-byte v12, v6, v14

    const/4 v12, 0x7

    aput-byte v7, v6, v12

    invoke-static {v5, v6}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    new-instance v5, Lorg/json/JSONObject;

    invoke-direct {v5}, Lorg/json/JSONObject;-><init>()V

    new-array v6, v11, [B

    const/16 v12, 0x49

    aput-byte v12, v6, v7

    const/16 v12, -0x74

    aput-byte v12, v6, v8

    const/16 v12, 0x3c

    aput-byte v12, v6, v9

    new-array v12, v3, [B

    const/16 v14, 0x3c

    aput-byte v14, v12, v7

    const/4 v14, -0x2

    aput-byte v14, v12, v8

    const/16 v14, 0x50

    aput-byte v14, v12, v9

    const/16 v14, -0x13

    aput-byte v14, v12, v11

    const/16 v14, -0x1e

    aput-byte v14, v12, v10

    aput-byte v13, v12, v13

    const/16 v14, 0x3d

    const/4 v15, 0x6

    aput-byte v14, v12, v15

    const/16 v14, 0x45

    const/4 v15, 0x7

    aput-byte v14, v12, v15

    invoke-static {v6, v12}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v5, v6, v4}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    new-array v4, v13, [B

    const/16 v6, 0x14

    aput-byte v6, v4, v7

    const/16 v6, -0x74

    aput-byte v6, v4, v8

    const/4 v6, -0x1

    aput-byte v6, v4, v9

    const/16 v6, -0xa

    aput-byte v6, v4, v11

    const/16 v6, 0x51

    aput-byte v6, v4, v10

    new-array v6, v3, [B

    const/16 v12, 0x60

    aput-byte v12, v6, v7

    const/16 v7, -0x1d

    aput-byte v7, v6, v8

    const/16 v7, -0x6c

    aput-byte v7, v6, v9

    const/16 v7, -0x6d

    aput-byte v7, v6, v11

    const/16 v7, 0x3f

    aput-byte v7, v6, v10

    const/16 v7, 0x4e

    aput-byte v7, v6, v13

    const/16 v7, 0x34

    const/4 v9, 0x6

    aput-byte v7, v6, v9

    const/16 v7, 0x4c

    const/4 v9, 0x7

    aput-byte v7, v6, v9

    invoke-static {v4, v6}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v5, v4, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    new-instance v2, Lcom/github/catvod/spider/appysv2/b/K;

    invoke-direct {v2, v1, v5, v8}, Lcom/github/catvod/spider/appysv2/b/K;-><init>(Ljava/lang/Object;Ljava/lang/Object;I)V

    invoke-static {v2}, Lcom/github/catvod/spider/Init;->run(Ljava/lang/Runnable;)V
    :try_end_b9f
    .catch Ljava/lang/Exception; {:try_start_6 .. :try_end_b9f} :catch_ba0

    goto :goto_bb6

    :catch_ba0
    move-exception v0

    move-object v2, v0

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const/16 v5, 0xd

    new-array v5, v5, [B

    fill-array-data v5, :array_bb8

    new-array v3, v3, [B

    fill-array-data v3, :array_bc4

    .line 1
    invoke-static {v5, v3, v4, v2}, Lcom/github/catvod/spider/appysv2/b/y;->b([B[BLjava/lang/StringBuilder;Ljava/lang/Exception;)V

    :goto_bb6
    return-void

    nop

    :array_bb8
    .array-data 1
        -0x35t
        -0x28t
        0x24t
        0x37t
        0x41t
        0x39t
        -0x45t
        -0xet
        -0x37t
        -0x63t
        0x35t
        0x5ct
        0x33t
    .end array-data

    nop

    :array_bc4
    .array-data 1
        -0x54t
        -0x43t
        0x50t
        0x66t
        0x13t
        0x7at
        -0x2ct
        -0x6at
    .end array-data
.end method

.method private E()Ljava/lang/String;
    .registers 3

    const/16 v0, 0x26

    new-array v0, v0, [B

    fill-array-data v0, :array_20

    const/16 v1, 0x8

    new-array v1, v1, [B

    fill-array-data v1, :array_38

    invoke-static {v0, v1}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-direct {p0}, Lcom/github/catvod/spider/appysv2/b/U;->y()Ljava/util/Map;

    move-result-object v1

    invoke-static {v0, v1}, Lcom/github/catvod/spider/appysv2/n/c;->b(Ljava/lang/String;Ljava/util/Map;)Lcom/github/catvod/spider/appysv2/n/e;

    move-result-object v0

    invoke-virtual {v0}, Lcom/github/catvod/spider/appysv2/n/e;->a()Ljava/lang/String;

    move-result-object v0

    return-object v0

    nop

    :array_20
    .array-data 1
        -0x42t
        0x36t
        0x8t
        0x6dt
        0x3et
        0x6at
        -0x6bt
        -0x12t
        -0x5at
        0x21t
        0x51t
        0x7ct
        0x3dt
        0x39t
        -0x6ct
        -0x4ct
        -0x4bt
        0x6ct
        0x1ft
        0x73t
        0x62t
        0x61t
        -0x6bt
        -0x5et
        -0x46t
        0x2dt
        0x9t
        0x79t
        0x29t
        0x22t
        -0x2dt
        -0x49t
        -0x4dt
        0x6dt
        0x1at
        0x74t
        0x21t
        0x35t
    .end array-data

    nop

    :array_38
    .array-data 1
        -0x2at
        0x42t
        0x7ct
        0x1dt
        0x4dt
        0x50t
        -0x46t
        -0x3ft
    .end array-data
.end method

.method private G(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    .registers 25

    move-object/from16 v1, p2

    const/16 v2, 0x26

    const/16 v3, 0x16

    const/16 v4, 0x8

    :try_start_8
    new-array v2, v2, [B

    const/16 v5, -0x5e

    const/4 v6, 0x0

    aput-byte v5, v2, v6

    const/16 v5, 0x23

    const/4 v7, 0x1

    aput-byte v5, v2, v7

    const/16 v5, -0x2f

    const/4 v8, 0x2

    aput-byte v5, v2, v8

    const/16 v5, -0x31

    const/4 v9, 0x3

    aput-byte v5, v2, v9

    const/16 v5, 0x11

    const/4 v10, 0x4

    aput-byte v5, v2, v10

    const/16 v11, -0x9

    const/4 v12, 0x5

    aput-byte v11, v2, v12

    const/4 v11, 0x7

    const/4 v13, 0x6

    aput-byte v11, v2, v13

    const/16 v14, 0x15

    aput-byte v14, v2, v11

    const/16 v14, -0x46

    aput-byte v14, v2, v4

    const/16 v14, 0x3e

    const/16 v15, 0x9

    aput-byte v14, v2, v15

    const/16 v14, -0x75

    const/16 v15, 0xa

    aput-byte v14, v2, v15

    const/16 v14, -0x26

    const/16 v15, 0xb

    aput-byte v14, v2, v15

    const/16 v14, 0x53

    const/16 v15, 0xc

    aput-byte v14, v2, v15

    const/16 v14, -0x54

    const/16 v15, 0xd

    aput-byte v14, v2, v15

    const/16 v14, 0x5b

    const/16 v15, 0xe

    aput-byte v14, v2, v15

    const/16 v14, 0x17

    const/16 v16, 0xf

    aput-byte v14, v2, v16

    const/16 v14, 0x10

    const/16 v16, -0x48

    aput-byte v16, v2, v14

    const/16 v14, 0x32

    aput-byte v14, v2, v5

    const/16 v14, -0x40

    const/16 v16, 0x12

    aput-byte v14, v2, v16

    const/16 v14, 0x13

    const/16 v17, -0x2f

    aput-byte v17, v2, v14

    const/16 v14, 0x14

    aput-byte v12, v2, v14

    const/16 v14, 0x15

    const/16 v17, -0x45

    aput-byte v17, v2, v14

    const/16 v14, 0x47

    aput-byte v14, v2, v3

    const/16 v14, 0x17

    const/16 v17, 0x19

    aput-byte v17, v2, v14

    const/16 v14, 0x18

    const/16 v17, -0x1b

    aput-byte v17, v2, v14

    const/16 v14, 0x19

    const/16 v17, 0x22

    aput-byte v17, v2, v14

    const/16 v14, 0x1a

    const/16 v17, -0x3a

    aput-byte v17, v2, v14

    const/16 v14, 0x1b

    const/16 v17, -0x25

    aput-byte v17, v2, v14

    const/16 v14, 0x1c

    const/16 v17, 0x59

    aput-byte v17, v2, v14

    const/16 v14, 0x1d

    const/16 v17, -0x4f

    aput-byte v17, v2, v14

    const/16 v14, 0x1e

    const/16 v17, 0x5e

    aput-byte v17, v2, v14

    const/16 v14, 0x1f

    aput-byte v5, v2, v14

    const/16 v5, 0x20

    const/16 v14, -0x1b

    aput-byte v14, v2, v5

    const/16 v5, 0x21

    const/16 v14, 0x23

    aput-byte v14, v2, v5

    const/16 v5, 0x22

    const/16 v14, -0x36

    aput-byte v14, v2, v5

    const/16 v5, 0x23

    const/16 v14, -0x2c

    aput-byte v14, v2, v5

    const/16 v5, 0x24

    const/16 v14, 0x4e

    aput-byte v14, v2, v5

    const/16 v5, 0x25

    const/16 v14, -0x4a

    aput-byte v14, v2, v5

    new-array v5, v4, [B

    const/16 v14, -0x36

    aput-byte v14, v5, v6

    const/16 v14, 0x57

    aput-byte v14, v5, v7

    const/16 v14, -0x5b

    aput-byte v14, v5, v8

    const/16 v17, -0x41

    aput-byte v17, v5, v9

    const/16 v17, 0x2b

    aput-byte v17, v5, v10

    const/16 v17, -0x28

    aput-byte v17, v5, v12

    const/16 v17, 0x28

    aput-byte v17, v5, v13

    const/16 v17, 0x74

    aput-byte v17, v5, v11

    invoke-static {v2, v5}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v2

    new-instance v5, Lorg/json/JSONObject;

    invoke-direct {v5}, Lorg/json/JSONObject;-><init>()V

    new-array v15, v13, [B

    const/16 v18, -0xb

    aput-byte v18, v15, v6

    const/16 v18, -0x5e

    aput-byte v18, v15, v7

    const/16 v18, 0x77

    aput-byte v18, v15, v8

    const/16 v19, 0x49

    aput-byte v19, v15, v9

    const/16 v19, 0x3b

    aput-byte v19, v15, v10

    const/16 v19, 0x2c

    aput-byte v19, v15, v12

    new-array v14, v4, [B

    const/16 v20, -0x79

    aput-byte v20, v14, v6

    const/16 v20, -0x39

    aput-byte v20, v14, v7

    aput-byte v13, v14, v8

    aput-byte v3, v14, v9

    const/16 v3, 0x52

    aput-byte v3, v14, v10

    const/16 v3, 0x48

    aput-byte v3, v14, v12

    const/16 v3, 0x6c

    aput-byte v3, v14, v13

    aput-byte v18, v14, v11

    invoke-static {v15, v14}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v3

    move-object/from16 v14, p1

    invoke-virtual {v5, v3, v14}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    new-array v3, v11, [B

    const/16 v14, -0x40

    aput-byte v14, v3, v6

    const/16 v14, -0x3a

    aput-byte v14, v3, v7

    const/16 v14, -0x7c

    aput-byte v14, v3, v8

    const/16 v14, 0x65

    aput-byte v14, v3, v9

    const/16 v14, 0x72

    aput-byte v14, v3, v10

    const/16 v14, -0x23

    aput-byte v14, v3, v12

    const/16 v14, -0x33

    aput-byte v14, v3, v13

    new-array v14, v4, [B

    const/16 v15, -0x5f

    aput-byte v15, v14, v6

    const/16 v15, -0x4a

    aput-byte v15, v14, v7

    const/16 v15, -0xc

    aput-byte v15, v14, v8

    const/16 v15, 0x3a

    aput-byte v15, v14, v9

    aput-byte v10, v14, v10

    const/16 v15, -0x48

    aput-byte v15, v14, v12

    const/16 v15, -0x41

    aput-byte v15, v14, v13

    const/16 v15, -0xc

    aput-byte v15, v14, v11

    invoke-static {v3, v14}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v3

    new-array v14, v12, [B

    aput-byte v13, v14, v6

    const/16 v15, 0xf

    aput-byte v15, v14, v7

    const/16 v15, 0x1f

    aput-byte v15, v14, v8

    const/16 v15, 0x31

    aput-byte v15, v14, v9

    const/16 v15, 0xc

    aput-byte v15, v14, v10

    new-array v15, v4, [B

    const/16 v20, 0x37

    aput-byte v20, v15, v6

    const/16 v20, 0x21

    aput-byte v20, v15, v7

    const/16 v20, 0x29

    aput-byte v20, v15, v8

    const/16 v20, 0x1f

    aput-byte v20, v15, v9

    const/16 v20, 0x34

    aput-byte v20, v15, v10

    const/16 v20, 0x7d

    aput-byte v20, v15, v12

    const/16 v20, -0x14

    aput-byte v20, v15, v13

    const/16 v20, 0x35

    aput-byte v20, v15, v11

    invoke-static {v14, v15}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v14

    invoke-virtual {v5, v3, v14}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/16 v3, 0x9

    new-array v3, v3, [B

    aput-byte v18, v3, v6

    const/16 v14, 0x16

    aput-byte v14, v3, v7

    const/16 v14, -0x19

    aput-byte v14, v3, v8

    const/16 v14, -0x49

    aput-byte v14, v3, v9

    const/16 v14, 0x35

    aput-byte v14, v3, v10

    const/4 v14, -0x6

    aput-byte v14, v3, v12

    const/16 v14, -0x1d

    aput-byte v14, v3, v13

    const/16 v14, -0x80

    aput-byte v14, v3, v11

    aput-byte v18, v3, v4

    new-array v14, v4, [B

    const/16 v15, 0x13

    aput-byte v15, v14, v6

    const/16 v15, 0x73

    aput-byte v15, v14, v7

    const/16 v15, -0x6f

    aput-byte v15, v14, v8

    const/16 v15, -0x22

    aput-byte v15, v14, v9

    const/16 v15, 0x56

    aput-byte v15, v14, v10

    const/16 v15, -0x61

    aput-byte v15, v14, v12

    const/16 v15, -0x44

    aput-byte v15, v14, v13

    const/16 v15, -0x17

    aput-byte v15, v14, v11

    invoke-static {v3, v14}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v5, v3, v1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/16 v3, 0xc

    new-array v3, v3, [B

    const/16 v14, 0x5b

    aput-byte v14, v3, v6

    const/4 v14, -0x8

    aput-byte v14, v3, v7

    const/16 v14, 0x54

    aput-byte v14, v3, v8

    const/16 v14, -0x5b

    aput-byte v14, v3, v9

    const/16 v14, -0x24

    aput-byte v14, v3, v10

    const/16 v14, 0x4a

    aput-byte v14, v3, v12

    const/16 v14, -0x33

    aput-byte v14, v3, v13

    const/16 v14, 0x59

    aput-byte v14, v3, v11

    const/16 v14, 0x4d

    aput-byte v14, v3, v4

    const/4 v14, -0x4

    const/16 v15, 0x9

    aput-byte v14, v3, v15

    const/16 v14, 0x4c

    const/16 v15, 0xa

    aput-byte v14, v3, v15

    const/16 v14, -0x58

    const/16 v15, 0xb

    aput-byte v14, v3, v15

    new-array v14, v4, [B

    const/16 v15, 0x3f

    aput-byte v15, v14, v6

    const/16 v15, -0x63

    aput-byte v15, v14, v7

    const/16 v15, 0x22

    aput-byte v15, v14, v8

    const/16 v15, -0x34

    aput-byte v15, v14, v9

    const/16 v15, -0x41

    aput-byte v15, v14, v10

    const/16 v15, 0x2f

    aput-byte v15, v14, v12

    const/16 v15, -0x6e

    aput-byte v15, v14, v13

    const/16 v15, 0x3b

    aput-byte v15, v14, v11

    invoke-static {v3, v14}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v3

    new-array v14, v10, [B

    const/16 v15, -0x54

    aput-byte v15, v14, v6

    const/16 v15, 0x58

    aput-byte v15, v14, v7

    const/16 v15, 0x30

    aput-byte v15, v14, v8

    const/16 v15, 0x30

    aput-byte v15, v14, v9

    new-array v15, v4, [B

    const/16 v20, -0x26

    aput-byte v20, v15, v6

    const/16 v20, 0x31

    aput-byte v20, v15, v7

    const/16 v20, 0x46

    aput-byte v20, v15, v8

    const/16 v20, 0x5f

    aput-byte v20, v15, v9

    const/16 v20, -0x41

    aput-byte v20, v15, v10

    const/16 v20, -0x4

    aput-byte v20, v15, v12

    const/16 v20, -0x49

    aput-byte v20, v15, v13

    const/16 v20, -0x22

    aput-byte v20, v15, v11

    invoke-static {v14, v15}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v14

    invoke-virtual {v5, v3, v14}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    new-array v3, v4, [B

    aput-byte v16, v3, v6

    const/16 v14, 0x19

    aput-byte v14, v3, v7

    const/16 v14, -0x79

    aput-byte v14, v3, v8

    const/16 v14, -0x71

    aput-byte v14, v3, v9

    const/16 v14, -0x65

    aput-byte v14, v3, v10

    const/16 v14, -0x7e

    aput-byte v14, v3, v12

    const/16 v14, 0x16

    aput-byte v14, v3, v13

    aput-byte v18, v3, v11

    new-array v14, v4, [B

    const/16 v15, 0x62

    aput-byte v15, v14, v6

    const/16 v15, 0x75

    aput-byte v15, v14, v7

    const/16 v15, -0x1a

    aput-byte v15, v14, v8

    const/4 v15, -0x5

    aput-byte v15, v14, v9

    const/4 v15, -0x3

    aput-byte v15, v14, v10

    const/16 v15, -0x13

    aput-byte v15, v14, v12

    const/16 v15, 0x64

    aput-byte v15, v14, v13

    const/16 v15, 0x1a

    aput-byte v15, v14, v11

    invoke-static {v3, v14}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v3

    new-array v14, v8, [B

    const/16 v15, 0x72

    aput-byte v15, v14, v6

    const/16 v15, 0x52

    aput-byte v15, v14, v7

    new-array v15, v4, [B

    aput-byte v13, v15, v6

    const/16 v20, 0x24

    aput-byte v20, v15, v7

    const/16 v19, -0x5b

    aput-byte v19, v15, v8

    const/16 v20, 0x39

    aput-byte v20, v15, v9

    const/16 v20, -0x10

    aput-byte v20, v15, v10

    const/16 v20, 0x2e

    aput-byte v20, v15, v12

    const/16 v20, 0x29

    aput-byte v20, v15, v13

    const/16 v20, 0x7f

    aput-byte v20, v15, v11

    invoke-static {v14, v15}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v14

    invoke-virtual {v5, v3, v14}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/16 v3, 0xb

    new-array v3, v3, [B

    const/16 v14, 0x78

    aput-byte v14, v3, v6

    const/16 v14, -0x4c

    aput-byte v14, v3, v7

    const/16 v14, -0x38

    aput-byte v14, v3, v8

    const/16 v14, -0x62

    aput-byte v14, v3, v9

    const/16 v14, -0x3f

    aput-byte v14, v3, v10

    const/16 v14, -0x6d

    aput-byte v14, v3, v12

    const/16 v14, 0x29

    aput-byte v14, v3, v13

    const/16 v14, 0x4a

    aput-byte v14, v3, v11

    const/16 v14, 0x7d

    aput-byte v14, v3, v4

    const/16 v14, -0x44

    const/16 v15, 0x9

    aput-byte v14, v3, v15

    const/16 v14, -0x25

    const/16 v15, 0xa

    aput-byte v14, v3, v15

    new-array v14, v4, [B

    const/16 v15, 0x1c

    aput-byte v15, v14, v6

    const/16 v15, -0x2f

    aput-byte v15, v14, v7

    const/16 v15, -0x42

    aput-byte v15, v14, v8

    const/16 v15, -0x9

    aput-byte v15, v14, v9

    const/16 v15, -0x5e

    aput-byte v15, v14, v10

    const/16 v15, -0xa

    aput-byte v15, v14, v12

    const/16 v15, 0x76

    aput-byte v15, v14, v13

    const/16 v15, 0x24

    aput-byte v15, v14, v11

    invoke-static {v3, v14}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v3

    new-array v14, v13, [B

    const/16 v15, -0x1b

    aput-byte v15, v14, v6

    const/16 v15, 0x3a

    aput-byte v15, v14, v7

    const/16 v15, -0x13

    aput-byte v15, v14, v8

    const/16 v15, -0x7e

    aput-byte v15, v14, v9

    const/16 v15, -0x56

    aput-byte v15, v14, v10

    const/16 v15, -0x4a

    aput-byte v15, v14, v12

    new-array v15, v4, [B

    const/16 v20, -0x4d

    aput-byte v20, v15, v6

    aput-byte v4, v15, v7

    const/16 v20, -0x21

    aput-byte v20, v15, v8

    const/16 v20, -0x4f

    aput-byte v20, v15, v9

    const/16 v20, -0x6e

    aput-byte v20, v15, v10

    const/16 v20, -0x9

    aput-byte v20, v15, v12

    const/16 v20, 0x7f

    aput-byte v20, v15, v13

    const/16 v20, -0x34

    aput-byte v20, v15, v11

    invoke-static {v14, v15}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v14

    invoke-virtual {v5, v3, v14}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/16 v3, 0xc

    new-array v3, v3, [B

    const/16 v14, 0x20

    aput-byte v14, v3, v6

    const/16 v14, -0x56

    aput-byte v14, v3, v7

    const/16 v14, -0x6f

    aput-byte v14, v3, v8

    const/16 v14, 0x54

    aput-byte v14, v3, v9

    const/16 v14, 0x2d

    aput-byte v14, v3, v10

    const/16 v14, -0x5a

    aput-byte v14, v3, v12

    aput-byte v4, v3, v13

    const/16 v14, -0x45

    aput-byte v14, v3, v11

    const/16 v14, 0x2b

    aput-byte v14, v3, v4

    const/16 v14, -0x55

    const/16 v15, 0x9

    aput-byte v14, v3, v15

    const/16 v14, -0x7e

    const/16 v15, 0xa

    aput-byte v14, v3, v15

    const/16 v14, 0x51

    const/16 v15, 0xb

    aput-byte v14, v3, v15

    new-array v14, v4, [B

    const/16 v15, 0x44

    aput-byte v15, v14, v6

    const/16 v15, -0x31

    aput-byte v15, v14, v7

    const/16 v15, -0x19

    aput-byte v15, v14, v8

    const/16 v15, 0x3d

    aput-byte v15, v14, v9

    const/16 v15, 0x4e

    aput-byte v15, v14, v10

    const/16 v15, -0x3d

    aput-byte v15, v14, v12

    const/16 v15, 0x57

    aput-byte v15, v14, v13

    const/16 v15, -0x2a

    aput-byte v15, v14, v11

    invoke-static {v3, v14}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v3

    new-array v14, v13, [B

    const/4 v15, -0x8

    aput-byte v15, v14, v6

    const/16 v15, -0x10

    aput-byte v15, v14, v7

    const/16 v15, 0x67

    aput-byte v15, v14, v8

    const/16 v15, -0x59

    aput-byte v15, v14, v9

    const/16 v15, 0x70

    aput-byte v15, v14, v10

    const/16 v15, -0x25

    aput-byte v15, v14, v12

    new-array v15, v4, [B

    const/16 v20, -0x52

    aput-byte v20, v15, v6

    const/16 v20, -0x3e

    aput-byte v20, v15, v7

    const/16 v20, 0x55

    aput-byte v20, v15, v8

    const/16 v20, -0x6c

    aput-byte v20, v15, v9

    const/16 v20, 0x48

    aput-byte v20, v15, v10

    const/16 v20, -0x66

    aput-byte v20, v15, v12

    const/16 v20, 0x5f

    aput-byte v20, v15, v13

    const/16 v20, 0x13

    aput-byte v20, v15, v11

    invoke-static {v14, v15}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v14

    invoke-virtual {v5, v3, v14}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/16 v3, 0xc

    new-array v14, v3, [B

    const/16 v15, -0x64

    aput-byte v15, v14, v6

    const/16 v15, -0x37

    aput-byte v15, v14, v7

    const/16 v15, -0x1e

    aput-byte v15, v14, v8

    aput-byte v3, v14, v9

    const/16 v3, 0x6c

    aput-byte v3, v14, v10

    const/16 v3, -0x30

    aput-byte v3, v14, v12

    const/16 v3, -0x26

    aput-byte v3, v14, v13

    const/4 v3, -0x2

    aput-byte v3, v14, v11

    const/16 v3, -0x78

    aput-byte v3, v14, v4

    const/16 v3, -0x2b

    const/16 v15, 0x9

    aput-byte v3, v14, v15

    const/16 v3, -0x18

    const/16 v15, 0xa

    aput-byte v3, v14, v15

    const/16 v3, 0xb

    aput-byte v12, v14, v3

    new-array v3, v4, [B

    const/4 v15, -0x2

    aput-byte v15, v3, v6

    const/16 v15, -0x44

    aput-byte v15, v3, v7

    const/16 v15, -0x75

    aput-byte v15, v3, v8

    const/16 v15, 0x60

    aput-byte v15, v3, v9

    aput-byte v4, v3, v10

    const/16 v15, -0x71

    aput-byte v15, v3, v12

    const/16 v15, -0x42

    aput-byte v15, v3, v13

    const/16 v15, -0x65

    aput-byte v15, v3, v11

    invoke-static {v14, v3}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v3

    new-array v14, v13, [B

    const/16 v15, -0x14

    aput-byte v15, v14, v6

    const/16 v15, 0x57

    aput-byte v15, v14, v7

    const/4 v15, -0x2

    aput-byte v15, v14, v8

    const/16 v15, 0x57

    aput-byte v15, v14, v9

    const/16 v15, 0x57

    aput-byte v15, v14, v10

    const/16 v15, -0x37

    aput-byte v15, v14, v12

    new-array v15, v4, [B

    const/16 v20, -0x46

    aput-byte v20, v15, v6

    const/16 v20, 0x65

    aput-byte v20, v15, v7

    const/16 v20, -0x34

    aput-byte v20, v15, v8

    const/16 v20, 0x64

    aput-byte v20, v15, v9

    const/16 v20, 0x6f

    aput-byte v20, v15, v10

    const/16 v20, -0x78

    aput-byte v20, v15, v12

    aput-byte v8, v15, v13

    const/16 v20, 0x1d

    aput-byte v20, v15, v11

    invoke-static {v14, v15}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v14

    invoke-virtual {v5, v3, v14}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/16 v3, 0xd

    new-array v3, v3, [B

    const/16 v14, -0xa

    aput-byte v14, v3, v6

    const/16 v14, 0x4b

    aput-byte v14, v3, v7

    const/16 v14, -0x9

    aput-byte v14, v3, v8

    const/16 v14, 0xe

    aput-byte v14, v3, v9

    const/16 v14, -0x2e

    aput-byte v14, v3, v10

    const/16 v14, -0x4d

    aput-byte v14, v3, v12

    aput-byte v7, v3, v13

    const/16 v14, 0x66

    aput-byte v14, v3, v11

    const/4 v14, -0x5

    aput-byte v14, v3, v4

    const/16 v14, 0x5a

    const/16 v15, 0x9

    aput-byte v14, v3, v15

    const/16 v14, -0x15

    const/16 v15, 0xa

    aput-byte v14, v3, v15

    const/16 v14, 0xb

    aput-byte v7, v3, v14

    const/16 v14, -0x3e

    const/16 v15, 0xc

    aput-byte v14, v3, v15

    new-array v14, v4, [B

    const/16 v15, -0x6c

    aput-byte v15, v14, v6

    const/16 v15, 0x3e

    aput-byte v15, v14, v7

    const/16 v15, -0x62

    aput-byte v15, v14, v8

    const/16 v15, 0x62

    aput-byte v15, v14, v9

    const/16 v15, -0x4a

    aput-byte v15, v14, v10

    const/16 v15, -0x14

    aput-byte v15, v14, v12

    const/16 v15, 0x71

    aput-byte v15, v14, v13

    const/16 v15, 0x14

    aput-byte v15, v14, v11

    invoke-static {v3, v14}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v3

    new-array v14, v13, [B

    const/16 v15, -0x46

    aput-byte v15, v14, v6

    const/16 v15, 0x50

    aput-byte v15, v14, v7

    const/16 v15, -0x4f

    aput-byte v15, v14, v8

    const/16 v15, 0x47

    aput-byte v15, v14, v9

    const/16 v15, -0x3e

    aput-byte v15, v14, v10

    const/16 v15, -0x6e

    aput-byte v15, v14, v12

    new-array v15, v4, [B

    const/16 v20, -0x14

    aput-byte v20, v15, v6

    const/16 v20, 0x62

    aput-byte v20, v15, v7

    const/16 v20, -0x7d

    aput-byte v20, v15, v8

    const/16 v20, 0x74

    aput-byte v20, v15, v9

    const/16 v20, -0x6

    aput-byte v20, v15, v10

    const/16 v20, -0x2d

    aput-byte v20, v15, v12

    const/16 v20, 0x7a

    aput-byte v20, v15, v13

    aput-byte v16, v15, v11

    invoke-static {v14, v15}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v14

    invoke-virtual {v5, v3, v14}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/16 v3, 0xa

    new-array v3, v3, [B

    const/16 v14, 0x59

    aput-byte v14, v3, v6

    const/16 v14, 0x62

    aput-byte v14, v3, v7

    const/16 v14, -0x4c

    aput-byte v14, v3, v8

    const/4 v14, -0x4

    aput-byte v14, v3, v9

    const/16 v14, 0x68

    aput-byte v14, v3, v10

    const/16 v14, 0x66

    aput-byte v14, v3, v12

    const/16 v14, -0x74

    aput-byte v14, v3, v13

    const/16 v14, 0x39

    aput-byte v14, v3, v11

    const/16 v14, 0x4d

    aput-byte v14, v3, v4

    const/16 v14, 0x72

    const/16 v15, 0x9

    aput-byte v14, v3, v15

    new-array v14, v4, [B

    const/16 v15, 0x3d

    aput-byte v15, v14, v6

    aput-byte v11, v14, v7

    const/16 v15, -0x3e

    aput-byte v15, v14, v8

    const/16 v15, -0x6b

    aput-byte v15, v14, v9

    const/16 v15, 0xb

    aput-byte v15, v14, v10

    aput-byte v9, v14, v12

    const/16 v15, -0x2d

    aput-byte v15, v14, v13

    const/16 v15, 0x5e

    aput-byte v15, v14, v11

    invoke-static {v3, v14}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v3

    const/16 v14, 0xf

    new-array v14, v14, [B

    const/16 v15, 0x1b

    aput-byte v15, v14, v6

    const/16 v15, -0x2f

    aput-byte v15, v14, v7

    const/16 v15, -0x70

    aput-byte v15, v14, v8

    aput-byte v16, v14, v9

    const/16 v15, 0x61

    aput-byte v15, v14, v10

    const/16 v15, 0x29

    aput-byte v15, v14, v12

    const/16 v15, -0x7b

    aput-byte v15, v14, v13

    const/16 v15, -0x72

    aput-byte v15, v14, v11

    const/16 v15, 0xe

    aput-byte v15, v14, v4

    const/4 v15, -0x8

    const/16 v20, 0x9

    aput-byte v15, v14, v20

    const/16 v15, -0x35

    const/16 v20, 0xa

    aput-byte v15, v14, v20

    const/16 v15, 0x57

    const/16 v20, 0xb

    aput-byte v15, v14, v20

    const/16 v15, 0x39

    const/16 v20, 0xc

    aput-byte v15, v14, v20

    const/16 v15, 0x72

    const/16 v20, 0xd

    aput-byte v15, v14, v20

    const/16 v15, -0x6b

    const/16 v17, 0xe

    aput-byte v15, v14, v17

    new-array v15, v4, [B

    const/16 v20, 0x5a

    aput-byte v20, v15, v6

    const/16 v20, -0x4b

    aput-byte v20, v15, v7

    const/16 v20, -0x1e

    aput-byte v20, v15, v8

    aput-byte v18, v15, v9

    const/16 v20, 0xf

    aput-byte v20, v15, v10

    const/16 v20, 0x46

    aput-byte v20, v15, v12

    const/16 v19, -0x5b

    aput-byte v19, v15, v13

    const/16 v20, -0x5a

    aput-byte v20, v15, v11

    invoke-static {v14, v15}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v14

    invoke-virtual {v5, v3, v14}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/16 v3, 0xd

    new-array v3, v3, [B

    const/16 v14, -0x36

    aput-byte v14, v3, v6

    const/16 v14, 0x11

    aput-byte v14, v3, v7

    const/16 v15, 0x15

    aput-byte v15, v3, v8

    aput-byte v14, v3, v9

    const/16 v14, -0x6e

    aput-byte v14, v3, v10

    const/16 v14, 0x36

    aput-byte v14, v3, v12

    const/16 v14, -0x27

    aput-byte v14, v3, v13

    const/16 v14, 0x62

    aput-byte v14, v3, v11

    const/16 v14, -0xc

    aput-byte v14, v3, v4

    const/16 v14, 0x9

    aput-byte v6, v3, v14

    const/16 v14, 0xa

    aput-byte v10, v3, v14

    const/16 v14, 0x1b

    const/16 v15, 0xb

    aput-byte v14, v3, v15

    const/16 v14, -0x70

    const/16 v15, 0xc

    aput-byte v14, v3, v15

    new-array v14, v4, [B

    const/16 v15, -0x55

    aput-byte v15, v14, v6

    const/16 v15, 0x72

    aput-byte v15, v14, v7

    const/16 v15, 0x61

    aput-byte v15, v14, v8

    const/16 v15, 0x78

    aput-byte v15, v14, v9

    const/16 v15, -0x1c

    aput-byte v15, v14, v10

    const/16 v15, 0x5f

    aput-byte v15, v14, v12

    const/16 v15, -0x53

    aput-byte v15, v14, v13

    const/16 v15, 0x1b

    aput-byte v15, v14, v11

    invoke-static {v3, v14}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v3

    new-array v14, v8, [B

    const/16 v15, -0x45

    aput-byte v15, v14, v6

    const/16 v15, -0x76

    aput-byte v15, v14, v7

    new-array v15, v4, [B

    const/16 v20, -0x40

    aput-byte v20, v15, v6

    const/16 v20, -0x9

    aput-byte v20, v15, v7

    const/16 v20, 0x4a

    aput-byte v20, v15, v8

    const/16 v20, -0x38

    aput-byte v20, v15, v9

    aput-byte v18, v15, v10

    const/16 v20, -0x5d

    aput-byte v20, v15, v12

    const/16 v20, -0x2e

    aput-byte v20, v15, v13

    const/16 v20, 0x5a

    aput-byte v20, v15, v11

    invoke-static {v14, v15}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v14

    invoke-virtual {v5, v3, v14}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    new-array v3, v11, [B

    const/16 v14, -0x62

    aput-byte v14, v3, v6

    const/16 v14, 0x6b

    aput-byte v14, v3, v7

    const/16 v14, 0x31

    aput-byte v14, v3, v8

    const/16 v14, -0x78

    aput-byte v14, v3, v9

    const/16 v14, 0x25

    aput-byte v14, v3, v10

    const/16 v14, -0x1a

    aput-byte v14, v3, v12

    const/16 v14, -0x3c

    aput-byte v14, v3, v13

    new-array v14, v4, [B

    const/4 v15, -0x3

    aput-byte v15, v14, v6

    aput-byte v9, v14, v7

    const/16 v15, 0x50

    aput-byte v15, v14, v8

    const/16 v15, -0x1a

    aput-byte v15, v14, v9

    const/16 v15, 0x4b

    aput-byte v15, v14, v10

    const/16 v15, -0x7d

    aput-byte v15, v14, v12

    const/16 v15, -0x58

    aput-byte v15, v14, v13

    const/16 v15, -0x59

    aput-byte v15, v14, v11

    invoke-static {v3, v14}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v3

    const/16 v14, 0xf

    new-array v14, v14, [B

    const/16 v15, -0x44

    aput-byte v15, v14, v6

    const/16 v15, -0x78

    aput-byte v15, v14, v7

    const/16 v15, -0x28

    aput-byte v15, v14, v8

    const/16 v15, -0x61

    aput-byte v15, v14, v9

    const/16 v15, -0x75

    aput-byte v15, v14, v10

    const/16 v15, -0x54

    aput-byte v15, v14, v12

    const/16 v15, -0x1d

    aput-byte v15, v14, v13

    const/16 v15, 0x5f

    aput-byte v15, v14, v11

    const/16 v15, -0x56

    aput-byte v15, v14, v4

    const/16 v15, -0x7e

    const/16 v20, 0x9

    aput-byte v15, v14, v20

    const/16 v15, -0x33

    const/16 v20, 0xa

    aput-byte v15, v14, v20

    const/16 v15, -0x7b

    const/16 v20, 0xb

    aput-byte v15, v14, v20

    const/16 v15, -0x6d

    const/16 v20, 0xc

    aput-byte v15, v14, v20

    const/16 v15, -0x51

    const/16 v20, 0xd

    aput-byte v15, v14, v20

    const/16 v15, -0x19

    const/16 v17, 0xe

    aput-byte v15, v14, v17

    new-array v15, v4, [B

    const/16 v20, -0x17

    aput-byte v20, v15, v6

    const/16 v20, -0x35

    aput-byte v20, v15, v7

    const/16 v20, -0x74

    aput-byte v20, v15, v8

    const/16 v20, -0x37

    aput-byte v20, v15, v9

    const/16 v20, -0x3c

    aput-byte v20, v15, v10

    const/16 v20, -0x16

    aput-byte v20, v15, v12

    const/16 v19, -0x5b

    aput-byte v19, v15, v13

    const/16 v20, 0x16

    aput-byte v20, v15, v11

    invoke-static {v14, v15}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v14

    invoke-virtual {v5, v3, v14}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    invoke-static/range {p3 .. p3}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v3

    if-eqz v3, :cond_878

    const/16 v3, 0xd

    new-array v3, v3, [B

    const/16 v14, -0x34

    aput-byte v14, v3, v6

    const/16 v14, -0x6a

    aput-byte v14, v3, v7

    const/16 v14, 0x64

    aput-byte v14, v3, v8

    const/16 v14, -0x79

    aput-byte v14, v3, v9

    const/16 v14, 0x38

    aput-byte v14, v3, v10

    const/16 v14, -0x4e

    aput-byte v14, v3, v12

    const/16 v14, -0x2e

    aput-byte v14, v3, v13

    const/16 v14, 0x60

    aput-byte v14, v3, v11

    const/16 v14, -0x36

    aput-byte v14, v3, v4

    const/16 v14, -0x64

    const/16 v15, 0x9

    aput-byte v14, v3, v15

    const/16 v14, 0x69

    const/16 v15, 0xa

    aput-byte v14, v3, v15

    const/16 v14, -0x70

    const/16 v15, 0xb

    aput-byte v14, v3, v15

    const/16 v14, 0x33

    const/16 v15, 0xc

    aput-byte v14, v3, v15

    new-array v4, v4, [B

    const/16 v14, -0x42

    aput-byte v14, v4, v6

    const/16 v14, -0xd

    aput-byte v14, v4, v7

    aput-byte v8, v4, v8

    const/16 v14, -0xb

    aput-byte v14, v4, v9

    const/16 v14, 0x5d

    aput-byte v14, v4, v10

    const/16 v14, -0x3f

    aput-byte v14, v4, v12

    const/16 v14, -0x46

    aput-byte v14, v4, v13

    const/16 v14, 0x3f

    aput-byte v14, v4, v11

    invoke-static {v3, v4}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v3
    :try_end_800
    .catch Ljava/lang/Exception; {:try_start_8 .. :try_end_800} :catch_ece

    move-object/from16 v4, p0

    :try_start_802
    iget-object v11, v4, Lcom/github/catvod/spider/appysv2/b/U;->b:Lorg/json/JSONObject;

    const/16 v14, 0xd

    new-array v14, v14, [B

    const/16 v15, -0x5d

    aput-byte v15, v14, v6

    const/16 v15, 0x28

    aput-byte v15, v14, v7

    const/16 v15, 0x20

    aput-byte v15, v14, v8

    const/16 v15, -0x3e

    aput-byte v15, v14, v9

    const/16 v15, -0x73

    aput-byte v15, v14, v10

    const/16 v15, -0x2a

    aput-byte v15, v14, v12

    const/16 v15, -0x1e

    aput-byte v15, v14, v13

    const/16 v13, -0x40

    const/4 v15, 0x7

    aput-byte v13, v14, v15

    const/16 v13, 0x8

    const/16 v15, -0x5b

    aput-byte v15, v14, v13

    const/16 v13, 0x22

    const/16 v15, 0x9

    aput-byte v13, v14, v15

    const/16 v13, 0x2d

    const/16 v15, 0xa

    aput-byte v13, v14, v15

    const/16 v13, -0x2b

    const/16 v15, 0xb

    aput-byte v13, v14, v15

    const/16 v13, -0x7a

    const/16 v15, 0xc

    aput-byte v13, v14, v15

    const/16 v13, 0x8

    new-array v13, v13, [B

    const/16 v15, -0x2f

    aput-byte v15, v13, v6

    const/16 v15, 0x4d

    aput-byte v15, v13, v7

    const/16 v15, 0x46

    aput-byte v15, v13, v8

    const/16 v15, -0x50

    aput-byte v15, v13, v9

    const/16 v15, -0x18

    aput-byte v15, v13, v10

    const/16 v15, -0x5b

    aput-byte v15, v13, v12

    const/16 v15, -0x76

    const/16 v20, 0x6

    aput-byte v15, v13, v20

    const/16 v15, -0x61

    const/16 v20, 0x7

    aput-byte v15, v13, v20

    invoke-static {v14, v13}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v13

    invoke-virtual {v11, v13}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v11

    goto :goto_8b8

    :cond_878
    move-object/from16 v4, p0

    new-array v3, v10, [B

    const/16 v11, -0x30

    aput-byte v11, v3, v6

    const/16 v11, 0x41

    aput-byte v11, v3, v7

    const/16 v11, -0x50

    aput-byte v11, v3, v8

    const/16 v11, -0x7e

    aput-byte v11, v3, v9

    const/16 v11, 0x8

    new-array v11, v11, [B

    const/16 v13, -0x4d

    aput-byte v13, v11, v6

    const/16 v13, 0x2e

    aput-byte v13, v11, v7

    const/16 v13, -0x2c

    aput-byte v13, v11, v8

    const/16 v13, -0x19

    aput-byte v13, v11, v9

    const/16 v13, -0x3d

    aput-byte v13, v11, v10

    const/16 v13, -0xa

    aput-byte v13, v11, v12

    const/16 v13, 0x39

    const/4 v14, 0x6

    aput-byte v13, v11, v14

    const/16 v13, 0x7e

    const/4 v14, 0x7

    aput-byte v13, v11, v14

    invoke-static {v3, v11}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v3

    move-object/from16 v11, p3

    :goto_8b8
    invoke-virtual {v5, v3, v11}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    new-instance v3, Ljava/util/HashMap;

    invoke-direct {v3}, Ljava/util/HashMap;-><init>()V

    const/16 v11, 0xa

    new-array v11, v11, [B

    const/16 v13, 0x78

    aput-byte v13, v11, v6

    const/16 v13, -0x25

    aput-byte v13, v11, v7

    const/16 v13, 0x42

    aput-byte v13, v11, v8

    const/16 v13, 0x2a

    aput-byte v13, v11, v9

    const/16 v13, -0x43

    aput-byte v13, v11, v10

    const/16 v13, 0x1a

    aput-byte v13, v11, v12

    const/16 v13, -0x4e

    const/4 v14, 0x6

    aput-byte v13, v11, v14

    const/16 v13, -0x24

    const/4 v14, 0x7

    aput-byte v13, v11, v14

    const/16 v13, 0x43

    const/16 v14, 0x8

    aput-byte v13, v11, v14

    const/16 v13, -0x24

    const/16 v15, 0x9

    aput-byte v13, v11, v15

    new-array v13, v14, [B

    const/16 v14, 0x2d

    aput-byte v14, v13, v6

    const/16 v14, -0x58

    aput-byte v14, v13, v7

    const/16 v14, 0x27

    aput-byte v14, v13, v8

    const/16 v14, 0x58

    aput-byte v14, v13, v9

    const/16 v14, -0x70

    aput-byte v14, v13, v10

    const/16 v14, 0x5b

    aput-byte v14, v13, v12

    const/16 v14, -0x2b

    const/4 v15, 0x6

    aput-byte v14, v13, v15

    const/16 v14, -0x47

    const/4 v15, 0x7

    aput-byte v14, v13, v15

    invoke-static {v11, v13}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v11

    const/16 v13, 0x78

    new-array v13, v13, [B

    const/16 v14, -0x6a

    aput-byte v14, v13, v6

    const/16 v14, 0x50

    aput-byte v14, v13, v7

    const/16 v14, -0x11

    aput-byte v14, v13, v8

    aput-byte v16, v13, v9

    const/16 v14, -0x80

    aput-byte v14, v13, v10

    const/4 v14, -0x8

    aput-byte v14, v13, v12

    const/16 v14, -0x51

    const/4 v15, 0x6

    aput-byte v14, v13, v15

    const/16 v14, 0x27

    const/4 v15, 0x7

    aput-byte v14, v13, v15

    const/16 v14, -0x12

    const/16 v15, 0x8

    aput-byte v14, v13, v15

    const/16 v14, 0x11

    const/16 v15, 0x9

    aput-byte v14, v13, v15

    const/16 v14, 0xa

    const/16 v15, -0x5b

    aput-byte v15, v13, v14

    const/16 v14, 0x5b

    const/16 v15, 0xb

    aput-byte v14, v13, v15

    const/16 v14, -0x3c

    const/16 v15, 0xc

    aput-byte v14, v13, v15

    const/16 v14, -0x28

    const/16 v15, 0xd

    aput-byte v14, v13, v15

    const/16 v14, -0x59

    const/16 v15, 0xe

    aput-byte v14, v13, v15

    const/16 v14, 0x66

    const/16 v15, 0xf

    aput-byte v14, v13, v15

    const/16 v14, 0x10

    const/16 v15, -0x52

    aput-byte v15, v13, v14

    const/16 v14, 0x47

    const/16 v15, 0x11

    aput-byte v14, v13, v15

    const/16 v14, -0x52

    aput-byte v14, v13, v16

    const/16 v14, 0x13

    const/16 v15, 0x5b

    aput-byte v15, v13, v14

    const/16 v14, 0x14

    const/16 v15, -0x47

    aput-byte v15, v13, v14

    const/16 v14, 0x15

    const/16 v15, -0x51

    aput-byte v15, v13, v14

    const/16 v14, -0x12

    const/16 v15, 0x16

    aput-byte v14, v13, v15

    const/16 v14, 0x17

    const/16 v15, 0x49

    aput-byte v15, v13, v14

    const/16 v14, 0x18

    const/16 v15, -0x4b

    aput-byte v15, v13, v14

    const/16 v14, 0x19

    const/16 v15, 0x5b

    aput-byte v15, v13, v14

    const/16 v14, 0x1a

    const/16 v15, -0x19

    aput-byte v15, v13, v14

    const/16 v14, 0x1b

    const/16 v15, 0x14

    aput-byte v15, v13, v14

    const/16 v14, 0x1c

    const/16 v15, -0x7b

    aput-byte v15, v13, v14

    const/16 v14, 0x1d

    const/16 v15, -0x10

    aput-byte v15, v13, v14

    const/16 v14, 0x1e

    const/16 v15, -0x12

    aput-byte v15, v13, v14

    const/16 v14, 0x1f

    const/16 v15, 0x39

    aput-byte v15, v13, v14

    const/16 v14, 0x20

    const/16 v15, -0x17

    aput-byte v15, v13, v14

    const/16 v14, 0x21

    aput-byte v10, v13, v14

    const/16 v14, 0x22

    const/16 v15, -0x4b

    aput-byte v15, v13, v14

    const/16 v14, 0x23

    aput-byte v7, v13, v14

    const/16 v14, 0x24

    const/16 v15, -0x7c

    aput-byte v15, v13, v14

    const/16 v14, 0x25

    const/16 v15, -0x47

    aput-byte v15, v13, v14

    const/16 v14, 0x26

    const/16 v15, -0x53

    aput-byte v15, v13, v14

    const/16 v14, 0x27

    const/16 v15, 0x66

    aput-byte v15, v13, v14

    const/16 v14, 0x28

    const/16 v15, -0x20

    aput-byte v15, v13, v14

    const/16 v14, 0x29

    const/16 v15, 0x1f

    aput-byte v15, v13, v14

    const/16 v14, 0x2a

    const/16 v15, -0x3d

    aput-byte v15, v13, v14

    const/16 v14, 0x2b

    const/16 v15, 0x49

    aput-byte v15, v13, v14

    const/16 v14, 0x2c

    const/16 v15, -0x22

    aput-byte v15, v13, v14

    const/16 v14, 0x2d

    const/16 v15, -0x59

    aput-byte v15, v13, v14

    const/16 v14, 0x2e

    const/16 v15, -0xa

    aput-byte v15, v13, v14

    const/16 v14, 0x2f

    const/16 v15, 0x49

    aput-byte v15, v13, v14

    const/16 v14, 0x30

    const/4 v15, -0x5

    aput-byte v15, v13, v14

    const/16 v14, 0x31

    const/16 v15, 0x7d

    aput-byte v15, v13, v14

    const/16 v14, 0x32

    const/16 v15, -0x20

    aput-byte v15, v13, v14

    const/16 v14, 0x33

    aput-byte v16, v13, v14

    const/16 v14, 0x34

    const/16 v15, -0x80

    aput-byte v15, v13, v14

    const/16 v14, 0x35

    const/16 v15, -0x10

    aput-byte v15, v13, v14

    const/16 v14, 0x36

    const/16 v15, -0x1f

    aput-byte v15, v13, v14

    const/16 v14, 0x37

    const/16 v15, 0x5e

    aput-byte v15, v13, v14

    const/16 v14, 0x38

    const/16 v15, -0x11

    aput-byte v15, v13, v14

    const/16 v14, 0x39

    const/16 v15, 0xe

    aput-byte v15, v13, v14

    const/16 v14, 0x3a

    const/16 v15, -0x5e

    aput-byte v15, v13, v14

    const/16 v14, 0x3b

    const/16 v15, 0x32

    aput-byte v15, v13, v14

    const/16 v14, 0x3c

    const/16 v15, -0x42

    aput-byte v15, v13, v14

    const/16 v14, 0x3d

    const/16 v15, -0x43

    aput-byte v15, v13, v14

    const/16 v14, 0x3e

    const/16 v15, -0x12

    aput-byte v15, v13, v14

    const/16 v14, 0x3f

    const/16 v15, 0x49

    aput-byte v15, v13, v14

    const/16 v14, 0x40

    const/16 v15, -0x55

    aput-byte v15, v13, v14

    const/16 v14, 0x41

    const/16 v15, 0x4f

    aput-byte v15, v13, v14

    const/16 v14, 0x42

    const/4 v15, -0x7

    aput-byte v15, v13, v14

    const/16 v14, 0x43

    const/16 v15, 0x1e

    aput-byte v15, v13, v14

    const/16 v14, 0x44

    const/16 v15, -0x45

    aput-byte v15, v13, v14

    const/16 v14, 0x45

    const/16 v15, -0xf

    aput-byte v15, v13, v14

    const/16 v14, 0x46

    const/16 v15, -0x54

    aput-byte v15, v13, v14

    const/16 v14, 0x47

    const/16 v15, 0x43

    aput-byte v15, v13, v14

    const/16 v14, 0x48

    const/16 v15, -0x4e

    aput-byte v15, v13, v14

    const/16 v14, 0x49

    const/16 v15, 0x4b

    aput-byte v15, v13, v14

    const/16 v14, 0x4a

    const/16 v15, -0x46

    aput-byte v15, v13, v14

    const/16 v14, 0x4b

    const/16 v15, 0x4e

    aput-byte v15, v13, v14

    const/16 v14, 0x4c

    const/16 v15, -0x21

    aput-byte v15, v13, v14

    const/16 v14, 0x4d

    const/16 v15, -0x59

    aput-byte v15, v13, v14

    const/16 v14, 0x4e

    const/16 v15, -0x20

    aput-byte v15, v13, v14

    const/16 v14, 0x4f

    const/16 v15, 0x39

    aput-byte v15, v13, v14

    const/16 v14, 0x50

    const/4 v15, -0x5

    aput-byte v15, v13, v14

    const/16 v14, 0x51

    const/16 v15, 0x17

    aput-byte v15, v13, v14

    const/16 v14, 0x52

    const/16 v15, -0x22

    aput-byte v15, v13, v14

    const/16 v14, 0x53

    const/16 v15, 0x33

    aput-byte v15, v13, v14

    const/16 v14, 0x54

    const/16 v15, -0x48

    aput-byte v15, v13, v14

    const/16 v14, 0x55

    const/16 v15, -0x27

    aput-byte v15, v13, v14

    const/16 v14, 0x56

    const/16 v15, -0x7e

    aput-byte v15, v13, v14

    const/16 v14, 0x57

    const/16 v15, 0x24

    aput-byte v15, v13, v14

    const/16 v14, 0x58

    const/4 v15, -0x5

    aput-byte v15, v13, v14

    const/16 v14, 0x59

    const/16 v15, 0x53

    aput-byte v15, v13, v14

    const/16 v14, 0x5a

    const/4 v15, -0x4

    aput-byte v15, v13, v14

    const/16 v14, 0x10

    const/16 v15, 0x5b

    aput-byte v14, v13, v15

    const/16 v14, 0x5c

    const/16 v15, -0x77

    aput-byte v15, v13, v14

    const/16 v14, 0x5d

    const/16 v15, -0x4c

    aput-byte v15, v13, v14

    const/16 v14, 0x5e

    const/16 v15, -0x77

    aput-byte v15, v13, v14

    const/16 v14, 0x5f

    const/16 v15, 0x6d

    aput-byte v15, v13, v14

    const/16 v14, 0x60

    const/16 v15, -0x48

    aput-byte v15, v13, v14

    const/16 v14, 0x61

    const/16 v15, 0x54

    aput-byte v15, v13, v14

    const/16 v14, 0x62

    const/4 v15, -0x6

    aput-byte v15, v13, v14

    const/16 v14, 0x63

    const/16 v15, 0x52

    aput-byte v15, v13, v14

    const/16 v14, 0x64

    const/16 v15, -0x34

    aput-byte v15, v13, v14

    const/16 v14, 0x65

    const/16 v15, -0x27

    aput-byte v15, v13, v14

    const/16 v14, 0x66

    const/16 v15, -0x5f

    aput-byte v15, v13, v14

    const/16 v14, 0x67

    const/16 v15, 0x6a

    aput-byte v15, v13, v14

    const/16 v14, 0x68

    const/16 v15, -0x4e

    aput-byte v15, v13, v14

    const/16 v14, 0x69

    const/16 v15, 0x53

    aput-byte v15, v13, v14

    const/16 v14, 0x6a

    const/16 v15, -0x10

    aput-byte v15, v13, v14

    const/16 v14, 0x6b

    const/16 v15, 0x5b

    aput-byte v15, v13, v14

    const/16 v14, 0x6c

    const/16 v15, -0x41

    aput-byte v15, v13, v14

    const/16 v14, 0x6d

    const/16 v15, -0xb

    aput-byte v15, v13, v14

    const/16 v14, 0x6e

    const/16 v15, -0x58

    aput-byte v15, v13, v14

    const/16 v14, 0x6f

    const/16 v15, 0x69

    aput-byte v15, v13, v14

    const/16 v14, 0x70

    const/16 v15, -0x57

    aput-byte v15, v13, v14

    const/16 v14, 0x71

    const/16 v15, 0x56

    aput-byte v15, v13, v14

    const/16 v14, 0x72

    const/16 v15, -0x46

    aput-byte v15, v13, v14

    const/16 v14, 0x73

    const/16 v15, 0x4e

    aput-byte v15, v13, v14

    const/16 v14, 0x74

    const/16 v15, -0x21

    aput-byte v15, v13, v14

    const/16 v14, 0x75

    const/16 v15, -0x59

    aput-byte v15, v13, v14

    const/16 v14, 0x76

    const/16 v15, -0x20

    aput-byte v15, v13, v14

    const/16 v14, 0x39

    aput-byte v14, v13, v18

    const/16 v14, 0x8

    new-array v14, v14, [B

    const/16 v15, -0x25

    aput-byte v15, v14, v6

    const/16 v15, 0x3f

    aput-byte v15, v14, v7

    const/16 v15, -0x6b

    aput-byte v15, v14, v8

    const/16 v15, 0x7b

    aput-byte v15, v14, v9

    const/16 v15, -0x14

    aput-byte v15, v14, v10

    const/16 v15, -0x6c

    aput-byte v15, v14, v12

    const/16 v15, -0x32

    const/16 v18, 0x6

    aput-byte v15, v14, v18

    const/4 v15, 0x7

    const/16 v18, 0x8

    aput-byte v18, v14, v15

    invoke-static {v13, v14}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v13

    invoke-virtual {v3, v11, v13}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/16 v11, 0xc

    new-array v11, v11, [B

    const/16 v13, -0x4f

    aput-byte v13, v11, v6

    const/16 v13, 0x4d

    aput-byte v13, v11, v7

    const/16 v13, 0xb

    aput-byte v13, v11, v8

    const/16 v13, -0x29

    aput-byte v13, v11, v9

    const/16 v13, -0x17

    aput-byte v13, v11, v10

    const/16 v13, 0x4b

    aput-byte v13, v11, v12

    const/16 v13, 0x41

    const/4 v14, 0x6

    aput-byte v13, v11, v14

    const/16 v13, 0x43

    const/4 v14, 0x7

    aput-byte v13, v11, v14

    const/16 v13, -0x5a

    const/16 v14, 0x8

    aput-byte v13, v11, v14

    const/16 v13, 0x5b

    const/16 v15, 0x9

    aput-byte v13, v11, v15

    const/16 v13, 0x15

    const/16 v15, 0xa

    aput-byte v13, v11, v15

    const/16 v13, -0x3a

    const/16 v15, 0xb

    aput-byte v13, v11, v15

    new-array v13, v14, [B

    const/16 v14, -0xe

    aput-byte v14, v13, v6

    const/16 v14, 0x22

    aput-byte v14, v13, v7

    const/16 v14, 0x65

    aput-byte v14, v13, v8

    const/16 v14, -0x5d

    aput-byte v14, v13, v9

    const/16 v14, -0x74

    aput-byte v14, v13, v10

    const/16 v14, 0x25

    aput-byte v14, v13, v12

    const/16 v14, 0x35

    const/4 v15, 0x6

    aput-byte v14, v13, v15

    const/16 v14, 0x6e

    const/4 v15, 0x7

    aput-byte v14, v13, v15

    invoke-static {v11, v13}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v11

    const/16 v13, 0x1f

    new-array v13, v13, [B

    const/16 v14, -0x21

    aput-byte v14, v13, v6

    aput-byte v16, v13, v7

    const/16 v14, 0x2b

    aput-byte v14, v13, v8

    const/16 v14, 0x63

    aput-byte v14, v13, v9

    const/16 v14, -0x5f

    aput-byte v14, v13, v10

    const/16 v14, 0x3b

    aput-byte v14, v13, v12

    const/16 v14, 0x30

    const/4 v15, 0x6

    aput-byte v14, v13, v15

    const/16 v14, 0x55

    const/4 v15, 0x7

    aput-byte v14, v13, v15

    const/16 v14, -0x29

    const/16 v15, 0x8

    aput-byte v14, v13, v15

    const/16 v14, 0xd

    const/16 v15, 0x9

    aput-byte v14, v13, v15

    const/16 v14, 0x35

    const/16 v15, 0xa

    aput-byte v14, v13, v15

    const/16 v14, 0x20

    const/16 v15, 0xb

    aput-byte v14, v13, v15

    const/16 v14, -0x5e

    const/16 v15, 0xc

    aput-byte v14, v13, v15

    const/16 v14, 0x2b

    const/16 v15, 0xd

    aput-byte v14, v13, v15

    const/16 v14, 0x3e

    const/16 v15, 0xe

    aput-byte v14, v13, v15

    const/16 v14, 0x4f

    const/16 v15, 0xf

    aput-byte v14, v13, v15

    const/16 v14, 0x10

    const/16 v15, -0x7b

    aput-byte v15, v13, v14

    const/16 v14, 0x42

    const/16 v15, 0x11

    aput-byte v14, v13, v15

    const/16 v14, 0x38

    aput-byte v14, v13, v16

    const/16 v14, 0x13

    const/16 v15, 0x67

    aput-byte v15, v13, v14

    const/16 v14, 0x14

    const/16 v15, -0x57

    aput-byte v15, v13, v14

    const/16 v14, 0x15

    const/16 v15, 0x2a

    aput-byte v15, v13, v14

    const/16 v14, 0x22

    const/16 v15, 0x16

    aput-byte v14, v13, v15

    const/16 v14, 0x17

    const/16 v15, 0x44

    aput-byte v15, v13, v14

    const/16 v14, 0x18

    const/16 v15, -0x36

    aput-byte v15, v13, v14

    const/16 v14, 0x19

    const/16 v15, 0x5f

    aput-byte v15, v13, v14

    const/16 v14, 0x1a

    const/16 v15, 0x2e

    aput-byte v15, v13, v14

    const/16 v14, 0x1b

    const/16 v15, 0x7b

    aput-byte v15, v13, v14

    const/16 v14, 0x1c

    const/16 v15, -0x52

    aput-byte v15, v13, v14

    const/16 v14, 0x1d

    const/16 v15, 0x75

    aput-byte v15, v13, v14

    const/16 v14, 0x1e

    const/16 v15, 0x69

    aput-byte v15, v13, v14

    const/16 v14, 0x8

    new-array v14, v14, [B

    const/16 v15, -0x42

    aput-byte v15, v14, v6

    const/16 v15, 0x62

    aput-byte v15, v14, v7

    const/16 v15, 0x5b

    aput-byte v15, v14, v8

    const/16 v15, 0xf

    aput-byte v15, v14, v9

    const/16 v15, -0x38

    aput-byte v15, v14, v10

    const/16 v15, 0x58

    aput-byte v15, v14, v12

    const/16 v15, 0x51

    const/16 v16, 0x6

    aput-byte v15, v14, v16

    const/16 v15, 0x21

    const/16 v16, 0x7

    aput-byte v15, v14, v16

    invoke-static {v13, v14}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v13

    invoke-virtual {v3, v11, v13}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    invoke-virtual {v5}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-static {v2, v5, v3}, Lcom/github/catvod/spider/appysv2/n/c;->g(Ljava/lang/String;Ljava/lang/String;Ljava/util/Map;)Lcom/github/catvod/spider/appysv2/n/e;

    move-result-object v2

    invoke-virtual {v2}, Lcom/github/catvod/spider/appysv2/n/e;->a()Ljava/lang/String;

    move-result-object v2

    new-instance v3, Lorg/json/JSONObject;

    invoke-direct {v3, v2}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    new-array v2, v10, [B

    const/16 v5, 0x6d

    aput-byte v5, v2, v6

    const/16 v5, -0x2b

    aput-byte v5, v2, v7

    const/16 v5, 0x58

    aput-byte v5, v2, v8

    const/16 v5, -0x55

    aput-byte v5, v2, v9

    const/16 v5, 0x8

    new-array v5, v5, [B

    const/16 v11, 0xe

    aput-byte v11, v5, v6

    const/16 v11, -0x46

    aput-byte v11, v5, v7

    const/16 v11, 0x3c

    aput-byte v11, v5, v8

    const/16 v11, -0x32

    aput-byte v11, v5, v9

    const/16 v11, -0x1c

    aput-byte v11, v5, v10

    const/16 v11, 0x65

    aput-byte v11, v5, v12

    const/16 v11, 0x18

    const/4 v13, 0x6

    aput-byte v11, v5, v13

    const/16 v11, -0x39

    const/4 v13, 0x7

    aput-byte v11, v5, v13

    invoke-static {v2, v5}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v3, v2}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;)I

    move-result v2

    const/16 v5, 0xc8

    if-ne v2, v5, :cond_ee8

    new-array v2, v10, [B

    const/16 v5, 0x5f

    aput-byte v5, v2, v6

    const/16 v5, -0x5d

    aput-byte v5, v2, v7

    const/16 v5, 0x27

    aput-byte v5, v2, v8

    const/16 v5, 0x76

    aput-byte v5, v2, v9

    const/16 v5, 0x8

    new-array v5, v5, [B

    const/16 v11, 0x3b

    aput-byte v11, v5, v6

    const/16 v11, -0x3e

    aput-byte v11, v5, v7

    const/16 v11, 0x53

    aput-byte v11, v5, v8

    const/16 v11, 0x17

    aput-byte v11, v5, v9

    const/16 v11, 0x18

    aput-byte v11, v5, v10

    const/16 v11, 0x25

    aput-byte v11, v5, v12

    const/16 v11, -0x18

    const/4 v13, 0x6

    aput-byte v11, v5, v13

    const/16 v11, 0x71

    const/4 v13, 0x7

    aput-byte v11, v5, v13

    invoke-static {v2, v5}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v3, v2}, Lorg/json/JSONObject;->optJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v2

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v13

    const-wide/16 v15, 0x3e8

    div-long/2addr v13, v15

    const/16 v3, 0xa

    new-array v3, v3, [B

    const/16 v5, -0x2a

    aput-byte v5, v3, v6

    const/16 v5, 0x20

    aput-byte v5, v3, v7

    const/16 v5, 0x6f

    aput-byte v5, v3, v8

    const/16 v5, 0x4e

    aput-byte v5, v3, v9

    const/16 v5, 0x71

    aput-byte v5, v3, v10

    aput-byte v6, v3, v12

    const/16 v5, 0x62

    const/4 v11, 0x6

    aput-byte v5, v3, v11

    const/16 v5, -0x22

    const/4 v11, 0x7

    aput-byte v5, v3, v11

    const/16 v5, -0x38

    const/16 v11, 0x8

    aput-byte v5, v3, v11

    const/16 v5, 0x31

    const/16 v15, 0x9

    aput-byte v5, v3, v15

    new-array v5, v11, [B

    const/16 v11, -0x5b

    aput-byte v11, v5, v6

    const/16 v11, 0x54

    aput-byte v11, v5, v7

    const/16 v11, 0xe

    aput-byte v11, v5, v8

    const/16 v11, 0x3c

    aput-byte v11, v5, v9

    aput-byte v12, v5, v10

    const/16 v11, 0x5f

    aput-byte v11, v5, v12

    const/16 v11, 0x16

    const/4 v15, 0x6

    aput-byte v11, v5, v15

    const/16 v11, -0x49

    const/4 v15, 0x7

    aput-byte v11, v5, v15

    invoke-static {v3, v5}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3, v13, v14}, Lorg/json/JSONObject;->put(Ljava/lang/String;J)Lorg/json/JSONObject;

    const/16 v3, 0x9

    new-array v3, v3, [B

    const/4 v5, -0x4

    aput-byte v5, v3, v6

    const/16 v5, 0x3c

    aput-byte v5, v3, v7

    const/16 v5, 0x58

    aput-byte v5, v3, v8

    const/16 v5, 0x6d

    aput-byte v5, v3, v9

    const/4 v5, -0x3

    aput-byte v5, v3, v10

    const/16 v5, 0x4f

    aput-byte v5, v3, v12

    const/16 v5, 0x56

    const/4 v11, 0x6

    aput-byte v5, v3, v11

    const/16 v5, 0x40

    const/4 v11, 0x7

    aput-byte v5, v3, v11

    const/4 v5, -0x4

    const/16 v11, 0x8

    aput-byte v5, v3, v11

    new-array v5, v11, [B

    const/16 v11, -0x68

    aput-byte v11, v5, v6

    const/16 v11, 0x59

    aput-byte v11, v5, v7

    const/16 v11, 0x2e

    aput-byte v11, v5, v8

    aput-byte v10, v5, v9

    const/16 v11, -0x62

    aput-byte v11, v5, v10

    const/16 v11, 0x2a

    aput-byte v11, v5, v12

    const/16 v11, 0x9

    const/4 v13, 0x6

    aput-byte v11, v5, v13

    const/16 v11, 0x29

    const/4 v13, 0x7

    aput-byte v11, v5, v13

    invoke-static {v3, v5}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3, v1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    new-array v1, v12, [B

    const/16 v3, 0x60

    aput-byte v3, v1, v6

    const/16 v3, 0x44

    aput-byte v3, v1, v7

    const/16 v3, 0x3a

    aput-byte v3, v1, v8

    const/16 v3, -0x31

    aput-byte v3, v1, v9

    const/16 v3, 0x4a

    aput-byte v3, v1, v10

    const/16 v3, 0x8

    new-array v3, v3, [B

    const/16 v5, 0x4e

    aput-byte v5, v3, v6

    const/16 v5, 0x31

    aput-byte v5, v3, v7

    const/16 v5, 0x59

    aput-byte v5, v3, v8

    const/16 v5, -0x45

    aput-byte v5, v3, v9

    const/16 v5, 0x3c

    aput-byte v5, v3, v10

    const/16 v5, 0x1f

    aput-byte v5, v3, v12

    const/16 v5, -0x43

    const/4 v6, 0x6

    aput-byte v5, v3, v6

    const/16 v5, 0x40

    const/4 v6, 0x7

    aput-byte v5, v3, v6

    invoke-static {v1, v3}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v2}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v1, v2}, Lcom/github/catvod/spider/appysv2/p/C;->u(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_eca
    .catch Ljava/lang/Exception; {:try_start_802 .. :try_end_eca} :catch_ecb

    goto :goto_ee8

    :catch_ecb
    move-exception v0

    :goto_ecc
    move-object v1, v0

    goto :goto_ed2

    :catch_ece
    move-exception v0

    move-object/from16 v4, p0

    goto :goto_ecc

    :goto_ed2
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/16 v3, 0x16

    new-array v3, v3, [B

    fill-array-data v3, :array_eea

    const/16 v5, 0x8

    new-array v5, v5, [B

    fill-array-data v5, :array_efa

    .line 1
    invoke-static {v3, v5, v2, v1}, Lcom/github/catvod/spider/appysv2/b/y;->b([B[BLjava/lang/StringBuilder;Ljava/lang/Exception;)V

    :cond_ee8
    :goto_ee8
    return-void

    nop

    :array_eea
    .array-data 1
        0x37t
        0x27t
        0x10t
        -0x7bt
        -0x73t
        -0x7t
        -0x74t
        -0x7bt
        0x23t
        0x2at
        0x30t
        -0x48t
        -0x7dt
        -0x6t
        -0x70t
        -0x5et
        0x29t
        0x16t
        0x32t
        -0x9t
        -0x73t
        -0x5bt
    .end array-data

    nop

    :array_efa
    .array-data 1
        0x50t
        0x42t
        0x64t
        -0x29t
        -0x18t
        -0x61t
        -0x2t
        -0x20t
    .end array-data
.end method

.method private H(Lorg/json/JSONObject;Ljava/lang/String;Ljava/lang/String;Ljava/util/Map;)Lorg/json/JSONObject;
    .registers 43
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lorg/json/JSONObject;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/Object;",
            ">;)",
            "Lorg/json/JSONObject;"
        }
    .end annotation

    move-object/from16 v1, p0

    move-object/from16 v0, p2

    move-object/from16 v2, p3

    move-object/from16 v3, p4

    const/4 v4, 0x4

    :try_start_9
    new-array v5, v4, [B

    const/16 v6, -0xf

    const/4 v7, 0x0

    aput-byte v6, v5, v7

    const/16 v6, -0x7d

    const/4 v8, 0x1

    aput-byte v6, v5, v8

    const/16 v6, 0x3b

    const/4 v9, 0x2

    aput-byte v6, v5, v9

    const/4 v10, 0x3

    aput-byte v6, v5, v10

    const/16 v6, 0x8

    new-array v11, v6, [B

    const/16 v12, -0x6e

    aput-byte v12, v11, v7

    const/16 v13, -0x14

    aput-byte v13, v11, v8

    const/16 v13, 0x5f

    aput-byte v13, v11, v9

    const/16 v13, 0x5e

    aput-byte v13, v11, v10

    const/16 v14, 0x7e

    aput-byte v14, v11, v4

    const/16 v14, -0x16

    const/4 v15, 0x5

    aput-byte v14, v11, v15

    const/16 v14, 0x47

    const/4 v13, 0x6

    aput-byte v14, v11, v13

    const/4 v14, 0x7

    aput-byte v6, v11, v14

    invoke-static {v5, v11}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v5

    move-object/from16 v11, p1

    invoke-virtual {v11, v5}, Lorg/json/JSONObject;->getInt(Ljava/lang/String;)I

    move-result v5

    const/16 v11, 0x7d03

    const/16 v17, 0x23

    const/16 v18, 0x15

    const/16 v19, 0x13

    const/16 v20, 0x16

    const/16 v21, 0xc

    const/16 v22, 0xb

    const/16 v23, 0x9

    const/16 v24, 0x25

    const/16 v25, 0x1f

    const/16 v26, 0x27

    const/16 v27, -0x22

    const/16 v28, 0x73

    const/16 v29, 0x14

    const/16 v30, 0x12

    const/16 v31, 0x41

    const/16 v32, 0xf

    const/16 v33, 0xd

    const/16 v34, 0xa

    const/16 v35, -0x66

    const/16 v36, 0x21

    const/16 v37, 0x37

    const/16 v12, 0x29

    if-ne v5, v11, :cond_14c

    new-array v0, v12, [B

    aput-byte v25, v0, v7

    const/16 v2, -0x29

    aput-byte v2, v0, v8

    const/16 v2, -0x33

    aput-byte v2, v0, v9

    aput-byte v37, v0, v10

    const/16 v2, -0x2d

    aput-byte v2, v0, v4

    const/16 v2, -0x42

    aput-byte v2, v0, v15

    const/16 v2, -0x6a

    aput-byte v2, v0, v13

    aput-byte v36, v0, v14

    const/16 v2, 0x43

    aput-byte v2, v0, v6

    aput-byte v35, v0, v23

    const/16 v2, -0xe

    aput-byte v2, v0, v34

    const/16 v2, 0x5d

    aput-byte v2, v0, v22

    const/16 v2, -0x4d

    aput-byte v2, v0, v21

    const/16 v2, -0x7e

    aput-byte v2, v0, v33

    const/16 v2, -0x3f

    const/16 v3, 0xe

    aput-byte v2, v0, v3

    const/16 v2, 0x68

    aput-byte v2, v0, v32

    const/16 v2, 0x10

    aput-byte v31, v0, v2

    const/16 v2, 0x11

    const/4 v3, -0x4

    aput-byte v3, v0, v2

    const/16 v2, -0x6e

    aput-byte v2, v0, v30

    const/16 v2, 0x46

    aput-byte v2, v0, v19

    const/4 v2, -0x2

    aput-byte v2, v0, v29

    const/16 v2, -0x30

    aput-byte v2, v0, v18

    const/16 v2, -0x23

    aput-byte v2, v0, v20

    const/16 v2, 0x17

    aput-byte v10, v0, v2

    const/16 v2, 0x18

    const/16 v3, -0x2a

    aput-byte v3, v0, v2

    const/16 v2, 0x19

    const/16 v3, 0x53

    aput-byte v3, v0, v2

    const/16 v2, 0x1a

    const/16 v3, -0x63

    aput-byte v3, v0, v2

    const/16 v2, 0x1b

    const/16 v3, 0x7d

    aput-byte v3, v0, v2

    const/16 v2, 0x1c

    const/16 v3, -0x1f

    aput-byte v3, v0, v2

    const/16 v2, 0x1d

    const/16 v3, -0x2d

    aput-byte v3, v0, v2

    const/16 v2, 0x1e

    const/4 v3, -0x6

    aput-byte v3, v0, v2

    aput-byte v4, v0, v25

    const/16 v2, 0x20

    aput-byte v25, v0, v2

    const/4 v2, -0x7

    aput-byte v2, v0, v36

    const/16 v2, 0x22

    const/16 v3, -0x23

    aput-byte v3, v0, v2

    aput-byte v37, v0, v17

    const/16 v2, 0x24

    aput-byte v27, v0, v2

    const/16 v2, -0x6b

    aput-byte v2, v0, v24

    const/16 v2, 0x26

    aput-byte v35, v0, v2

    aput-byte v20, v0, v26

    const/16 v2, 0x28

    const/16 v3, 0x5e

    aput-byte v3, v0, v2

    new-array v2, v6, [B

    const/4 v3, -0x6

    aput-byte v3, v2, v7

    aput-byte v28, v2, v8

    const/16 v3, 0x75

    aput-byte v3, v2, v9

    const/16 v3, -0x2e

    aput-byte v3, v2, v10

    const/16 v3, 0x56

    aput-byte v3, v2, v4

    const/16 v3, 0x35

    aput-byte v3, v2, v15

    aput-byte v28, v2, v13

    const/16 v3, -0x71

    aput-byte v3, v2, v14

    invoke-static {v0, v2}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lcom/github/catvod/spider/appysv2/p/j;->b(Ljava/lang/String;)V

    const/4 v0, 0x0

    return-object v0

    :cond_14c
    new-instance v5, Ljava/util/HashMap;

    invoke-direct {v5}, Ljava/util/HashMap;-><init>()V

    sput-object v5, Lcom/github/catvod/spider/appysv2/b/U;->j:Ljava/util/HashMap;

    invoke-virtual {v1, v0}, Lcom/github/catvod/spider/appysv2/b/U;->N(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    invoke-static {v5}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v5

    if-nez v5, :cond_41f

    invoke-direct {v1, v0}, Lcom/github/catvod/spider/appysv2/b/U;->O(Ljava/lang/String;)V

    const-string v0, ""

    iget-object v5, v1, Lcom/github/catvod/spider/appysv2/b/U;->e:Lcom/github/catvod/spider/appysv2/l/e;

    invoke-virtual {v5}, Lcom/github/catvod/spider/appysv2/l/e;->c()Ljava/util/List;

    move-result-object v5

    invoke-interface {v5}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v5

    :goto_16c
    invoke-interface {v5}, Ljava/util/Iterator;->hasNext()Z

    move-result v11

    if-eqz v11, :cond_194

    invoke-interface {v5}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v11

    check-cast v11, Lcom/github/catvod/spider/appysv2/l/a;

    invoke-virtual {v11}, Lcom/github/catvod/spider/appysv2/l/a;->b()Ljava/lang/String;

    move-result-object v12

    if-eq v12, v2, :cond_189

    if-eqz v12, :cond_187

    invoke-virtual {v12, v2}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v12

    if-eqz v12, :cond_187

    goto :goto_189

    :cond_187
    const/4 v12, 0x0

    goto :goto_18a

    :cond_189
    :goto_189
    const/4 v12, 0x1

    :goto_18a
    if-eqz v12, :cond_191

    invoke-virtual {v11}, Lcom/github/catvod/spider/appysv2/l/a;->f()Ljava/lang/String;

    move-result-object v0

    goto :goto_194

    :cond_191
    const/16 v12, 0x29

    goto :goto_16c

    :cond_194
    :goto_194
    new-array v2, v13, [B

    const/16 v5, -0x17

    aput-byte v5, v2, v7

    aput-byte v20, v2, v8

    const/16 v5, 0x66

    aput-byte v5, v2, v9

    const/16 v11, -0x18

    aput-byte v11, v2, v10

    const/16 v11, -0x5b

    aput-byte v11, v2, v4

    const/16 v11, 0x54

    aput-byte v11, v2, v15

    new-array v11, v6, [B

    aput-byte v35, v11, v7

    const/16 v12, 0x62

    aput-byte v12, v11, v8

    aput-byte v23, v11, v9

    const/16 v12, -0x7d

    aput-byte v12, v11, v10

    const/16 v12, -0x40

    aput-byte v12, v11, v4

    const/16 v12, 0x3a

    aput-byte v12, v11, v15

    aput-byte v28, v11, v13

    aput-byte v22, v11, v14

    invoke-static {v2, v11}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v2

    iget-object v11, v1, Lcom/github/catvod/spider/appysv2/b/U;->e:Lcom/github/catvod/spider/appysv2/l/e;

    invoke-virtual {v11}, Lcom/github/catvod/spider/appysv2/l/e;->b()Lcom/github/catvod/spider/appysv2/l/d;

    move-result-object v11

    invoke-virtual {v11}, Lcom/github/catvod/spider/appysv2/l/d;->a()Ljava/lang/String;

    move-result-object v11

    invoke-interface {v3, v2, v11}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/16 v2, 0xe

    new-array v11, v2, [B

    const/16 v2, -0x5c

    aput-byte v2, v11, v7

    const/16 v2, -0x49

    aput-byte v2, v11, v8

    const/16 v2, 0x3e

    aput-byte v2, v11, v9

    const/16 v28, -0x13

    aput-byte v28, v11, v10

    const/16 v28, 0x7b

    aput-byte v28, v11, v4

    const/16 v28, 0x70

    aput-byte v28, v11, v15

    const/16 v28, 0x7f

    aput-byte v28, v11, v13

    const/16 v28, 0x4f

    aput-byte v28, v11, v14

    const/16 v28, -0x54

    aput-byte v28, v11, v6

    const/16 v28, -0x7f

    aput-byte v28, v11, v23

    const/16 v28, 0x36

    aput-byte v28, v11, v34

    const/16 v28, -0x25

    aput-byte v28, v11, v22

    const/16 v28, 0x7c

    aput-byte v28, v11, v21

    const/16 v28, 0x6b

    aput-byte v28, v11, v33

    new-array v12, v6, [B

    const/16 v28, -0x3e

    aput-byte v28, v12, v7

    aput-byte v27, v12, v8

    const/16 v28, 0x5a

    aput-byte v28, v12, v9

    const/16 v28, -0x4e

    aput-byte v28, v12, v10

    aput-byte v32, v12, v4

    aput-byte v25, v12, v15

    aput-byte v29, v12, v13

    const/16 v28, 0x2a

    aput-byte v28, v12, v14

    invoke-static {v11, v12}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v11

    invoke-static {v0}, Ljava/util/Collections;->singletonList(Ljava/lang/Object;)Ljava/util/List;

    move-result-object v0

    invoke-interface {v3, v11, v0}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/16 v11, 0x58

    new-array v11, v11, [B

    const/16 v12, 0x45

    aput-byte v12, v11, v7

    const/16 v12, 0x2f

    aput-byte v12, v11, v8

    aput-byte v30, v11, v9

    const/16 v12, -0x3c

    aput-byte v12, v11, v10

    const/16 v12, -0x38

    aput-byte v12, v11, v4

    const/16 v12, 0x6d

    aput-byte v12, v11, v15

    const/16 v12, -0x58

    aput-byte v12, v11, v13

    aput-byte v17, v11, v14

    const/16 v12, 0x5d

    aput-byte v12, v11, v6

    const/16 v12, 0x38

    aput-byte v12, v11, v23

    const/16 v12, 0x4b

    aput-byte v12, v11, v34

    const/16 v23, -0x2b

    aput-byte v23, v11, v22

    const/16 v22, -0x35

    aput-byte v22, v11, v21

    aput-byte v2, v11, v33

    const/16 v22, -0x57

    const/16 v23, 0xe

    aput-byte v22, v11, v23

    const/16 v22, 0x79

    aput-byte v22, v11, v32

    const/16 v22, 0x10

    const/16 v23, 0x4e

    aput-byte v23, v11, v22

    const/16 v22, 0x11

    const/16 v23, 0x75

    aput-byte v23, v11, v22

    aput-byte v15, v11, v30

    const/16 v22, -0x26

    aput-byte v22, v11, v19

    const/16 v23, -0x6c

    aput-byte v23, v11, v29

    aput-byte v5, v11, v18

    const/16 v23, -0x58

    aput-byte v23, v11, v20

    const/16 v20, 0x17

    const/16 v23, 0x6f

    aput-byte v23, v11, v20

    const/16 v20, 0x18

    aput-byte v31, v11, v20

    const/16 v20, 0x19

    const/16 v23, 0x34

    aput-byte v23, v11, v20

    const/16 v20, 0x1a

    aput-byte v19, v11, v20

    const/16 v20, 0x1b

    const/16 v23, -0x30

    aput-byte v23, v11, v20

    const/16 v20, 0x1c

    const/16 v23, -0x21

    aput-byte v23, v11, v20

    const/16 v20, 0x1d

    aput-byte v24, v11, v20

    const/16 v20, 0x1e

    const/16 v23, -0x12

    aput-byte v23, v11, v20

    const/16 v20, 0x7a

    aput-byte v20, v11, v25

    const/16 v20, 0x20

    const/16 v23, 0x48

    aput-byte v23, v11, v20

    const/16 v20, 0x74

    aput-byte v20, v11, v36

    const/16 v20, 0x22

    aput-byte v18, v11, v20

    const/16 v20, -0x24

    aput-byte v20, v11, v17

    const/16 v20, 0x24

    aput-byte v22, v11, v20

    aput-byte v24, v11, v24

    const/16 v20, 0x26

    const/16 v25, -0x1e

    aput-byte v25, v11, v20

    aput-byte v17, v11, v26

    const/16 v17, 0x28

    const/16 v16, 0x5e

    aput-byte v16, v11, v17

    const/16 v16, 0x33

    const/16 v17, 0x29

    aput-byte v16, v11, v17

    aput-byte v14, v11, v28

    const/16 v16, 0x2b

    const/16 v17, -0x3a

    aput-byte v17, v11, v16

    const/16 v16, 0x2c

    aput-byte v27, v11, v16

    const/16 v16, 0x2d

    aput-byte v26, v11, v16

    const/16 v16, 0x2e

    const/16 v17, -0x1a

    aput-byte v17, v11, v16

    const/16 v16, 0x2f

    const/16 v17, 0x6b

    aput-byte v17, v11, v16

    const/16 v16, 0x30

    aput-byte v23, v11, v16

    const/16 v16, 0x31

    const/16 v17, 0x74

    aput-byte v17, v11, v16

    const/16 v16, 0x32

    aput-byte v18, v11, v16

    const/16 v16, 0x33

    const/16 v17, -0x2b

    aput-byte v17, v11, v16

    const/16 v16, 0x34

    const/16 v17, -0x33

    aput-byte v17, v11, v16

    const/16 v16, 0x35

    const/16 v17, 0x32

    aput-byte v17, v11, v16

    const/16 v16, 0x36

    const/16 v17, -0x48

    aput-byte v17, v11, v16

    const/16 v16, 0x7c

    aput-byte v16, v11, v37

    const/16 v16, 0x38

    const/16 v17, 0x5f

    aput-byte v17, v11, v16

    const/16 v16, 0x39

    aput-byte v5, v11, v16

    const/16 v16, 0x3a

    aput-byte v19, v11, v16

    const/16 v16, -0x29

    const/16 v17, 0x3b

    aput-byte v16, v11, v17

    const/16 v16, 0x3c

    const/16 v17, -0x35

    aput-byte v17, v11, v16

    const/16 v16, 0x3d

    aput-byte v24, v11, v16

    const/16 v16, -0x18

    aput-byte v16, v11, v2

    const/16 v2, 0x3f

    aput-byte v28, v11, v2

    const/16 v2, 0x40

    aput-byte v12, v11, v2

    const/16 v2, 0x29

    aput-byte v2, v11, v31

    const/16 v2, 0x42

    const/16 v16, 0x5b

    aput-byte v16, v11, v2

    const/16 v2, 0x43

    const/16 v16, -0x3c

    aput-byte v16, v11, v2

    const/16 v2, 0x44

    const/16 v16, -0x28

    aput-byte v16, v11, v2

    const/16 v2, 0x45

    const/16 v16, 0x71

    aput-byte v16, v11, v2

    const/16 v2, 0x46

    const/16 v16, -0xe

    aput-byte v16, v11, v2

    const/16 v2, 0x47

    const/16 v16, 0x6f

    aput-byte v16, v11, v2

    const/16 v2, 0x72

    aput-byte v2, v11, v23

    const/16 v2, 0x49

    const/16 v16, 0x2b

    aput-byte v16, v11, v2

    const/16 v2, 0x4a

    aput-byte v14, v11, v2

    const/16 v2, -0x3a

    aput-byte v2, v11, v12

    const/16 v2, 0x4c

    aput-byte v22, v11, v2

    const/16 v2, 0x4d

    const/16 v12, 0x3a

    aput-byte v12, v11, v2

    const/16 v2, 0x4e

    const/16 v12, -0x28

    aput-byte v12, v11, v2

    const/16 v2, 0x4f

    const/16 v12, 0x7f

    aput-byte v12, v11, v2

    const/16 v2, 0x50

    const/16 v12, 0x59

    aput-byte v12, v11, v2

    const/16 v2, 0x51

    const/16 v12, 0x29

    aput-byte v12, v11, v2

    const/16 v2, 0x52

    const/16 v12, 0x5b

    aput-byte v12, v11, v2

    const/16 v2, 0x53

    const/16 v12, -0x6e

    aput-byte v12, v11, v2

    const/16 v2, 0x54

    const/16 v12, -0x1c

    aput-byte v12, v11, v2

    const/16 v2, 0x55

    aput-byte v6, v11, v2

    const/16 v2, 0x56

    const/16 v12, -0xd

    aput-byte v12, v11, v2

    const/16 v2, 0x57

    const/16 v12, 0x31

    aput-byte v12, v11, v2

    new-array v2, v6, [B

    const/16 v6, 0x2d

    aput-byte v6, v2, v7

    const/16 v6, 0x5b

    aput-byte v6, v2, v8

    aput-byte v5, v2, v9

    const/16 v5, -0x4c

    aput-byte v5, v2, v10

    const/16 v5, -0x45

    aput-byte v5, v2, v4

    const/16 v4, 0x57

    aput-byte v4, v2, v15

    const/16 v4, -0x79

    aput-byte v4, v2, v13

    aput-byte v21, v2, v14

    invoke-static {v11, v2}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v4

    invoke-virtual {v0, v4, v5}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    new-instance v2, Lorg/json/JSONObject;

    invoke-direct {v1, v0, v3}, Lcom/github/catvod/spider/appysv2/b/U;->L(Ljava/lang/String;Ljava/util/Map;)Ljava/lang/String;

    move-result-object v0

    invoke-direct {v2, v0}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V
    :try_end_41a
    .catch Ljava/lang/Exception; {:try_start_9 .. :try_end_41a} :catch_41b

    return-object v2

    :catch_41b
    move-exception v0

    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    :cond_41f
    const/4 v0, 0x0

    return-object v0
.end method

.method private I()Z
    .registers 26

    const/16 v0, 0x59

    const/4 v1, 0x0

    :try_start_3
    new-array v0, v0, [B

    const/16 v2, -0x71

    aput-byte v2, v0, v1

    const/16 v3, 0x68

    const/4 v4, 0x1

    aput-byte v3, v0, v4

    const/16 v5, -0x49

    const/4 v6, 0x2

    aput-byte v5, v0, v6

    const/16 v5, 0x6a

    const/4 v7, 0x3

    aput-byte v5, v0, v7

    const/16 v5, 0x41

    const/4 v8, 0x4

    aput-byte v5, v0, v8

    const/16 v5, 0x3a

    const/4 v9, 0x5

    aput-byte v5, v0, v9

    const/16 v10, 0x6c

    const/4 v11, 0x6

    aput-byte v10, v0, v11

    const/16 v12, 0x22

    const/4 v13, 0x7

    aput-byte v12, v0, v13

    const/16 v12, -0x69

    const/16 v14, 0x8

    aput-byte v12, v0, v14

    const/16 v12, 0x9

    const/16 v15, 0x7f

    aput-byte v15, v0, v12

    const/16 v12, 0xa

    const/16 v16, -0x12

    aput-byte v16, v0, v12

    const/16 v12, 0xb

    const/16 v16, 0x7b

    aput-byte v16, v0, v12

    const/16 v12, 0xc

    const/16 v16, 0x42

    aput-byte v16, v0, v12

    const/16 v12, 0xd

    const/16 v16, 0x69

    aput-byte v16, v0, v12

    const/16 v12, 0xe

    const/16 v16, 0x6d

    aput-byte v16, v0, v12

    const/16 v12, 0xf

    const/16 v16, 0x78

    aput-byte v16, v0, v12

    const/16 v12, 0x10

    const/16 v16, -0x7c

    aput-byte v16, v0, v12

    const/16 v12, 0x11

    const/16 v16, 0x32

    aput-byte v16, v0, v12

    const/16 v12, 0x12

    const/16 v17, -0x60

    aput-byte v17, v0, v12

    const/16 v12, 0x13

    const/16 v18, 0x74

    aput-byte v18, v0, v12

    const/16 v12, 0x14

    const/16 v18, 0x1d

    aput-byte v18, v0, v12

    const/16 v12, 0x15

    const/16 v19, 0x31

    aput-byte v19, v0, v12

    const/16 v12, 0x16

    aput-byte v10, v0, v12

    const/16 v12, 0x17

    const/16 v19, 0x6e

    aput-byte v19, v0, v12

    const/16 v12, 0x18

    const/16 v19, -0x75

    aput-byte v19, v0, v12

    const/16 v12, 0x19

    const/16 v19, 0x73

    aput-byte v19, v0, v12

    const/16 v12, 0x1a

    const/16 v20, -0x4a

    aput-byte v20, v0, v12

    const/16 v12, 0x1b

    const/16 v20, 0x7e

    aput-byte v20, v0, v12

    const/16 v12, 0x1c

    const/16 v20, 0x56

    aput-byte v20, v0, v12

    const/16 v12, 0x72

    aput-byte v12, v0, v18

    const/16 v21, 0x1e

    const/16 v22, 0x2a

    aput-byte v22, v0, v21

    const/16 v21, 0x1f

    const/16 v22, 0x7b

    aput-byte v22, v0, v21

    const/16 v21, 0x20

    const/16 v22, -0x7e

    aput-byte v22, v0, v21

    const/16 v21, 0x21

    const/16 v22, 0x33

    aput-byte v22, v0, v21

    const/16 v21, 0x22

    const/16 v22, -0x52

    aput-byte v22, v0, v21

    const/16 v21, 0x23

    aput-byte v15, v0, v21

    const/16 v21, 0x24

    const/16 v22, 0x5f

    aput-byte v22, v0, v21

    const/16 v21, 0x25

    const/16 v22, 0x62

    aput-byte v22, v0, v21

    const/16 v21, 0x26

    aput-byte v21, v0, v21

    const/16 v22, 0x27

    aput-byte v15, v0, v22

    const/16 v22, 0x28

    const/16 v23, -0x28

    aput-byte v23, v0, v22

    const/16 v22, 0x29

    aput-byte v10, v0, v22

    const/16 v22, 0x2a

    const/16 v23, -0x4f

    aput-byte v23, v0, v22

    const/16 v22, 0x2b

    const/16 v23, 0x27

    aput-byte v23, v0, v22

    const/16 v22, 0x2c

    const/16 v23, 0x67

    aput-byte v23, v0, v22

    const/16 v22, 0x2d

    const/16 v23, 0x43

    aput-byte v23, v0, v22

    const/16 v22, 0x2e

    aput-byte v4, v0, v22

    const/16 v22, 0x2f

    aput-byte v15, v0, v22

    const/16 v22, 0x30

    const/16 v24, -0x78

    aput-byte v24, v0, v22

    const/16 v22, 0x31

    const/16 v24, 0x6b

    aput-byte v24, v0, v22

    const/16 v22, -0x50

    aput-byte v22, v0, v16

    const/16 v22, 0x33

    aput-byte v15, v0, v22

    const/16 v22, 0x34

    const/16 v24, 0x40

    aput-byte v24, v0, v22

    const/16 v22, 0x35

    aput-byte v21, v0, v22

    const/16 v22, 0x36

    const/16 v24, 0x25

    aput-byte v24, v0, v22

    const/16 v22, 0x37

    aput-byte v15, v0, v22

    const/16 v22, 0x38

    const/16 v24, -0x26

    aput-byte v24, v0, v22

    const/16 v22, 0x39

    aput-byte v10, v0, v22

    aput-byte v17, v0, v5

    const/16 v10, 0x3b

    const/16 v22, 0x3c

    aput-byte v22, v0, v10

    const/16 v10, 0x3c

    const/16 v22, 0x54

    aput-byte v22, v0, v10

    const/16 v10, 0x3d

    const/16 v22, 0x65

    aput-byte v22, v0, v10

    const/16 v10, 0x3e

    const/16 v22, 0x37

    aput-byte v22, v0, v10

    const/16 v10, 0x3f

    const/16 v22, 0x6e

    aput-byte v22, v0, v10

    const/16 v10, 0x40

    aput-byte v2, v0, v10

    const/16 v10, 0x41

    aput-byte v23, v0, v10

    const/16 v10, 0x42

    const/16 v22, -0x50

    aput-byte v22, v0, v10

    const/16 v10, 0x6f

    aput-byte v10, v0, v23

    const/16 v10, 0x44

    const/16 v22, 0x50

    aput-byte v22, v0, v10

    const/16 v10, 0x45

    aput-byte v19, v0, v10

    const/16 v10, 0x46

    const/16 v22, 0x20

    aput-byte v22, v0, v10

    const/16 v10, 0x47

    aput-byte v15, v0, v10

    const/16 v10, 0x48

    const/16 v22, -0x72

    aput-byte v22, v0, v10

    const/16 v10, 0x49

    const/16 v22, 0x7e

    aput-byte v22, v0, v10

    const/16 v10, 0x4a

    const/16 v22, -0x5a

    aput-byte v22, v0, v10

    const/16 v10, 0x4b

    const/16 v22, 0x27

    aput-byte v22, v0, v10

    const/16 v10, 0x4c

    const/16 v22, 0x46

    aput-byte v22, v0, v10

    const/16 v10, 0x4d

    aput-byte v12, v0, v10

    const/16 v10, 0x4e

    const/16 v22, 0x36

    aput-byte v22, v0, v10

    const/16 v10, 0x4f

    aput-byte v3, v0, v10

    const/16 v10, 0x50

    const/16 v22, -0x3f

    aput-byte v22, v0, v10

    const/16 v10, 0x51

    aput-byte v23, v0, v10

    const/16 v10, 0x52

    aput-byte v17, v0, v10

    const/16 v10, 0x53

    aput-byte v12, v0, v10

    const/16 v10, 0x54

    const/16 v22, 0xf

    aput-byte v22, v0, v10

    const/16 v10, 0x55

    aput-byte v3, v0, v10

    const/16 v3, 0x2c

    aput-byte v3, v0, v20

    const/16 v3, 0x57

    const/16 v10, 0x60

    aput-byte v10, v0, v3

    const/16 v3, 0x58

    const/16 v10, -0x7e

    aput-byte v10, v0, v3

    new-array v3, v14, [B

    const/16 v10, -0x19

    aput-byte v10, v3, v1

    const/16 v10, 0x1c

    aput-byte v10, v3, v4

    const/16 v10, -0x3d

    aput-byte v10, v3, v6

    const/16 v10, 0x1a

    aput-byte v10, v3, v7

    aput-byte v16, v3, v8

    aput-byte v1, v3, v9

    aput-byte v23, v3, v11

    const/16 v10, 0xd

    aput-byte v10, v3, v13

    invoke-static {v0, v3}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v0

    new-instance v3, Lorg/json/JSONObject;

    invoke-direct/range {p0 .. p0}, Lcom/github/catvod/spider/appysv2/b/U;->y()Ljava/util/Map;

    move-result-object v10

    invoke-static {v0, v10}, Lcom/github/catvod/spider/appysv2/n/c;->m(Ljava/lang/String;Ljava/util/Map;)Ljava/lang/String;

    move-result-object v0

    invoke-direct {v3, v0}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    new-array v0, v7, [B

    const/16 v10, -0xc

    aput-byte v10, v0, v1

    const/4 v10, -0x4

    aput-byte v10, v0, v4

    const/16 v10, 0x44

    aput-byte v10, v0, v6

    new-array v10, v14, [B

    const/16 v22, -0x3a

    aput-byte v22, v10, v1

    const/16 v22, -0x34

    aput-byte v22, v10, v4

    const/16 v22, 0x74

    aput-byte v22, v10, v6

    const/16 v22, -0x3b

    aput-byte v22, v10, v7

    const/16 v22, 0x3b

    aput-byte v22, v10, v8

    const/16 v22, -0xc

    aput-byte v22, v10, v9

    const/16 v22, -0x7c

    aput-byte v22, v10, v11

    const/16 v22, -0x2f

    aput-byte v22, v10, v13

    invoke-static {v0, v10}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v0

    new-array v10, v11, [B

    const/16 v22, -0x1c

    aput-byte v22, v10, v1

    aput-byte v2, v10, v4

    const/16 v22, 0x61

    aput-byte v22, v10, v6

    const/16 v22, 0x4e

    aput-byte v22, v10, v7

    const/16 v22, -0x6e

    aput-byte v22, v10, v8

    const/16 v22, -0x2

    aput-byte v22, v10, v9

    new-array v12, v14, [B

    const/16 v23, -0x69

    aput-byte v23, v12, v1

    const/16 v23, -0x5

    aput-byte v23, v12, v4

    aput-byte v1, v12, v6

    aput-byte v5, v12, v7

    const/16 v5, -0x19

    aput-byte v5, v12, v8

    const/16 v5, -0x73

    aput-byte v5, v12, v9

    const/16 v5, -0x6c

    aput-byte v5, v12, v11

    const/16 v5, -0x2b

    aput-byte v5, v12, v13

    invoke-static {v10, v12}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v3, v5}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v0, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_37b

    new-array v0, v8, [B

    aput-byte v16, v0, v1

    const/16 v5, -0x7b

    aput-byte v5, v0, v4

    const/4 v5, -0x5

    aput-byte v5, v0, v6

    const/16 v5, 0x4c

    aput-byte v5, v0, v7

    new-array v5, v14, [B

    aput-byte v20, v5, v1

    const/16 v10, -0x1c

    aput-byte v10, v5, v4

    aput-byte v2, v5, v6

    const/16 v2, 0x2d

    aput-byte v2, v5, v7

    aput-byte v21, v5, v8

    const/4 v2, -0x8

    aput-byte v2, v5, v9

    const/16 v2, 0x76

    aput-byte v2, v5, v11

    const/16 v2, -0x74

    aput-byte v2, v5, v13

    invoke-static {v0, v5}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v3, v0}, Lorg/json/JSONObject;->optJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v0

    const/16 v2, 0xb

    new-array v2, v2, [B

    const/16 v3, -0x54

    aput-byte v3, v2, v1

    const/16 v3, -0x22

    aput-byte v3, v2, v4

    aput-byte v15, v2, v6

    aput-byte v18, v2, v7

    aput-byte v14, v2, v8

    const/16 v3, 0x24

    aput-byte v3, v2, v9

    const/16 v3, 0x70

    aput-byte v3, v2, v11

    const/16 v3, 0x39

    aput-byte v3, v2, v13

    const/16 v3, -0x48

    aput-byte v3, v2, v14

    const/16 v3, 0x9

    const/16 v5, -0x35

    aput-byte v5, v2, v3

    const/16 v3, 0xa

    const/16 v5, 0x77

    aput-byte v5, v2, v3

    new-array v3, v14, [B

    const/16 v5, -0x3f

    aput-byte v5, v3, v1

    const/16 v5, -0x45

    aput-byte v5, v3, v4

    const/16 v5, 0x12

    aput-byte v5, v3, v6

    aput-byte v15, v3, v7

    const/16 v5, 0x6d

    aput-byte v5, v3, v8

    aput-byte v20, v3, v9

    const/16 v5, 0x2f

    aput-byte v5, v3, v11

    const/16 v5, 0x4d

    aput-byte v5, v3, v13

    invoke-static {v2, v3}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    new-array v0, v7, [B

    const/16 v2, -0x4e

    aput-byte v2, v0, v1

    const/4 v2, -0x4

    aput-byte v2, v0, v4

    const/16 v2, -0x3d

    aput-byte v2, v0, v6

    new-array v2, v14, [B

    const/16 v3, -0x64

    aput-byte v3, v2, v1

    const/16 v3, -0x77

    aput-byte v3, v2, v4

    aput-byte v17, v2, v6

    const/16 v3, 0x77

    aput-byte v3, v2, v7

    const/16 v3, -0x33

    aput-byte v3, v2, v8

    const/16 v3, -0xe

    aput-byte v3, v2, v9

    const/16 v3, 0x63

    aput-byte v3, v2, v11

    const/16 v3, -0x2b

    aput-byte v3, v2, v13

    invoke-static {v0, v2}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lcom/github/catvod/spider/appysv2/p/C;->q(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    if-eqz v0, :cond_378

    new-array v0, v7, [B

    const/16 v2, 0x37

    aput-byte v2, v0, v1

    const/16 v2, 0x72

    aput-byte v2, v0, v4

    const/16 v2, 0x3c

    aput-byte v2, v0, v6

    new-array v2, v14, [B

    const/16 v3, 0x19

    aput-byte v3, v2, v1

    aput-byte v13, v2, v4

    const/16 v3, 0x5f

    aput-byte v3, v2, v6

    aput-byte v19, v2, v7

    const/16 v3, 0x7e

    aput-byte v3, v2, v8

    const/16 v3, 0x55

    aput-byte v3, v2, v9

    const/16 v3, -0x2a

    aput-byte v3, v2, v11

    const/16 v3, -0x1b

    aput-byte v3, v2, v13

    invoke-static {v0, v2}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v0
    :try_end_370
    .catch Ljava/lang/Exception; {:try_start_3 .. :try_end_370} :catch_383

    move-object/from16 v2, p0

    :try_start_372
    iget-object v3, v2, Lcom/github/catvod/spider/appysv2/b/U;->a:Ljava/lang/String;

    invoke-static {v0, v3}, Lcom/github/catvod/spider/appysv2/p/C;->u(Ljava/lang/String;Ljava/lang/String;)V

    goto :goto_37a

    :cond_378
    move-object/from16 v2, p0

    :goto_37a
    return v4

    :cond_37b
    move-object/from16 v2, p0

    new-instance v0, Ljava/lang/Exception;

    invoke-direct {v0}, Ljava/lang/Exception;-><init>()V

    throw v0
    :try_end_383
    .catch Ljava/lang/Exception; {:try_start_372 .. :try_end_383} :catch_385

    :catch_383
    move-object/from16 v2, p0

    :catch_385
    return v1
.end method

.method private J(Ljava/lang/String;Lcom/github/catvod/spider/appysv2/l/a;Ljava/util/List;)V
    .registers 24
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Lcom/github/catvod/spider/appysv2/l/a;",
            "Ljava/util/List<",
            "Lcom/github/catvod/spider/appysv2/l/a;",
            ">;)V"
        }
    .end annotation

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move-object/from16 v2, p3

    iget-object v3, v0, Lcom/github/catvod/spider/appysv2/b/U;->e:Lcom/github/catvod/spider/appysv2/l/e;

    invoke-virtual {v3}, Lcom/github/catvod/spider/appysv2/l/e;->b()Lcom/github/catvod/spider/appysv2/l/d;

    move-result-object v3

    const/4 v4, 0x0

    const/4 v5, 0x1

    if-nez v3, :cond_12

    const/4 v3, 0x1

    goto :goto_13

    :cond_12
    const/4 v3, 0x0

    :goto_13
    if-eqz v3, :cond_16

    return-void

    :cond_16
    invoke-virtual/range {p2 .. p2}, Lcom/github/catvod/spider/appysv2/l/a;->b()Ljava/lang/String;

    move-result-object v3

    new-instance v6, Ljava/util/ArrayList;

    invoke-direct {v6}, Ljava/util/ArrayList;-><init>()V

    new-instance v7, Ljava/util/ArrayList;

    invoke-direct {v7}, Ljava/util/ArrayList;-><init>()V

    const/4 v8, 0x1

    :goto_25
    new-instance v9, Ljava/lang/StringBuilder;

    invoke-direct {v9}, Ljava/lang/StringBuilder;-><init>()V

    const/16 v10, 0x53

    new-array v10, v10, [B

    fill-array-data v10, :array_22e

    const/16 v11, 0x8

    new-array v12, v11, [B

    fill-array-data v12, :array_25c

    .line 1
    invoke-static {v10, v12, v9, v1}, Lcom/github/catvod/spider/appysv2/b/v;->c([B[BLjava/lang/StringBuilder;Ljava/lang/String;)V

    new-array v10, v11, [B

    .line 2
    fill-array-data v10, :array_264

    new-array v12, v11, [B

    fill-array-data v12, :array_26c

    invoke-static {v10, v12}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v9, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v10, v0, Lcom/github/catvod/spider/appysv2/b/U;->e:Lcom/github/catvod/spider/appysv2/l/e;

    invoke-virtual {v10}, Lcom/github/catvod/spider/appysv2/l/e;->b()Lcom/github/catvod/spider/appysv2/l/d;

    move-result-object v10

    invoke-virtual {v10}, Lcom/github/catvod/spider/appysv2/l/d;->a()Ljava/lang/String;

    move-result-object v10

    invoke-static {v10}, Ljava/net/URLEncoder;->encode(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v9, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v10, 0xa

    new-array v10, v10, [B

    fill-array-data v10, :array_274

    new-array v12, v11, [B

    fill-array-data v12, :array_27e

    .line 3
    invoke-static {v10, v12, v9, v3}, Lcom/github/catvod/spider/appysv2/b/v;->c([B[BLjava/lang/StringBuilder;Ljava/lang/String;)V

    const/16 v10, 0xf

    new-array v10, v10, [B

    .line 4
    fill-array-data v10, :array_286

    new-array v12, v11, [B

    fill-array-data v12, :array_292

    invoke-static {v10, v12}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v9, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v9, v8}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v10, 0x7

    new-array v12, v10, [B

    fill-array-data v12, :array_29a

    new-array v13, v11, [B

    fill-array-data v13, :array_2a2

    invoke-static {v12, v13}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v12

    invoke-virtual {v9, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v12, 0x64

    invoke-virtual {v9, v12}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/16 v12, 0x50

    new-array v12, v12, [B

    fill-array-data v12, :array_2aa

    new-array v13, v11, [B

    fill-array-data v13, :array_2d6

    .line 5
    invoke-static {v12, v13, v9}, Lcom/github/catvod/spider/appysv2/b/t;->a([B[BLjava/lang/StringBuilder;)Ljava/lang/String;

    move-result-object v9

    .line 6
    invoke-direct {v0, v9}, Lcom/github/catvod/spider/appysv2/b/U;->u(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    .line 7
    const-class v12, Lcom/github/catvod/spider/appysv2/l/c;

    .line 8
    invoke-static {v9, v12}, Lcom/github/catvod/spider/appysv2/b/s;->a(Ljava/lang/String;Ljava/lang/Class;)Ljava/lang/Object;

    move-result-object v12

    .line 9
    check-cast v12, Lcom/github/catvod/spider/appysv2/l/c;

    .line 10
    invoke-virtual {v12}, Lcom/github/catvod/spider/appysv2/l/c;->a()Lcom/github/catvod/spider/appysv2/l/b;

    move-result-object v12

    invoke-virtual {v12}, Lcom/github/catvod/spider/appysv2/l/b;->a()Ljava/util/List;

    move-result-object v12

    invoke-interface {v12}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v12

    :cond_c1
    :goto_c1
    invoke-interface {v12}, Ljava/util/Iterator;->hasNext()Z

    move-result v13

    if-eqz v13, :cond_116

    invoke-interface {v12}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v13

    check-cast v13, Lcom/github/catvod/spider/appysv2/l/a;

    invoke-virtual {v13}, Lcom/github/catvod/spider/appysv2/l/a;->h()Z

    move-result v14

    if-eqz v14, :cond_d7

    invoke-virtual {v6, v13}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_c1

    :cond_d7
    invoke-virtual {v13}, Lcom/github/catvod/spider/appysv2/l/a;->i()Z

    move-result v14

    if-eqz v14, :cond_e3

    invoke-virtual {v13}, Lcom/github/catvod/spider/appysv2/l/a;->a()I

    move-result v14

    if-eq v14, v5, :cond_f7

    :cond_e3
    invoke-virtual {v13}, Lcom/github/catvod/spider/appysv2/l/a;->i()Z

    move-result v14

    if-eqz v14, :cond_c1

    invoke-static {}, Lcom/github/catvod/spider/appysv2/p/C;->k()Ljava/util/ArrayList;

    move-result-object v14

    invoke-virtual {v13}, Lcom/github/catvod/spider/appysv2/l/a;->d()Ljava/lang/String;

    move-result-object v15

    invoke-virtual {v14, v15}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result v14

    if-eqz v14, :cond_c1

    :cond_f7
    iget-object v14, v0, Lcom/github/catvod/spider/appysv2/b/U;->e:Lcom/github/catvod/spider/appysv2/l/e;

    invoke-virtual {v14}, Lcom/github/catvod/spider/appysv2/l/e;->b()Lcom/github/catvod/spider/appysv2/l/d;

    move-result-object v14

    invoke-virtual {v14}, Lcom/github/catvod/spider/appysv2/l/d;->b()Ljava/lang/String;

    move-result-object v14

    invoke-virtual/range {p2 .. p2}, Lcom/github/catvod/spider/appysv2/l/a;->c()Ljava/lang/String;

    move-result-object v15

    invoke-virtual {v14, v15}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v14

    if-nez v14, :cond_112

    invoke-virtual/range {p2 .. p2}, Lcom/github/catvod/spider/appysv2/l/a;->c()Ljava/lang/String;

    move-result-object v14

    invoke-virtual {v13, v14}, Lcom/github/catvod/spider/appysv2/l/a;->k(Ljava/lang/String;)Lcom/github/catvod/spider/appysv2/l/a;

    :cond_112
    invoke-interface {v7, v13}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    goto :goto_c1

    :cond_116
    invoke-interface {v7}, Ljava/util/List;->isEmpty()Z

    move-result v12

    if-nez v12, :cond_124

    invoke-interface {v2, v7}, Ljava/util/List;->addAll(Ljava/util/Collection;)Z

    new-instance v7, Ljava/util/ArrayList;

    invoke-direct {v7}, Ljava/util/ArrayList;-><init>()V

    :cond_124
    :try_start_124
    new-instance v12, Lorg/json/JSONObject;

    invoke-direct {v12, v9}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    new-array v9, v11, [B

    const/16 v13, -0x68

    aput-byte v13, v9, v4

    const/16 v13, -0x48

    aput-byte v13, v9, v5

    const/16 v13, 0x38

    const/4 v14, 0x2

    aput-byte v13, v9, v14

    const/4 v13, -0x7

    const/4 v15, 0x3

    aput-byte v13, v9, v15

    const/16 v13, -0x21

    const/16 v16, 0x4

    aput-byte v13, v9, v16

    const/16 v13, 0x1c

    const/16 v17, 0x5

    aput-byte v13, v9, v17

    const/16 v13, -0x33

    const/4 v15, 0x6

    aput-byte v13, v9, v15

    aput-byte v13, v9, v10

    new-array v13, v11, [B

    const/16 v19, -0xb

    aput-byte v19, v13, v4

    const/16 v19, -0x23

    aput-byte v19, v13, v5

    const/16 v19, 0x4c

    aput-byte v19, v13, v14

    const/16 v19, -0x68

    const/16 v18, 0x3

    aput-byte v19, v13, v18

    const/16 v19, -0x45

    aput-byte v19, v13, v16

    const/16 v19, 0x7d

    aput-byte v19, v13, v17

    const/16 v19, -0x47

    aput-byte v19, v13, v15

    const/16 v19, -0x54

    aput-byte v19, v13, v10

    invoke-static {v9, v13}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v12, v9}, Lorg/json/JSONObject;->getJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v9

    new-array v12, v15, [B

    const/16 v13, -0x10

    aput-byte v13, v12, v4

    const/16 v13, -0x65

    aput-byte v13, v12, v5

    const/16 v13, 0x30

    aput-byte v13, v12, v14

    const/16 v13, 0x1b

    const/16 v18, 0x3

    aput-byte v13, v12, v18

    const/16 v13, -0x5f

    aput-byte v13, v12, v16

    const/16 v13, 0x5d

    aput-byte v13, v12, v17

    new-array v13, v11, [B

    const/16 v19, -0x51

    aput-byte v19, v13, v4

    const/16 v19, -0x11

    aput-byte v19, v13, v5

    const/16 v19, 0x5f

    aput-byte v19, v13, v14

    const/16 v19, 0x6f

    const/16 v18, 0x3

    aput-byte v19, v13, v18

    const/16 v19, -0x40

    aput-byte v19, v13, v16

    const/16 v19, 0x31

    aput-byte v19, v13, v17

    const/16 v19, -0x60

    aput-byte v19, v13, v15

    const/16 v19, -0x4

    aput-byte v19, v13, v10

    invoke-static {v12, v13}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v12

    invoke-virtual {v9, v12}, Lorg/json/JSONObject;->getInt(Ljava/lang/String;)I

    move-result v12

    new-array v13, v15, [B

    const/16 v19, 0xc

    aput-byte v19, v13, v4

    const/16 v19, -0x73

    aput-byte v19, v13, v5

    const/16 v19, -0x7b

    aput-byte v19, v13, v14

    const/16 v19, -0x53

    const/16 v18, 0x3

    aput-byte v19, v13, v18

    const/16 v19, -0x34

    aput-byte v19, v13, v16

    const/16 v19, -0x2a

    aput-byte v19, v13, v17

    new-array v11, v11, [B

    const/16 v19, 0x53

    aput-byte v19, v11, v4

    const/16 v19, -0x12

    aput-byte v19, v11, v5

    const/16 v19, -0x16

    aput-byte v19, v11, v14

    const/16 v14, -0x28

    const/16 v18, 0x3

    aput-byte v14, v11, v18

    const/16 v14, -0x5e

    aput-byte v14, v11, v16

    aput-byte v14, v11, v17

    const/16 v14, 0x46

    aput-byte v14, v11, v15

    const/16 v14, -0x42

    aput-byte v14, v11, v10

    invoke-static {v13, v11}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v9, v10}, Lorg/json/JSONObject;->getInt(Ljava/lang/String;)I

    move-result v9
    :try_end_209
    .catch Ljava/lang/Exception; {:try_start_124 .. :try_end_209} :catch_218

    const/16 v10, 0x64

    if-le v12, v10, :cond_218

    mul-int/lit8 v11, v8, 0x64

    if-eq v11, v12, :cond_218

    if-eq v9, v10, :cond_214

    goto :goto_218

    :cond_214
    add-int/lit8 v8, v8, 0x1

    goto/16 :goto_25

    :catch_218
    :cond_218
    :goto_218
    invoke-virtual {v6}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v3

    :goto_21c
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    if-eqz v4, :cond_22c

    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Lcom/github/catvod/spider/appysv2/l/a;

    invoke-direct {v0, v1, v4, v2}, Lcom/github/catvod/spider/appysv2/b/U;->J(Ljava/lang/String;Lcom/github/catvod/spider/appysv2/l/a;Ljava/util/List;)V

    goto :goto_21c

    :cond_22c
    return-void

    nop

    :array_22e
    .array-data 1
        0x2et
        -0x54t
        -0x5bt
        -0x80t
        0x3bt
        0x6ct
        0x48t
        -0x60t
        0x36t
        -0x45t
        -0x4t
        -0x6ft
        0x38t
        0x3ft
        0x49t
        -0x6t
        0x25t
        -0xat
        -0x4et
        -0x62t
        0x67t
        0x67t
        0x48t
        -0x14t
        0x2at
        -0x49t
        -0x5ct
        -0x6ct
        0x2ct
        0x24t
        0xet
        -0x7t
        0x23t
        -0x9t
        -0x5et
        -0x68t
        0x29t
        0x24t
        0x2t
        -0x60t
        0x35t
        -0x50t
        -0x50t
        -0x7et
        0x2dt
        0x26t
        0x6t
        -0x18t
        0x23t
        -0x9t
        -0x4bt
        -0x6bt
        0x3ct
        0x37t
        0xet
        -0x1dt
        0x79t
        -0x58t
        -0x5dt
        -0x33t
        0x1dt
        0x15t
        0x25t
        -0x3t
        0x29t
        -0x51t
        -0x5et
        -0x6bt
        0x3at
        0x70t
        0x1t
        -0x3t
        0x7bt
        -0x58t
        -0x4et
        -0x2at
        0x38t
        0x21t
        0x3t
        -0x30t
        0x2ft
        -0x44t
        -0x14t
    .end array-data

    :array_25c
    .array-data 1
        0x46t
        -0x28t
        -0x2ft
        -0x10t
        0x48t
        0x56t
        0x67t
        -0x71t
    .end array-data

    :array_264
    .array-data 1
        -0x3et
        0x38t
        -0x70t
        0x42t
        0x1at
        -0x2t
        -0x20t
        0x3dt
    .end array-data

    :array_26c
    .array-data 1
        -0x1ct
        0x4bt
        -0x1ct
        0x2dt
        0x71t
        -0x65t
        -0x72t
        0x0t
    .end array-data

    :array_274
    .array-data 1
        -0x26t
        -0x6dt
        -0x2ft
        -0x2et
        -0x30t
        0x65t
        0x70t
        0x18t
        -0x68t
        -0x22t
    .end array-data

    nop

    :array_27e
    .array-data 1
        -0x4t
        -0x1dt
        -0x4bt
        -0x45t
        -0x5et
        0x3at
        0x16t
        0x71t
    .end array-data

    :array_286
    .array-data 1
        0x5bt
        0xat
        -0x4bt
        -0x3dt
        -0x27t
        0x7ft
        0x49t
        0x56t
        0x5bt
        0x33t
        -0x56t
        -0x30t
        -0x23t
        0x7ft
        0x49t
    .end array-data

    :array_292
    .array-data 1
        0x7dt
        0x6ct
        -0x26t
        -0x4ft
        -0x46t
        0x1at
        0x74t
        0x66t
    .end array-data

    :array_29a
    .array-data 1
        -0x48t
        -0x34t
        -0x55t
        0x3ct
        0xbt
        -0x68t
        -0x14t
    .end array-data

    :array_2a2
    .array-data 1
        -0x62t
        -0x6dt
        -0x28t
        0x55t
        0x71t
        -0x3t
        -0x2ft
        0x3at
    .end array-data

    :array_2aa
    .array-data 1
        -0x32t
        -0x53t
        -0x29t
        -0x51t
        0x3at
        -0xbt
        0x63t
        0x60t
        -0x76t
        -0x6dt
        -0x21t
        -0x5ct
        0x2bt
        -0x1ct
        0x36t
        0xft
        -0x32t
        -0x53t
        -0x29t
        -0x51t
        0x3at
        -0xbt
        0x63t
        0x60t
        -0x65t
        -0x66t
        -0x30t
        -0x48t
        0x2bt
        -0x55t
        0x3bt
        0x19t
        -0x49t
        -0x6ct
        -0x2ct
        -0x42t
        0x2dt
        -0x2t
        0x54t
        0x4bt
        -0x79t
        -0x7at
        -0x30t
        -0x5at
        0x73t
        -0x59t
        0x2dt
        0x60t
        -0x65t
        -0x63t
        -0x3dt
        -0x42t
        0x73t
        -0x10t
        0x62t
        0x53t
        -0x73t
        -0x53t
        -0x3bt
        -0x4dt
        0x3et
        -0xdt
        0x31t
        0x5et
        -0x65t
        -0x6ft
        -0x63t
        -0x54t
        0x27t
        -0x6t
        0x6et
        0x60t
        -0x7at
        -0x6dt
        -0x24t
        -0x51t
        0x74t
        -0x9t
        0x78t
        0x5ct
    .end array-data

    :array_2d6
    .array-data 1
        -0x18t
        -0xet
        -0x4ft
        -0x36t
        0x4et
        -0x6at
        0xbt
        0x3ft
    .end array-data
.end method

.method private L(Ljava/lang/String;Ljava/util/Map;)Ljava/lang/String;
    .registers 27
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/Object;",
            ">;)",
            "Ljava/lang/String;"
        }
    .end annotation

    move-object/from16 v0, p0

    new-instance v1, Lorg/json/JSONObject;

    move-object/from16 v2, p2

    invoke-direct {v1, v2}, Lorg/json/JSONObject;-><init>(Ljava/util/Map;)V

    invoke-virtual {v1}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct/range {p0 .. p0}, Lcom/github/catvod/spider/appysv2/b/U;->y()Ljava/util/Map;

    move-result-object v2

    move-object/from16 v3, p1

    invoke-static {v3, v1, v2}, Lcom/github/catvod/spider/appysv2/n/c;->g(Ljava/lang/String;Ljava/lang/String;Ljava/util/Map;)Lcom/github/catvod/spider/appysv2/n/e;

    move-result-object v1

    invoke-virtual {v1}, Lcom/github/catvod/spider/appysv2/n/e;->c()Ljava/util/Map;

    move-result-object v2

    const/16 v3, 0xa

    new-array v3, v3, [B

    fill-array-data v3, :array_1c2

    const/16 v4, 0x8

    new-array v5, v4, [B

    fill-array-data v5, :array_1cc

    invoke-static {v3, v5}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v3

    invoke-interface {v2, v3}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/util/List;

    iget-object v3, v0, Lcom/github/catvod/spider/appysv2/b/U;->a:Ljava/lang/String;

    iput-object v3, v0, Lcom/github/catvod/spider/appysv2/b/U;->d:Ljava/lang/String;

    const/4 v3, 0x0

    const/4 v5, 0x1

    if-nez v2, :cond_3d

    const/4 v6, 0x1

    goto :goto_3e

    :cond_3d
    const/4 v6, 0x0

    :goto_3e
    if-nez v6, :cond_198

    invoke-interface {v2}, Ljava/util/List;->size()I

    move-result v6

    if-lez v6, :cond_198

    iget-object v6, v0, Lcom/github/catvod/spider/appysv2/b/U;->d:Ljava/lang/String;

    invoke-interface {v2, v3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/String;

    const-string v7, ""

    :try_start_50
    new-array v8, v5, [B

    const/16 v9, -0x1c

    aput-byte v9, v8, v3

    new-array v9, v4, [B

    const/16 v10, -0x21

    aput-byte v10, v9, v3

    const/16 v11, -0x75

    aput-byte v11, v9, v5

    const/16 v11, -0x1b

    const/4 v12, 0x2

    aput-byte v11, v9, v12

    const/16 v11, -0x7a

    const/4 v13, 0x3

    aput-byte v11, v9, v13

    const/16 v11, 0x4a

    const/4 v14, 0x4

    aput-byte v11, v9, v14

    const/16 v11, 0x77

    const/4 v15, 0x5

    aput-byte v11, v9, v15

    const/16 v11, 0x68

    const/16 v16, 0x6

    aput-byte v11, v9, v16

    const/16 v11, 0x1e

    const/16 v17, 0x7

    aput-byte v11, v9, v17

    .line 1
    invoke-static {v8, v9}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v2, v8}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v2

    aget-object v2, v2, v3

    new-array v8, v5, [B

    const/16 v9, 0x59

    aput-byte v9, v8, v3

    new-array v9, v4, [B

    const/16 v11, 0x64

    aput-byte v11, v9, v3

    const/16 v11, -0x1a

    aput-byte v11, v9, v5

    const/16 v11, -0x53

    aput-byte v11, v9, v12

    const/16 v18, -0x51

    aput-byte v18, v9, v13

    const/16 v18, -0x20

    aput-byte v18, v9, v14

    const/16 v18, 0x63

    aput-byte v18, v9, v15

    const/16 v18, 0x4e

    aput-byte v18, v9, v16

    const/16 v18, -0x6a

    aput-byte v18, v9, v17

    invoke-static {v8, v9}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v2, v8}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v8

    aget-object v8, v8, v3

    new-array v9, v5, [B

    const/16 v18, -0x36

    aput-byte v18, v9, v3

    new-array v10, v4, [B

    const/16 v18, -0x9

    aput-byte v18, v10, v3

    const/16 v18, 0x7c

    aput-byte v18, v10, v5

    const/16 v18, 0x31

    aput-byte v18, v10, v12

    aput-byte v11, v10, v13

    aput-byte v5, v10, v14

    const/16 v11, 0x5d

    aput-byte v11, v10, v15

    const/16 v11, -0x38

    aput-byte v11, v10, v16

    const/16 v11, 0x6c

    aput-byte v11, v10, v17

    invoke-static {v9, v10}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v2, v9}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v9

    aget-object v9, v9, v5

    new-array v9, v5, [B

    const/16 v10, 0x7e

    aput-byte v10, v9, v3

    new-array v10, v4, [B

    const/16 v19, 0x45

    aput-byte v19, v10, v3

    const/16 v20, -0x6f

    aput-byte v20, v10, v5

    const/16 v20, 0x6b

    aput-byte v20, v10, v12

    const/16 v20, 0x43

    aput-byte v20, v10, v13

    aput-byte v11, v10, v14

    aput-byte v19, v10, v15

    aput-byte v20, v10, v16

    const/16 v11, -0x32

    aput-byte v11, v10, v17

    invoke-static {v9, v10}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v6, v9}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v6

    array-length v9, v6

    move-object v11, v7

    const/4 v10, 0x0

    :goto_117
    if-ge v10, v9, :cond_17f

    aget-object v15, v6, v10

    new-instance v14, Ljava/lang/StringBuilder;

    invoke-direct {v14}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v14, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v15, v8}, Ljava/lang/String;->indexOf(Ljava/lang/String;)I

    move-result v11

    if-lez v11, :cond_133

    move-object v11, v2

    const/16 v19, 0x4

    const/16 v20, 0x3

    const/16 v21, -0x21

    const/16 v23, 0x5

    goto :goto_172

    :cond_133
    new-instance v11, Ljava/lang/StringBuilder;

    invoke-direct {v11}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v11, v15}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    new-array v15, v5, [B

    const/16 v20, -0x3b

    aput-byte v20, v15, v3

    new-array v13, v4, [B

    const/16 v21, -0x2

    aput-byte v21, v13, v3

    const/16 v21, -0x21

    aput-byte v21, v13, v5

    const/16 v22, 0x4d

    aput-byte v22, v13, v12

    const/16 v22, 0x48

    const/16 v20, 0x3

    aput-byte v22, v13, v20

    const/16 v19, 0x4

    aput-byte v18, v13, v19

    const/16 v22, 0x11

    const/16 v23, 0x5

    aput-byte v22, v13, v23

    const/16 v22, 0x16

    aput-byte v22, v13, v16

    const/16 v22, 0x20

    aput-byte v22, v13, v17

    invoke-static {v15, v13}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v13

    invoke-virtual {v11, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v11}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v11

    :goto_172
    invoke-virtual {v14, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v14}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v11

    add-int/lit8 v10, v10, 0x1

    const/4 v13, 0x3

    const/4 v14, 0x4

    const/4 v15, 0x5

    goto :goto_117

    :cond_17f
    invoke-virtual {v11, v8}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v3

    if-nez v3, :cond_195

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v3, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v7
    :try_end_194
    .catch Ljava/lang/Exception; {:try_start_50 .. :try_end_194} :catch_196

    goto :goto_196

    :cond_195
    move-object v7, v11

    .line 2
    :catch_196
    :goto_196
    iput-object v7, v0, Lcom/github/catvod/spider/appysv2/b/U;->d:Ljava/lang/String;

    :cond_198
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/16 v3, 0xd

    new-array v3, v3, [B

    fill-array-data v3, :array_1d4

    new-array v4, v4, [B

    fill-array-data v4, :array_1e0

    invoke-static {v3, v4}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v3, v0, Lcom/github/catvod/spider/appysv2/b/U;->d:Ljava/lang/String;

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Lcom/github/catvod/crawler/SpiderDebug;->log(Ljava/lang/String;)V

    invoke-virtual {v1}, Lcom/github/catvod/spider/appysv2/n/e;->a()Ljava/lang/String;

    move-result-object v1

    return-object v1

    nop

    :array_1c2
    .array-data 1
        0x75t
        0x7at
        0x4t
        0x61t
        0x58t
        -0x56t
        0x2dt
        -0x20t
        0x6ft
        0x7at
    .end array-data

    nop

    :array_1cc
    .array-data 1
        0x6t
        0x1ft
        0x70t
        0x4ct
        0x3bt
        -0x3bt
        0x42t
        -0x75t
    .end array-data

    :array_1d4
    .array-data 1
        0x74t
        -0x24t
        0x25t
        0x8t
        -0xdt
        -0x6bt
        -0x14t
        -0x4ct
        0x6dt
        -0x2bt
        0x75t
        0x4bt
        -0x70t
    .end array-data

    nop

    :array_1e0
    .array-data 1
        0x4t
        -0x50t
        0x44t
        0x71t
        -0x50t
        -0x6t
        -0x7dt
        -0x21t
    .end array-data
.end method

.method private O(Ljava/lang/String;)V
    .registers 5

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    new-instance v1, Lcom/github/catvod/spider/appysv2/l/a;

    invoke-direct {v1}, Lcom/github/catvod/spider/appysv2/l/a;-><init>()V

    const-string v2, ""

    invoke-virtual {v1, v2}, Lcom/github/catvod/spider/appysv2/l/a;->j(Ljava/lang/String;)Lcom/github/catvod/spider/appysv2/l/a;

    invoke-direct {p0, p1, v1, v0}, Lcom/github/catvod/spider/appysv2/b/U;->J(Ljava/lang/String;Lcom/github/catvod/spider/appysv2/l/a;Ljava/util/List;)V

    iget-object p1, p0, Lcom/github/catvod/spider/appysv2/b/U;->e:Lcom/github/catvod/spider/appysv2/l/e;

    invoke-virtual {p1, v0}, Lcom/github/catvod/spider/appysv2/l/e;->d(Ljava/util/List;)V

    return-void
.end method

.method private P(Ljava/lang/String;)V
    .registers 3

    iput-object p1, p0, Lcom/github/catvod/spider/appysv2/b/U;->a:Ljava/lang/String;

    const/4 p1, 0x3

    new-array p1, p1, [B

    fill-array-data p1, :array_20

    const/16 v0, 0x8

    new-array v0, v0, [B

    fill-array-data v0, :array_26

    invoke-static {p1, v0}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object p1

    iget-object v0, p0, Lcom/github/catvod/spider/appysv2/b/U;->a:Ljava/lang/String;

    invoke-static {p1, v0}, Lcom/github/catvod/spider/appysv2/p/C;->u(Ljava/lang/String;Ljava/lang/String;)V

    invoke-direct {p0}, Lcom/github/catvod/spider/appysv2/b/U;->I()Z

    invoke-direct {p0}, Lcom/github/catvod/spider/appysv2/b/U;->S()V

    return-void

    nop

    :array_20
    .array-data 1
        -0x77t
        -0x1bt
        -0x4et
    .end array-data

    :array_26
    .array-data 1
        -0x59t
        -0x70t
        -0x2ft
        0x10t
        -0x4ct
        -0x4et
        -0x7ft
        0x24t
    .end array-data
.end method

.method private S()V
    .registers 3

    iget-object v0, p0, Lcom/github/catvod/spider/appysv2/b/U;->c:Ljava/util/concurrent/ScheduledExecutorService;

    if-eqz v0, :cond_7

    invoke-interface {v0}, Ljava/util/concurrent/ExecutorService;->shutdownNow()Ljava/util/List;

    :cond_7
    new-instance v0, Lcom/github/catvod/spider/appysv2/b/f;

    const/4 v1, 0x3

    invoke-direct {v0, p0, v1}, Lcom/github/catvod/spider/appysv2/b/f;-><init>(Ljava/lang/Object;I)V

    invoke-static {v0}, Lcom/github/catvod/spider/Init;->run(Ljava/lang/Runnable;)V

    return-void
.end method

.method public static a(Lcom/github/catvod/spider/appysv2/b/U;)V
    .registers 1

    invoke-direct {p0}, Lcom/github/catvod/spider/appysv2/b/U;->S()V

    return-void
.end method

.method public static synthetic b(Lcom/github/catvod/spider/appysv2/b/U;Lorg/json/JSONObject;)V
    .registers 18

    move-object/from16 v0, p1

    invoke-virtual/range {p0 .. p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v2

    invoke-virtual {v1, v2, v3}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const-string v2, ""

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/16 v2, 0x9

    new-array v3, v2, [B

    fill-array-data v3, :array_1ee

    const/16 v4, 0x8

    new-array v5, v4, [B

    fill-array-data v5, :array_1f8

    invoke-static {v3, v5}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v0, v3}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    const/4 v5, 0x5

    new-array v6, v5, [B

    fill-array-data v6, :array_200

    new-array v7, v4, [B

    fill-array-data v7, :array_208

    invoke-static {v6, v7}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v0, v6}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    new-array v2, v2, [B

    fill-array-data v2, :array_210

    new-array v7, v4, [B

    fill-array-data v7, :array_21a

    invoke-static {v2, v7}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Lcom/github/catvod/spider/appysv2/p/C;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    new-instance v7, Ljava/lang/StringBuilder;

    invoke-direct {v7}, Ljava/lang/StringBuilder;-><init>()V

    const/16 v8, 0x2f

    new-array v9, v8, [B

    fill-array-data v9, :array_222

    new-array v10, v4, [B

    fill-array-data v10, :array_23e

    .line 2
    invoke-static {v9, v10, v7, v2}, Lcom/github/catvod/spider/appysv2/b/v;->c([B[BLjava/lang/StringBuilder;Ljava/lang/String;)V

    const/16 v9, 0x27

    new-array v9, v9, [B

    .line 3
    fill-array-data v9, :array_246

    new-array v10, v4, [B

    fill-array-data v10, :array_25e

    .line 4
    invoke-static {v9, v10, v7, v0}, Lcom/github/catvod/spider/appysv2/b/v;->c([B[BLjava/lang/StringBuilder;Ljava/lang/String;)V

    const/16 v9, 0xc5

    new-array v9, v9, [B

    .line 5
    fill-array-data v9, :array_266

    new-array v10, v4, [B

    fill-array-data v10, :array_2ce

    .line 6
    invoke-static {v9, v10, v7, v3}, Lcom/github/catvod/spider/appysv2/b/v;->c([B[BLjava/lang/StringBuilder;Ljava/lang/String;)V

    const/16 v9, 0x1b

    new-array v9, v9, [B

    .line 7
    fill-array-data v9, :array_2d6

    new-array v10, v4, [B

    fill-array-data v10, :array_2e8

    .line 8
    invoke-static {v9, v10, v7, v6}, Lcom/github/catvod/spider/appysv2/b/u;->a([B[BLjava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    const/16 v7, 0x33

    new-array v7, v7, [B

    .line 9
    fill-array-data v7, :array_2f0

    new-array v9, v4, [B

    fill-array-data v9, :array_30e

    invoke-static {v7, v9}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v7

    const/4 v9, 0x1

    new-array v10, v9, [Ljava/lang/Object;

    const/4 v11, 0x0

    aput-object v1, v10, v11

    invoke-static {v7, v10}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v7

    invoke-static {v7}, Lcom/github/catvod/spider/appysv2/p/C;->b(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    new-instance v10, Ljava/util/HashMap;

    invoke-direct {v10}, Ljava/util/HashMap;-><init>()V

    const/16 v12, 0xa

    new-array v12, v12, [B

    fill-array-data v12, :array_316

    new-array v13, v4, [B

    fill-array-data v13, :array_320

    invoke-static {v12, v13}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v12

    const/16 v13, 0x78

    new-array v13, v13, [B

    fill-array-data v13, :array_328

    new-array v14, v4, [B

    fill-array-data v14, :array_368

    invoke-static {v13, v14}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v13

    invoke-virtual {v10, v12, v13}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    new-array v12, v4, [B

    fill-array-data v12, :array_370

    new-array v13, v4, [B

    fill-array-data v13, :array_378

    invoke-static {v12, v13}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v12

    invoke-virtual {v10, v12, v1}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v1, 0x4

    new-array v12, v1, [B

    fill-array-data v12, :array_380

    new-array v13, v4, [B

    fill-array-data v13, :array_386

    invoke-static {v12, v13}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v12

    const/16 v13, 0x14

    new-array v13, v13, [B

    fill-array-data v13, :array_38e

    new-array v14, v4, [B

    fill-array-data v14, :array_39c

    invoke-static {v13, v14}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v13

    invoke-virtual {v10, v12, v13}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/16 v12, 0xb

    new-array v12, v12, [B

    fill-array-data v12, :array_3a4

    new-array v13, v4, [B

    fill-array-data v13, :array_3ae

    invoke-static {v12, v13}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v12

    invoke-virtual {v10, v12, v7}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/16 v7, 0xf

    new-array v7, v7, [B

    fill-array-data v7, :array_3b6

    new-array v12, v4, [B

    fill-array-data v12, :array_3c2

    invoke-static {v7, v12}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v10, v7, v3}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    invoke-static {v6, v10}, Lcom/github/catvod/spider/appysv2/n/c;->m(Ljava/lang/String;Ljava/util/Map;)Ljava/lang/String;

    move-result-object v3

    :try_start_14d
    new-instance v6, Lorg/json/JSONObject;

    invoke-direct {v6, v3}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x6

    new-array v7, v3, [B

    const/16 v10, 0x21

    aput-byte v10, v7, v11

    const/16 v10, 0x71

    aput-byte v10, v7, v9

    const/4 v12, 0x2

    aput-byte v10, v7, v12

    const/16 v10, -0x31

    const/4 v13, 0x3

    aput-byte v10, v7, v13

    const/16 v10, 0x36

    aput-byte v10, v7, v1

    const/4 v10, -0x2

    aput-byte v10, v7, v5

    new-array v10, v4, [B

    const/16 v14, 0x52

    aput-byte v14, v10, v11

    aput-byte v5, v10, v9

    const/16 v14, 0x10

    aput-byte v14, v10, v12

    const/16 v14, -0x45

    aput-byte v14, v10, v13

    const/16 v14, 0x43

    aput-byte v14, v10, v1

    const/16 v14, -0x73

    aput-byte v14, v10, v5

    const/16 v14, 0x20

    aput-byte v14, v10, v3

    const/16 v14, -0x14

    const/4 v15, 0x7

    aput-byte v14, v10, v15

    invoke-static {v7, v10}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v6, v7}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;)I

    move-result v7

    if-nez v7, :cond_1ed

    new-array v7, v1, [B

    const/16 v10, 0x32

    aput-byte v10, v7, v11

    const/16 v10, 0xd

    aput-byte v10, v7, v9

    const/16 v10, 0x38

    aput-byte v10, v7, v12

    const/16 v10, 0x7d

    aput-byte v10, v7, v13

    new-array v10, v4, [B

    const/16 v14, 0x51

    aput-byte v14, v10, v11

    const/16 v11, 0x62

    aput-byte v11, v10, v9

    const/16 v9, 0x5c

    aput-byte v9, v10, v12

    const/16 v9, 0x18

    aput-byte v9, v10, v13

    aput-byte v8, v10, v1

    const/16 v8, 0x1d

    aput-byte v8, v10, v5

    const/16 v5, 0x26

    aput-byte v5, v10, v3

    const/16 v3, 0x63

    aput-byte v3, v10, v15

    invoke-static {v7, v10}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v6, v3}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    move-object/from16 v5, p0

    invoke-direct {v5, v2, v0, v3}, Lcom/github/catvod/spider/appysv2/b/U;->G(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    invoke-direct/range {p0 .. p0}, Lcom/github/catvod/spider/appysv2/b/U;->S()V
    :try_end_1d9
    .catch Ljava/lang/Exception; {:try_start_14d .. :try_end_1d9} :catch_1da

    goto :goto_1ed

    :catch_1da
    move-exception v0

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    new-array v1, v1, [B

    fill-array-data v1, :array_3ca

    new-array v3, v4, [B

    fill-array-data v3, :array_3d0

    .line 10
    invoke-static {v1, v3, v2, v0}, Lcom/github/catvod/spider/appysv2/b/y;->b([B[BLjava/lang/StringBuilder;Ljava/lang/Exception;)V

    :cond_1ed
    :goto_1ed
    return-void

    :array_1ee
    .array-data 1
        -0x1bt
        -0x3dt
        0x6ct
        0xet
        0x59t
        -0x6at
        0x56t
        0xft
        -0x1et
    .end array-data

    nop

    :array_1f8
    .array-data 1
        -0x7at
        -0x51t
        0x5t
        0x6bt
        0x37t
        -0x1et
        0x9t
        0x66t
    .end array-data

    :array_200
    .array-data 1
        -0x50t
        0x41t
        -0x6dt
        0x7ct
        -0x1ft
    .end array-data

    nop

    :array_208
    .array-data 1
        -0x3ct
        0x2et
        -0x8t
        0x19t
        -0x71t
        -0x9t
        -0x9t
        -0x9t
    .end array-data

    :array_210
    .array-data 1
        -0x6bt
        -0x11t
        -0x39t
        -0x62t
        0x1ct
        -0x3bt
        -0x5dt
        -0x4ct
        -0x6bt
    .end array-data

    nop

    :array_21a
    .array-data 1
        -0xft
        -0x76t
        -0x4ft
        -0x9t
        0x7ft
        -0x60t
        -0x4t
        -0x23t
    .end array-data

    :array_222
    .array-data 1
        -0x33t
        0x57t
        -0x1ft
        0x7et
        0x0t
        0x6ct
        0x4ft
        0x36t
        -0x36t
        0x53t
        -0x10t
        0x60t
        0x5et
        0x37t
        0x10t
        0x70t
        -0x78t
        0x47t
        -0x19t
        0x67t
        0x5t
        0x33t
        0x4et
        0x6ct
        -0x3at
        0xdt
        -0xat
        0x60t
        0x5ct
        0x39t
        0x1t
        0x6ct
        -0x2ft
        0x4bt
        -0x46t
        0x6dt
        0x1ct
        0x32t
        0x5t
        0x26t
        -0x29t
        0x46t
        -0x1ct
        0x51t
        0x1at
        0x32t
        0x5dt
    .end array-data

    :array_23e
    .array-data 1
        -0x5bt
        0x23t
        -0x6bt
        0xet
        0x73t
        0x56t
        0x60t
        0x19t
    .end array-data

    :array_246
    .array-data 1
        -0x17t
        0x7ft
        -0x17t
        -0x67t
        -0x62t
        -0x46t
        -0x2ct
        0x20t
        -0x45t
        0x71t
        -0x1ft
        -0x61t
        -0x6bt
        -0xct
        -0x7ft
        0x1et
        -0x41t
        0x6et
        -0x2bt
        -0x74t
        -0x62t
        -0x45t
        -0x66t
        0x4et
        -0x1ft
        0x28t
        -0x5ct
        -0x3et
        -0x23t
        -0x53t
        -0x3et
        0x9t
        -0x5at
        0x7dt
        -0x11t
        -0x5bt
        -0x6et
        -0x53t
        -0x66t
    .end array-data

    :array_25e
    .array-data 1
        -0x31t
        0x1et
        -0x76t
        -0x6t
        -0x5t
        -0x37t
        -0x59t
        0x7ft
    .end array-data

    :array_266
    .array-data 1
        -0x67t
        0x22t
        0x13t
        -0x18t
        -0x44t
        0x3t
        -0x75t
        -0x79t
        -0x23t
        0x34t
        0x17t
        -0x10t
        -0x4ft
        0x5dt
        -0x68t
        -0x4ft
        -0x37t
        0x29t
        0x50t
        -0x12t
        -0x47t
        0x1t
        -0x66t
        -0x42t
        -0x30t
        0x34t
        0x1bt
        -0x5dt
        -0x5ft
        0x16t
        -0x38t
        -0x44t
        -0x26t
        0x30t
        0x1ft
        -0x3t
        -0x50t
        0x3ft
        -0x80t
        -0x47t
        -0x2et
        0x23t
        0x4bt
        -0x38t
        -0x19t
        0x52t
        -0x23t
        -0x20t
        -0x2t
        0x60t
        0x12t
        -0x5t
        -0x5dt
        0x9t
        -0x73t
        -0x43t
        -0x20t
        0x2bt
        0x19t
        -0x6t
        -0x50t
        0xct
        -0x2dt
        -0x72t
        -0x73t
        0x74t
        0x45t
        -0x5at
        -0x6ct
        0x46t
        -0x74t
        -0x53t
        -0x2at
        0x2at
        0x12t
        -0x3ft
        -0x4ft
        0x5t
        -0x68t
        -0x4ft
        -0x24t
        0x23t
        0x4bt
        -0x38t
        -0x19t
        0x52t
        -0x23t
        -0x20t
        -0x2t
        0x60t
        0x14t
        -0x15t
        -0x44t
        0xct
        -0x76t
        -0x79t
        -0x31t
        0x34t
        0x19t
        -0x6t
        -0x60t
        0x3t
        -0x66t
        -0x1bt
        -0x17t
        0x74t
        0x44t
        -0x53t
        -0x13t
        0x21t
        -0x38t
        -0x44t
        -0x26t
        0x30t
        0x1ft
        -0x3t
        -0x50t
        0x3ft
        -0x77t
        -0x58t
        -0x36t
        0x7bt
        0x37t
        -0x6t
        -0x59t
        0x5t
        -0x80t
        -0x49t
        -0x66t
        0x74t
        0x46t
        -0x4at
        -0x7ft
        0x2dt
        -0x39t
        -0x3t
        -0x73t
        0x76t
        0x40t
        -0x56t
        -0x1bt
        0x46t
        -0x71t
        -0x45t
        -0x35t
        0x2ft
        0x0t
        -0x9t
        -0x5ft
        0x19t
        -0x4ft
        -0x56t
        -0x26t
        0x25t
        0x2t
        -0x5dt
        -0x10t
        0x57t
        -0x54t
        -0x3t
        -0x78t
        0x2t
        0x50t
        -0x3t
        -0x43t
        0x1t
        -0x80t
        -0x4at
        -0x26t
        0x2at
        0x4bt
        -0x35t
        -0x6at
        0x34t
        -0x48t
        -0x69t
        -0x7t
        0x0t
        0x3ft
        -0x23t
        -0x64t
        0x21t
        -0x5et
        -0x71t
        -0x6t
        0x4t
        0x50t
        -0x3t
        -0x47t
        0x9t
        -0x75t
        -0x4at
        -0x35t
        0x19t
        0x1ft
        -0x6t
        -0x18t
    .end array-data

    nop

    :array_2ce
    .array-data 1
        -0x41t
        0x46t
        0x76t
        -0x62t
        -0x2bt
        0x60t
        -0x12t
        -0x28t
    .end array-data

    :array_2d6
    .array-data 1
        -0x32t
        -0x5at
        -0x23t
        -0x3t
        -0x73t
        -0x2bt
        0xbt
        -0x1at
        -0x73t
        -0x5ft
        -0x26t
        -0x5t
        -0x72t
        -0x25t
        0x10t
        -0x7t
        -0x63t
        -0x50t
        -0x34t
        -0x15t
        -0x5et
        -0x3ct
        0x59t
        -0x1dt
        -0x73t
        -0x45t
        -0x7dt
    .end array-data

    :array_2e8
    .array-data 1
        -0x18t
        -0x2bt
        -0x42t
        -0x6et
        -0x3t
        -0x50t
        0x36t
        -0x78t
    .end array-data

    :array_2f0
    .array-data 1
        -0x69t
        -0x74t
        0x46t
        0x41t
        0x4dt
        -0x15t
        -0x18t
        0x59t
        -0x5ct
        -0x5ft
        0x3dt
        0x4t
        0xdt
        -0x20t
        -0x14t
        0xat
        -0xbt
        -0x46t
        0x34t
        0xbt
        0x51t
        -0x9t
        -0x5t
        0x5at
        -0x5ct
        -0x53t
        0x25t
        0x17t
        0x56t
        -0x4at
        -0x1bt
        0x1ct
        -0x4ct
        -0x7t
        0x6at
        0x56t
        0x17t
        -0x44t
        -0x13t
        0x1bt
        -0x57t
        -0x56t
        0x2at
        0x1et
        0x7t
        -0x43t
        -0x1et
        0x47t
        -0x47t
        -0x3t
        0x76t
    .end array-data

    :array_30e
    .array-data 1
        -0x30t
        -0x37t
        0x12t
        0x67t
        0x62t
        -0x7ct
        -0x77t
        0x2ct
    .end array-data

    :array_316
    .array-data 1
        0x75t
        0x40t
        -0x77t
        0x55t
        -0x8t
        0x4dt
        -0x45t
        0xdt
        0x4et
        0x47t
    .end array-data

    nop

    :array_320
    .array-data 1
        0x20t
        0x33t
        -0x14t
        0x27t
        -0x2bt
        0xct
        -0x24t
        0x68t
    .end array-data

    :array_328
    .array-data 1
        -0x5ft
        -0x72t
        -0x4bt
        0x48t
        0x5t
        0x4ft
        -0x4t
        0x67t
        -0x27t
        -0x31t
        -0x1t
        0x1t
        0x41t
        0x6ft
        -0xct
        0x26t
        -0x67t
        -0x67t
        -0xct
        0x1t
        0x3ct
        0x18t
        -0x43t
        0x9t
        -0x7et
        -0x7bt
        -0x43t
        0x4et
        0x0t
        0x47t
        -0x43t
        0x79t
        -0x22t
        -0x26t
        -0x11t
        0x5bt
        0x1t
        0xet
        -0x2t
        0x26t
        -0x29t
        -0x3ft
        -0x67t
        0x13t
        0x5bt
        0x10t
        -0x5bt
        0x9t
        -0x34t
        -0x5dt
        -0x46t
        0x48t
        0x5t
        0x47t
        -0x4et
        0x1et
        -0x28t
        -0x30t
        -0x8t
        0x68t
        0x3bt
        0xat
        -0x43t
        0x9t
        -0x64t
        -0x6ft
        -0x5dt
        0x44t
        0x3et
        0x46t
        -0x1t
        0x3t
        -0x7bt
        -0x6bt
        -0x20t
        0x14t
        0x5at
        0x10t
        -0x4dt
        0x79t
        -0x34t
        -0x37t
        -0x7ct
        0x69t
        0x3dt
        0x6et
        -0x2ft
        0x64t
        -0x34t
        -0x73t
        -0x5at
        0x4at
        0xct
        0x3t
        -0x26t
        0x2dt
        -0x71t
        -0x76t
        -0x60t
        0x8t
        0x49t
        0x6et
        -0xet
        0x2at
        -0x7bt
        -0x73t
        -0x56t
        0x1t
        0x3at
        0x42t
        -0x5t
        0x29t
        -0x62t
        -0x78t
        -0x20t
        0x14t
        0x5at
        0x10t
        -0x4dt
        0x79t
    .end array-data

    :array_368
    .array-data 1
        -0x14t
        -0x1ft
        -0x31t
        0x21t
        0x69t
        0x23t
        -0x63t
        0x48t
    .end array-data

    :array_370
    .array-data 1
        0x6et
        -0x41t
        -0x13t
        0x44t
        0x2ft
        -0x46t
        0x30t
        -0x7at
    .end array-data

    :array_378
    .array-data 1
        0x16t
        -0x6et
        -0x63t
        0x25t
        0x41t
        -0x69t
        0x44t
        -0x15t
    .end array-data

    :array_380
    .array-data 1
        0x4ct
        0x26t
        0x54t
        -0x6at
    .end array-data

    :array_386
    .array-data 1
        0x24t
        0x49t
        0x27t
        -0x1et
        0x9t
        -0x47t
        -0x78t
        -0x10t
    .end array-data

    :array_38e
    .array-data 1
        0x37t
        0x4ft
        0x4ct
        0x6ft
        -0x50t
        -0x69t
        -0x7at
        0x1ft
        0x75t
        0x5bt
        0x5bt
        0x68t
        -0x15t
        -0x6dt
        -0x28t
        0x3t
        0x3bt
        0x11t
        0x4at
        0x6ft
    .end array-data

    :array_39c
    .array-data 1
        0x58t
        0x3ft
        0x29t
        0x1t
        -0x63t
        -0xat
        -0xat
        0x76t
    .end array-data

    :array_3a4
    .array-data 1
        -0x46t
        0x7bt
        -0x8t
        -0x2dt
        0x2bt
        -0x33t
        -0x2bt
        0x73t
        -0x57t
        0x33t
        -0x1at
    .end array-data

    :array_3ae
    .array-data 1
        -0x3et
        0x56t
        -0x78t
        -0x4et
        0x45t
        -0x20t
        -0x5ft
        0x1ct
    .end array-data

    :array_3b6
    .array-data 1
        0x61t
        0x60t
        0x1ct
        0x55t
        0x41t
        0x5bt
        -0x70t
        0x24t
        0x70t
        0x28t
        0x2t
        0x40t
        0x2t
        0x1ft
        -0x69t
    .end array-data

    :array_3c2
    .array-data 1
        0x19t
        0x4dt
        0x6ct
        0x34t
        0x2ft
        0x76t
        -0xdt
        0x48t
    .end array-data

    :array_3ca
    .array-data 1
        -0x69t
        -0x18t
        -0x7t
        -0x40t
    .end array-data

    :array_3d0
    .array-data 1
        -0xet
        -0x27t
        -0x3dt
        -0x20t
        -0x76t
        -0x14t
        -0x1bt
        -0x80t
    .end array-data
.end method

.method public static synthetic c(Lcom/github/catvod/spider/appysv2/b/U;)V
    .registers 1

    invoke-direct {p0}, Lcom/github/catvod/spider/appysv2/b/U;->s()V

    return-void
.end method

.method public static d(Lcom/github/catvod/spider/appysv2/b/U;Ljava/lang/String;)V
    .registers 4

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v0, 0x4

    new-array v0, v0, [B

    .line 1
    fill-array-data v0, :array_24

    const/16 v1, 0x8

    new-array v1, v1, [B

    fill-array-data v1, :array_2a

    invoke-static {v0, v1}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_1f

    const/4 v0, 0x0

    .line 2
    invoke-static {p1, v0}, Lcom/github/catvod/spider/appysv2/n/c;->m(Ljava/lang/String;Ljava/util/Map;)Ljava/lang/String;

    move-result-object p1

    .line 3
    :cond_1f
    invoke-direct {p0, p1}, Lcom/github/catvod/spider/appysv2/b/U;->P(Ljava/lang/String;)V

    return-void

    nop

    :array_24
    .array-data 1
        0x14t
        0x9t
        -0xbt
        0x74t
    .end array-data

    :array_2a
    .array-data 1
        0x7ct
        0x7dt
        -0x7ft
        0x4t
        -0x68t
        -0xft
        -0x77t
        0x67t
    .end array-data
.end method

.method public static e(Lcom/github/catvod/spider/appysv2/b/U;Landroid/widget/EditText;)V
    .registers 4

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1
    invoke-virtual {p1}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p1

    .line 2
    invoke-direct {p0}, Lcom/github/catvod/spider/appysv2/b/U;->s()V

    new-instance v0, Lcom/github/catvod/spider/appysv2/p/z;

    const/4 v1, 0x3

    invoke-direct {v0, p0, p1, v1}, Lcom/github/catvod/spider/appysv2/p/z;-><init>(Ljava/lang/Object;Ljava/lang/Object;I)V

    invoke-static {v0}, Lcom/github/catvod/spider/Init;->execute(Ljava/lang/Runnable;)V

    return-void
.end method

.method public static f(Lcom/github/catvod/spider/appysv2/b/U;)V
    .registers 3

    invoke-direct {p0}, Lcom/github/catvod/spider/appysv2/b/U;->s()V

    new-instance v0, Lcom/github/catvod/spider/appysv2/b/a;

    const/4 v1, 0x2

    invoke-direct {v0, p0, v1}, Lcom/github/catvod/spider/appysv2/b/a;-><init>(Ljava/lang/Object;I)V

    invoke-static {v0}, Lcom/github/catvod/spider/Init;->execute(Ljava/lang/Runnable;)V

    return-void
.end method

.method public static g(Lcom/github/catvod/spider/appysv2/b/U;)V
    .registers 1

    invoke-direct {p0}, Lcom/github/catvod/spider/appysv2/b/U;->S()V

    return-void
.end method

.method public static synthetic h(Lcom/github/catvod/spider/appysv2/b/U;)V
    .registers 1

    invoke-direct {p0}, Lcom/github/catvod/spider/appysv2/b/U;->B()V

    return-void
.end method

.method public static i(Lcom/github/catvod/spider/appysv2/b/U;Lorg/json/JSONObject;)V
    .registers 10

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v0, 0x5

    new-array v0, v0, [B

    .line 1
    fill-array-data v0, :array_30

    const/16 v1, 0x8

    new-array v1, v1, [B

    fill-array-data v1, :array_38

    invoke-static {v0, v1}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const/4 v0, 0x1

    .line 2
    invoke-static {v0}, Ljava/util/concurrent/Executors;->newScheduledThreadPool(I)Ljava/util/concurrent/ScheduledExecutorService;

    move-result-object v1

    iput-object v1, p0, Lcom/github/catvod/spider/appysv2/b/U;->c:Ljava/util/concurrent/ScheduledExecutorService;

    new-instance v2, Lcom/github/catvod/spider/appysv2/b/i;

    const/4 v0, 0x3

    invoke-direct {v2, p0, p1, v0}, Lcom/github/catvod/spider/appysv2/b/i;-><init>(Ljava/lang/Object;Ljava/lang/Object;I)V

    sget-object v7, Ljava/util/concurrent/TimeUnit;->SECONDS:Ljava/util/concurrent/TimeUnit;

    const-wide/16 v3, 0x1

    const-wide/16 v5, 0x1

    invoke-interface/range {v1 .. v7}, Ljava/util/concurrent/ScheduledExecutorService;->scheduleWithFixedDelay(Ljava/lang/Runnable;JJLjava/util/concurrent/TimeUnit;)Ljava/util/concurrent/ScheduledFuture;

    return-void

    nop

    :array_30
    .array-data 1
        0x2at
        0x15t
        0x7at
        -0x57t
        -0x19t
    .end array-data

    nop

    :array_38
    .array-data 1
        0x5et
        0x7at
        0x11t
        -0x34t
        -0x77t
        -0x1at
        -0x21t
        0x57t
    .end array-data
.end method

.method public static j(Lcom/github/catvod/spider/appysv2/b/U;Lorg/json/JSONObject;)V
    .registers 23

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    invoke-virtual/range {p0 .. p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v2, 0xf0

    :try_start_9
    invoke-static {v2}, Lcom/github/catvod/spider/appysv2/a/a;->b(I)I

    move-result v2

    new-instance v3, Landroid/widget/FrameLayout$LayoutParams;

    invoke-direct {v3, v2, v2}, Landroid/widget/FrameLayout$LayoutParams;-><init>(II)V

    new-instance v4, Landroid/widget/ImageView;

    invoke-static {}, Lcom/github/catvod/spider/Init;->context()Landroid/app/Application;

    move-result-object v5

    invoke-direct {v4, v5}, Landroid/widget/ImageView;-><init>(Landroid/content/Context;)V

    sget-object v5, Landroid/widget/ImageView$ScaleType;->CENTER_CROP:Landroid/widget/ImageView$ScaleType;

    invoke-virtual {v4, v5}, Landroid/widget/ImageView;->setScaleType(Landroid/widget/ImageView$ScaleType;)V

    const/4 v5, 0x3

    new-array v6, v5, [B

    const/16 v7, 0x3e

    const/4 v8, 0x0

    aput-byte v7, v6, v8

    const/4 v7, 0x7

    const/4 v9, 0x1

    aput-byte v7, v6, v9

    const/16 v10, 0x45

    const/4 v11, 0x2

    aput-byte v10, v6, v11

    const/16 v10, 0x8

    new-array v12, v10, [B

    const/16 v13, 0x4b

    aput-byte v13, v12, v8

    const/16 v13, 0x75

    aput-byte v13, v12, v9

    const/16 v14, 0x29

    aput-byte v14, v12, v11

    const/16 v15, -0x45

    aput-byte v15, v12, v5

    const/16 v15, 0x1a

    const/16 v16, 0x4

    aput-byte v15, v12, v16

    const/16 v17, -0x1e

    const/16 v18, 0x5

    aput-byte v17, v12, v18

    const/16 v17, -0x7e

    const/16 v19, 0x6

    aput-byte v17, v12, v19

    const/16 v20, -0x4d

    aput-byte v20, v12, v7

    invoke-static {v6, v12}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v1, v6}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    invoke-static {v6, v2}, Lcom/github/catvod/spider/appysv2/B/l;->e(Ljava/lang/String;I)Landroid/graphics/Bitmap;

    move-result-object v2

    invoke-virtual {v4, v2}, Landroid/widget/ImageView;->setImageBitmap(Landroid/graphics/Bitmap;)V

    new-instance v2, Landroid/widget/FrameLayout;

    invoke-static {}, Lcom/github/catvod/spider/Init;->context()Landroid/app/Application;

    move-result-object v6

    invoke-direct {v2, v6}, Landroid/widget/FrameLayout;-><init>(Landroid/content/Context;)V

    const/16 v6, 0x11

    iput v6, v3, Landroid/widget/FrameLayout$LayoutParams;->gravity:I

    invoke-virtual {v2, v4, v3}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    new-instance v3, Landroid/app/AlertDialog$Builder;

    invoke-static {}, Lcom/github/catvod/spider/Init;->getActivity()Landroid/app/Activity;

    move-result-object v4

    invoke-direct {v3, v4}, Landroid/app/AlertDialog$Builder;-><init>(Landroid/content/Context;)V

    invoke-virtual {v3, v2}, Landroid/app/AlertDialog$Builder;->setView(Landroid/view/View;)Landroid/app/AlertDialog$Builder;

    move-result-object v2

    new-instance v3, Lcom/github/catvod/spider/appysv2/b/N;

    invoke-direct {v3, v0}, Lcom/github/catvod/spider/appysv2/b/N;-><init>(Lcom/github/catvod/spider/appysv2/b/U;)V

    invoke-virtual {v2, v3}, Landroid/app/AlertDialog$Builder;->setOnCancelListener(Landroid/content/DialogInterface$OnCancelListener;)Landroid/app/AlertDialog$Builder;

    move-result-object v2

    new-instance v3, Lcom/github/catvod/spider/appysv2/b/P;

    invoke-direct {v3, v0}, Lcom/github/catvod/spider/appysv2/b/P;-><init>(Lcom/github/catvod/spider/appysv2/b/U;)V

    invoke-virtual {v2, v3}, Landroid/app/AlertDialog$Builder;->setOnDismissListener(Landroid/content/DialogInterface$OnDismissListener;)Landroid/app/AlertDialog$Builder;

    move-result-object v2

    invoke-virtual {v2}, Landroid/app/AlertDialog$Builder;->show()Landroid/app/AlertDialog;

    move-result-object v2

    iput-object v2, v0, Lcom/github/catvod/spider/appysv2/b/U;->f:Landroid/app/AlertDialog;

    invoke-virtual {v2}, Landroid/app/Dialog;->getWindow()Landroid/view/Window;

    move-result-object v2

    new-instance v3, Landroid/graphics/drawable/ColorDrawable;

    invoke-direct {v3, v8}, Landroid/graphics/drawable/ColorDrawable;-><init>(I)V

    invoke-virtual {v2, v3}, Landroid/view/Window;->setBackgroundDrawable(Landroid/graphics/drawable/Drawable;)V

    new-instance v2, Lcom/github/catvod/spider/appysv2/b/S;

    invoke-direct {v2, v0, v1}, Lcom/github/catvod/spider/appysv2/b/S;-><init>(Lcom/github/catvod/spider/appysv2/b/U;Lorg/json/JSONObject;)V

    invoke-static {v2}, Lcom/github/catvod/spider/Init;->execute(Ljava/lang/Runnable;)V

    const/16 v0, 0x1f

    new-array v0, v0, [B

    const/16 v1, 0x69

    aput-byte v1, v0, v8

    const/16 v1, 0x6c

    aput-byte v1, v0, v9

    const/16 v1, 0x38

    aput-byte v1, v0, v11

    const/16 v1, 0x20

    aput-byte v1, v0, v5

    const/16 v1, 0x66

    aput-byte v1, v0, v16

    const/16 v1, 0x4d

    aput-byte v1, v0, v18

    const/16 v2, 0x13

    aput-byte v2, v0, v19

    const/16 v3, -0x27

    aput-byte v3, v0, v7

    aput-byte v14, v0, v10

    const/16 v3, 0x9

    const/16 v4, -0x6a

    aput-byte v4, v0, v3

    const/16 v3, 0xa

    const/16 v4, -0x34

    aput-byte v4, v0, v3

    const/16 v3, 0xb

    const/16 v4, -0x1c

    aput-byte v4, v0, v3

    const/16 v3, 0xc

    const/16 v4, -0x66

    aput-byte v4, v0, v3

    const/16 v3, 0xd

    aput-byte v17, v0, v3

    const/16 v4, 0xe

    const/16 v12, -0x7c

    aput-byte v12, v0, v4

    const/16 v4, 0xf

    const/16 v12, 0x6d

    aput-byte v12, v0, v4

    const/16 v4, 0x67

    const/16 v12, 0x10

    aput-byte v4, v0, v12

    const/16 v4, 0x4a

    aput-byte v4, v0, v6

    const/16 v4, 0x12

    const/16 v6, 0x24

    aput-byte v6, v0, v4

    const/16 v4, 0x22

    aput-byte v4, v0, v2

    const/16 v2, 0x14

    const/16 v4, 0x54

    aput-byte v4, v0, v2

    const/16 v2, 0x15

    const/16 v4, 0x7d

    aput-byte v4, v0, v2

    const/16 v2, 0x16

    aput-byte v12, v0, v2

    const/16 v2, 0x17

    const/16 v4, -0x9

    aput-byte v4, v0, v2

    const/16 v2, 0x18

    aput-byte v3, v0, v2

    const/16 v2, 0x19

    aput-byte v6, v0, v2

    const/16 v2, 0x34

    aput-byte v2, v0, v15

    const/16 v2, 0x1b

    const/16 v3, 0x70

    aput-byte v3, v0, v2

    const/16 v2, 0x1c

    const/16 v3, 0x3c

    aput-byte v3, v0, v2

    const/16 v2, 0x1d

    const/16 v3, 0x52

    aput-byte v3, v0, v2

    const/16 v2, 0x1e

    aput-byte v13, v0, v2

    new-array v2, v10, [B

    const/16 v3, -0x7f

    aput-byte v3, v2, v8

    const/16 v3, -0x3d

    aput-byte v3, v2, v9

    const/16 v3, -0x71

    aput-byte v3, v2, v11

    const/16 v3, -0x3c

    aput-byte v3, v2, v5

    const/16 v3, -0x25

    aput-byte v3, v2, v16

    const/16 v3, -0xe

    aput-byte v3, v2, v18

    const/16 v3, -0xc

    aput-byte v3, v2, v19

    aput-byte v1, v2, v7

    invoke-static {v0, v2}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lcom/github/catvod/spider/appysv2/p/j;->b(Ljava/lang/String;)V
    :try_end_174
    .catch Ljava/lang/Exception; {:try_start_9 .. :try_end_174} :catch_174

    :catch_174
    return-void
.end method

.method public static synthetic k(Lcom/github/catvod/spider/appysv2/b/U;Ljava/lang/String;)V
    .registers 46

    move-object/from16 v0, p0

    invoke-virtual/range {p0 .. p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v1, Ljava/util/HashMap;

    invoke-direct {v1}, Ljava/util/HashMap;-><init>()V

    const/16 v2, 0x9

    new-array v3, v2, [B

    fill-array-data v3, :array_55e

    const/16 v4, 0x8

    new-array v5, v4, [B

    fill-array-data v5, :array_568

    invoke-static {v3, v5}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v3

    const/4 v5, 0x3

    new-array v6, v5, [B

    fill-array-data v6, :array_570

    new-array v7, v4, [B

    fill-array-data v7, :array_576

    invoke-static {v6, v7}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v1, v3, v6}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v3, 0x1

    new-array v6, v3, [B

    const/4 v7, 0x0

    const/16 v8, 0xa

    aput-byte v8, v6, v7

    new-array v9, v4, [B

    fill-array-data v9, :array_57e

    invoke-static {v6, v9}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v6

    new-array v9, v5, [B

    fill-array-data v9, :array_586

    new-array v10, v4, [B

    fill-array-data v10, :array_58c

    invoke-static {v9, v10}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v1, v6, v9}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    new-array v6, v8, [B

    fill-array-data v6, :array_594

    new-array v9, v4, [B

    fill-array-data v9, :array_59e

    invoke-static {v6, v9}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v6

    iget-object v9, v0, Lcom/github/catvod/spider/appysv2/b/U;->h:Ljava/lang/String;

    invoke-virtual {v1, v6, v9}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v6, 0x5

    new-array v9, v6, [B

    fill-array-data v9, :array_5a6

    new-array v10, v4, [B

    fill-array-data v10, :array_5ae

    invoke-static {v9, v10}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v9

    move-object/from16 v10, p1

    invoke-virtual {v1, v9, v10}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    new-instance v9, Ljava/lang/StringBuilder;

    invoke-direct {v9}, Ljava/lang/StringBuilder;-><init>()V

    const/16 v10, 0x4c

    new-array v11, v10, [B

    fill-array-data v11, :array_5b6

    new-array v12, v4, [B

    fill-array-data v12, :array_5e0

    invoke-static {v11, v12}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v11

    invoke-virtual {v9, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v11, v0, Lcom/github/catvod/spider/appysv2/b/U;->h:Ljava/lang/String;

    invoke-virtual {v9, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v9}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v9

    invoke-direct/range {p0 .. p0}, Lcom/github/catvod/spider/appysv2/b/U;->y()Ljava/util/Map;

    move-result-object v11

    invoke-static {v9, v1, v11}, Lcom/github/catvod/spider/appysv2/n/c;->h(Ljava/lang/String;Ljava/util/Map;Ljava/util/Map;)Lcom/github/catvod/spider/appysv2/n/e;

    move-result-object v1

    :try_start_a0
    new-instance v9, Lorg/json/JSONObject;

    invoke-virtual {v1}, Lcom/github/catvod/spider/appysv2/n/e;->a()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v9, v1}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    const/4 v1, 0x2

    new-array v11, v1, [B

    const/16 v12, 0x5b

    aput-byte v12, v11, v7

    const/16 v12, 0x1e

    aput-byte v12, v11, v3

    new-array v13, v4, [B

    const/16 v14, 0x34

    aput-byte v14, v13, v7

    const/16 v14, 0x75

    aput-byte v14, v13, v3

    const/16 v14, 0x3a

    aput-byte v14, v13, v1

    const/16 v14, 0x36

    aput-byte v14, v13, v5

    const/4 v14, 0x4

    const/16 v15, 0x16

    aput-byte v15, v13, v14

    const/16 v16, 0x5d

    aput-byte v16, v13, v6

    const/4 v12, 0x6

    const/16 v17, 0x27

    aput-byte v17, v13, v12

    const/16 v18, 0x47

    const/4 v15, 0x7

    aput-byte v18, v13, v15

    invoke-static {v11, v13}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v11

    new-array v13, v15, [B

    const/16 v18, 0xf

    aput-byte v18, v13, v7

    const/16 v20, 0x67

    aput-byte v20, v13, v3

    const/16 v20, -0x52

    aput-byte v20, v13, v1

    aput-byte v15, v13, v5

    const/16 v20, 0x35

    aput-byte v20, v13, v14

    const/16 v20, 0x3f

    aput-byte v20, v13, v6

    const/16 v20, 0x12

    aput-byte v20, v13, v12

    new-array v8, v4, [B

    const/16 v22, 0x62

    aput-byte v22, v8, v7

    aput-byte v1, v8, v3

    const/16 v22, -0x23

    aput-byte v22, v8, v1

    const/16 v23, 0x74

    aput-byte v23, v8, v5

    const/16 v23, 0x54

    aput-byte v23, v8, v14

    const/16 v23, 0x58

    aput-byte v23, v8, v6

    const/16 v24, 0x77

    aput-byte v24, v8, v12

    aput-byte v22, v8, v15

    invoke-static {v13, v8}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v9, v8}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v11, v8}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v8

    if-eqz v8, :cond_55c

    new-array v8, v14, [B

    const/16 v11, 0x75

    aput-byte v11, v8, v7

    const/16 v11, -0x5a

    aput-byte v11, v8, v3

    const/16 v11, 0x4d

    aput-byte v11, v8, v1

    aput-byte v4, v8, v5

    new-array v11, v4, [B

    const/16 v13, 0x11

    aput-byte v13, v11, v7

    const/16 v25, -0x39

    aput-byte v25, v11, v3

    const/16 v25, 0x39

    aput-byte v25, v11, v1

    const/16 v25, 0x69

    aput-byte v25, v11, v5

    aput-byte v17, v11, v14

    const/16 v25, 0x2a

    aput-byte v25, v11, v6

    const/16 v25, -0x11

    aput-byte v25, v11, v12

    const/16 v25, 0x52

    aput-byte v25, v11, v15

    invoke-static {v8, v11}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v9, v8}, Lorg/json/JSONObject;->optJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v8

    new-array v9, v15, [B

    const/16 v11, 0x19

    aput-byte v11, v9, v7

    const/16 v25, -0xc

    aput-byte v25, v9, v3

    const/16 v25, 0x76

    aput-byte v25, v9, v1

    aput-byte v10, v9, v5

    const/16 v26, -0x28

    aput-byte v26, v9, v14

    aput-byte v10, v9, v6

    const/16 v10, 0x56

    aput-byte v10, v9, v12

    new-array v10, v4, [B

    const/16 v26, 0x74

    aput-byte v26, v10, v7

    const/16 v26, -0x6f

    aput-byte v26, v10, v3

    const/16 v26, 0x1b

    aput-byte v26, v10, v1

    const/16 v27, 0x2e

    aput-byte v27, v10, v5

    const/16 v27, -0x43

    aput-byte v27, v10, v14

    const/16 v27, 0x3e

    aput-byte v27, v10, v6

    const/16 v27, 0x25

    aput-byte v27, v10, v12

    const/16 v27, 0x15

    aput-byte v27, v10, v15

    invoke-static {v9, v10}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v8, v9}, Lorg/json/JSONObject;->optJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v8

    const/16 v9, 0xe

    new-array v10, v9, [B

    const/16 v28, 0x70

    aput-byte v28, v10, v7

    const/16 v28, -0x76

    aput-byte v28, v10, v3

    const/16 v29, -0x2a

    aput-byte v29, v10, v1

    aput-byte v16, v10, v5

    const/16 v29, -0x1b

    aput-byte v29, v10, v14

    const/16 v30, 0x6d

    aput-byte v30, v10, v6

    const/16 v30, 0x57

    aput-byte v30, v10, v12

    const/16 v30, -0x21

    aput-byte v30, v10, v15

    aput-byte v24, v10, v4

    const/16 v30, -0x7a

    aput-byte v30, v10, v2

    const/16 v30, -0x39

    const/16 v21, 0xa

    aput-byte v30, v10, v21

    const/16 v30, 0x40

    const/16 v31, 0xb

    aput-byte v30, v10, v31

    const/16 v30, -0x17

    const/16 v32, 0xc

    aput-byte v30, v10, v32

    const/16 v30, 0x7a

    const/16 v33, 0xd

    aput-byte v30, v10, v33

    new-array v11, v4, [B

    aput-byte v5, v11, v7

    const/16 v34, -0x11

    aput-byte v34, v11, v3

    const/16 v34, -0x5c

    aput-byte v34, v11, v1

    const/16 v34, 0x2b

    aput-byte v34, v11, v5

    const/16 v34, -0x74

    aput-byte v34, v11, v14

    aput-byte v9, v11, v6

    const/16 v34, 0x32

    aput-byte v34, v11, v12

    const/16 v34, -0x80

    aput-byte v34, v11, v15

    invoke-static {v10, v11}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v8, v10}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    new-instance v10, Ljava/util/HashMap;

    invoke-direct {v10}, Ljava/util/HashMap;-><init>()V

    new-array v11, v12, [B

    const/16 v34, -0x26

    aput-byte v34, v11, v7

    const/16 v34, -0x13

    aput-byte v34, v11, v3

    const/16 v34, 0x1d

    aput-byte v34, v11, v1

    aput-byte v20, v11, v5

    const/16 v35, -0x5d

    aput-byte v35, v11, v14

    const/16 v35, -0x9

    aput-byte v35, v11, v6

    new-array v13, v4, [B

    const/16 v36, -0x65

    aput-byte v36, v13, v7

    const/16 v37, -0x72

    aput-byte v37, v13, v3

    const/16 v37, 0x7e

    aput-byte v37, v13, v1

    aput-byte v24, v13, v5

    const/16 v37, -0x2d

    aput-byte v37, v13, v14

    const/16 v37, -0x7d

    aput-byte v37, v13, v6

    const/16 v37, -0x46

    aput-byte v37, v13, v12

    const/16 v37, 0x2d

    aput-byte v37, v13, v15

    invoke-static {v11, v13}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v11

    const/16 v13, 0x21

    new-array v13, v13, [B

    const/16 v37, -0x6a

    aput-byte v37, v13, v7

    const/16 v37, 0x63

    aput-byte v37, v13, v3

    const/16 v37, 0x5c

    aput-byte v37, v13, v1

    const/16 v37, -0x77

    aput-byte v37, v13, v5

    const/16 v37, -0x47

    aput-byte v37, v13, v14

    const/16 v37, -0x63

    aput-byte v37, v13, v6

    const/16 v38, -0x15

    aput-byte v38, v13, v12

    const/16 v39, 0x7f

    aput-byte v39, v13, v15

    const/16 v39, -0x62

    aput-byte v39, v13, v4

    const/16 v39, 0x7c

    aput-byte v39, v13, v2

    const/16 v39, 0x42

    const/16 v21, 0xa

    aput-byte v39, v13, v21

    const/16 v39, -0x36

    aput-byte v39, v13, v31

    const/16 v39, -0x46

    aput-byte v39, v13, v32

    const/16 v39, -0x73

    aput-byte v39, v13, v33

    aput-byte v29, v13, v9

    const/16 v39, 0x65

    aput-byte v39, v13, v18

    const/16 v40, 0x10

    const/16 v41, -0x25

    aput-byte v41, v13, v40

    const/16 v40, 0x33

    const/16 v35, 0x11

    aput-byte v40, v13, v35

    aput-byte v23, v13, v20

    const/16 v40, -0x80

    const/16 v41, 0x13

    aput-byte v40, v13, v41

    const/16 v40, 0x14

    const/16 v42, -0x58

    aput-byte v42, v13, v40

    aput-byte v28, v13, v27

    const/16 v40, -0x5b

    const/16 v19, 0x16

    aput-byte v40, v13, v19

    const/16 v40, 0x17

    const/16 v42, 0x7b

    aput-byte v42, v13, v40

    const/16 v40, 0x18

    aput-byte v36, v13, v40

    const/16 v40, 0x72

    const/16 v30, 0x19

    aput-byte v40, v13, v30

    const/16 v40, 0x1a

    const/16 v42, 0x45

    aput-byte v42, v13, v40

    const/16 v40, -0x75

    aput-byte v40, v13, v26

    const/16 v40, 0x1c

    const/16 v42, -0x4

    aput-byte v42, v13, v40

    const/16 v40, -0x22

    aput-byte v40, v13, v34

    const/16 v40, -0x60

    const/16 v42, 0x1e

    aput-byte v40, v13, v42

    const/16 v40, 0x1f

    const/16 v42, 0x24

    aput-byte v42, v13, v40

    const/16 v40, 0x20

    aput-byte v22, v13, v40

    new-array v9, v4, [B

    const/16 v43, -0x9

    aput-byte v43, v9, v7

    aput-byte v41, v9, v3

    const/16 v43, 0x2c

    aput-byte v43, v9, v1

    aput-byte v29, v9, v5

    const/16 v29, -0x30

    aput-byte v29, v9, v14

    const/16 v29, -0x2

    aput-byte v29, v9, v6

    aput-byte v28, v9, v12

    aput-byte v31, v9, v15

    invoke-static {v13, v9}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v10, v11, v9}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    new-array v9, v15, [B

    const/16 v11, 0x48

    aput-byte v11, v9, v7

    const/16 v11, -0x6a

    aput-byte v11, v9, v3

    const/16 v11, -0x3e

    aput-byte v11, v9, v1

    const/16 v11, -0xf

    aput-byte v11, v9, v5

    aput-byte v17, v9, v14

    const/4 v11, -0x6

    aput-byte v11, v9, v6

    const/16 v11, -0x7f

    aput-byte v11, v9, v12

    new-array v11, v4, [B

    const/16 v13, 0x1a

    aput-byte v13, v11, v7

    const/16 v13, -0xd

    aput-byte v13, v11, v3

    const/16 v13, -0x5c

    aput-byte v13, v11, v1

    const/16 v13, -0x6c

    aput-byte v13, v11, v5

    const/16 v13, 0x55

    aput-byte v13, v11, v14

    const/16 v13, -0x61

    aput-byte v13, v11, v6

    const/16 v13, -0xd

    aput-byte v13, v11, v12

    const/16 v13, -0x4d

    aput-byte v13, v11, v15

    invoke-static {v9, v11}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v9

    const/16 v11, 0x14

    new-array v11, v11, [B

    aput-byte v23, v11, v7

    const/16 v13, -0x51

    aput-byte v13, v11, v3

    const/16 v13, -0xa

    aput-byte v13, v11, v1

    const/16 v13, -0x53

    aput-byte v13, v11, v5

    aput-byte v22, v11, v14

    const/16 v13, -0x7b

    aput-byte v13, v11, v6

    const/16 v13, 0x6e

    aput-byte v13, v11, v12

    const/16 v13, 0x28

    aput-byte v13, v11, v15

    const/16 v13, 0x54

    aput-byte v13, v11, v4

    const/16 v13, -0x57

    aput-byte v13, v11, v2

    const/16 v13, 0xa

    aput-byte v38, v11, v13

    const/16 v13, -0x55

    aput-byte v13, v11, v31

    const/16 v13, -0x35

    aput-byte v13, v11, v32

    const/16 v13, -0x6f

    aput-byte v13, v11, v33

    const/16 v13, 0x34

    const/16 v17, 0xe

    aput-byte v13, v11, v17

    const/16 v13, 0x64

    aput-byte v13, v11, v18

    const/16 v13, 0x10

    const/16 v17, 0x1e

    aput-byte v17, v11, v13

    const/16 v13, -0x48

    const/16 v17, 0x11

    aput-byte v13, v11, v17

    const/16 v13, -0x14

    aput-byte v13, v11, v20

    const/16 v13, -0xe

    aput-byte v13, v11, v41

    new-array v13, v4, [B

    const/16 v17, 0x30

    aput-byte v17, v13, v7

    const/16 v17, -0x25

    aput-byte v17, v13, v3

    const/16 v17, -0x7e

    aput-byte v17, v13, v1

    aput-byte v22, v13, v5

    const/16 v17, -0x52

    aput-byte v17, v13, v14

    const/16 v17, -0x41

    aput-byte v17, v13, v6

    const/16 v17, 0x41

    aput-byte v17, v13, v12

    aput-byte v15, v13, v15

    invoke-static {v11, v13}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v11

    invoke-virtual {v10, v9, v11}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    new-instance v9, Ljava/lang/StringBuilder;

    invoke-direct {v9}, Ljava/lang/StringBuilder;-><init>()V

    const/16 v11, 0x24

    new-array v11, v11, [B

    const/16 v13, 0x6a

    aput-byte v13, v11, v7

    const/16 v13, -0x3a

    aput-byte v13, v11, v3

    const/16 v13, -0x3b

    aput-byte v13, v11, v1

    const/16 v13, -0x12

    aput-byte v13, v11, v5

    const/16 v13, -0x5b

    aput-byte v13, v11, v14

    const/16 v13, -0x6b

    aput-byte v13, v11, v6

    const/16 v13, 0x2c

    aput-byte v13, v11, v12

    const/16 v13, -0x1f

    aput-byte v13, v11, v15

    const/16 v13, 0x66

    aput-byte v13, v11, v4

    const/16 v13, -0x40

    aput-byte v13, v11, v2

    const/16 v13, -0x28

    const/16 v17, 0xa

    aput-byte v13, v11, v17

    const/16 v13, -0x18

    aput-byte v13, v11, v31

    const/16 v13, -0x4d

    aput-byte v13, v11, v32

    const/16 v13, -0x7f

    aput-byte v13, v11, v33

    const/16 v13, 0xe

    aput-byte v25, v11, v13

    const/16 v13, -0x53

    aput-byte v13, v11, v18

    const/16 v13, 0x10

    const/16 v17, 0x2c

    aput-byte v17, v11, v13

    const/16 v13, -0x2f

    const/16 v17, 0x11

    aput-byte v13, v11, v17

    const/16 v13, -0x21

    aput-byte v13, v11, v20

    const/16 v13, -0x4f

    aput-byte v13, v11, v41

    const/16 v13, 0x14

    const/16 v17, -0x49

    aput-byte v17, v11, v13

    const/16 v13, -0x34

    aput-byte v13, v11, v27

    const/16 v13, 0x60

    const/16 v17, 0x16

    aput-byte v13, v11, v17

    const/16 v13, 0x17

    const/16 v17, -0x5f

    aput-byte v17, v11, v13

    const/16 v13, 0x18

    aput-byte v24, v11, v13

    const/16 v13, -0x24

    const/16 v17, 0x19

    aput-byte v13, v11, v17

    const/16 v13, 0x1a

    const/16 v17, -0x3b

    aput-byte v17, v11, v13

    const/16 v13, -0x4f

    aput-byte v13, v11, v26

    const/16 v13, 0x1c

    const/16 v17, -0x41

    aput-byte v17, v11, v13

    const/16 v13, -0x3f

    aput-byte v13, v11, v34

    const/16 v13, 0x1e

    aput-byte v39, v11, v13

    const/16 v13, 0x1f

    const/16 v17, -0x5f

    aput-byte v17, v11, v13

    const/16 v13, 0x3d

    aput-byte v13, v11, v40

    const/16 v13, 0x21

    const/16 v17, -0x3f

    aput-byte v17, v11, v13

    const/16 v13, 0x22

    const/16 v17, -0x3b

    aput-byte v17, v11, v13

    const/16 v13, 0x23

    const/16 v17, -0x5d

    aput-byte v17, v11, v13

    new-array v13, v4, [B

    aput-byte v1, v13, v7

    const/16 v17, -0x4e

    aput-byte v17, v13, v3

    const/16 v17, -0x4f

    aput-byte v17, v13, v1

    const/16 v17, -0x62

    aput-byte v17, v13, v5

    const/16 v17, -0x2a

    aput-byte v17, v13, v14

    const/16 v17, -0x51

    aput-byte v17, v13, v6

    aput-byte v5, v13, v12

    const/16 v17, -0x32

    aput-byte v17, v13, v15

    invoke-static {v11, v13}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v11

    invoke-virtual {v9, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v9, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v9}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v8

    invoke-static {v8, v10}, Lcom/github/catvod/spider/appysv2/n/c;->e(Ljava/lang/String;Ljava/util/Map;)Lokhttp3/Response;

    move-result-object v8

    const/16 v9, 0xa

    new-array v10, v9, [B

    aput-byte v16, v10, v7

    aput-byte v23, v10, v3

    aput-byte v22, v10, v1

    const/16 v9, -0x59

    aput-byte v9, v10, v5

    aput-byte v25, v10, v14

    aput-byte v39, v10, v6

    const/16 v9, -0xe

    aput-byte v9, v10, v12

    const/16 v9, 0x5a

    aput-byte v9, v10, v15

    const/16 v9, 0x47

    aput-byte v9, v10, v4

    aput-byte v23, v10, v2

    new-array v2, v4, [B

    const/16 v9, 0x2e

    aput-byte v9, v2, v7

    const/16 v9, 0x3d

    aput-byte v9, v2, v3

    const/16 v9, -0x57

    aput-byte v9, v2, v1

    aput-byte v28, v2, v5

    aput-byte v27, v2, v14

    const/16 v9, 0xa

    aput-byte v9, v2, v6

    aput-byte v37, v2, v12

    const/16 v9, 0x31

    aput-byte v9, v2, v15

    invoke-static {v10, v2}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v8, v2}, Lokhttp3/Response;->headers(Ljava/lang/String;)Ljava/util/List;

    move-result-object v2

    const-string v8, ""

    invoke-interface {v2}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :goto_4ec
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v9

    if-eqz v9, :cond_559

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v9

    check-cast v9, Ljava/lang/String;

    new-instance v10, Ljava/lang/StringBuilder;

    invoke-direct {v10}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v10, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    new-array v8, v3, [B

    aput-byte v37, v8, v7

    new-array v11, v4, [B

    const/16 v13, -0x5a

    aput-byte v13, v11, v7

    const/16 v13, -0x44

    aput-byte v13, v11, v3

    aput-byte v40, v11, v1

    const/16 v13, 0x38

    aput-byte v13, v11, v5

    const/16 v13, 0x37

    aput-byte v13, v11, v14

    const/16 v13, -0x57

    aput-byte v13, v11, v6

    aput-byte v40, v11, v12

    const/4 v13, -0x3

    aput-byte v13, v11, v15

    invoke-static {v8, v11}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v9, v8}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v8

    aget-object v8, v8, v7

    invoke-virtual {v10, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    new-array v8, v3, [B

    const/16 v9, -0x26

    aput-byte v9, v8, v7

    new-array v9, v4, [B

    const/16 v11, -0x1f

    aput-byte v11, v9, v7

    aput-byte v26, v9, v3

    const/16 v11, 0x6f

    aput-byte v11, v9, v1

    const/4 v11, -0x7

    aput-byte v11, v9, v5

    aput-byte v36, v9, v14

    aput-byte v12, v9, v6

    aput-byte v38, v9, v12

    const/16 v11, 0x36

    aput-byte v11, v9, v15

    invoke-static {v8, v9}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v10, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v10}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v8

    goto :goto_4ec

    :cond_559
    invoke-direct {v0, v8}, Lcom/github/catvod/spider/appysv2/b/U;->P(Ljava/lang/String;)V
    :try_end_55c
    .catch Ljava/lang/Exception; {:try_start_a0 .. :try_end_55c} :catch_55c

    :catch_55c
    :cond_55c
    return-void

    nop

    :array_55e
    .array-data 1
        -0x48t
        -0x20t
        -0x15t
        0x30t
        -0x4at
        -0x7bt
        0x32t
        -0x47t
        -0x41t
    .end array-data

    nop

    :array_568
    .array-data 1
        -0x25t
        -0x74t
        -0x7et
        0x55t
        -0x28t
        -0xft
        0x6dt
        -0x30t
    .end array-data

    :array_570
    .array-data 1
        -0xet
        -0x8t
        0x13t
    .end array-data

    :array_576
    .array-data 1
        -0x3ft
        -0x40t
        0x22t
        -0x4et
        0x28t
        0x69t
        0x8t
        -0x47t
    .end array-data

    :array_57e
    .array-data 1
        0x7ct
        -0x74t
        -0x39t
        -0xdt
        -0x25t
        -0x60t
        -0x3bt
        0x4ct
    .end array-data

    :array_586
    .array-data 1
        0x34t
        -0x20t
        -0x9t
    .end array-data

    :array_58c
    .array-data 1
        0x5t
        -0x32t
        -0x3bt
        0x6ft
        -0x62t
        -0x2ft
        0x65t
        -0x2bt
    .end array-data

    :array_594
    .array-data 1
        -0x1dt
        0x4ft
        0x6dt
        0x24t
        -0x42t
        -0x17t
        0x1bt
        -0x1et
        -0x8t
        0x4et
    .end array-data

    nop

    :array_59e
    .array-data 1
        -0x6ft
        0x2at
        0x1ct
        0x51t
        -0x25t
        -0x66t
        0x6ft
        -0x43t
    .end array-data

    :array_5a6
    .array-data 1
        -0x79t
        -0x13t
        -0x47t
        0x62t
        0x15t
    .end array-data

    nop

    :array_5ae
    .array-data 1
        -0xdt
        -0x7et
        -0x2et
        0x7t
        0x7bt
        -0x7dt
        -0x49t
        0x5et
    .end array-data

    :array_5b6
    .array-data 1
        -0x2bt
        -0xdt
        0x35t
        -0xet
        -0x12t
        0x52t
        -0x20t
        -0x70t
        -0x24t
        -0x9t
        0x28t
        -0x54t
        -0xet
        0x18t
        -0x56t
        -0x2ft
        -0x6dt
        -0xet
        0x22t
        -0x54t
        -0x2t
        0x6t
        -0x20t
        -0x24t
        -0x24t
        -0xct
        0x6et
        -0x1dt
        -0x9t
        0x9t
        -0x49t
        -0x70t
        -0x26t
        -0x1et
        0x35t
        -0x2ft
        -0x8t
        0x1at
        -0x47t
        -0x2at
        -0x22t
        -0x1et
        0x15t
        -0x15t
        -0x2t
        0x3t
        -0x56t
        -0x35t
        -0x1t
        -0x2t
        0x10t
        -0x10t
        -0x2t
        0x7t
        -0x55t
        -0x26t
        -0x17t
        -0x18t
        0x2at
        -0x19t
        -0xdt
        0x57t
        -0x70t
        -0x20t
        -0x27t
        -0xdt
        0x7ct
        -0x45t
        -0x56t
        0x59t
        -0x3t
        -0x74t
        -0x65t
        -0x28t
        0x35t
        -0x41t
    .end array-data

    :array_5e0
    .array-data 1
        -0x43t
        -0x79t
        0x41t
        -0x7et
        -0x63t
        0x68t
        -0x31t
        -0x41t
    .end array-data
.end method

.method public static l(Lcom/github/catvod/spider/appysv2/b/U;Lorg/json/JSONObject;)V
    .registers 20

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    invoke-virtual/range {p0 .. p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v2, 0xf0

    :try_start_9
    invoke-static {v2}, Lcom/github/catvod/spider/appysv2/a/a;->b(I)I

    move-result v2

    new-instance v3, Landroid/widget/FrameLayout$LayoutParams;

    invoke-direct {v3, v2, v2}, Landroid/widget/FrameLayout$LayoutParams;-><init>(II)V

    new-instance v4, Landroid/widget/ImageView;

    invoke-static {}, Lcom/github/catvod/spider/Init;->context()Landroid/app/Application;

    move-result-object v5

    invoke-direct {v4, v5}, Landroid/widget/ImageView;-><init>(Landroid/content/Context;)V

    sget-object v5, Landroid/widget/ImageView$ScaleType;->CENTER_CROP:Landroid/widget/ImageView$ScaleType;

    invoke-virtual {v4, v5}, Landroid/widget/ImageView;->setScaleType(Landroid/widget/ImageView$ScaleType;)V

    const/4 v5, 0x3

    new-array v6, v5, [B

    const/16 v7, 0x34

    const/4 v8, 0x0

    aput-byte v7, v6, v8

    const/16 v9, -0x51

    const/4 v10, 0x1

    aput-byte v9, v6, v10

    const/16 v9, -0x53

    const/4 v11, 0x2

    aput-byte v9, v6, v11

    const/16 v9, 0x8

    new-array v12, v9, [B

    const/16 v13, 0x41

    aput-byte v13, v12, v8

    const/16 v13, -0x23

    aput-byte v13, v12, v10

    const/16 v13, -0x3f

    aput-byte v13, v12, v11

    const/16 v13, 0x3d

    aput-byte v13, v12, v5

    const/16 v13, 0x28

    const/4 v14, 0x4

    aput-byte v13, v12, v14

    const/16 v13, 0x57

    const/4 v15, 0x5

    aput-byte v13, v12, v15

    const/16 v13, -0x27

    const/16 v16, 0x6

    aput-byte v13, v12, v16

    const/16 v13, 0xb

    const/16 v17, 0x7

    aput-byte v13, v12, v17

    invoke-static {v6, v12}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v1, v6}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    invoke-static {v6, v2}, Lcom/github/catvod/spider/appysv2/B/l;->e(Ljava/lang/String;I)Landroid/graphics/Bitmap;

    move-result-object v2

    invoke-virtual {v4, v2}, Landroid/widget/ImageView;->setImageBitmap(Landroid/graphics/Bitmap;)V

    new-instance v2, Landroid/widget/FrameLayout;

    invoke-static {}, Lcom/github/catvod/spider/Init;->context()Landroid/app/Application;

    move-result-object v6

    invoke-direct {v2, v6}, Landroid/widget/FrameLayout;-><init>(Landroid/content/Context;)V

    const/16 v6, 0x11

    iput v6, v3, Landroid/widget/FrameLayout$LayoutParams;->gravity:I

    invoke-virtual {v2, v4, v3}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    new-instance v3, Landroid/app/AlertDialog$Builder;

    invoke-static {}, Lcom/github/catvod/spider/Init;->getActivity()Landroid/app/Activity;

    move-result-object v4

    invoke-direct {v3, v4}, Landroid/app/AlertDialog$Builder;-><init>(Landroid/content/Context;)V

    invoke-virtual {v3, v2}, Landroid/app/AlertDialog$Builder;->setView(Landroid/view/View;)Landroid/app/AlertDialog$Builder;

    move-result-object v2

    new-instance v3, Lcom/github/catvod/spider/appysv2/b/G;

    invoke-direct {v3, v0, v10}, Lcom/github/catvod/spider/appysv2/b/G;-><init>(Ljava/lang/Object;I)V

    invoke-virtual {v2, v3}, Landroid/app/AlertDialog$Builder;->setOnCancelListener(Landroid/content/DialogInterface$OnCancelListener;)Landroid/app/AlertDialog$Builder;

    move-result-object v2

    new-instance v3, Lcom/github/catvod/spider/appysv2/b/J;

    invoke-direct {v3, v0, v10}, Lcom/github/catvod/spider/appysv2/b/J;-><init>(Ljava/lang/Object;I)V

    invoke-virtual {v2, v3}, Landroid/app/AlertDialog$Builder;->setOnDismissListener(Landroid/content/DialogInterface$OnDismissListener;)Landroid/app/AlertDialog$Builder;

    move-result-object v2

    invoke-virtual {v2}, Landroid/app/AlertDialog$Builder;->show()Landroid/app/AlertDialog;

    move-result-object v2

    iput-object v2, v0, Lcom/github/catvod/spider/appysv2/b/U;->f:Landroid/app/AlertDialog;

    invoke-virtual {v2}, Landroid/app/Dialog;->getWindow()Landroid/view/Window;

    move-result-object v2

    new-instance v3, Landroid/graphics/drawable/ColorDrawable;

    invoke-direct {v3, v8}, Landroid/graphics/drawable/ColorDrawable;-><init>(I)V

    invoke-virtual {v2, v3}, Landroid/view/Window;->setBackgroundDrawable(Landroid/graphics/drawable/Drawable;)V

    new-instance v2, Lcom/github/catvod/spider/appysv2/b/Q;

    invoke-direct {v2, v0, v1, v10}, Lcom/github/catvod/spider/appysv2/b/Q;-><init>(Lcom/github/catvod/spider/appysv2/b/U;Lorg/json/JSONObject;I)V

    invoke-static {v2}, Lcom/github/catvod/spider/Init;->execute(Ljava/lang/Runnable;)V

    const/16 v0, 0x1f

    new-array v0, v0, [B

    const/16 v1, 0x50

    aput-byte v1, v0, v8

    const/16 v1, -0x54

    aput-byte v1, v0, v10

    aput-byte v6, v0, v11

    const/16 v1, 0x47

    aput-byte v1, v0, v5

    const/16 v1, 0x59

    aput-byte v1, v0, v14

    const/16 v1, 0x19

    aput-byte v1, v0, v15

    const/16 v2, 0x6e

    aput-byte v2, v0, v16

    const/16 v2, 0x1c

    aput-byte v2, v0, v17

    const/16 v3, 0x10

    aput-byte v3, v0, v9

    const/16 v4, 0x9

    const/16 v12, 0x56

    aput-byte v12, v0, v4

    const/16 v4, 0xa

    const/16 v12, -0x1b

    aput-byte v12, v0, v4

    const/16 v4, -0x7d

    aput-byte v4, v0, v13

    const/16 v4, 0xc

    const/16 v12, -0x5b

    aput-byte v12, v0, v4

    const/16 v4, -0x2a

    const/16 v12, 0xd

    aput-byte v4, v0, v12

    const/16 v4, 0xe

    const/4 v13, -0x7

    aput-byte v13, v0, v4

    const/16 v4, 0xf

    const/16 v13, -0x58

    aput-byte v13, v0, v4

    const/16 v4, 0x5e

    aput-byte v4, v0, v3

    const/16 v3, -0x76

    aput-byte v3, v0, v6

    const/16 v3, 0x12

    aput-byte v12, v0, v3

    const/16 v3, 0x13

    const/16 v4, 0x45

    aput-byte v4, v0, v3

    const/16 v3, 0x14

    const/16 v4, 0x6b

    aput-byte v4, v0, v3

    const/16 v3, 0x15

    const/16 v4, 0x29

    aput-byte v4, v0, v3

    const/16 v3, 0x16

    const/16 v4, 0x6d

    aput-byte v4, v0, v3

    const/16 v3, 0x32

    const/16 v4, 0x17

    aput-byte v3, v0, v4

    const/16 v3, 0x18

    aput-byte v7, v0, v3

    const/16 v3, -0x1c

    aput-byte v3, v0, v1

    const/16 v1, 0x1a

    const/16 v6, 0x1d

    aput-byte v6, v0, v1

    const/16 v1, 0x1b

    aput-byte v4, v0, v1

    aput-byte v5, v0, v2

    aput-byte v16, v0, v6

    const/16 v1, 0x1e

    aput-byte v9, v0, v1

    new-array v1, v9, [B

    const/16 v2, -0x48

    aput-byte v2, v1, v8

    aput-byte v5, v1, v10

    const/16 v2, -0x5a

    aput-byte v2, v1, v11

    const/16 v4, -0x5d

    aput-byte v4, v1, v5

    aput-byte v3, v1, v14

    aput-byte v2, v1, v15

    const/16 v2, -0x77

    aput-byte v2, v1, v16

    const/16 v2, -0x78

    aput-byte v2, v1, v17

    invoke-static {v0, v1}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lcom/github/catvod/spider/appysv2/p/j;->b(Ljava/lang/String;)V
    :try_end_168
    .catch Ljava/lang/Exception; {:try_start_9 .. :try_end_168} :catch_168

    :catch_168
    return-void
.end method

.method public static m(Lcom/github/catvod/spider/appysv2/b/U;Lorg/json/JSONObject;)V
    .registers 10

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v0, 0x1

    invoke-static {v0}, Ljava/util/concurrent/Executors;->newScheduledThreadPool(I)Ljava/util/concurrent/ScheduledExecutorService;

    move-result-object v1

    iput-object v1, p0, Lcom/github/catvod/spider/appysv2/b/U;->c:Ljava/util/concurrent/ScheduledExecutorService;

    new-instance v2, Lcom/github/catvod/spider/appysv2/b/j;

    const/4 v0, 0x2

    invoke-direct {v2, p0, p1, v0}, Lcom/github/catvod/spider/appysv2/b/j;-><init>(Ljava/lang/Object;Ljava/lang/Object;I)V

    sget-object v7, Ljava/util/concurrent/TimeUnit;->SECONDS:Ljava/util/concurrent/TimeUnit;

    const-wide/16 v3, 0x1

    const-wide/16 v5, 0x1

    invoke-interface/range {v1 .. v7}, Ljava/util/concurrent/ScheduledExecutorService;->scheduleWithFixedDelay(Ljava/lang/Runnable;JJLjava/util/concurrent/TimeUnit;)Ljava/util/concurrent/ScheduledFuture;

    return-void
.end method

.method private n(Ljava/util/List;)Z
    .registers 33
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;Z)Z"
        }
    .end annotation

    const/4 v1, 0x1

    const/16 v2, 0x8

    const/4 v3, 0x7

    :try_start_4
    const-string v0, ""

    const/4 v4, 0x0

    const/4 v5, 0x0

    :goto_8
    const/4 v6, 0x3

    if-ge v5, v6, :cond_36f

    const/16 v0, 0x40

    new-array v0, v0, [B

    const/16 v7, -0x6a

    aput-byte v7, v0, v4

    const/16 v8, -0x79

    aput-byte v8, v0, v1

    const/4 v8, 0x2

    const/16 v9, 0x25

    aput-byte v9, v0, v8

    const/16 v10, -0x12

    aput-byte v10, v0, v6

    const/4 v11, 0x4

    aput-byte v7, v0, v11

    const/4 v7, 0x5

    const/16 v12, 0x56

    aput-byte v12, v0, v7

    const/4 v12, 0x6

    const/16 v13, 0x23

    aput-byte v13, v0, v12

    const/16 v14, -0x2d

    aput-byte v14, v0, v3

    const/16 v15, -0x72

    aput-byte v15, v0, v2

    const/16 v16, -0x70

    const/16 v17, 0x9

    aput-byte v16, v0, v17

    const/16 v16, 0x7c

    const/16 v18, 0xa

    aput-byte v16, v0, v18

    const/16 v19, -0x1

    const/16 v20, 0xb

    aput-byte v19, v0, v20

    const/16 v20, -0x6b

    const/16 v14, 0xc

    aput-byte v20, v0, v14

    const/16 v20, 0xd

    aput-byte v7, v0, v20

    const/16 v20, 0xe

    const/16 v22, 0x22

    aput-byte v22, v0, v20

    const/16 v20, 0xf

    const/16 v23, -0x77

    aput-byte v23, v0, v20

    const/16 v20, -0x63

    const/16 v24, 0x10

    aput-byte v20, v0, v24

    const/16 v20, 0x11

    const/16 v25, -0x23

    aput-byte v25, v0, v20

    const/16 v20, 0x12

    const/16 v26, 0x32

    aput-byte v26, v0, v20

    const/16 v20, 0x13

    const/16 v26, -0x10

    aput-byte v26, v0, v20

    const/16 v20, 0x14

    const/16 v26, -0x36

    aput-byte v26, v0, v20

    const/16 v20, 0x15

    const/16 v26, 0x5d

    aput-byte v26, v0, v20

    const/16 v20, 0x16

    aput-byte v13, v0, v20

    const/16 v20, 0x17

    const/16 v26, -0x61

    aput-byte v26, v0, v20

    const/16 v20, 0x18

    const/16 v27, -0x6e

    aput-byte v27, v0, v20

    const/16 v20, 0x19

    const/16 v27, -0x64

    aput-byte v27, v0, v20

    const/16 v20, 0x1a

    const/16 v27, 0x24

    aput-byte v27, v0, v20

    const/16 v20, 0x1b

    const/16 v28, -0x6

    aput-byte v28, v0, v20

    const/16 v20, 0x1c

    const/16 v28, -0x7f

    aput-byte v28, v0, v20

    const/16 v20, 0x1d

    const/16 v28, 0x1e

    aput-byte v28, v0, v20

    const/16 v20, 0x1e

    const/16 v28, 0x65

    aput-byte v28, v0, v20

    const/16 v20, 0x1f

    const/16 v28, -0x76

    aput-byte v28, v0, v20

    const/16 v20, 0x20

    const/16 v29, -0x65

    aput-byte v29, v0, v20

    const/16 v20, 0x21

    const/16 v30, -0x24

    aput-byte v30, v0, v20

    const/16 v20, 0x37

    aput-byte v20, v0, v22

    const/16 v30, -0x9

    aput-byte v30, v0, v13

    aput-byte v23, v0, v27

    aput-byte v17, v0, v9

    const/16 v9, 0x26

    aput-byte v13, v0, v9

    const/16 v9, 0x27

    const/16 v23, -0x68

    aput-byte v23, v0, v9

    const/16 v9, 0x28

    aput-byte v29, v0, v9

    const/16 v9, 0x29

    aput-byte v26, v0, v9

    const/16 v9, 0x2a

    const/16 v23, 0x34

    aput-byte v23, v0, v9

    const/16 v9, 0x2b

    const/16 v23, -0x16

    aput-byte v23, v0, v9

    const/16 v9, 0x2c

    const/16 v23, -0x80

    aput-byte v23, v0, v9

    const/16 v9, 0x2d

    const/16 v23, 0x53

    aput-byte v23, v0, v9

    const/16 v9, 0x2e

    aput-byte v16, v0, v9

    const/16 v9, 0x2f

    aput-byte v15, v0, v9

    const/16 v9, 0x30

    const/16 v15, -0x3d

    aput-byte v15, v0, v9

    const/16 v9, 0x31

    const/16 v15, -0x5a

    aput-byte v15, v0, v9

    const/16 v9, 0x32

    const/16 v15, 0x12

    aput-byte v15, v0, v9

    const/16 v9, 0x33

    const/16 v15, -0x24

    aput-byte v15, v0, v9

    const/16 v9, 0x34

    const/16 v15, -0x69

    aput-byte v15, v0, v9

    const/16 v9, 0x35

    aput-byte v6, v0, v9

    const/16 v9, 0x36

    const/16 v15, 0x7b

    aput-byte v15, v0, v9

    const/16 v9, -0x71

    aput-byte v9, v0, v20

    const/16 v9, 0x38

    aput-byte v29, v0, v9

    const/16 v9, 0x39

    const/16 v15, -0x7f

    aput-byte v15, v0, v9

    const/16 v9, 0x3a

    const/16 v15, 0x77

    aput-byte v15, v0, v9

    const/16 v9, 0x3b

    const/4 v15, -0x8

    aput-byte v15, v0, v9

    const/16 v9, 0x3c

    const/16 v15, -0x69

    aput-byte v15, v0, v9

    const/16 v9, 0x3d

    const/16 v15, 0x51

    aput-byte v15, v0, v9

    const/16 v9, 0x3e

    aput-byte v16, v0, v9

    const/16 v9, 0x3f

    aput-byte v26, v0, v9

    new-array v9, v2, [B

    const/4 v15, -0x2

    aput-byte v15, v9, v4

    const/16 v15, -0xd

    aput-byte v15, v9, v1

    const/16 v15, 0x51

    aput-byte v15, v9, v8

    const/16 v15, -0x62

    aput-byte v15, v9, v6

    const/16 v15, -0x1b

    aput-byte v15, v9, v11

    const/16 v15, 0x6c

    aput-byte v15, v9, v7

    aput-byte v14, v9, v12

    const/4 v15, -0x4

    aput-byte v15, v9, v3

    invoke-static {v0, v9}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v0

    new-instance v9, Ljava/util/HashMap;

    invoke-direct {v9}, Ljava/util/HashMap;-><init>()V

    new-array v15, v2, [B

    const/16 v16, 0x20

    aput-byte v16, v15, v4

    const/16 v16, 0x3b

    aput-byte v16, v15, v1

    const/16 v16, 0x4e

    aput-byte v16, v15, v8

    const/16 v16, 0x5c

    aput-byte v16, v15, v6

    const/16 v16, -0x7e

    aput-byte v16, v15, v11

    aput-byte v18, v15, v7

    aput-byte v2, v15, v12

    const/16 v16, 0x1c

    aput-byte v16, v15, v3

    new-array v13, v2, [B

    const/16 v23, 0x46

    aput-byte v23, v13, v4

    const/16 v23, 0x52

    aput-byte v23, v13, v1

    aput-byte v22, v13, v8

    const/16 v22, 0x39

    aput-byte v22, v13, v6

    aput-byte v10, v13, v11

    const/16 v10, 0x63

    aput-byte v10, v13, v7

    const/16 v10, 0x7b

    aput-byte v10, v13, v12

    const/16 v10, 0x68

    aput-byte v10, v13, v3

    invoke-static {v15, v13}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v10

    move-object/from16 v13, p1

    invoke-virtual {v9, v10, v13}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    new-array v10, v14, [B

    const/16 v14, -0x11

    aput-byte v14, v10, v4

    const/16 v14, -0x3f

    aput-byte v14, v10, v1

    const/16 v14, 0x54

    aput-byte v14, v10, v8

    aput-byte v25, v10, v6

    const/16 v14, -0x34

    aput-byte v14, v10, v11

    const/16 v14, 0x5b

    aput-byte v14, v10, v7

    aput-byte v6, v10, v12

    const/16 v14, 0x60

    aput-byte v14, v10, v3

    const/16 v14, -0x14

    aput-byte v14, v10, v2

    const/16 v14, -0x30

    aput-byte v14, v10, v17

    const/16 v14, 0x53

    aput-byte v14, v10, v18

    const/16 v14, -0x3e

    const/16 v15, 0xb

    aput-byte v14, v10, v15

    new-array v15, v2, [B

    aput-byte v28, v15, v4

    const/16 v22, -0x47

    aput-byte v22, v15, v1

    aput-byte v20, v15, v8

    const/16 v22, -0x4f

    aput-byte v22, v15, v6

    const/16 v22, -0x47

    aput-byte v22, v15, v11

    const/16 v22, 0x3f

    aput-byte v22, v15, v7

    const/16 v23, 0x66

    aput-byte v23, v15, v12

    aput-byte v22, v15, v3

    invoke-static {v10, v15}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v10

    new-instance v15, Ljava/util/ArrayList;

    invoke-direct {v15}, Ljava/util/ArrayList;-><init>()V

    invoke-virtual {v9, v10, v15}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/16 v10, 0xb

    new-array v10, v10, [B

    aput-byte v28, v10, v4

    aput-byte v14, v10, v1

    const/16 v14, -0x57

    aput-byte v14, v10, v8

    const/4 v14, -0x8

    aput-byte v14, v10, v6

    const/16 v14, -0x4e

    aput-byte v14, v10, v11

    const/16 v14, 0x5e

    aput-byte v14, v10, v7

    const/16 v14, 0x26

    aput-byte v14, v10, v12

    const/16 v14, 0x14

    aput-byte v14, v10, v3

    const/16 v14, -0x6e

    aput-byte v14, v10, v2

    const/16 v14, -0x2f

    aput-byte v14, v10, v17

    const/16 v14, -0x48

    aput-byte v14, v10, v18

    new-array v14, v2, [B

    const/16 v15, -0x15

    aput-byte v15, v14, v4

    const/16 v15, -0x5f

    aput-byte v15, v14, v1

    aput-byte v25, v14, v8

    const/16 v15, -0x6f

    aput-byte v15, v14, v6

    aput-byte v25, v14, v11

    const/16 v15, 0x30

    aput-byte v15, v14, v7

    const/16 v15, 0x79

    aput-byte v15, v14, v12

    const/16 v15, 0x60

    aput-byte v15, v14, v3

    invoke-static {v10, v14}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v10

    invoke-static {v8}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v14

    invoke-virtual {v9, v10, v14}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_272
    .catch Ljava/lang/Exception; {:try_start_4 .. :try_end_272} :catch_384

    move-object/from16 v10, p0

    :try_start_274
    invoke-direct {v10, v0, v9}, Lcom/github/catvod/spider/appysv2/b/U;->L(Ljava/lang/String;Ljava/util/Map;)Ljava/lang/String;

    move-result-object v0

    new-instance v9, Ljava/lang/StringBuilder;

    invoke-direct {v9}, Ljava/lang/StringBuilder;-><init>()V

    const/16 v14, 0xd

    new-array v14, v14, [B

    const/16 v15, 0x16

    aput-byte v15, v14, v4

    const/16 v15, 0x4f

    aput-byte v15, v14, v1

    const/16 v15, -0x4c

    aput-byte v15, v14, v8

    const/16 v21, -0x2d

    aput-byte v21, v14, v6

    aput-byte v3, v14, v11

    aput-byte v24, v14, v7

    const/16 v21, 0x56

    aput-byte v21, v14, v12

    const/16 v21, 0x69

    aput-byte v21, v14, v3

    aput-byte v1, v14, v2

    const/16 v21, 0x5f

    aput-byte v21, v14, v17

    aput-byte v15, v14, v18

    const/16 v15, -0x3e

    const/16 v17, 0xb

    aput-byte v15, v14, v17

    const/16 v15, 0x49

    const/16 v17, 0xc

    aput-byte v15, v14, v17

    new-array v15, v2, [B

    const/16 v17, 0x72

    aput-byte v17, v15, v4

    const/16 v17, 0x2a

    aput-byte v17, v15, v1

    const/16 v17, -0x28

    aput-byte v17, v15, v8

    const/16 v17, -0x4a

    aput-byte v17, v15, v6

    const/16 v17, 0x73

    aput-byte v17, v15, v11

    const/16 v17, 0x75

    aput-byte v17, v15, v7

    aput-byte v11, v15, v12

    const/16 v17, 0xc

    aput-byte v17, v15, v3

    invoke-static {v14, v15}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v14

    invoke-virtual {v9, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v9, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v9}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v9

    invoke-static {v9}, Lcom/github/catvod/crawler/SpiderDebug;->log(Ljava/lang/String;)V

    new-instance v9, Lorg/json/JSONObject;

    invoke-direct {v9, v0}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    new-array v0, v11, [B

    const/16 v14, -0x43

    aput-byte v14, v0, v4

    const/16 v14, 0xd

    aput-byte v14, v0, v1

    const/16 v14, 0x50

    aput-byte v14, v0, v8

    const/16 v14, -0x1a

    aput-byte v14, v0, v6

    new-array v14, v2, [B

    const/16 v15, -0x27

    aput-byte v15, v14, v4

    const/16 v15, 0x6c

    aput-byte v15, v14, v1

    aput-byte v27, v14, v8

    const/16 v15, -0x79

    aput-byte v15, v14, v6

    const/16 v15, -0x2a

    aput-byte v15, v14, v11

    const/16 v15, -0x4b

    aput-byte v15, v14, v7

    const/16 v15, 0x13

    aput-byte v15, v14, v12

    const/16 v15, -0x43

    aput-byte v15, v14, v3

    invoke-static {v0, v14}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v9, v0}, Lorg/json/JSONObject;->optJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v0

    new-array v9, v3, [B

    const/16 v14, 0x57

    aput-byte v14, v9, v4

    const/16 v14, -0x4c

    aput-byte v14, v9, v1

    const/16 v14, -0x6d

    aput-byte v14, v9, v8

    aput-byte v20, v9, v6

    const/16 v14, -0x1d

    aput-byte v14, v9, v11

    const/16 v14, -0x6a

    aput-byte v14, v9, v7

    const/16 v14, -0x68

    aput-byte v14, v9, v12

    new-array v14, v2, [B

    const/16 v15, 0x23

    aput-byte v15, v14, v4

    const/16 v15, -0x2b

    aput-byte v15, v14, v1

    const/16 v15, -0x20

    aput-byte v15, v14, v8

    const/16 v8, 0x5c

    aput-byte v8, v14, v6

    const/16 v6, -0x44

    aput-byte v6, v14, v11

    aput-byte v19, v14, v7

    const/4 v6, -0x4

    aput-byte v6, v14, v12

    const/16 v6, 0x56

    aput-byte v6, v14, v3

    invoke-static {v9, v14}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v0, v6}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v6

    if-nez v6, :cond_36b

    goto :goto_373

    :cond_36b
    add-int/lit8 v5, v5, 0x1

    goto/16 :goto_8

    :cond_36f
    move-object/from16 v10, p0

    move-object/from16 v13, p1

    :goto_373
    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    if-eqz v0, :cond_381

    invoke-direct/range {p0 .. p1}, Lcom/github/catvod/spider/appysv2/b/U;->n(Ljava/util/List;)Z

    move-result v0
    :try_end_37d
    .catch Ljava/lang/Exception; {:try_start_274 .. :try_end_37d} :catch_382

    if-eqz v0, :cond_380

    goto :goto_381

    :cond_380
    const/4 v1, 0x0

    :cond_381
    :goto_381
    return v1

    :catch_382
    move-exception v0

    goto :goto_387

    :catch_384
    move-exception v0

    move-object/from16 v10, p0

    :goto_387
    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    new-array v3, v3, [B

    fill-array-data v3, :array_39a

    new-array v2, v2, [B

    fill-array-data v2, :array_3a2

    .line 1
    invoke-static {v3, v2, v4, v0}, Lcom/github/catvod/spider/appysv2/b/y;->b([B[BLjava/lang/StringBuilder;Ljava/lang/Exception;)V

    return v1

    :array_39a
    .array-data 1
        -0x45t
        -0x5bt
        -0xft
        0x33t
        0x3bt
        0x53t
        0x6at
    .end array-data

    :array_3a2
    .array-data 1
        -0x21t
        -0x40t
        -0x63t
        0x56t
        0x4ft
        0x36t
        0x50t
        -0x72t
    .end array-data
.end method

.method private q(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)Ljava/lang/String;
    .registers 43

    move-object/from16 v1, p0

    move-object/from16 v2, p1

    move-object/from16 v3, p2

    const/16 v4, 0x9

    const/16 v5, 0x8

    :try_start_a
    iget-object v6, v1, Lcom/github/catvod/spider/appysv2/b/U;->e:Lcom/github/catvod/spider/appysv2/l/e;

    invoke-virtual {v6}, Lcom/github/catvod/spider/appysv2/l/e;->c()Ljava/util/List;

    move-result-object v6

    const-string v7, ""

    if-eqz v6, :cond_1a

    invoke-interface {v6}, Ljava/util/List;->size()I

    move-result v8

    if-nez v8, :cond_26

    :cond_1a
    invoke-virtual/range {p0 .. p1}, Lcom/github/catvod/spider/appysv2/b/U;->N(Ljava/lang/String;)Ljava/lang/String;

    invoke-direct/range {p0 .. p1}, Lcom/github/catvod/spider/appysv2/b/U;->O(Ljava/lang/String;)V

    iget-object v6, v1, Lcom/github/catvod/spider/appysv2/b/U;->e:Lcom/github/catvod/spider/appysv2/l/e;

    invoke-virtual {v6}, Lcom/github/catvod/spider/appysv2/l/e;->c()Ljava/util/List;

    move-result-object v6

    :cond_26
    if-eqz v6, :cond_4c

    invoke-interface {v6}, Ljava/util/List;->size()I

    move-result v8

    if-lez v8, :cond_4c

    invoke-interface {v6}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v6

    :cond_32
    invoke-interface {v6}, Ljava/util/Iterator;->hasNext()Z

    move-result v8

    if-eqz v8, :cond_4c

    invoke-interface {v6}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v8

    check-cast v8, Lcom/github/catvod/spider/appysv2/l/a;

    invoke-virtual {v8}, Lcom/github/catvod/spider/appysv2/l/a;->b()Ljava/lang/String;

    move-result-object v9

    invoke-static {v9, v3}, Lcom/github/catvod/spider/appysv2/b/u;->c(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v9

    if-eqz v9, :cond_32

    invoke-virtual {v8}, Lcom/github/catvod/spider/appysv2/l/a;->f()Ljava/lang/String;

    move-result-object v7

    :cond_4c
    invoke-virtual {v7}, Ljava/lang/String;->isEmpty()Z

    move-result v6

    if-eqz v6, :cond_55

    const-string v2, ""

    return-object v2

    :cond_55
    invoke-direct/range {p0 .. p0}, Lcom/github/catvod/spider/appysv2/b/U;->v()Ljava/lang/String;

    move-result-object v6

    const/16 v8, 0x5c

    new-array v8, v8, [B

    const/16 v9, -0x80

    const/4 v10, 0x0

    aput-byte v9, v8, v10

    const/16 v9, -0x26

    const/4 v11, 0x1

    aput-byte v9, v8, v11

    const/16 v9, -0x77

    const/4 v12, 0x2

    aput-byte v9, v8, v12

    const/4 v9, -0x3

    const/4 v13, 0x3

    aput-byte v9, v8, v13

    const/16 v9, -0x66

    const/4 v14, 0x4

    aput-byte v9, v8, v14

    const/16 v9, -0x6b

    const/4 v15, 0x5

    aput-byte v9, v8, v15

    const/16 v9, 0x68

    const/4 v15, 0x6

    aput-byte v9, v8, v15

    const/16 v9, -0x2d

    const/4 v15, 0x7

    aput-byte v9, v8, v15

    const/16 v9, -0x68

    aput-byte v9, v8, v5

    const/16 v9, -0x33

    aput-byte v9, v8, v4

    const/16 v4, -0x30

    const/16 v16, 0xa

    aput-byte v4, v8, v16

    const/16 v4, -0x14

    const/16 v17, 0xb

    aput-byte v4, v8, v17

    const/16 v4, -0x67

    const/16 v17, 0xc

    aput-byte v4, v8, v17

    const/16 v4, -0x3a

    const/16 v18, 0xd

    aput-byte v4, v8, v18

    const/16 v4, 0x69

    const/16 v18, 0xe

    aput-byte v4, v8, v18

    const/16 v4, -0x77

    const/16 v18, 0xf

    aput-byte v4, v8, v18

    const/16 v4, -0x75

    const/16 v19, 0x10

    aput-byte v4, v8, v19

    const/16 v19, 0x11

    const/16 v20, -0x80

    aput-byte v20, v8, v19

    const/16 v19, 0x12

    const/16 v20, -0x62

    aput-byte v20, v8, v19

    const/16 v19, 0x13

    const/16 v20, -0x1d

    aput-byte v20, v8, v19

    const/16 v19, -0x3a

    const/16 v20, 0x14

    aput-byte v19, v8, v20

    const/16 v19, 0x15

    const/16 v21, -0x62

    aput-byte v21, v8, v19

    const/16 v19, 0x68

    const/16 v21, 0x16

    aput-byte v19, v8, v21

    const/16 v19, 0x17

    const/16 v22, -0x61

    aput-byte v22, v8, v19

    const/16 v19, 0x18

    const/16 v22, -0x7c

    aput-byte v22, v8, v19

    const/16 v19, 0x19

    const/16 v22, -0x3f

    aput-byte v22, v8, v19

    const/16 v19, -0x78

    const/16 v22, 0x1a

    aput-byte v19, v8, v22

    const/16 v19, 0x1b

    const/16 v23, -0x17

    aput-byte v23, v8, v19

    const/16 v19, -0x73

    const/16 v24, 0x1c

    aput-byte v19, v8, v24

    const/16 v25, 0x1d

    const/16 v26, -0x23

    aput-byte v26, v8, v25

    const/16 v25, 0x1e

    const/16 v26, 0x2e

    aput-byte v26, v8, v25

    const/16 v25, 0x1f

    const/16 v26, -0x76

    aput-byte v26, v8, v25

    const/16 v25, 0x20

    aput-byte v19, v8, v25

    const/16 v26, 0x21

    const/16 v27, -0x7f

    aput-byte v27, v8, v26

    const/16 v26, -0x72

    const/16 v27, 0x22

    aput-byte v26, v8, v27

    const/16 v26, 0x23

    const/16 v28, -0x1b

    aput-byte v28, v8, v26

    const/16 v26, -0x78

    const/16 v28, 0x24

    aput-byte v26, v8, v28

    const/16 v26, 0x25

    const/16 v29, -0x23

    aput-byte v29, v8, v26

    const/16 v26, 0x26

    aput-byte v27, v8, v26

    const/16 v29, 0x27

    const/16 v30, -0x2d

    aput-byte v30, v8, v29

    const/16 v29, -0x65

    const/16 v30, 0x28

    aput-byte v29, v8, v30

    const/16 v29, 0x29

    const/16 v31, -0x3a

    aput-byte v31, v8, v29

    const/16 v29, -0x64

    const/16 v31, 0x2a

    aput-byte v29, v8, v31

    const/16 v29, 0x2b

    const/16 v32, -0x1

    aput-byte v32, v8, v29

    const/16 v29, 0x2c

    const/16 v32, -0x74

    aput-byte v32, v8, v29

    const/16 v29, 0x2d

    const/16 v32, -0x21

    aput-byte v32, v8, v29

    const/16 v29, 0x2e

    aput-byte v26, v8, v29

    const/16 v29, 0x2f

    const/16 v32, -0x65

    aput-byte v32, v8, v29

    const/16 v29, 0x30

    aput-byte v19, v8, v29

    const/16 v32, 0x31

    const/16 v33, -0x7f

    aput-byte v33, v8, v32

    const/16 v32, 0x32

    const/16 v33, -0x72

    aput-byte v33, v8, v32

    const/16 v32, 0x33

    const/16 v33, -0x14

    aput-byte v33, v8, v32

    const/16 v32, 0x34

    const/16 v33, -0x61

    aput-byte v33, v8, v32

    const/16 v32, 0x35

    const/16 v33, -0x36

    aput-byte v33, v8, v32

    const/16 v32, 0x36

    const/16 v33, 0x78

    aput-byte v33, v8, v32

    const/16 v32, 0x37

    const/16 v33, -0x74

    aput-byte v33, v8, v32

    const/16 v32, 0x38

    const/16 v33, -0x66

    aput-byte v33, v8, v32

    const/16 v32, 0x39

    const/16 v33, -0x6d

    aput-byte v33, v8, v32

    const/16 v32, 0x3a

    const/16 v33, -0x58

    aput-byte v33, v8, v32

    const/16 v32, 0x3b

    const/16 v33, -0x32

    aput-byte v33, v8, v32

    const/16 v32, 0x3c

    const/16 v33, -0x55

    aput-byte v33, v8, v32

    const/16 v32, 0x3d

    const/16 v33, -0x23

    aput-byte v33, v8, v32

    const/16 v32, 0x3e

    aput-byte v30, v8, v32

    const/16 v32, 0x3f

    aput-byte v4, v8, v32

    const/16 v32, 0x40

    const/16 v33, -0x65

    aput-byte v33, v8, v32

    const/16 v32, 0x41

    const/16 v33, -0x35

    aput-byte v33, v8, v32

    const/16 v32, 0x42

    const/16 v33, -0x71

    aput-byte v33, v8, v32

    const/16 v32, 0x43

    const/16 v33, -0x55

    aput-byte v33, v8, v32

    const/16 v32, 0x44

    const/16 v33, -0x71

    aput-byte v33, v8, v32

    const/16 v32, 0x45

    const/16 v33, -0x23

    aput-byte v33, v8, v32

    const/16 v32, 0x46

    const/16 v33, 0x7a

    aput-byte v33, v8, v32

    const/16 v32, 0x47

    const/16 v33, -0x74

    aput-byte v33, v8, v32

    const/16 v32, 0x48

    aput-byte v4, v8, v32

    const/16 v32, 0x49

    const/16 v33, -0x78

    aput-byte v33, v8, v32

    const/16 v32, 0x4a

    const/16 v33, -0x72

    aput-byte v33, v8, v32

    const/16 v32, 0x4b

    const/16 v33, -0xc

    aput-byte v33, v8, v32

    const/16 v32, 0x4c

    const/16 v33, -0x66

    aput-byte v33, v8, v32

    const/16 v32, 0x4d

    const/16 v33, -0x6e

    aput-byte v33, v8, v32

    const/16 v32, 0x4e

    aput-byte v29, v8, v32

    const/16 v32, -0x6b

    const/16 v33, 0x4f

    aput-byte v32, v8, v33

    const/16 v32, 0x50

    const/16 v34, -0x7a

    aput-byte v34, v8, v32

    const/16 v32, 0x51

    const/16 v34, -0x63

    aput-byte v34, v8, v32

    const/16 v32, 0x52

    const/16 v34, -0x31

    aput-byte v34, v8, v32

    const/16 v32, 0x53

    const/16 v34, -0x55

    aput-byte v34, v8, v32

    const/16 v32, -0x61

    const/16 v34, 0x54

    aput-byte v32, v8, v34

    const/16 v32, 0x55

    const/16 v35, -0x36

    aput-byte v35, v8, v32

    const/16 v32, 0x56

    const/16 v35, 0x7a

    aput-byte v35, v8, v32

    const/16 v32, 0x57

    aput-byte v9, v8, v32

    const/16 v9, 0x58

    const/16 v32, -0x3a

    aput-byte v32, v8, v9

    const/16 v9, 0x59

    const/16 v32, -0x65

    aput-byte v32, v8, v9

    const/16 v9, -0x2d

    const/16 v32, 0x5a

    aput-byte v9, v8, v32

    const/16 v9, 0x5b

    const/16 v35, -0x41

    aput-byte v35, v8, v9

    new-array v9, v5, [B

    const/16 v35, -0x18

    aput-byte v35, v9, v10

    const/16 v35, -0x52

    aput-byte v35, v9, v11

    const/16 v35, -0x3

    aput-byte v35, v9, v12

    aput-byte v19, v9, v13

    aput-byte v23, v9, v14

    const/16 v35, -0x51

    const/16 v36, 0x5

    aput-byte v35, v9, v36

    const/16 v35, 0x47

    const/16 v36, 0x6

    aput-byte v35, v9, v36

    const/16 v35, -0x4

    aput-byte v35, v9, v15

    invoke-static {v8, v9}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v8

    new-instance v9, Ljava/util/HashMap;

    invoke-direct {v9}, Ljava/util/HashMap;-><init>()V

    const/4 v15, 0x5

    new-array v15, v15, [B

    const/16 v35, 0x7e

    aput-byte v35, v15, v10

    const/16 v35, 0x75

    aput-byte v35, v15, v11

    const/16 v35, -0x49

    aput-byte v35, v15, v12

    const/16 v35, -0x5d

    aput-byte v35, v15, v13

    const/16 v35, -0x22

    aput-byte v35, v15, v14

    new-array v4, v5, [B

    const/16 v36, 0xd

    aput-byte v36, v4, v10

    aput-byte v21, v4, v11

    const/16 v36, -0x2e

    aput-byte v36, v4, v12

    const/16 v36, -0x33

    aput-byte v36, v4, v13

    const/16 v36, -0x45

    aput-byte v36, v4, v14

    const/16 v36, -0x6e

    const/16 v37, 0x5

    aput-byte v36, v4, v37

    const/16 v36, -0x5e

    const/16 v37, 0x6

    aput-byte v36, v4, v37

    const/16 v36, 0x7

    aput-byte v31, v4, v36

    invoke-static {v15, v4}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v4

    new-array v14, v14, [B

    const/16 v15, 0x45

    aput-byte v15, v14, v10

    const/16 v15, 0xd

    aput-byte v15, v14, v11

    aput-byte v34, v14, v12

    const/16 v15, 0x50

    aput-byte v15, v14, v13

    new-array v15, v5, [B

    const/16 v36, 0x29

    aput-byte v36, v15, v10

    const/16 v36, 0x64

    aput-byte v36, v15, v11

    const/16 v36, 0x3a

    aput-byte v36, v15, v12

    const/16 v36, 0x3b

    aput-byte v36, v15, v13

    const/16 v36, 0x4

    aput-byte v23, v15, v36

    const/16 v36, -0x43

    const/16 v37, 0x5

    aput-byte v36, v15, v37

    const/16 v36, 0x6

    aput-byte v25, v15, v36

    const/16 v36, -0x1c

    const/16 v37, 0x7

    aput-byte v36, v15, v37

    invoke-static {v14, v15}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v14

    invoke-virtual {v9, v4, v14}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    new-array v4, v5, [B

    const/16 v14, 0x10

    aput-byte v14, v4, v10

    const/16 v14, -0x5d

    aput-byte v14, v4, v11

    const/16 v14, -0x22

    aput-byte v14, v4, v12

    const/16 v14, -0x80

    aput-byte v14, v4, v13

    const/16 v14, -0x2c

    const/4 v15, 0x4

    aput-byte v14, v4, v15

    const/4 v14, 0x5

    aput-byte v22, v4, v14

    const/16 v14, -0x67

    const/4 v15, 0x6

    aput-byte v14, v4, v15

    const/16 v14, -0x45

    const/4 v15, 0x7

    aput-byte v14, v4, v15

    new-array v14, v5, [B

    const/16 v15, 0x60

    aput-byte v15, v14, v10

    const/16 v15, -0x39

    aput-byte v15, v14, v11

    const/16 v15, -0x49

    aput-byte v15, v14, v12

    const/16 v15, -0xe

    aput-byte v15, v14, v13

    const/4 v15, 0x4

    const/16 v35, -0x75

    aput-byte v35, v14, v15

    const/16 v15, 0x7c

    const/16 v36, 0x5

    aput-byte v15, v14, v36

    const/16 v15, -0x10

    const/16 v36, 0x6

    aput-byte v15, v14, v36

    const/16 v15, -0x21

    const/16 v36, 0x7

    aput-byte v15, v14, v36

    invoke-static {v4, v14}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v4

    new-array v14, v11, [B

    const/16 v15, 0x43

    aput-byte v15, v14, v10

    new-array v5, v5, [B

    const/16 v15, 0x73

    aput-byte v15, v5, v10

    const/16 v15, -0x29

    aput-byte v15, v5, v11

    const/16 v15, -0xc

    aput-byte v15, v5, v12

    const/16 v15, -0xb

    aput-byte v15, v5, v13

    const/4 v15, 0x4

    aput-byte v22, v5, v15

    const/16 v15, 0x5f

    const/16 v36, 0x5

    aput-byte v15, v5, v36

    const/16 v15, 0x1b

    const/4 v13, 0x6

    aput-byte v15, v5, v13

    const/16 v15, 0x38

    const/16 v37, 0x7

    aput-byte v15, v5, v37

    invoke-static {v14, v5}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v9, v4, v5}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    new-array v4, v13, [B

    const/16 v5, -0x1f

    aput-byte v5, v4, v10

    const/16 v5, -0x2b

    aput-byte v5, v4, v11

    const/16 v5, 0x55

    aput-byte v5, v4, v12

    const/16 v5, 0x34

    const/4 v13, 0x3

    aput-byte v5, v4, v13

    const/16 v5, 0x1e

    const/4 v13, 0x4

    aput-byte v5, v4, v13

    const/16 v5, -0x64

    const/4 v13, 0x5

    aput-byte v5, v4, v13

    const/16 v5, 0x8

    new-array v5, v5, [B

    const/16 v13, -0x6f

    aput-byte v13, v5, v10

    const/16 v13, -0x5e

    aput-byte v13, v5, v11

    const/16 v13, 0x31

    aput-byte v13, v5, v12

    const/16 v13, 0x6b

    const/4 v14, 0x3

    aput-byte v13, v5, v14

    const/16 v13, 0x77

    const/4 v14, 0x4

    aput-byte v13, v5, v14

    const/4 v13, -0x8

    const/4 v14, 0x5

    aput-byte v13, v5, v14

    const/16 v13, -0x39

    const/4 v14, 0x6

    aput-byte v13, v5, v14

    const/16 v13, -0x74

    const/4 v15, 0x7

    aput-byte v13, v5, v15

    invoke-static {v4, v5}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v9, v4, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    new-array v4, v14, [B

    aput-byte v30, v4, v10

    const/16 v5, 0x63

    aput-byte v5, v4, v11

    const/16 v5, -0xa

    aput-byte v5, v4, v12

    const/4 v5, -0x3

    const/4 v13, 0x3

    aput-byte v5, v4, v13

    const/16 v5, 0x25

    const/4 v13, 0x4

    aput-byte v5, v4, v13

    const/16 v5, -0x57

    const/4 v13, 0x5

    aput-byte v5, v4, v13

    const/16 v5, 0x8

    new-array v5, v5, [B

    const/16 v13, 0x5b

    aput-byte v13, v5, v10

    const/16 v13, 0x17

    aput-byte v13, v5, v11

    const/16 v13, -0x67

    aput-byte v13, v5, v12

    const/16 v13, -0x6a

    const/4 v14, 0x3

    aput-byte v13, v5, v14

    const/16 v13, 0x40

    const/4 v14, 0x4

    aput-byte v13, v5, v14

    const/16 v13, -0x39

    const/4 v14, 0x5

    aput-byte v13, v5, v14

    const/16 v13, -0x22

    const/4 v14, 0x6

    aput-byte v13, v5, v14

    const/16 v13, 0x5d

    const/4 v14, 0x7

    aput-byte v13, v5, v14

    invoke-static {v4, v5}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v4

    iget-object v5, v1, Lcom/github/catvod/spider/appysv2/b/U;->e:Lcom/github/catvod/spider/appysv2/l/e;

    invoke-virtual {v5}, Lcom/github/catvod/spider/appysv2/l/e;->b()Lcom/github/catvod/spider/appysv2/l/d;

    move-result-object v5

    invoke-virtual {v5}, Lcom/github/catvod/spider/appysv2/l/d;->a()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v9, v4, v5}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/16 v4, 0xb

    new-array v4, v4, [B

    const/16 v5, -0x25

    aput-byte v5, v4, v10

    aput-byte v22, v4, v11

    const/16 v5, 0x5b

    aput-byte v5, v4, v12

    const/16 v5, -0x44

    const/4 v13, 0x3

    aput-byte v5, v4, v13

    const/4 v5, 0x4

    aput-byte v28, v4, v5

    const/16 v5, -0x71

    const/4 v13, 0x5

    aput-byte v5, v4, v13

    const/16 v5, 0x42

    const/4 v13, 0x6

    aput-byte v5, v4, v13

    const/16 v5, -0x6d

    const/4 v13, 0x7

    aput-byte v5, v4, v13

    const/16 v5, -0x37

    const/16 v13, 0x8

    aput-byte v5, v4, v13

    const/16 v5, 0x9

    aput-byte v24, v4, v5

    const/16 v5, 0x60

    aput-byte v5, v4, v16

    new-array v5, v13, [B

    const/16 v13, -0x51

    aput-byte v13, v5, v10

    const/16 v13, 0x75

    aput-byte v13, v5, v11

    const/4 v13, 0x4

    aput-byte v13, v5, v12

    const/16 v14, -0x34

    const/4 v15, 0x3

    aput-byte v14, v5, v15

    const/16 v14, 0x40

    aput-byte v14, v5, v13

    const/16 v13, -0x1a

    const/4 v14, 0x5

    aput-byte v13, v5, v14

    const/4 v13, 0x6

    aput-byte v29, v5, v13

    const/16 v13, -0x34

    const/4 v14, 0x7

    aput-byte v13, v5, v14

    invoke-static {v4, v5}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v9, v4, v6}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/16 v4, 0x8

    new-array v4, v4, [B

    aput-byte v31, v4, v10

    const/16 v5, 0x7d

    aput-byte v5, v4, v11

    const/16 v5, -0x66

    aput-byte v5, v4, v12

    const/4 v5, 0x3

    aput-byte v22, v4, v5

    const/16 v5, -0x9

    const/4 v6, 0x4

    aput-byte v5, v4, v6

    const/4 v5, 0x5

    aput-byte v29, v4, v5

    const/4 v5, 0x6

    aput-byte v33, v4, v5

    const/16 v5, -0x27

    const/4 v6, 0x7

    aput-byte v5, v4, v6

    const/16 v5, 0x8

    new-array v5, v5, [B

    const/16 v6, 0x4c

    aput-byte v6, v5, v10

    aput-byte v20, v5, v11

    const/4 v6, -0x2

    aput-byte v6, v5, v12

    const/16 v6, 0x45

    const/4 v13, 0x3

    aput-byte v6, v5, v13

    const/16 v6, -0x65

    const/4 v13, 0x4

    aput-byte v6, v5, v13

    const/16 v6, 0x59

    const/4 v13, 0x5

    aput-byte v6, v5, v13

    const/16 v6, 0x3c

    const/4 v13, 0x6

    aput-byte v6, v5, v13

    const/16 v6, -0x53

    const/4 v13, 0x7

    aput-byte v6, v5, v13

    invoke-static {v4, v5}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-static/range {p2 .. p2}, Ljava/util/Collections;->singletonList(Ljava/lang/Object;)Ljava/util/List;

    move-result-object v5

    invoke-virtual {v9, v4, v5}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/16 v4, 0xe

    new-array v4, v4, [B

    const/16 v5, 0x47

    aput-byte v5, v4, v10

    aput-byte v18, v4, v11

    const/16 v5, -0x51

    aput-byte v5, v4, v12

    const/16 v5, -0x45

    const/4 v6, 0x3

    aput-byte v5, v4, v6

    const/4 v5, 0x4

    aput-byte v12, v4, v5

    const/16 v5, 0x12

    const/4 v6, 0x5

    aput-byte v5, v4, v6

    const/16 v5, 0x43

    const/4 v6, 0x6

    aput-byte v5, v4, v6

    const/16 v5, -0x2d

    const/4 v6, 0x7

    aput-byte v5, v4, v6

    const/16 v5, 0x8

    aput-byte v33, v4, v5

    const/16 v5, 0x39

    const/16 v6, 0x9

    aput-byte v5, v4, v6

    const/16 v5, -0x59

    aput-byte v5, v4, v16

    const/16 v5, 0xb

    aput-byte v19, v4, v5

    const/4 v5, 0x5

    aput-byte v5, v4, v17

    const/16 v5, 0xd

    aput-byte v6, v4, v5

    const/16 v5, 0x8

    new-array v5, v5, [B

    const/16 v6, 0x21

    aput-byte v6, v5, v10

    const/16 v6, 0x66

    aput-byte v6, v5, v11

    const/16 v6, -0x35

    aput-byte v6, v5, v12

    const/16 v6, -0x1c

    const/4 v13, 0x3

    aput-byte v6, v5, v13

    const/16 v6, 0x76

    const/4 v13, 0x4

    aput-byte v6, v5, v13

    const/16 v6, 0x7d

    const/4 v13, 0x5

    aput-byte v6, v5, v13

    const/4 v6, 0x6

    aput-byte v30, v5, v6

    const/16 v6, -0x4a

    const/4 v13, 0x7

    aput-byte v6, v5, v13

    invoke-static {v4, v5}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-static {v7}, Ljava/util/Collections;->singletonList(Ljava/lang/Object;)Ljava/util/List;

    move-result-object v5

    invoke-virtual {v9, v4, v5}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    new-instance v4, Lorg/json/JSONObject;

    invoke-direct {v1, v8, v9}, Lcom/github/catvod/spider/appysv2/b/U;->L(Ljava/lang/String;Ljava/util/Map;)Ljava/lang/String;

    move-result-object v5

    invoke-direct {v4, v5}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x4

    new-array v5, v5, [B

    aput-byte v28, v5, v10

    aput-byte v17, v5, v11

    const/16 v6, -0x41

    aput-byte v6, v5, v12

    const/4 v6, 0x3

    aput-byte v33, v5, v6

    const/16 v6, 0x8

    new-array v6, v6, [B

    const/16 v7, 0x47

    aput-byte v7, v6, v10

    const/16 v7, 0x63

    aput-byte v7, v6, v11

    const/16 v7, -0x25

    aput-byte v7, v6, v12

    const/4 v7, 0x3

    aput-byte v31, v6, v7

    const/4 v7, 0x4

    aput-byte v27, v6, v7

    const/16 v7, -0x39

    const/4 v8, 0x5

    aput-byte v7, v6, v8

    const/16 v7, -0x5d

    const/4 v8, 0x6

    aput-byte v7, v6, v8

    const/16 v7, 0x32

    const/4 v8, 0x7

    aput-byte v7, v6, v8

    invoke-static {v5, v6}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5}, Lorg/json/JSONObject;->getInt(Ljava/lang/String;)I

    move-result v5

    const v6, 0xa039

    if-ne v5, v6, :cond_59a

    return-object v3

    :cond_59a
    const/4 v5, 0x6

    new-array v5, v5, [B

    const/16 v6, -0x6f

    aput-byte v6, v5, v10

    aput-byte v29, v5, v11

    const/16 v6, 0x6e

    aput-byte v6, v5, v12

    const/4 v6, 0x3

    aput-byte v16, v5, v6

    const/4 v6, 0x4

    aput-byte v28, v5, v6

    const/4 v6, 0x5

    aput-byte v26, v5, v6

    const/16 v6, 0x8

    new-array v6, v6, [B

    const/16 v7, -0x1e

    aput-byte v7, v6, v10

    const/16 v7, 0x44

    aput-byte v7, v6, v11

    aput-byte v18, v6, v12

    const/16 v7, 0x7e

    const/4 v8, 0x3

    aput-byte v7, v6, v8

    const/16 v7, 0x51

    const/4 v8, 0x4

    aput-byte v7, v6, v8

    const/16 v7, 0x55

    const/4 v8, 0x5

    aput-byte v7, v6, v8

    const/16 v7, -0x7b

    const/4 v8, 0x6

    aput-byte v7, v6, v8

    const/16 v7, -0x1b

    const/4 v8, 0x7

    aput-byte v7, v6, v8

    invoke-static {v5, v6}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5}, Lorg/json/JSONObject;->getInt(Ljava/lang/String;)I

    move-result v5

    const/16 v6, 0xc8

    if-ne v5, v6, :cond_626

    const/4 v5, 0x4

    new-array v5, v5, [B

    const/16 v6, -0x1a

    aput-byte v6, v5, v10

    const/16 v6, -0x63

    aput-byte v6, v5, v11

    const/16 v6, 0x61

    aput-byte v6, v5, v12

    const/16 v6, -0x28

    const/4 v7, 0x3

    aput-byte v6, v5, v7

    const/16 v6, 0x8

    new-array v6, v6, [B

    const/16 v7, -0x7b

    aput-byte v7, v6, v10

    const/16 v7, -0xe

    aput-byte v7, v6, v11

    const/4 v7, 0x5

    aput-byte v7, v6, v12

    const/16 v8, -0x43

    const/4 v13, 0x3

    aput-byte v8, v6, v13

    const/16 v8, -0x45

    const/4 v13, 0x4

    aput-byte v8, v6, v13

    aput-byte v33, v6, v7

    const/16 v7, 0x3b

    const/4 v8, 0x6

    aput-byte v7, v6, v8

    const/16 v7, -0x24

    const/4 v8, 0x7

    aput-byte v7, v6, v8

    invoke-static {v5, v6}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5}, Lorg/json/JSONObject;->getInt(Ljava/lang/String;)I

    move-result v5

    if-eqz v5, :cond_6bc

    :cond_626
    invoke-direct {v1, v4, v2, v3, v9}, Lcom/github/catvod/spider/appysv2/b/U;->H(Lorg/json/JSONObject;Ljava/lang/String;Ljava/lang/String;Ljava/util/Map;)Lorg/json/JSONObject;

    move-result-object v4

    if-nez v4, :cond_62f

    const-string v2, ""

    return-object v2

    :cond_62f
    const/4 v5, 0x4

    new-array v5, v5, [B

    const/16 v6, 0x36

    aput-byte v6, v5, v10

    aput-byte v23, v5, v11

    const/16 v6, -0x44

    aput-byte v6, v5, v12

    const/16 v6, -0x7f

    const/4 v7, 0x3

    aput-byte v6, v5, v7

    const/16 v6, 0x8

    new-array v6, v6, [B

    const/16 v7, 0x55

    aput-byte v7, v6, v10

    const/16 v7, -0x7a

    aput-byte v7, v6, v11

    const/16 v7, -0x28

    aput-byte v7, v6, v12

    const/16 v7, -0x1c

    const/4 v8, 0x3

    aput-byte v7, v6, v8

    const/4 v7, 0x4

    aput-byte v18, v6, v7

    const/16 v7, 0x58

    const/4 v8, 0x5

    aput-byte v7, v6, v8

    const/16 v7, 0x77

    const/4 v8, 0x6

    aput-byte v7, v6, v8

    const/16 v7, -0x18

    const/4 v8, 0x7

    aput-byte v7, v6, v8

    invoke-static {v5, v6}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5}, Lorg/json/JSONObject;->getInt(Ljava/lang/String;)I

    move-result v5

    const v6, 0xa039

    if-ne v5, v6, :cond_676

    return-object v3

    :cond_676
    const/4 v5, 0x6

    new-array v5, v5, [B

    const/4 v6, -0x2

    aput-byte v6, v5, v10

    const/16 v6, 0x60

    aput-byte v6, v5, v11

    aput-byte v24, v5, v12

    const/4 v6, 0x3

    const/16 v7, -0x75

    aput-byte v7, v5, v6

    const/16 v6, -0xe

    const/4 v7, 0x4

    aput-byte v6, v5, v7

    const/16 v6, -0x4f

    const/4 v7, 0x5

    aput-byte v6, v5, v7

    const/16 v6, 0x8

    new-array v6, v6, [B

    aput-byte v19, v6, v10

    aput-byte v20, v6, v11

    const/16 v7, 0x7d

    aput-byte v7, v6, v12

    const/4 v7, -0x1

    const/4 v8, 0x3

    aput-byte v7, v6, v8

    const/16 v7, -0x79

    const/4 v8, 0x4

    aput-byte v7, v6, v8

    const/16 v7, -0x3e

    const/4 v8, 0x5

    aput-byte v7, v6, v8

    const/16 v7, 0x67

    const/4 v8, 0x6

    aput-byte v7, v6, v8

    const/16 v7, -0x9

    const/4 v8, 0x7

    aput-byte v7, v6, v8

    invoke-static {v5, v6}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5}, Lorg/json/JSONObject;->getInt(Ljava/lang/String;)I

    :cond_6bc
    const/4 v5, 0x4

    new-array v5, v5, [B

    const/16 v6, 0x7c

    aput-byte v6, v5, v10

    const/4 v6, 0x3

    aput-byte v6, v5, v11

    aput-byte v22, v5, v12

    const/16 v7, 0x45

    aput-byte v7, v5, v6

    const/16 v6, 0x8

    new-array v6, v6, [B

    const/16 v7, 0x18

    aput-byte v7, v6, v10

    const/16 v7, 0x62

    aput-byte v7, v6, v11

    const/16 v7, 0x6e

    aput-byte v7, v6, v12

    const/4 v7, 0x3

    aput-byte v28, v6, v7

    const/16 v7, -0x50

    const/4 v8, 0x4

    aput-byte v7, v6, v8

    const/16 v7, -0xc

    const/4 v8, 0x5

    aput-byte v7, v6, v8

    const/16 v7, -0x5d

    const/4 v8, 0x6

    aput-byte v7, v6, v8

    const/4 v7, 0x7

    aput-byte v34, v6, v7

    invoke-static {v5, v6}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5}, Lorg/json/JSONObject;->optJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v4

    new-array v5, v7, [B

    const/16 v6, -0x4c

    aput-byte v6, v5, v10

    const/16 v6, -0x9

    aput-byte v6, v5, v11

    const/16 v6, -0x58

    aput-byte v6, v5, v12

    const/4 v6, 0x4

    const/4 v7, 0x3

    aput-byte v6, v5, v7

    aput-byte v27, v5, v6

    const/16 v6, 0x8

    const/4 v7, 0x5

    aput-byte v6, v5, v7

    const/16 v7, -0x6c

    const/4 v8, 0x6

    aput-byte v7, v5, v8

    new-array v6, v6, [B

    const/16 v7, -0x40

    aput-byte v7, v6, v10

    const/16 v7, -0x6a

    aput-byte v7, v6, v11

    const/16 v7, -0x25

    aput-byte v7, v6, v12

    const/16 v7, 0x6f

    const/4 v8, 0x3

    aput-byte v7, v6, v8

    const/16 v7, 0x7d

    const/4 v8, 0x4

    aput-byte v7, v6, v8

    const/16 v7, 0x61

    const/4 v8, 0x5

    aput-byte v7, v6, v8

    const/16 v7, -0x10

    const/4 v8, 0x6

    aput-byte v7, v6, v8

    const/16 v7, -0x63

    const/4 v8, 0x7

    aput-byte v7, v6, v8

    invoke-static {v5, v6}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    new-instance v5, Lorg/json/JSONArray;

    invoke-direct {v5}, Lorg/json/JSONArray;-><init>()V

    const/4 v6, 0x0

    :goto_74c
    const/4 v7, 0x5

    if-ge v6, v7, :cond_ad3

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    const/16 v7, 0x4c

    new-array v7, v7, [B

    const/16 v8, -0x1e

    aput-byte v8, v7, v10

    const/16 v8, -0x19

    aput-byte v8, v7, v11

    aput-byte v25, v7, v12

    const/16 v8, 0x7d

    const/4 v9, 0x3

    aput-byte v8, v7, v9

    const/4 v8, 0x4

    aput-byte v32, v7, v8

    const/4 v8, 0x5

    aput-byte v34, v7, v8

    const/4 v8, 0x6

    aput-byte v32, v7, v8

    const/4 v8, 0x7

    aput-byte v19, v7, v8

    const/4 v8, -0x6

    const/16 v9, 0x8

    aput-byte v8, v7, v9

    const/16 v8, -0x10

    const/16 v9, 0x9

    aput-byte v8, v7, v9

    const/16 v8, 0x79

    aput-byte v8, v7, v16

    const/16 v8, 0x6c

    const/16 v9, 0xb

    aput-byte v8, v7, v9

    const/16 v8, 0x59

    aput-byte v8, v7, v17

    const/16 v8, 0xd

    const/4 v9, 0x7

    aput-byte v9, v7, v8

    const/16 v8, 0x5b

    const/16 v9, 0xe

    aput-byte v8, v7, v9

    const/16 v8, -0x29

    aput-byte v8, v7, v18

    const/16 v8, 0x10

    aput-byte v23, v7, v8

    const/16 v8, 0x11

    const/16 v9, -0x43

    aput-byte v9, v7, v8

    const/16 v8, 0x12

    const/16 v9, 0x37

    aput-byte v9, v7, v8

    const/16 v8, 0x13

    const/16 v9, 0x63

    aput-byte v9, v7, v8

    const/4 v8, 0x6

    aput-byte v8, v7, v20

    const/16 v8, 0x15

    const/16 v9, 0x5f

    aput-byte v9, v7, v8

    aput-byte v32, v7, v21

    const/16 v8, 0x17

    const/16 v9, -0x3f

    aput-byte v9, v7, v8

    const/16 v8, 0x18

    const/16 v9, -0x1a

    aput-byte v9, v7, v8

    const/16 v8, 0x19

    const/4 v9, -0x4

    aput-byte v9, v7, v8

    const/16 v8, 0x21

    aput-byte v8, v7, v22

    const/16 v8, 0x1b

    const/16 v9, 0x69

    aput-byte v9, v7, v8

    const/16 v8, 0x4d

    aput-byte v8, v7, v24

    const/16 v8, 0x1d

    aput-byte v24, v7, v8

    const/16 v8, 0x1e

    aput-byte v24, v7, v8

    const/16 v8, 0x1f

    const/16 v9, -0x2c

    aput-byte v9, v7, v8

    const/16 v8, -0x11

    aput-byte v8, v7, v25

    const/16 v8, 0x21

    const/16 v9, -0x44

    aput-byte v9, v7, v8

    aput-byte v25, v7, v27

    const/16 v8, 0x23

    const/16 v9, 0x6c

    aput-byte v9, v7, v8

    aput-byte v32, v7, v28

    const/16 v8, 0x25

    const/4 v9, 0x5

    aput-byte v9, v7, v8

    const/16 v8, 0x4a

    aput-byte v8, v7, v26

    const/16 v8, 0x27

    const/16 v9, -0x2e

    aput-byte v9, v7, v8

    const/4 v8, -0x8

    aput-byte v8, v7, v30

    const/16 v8, 0x29

    const/16 v9, -0x52

    aput-byte v9, v7, v8

    aput-byte v11, v7, v31

    const/16 v8, 0x2b

    const/16 v9, 0x4e

    aput-byte v9, v7, v8

    const/16 v8, 0x2c

    const/16 v9, 0x6b

    aput-byte v9, v7, v8

    const/16 v8, 0x2d

    aput-byte v24, v7, v8

    const/16 v8, 0x2e

    aput-byte v22, v7, v8

    const/16 v8, 0x2f

    const/16 v9, -0x2b

    aput-byte v9, v7, v8

    const/4 v8, -0x7

    aput-byte v8, v7, v29

    const/16 v8, 0x31

    const/16 v9, -0xa

    aput-byte v9, v7, v8

    const/16 v8, 0x32

    aput-byte v26, v7, v8

    const/16 v8, 0x33

    const/16 v9, 0x2b

    aput-byte v9, v7, v8

    const/16 v8, 0x34

    aput-byte v33, v7, v8

    const/16 v8, 0x35

    aput-byte v24, v7, v8

    const/16 v8, 0x36

    const/16 v9, 0x48

    aput-byte v9, v7, v8

    const/16 v8, 0x37

    const/16 v9, -0x2e

    aput-byte v9, v7, v8

    const/16 v8, 0x38

    aput-byte v23, v7, v8

    const/16 v8, 0x39

    const/16 v9, -0x4b

    aput-byte v9, v7, v8

    const/16 v8, 0x3a

    const/16 v9, 0x27

    aput-byte v9, v7, v8

    const/16 v8, 0x3b

    const/16 v9, 0x74

    aput-byte v9, v7, v8

    const/16 v8, 0x3c

    aput-byte v32, v7, v8

    const/16 v8, 0x3d

    const/16 v9, 0x53

    aput-byte v9, v7, v8

    const/16 v8, 0x3e

    aput-byte v12, v7, v8

    const/16 v8, 0x3f

    const/16 v9, -0x35

    aput-byte v9, v7, v8

    const/16 v8, 0x40

    const/16 v9, -0x1c

    aput-byte v9, v7, v8

    const/16 v8, 0x41

    const/16 v9, -0x60

    aput-byte v9, v7, v8

    const/16 v8, 0x42

    const/16 v9, 0x66

    aput-byte v9, v7, v8

    const/16 v8, 0x43

    const/16 v9, 0x2b

    aput-byte v9, v7, v8

    const/16 v8, 0x44

    const/16 v9, 0x5d

    aput-byte v9, v7, v8

    const/16 v8, 0x45

    aput-byte v18, v7, v8

    const/16 v8, 0x46

    const/4 v9, 0x6

    aput-byte v9, v7, v8

    const/16 v8, 0x47

    const/16 v9, -0x37

    aput-byte v9, v7, v8

    const/16 v8, 0x48

    const/16 v9, -0x2b

    aput-byte v9, v7, v8

    const/16 v8, 0x49

    const/4 v9, -0x6

    aput-byte v9, v7, v8

    const/16 v8, 0x4a

    aput-byte v29, v7, v8

    const/16 v8, 0x4b

    aput-byte v29, v7, v8

    const/16 v8, 0x8

    new-array v8, v8, [B

    const/16 v9, -0x76

    aput-byte v9, v8, v10

    const/16 v9, -0x6d

    aput-byte v9, v8, v11

    aput-byte v34, v8, v12

    const/16 v9, 0xd

    const/4 v13, 0x3

    aput-byte v9, v8, v13

    const/16 v9, 0x29

    const/4 v13, 0x4

    aput-byte v9, v8, v13

    const/16 v9, 0x6e

    const/4 v13, 0x5

    aput-byte v9, v8, v13

    const/16 v9, 0x75

    const/4 v13, 0x6

    aput-byte v9, v8, v13

    const/16 v9, -0x5e

    const/4 v13, 0x7

    aput-byte v9, v8, v13

    invoke-static {v7, v8}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v5, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v7, 0xd

    new-array v7, v7, [B

    const/16 v8, 0x11

    aput-byte v8, v7, v10

    const/16 v8, 0x18

    aput-byte v8, v7, v11

    const/16 v8, -0x6d

    aput-byte v8, v7, v12

    const/4 v8, 0x3

    aput-byte v17, v7, v8

    const/16 v8, 0x33

    const/4 v9, 0x4

    aput-byte v8, v7, v9

    const/16 v8, 0x2f

    const/4 v9, 0x5

    aput-byte v8, v7, v9

    const/16 v8, 0x34

    const/4 v9, 0x6

    aput-byte v8, v7, v9

    const/16 v8, -0xf

    const/4 v9, 0x7

    aput-byte v8, v7, v9

    const/16 v8, 0x59

    const/16 v9, 0x8

    aput-byte v8, v7, v9

    const/16 v8, 0xe

    const/16 v9, 0x9

    aput-byte v8, v7, v9

    const/16 v8, -0x6d

    aput-byte v8, v7, v16

    const/16 v8, 0xb

    aput-byte v10, v7, v8

    const/16 v8, 0x7c

    aput-byte v8, v7, v17

    const/16 v8, 0x8

    new-array v8, v8, [B

    const/16 v9, 0x37

    aput-byte v9, v8, v10

    const/16 v9, 0x6a

    aput-byte v9, v8, v11

    const/16 v9, -0xa

    aput-byte v9, v8, v12

    const/16 v9, 0x78

    const/4 v13, 0x3

    aput-byte v9, v8, v13

    const/16 v9, 0x41

    const/4 v13, 0x4

    aput-byte v9, v8, v13

    const/16 v9, 0x56

    const/4 v13, 0x5

    aput-byte v9, v8, v13

    const/16 v9, 0x6b

    const/4 v13, 0x6

    aput-byte v9, v8, v13

    const/16 v9, -0x68

    const/4 v13, 0x7

    aput-byte v9, v8, v13

    invoke-static {v7, v8}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v5, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v5, v11}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v7, 0x5

    new-array v7, v7, [B

    const/16 v8, -0x68

    aput-byte v8, v7, v10

    const/16 v8, 0x71

    aput-byte v8, v7, v11

    const/16 v8, 0x4c

    aput-byte v8, v7, v12

    const/16 v8, 0x49

    const/4 v9, 0x3

    aput-byte v8, v7, v9

    const/16 v8, -0x33

    const/4 v9, 0x4

    aput-byte v8, v7, v9

    const/16 v8, 0x8

    new-array v8, v8, [B

    const/16 v9, -0x42

    aput-byte v9, v8, v10

    const/16 v9, 0x2e

    aput-byte v9, v8, v11

    const/16 v9, 0x13

    aput-byte v9, v8, v12

    const/16 v9, 0x3d

    const/4 v13, 0x3

    aput-byte v9, v8, v13

    const/16 v9, -0x10

    const/4 v13, 0x4

    aput-byte v9, v8, v13

    const/16 v9, 0x6a

    const/4 v14, 0x5

    aput-byte v9, v8, v14

    const/16 v9, 0x10

    const/4 v14, 0x6

    aput-byte v9, v8, v14

    const/4 v9, 0x7

    aput-byte v13, v8, v9

    invoke-static {v7, v8}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v5, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v7

    invoke-virtual {v5, v7, v8}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    new-instance v7, Lorg/json/JSONObject;

    invoke-direct {v1, v5}, Lcom/github/catvod/spider/appysv2/b/U;->u(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    invoke-direct {v7, v5}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x4

    new-array v5, v5, [B

    const/16 v8, 0x73

    aput-byte v8, v5, v10

    const/16 v8, 0x4b

    aput-byte v8, v5, v11

    const/16 v8, 0x68

    aput-byte v8, v5, v12

    const/16 v8, -0x54

    const/4 v9, 0x3

    aput-byte v8, v5, v9

    const/16 v8, 0x8

    new-array v8, v8, [B

    const/16 v9, 0x17

    aput-byte v9, v8, v10

    aput-byte v31, v8, v11

    aput-byte v24, v8, v12

    const/16 v9, -0x33

    const/4 v13, 0x3

    aput-byte v9, v8, v13

    const/16 v9, 0x2b

    const/4 v13, 0x4

    aput-byte v9, v8, v13

    const/16 v9, 0x78

    const/4 v13, 0x5

    aput-byte v9, v8, v13

    const/16 v9, -0x57

    const/4 v13, 0x6

    aput-byte v9, v8, v13

    const/4 v9, 0x7

    aput-byte v17, v8, v9

    invoke-static {v5, v8}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v7, v5}, Lorg/json/JSONObject;->optJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v5

    new-array v7, v9, [B

    aput-byte v20, v7, v10

    const/16 v8, 0x53

    aput-byte v8, v7, v11

    aput-byte v34, v7, v12

    const/4 v8, 0x3

    aput-byte v21, v7, v8

    const/16 v8, -0x30

    const/4 v9, 0x4

    aput-byte v8, v7, v9

    const/4 v8, -0x4

    const/4 v9, 0x5

    aput-byte v8, v7, v9

    const/16 v8, -0x74

    const/4 v9, 0x6

    aput-byte v8, v7, v9

    const/16 v8, 0x8

    new-array v8, v8, [B

    const/16 v9, 0x67

    aput-byte v9, v8, v10

    const/16 v9, 0x32

    aput-byte v9, v8, v11

    aput-byte v27, v8, v12

    const/16 v9, 0x73

    const/4 v13, 0x3

    aput-byte v9, v8, v13

    const/16 v9, -0x71

    const/4 v13, 0x4

    aput-byte v9, v8, v13

    const/16 v9, -0x63

    const/4 v13, 0x5

    aput-byte v9, v8, v13

    const/4 v9, -0x1

    const/4 v13, 0x6

    aput-byte v9, v8, v13

    const/4 v9, -0x3

    const/4 v13, 0x7

    aput-byte v9, v8, v13

    invoke-static {v7, v8}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v5, v7}, Lorg/json/JSONObject;->optJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v5

    const/16 v7, 0x10

    new-array v7, v7, [B

    const/16 v8, 0x11

    aput-byte v8, v7, v10

    const/16 v8, 0x15

    aput-byte v8, v7, v11

    const/16 v8, -0x35

    aput-byte v8, v7, v12

    const/16 v8, 0x5d

    const/4 v9, 0x3

    aput-byte v8, v7, v9

    const/16 v8, 0x31

    const/4 v9, 0x4

    aput-byte v8, v7, v9

    const/4 v8, 0x5

    aput-byte v18, v7, v8

    const/16 v8, -0x53

    const/4 v9, 0x6

    aput-byte v8, v7, v9

    const/4 v8, 0x7

    aput-byte v17, v7, v8

    const/16 v8, 0x8

    aput-byte v21, v7, v8

    const/16 v9, 0x1b

    const/16 v13, 0x9

    aput-byte v9, v7, v13

    const/16 v9, -0x33

    aput-byte v9, v7, v16

    const/16 v9, 0x67

    const/16 v13, 0xb

    aput-byte v9, v7, v13

    aput-byte v8, v7, v17

    const/16 v9, 0xd

    const/4 v13, 0x7

    aput-byte v13, v7, v9

    const/16 v9, -0x46

    const/16 v13, 0xe

    aput-byte v9, v7, v13

    aput-byte v25, v7, v18

    new-array v8, v8, [B

    const/16 v9, 0x62

    aput-byte v9, v8, v10

    const/16 v9, 0x74

    aput-byte v9, v8, v11

    const/16 v9, -0x43

    aput-byte v9, v8, v12

    const/16 v9, 0x38

    const/4 v13, 0x3

    aput-byte v9, v8, v13

    const/16 v9, 0x6e

    const/4 v14, 0x4

    aput-byte v9, v8, v14

    const/16 v9, 0x6e

    const/4 v14, 0x5

    aput-byte v9, v8, v14

    const/16 v9, -0x22

    const/4 v14, 0x6

    aput-byte v9, v8, v14

    const/16 v9, 0x53

    const/4 v14, 0x7

    aput-byte v9, v8, v14

    invoke-static {v7, v8}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v5, v7}, Lorg/json/JSONObject;->optJSONArray(Ljava/lang/String;)Lorg/json/JSONArray;

    move-result-object v5

    invoke-virtual {v5}, Lorg/json/JSONArray;->length()I

    move-result v7

    if-lez v7, :cond_ac8

    goto :goto_ad3

    :cond_ac8
    sget-object v7, Ljava/util/concurrent/TimeUnit;->SECONDS:Ljava/util/concurrent/TimeUnit;

    const-wide/16 v8, 0x1

    invoke-virtual {v7, v8, v9}, Ljava/util/concurrent/TimeUnit;->sleep(J)V

    add-int/lit8 v6, v6, 0x1

    goto/16 :goto_74c

    :cond_ad3
    :goto_ad3
    invoke-virtual/range {p4 .. p4}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v4

    if-eqz v4, :cond_ae8

    invoke-virtual {v5}, Lorg/json/JSONArray;->length()I

    move-result v4

    if-nez v4, :cond_ae8

    sget-object v4, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    move-object/from16 v5, p3

    invoke-direct {v1, v2, v3, v5, v4}, Lcom/github/catvod/spider/appysv2/b/U;->q(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)Ljava/lang/String;

    move-result-object v2

    goto :goto_aec

    :cond_ae8
    invoke-virtual {v5, v10}, Lorg/json/JSONArray;->optString(I)Ljava/lang/String;

    move-result-object v2
    :try_end_aec
    .catch Ljava/lang/Exception; {:try_start_a .. :try_end_aec} :catch_aed

    :goto_aec
    return-object v2

    :catch_aed
    move-exception v0

    move-object v2, v0

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const/16 v4, 0x9

    new-array v4, v4, [B

    fill-array-data v4, :array_b08

    const/16 v5, 0x8

    new-array v5, v5, [B

    fill-array-data v5, :array_b12

    .line 1
    invoke-static {v4, v5, v3, v2}, Lcom/github/catvod/spider/appysv2/b/y;->b([B[BLjava/lang/StringBuilder;Ljava/lang/Exception;)V

    const-string v2, ""

    return-object v2

    :array_b08
    .array-data 1
        -0x68t
        -0x1t
        -0x4dt
        -0x45t
        0x2ft
        0x52t
        -0x27t
        0x54t
        -0x78t
    .end array-data

    nop

    :array_b12
    .array-data 1
        -0x13t
        -0x64t
        -0x6dt
        -0x28t
        0x40t
        0x22t
        -0x60t
        0x74t
    .end array-data
.end method

.method private r(Ljava/lang/String;)V
    .registers 49

    move-object/from16 v1, p0

    invoke-static/range {p1 .. p1}, Ljava/util/Collections;->singletonList(Ljava/lang/Object;)Ljava/util/List;

    move-result-object v0

    .line 1
    new-instance v2, Ljava/util/ArrayList;

    invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V

    const/16 v3, 0x15

    const/16 v4, 0x8

    :try_start_f
    invoke-direct/range {p0 .. p0}, Lcom/github/catvod/spider/appysv2/b/U;->v()Ljava/lang/String;

    move-result-object v5

    const/4 v6, 0x1

    new-array v7, v6, [B

    const/16 v8, 0x49

    const/4 v9, 0x0

    aput-byte v8, v7, v9

    new-array v8, v4, [B

    const/16 v10, 0x79

    aput-byte v10, v8, v9

    const/16 v10, 0x32

    aput-byte v10, v8, v6

    const/4 v10, 0x2

    const/16 v11, -0x49

    aput-byte v11, v8, v10

    const/4 v12, -0x6

    const/4 v13, 0x3

    aput-byte v12, v8, v13

    const/16 v12, -0x1a

    const/4 v14, 0x4

    aput-byte v12, v8, v14

    const/16 v12, -0x56

    const/4 v15, 0x5

    aput-byte v12, v8, v15

    const/16 v12, 0x3e

    const/16 v16, 0x6

    aput-byte v12, v8, v16

    const/4 v12, 0x7

    const/16 v17, -0x76

    aput-byte v17, v8, v12

    invoke-static {v7, v8}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v5, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v7

    if-eqz v7, :cond_4f

    goto/16 :goto_5fa

    :cond_4f
    invoke-virtual/range {p0 .. p0}, Lcom/github/catvod/spider/appysv2/b/U;->C()J

    const/4 v7, 0x1

    :goto_53
    const/16 v8, 0xa1

    new-array v8, v8, [B

    const/16 v18, -0x5a

    aput-byte v18, v8, v9

    const/16 v19, 0xa

    aput-byte v19, v8, v6

    const/16 v20, -0x6e

    aput-byte v20, v8, v10

    aput-byte v11, v8, v13

    const/16 v21, -0x25

    aput-byte v21, v8, v14

    const/16 v21, 0x52

    aput-byte v21, v8, v15

    const/16 v22, -0x15

    aput-byte v22, v8, v16

    const/16 v23, -0x24

    aput-byte v23, v8, v12

    const/16 v23, -0x42

    aput-byte v23, v8, v4

    const/16 v23, 0x1d

    const/16 v24, 0x9

    aput-byte v23, v8, v24

    const/16 v25, -0x35

    aput-byte v25, v8, v19

    const/16 v25, 0xb

    aput-byte v18, v8, v25

    const/16 v25, -0x28

    const/16 v26, 0xc

    aput-byte v25, v8, v26

    const/16 v27, 0xd

    aput-byte v6, v8, v27

    const/16 v28, 0xe

    const/16 v29, -0x16

    aput-byte v29, v8, v28

    const/16 v28, 0xf

    const/16 v29, -0x7a

    aput-byte v29, v8, v28

    const/16 v28, 0x10

    const/16 v29, -0x53

    aput-byte v29, v8, v28

    const/16 v28, 0x11

    const/16 v30, 0x50

    aput-byte v30, v8, v28

    const/16 v28, 0x12

    const/16 v30, -0x7b

    aput-byte v30, v8, v28

    const/16 v28, 0x13

    const/16 v31, -0x57

    aput-byte v31, v8, v28

    const/16 v28, 0x14

    const/16 v31, -0x79

    aput-byte v31, v8, v28

    const/16 v28, 0x59

    aput-byte v28, v8, v3

    const/16 v3, 0x16

    aput-byte v22, v8, v3

    const/16 v3, 0x17

    const/16 v32, -0x70

    aput-byte v32, v8, v3

    const/16 v3, 0x18

    const/16 v32, -0x5e

    aput-byte v32, v8, v3

    const/16 v3, 0x19

    const/16 v33, 0x11

    aput-byte v33, v8, v3

    const/16 v3, -0x6d

    const/16 v33, 0x1a

    aput-byte v3, v8, v33

    const/16 v34, -0x5d

    const/16 v35, 0x1b

    aput-byte v34, v8, v35

    const/16 v34, 0x1c

    const/16 v36, -0x34

    aput-byte v36, v8, v34

    aput-byte v33, v8, v23

    const/16 v34, 0x1e

    aput-byte v29, v8, v34

    const/16 v34, 0x1f

    aput-byte v30, v8, v34

    const/16 v34, 0x20

    const/16 v36, -0x55

    aput-byte v36, v8, v34

    const/16 v34, 0x21

    const/16 v36, 0x51

    aput-byte v36, v8, v34

    const/16 v34, 0x22

    const/16 v37, -0x80

    aput-byte v37, v8, v34

    const/16 v34, 0x23

    const/16 v38, -0x52

    aput-byte v38, v8, v34

    const/16 v34, 0x24

    const/16 v38, -0x3c

    aput-byte v38, v8, v34

    const/16 v34, 0x25

    aput-byte v27, v8, v34

    const/16 v34, 0x26

    aput-byte v22, v8, v34

    const/16 v34, 0x27

    aput-byte v37, v8, v34

    const/16 v34, 0x28

    const/16 v39, -0x5f

    aput-byte v39, v8, v34

    const/16 v34, 0x29

    aput-byte v26, v8, v34

    const/16 v34, 0x2a

    aput-byte v20, v8, v34

    const/16 v40, 0x2b

    const/16 v41, -0x8

    aput-byte v41, v8, v40

    const/16 v40, 0x2c

    aput-byte v25, v8, v40

    const/16 v40, 0x2d

    aput-byte v33, v8, v40

    const/16 v33, 0x2e

    const/16 v40, -0x7

    aput-byte v40, v8, v33

    const/16 v33, 0x2f

    aput-byte v18, v8, v33

    const/16 v18, 0x30

    const/16 v33, -0x73

    aput-byte v33, v8, v18

    const/16 v18, 0x31

    const/16 v33, 0x3c

    aput-byte v33, v8, v18

    const/16 v18, -0x6c

    const/16 v33, 0x32

    aput-byte v18, v8, v33

    const/16 v33, 0x33

    const/16 v40, -0x58

    aput-byte v40, v8, v33

    const/16 v33, 0x34

    const/16 v41, -0x21

    aput-byte v41, v8, v33

    const/16 v33, 0x35

    aput-byte v35, v8, v33

    const/16 v33, 0x36

    aput-byte v39, v8, v33

    const/16 v33, 0x37

    const/16 v41, -0x7f

    aput-byte v41, v8, v33

    const/16 v33, 0x38

    const/16 v41, -0x18

    aput-byte v41, v8, v33

    const/16 v33, 0x39

    const/16 v41, 0x18

    aput-byte v41, v8, v33

    const/16 v33, 0x3a

    aput-byte v18, v8, v33

    const/16 v33, 0x3b

    const/16 v41, -0x6

    aput-byte v41, v8, v33

    const/16 v33, 0x3c

    aput-byte v25, v8, v33

    const/16 v33, 0x3d

    const/16 v41, 0xb

    aput-byte v41, v8, v33

    const/16 v33, 0x3e

    const/16 v41, -0x1e

    aput-byte v41, v8, v33

    const/16 v33, 0x3f

    const/16 v41, -0x7d

    aput-byte v41, v8, v33

    const/16 v33, 0x40

    const/16 v41, -0x56

    aput-byte v41, v8, v33

    const/16 v33, 0x41

    const/16 v41, 0x17

    aput-byte v41, v8, v33

    const/16 v33, 0x42

    aput-byte v18, v8, v33

    const/16 v18, -0x68

    const/16 v33, 0x43

    aput-byte v18, v8, v33

    const/16 v41, 0x44

    const/16 v42, -0x32

    aput-byte v42, v8, v41

    const/16 v41, 0x45

    aput-byte v6, v8, v41

    const/16 v41, 0x46

    const/16 v43, -0x60

    aput-byte v43, v8, v41

    const/16 v41, 0x47

    aput-byte v42, v8, v41

    const/16 v41, 0x48

    aput-byte v22, v8, v41

    const/16 v22, 0x49

    aput-byte v27, v8, v22

    const/16 v22, 0x4a

    const/16 v41, -0x40

    aput-byte v41, v8, v22

    const/16 v22, 0x4b

    aput-byte v18, v8, v22

    const/16 v22, 0x4c

    aput-byte v25, v8, v22

    const/16 v22, 0x4d

    aput-byte v24, v8, v22

    const/16 v22, -0x5d

    const/16 v41, 0x4e

    aput-byte v22, v8, v41

    const/16 v22, 0x4f

    const/16 v43, -0x6a

    aput-byte v43, v8, v22

    const/16 v22, 0x50

    const/16 v44, -0xd

    aput-byte v44, v8, v22

    const/16 v22, 0x5b

    aput-byte v22, v8, v36

    const/16 v45, -0x6b

    aput-byte v45, v8, v21

    const/16 v45, 0x53

    const/16 v46, -0x1f

    aput-byte v46, v8, v45

    const/16 v45, 0x54

    const/16 v46, -0x9

    aput-byte v46, v8, v45

    const/16 v45, 0x55

    aput-byte v35, v8, v45

    const/16 v35, 0x56

    aput-byte v29, v8, v35

    const/16 v35, 0x57

    const/16 v45, -0x77

    aput-byte v45, v8, v35

    const/16 v35, 0x58

    const/16 v45, -0x55

    aput-byte v45, v8, v35

    aput-byte v33, v8, v28

    const/16 v35, 0x5a

    const/16 v45, -0x3d

    aput-byte v45, v8, v35

    const/16 v35, -0x4c

    aput-byte v35, v8, v22

    const/16 v35, 0x5c

    const/16 v45, -0x72

    aput-byte v45, v8, v35

    const/16 v35, 0x5d

    const/16 v45, 0x37

    aput-byte v45, v8, v35

    const/16 v35, 0x5e

    aput-byte v32, v8, v35

    const/16 v35, 0x5f

    aput-byte v43, v8, v35

    const/16 v35, 0x60

    const/16 v45, -0x46

    aput-byte v45, v8, v35

    const/16 v35, 0x61

    aput-byte v23, v8, v35

    const/16 v23, 0x62

    const/16 v35, -0x72

    aput-byte v35, v8, v23

    const/16 v23, 0x63

    aput-byte v18, v8, v23

    const/16 v23, 0x64

    const/16 v35, -0x24

    aput-byte v35, v8, v23

    const/16 v23, 0x65

    aput-byte v12, v8, v23

    const/16 v23, 0x66

    const/16 v35, -0x50

    aput-byte v35, v8, v23

    const/16 v23, 0x67

    aput-byte v20, v8, v23

    const/16 v23, 0x68

    aput-byte v32, v8, v23

    const/16 v32, 0x69

    aput-byte v33, v8, v32

    const/16 v32, 0x6a

    const/16 v33, -0x29

    aput-byte v33, v8, v32

    const/16 v32, 0x6b

    const/16 v33, -0x1f

    aput-byte v33, v8, v32

    const/16 v32, 0x6c

    const/16 v33, -0x9

    aput-byte v33, v8, v32

    const/16 v32, 0x6d

    const/16 v33, 0xe

    aput-byte v33, v8, v32

    const/16 v32, 0x6e

    aput-byte v39, v8, v32

    const/16 v32, 0x6f

    aput-byte v31, v8, v32

    const/16 v32, 0x70

    aput-byte v29, v8, v32

    const/16 v32, 0x71

    const/16 v33, 0x16

    aput-byte v33, v8, v32

    const/16 v32, 0x72

    const/16 v33, -0x47

    aput-byte v33, v8, v32

    const/16 v32, 0x73

    const/16 v33, -0x4c

    aput-byte v33, v8, v32

    const/16 v32, 0x74

    const/16 v33, -0x23

    aput-byte v33, v8, v32

    const/16 v32, 0x75

    aput-byte v19, v8, v32

    const/16 v32, 0x76

    const/16 v33, -0x65

    aput-byte v33, v8, v32

    const/16 v32, 0x77

    const/16 v33, -0x69

    aput-byte v33, v8, v32

    const/16 v32, 0x78

    const/16 v33, -0x59

    aput-byte v33, v8, v32

    const/16 v32, 0x79

    aput-byte v26, v8, v32

    const/16 v32, 0x7a

    const/16 v33, -0x6b

    aput-byte v33, v8, v32

    const/16 v32, 0x7b

    const/16 v33, -0x6

    aput-byte v33, v8, v32

    const/16 v32, 0x7c

    aput-byte v18, v8, v32

    const/16 v18, 0x7d

    aput-byte v41, v8, v18

    const/16 v18, -0x65

    const/16 v32, 0x7e

    aput-byte v18, v8, v32

    const/16 v18, 0x7f

    aput-byte v37, v8, v18

    const/16 v18, 0x80

    aput-byte v39, v8, v18

    const/16 v18, 0x81

    aput-byte v26, v8, v18

    const/16 v18, 0x82

    aput-byte v20, v8, v18

    const/16 v18, 0x83

    const/16 v33, -0x6

    aput-byte v33, v8, v18

    const/16 v18, 0x84

    aput-byte v42, v8, v18

    const/16 v18, 0x85

    aput-byte v6, v8, v18

    const/16 v18, 0x86

    aput-byte v40, v8, v18

    const/16 v18, 0x87

    aput-byte v43, v8, v18

    const/16 v18, 0x88

    const/16 v33, -0x6f

    aput-byte v33, v8, v18

    const/16 v18, 0x89

    aput-byte v19, v8, v18

    const/16 v18, 0x8a

    const/16 v19, -0x61

    aput-byte v19, v8, v18

    const/16 v18, 0x8b

    aput-byte v11, v8, v18

    const/16 v18, 0x8c

    const/16 v19, -0x33

    aput-byte v19, v8, v18

    const/16 v18, 0x8d

    aput-byte v21, v8, v18

    const/16 v18, 0x8e

    const/16 v19, -0x5b

    aput-byte v19, v8, v18

    const/16 v18, 0x8f

    aput-byte v37, v8, v18

    const/16 v18, 0x90

    aput-byte v29, v8, v18

    const/16 v18, 0x91

    aput-byte v21, v8, v18

    const/16 v18, 0x92

    aput-byte v3, v8, v18

    const/16 v18, 0x93

    aput-byte v11, v8, v18

    const/16 v11, 0x94

    const/16 v18, -0x34

    aput-byte v18, v8, v11

    const/16 v11, 0x95

    aput-byte v24, v8, v11

    const/16 v11, 0x96

    const/16 v18, -0x50

    aput-byte v18, v8, v11

    const/16 v11, 0x97

    aput-byte v43, v8, v11

    const/16 v11, 0x98

    const/16 v18, -0x56

    aput-byte v18, v8, v11

    const/16 v11, 0x99

    const/16 v18, 0x21

    aput-byte v18, v8, v11

    const/16 v11, 0x9a

    aput-byte v31, v8, v11

    const/16 v11, 0x9b

    const/16 v18, -0x4d

    aput-byte v18, v8, v11

    const/16 v11, 0x9c

    aput-byte v20, v8, v11

    const/16 v11, 0x9d

    aput-byte v26, v8, v11

    const/16 v11, 0x9e

    aput-byte v39, v8, v11

    const/16 v11, 0x9f

    aput-byte v37, v8, v11

    const/16 v11, 0xa0

    aput-byte v29, v8, v11

    new-array v11, v4, [B

    aput-byte v42, v11, v9

    aput-byte v32, v11, v6

    const/16 v18, -0x1a

    aput-byte v18, v11, v10

    const/16 v18, -0x39

    aput-byte v18, v11, v13

    aput-byte v40, v11, v14

    aput-byte v23, v11, v15

    aput-byte v38, v11, v16

    aput-byte v44, v11, v12

    invoke-static {v8, v11}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v8

    new-array v11, v13, [Ljava/lang/Object;

    aput-object v5, v11, v9

    invoke-static {v7}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v18

    aput-object v18, v11, v6

    const/16 v18, 0x64

    invoke-static/range {v18 .. v18}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v18

    aput-object v18, v11, v10

    invoke-static {v8, v11}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v8

    new-instance v11, Lorg/json/JSONObject;

    invoke-direct {v1, v8}, Lcom/github/catvod/spider/appysv2/b/U;->u(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    invoke-direct {v11, v8}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    new-array v8, v14, [B

    const/16 v18, -0x12

    aput-byte v18, v8, v9

    const/16 v18, 0x38

    aput-byte v18, v8, v6

    const/16 v18, -0x36

    aput-byte v18, v8, v10

    const/16 v18, 0x4f

    aput-byte v18, v8, v13

    new-array v3, v4, [B

    aput-byte v17, v3, v9

    aput-byte v28, v3, v6

    const/16 v18, -0x42

    aput-byte v18, v3, v10

    const/16 v18, 0x2e

    aput-byte v18, v3, v13

    const/16 v18, -0x8

    aput-byte v18, v3, v14

    const/16 v18, -0x6f

    aput-byte v18, v3, v15

    aput-byte v38, v3, v16

    const/16 v16, -0x56

    aput-byte v16, v3, v12

    invoke-static {v8, v3}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v11, v3}, Lorg/json/JSONObject;->getJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v3

    new-array v8, v14, [B

    const/16 v16, -0x4b

    aput-byte v16, v8, v9

    const/16 v16, -0x3a

    aput-byte v16, v8, v6

    aput-byte v28, v8, v10

    const/16 v16, 0x4b

    aput-byte v16, v8, v13

    new-array v12, v4, [B

    const/16 v18, -0x27

    aput-byte v18, v12, v9

    const/16 v18, -0x51

    aput-byte v18, v12, v6

    aput-byte v34, v12, v10

    const/16 v18, 0x3f

    aput-byte v18, v12, v13

    const/16 v18, -0x22

    aput-byte v18, v12, v14

    const/16 v14, -0x38

    aput-byte v14, v12, v15

    const/16 v14, 0x41

    const/4 v15, 0x6

    aput-byte v14, v12, v15

    const/16 v14, -0x17

    const/4 v15, 0x7

    aput-byte v14, v12, v15

    invoke-static {v8, v12}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v3, v8}, Lorg/json/JSONObject;->getJSONArray(Ljava/lang/String;)Lorg/json/JSONArray;

    move-result-object v3

    const/4 v8, 0x0

    :goto_41d
    invoke-virtual {v3}, Lorg/json/JSONArray;->length()I

    move-result v12

    if-ge v8, v12, :cond_469

    invoke-virtual {v3, v8}, Lorg/json/JSONArray;->getJSONObject(I)Lorg/json/JSONObject;

    move-result-object v12

    new-array v14, v13, [B

    const/16 v15, -0x1d

    aput-byte v15, v14, v9

    const/16 v15, 0x2d

    aput-byte v15, v14, v6

    const/16 v15, 0x28

    aput-byte v15, v14, v10

    new-array v15, v4, [B

    aput-byte v30, v15, v9

    const/16 v18, 0x44

    aput-byte v18, v15, v6

    const/16 v18, 0x4c

    aput-byte v18, v15, v10

    const/16 v18, -0x44

    aput-byte v18, v15, v13

    const/16 v18, 0x4

    aput-byte v30, v15, v18

    const/16 v18, -0x21

    const/16 v19, 0x5

    aput-byte v18, v15, v19

    const/16 v18, 0x7b

    const/16 v19, 0x6

    aput-byte v18, v15, v19

    const/16 v16, 0x7

    const/16 v18, -0x6d

    aput-byte v18, v15, v16

    invoke-static {v14, v15}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v14

    invoke-virtual {v12, v14}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v12

    invoke-virtual {v2, v12}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/lit8 v8, v8, 0x1

    goto :goto_41d

    :cond_469
    new-array v3, v4, [B

    const/16 v8, -0x49

    aput-byte v8, v3, v9

    aput-byte v44, v3, v6

    const/16 v8, 0x56

    aput-byte v8, v3, v10

    aput-byte v30, v3, v13

    const/4 v8, 0x4

    aput-byte v34, v3, v8

    const/16 v8, -0x33

    const/4 v12, 0x5

    aput-byte v8, v3, v12

    const/16 v8, 0x1e

    const/4 v12, 0x6

    aput-byte v8, v3, v12

    const/16 v8, -0x66

    const/4 v12, 0x7

    aput-byte v8, v3, v12

    new-array v8, v4, [B

    const/16 v12, -0x26

    aput-byte v12, v8, v9

    aput-byte v43, v8, v6

    const/16 v12, 0x22

    aput-byte v12, v8, v10

    const/16 v12, -0x1c

    aput-byte v12, v8, v13

    const/4 v12, 0x4

    aput-byte v41, v8, v12

    const/16 v12, -0x54

    const/4 v14, 0x5

    aput-byte v12, v8, v14

    const/16 v12, 0x6a

    const/4 v14, 0x6

    aput-byte v12, v8, v14

    const/4 v12, -0x5

    const/4 v14, 0x7

    aput-byte v12, v8, v14

    invoke-static {v3, v8}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v11, v3}, Lorg/json/JSONObject;->getJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v3

    const/4 v8, 0x5

    new-array v8, v8, [B

    aput-byte v27, v8, v9

    const/16 v11, 0x77

    aput-byte v11, v8, v6

    const/16 v11, -0x2d

    aput-byte v11, v8, v10

    aput-byte v23, v8, v13

    const/16 v11, 0x15

    const/4 v12, 0x4

    aput-byte v11, v8, v12

    new-array v11, v4, [B

    aput-byte v21, v11, v9

    aput-byte v12, v11, v6

    const/16 v14, -0x46

    aput-byte v14, v11, v10

    const/16 v14, 0x12

    aput-byte v14, v11, v13

    const/16 v14, 0x70

    aput-byte v14, v11, v12

    const/16 v12, 0x35

    const/4 v14, 0x5

    aput-byte v12, v11, v14

    const/4 v12, 0x6

    aput-byte v26, v11, v12

    const/16 v14, -0x7e

    const/4 v15, 0x7

    aput-byte v14, v11, v15

    invoke-static {v8, v11}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v3, v8}, Lorg/json/JSONObject;->getInt(Ljava/lang/String;)I

    move-result v8

    new-array v11, v12, [B

    const/16 v12, 0x66

    aput-byte v12, v11, v9

    const/16 v12, -0x45

    aput-byte v12, v11, v6

    const/16 v12, -0x67

    aput-byte v12, v11, v10

    const/16 v12, 0x24

    aput-byte v12, v11, v13

    const/16 v12, -0x75

    const/4 v14, 0x4

    aput-byte v12, v11, v14

    const/16 v12, 0x6d

    const/4 v14, 0x5

    aput-byte v12, v11, v14

    new-array v12, v4, [B

    const/16 v14, 0x39

    aput-byte v14, v12, v9

    aput-byte v25, v12, v6

    const/16 v14, -0xa

    aput-byte v14, v12, v10

    aput-byte v36, v12, v13

    const/16 v14, -0x1b

    const/4 v15, 0x4

    aput-byte v14, v12, v15

    const/16 v14, 0x19

    const/4 v15, 0x5

    aput-byte v14, v12, v15

    const/16 v14, 0xf

    const/4 v15, 0x6

    aput-byte v14, v12, v15

    const/16 v14, -0x2c

    const/4 v15, 0x7

    aput-byte v14, v12, v15

    invoke-static {v11, v12}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v11

    invoke-virtual {v3, v11}, Lorg/json/JSONObject;->getInt(Ljava/lang/String;)I

    move-result v11

    if-ne v8, v11, :cond_585

    const/4 v8, 0x6

    new-array v8, v8, [B

    aput-byte v22, v8, v9

    const/16 v11, -0x17

    aput-byte v11, v8, v6

    const/16 v11, 0x31

    aput-byte v11, v8, v10

    const/16 v11, -0x3d

    aput-byte v11, v8, v13

    const/16 v11, -0x19

    const/4 v12, 0x4

    aput-byte v11, v8, v12

    const/4 v11, 0x5

    const/4 v14, 0x7

    aput-byte v14, v8, v11

    new-array v11, v4, [B

    aput-byte v12, v11, v9

    aput-byte v17, v11, v6

    const/16 v14, 0x5e

    aput-byte v14, v11, v10

    const/16 v14, -0x4a

    aput-byte v14, v11, v13

    const/16 v14, -0x77

    aput-byte v14, v11, v12

    const/16 v12, 0x73

    const/4 v14, 0x5

    aput-byte v12, v11, v14

    const/16 v12, -0x23

    const/4 v14, 0x6

    aput-byte v12, v11, v14

    const/4 v12, 0x7

    aput-byte v32, v11, v12

    invoke-static {v8, v11}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v3, v8}, Lorg/json/JSONObject;->getInt(Ljava/lang/String;)I

    move-result v3
    :try_end_576
    .catch Ljava/lang/Exception; {:try_start_f .. :try_end_576} :catch_5e5

    if-nez v3, :cond_579

    goto :goto_585

    :cond_579
    add-int/lit8 v7, v7, 0x1

    const/16 v3, 0x15

    const/4 v14, 0x4

    const/4 v15, 0x5

    const/16 v11, -0x49

    const/16 v16, 0x6

    goto/16 :goto_53

    :cond_585
    :goto_585
    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v3

    if-nez v3, :cond_58c

    goto :goto_5fa

    :cond_58c
    invoke-interface {v0, v9}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    invoke-virtual {v2}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v3

    :cond_596
    :goto_596
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    if-eqz v4, :cond_5ac

    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/lang/String;

    invoke-static {v0, v4}, Lcom/github/catvod/spider/appysv2/b/u;->c(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_596

    invoke-interface {v3}, Ljava/util/Iterator;->remove()V

    goto :goto_596

    :cond_5ac
    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v0

    int-to-double v3, v0

    const/16 v5, 0x32

    int-to-double v5, v5

    invoke-static {v3, v4}, Ljava/lang/Double;->isNaN(D)Z

    invoke-static {v5, v6}, Ljava/lang/Double;->isNaN(D)Z

    invoke-static {v3, v4}, Ljava/lang/Double;->isNaN(D)Z

    invoke-static {v5, v6}, Ljava/lang/Double;->isNaN(D)Z

    invoke-static {v3, v4}, Ljava/lang/Double;->isNaN(D)Z

    invoke-static {v5, v6}, Ljava/lang/Double;->isNaN(D)Z

    div-double/2addr v3, v5

    invoke-static {v3, v4}, Ljava/lang/Math;->ceil(D)D

    move-result-wide v3

    double-to-int v3, v3

    :goto_5cc
    if-ge v9, v3, :cond_5fa

    mul-int/lit8 v4, v9, 0x32

    add-int/lit8 v5, v4, 0x32

    invoke-static {v5, v0}, Ljava/lang/Math;->min(II)I

    move-result v5

    new-instance v6, Ljava/util/ArrayList;

    invoke-virtual {v2, v4, v5}, Ljava/util/ArrayList;->subList(II)Ljava/util/List;

    move-result-object v4

    invoke-direct {v6, v4}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    invoke-direct {v1, v6}, Lcom/github/catvod/spider/appysv2/b/U;->n(Ljava/util/List;)Z

    add-int/lit8 v9, v9, 0x1

    goto :goto_5cc

    :catch_5e5
    move-exception v0

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/16 v3, 0x15

    new-array v3, v3, [B

    fill-array-data v3, :array_5fc

    new-array v4, v4, [B

    fill-array-data v4, :array_60c

    .line 2
    invoke-static {v3, v4, v2, v0}, Lcom/github/catvod/spider/appysv2/b/y;->b([B[BLjava/lang/StringBuilder;Ljava/lang/Exception;)V

    :cond_5fa
    :goto_5fa
    return-void

    nop

    :array_5fc
    .array-data 1
        0x78t
        -0x20t
        0x44t
        0x6t
        0x61t
        0x69t
        -0x5dt
        -0x35t
        0x78t
        -0x14t
        0x5at
        0x43t
        0x79t
        0x65t
        -0x10t
        -0x31t
        0x3ct
        -0x20t
        0x5at
        0x11t
        0x2ft
    .end array-data

    nop

    :array_60c
    .array-data 1
        0x1ct
        -0x7bt
        0x28t
        0x63t
        0x15t
        0xct
        -0x7dt
        -0x45t
    .end array-data
.end method

.method private s()V
    .registers 2

    :try_start_0
    iget-object v0, p0, Lcom/github/catvod/spider/appysv2/b/U;->f:Landroid/app/AlertDialog;

    if-eqz v0, :cond_7

    invoke-virtual {v0}, Landroid/app/Dialog;->dismiss()V
    :try_end_7
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_7} :catch_7

    :catch_7
    :cond_7
    return-void
.end method

.method public static t()Lcom/github/catvod/spider/appysv2/b/U;
    .registers 1

    sget-object v0, Lcom/github/catvod/spider/appysv2/b/T;->a:Lcom/github/catvod/spider/appysv2/b/U;

    return-object v0
.end method

.method private u(Ljava/lang/String;)Ljava/lang/String;
    .registers 3

    invoke-direct {p0}, Lcom/github/catvod/spider/appysv2/b/U;->y()Ljava/util/Map;

    move-result-object v0

    invoke-static {p1, v0}, Lcom/github/catvod/spider/appysv2/n/c;->m(Ljava/lang/String;Ljava/util/Map;)Ljava/lang/String;

    move-result-object p1

    return-object p1
.end method

.method private v()Ljava/lang/String;
    .registers 27

    move-object/from16 v1, p0

    const/4 v0, 0x6

    new-array v2, v0, [B

    fill-array-data v2, :array_886

    const/16 v3, 0x8

    new-array v4, v3, [B

    fill-array-data v4, :array_88e

    invoke-static {v2, v4}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v2

    const/16 v4, 0x9f

    const/4 v5, 0x1

    const/4 v6, 0x0

    :try_start_17
    new-array v4, v4, [B

    const/16 v7, -0x4c

    aput-byte v7, v4, v6

    const/16 v7, -0x1d

    aput-byte v7, v4, v5

    const/16 v7, 0x37

    const/4 v8, 0x2

    aput-byte v7, v4, v8

    const/16 v9, -0xc

    const/4 v10, 0x3

    aput-byte v9, v4, v10

    const/16 v9, 0x6d

    const/4 v11, 0x4

    aput-byte v9, v4, v11

    const/16 v9, -0x38

    const/4 v12, 0x5

    aput-byte v9, v4, v12

    const/16 v13, -0xa

    aput-byte v13, v4, v0

    const/16 v13, 0x23

    const/4 v14, 0x7

    aput-byte v13, v4, v14

    const/16 v14, -0x54

    aput-byte v14, v4, v3

    const/16 v14, -0xc

    const/16 v15, 0x9

    aput-byte v14, v4, v15

    const/16 v14, 0xa

    const/16 v15, 0x6e

    aput-byte v15, v4, v14

    const/16 v14, 0xb

    const/16 v15, -0x1b

    aput-byte v15, v4, v14

    const/16 v14, 0xc

    const/16 v15, 0x6e

    aput-byte v15, v4, v14

    const/16 v14, 0xd

    const/16 v15, -0x65

    aput-byte v15, v4, v14

    const/16 v14, 0xe

    const/16 v15, -0x9

    aput-byte v15, v4, v14

    const/16 v14, 0xf

    const/16 v15, 0x79

    aput-byte v15, v4, v14

    const/16 v14, 0x10

    const/16 v15, -0x41

    aput-byte v15, v4, v14

    const/16 v14, 0x11

    const/16 v15, -0x47

    aput-byte v15, v4, v14

    const/16 v14, 0x12

    const/16 v15, 0x20

    aput-byte v15, v4, v14

    const/16 v14, 0x13

    const/16 v15, -0x16

    aput-byte v15, v4, v14

    const/16 v14, 0x14

    const/16 v15, 0x31

    aput-byte v15, v4, v14

    const/16 v14, 0x15

    const/16 v16, -0x3d

    aput-byte v16, v4, v14

    const/16 v14, 0x16

    const/16 v16, -0xa

    aput-byte v16, v4, v14

    const/16 v14, 0x17

    const/16 v16, 0x6f

    aput-byte v16, v4, v14

    const/16 v14, 0x18

    const/16 v16, -0x50

    aput-byte v16, v4, v14

    const/4 v14, -0x8

    const/16 v16, 0x19

    aput-byte v14, v4, v16

    const/16 v14, 0x1a

    const/16 v17, 0x36

    aput-byte v17, v4, v14

    const/16 v14, 0x1b

    const/16 v18, -0x20

    aput-byte v18, v4, v14

    const/16 v14, 0x7a

    const/16 v18, 0x1c

    aput-byte v14, v4, v18

    const/16 v19, 0x1d

    const/16 v20, -0x80

    aput-byte v20, v4, v19

    const/16 v19, 0x1e

    const/16 v20, -0x50

    aput-byte v20, v4, v19

    const/16 v19, 0x1f

    aput-byte v14, v4, v19

    const/16 v19, 0x20

    const/16 v20, -0x47

    aput-byte v20, v4, v19

    const/16 v19, 0x21

    const/16 v20, -0x48

    aput-byte v20, v4, v19

    const/16 v19, 0x22

    const/16 v20, 0x25

    aput-byte v20, v4, v19

    const/16 v19, -0x13

    aput-byte v19, v4, v13

    const/16 v13, 0x24

    const/16 v19, 0x72

    aput-byte v19, v4, v13

    const/16 v13, 0x25

    const/16 v19, -0x69

    aput-byte v19, v4, v13

    const/16 v13, 0x26

    const/16 v19, -0xa

    aput-byte v19, v4, v13

    const/16 v13, 0x27

    const/16 v19, 0x7f

    aput-byte v19, v4, v13

    const/16 v13, 0x28

    const/16 v19, -0x4d

    aput-byte v19, v4, v13

    const/16 v13, 0x29

    const/16 v19, -0x1b

    aput-byte v19, v4, v13

    const/16 v13, 0x2a

    aput-byte v7, v4, v13

    const/16 v13, 0x2b

    const/16 v19, -0x45

    aput-byte v19, v4, v13

    const/16 v13, 0x2c

    const/16 v19, 0x6e

    aput-byte v19, v4, v13

    const/16 v13, 0x2d

    const/16 v19, -0x80

    aput-byte v19, v4, v13

    const/16 v13, 0x2e

    const/16 v19, -0x1c

    aput-byte v19, v4, v13

    const/16 v13, 0x2f

    const/16 v19, 0x59

    aput-byte v19, v4, v13

    const/16 v13, 0x30

    const/16 v19, -0x61

    aput-byte v19, v4, v13

    const/16 v13, -0x2b

    aput-byte v13, v4, v15

    const/16 v13, 0x32

    aput-byte v15, v4, v13

    const/16 v13, -0x15

    const/16 v19, 0x33

    aput-byte v13, v4, v19

    const/16 v13, 0x34

    const/16 v20, 0x69

    aput-byte v20, v4, v13

    const/16 v13, 0x35

    const/16 v20, -0x7f

    aput-byte v20, v4, v13

    const/16 v13, -0x44

    aput-byte v13, v4, v17

    const/16 v13, 0x7e

    aput-byte v13, v4, v7

    const/16 v13, 0x38

    const/16 v21, -0x6

    aput-byte v21, v4, v13

    const/16 v13, 0x39

    const/16 v21, -0xf

    aput-byte v21, v4, v13

    const/16 v13, 0x3a

    aput-byte v15, v4, v13

    const/16 v13, 0x3b

    const/16 v21, -0x47

    aput-byte v21, v4, v13

    const/16 v13, 0x3c

    const/16 v21, 0x6e

    aput-byte v21, v4, v13

    const/16 v13, 0x3d

    const/16 v21, -0x6f

    aput-byte v21, v4, v13

    const/16 v13, 0x3e

    const/16 v21, -0x1

    aput-byte v21, v4, v13

    const/16 v13, 0x3f

    const/16 v21, 0x7c

    aput-byte v21, v4, v13

    const/16 v13, 0x40

    const/16 v21, -0x48

    aput-byte v21, v4, v13

    const/4 v13, -0x2

    const/16 v21, 0x41

    aput-byte v13, v4, v21

    const/16 v13, 0x42

    aput-byte v15, v4, v13

    const/16 v13, 0x43

    const/16 v22, -0x25

    aput-byte v22, v4, v13

    const/16 v13, 0x44

    const/16 v22, 0x78

    aput-byte v22, v4, v13

    const/16 v13, 0x45

    const/16 v22, -0x65

    aput-byte v22, v4, v13

    const/16 v13, 0x46

    const/16 v22, -0x43

    aput-byte v22, v4, v13

    const/16 v13, 0x47

    aput-byte v15, v4, v13

    const/16 v13, 0x48

    const/16 v22, -0x14

    aput-byte v22, v4, v13

    const/16 v13, 0x49

    const/16 v22, -0x4f

    aput-byte v22, v4, v13

    const/16 v13, 0x4a

    aput-byte v18, v4, v13

    const/16 v13, 0x4b

    const/16 v22, -0xc

    aput-byte v22, v4, v13

    const/16 v13, 0x4c

    const/16 v22, 0x7f

    aput-byte v22, v4, v13

    const/16 v13, 0x4d

    const/16 v22, -0x6b

    aput-byte v22, v4, v13

    const/16 v13, 0x4e

    const/16 v22, -0x44

    aput-byte v22, v4, v13

    const/16 v13, 0x4f

    aput-byte v15, v4, v13

    const/16 v13, 0x50

    const/16 v22, -0x13

    aput-byte v22, v4, v13

    const/16 v13, 0x51

    const/16 v22, -0x4f

    aput-byte v22, v4, v13

    const/16 v13, 0x52

    aput-byte v18, v4, v13

    const/16 v13, 0x53

    const/16 v22, -0x9

    aput-byte v22, v4, v13

    const/16 v13, 0x54

    const/16 v22, 0x77

    aput-byte v22, v4, v13

    const/16 v13, 0x55

    const/16 v22, -0x78

    aput-byte v22, v4, v13

    const/16 v13, 0x56

    const/16 v22, -0x44

    aput-byte v22, v4, v13

    const/16 v13, 0x57

    aput-byte v15, v4, v13

    const/16 v13, 0x58

    const/16 v22, -0x17

    aput-byte v22, v4, v13

    const/16 v13, 0x59

    const/16 v22, -0x59

    aput-byte v22, v4, v13

    const/16 v13, 0x5a

    const/16 v22, 0x65

    aput-byte v22, v4, v13

    const/16 v13, 0x5b

    const/16 v22, -0x25

    aput-byte v22, v4, v13

    const/16 v13, 0x5c

    const/16 v22, 0x78

    aput-byte v22, v4, v13

    const/16 v13, 0x5d

    const/16 v22, -0x69

    aput-byte v22, v4, v13

    const/16 v13, 0x5e

    const/16 v22, -0x53

    aput-byte v22, v4, v13

    const/16 v13, 0x5f

    const/16 v22, 0x6f

    aput-byte v22, v4, v13

    const/16 v13, 0x60

    const/16 v22, -0x4c

    aput-byte v22, v4, v13

    const/16 v13, 0x61

    aput-byte v9, v4, v13

    const/16 v9, 0x62

    aput-byte v7, v4, v9

    const/16 v7, 0x63

    const/16 v9, -0x15

    aput-byte v9, v4, v7

    const/16 v7, 0x64

    const/16 v9, 0x6a

    aput-byte v9, v4, v7

    const/16 v7, 0x65

    const/16 v9, -0x6d

    aput-byte v9, v4, v7

    const/16 v7, 0x66

    const/16 v9, -0x4b

    aput-byte v9, v4, v7

    const/16 v7, 0x67

    aput-byte v15, v4, v7

    const/16 v7, 0x68

    const/16 v9, -0x13

    aput-byte v9, v4, v7

    const/16 v7, 0x69

    const/16 v9, -0x4f

    aput-byte v9, v4, v7

    const/16 v7, 0x6a

    aput-byte v18, v4, v7

    const/16 v7, 0x6b

    const/16 v9, -0x1e

    aput-byte v9, v4, v7

    const/16 v7, 0x6c

    const/16 v9, 0x7b

    aput-byte v9, v4, v7

    const/16 v7, 0x6d

    const/16 v9, -0x7a

    aput-byte v9, v4, v7

    const/16 v7, 0x6e

    const/16 v9, -0x46

    aput-byte v9, v4, v7

    const/16 v7, 0x6f

    const/16 v13, 0x64

    aput-byte v13, v4, v7

    const/16 v7, 0x70

    const/16 v13, -0x7d

    aput-byte v13, v4, v7

    const/16 v7, 0x71

    const/16 v13, -0x1c

    aput-byte v13, v4, v7

    const/16 v7, 0x72

    aput-byte v17, v4, v7

    const/16 v7, 0x73

    const/16 v13, -0x1a

    aput-byte v13, v4, v7

    const/16 v7, 0x74

    aput-byte v21, v4, v7

    const/16 v7, 0x75

    const/16 v13, -0x6a

    aput-byte v13, v4, v7

    const/16 v7, 0x76

    const/16 v13, -0x50

    aput-byte v13, v4, v7

    const/16 v7, 0x77

    const/16 v13, 0x7e

    aput-byte v13, v4, v7

    const/16 v7, 0x78

    const/16 v13, -0x51

    aput-byte v13, v4, v7

    const/16 v7, 0x79

    const/16 v13, -0x56

    aput-byte v13, v4, v7

    const/16 v7, 0x73

    aput-byte v7, v4, v14

    const/16 v7, 0x7b

    const/16 v13, -0x5e

    aput-byte v13, v4, v7

    const/16 v7, 0x7c

    aput-byte v21, v4, v7

    const/16 v7, 0x7d

    aput-byte v20, v4, v7

    const/16 v7, 0x7e

    const/16 v13, -0x4a

    aput-byte v13, v4, v7

    const/16 v7, 0x7f

    const/16 v13, 0x7e

    aput-byte v13, v4, v7

    const/16 v7, 0x80

    const/16 v13, -0x58

    aput-byte v13, v4, v7

    const/16 v7, 0x81

    const/16 v13, -0x56

    aput-byte v13, v4, v7

    const/16 v7, 0x82

    const/16 v13, 0x25

    aput-byte v13, v4, v7

    const/16 v7, 0x83

    const/16 v13, -0x13

    aput-byte v13, v4, v7

    const/16 v7, 0x84

    const/16 v13, 0x72

    aput-byte v13, v4, v7

    const/16 v7, 0x85

    const/16 v13, -0x69

    aput-byte v13, v4, v7

    const/16 v7, 0x86

    const/16 v13, -0x7a

    aput-byte v13, v4, v7

    const/16 v7, 0x87

    const/16 v13, 0x78

    aput-byte v13, v4, v7

    const/16 v7, 0x88

    const/16 v13, -0x5b

    aput-byte v13, v4, v7

    const/16 v7, 0x89

    const/16 v13, -0x19

    aput-byte v13, v4, v7

    const/16 v7, 0x8a

    const/16 v13, 0x26

    aput-byte v13, v4, v7

    const/16 v7, 0x8b

    const/16 v13, -0x42

    aput-byte v13, v4, v7

    const/16 v7, 0x8c

    const/16 v13, 0x7f

    aput-byte v13, v4, v7

    const/16 v7, 0x8d

    aput-byte v20, v4, v7

    const/16 v7, 0x8e

    aput-byte v9, v4, v7

    const/16 v7, 0x8f

    const/16 v13, 0x20

    aput-byte v13, v4, v7

    const/16 v7, 0x90

    const/16 v13, -0x57

    aput-byte v13, v4, v7

    const/16 v7, 0x91

    const/16 v13, -0x19

    aput-byte v13, v4, v7

    const/16 v7, 0x92

    const/16 v13, 0x27

    aput-byte v13, v4, v7

    const/16 v7, 0x93

    const/16 v13, -0x1b

    aput-byte v13, v4, v7

    const/16 v7, 0x94

    const/16 v13, 0x6a

    aput-byte v13, v4, v7

    const/16 v7, 0x95

    const/16 v13, -0x69

    aput-byte v13, v4, v7

    const/16 v7, 0x96

    const/16 v13, -0x43

    aput-byte v13, v4, v7

    const/16 v7, 0x97

    const/16 v13, 0x53

    aput-byte v13, v4, v7

    const/16 v7, 0x98

    const/16 v13, -0x43

    aput-byte v13, v4, v7

    const/16 v7, 0x99

    const/16 v13, -0x1d

    aput-byte v13, v4, v7

    const/16 v7, 0x9a

    const/16 v13, 0x79

    aput-byte v13, v4, v7

    const/16 v7, 0x9b

    const/16 v13, -0x20

    aput-byte v13, v4, v7

    const/16 v7, 0x9c

    const/16 v13, 0x7b

    aput-byte v13, v4, v7

    const/16 v7, 0x9d

    aput-byte v20, v4, v7

    const/16 v7, 0x9e

    aput-byte v9, v4, v7

    new-array v7, v3, [B

    const/16 v13, -0x24

    aput-byte v13, v7, v6

    const/16 v13, -0x69

    aput-byte v13, v7, v5

    const/16 v13, 0x43

    aput-byte v13, v7, v8

    const/16 v13, -0x7c

    aput-byte v13, v7, v10

    const/16 v13, 0x1e

    aput-byte v13, v7, v11

    const/16 v13, -0xe

    aput-byte v13, v7, v12

    const/16 v13, -0x27

    aput-byte v13, v7, v0

    const/16 v13, 0xc

    const/4 v14, 0x7

    aput-byte v13, v7, v14

    invoke-static {v4, v7}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v4

    new-instance v7, Lorg/json/JSONObject;

    invoke-direct {v1, v4}, Lcom/github/catvod/spider/appysv2/b/U;->u(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-direct {v7, v4}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    new-array v4, v11, [B

    const/16 v13, -0x48

    aput-byte v13, v4, v6

    const/16 v13, 0x3e

    aput-byte v13, v4, v5

    const/16 v13, 0x5a

    aput-byte v13, v4, v8

    const/16 v13, 0x20

    aput-byte v13, v4, v10

    new-array v13, v3, [B

    const/16 v14, -0x24

    aput-byte v14, v13, v6

    const/16 v14, 0x5f

    aput-byte v14, v13, v5

    const/16 v14, 0x2e

    aput-byte v14, v13, v8

    aput-byte v21, v13, v10

    const/4 v14, -0x6

    aput-byte v14, v13, v11

    const/16 v14, -0x5f

    aput-byte v14, v13, v12

    aput-byte v12, v13, v0

    const/16 v14, -0x2d

    const/16 v22, 0x7

    aput-byte v14, v13, v22

    invoke-static {v4, v13}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v7, v4}, Lorg/json/JSONObject;->getJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v4

    new-array v7, v11, [B

    const/16 v13, -0x73

    aput-byte v13, v7, v6

    const/16 v13, -0x15

    aput-byte v13, v7, v5

    const/16 v13, -0x34

    aput-byte v13, v7, v8

    aput-byte v20, v7, v10

    new-array v13, v3, [B

    const/16 v14, -0x1f

    aput-byte v14, v13, v6

    const/16 v14, -0x7e

    aput-byte v14, v13, v5

    const/16 v14, -0x41

    aput-byte v14, v13, v8

    const/16 v14, -0xb

    aput-byte v14, v13, v10

    const/16 v14, 0x4a

    aput-byte v14, v13, v11

    const/16 v14, 0x77

    aput-byte v14, v13, v12

    const/16 v14, 0x65

    aput-byte v14, v13, v0

    const/4 v14, -0x6

    const/16 v22, 0x7

    aput-byte v14, v13, v22

    invoke-static {v7, v13}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v4, v7}, Lorg/json/JSONObject;->getJSONArray(Ljava/lang/String;)Lorg/json/JSONArray;

    move-result-object v4

    const-string v7, ""

    const/4 v13, 0x0

    :goto_435
    invoke-virtual {v4}, Lorg/json/JSONArray;->length()I

    move-result v14

    if-ge v13, v14, :cond_512

    invoke-virtual {v4, v13}, Lorg/json/JSONArray;->get(I)Ljava/lang/Object;

    move-result-object v14

    check-cast v14, Lorg/json/JSONObject;

    new-array v15, v10, [B

    const/16 v23, 0x6b

    aput-byte v23, v15, v6

    aput-byte v18, v15, v5

    const/16 v23, -0x68

    aput-byte v23, v15, v8

    new-array v9, v3, [B

    const/16 v24, 0xf

    aput-byte v24, v9, v6

    const/16 v24, 0x75

    aput-byte v24, v9, v5

    const/16 v24, -0x16

    aput-byte v24, v9, v8

    const/16 v24, 0x62

    aput-byte v24, v9, v10

    const/16 v24, 0x55

    aput-byte v24, v9, v11

    const/16 v24, -0x5d

    aput-byte v24, v9, v12

    const/16 v24, -0x48

    aput-byte v24, v9, v0

    const/16 v24, -0x34

    const/16 v25, 0x7

    aput-byte v24, v9, v25

    invoke-static {v15, v9}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v14, v9}, Lorg/json/JSONObject;->getBoolean(Ljava/lang/String;)Z

    move-result v9

    if-eqz v9, :cond_50a

    const/16 v9, 0x9

    new-array v9, v9, [B

    const/16 v15, 0x13

    aput-byte v15, v9, v6

    const/16 v15, -0x42

    aput-byte v15, v9, v5

    aput-byte v19, v9, v8

    const/16 v15, 0x39

    aput-byte v15, v9, v10

    const/16 v15, -0x61

    aput-byte v15, v9, v11

    const/16 v15, 0x45

    aput-byte v15, v9, v12

    const/16 v15, -0x37

    aput-byte v15, v9, v0

    const/16 v15, -0x38

    const/16 v24, 0x7

    aput-byte v15, v9, v24

    const/16 v15, 0x10

    aput-byte v15, v9, v3

    new-array v15, v3, [B

    const/16 v24, 0x75

    aput-byte v24, v15, v6

    const/16 v24, -0x29

    aput-byte v24, v15, v5

    const/16 v24, 0x5f

    aput-byte v24, v15, v8

    const/16 v24, 0x5c

    aput-byte v24, v15, v10

    const/16 v24, -0x40

    aput-byte v24, v15, v11

    const/16 v24, 0x2b

    aput-byte v24, v15, v12

    const/16 v24, -0x58

    aput-byte v24, v15, v0

    const/16 v24, -0x5b

    const/16 v25, 0x7

    aput-byte v24, v15, v25

    invoke-static {v9, v15}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v14, v9}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v9, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v9

    if-eqz v9, :cond_50a

    new-array v4, v10, [B

    const/16 v7, 0x21

    aput-byte v7, v4, v6

    aput-byte v6, v4, v5

    const/4 v7, -0x5

    aput-byte v7, v4, v8

    new-array v7, v3, [B

    const/16 v9, 0x47

    aput-byte v9, v7, v6

    const/16 v9, 0x69

    aput-byte v9, v7, v5

    const/16 v9, -0x61

    aput-byte v9, v7, v8

    const/4 v9, -0x8

    aput-byte v9, v7, v10

    const/16 v9, 0x1d

    aput-byte v9, v7, v11

    const/4 v9, -0x2

    aput-byte v9, v7, v12

    const/16 v9, -0x46

    aput-byte v9, v7, v0

    const/16 v9, 0xb

    const/4 v13, 0x7

    aput-byte v9, v7, v13

    invoke-static {v4, v7}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v14, v4}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    goto :goto_512

    :cond_50a
    add-int/lit8 v13, v13, 0x1

    const/16 v9, -0x46

    const/16 v15, 0x31

    goto/16 :goto_435

    :cond_512
    :goto_512
    const-string v4, ""

    invoke-virtual {v7, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-nez v4, :cond_51b

    return-object v7

    :cond_51b
    const/16 v4, 0x39

    new-array v4, v4, [B

    const/16 v7, -0x2e

    aput-byte v7, v4, v6

    const/16 v7, -0x78

    aput-byte v7, v4, v5

    const/16 v7, -0x4d

    aput-byte v7, v4, v8

    const/16 v7, 0x71

    aput-byte v7, v4, v10

    const/16 v7, 0x6a

    aput-byte v7, v4, v11

    const/16 v7, -0x52

    aput-byte v7, v4, v12

    aput-byte v19, v4, v0

    const/16 v7, 0x43

    const/4 v9, 0x7

    aput-byte v7, v4, v9

    const/16 v7, -0x36

    aput-byte v7, v4, v3

    const/16 v7, -0x61

    const/16 v9, 0x9

    aput-byte v7, v4, v9

    const/16 v7, 0xa

    const/16 v9, -0x16

    aput-byte v9, v4, v7

    const/16 v7, 0xb

    const/16 v9, 0x60

    aput-byte v9, v4, v7

    const/16 v7, 0xc

    const/16 v9, 0x69

    aput-byte v9, v4, v7

    const/16 v7, 0xd

    const/4 v9, -0x3

    aput-byte v9, v4, v7

    const/16 v7, 0xe

    const/16 v9, 0x32

    aput-byte v9, v4, v7

    const/16 v7, 0xf

    aput-byte v16, v4, v7

    const/16 v7, 0x10

    const/16 v9, -0x27

    aput-byte v9, v4, v7

    const/16 v7, 0x11

    const/16 v9, -0x2e

    aput-byte v9, v4, v7

    const/16 v7, 0x12

    const/16 v9, -0x5c

    aput-byte v9, v4, v7

    const/16 v7, 0x13

    const/16 v9, 0x6f

    aput-byte v9, v4, v7

    const/16 v7, 0x14

    aput-byte v17, v4, v7

    const/16 v7, 0x15

    const/16 v9, -0x5b

    aput-byte v9, v4, v7

    const/16 v7, 0x16

    aput-byte v19, v4, v7

    const/16 v7, 0x17

    const/16 v9, 0xf

    aput-byte v9, v4, v7

    const/16 v7, 0x18

    const/16 v9, -0x2a

    aput-byte v9, v4, v7

    const/16 v7, -0x6d

    aput-byte v7, v4, v16

    const/16 v7, 0x1a

    const/16 v9, -0x4e

    aput-byte v9, v4, v7

    const/16 v7, 0x1b

    const/16 v9, 0x65

    aput-byte v9, v4, v7

    const/16 v7, 0x7d

    aput-byte v7, v4, v18

    const/16 v7, 0x1d

    const/16 v9, -0x1a

    aput-byte v9, v4, v7

    const/16 v7, 0x1e

    const/16 v9, 0x75

    aput-byte v9, v4, v7

    const/16 v7, 0x1f

    const/16 v9, 0x1a

    aput-byte v9, v4, v7

    const/16 v7, 0x20

    const/16 v9, -0x21

    aput-byte v9, v4, v7

    const/16 v7, 0x21

    const/16 v9, -0x2d

    aput-byte v9, v4, v7

    const/16 v7, 0x22

    const/16 v9, -0x5f

    aput-byte v9, v4, v7

    const/16 v7, 0x68

    const/16 v9, 0x23

    aput-byte v7, v4, v9

    const/16 v7, 0x24

    const/16 v13, 0x75

    aput-byte v13, v4, v7

    const/16 v7, 0x25

    const/16 v13, -0xf

    aput-byte v13, v4, v7

    const/16 v7, 0x26

    aput-byte v9, v4, v7

    const/16 v7, 0x27

    aput-byte v18, v4, v7

    const/16 v7, 0x28

    const/16 v9, -0x38

    aput-byte v9, v4, v7

    const/16 v7, 0x29

    const/16 v9, -0x3f

    aput-byte v9, v4, v7

    const/16 v7, 0x2a

    const/16 v9, -0x6e

    aput-byte v9, v4, v7

    const/16 v7, 0x2b

    const/16 v9, 0x42

    aput-byte v9, v4, v7

    const/16 v7, 0x2c

    const/16 v9, 0x5b

    aput-byte v9, v4, v7

    const/16 v7, 0x2d

    const/16 v9, -0x1a

    aput-byte v9, v4, v7

    const/16 v7, 0x2e

    const/16 v9, 0x73

    aput-byte v9, v4, v7

    const/16 v7, 0x2f

    const/16 v9, 0x1b

    aput-byte v9, v4, v7

    const/16 v7, 0x30

    const/16 v9, -0x37

    aput-byte v9, v4, v7

    const/16 v7, -0x67

    const/16 v9, 0x31

    aput-byte v7, v4, v9

    const/16 v7, 0x32

    const/16 v9, -0x4b

    aput-byte v9, v4, v7

    const/16 v7, 0x27

    aput-byte v7, v4, v19

    const/16 v7, 0x34

    const/16 v9, 0x7f

    aput-byte v9, v4, v7

    const/16 v7, 0x35

    const/16 v9, -0x1a

    aput-byte v9, v4, v7

    const/16 v7, 0x21

    aput-byte v7, v4, v17

    const/16 v7, 0x37

    aput-byte v18, v4, v7

    const/16 v7, 0x38

    const/16 v9, -0x27

    aput-byte v9, v4, v7

    new-array v7, v3, [B

    const/16 v9, -0x46

    aput-byte v9, v7, v6

    const/4 v9, -0x4

    aput-byte v9, v7, v5

    const/16 v9, -0x39

    aput-byte v9, v7, v8

    aput-byte v5, v7, v10

    aput-byte v16, v7, v11

    const/16 v9, -0x6c

    aput-byte v9, v7, v12

    aput-byte v18, v7, v0

    const/16 v9, 0x6c

    const/4 v13, 0x7

    aput-byte v9, v7, v13

    invoke-static {v4, v7}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v4

    new-instance v7, Ljava/util/HashMap;

    invoke-direct {v7}, Ljava/util/HashMap;-><init>()V

    new-array v9, v3, [B

    const/16 v13, 0x23

    aput-byte v13, v9, v6

    const/16 v13, 0x2e

    aput-byte v13, v9, v5

    const/16 v13, -0x3c

    aput-byte v13, v9, v8

    const/16 v13, -0x50

    aput-byte v13, v9, v10

    const/16 v13, 0x30

    aput-byte v13, v9, v11

    aput-byte v20, v9, v12

    const/16 v13, -0x1b

    aput-byte v13, v9, v0

    const/16 v13, -0x22

    const/4 v14, 0x7

    aput-byte v13, v9, v14

    new-array v13, v3, [B

    const/16 v14, 0x53

    aput-byte v14, v13, v6

    const/16 v14, 0x4a

    aput-byte v14, v13, v5

    const/16 v14, -0x53

    aput-byte v14, v13, v8

    const/16 v14, -0x3e

    aput-byte v14, v13, v10

    const/16 v14, 0x6f

    aput-byte v14, v13, v11

    const/16 v14, -0x19

    aput-byte v14, v13, v12

    const/16 v14, -0x74

    aput-byte v14, v13, v0

    const/4 v14, 0x7

    const/16 v15, -0x46

    aput-byte v15, v13, v14

    invoke-static {v9, v13}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v9

    new-array v13, v5, [B

    const/16 v14, 0x29

    aput-byte v14, v13, v6

    new-array v14, v3, [B

    aput-byte v16, v14, v6

    const/16 v15, 0x2c

    aput-byte v15, v14, v5

    aput-byte v19, v14, v8

    aput-byte v17, v14, v10

    const/16 v15, -0x1b

    aput-byte v15, v14, v11

    aput-byte v21, v14, v12

    const/16 v15, 0x6c

    aput-byte v15, v14, v0

    const/16 v15, 0x7b

    const/16 v18, 0x7

    aput-byte v15, v14, v18

    invoke-static {v13, v14}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v13

    invoke-virtual {v7, v9, v13}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/16 v9, 0x9

    new-array v9, v9, [B

    const/16 v13, -0x37

    aput-byte v13, v9, v6

    const/16 v13, 0x7a

    aput-byte v13, v9, v5

    const/16 v13, 0x30

    aput-byte v13, v9, v8

    const/16 v13, -0x64

    aput-byte v13, v9, v10

    const/16 v13, -0x55

    aput-byte v13, v9, v11

    const/16 v13, -0x62

    aput-byte v13, v9, v12

    const/16 v13, 0x4b

    aput-byte v13, v9, v0

    const/4 v13, 0x7

    aput-byte v19, v9, v13

    const/16 v13, -0x36

    aput-byte v13, v9, v3

    new-array v13, v3, [B

    const/16 v14, -0x51

    aput-byte v14, v13, v6

    const/16 v14, 0x13

    aput-byte v14, v13, v5

    const/16 v14, 0x5c

    aput-byte v14, v13, v8

    const/4 v14, -0x7

    aput-byte v14, v13, v10

    const/16 v14, -0xc

    aput-byte v14, v13, v11

    const/16 v14, -0x10

    aput-byte v14, v13, v12

    const/16 v14, 0x2a

    aput-byte v14, v13, v0

    const/16 v14, 0x5e

    const/4 v15, 0x7

    aput-byte v14, v13, v15

    invoke-static {v9, v13}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v7, v9, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    new-array v2, v3, [B

    const/16 v9, 0x1f

    aput-byte v9, v2, v6

    const/16 v9, 0x4b

    aput-byte v9, v2, v5

    const/16 v9, 0x3f

    aput-byte v9, v2, v8

    const/16 v9, -0x4d

    aput-byte v9, v2, v10

    const/16 v9, -0xe

    aput-byte v9, v2, v11

    const/16 v9, 0x49

    aput-byte v9, v2, v12

    const/16 v9, 0x17

    aput-byte v9, v2, v0

    const/16 v9, -0x22

    const/4 v13, 0x7

    aput-byte v9, v2, v13

    new-array v9, v3, [B

    const/16 v13, 0x7b

    aput-byte v13, v9, v6

    const/16 v13, 0x22

    aput-byte v13, v9, v5

    const/16 v13, 0x4d

    aput-byte v13, v9, v8

    const/16 v13, -0x14

    aput-byte v13, v9, v10

    const/16 v13, -0x7e

    aput-byte v13, v9, v11

    const/16 v13, 0x28

    aput-byte v13, v9, v12

    const/16 v13, 0x63

    aput-byte v13, v9, v0

    const/16 v13, -0x4a

    const/4 v14, 0x7

    aput-byte v13, v9, v14

    invoke-static {v2, v9}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v2

    const-string v9, ""

    invoke-virtual {v7, v2, v9}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/16 v2, 0xd

    new-array v2, v2, [B

    aput-byte v21, v2, v6

    const/16 v9, -0x54

    aput-byte v9, v2, v5

    const/16 v9, -0x28

    aput-byte v9, v2, v8

    const/16 v9, 0xa

    aput-byte v9, v2, v10

    const/16 v9, -0x44

    aput-byte v9, v2, v11

    const/16 v9, -0x5a

    aput-byte v9, v2, v12

    const/16 v9, -0x62

    aput-byte v9, v2, v0

    const/16 v9, 0xe

    const/4 v13, 0x7

    aput-byte v9, v2, v13

    const/16 v9, 0x7a

    aput-byte v9, v2, v3

    const/16 v9, -0x57

    const/16 v13, 0x9

    aput-byte v9, v2, v13

    const/16 v9, 0xa

    const/16 v13, -0x3b

    aput-byte v13, v2, v9

    const/16 v9, 0xb

    aput-byte v17, v2, v9

    const/16 v9, 0xc

    const/16 v13, -0x42

    aput-byte v13, v2, v9

    new-array v9, v3, [B

    const/16 v13, 0x25

    aput-byte v13, v9, v6

    const/16 v13, -0x3b

    aput-byte v13, v9, v5

    const/16 v13, -0x56

    aput-byte v13, v9, v8

    const/16 v13, 0x55

    aput-byte v13, v9, v10

    const/16 v13, -0x2b

    aput-byte v13, v9, v11

    const/16 v13, -0x38

    aput-byte v13, v9, v12

    const/16 v13, -0x9

    aput-byte v13, v9, v0

    const/16 v13, 0x7a

    const/4 v14, 0x7

    aput-byte v13, v9, v14

    invoke-static {v2, v9}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v2

    sget-object v9, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    invoke-virtual {v7, v2, v9}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    new-instance v2, Lorg/json/JSONObject;

    invoke-direct {v1, v4, v7}, Lcom/github/catvod/spider/appysv2/b/U;->L(Ljava/lang/String;Ljava/util/Map;)Ljava/lang/String;

    move-result-object v4

    invoke-direct {v2, v4}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    new-array v4, v11, [B

    const/16 v7, 0x47

    aput-byte v7, v4, v6

    const/16 v7, 0x1f

    aput-byte v7, v4, v5

    const/16 v7, -0xe

    aput-byte v7, v4, v8

    const/4 v7, -0x4

    aput-byte v7, v4, v10

    new-array v7, v3, [B

    const/16 v9, 0x23

    aput-byte v9, v7, v6

    const/16 v9, 0x7e

    aput-byte v9, v7, v5

    const/16 v9, -0x7a

    aput-byte v9, v7, v8

    const/16 v9, -0x63

    aput-byte v9, v7, v10

    const/16 v9, -0x2a

    aput-byte v9, v7, v11

    aput-byte v17, v7, v12

    const/4 v9, -0x6

    aput-byte v9, v7, v0

    const/16 v9, -0x31

    const/4 v13, 0x7

    aput-byte v9, v7, v13

    invoke-static {v4, v7}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v2, v4}, Lorg/json/JSONObject;->getJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v2

    new-array v4, v10, [B

    const/16 v7, 0x29

    aput-byte v7, v4, v6

    const/16 v7, -0x73

    aput-byte v7, v4, v5

    aput-byte v8, v4, v8

    new-array v7, v3, [B

    const/16 v9, 0x4f

    aput-byte v9, v7, v6

    const/16 v9, -0x1c

    aput-byte v9, v7, v5

    const/16 v9, 0x66

    aput-byte v9, v7, v8

    const/16 v8, 0x4b

    aput-byte v8, v7, v10

    aput-byte v12, v7, v11

    const/16 v8, 0x13

    aput-byte v8, v7, v12

    const/16 v8, -0x5d

    aput-byte v8, v7, v0

    const/4 v0, 0x7

    aput-byte v16, v7, v0

    invoke-static {v4, v7}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v2, v0}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0
    :try_end_860
    .catch Ljava/lang/Exception; {:try_start_17 .. :try_end_860} :catch_861

    return-object v0

    :catch_861
    move-exception v0

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/16 v4, 0x10

    new-array v4, v4, [B

    fill-array-data v4, :array_896

    new-array v7, v3, [B

    fill-array-data v7, :array_8a2

    .line 1
    invoke-static {v4, v7, v2, v0}, Lcom/github/catvod/spider/appysv2/b/y;->b([B[BLjava/lang/StringBuilder;Ljava/lang/Exception;)V

    new-array v0, v5, [B

    const/16 v2, -0x1f

    aput-byte v2, v0, v6

    new-array v2, v3, [B

    .line 2
    fill-array-data v2, :array_8aa

    invoke-static {v0, v2}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v0

    return-object v0

    :array_886
    .array-data 1
        0x51t
        0x51t
        -0x53t
        -0x7bt
        -0x50t
        0x30t
    .end array-data

    nop

    :array_88e
    .array-data 1
        0x25t
        0x27t
        -0x27t
        -0x20t
        -0x23t
        0x40t
        -0x10t
        0x51t
    .end array-data

    :array_896
    .array-data 1
        0x6ft
        -0x6ct
        -0x4et
        0x11t
        -0x50t
        0x59t
        -0x42t
        0x3ft
        0x6ct
        -0x68t
        -0x4ct
        0x72t
        -0x46t
        0x51t
        -0x3t
        0x4ft
    .end array-data

    :array_8a2
    .array-data 1
        0x8t
        -0xft
        -0x3at
        0x52t
        -0x21t
        0x29t
        -0x39t
        0x6ft
    .end array-data

    :array_8aa
    .array-data 1
        -0x2ft
        -0x78t
        -0x16t
        0x39t
        -0x3bt
        -0x41t
        -0x20t
        -0x17t
    .end array-data
.end method

.method private y()Ljava/util/Map;
    .registers 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    new-instance v0, Ljava/util/HashMap;

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    iget-object v1, p0, Lcom/github/catvod/spider/appysv2/b/U;->a:Ljava/lang/String;

    invoke-static {v1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    const/16 v2, 0x8

    if-nez v1, :cond_23

    const/4 v1, 0x6

    new-array v1, v1, [B

    fill-array-data v1, :array_5c

    new-array v3, v2, [B

    fill-array-data v3, :array_64

    invoke-static {v1, v3}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v1

    iget-object v3, p0, Lcom/github/catvod/spider/appysv2/b/U;->a:Ljava/lang/String;

    invoke-virtual {v0, v1, v3}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_23
    const/4 v1, 0x7

    new-array v1, v1, [B

    fill-array-data v1, :array_6c

    new-array v3, v2, [B

    fill-array-data v3, :array_74

    invoke-static {v1, v3}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v1

    const/16 v3, 0x13

    new-array v3, v3, [B

    fill-array-data v3, :array_7c

    new-array v4, v2, [B

    fill-array-data v4, :array_8a

    invoke-static {v3, v4}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v0, v1, v3}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/16 v1, 0xa

    new-array v1, v1, [B

    fill-array-data v1, :array_92

    new-array v2, v2, [B

    fill-array-data v2, :array_9c

    invoke-static {v1, v2}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v1

    sget-object v2, Lcom/github/catvod/spider/appysv2/b/U;->i:Ljava/lang/String;

    invoke-virtual {v0, v1, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    return-object v0

    nop

    :array_5c
    .array-data 1
        0x4at
        0x70t
        0x69t
        -0x3dt
        0x40t
        0x76t
    .end array-data

    nop

    :array_64
    .array-data 1
        0x9t
        0x1ft
        0x6t
        -0x58t
        0x29t
        0x13t
        0x28t
        -0x6dt
    .end array-data

    :array_6c
    .array-data 1
        0x1dt
        0x7et
        -0x5at
        0x14t
        -0x68t
        0x19t
        0x77t
    .end array-data

    :array_74
    .array-data 1
        0x4ft
        0x1bt
        -0x40t
        0x71t
        -0x16t
        0x7ct
        0x5t
        -0x26t
    .end array-data

    :array_7c
    .array-data 1
        -0x28t
        -0x3ft
        -0x53t
        0x57t
        0x1ct
        -0x48t
        -0x5at
        -0x1ft
        -0x2ct
        -0x39t
        -0x50t
        0x51t
        0xat
        -0x54t
        -0x4t
        -0x53t
        -0x62t
        -0x2at
        -0x49t
    .end array-data

    :array_8a
    .array-data 1
        -0x50t
        -0x4bt
        -0x27t
        0x27t
        0x6ft
        -0x7et
        -0x77t
        -0x32t
    .end array-data

    :array_92
    .array-data 1
        0xat
        -0x7t
        -0x4et
        0x38t
        -0x39t
        -0xat
        0x64t
        0x21t
        0x31t
        -0x2t
    .end array-data

    nop

    :array_9c
    .array-data 1
        0x5ft
        -0x76t
        -0x29t
        0x4at
        -0x16t
        -0x49t
        0x3t
        0x44t
    .end array-data
.end method

.method private z()Ljava/util/Map;
    .registers 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    new-instance v0, Ljava/util/HashMap;

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    iget-object v1, p0, Lcom/github/catvod/spider/appysv2/b/U;->d:Ljava/lang/String;

    invoke-static {v1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    const/16 v2, 0x8

    if-eqz v1, :cond_12

    iget-object v1, p0, Lcom/github/catvod/spider/appysv2/b/U;->a:Ljava/lang/String;

    goto :goto_39

    :cond_12
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v3, p0, Lcom/github/catvod/spider/appysv2/b/U;->a:Ljava/lang/String;

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x1

    new-array v3, v3, [B

    const/4 v4, 0x0

    const/16 v5, 0x2b

    aput-byte v5, v3, v4

    new-array v4, v2, [B

    fill-array-data v4, :array_84

    invoke-static {v3, v4}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v3, p0, Lcom/github/catvod/spider/appysv2/b/U;->d:Ljava/lang/String;

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    :goto_39
    const/4 v3, 0x6

    new-array v3, v3, [B

    fill-array-data v3, :array_8c

    new-array v4, v2, [B

    fill-array-data v4, :array_94

    invoke-static {v3, v4}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v0, v3, v1}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v1, 0x7

    new-array v1, v1, [B

    fill-array-data v1, :array_9c

    new-array v3, v2, [B

    fill-array-data v3, :array_a4

    invoke-static {v1, v3}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v1

    const/16 v3, 0x14

    new-array v3, v3, [B

    fill-array-data v3, :array_ac

    new-array v4, v2, [B

    fill-array-data v4, :array_ba

    invoke-static {v3, v4}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v0, v1, v3}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/16 v1, 0xa

    new-array v1, v1, [B

    fill-array-data v1, :array_c2

    new-array v2, v2, [B

    fill-array-data v2, :array_cc

    invoke-static {v1, v2}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v1

    sget-object v2, Lcom/github/catvod/spider/appysv2/b/U;->i:Ljava/lang/String;

    invoke-virtual {v0, v1, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    return-object v0

    nop

    :array_84
    .array-data 1
        0x10t
        -0x67t
        -0x3t
        0x6ft
        0x52t
        -0x20t
        -0x16t
        0x44t
    .end array-data

    :array_8c
    .array-data 1
        0x75t
        -0x5t
        -0x1t
        0x5at
        0x40t
        -0x59t
    .end array-data

    nop

    :array_94
    .array-data 1
        0x36t
        -0x6ct
        -0x70t
        0x31t
        0x29t
        -0x3et
        0x33t
        0x3bt
    .end array-data

    :array_9c
    .array-data 1
        -0x74t
        -0x30t
        -0x31t
        -0x13t
        -0x44t
        0x3t
        0x69t
    .end array-data

    :array_a4
    .array-data 1
        -0x22t
        -0x4bt
        -0x57t
        -0x78t
        -0x32t
        0x66t
        0x1bt
        -0x6t
    .end array-data

    :array_ac
    .array-data 1
        -0x2ft
        0x3t
        -0x8t
        -0x5at
        0x7ct
        -0x53t
        0x28t
        0x1bt
        -0x23t
        0x5t
        -0x1bt
        -0x60t
        0x6at
        -0x47t
        0x72t
        0x57t
        -0x69t
        0x14t
        -0x1et
        -0x7t
    .end array-data

    :array_ba
    .array-data 1
        -0x47t
        0x77t
        -0x74t
        -0x2at
        0xft
        -0x69t
        0x7t
        0x34t
    .end array-data

    :array_c2
    .array-data 1
        0x3ft
        -0x6t
        0x66t
        0x2et
        -0x6ct
        -0x71t
        -0x3et
        -0x48t
        0x4t
        -0x3t
    .end array-data

    nop

    :array_cc
    .array-data 1
        0x6at
        -0x77t
        0x3t
        0x5ct
        -0x47t
        -0x32t
        -0x5bt
        -0x23t
    .end array-data
.end method


# virtual methods
.method public final A(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)Ljava/util/List;
    .registers 46
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/lang/Boolean;",
            ")",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    move-object/from16 v1, p0

    move-object/from16 v2, p1

    move-object/from16 v3, p3

    :try_start_6
    invoke-virtual/range {p0 .. p1}, Lcom/github/catvod/spider/appysv2/b/U;->N(Ljava/lang/String;)Ljava/lang/String;

    sget-object v4, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;
    :try_end_b
    .catch Ljava/lang/Exception; {:try_start_6 .. :try_end_b} :catch_64d
    .catchall {:try_start_6 .. :try_end_b} :catchall_647

    move-object/from16 v5, p2

    :try_start_d
    invoke-direct {v1, v2, v5, v3, v4}, Lcom/github/catvod/spider/appysv2/b/U;->q(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)Ljava/lang/String;

    move-result-object v4
    :try_end_11
    .catch Ljava/lang/Exception; {:try_start_d .. :try_end_11} :catch_644
    .catchall {:try_start_d .. :try_end_11} :catchall_641

    const/16 v5, 0x41

    :try_start_13
    new-array v5, v5, [B

    const/16 v6, 0x32

    const/4 v7, 0x0

    aput-byte v6, v5, v7

    const/4 v6, 0x1

    const/16 v8, 0x6a

    aput-byte v8, v5, v6

    const/4 v9, 0x2

    const/16 v10, 0x14

    aput-byte v10, v5, v9

    const/4 v11, 0x3

    const/16 v12, 0x9

    aput-byte v12, v5, v11

    const/16 v13, 0x4c

    const/4 v14, 0x4

    aput-byte v13, v5, v14

    const/16 v15, -0x54

    const/16 v16, 0x5

    aput-byte v15, v5, v16

    const/16 v17, 0x6

    aput-byte v11, v5, v17

    const/16 v18, -0x60

    const/4 v13, 0x7

    aput-byte v18, v5, v13

    const/16 v19, 0x2a

    const/16 v15, 0x8

    aput-byte v19, v5, v15

    const/16 v19, 0x7d

    aput-byte v19, v5, v12

    const/16 v19, 0x4d

    const/16 v12, 0xa

    aput-byte v19, v5, v12

    const/16 v19, 0x18

    const/16 v12, 0xb

    aput-byte v19, v5, v12

    const/16 v23, 0xc

    const/16 v24, 0x4f

    aput-byte v24, v5, v23

    const/16 v23, -0x1

    const/16 v24, 0xd

    aput-byte v23, v5, v24

    const/16 v8, 0xe

    aput-byte v9, v5, v8

    const/16 v25, 0xf

    const/16 v26, -0x6

    aput-byte v26, v5, v25

    const/16 v25, 0x10

    const/16 v26, 0x39

    aput-byte v26, v5, v25

    const/16 v27, 0x30

    const/16 v28, 0x11

    aput-byte v27, v5, v28

    const/16 v29, 0x12

    aput-byte v11, v5, v29

    const/16 v30, 0x13

    const/16 v31, 0x17

    aput-byte v31, v5, v30

    aput-byte v25, v5, v10

    const/16 v30, -0x59

    const/16 v31, 0x15

    aput-byte v30, v5, v31

    const/16 v30, 0x16

    aput-byte v11, v5, v30

    const/16 v30, 0x17

    const/16 v32, -0x14

    aput-byte v32, v5, v30

    const/16 v30, 0x36

    aput-byte v30, v5, v19

    const/16 v19, 0x19

    const/16 v30, 0x71

    aput-byte v30, v5, v19

    const/16 v19, 0x1a

    aput-byte v31, v5, v19

    const/16 v19, 0x1b

    const/16 v30, 0x1d

    aput-byte v30, v5, v19

    const/16 v19, 0x1c

    const/16 v30, 0x5b

    aput-byte v30, v5, v19

    const/16 v19, 0x1d

    const/16 v30, -0x1c

    aput-byte v30, v5, v19

    const/16 v19, 0x1e

    const/16 v32, 0x45

    aput-byte v32, v5, v19

    const/16 v19, 0x1f

    const/16 v32, -0x7

    aput-byte v32, v5, v19

    const/16 v19, 0x20

    const/16 v32, 0x3f

    aput-byte v32, v5, v19

    const/16 v19, 0x21

    const/16 v32, 0x31

    aput-byte v32, v5, v19

    const/16 v19, 0x22

    aput-byte v17, v5, v19

    const/16 v19, 0x23

    aput-byte v25, v5, v19

    const/16 v33, 0x24

    const/16 v34, 0x53

    aput-byte v34, v5, v33

    const/16 v33, 0x25

    const/16 v34, -0xd

    aput-byte v34, v5, v33

    const/16 v33, 0x26

    aput-byte v11, v5, v33

    const/16 v33, 0x27

    const/16 v34, -0x7

    aput-byte v34, v5, v33

    const/16 v33, 0x68

    const/16 v34, 0x28

    aput-byte v33, v5, v34

    const/16 v33, 0x29

    aput-byte v32, v5, v33

    const/16 v35, 0x2a

    aput-byte v25, v5, v35

    const/16 v35, 0x2b

    aput-byte v31, v5, v35

    const/16 v35, 0x2c

    const/16 v36, 0x5e

    aput-byte v36, v5, v35

    const/16 v35, 0x2d

    const/16 v36, -0x11

    aput-byte v36, v5, v35

    const/16 v35, 0x2e

    const/16 v36, 0x13

    aput-byte v36, v5, v35

    const/16 v35, 0x2f

    aput-byte v23, v5, v35

    aput-byte v34, v5, v27

    aput-byte v19, v5, v32

    const/16 v36, 0x32

    const/16 v37, 0x35

    aput-byte v37, v5, v36

    const/16 v36, 0x33

    const/16 v37, 0x3a

    aput-byte v37, v5, v36

    const/16 v36, 0x34

    const/16 v37, 0x7d

    aput-byte v37, v5, v36

    const/16 v36, 0x35

    aput-byte v30, v5, v36

    const/16 v36, 0x36

    const/16 v37, 0x43

    aput-byte v37, v5, v36

    const/16 v36, 0x37

    const/16 v37, -0x8

    aput-byte v37, v5, v36

    const/16 v36, 0x38

    aput-byte v33, v5, v36

    const/16 v36, 0x7b

    aput-byte v36, v5, v26

    const/16 v36, 0x3a

    aput-byte v29, v5, v36

    const/16 v36, 0x3b

    const/16 v37, 0x5f

    aput-byte v37, v5, v36

    const/16 v36, 0x3c

    const/16 v37, 0x59

    aput-byte v37, v5, v36

    const/16 v36, 0x3d

    aput-byte v30, v5, v36

    const/16 v36, 0x3e

    aput-byte v28, v5, v36

    const/16 v36, 0x3f

    aput-byte v23, v5, v36

    const/16 v36, 0x40

    aput-byte v26, v5, v36

    new-array v10, v15, [B

    const/16 v37, 0x5a

    aput-byte v37, v10, v7

    const/16 v37, 0x1e

    aput-byte v37, v10, v6

    const/16 v37, 0x60

    aput-byte v37, v10, v9

    const/16 v37, 0x79

    aput-byte v37, v10, v11

    const/16 v37, 0x3f

    aput-byte v37, v10, v14

    const/16 v37, -0x6a

    aput-byte v37, v10, v16

    const/16 v37, 0x2c

    aput-byte v37, v10, v17

    const/16 v37, -0x71

    aput-byte v37, v10, v13

    invoke-static {v5, v10}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v5

    new-instance v10, Ljava/util/HashMap;

    invoke-direct {v10}, Ljava/util/HashMap;-><init>()V

    new-array v8, v11, [B

    const/16 v38, -0x59

    aput-byte v38, v8, v7

    const/16 v38, -0x48

    aput-byte v38, v8, v6

    const/16 v38, -0x6f

    aput-byte v38, v8, v9

    new-array v12, v15, [B

    const/16 v39, -0x3f

    aput-byte v39, v12, v7

    const/16 v39, -0x2f

    aput-byte v39, v12, v6

    const/16 v39, -0xb

    aput-byte v39, v12, v9

    aput-byte v9, v12, v11

    const/16 v39, 0x7e

    aput-byte v39, v12, v14

    const/16 v39, -0xe

    aput-byte v39, v12, v16

    const/16 v39, -0x4a

    aput-byte v39, v12, v17

    const/16 v39, 0x56

    aput-byte v39, v12, v13

    invoke-static {v8, v12}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v10, v8, v4}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/16 v8, 0xb

    new-array v12, v8, [B

    const/16 v8, -0x20

    aput-byte v8, v12, v7

    aput-byte v27, v12, v6

    aput-byte v35, v12, v9

    const/16 v8, 0x6a

    aput-byte v8, v12, v11

    const/16 v8, -0x1f

    aput-byte v8, v12, v14

    const/16 v8, -0x54

    aput-byte v8, v12, v16

    const/16 v8, 0x5c

    aput-byte v8, v12, v17

    const/16 v8, 0xb

    aput-byte v8, v12, v13

    const/4 v8, -0x3

    aput-byte v8, v12, v15

    const/16 v8, 0x3b

    const/16 v21, 0x9

    aput-byte v8, v12, v21

    const/16 v8, 0xa

    aput-byte v35, v12, v8

    new-array v8, v15, [B

    const/16 v39, -0x6e

    aput-byte v39, v8, v7

    const/16 v39, 0x55

    aput-byte v39, v8, v6

    const/16 v39, 0x5c

    aput-byte v39, v8, v9

    aput-byte v16, v8, v11

    const/16 v39, -0x73

    aput-byte v39, v8, v14

    const/16 v39, -0x27

    aput-byte v39, v8, v16

    aput-byte v34, v8, v17

    const/16 v39, 0x62

    aput-byte v39, v8, v13

    invoke-static {v12, v8}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v8

    const/16 v12, 0x1b

    new-array v12, v12, [B

    const/16 v39, 0xf

    aput-byte v39, v12, v7

    const/16 v39, -0x70

    aput-byte v39, v12, v6

    const/16 v39, 0x4e

    aput-byte v39, v12, v9

    const/16 v39, -0x50

    aput-byte v39, v12, v11

    const/16 v39, -0x77

    aput-byte v39, v12, v14

    const/16 v39, 0x58

    aput-byte v39, v12, v16

    const/16 v39, -0x2a

    aput-byte v39, v12, v17

    const/16 v39, 0x45

    aput-byte v39, v12, v13

    const/16 v37, 0xe

    aput-byte v37, v12, v15

    const/16 v39, -0x78

    const/16 v21, 0x9

    aput-byte v39, v12, v21

    const/16 v22, 0xa

    aput-byte v25, v12, v22

    const/16 v39, -0x4b

    const/16 v38, 0xb

    aput-byte v39, v12, v38

    const/16 v39, 0xc

    const/16 v40, -0x7f

    aput-byte v40, v12, v39

    const/16 v39, 0x53

    aput-byte v39, v12, v24

    const/16 v39, -0x6e

    const/16 v37, 0xe

    aput-byte v39, v12, v37

    const/16 v39, 0xf

    aput-byte v16, v12, v39

    aput-byte v29, v12, v25

    const/16 v39, -0x76

    aput-byte v39, v12, v28

    const/16 v39, 0x4c

    aput-byte v39, v12, v29

    const/16 v29, 0x13

    const/16 v39, -0x48

    aput-byte v39, v12, v29

    const/16 v29, -0x66

    const/16 v36, 0x14

    aput-byte v29, v12, v36

    const/16 v29, 0x18

    aput-byte v29, v12, v31

    const/16 v39, 0x16

    const/16 v40, -0x38

    aput-byte v40, v12, v39

    const/16 v39, 0x17

    const/16 v40, 0x42

    aput-byte v40, v12, v39

    const/16 v39, 0x4d

    aput-byte v39, v12, v29

    const/16 v29, 0x19

    const/16 v39, -0x35

    aput-byte v39, v12, v29

    const/16 v29, 0x1a

    const/16 v39, 0x57

    aput-byte v39, v12, v29

    new-array v13, v15, [B

    const/16 v39, 0x61

    aput-byte v39, v13, v7

    aput-byte v23, v13, v6

    const/16 v23, 0x3c

    aput-byte v23, v13, v9

    const/16 v23, -0x23

    aput-byte v23, v13, v11

    const/16 v23, -0x18

    aput-byte v23, v13, v14

    const/16 v23, 0x34

    aput-byte v23, v13, v16

    const/16 v23, -0x6

    aput-byte v23, v13, v17

    const/16 v23, 0x7

    aput-byte v33, v13, v23

    invoke-static {v12, v13}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v12

    invoke-virtual {v10, v8, v12}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    new-array v8, v15, [B

    const/16 v12, 0x70

    aput-byte v12, v8, v7

    const/16 v12, -0x54

    aput-byte v12, v8, v6

    aput-byte v30, v8, v9

    const/16 v12, -0x80

    aput-byte v12, v8, v11

    const/16 v12, 0x4c

    aput-byte v12, v8, v14

    const/16 v12, 0x5a

    aput-byte v12, v8, v16

    aput-byte v35, v8, v17

    const/16 v12, -0x34

    const/4 v13, 0x7

    aput-byte v12, v8, v13

    new-array v12, v15, [B

    aput-byte v11, v12, v7

    const/16 v13, -0x27

    aput-byte v13, v12, v6

    const/16 v13, -0x6c

    aput-byte v13, v12, v9

    const/16 v13, -0x10

    aput-byte v13, v12, v11

    aput-byte v19, v12, v14

    aput-byte v34, v12, v16

    const/16 v13, 0x5b

    aput-byte v13, v12, v17

    const/16 v13, -0x41

    const/16 v20, 0x7

    aput-byte v13, v12, v20

    invoke-static {v8, v12}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v8

    const/16 v12, 0x9

    new-array v13, v12, [B

    const/16 v12, 0x58

    aput-byte v12, v13, v7

    const/16 v12, -0x17

    aput-byte v12, v13, v6

    const/16 v12, -0xa

    aput-byte v12, v13, v9

    const/16 v12, 0x14

    aput-byte v12, v13, v11

    const/16 v12, -0x20

    aput-byte v12, v13, v14

    const/16 v12, -0x79

    aput-byte v12, v13, v16

    const/16 v12, 0x49

    aput-byte v12, v13, v17

    const/16 v12, -0x46

    const/16 v20, 0x7

    aput-byte v12, v13, v20

    aput-byte v17, v13, v15

    new-array v12, v15, [B

    const/16 v20, 0x3e

    aput-byte v20, v12, v7

    const/16 v20, -0x7c

    aput-byte v20, v12, v6

    const/16 v20, -0x7a

    aput-byte v20, v12, v9

    const/16 v20, 0x20

    aput-byte v20, v12, v11

    const/16 v20, -0x34

    aput-byte v20, v12, v14

    const/16 v20, -0x16

    aput-byte v20, v12, v16

    const/16 v20, 0x7a

    aput-byte v20, v12, v17

    const/16 v20, -0x31

    const/16 v23, 0x7

    aput-byte v20, v12, v23

    invoke-static {v13, v12}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v12

    invoke-virtual {v10, v8, v12}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    new-instance v8, Lorg/json/JSONObject;

    invoke-direct {v1, v5, v10}, Lcom/github/catvod/spider/appysv2/b/U;->L(Ljava/lang/String;Ljava/util/Map;)Ljava/lang/String;

    move-result-object v5

    invoke-direct {v8, v5}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x7

    new-array v10, v5, [B

    const/16 v5, -0x59

    aput-byte v5, v10, v7

    const/16 v5, 0x6f

    aput-byte v5, v10, v6

    const/16 v5, -0x6b

    aput-byte v5, v10, v9

    const/16 v5, -0x1f

    aput-byte v5, v10, v11

    const/16 v5, -0x42

    aput-byte v5, v10, v14

    const/16 v5, -0x75

    aput-byte v5, v10, v16

    const/16 v5, -0xc

    aput-byte v5, v10, v17

    new-array v5, v15, [B

    const/16 v12, -0x36

    aput-byte v12, v5, v7

    const/16 v12, 0xa

    aput-byte v12, v5, v6

    const/16 v12, -0x1a

    aput-byte v12, v5, v9

    const/16 v12, -0x6e

    aput-byte v12, v5, v11

    const/16 v12, -0x21

    aput-byte v12, v5, v14

    const/16 v12, -0x14

    aput-byte v12, v5, v16

    const/16 v12, -0x6f

    aput-byte v12, v5, v17

    const/16 v12, -0x1a

    const/4 v13, 0x7

    aput-byte v12, v5, v13

    invoke-static {v10, v5}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v8, v5}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    const/16 v10, 0xe

    new-array v10, v10, [B

    const/16 v12, 0x42

    aput-byte v12, v10, v7

    const/16 v12, -0x70

    aput-byte v12, v10, v6

    const/16 v12, 0x79

    aput-byte v12, v10, v9

    const/16 v12, -0x5f

    aput-byte v12, v10, v11

    const/16 v12, 0x56

    aput-byte v12, v10, v14

    const/16 v12, -0x2d

    aput-byte v12, v10, v16

    aput-byte v32, v10, v17

    const/16 v12, -0x37

    const/4 v13, 0x7

    aput-byte v12, v10, v13

    aput-byte v14, v10, v15

    const/16 v12, -0x61

    const/16 v13, 0x9

    aput-byte v12, v10, v13

    const/16 v12, 0x7a

    const/16 v13, 0xa

    aput-byte v12, v10, v13

    const/16 v12, -0x4f

    const/16 v13, 0xb

    aput-byte v12, v10, v13

    const/16 v12, 0xc

    const/16 v13, 0x18

    aput-byte v13, v10, v12

    const/16 v12, -0x27

    aput-byte v12, v10, v24

    new-array v12, v15, [B

    const/16 v13, 0x24

    aput-byte v13, v12, v7

    const/4 v13, -0x7

    aput-byte v13, v12, v6

    aput-byte v31, v12, v9

    const/16 v13, -0x3c

    aput-byte v13, v12, v11

    const/16 v13, 0x76

    aput-byte v13, v12, v14

    const/16 v13, -0x43

    aput-byte v13, v12, v16

    const/16 v13, 0x5e

    aput-byte v13, v12, v17

    const/16 v13, -0x43

    const/16 v20, 0x7

    aput-byte v13, v12, v20

    invoke-static {v10, v12}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v5, v10}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v5

    if-eqz v5, :cond_417

    new-instance v3, Ljava/util/ArrayList;

    invoke-direct {v3}, Ljava/util/ArrayList;-><init>()V
    :try_end_40d
    .catch Ljava/lang/Exception; {:try_start_13 .. :try_end_40d} :catch_63e
    .catchall {:try_start_13 .. :try_end_40d} :catchall_664

    invoke-static/range {p1 .. p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v2

    if-nez v2, :cond_416

    invoke-direct {v1, v4}, Lcom/github/catvod/spider/appysv2/b/U;->r(Ljava/lang/String;)V

    :cond_416
    return-object v3

    :cond_417
    :try_start_417
    new-array v5, v14, [B

    const/16 v10, -0x13

    aput-byte v10, v5, v7

    const/16 v10, 0x6c

    aput-byte v10, v5, v6

    const/16 v10, -0x3a

    aput-byte v10, v5, v9

    const/16 v10, -0x2c

    aput-byte v10, v5, v11

    new-array v10, v15, [B

    const/16 v12, -0x77

    aput-byte v12, v10, v7

    aput-byte v24, v10, v6

    const/16 v12, -0x4e

    aput-byte v12, v10, v9

    const/16 v12, -0x4b

    aput-byte v12, v10, v11

    aput-byte v26, v10, v14

    const/16 v12, -0x7f

    aput-byte v12, v10, v16

    const/16 v12, -0xb

    aput-byte v12, v10, v17

    const/16 v12, -0x1d

    const/4 v13, 0x7

    aput-byte v12, v10, v13

    invoke-static {v5, v10}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v8, v5}, Lorg/json/JSONObject;->optJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v5

    const/16 v8, 0xa

    new-array v10, v8, [B

    aput-byte v9, v10, v7

    aput-byte v19, v10, v6

    const/16 v8, 0x26

    aput-byte v8, v10, v9

    const/16 v8, 0x67

    aput-byte v8, v10, v11

    const/16 v8, -0x65

    aput-byte v8, v10, v14

    const/16 v8, 0x79

    aput-byte v8, v10, v16

    const/16 v8, -0x33

    aput-byte v8, v10, v17

    const/4 v8, 0x7

    aput-byte v27, v10, v8

    aput-byte v8, v10, v15

    const/16 v8, 0x3e

    const/16 v12, 0x9

    aput-byte v8, v10, v12

    new-array v8, v15, [B

    const/16 v12, 0x74

    aput-byte v12, v8, v7

    const/16 v12, 0x4a

    aput-byte v12, v8, v6

    const/16 v12, 0x42

    aput-byte v12, v8, v9

    aput-byte v9, v8, v11

    const/16 v12, -0xc

    aput-byte v12, v8, v14

    const/16 v12, 0x26

    aput-byte v12, v8, v16

    const/16 v12, -0x5f

    aput-byte v12, v8, v17

    const/16 v12, 0x59

    const/4 v13, 0x7

    aput-byte v12, v8, v13

    invoke-static {v10, v8}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v5, v8}, Lorg/json/JSONObject;->optJSONArray(Ljava/lang/String;)Lorg/json/JSONArray;

    move-result-object v5

    new-instance v8, Ljava/util/ArrayList;

    invoke-direct {v8}, Ljava/util/ArrayList;-><init>()V

    const/4 v10, 0x0

    :goto_4a6
    invoke-virtual {v5}, Lorg/json/JSONArray;->length()I

    move-result v12

    if-ge v10, v12, :cond_622

    invoke-virtual {v5, v10}, Lorg/json/JSONArray;->optJSONObject(I)Lorg/json/JSONObject;

    move-result-object v12

    const/16 v13, 0xa

    new-array v14, v13, [B

    const/16 v13, 0x4e

    aput-byte v13, v14, v7

    const/16 v13, -0x2f

    aput-byte v13, v14, v6

    const/16 v13, -0x11

    aput-byte v13, v14, v9

    const/16 v13, 0x2d

    aput-byte v13, v14, v11

    const/4 v13, 0x4

    aput-byte v15, v14, v13

    const/16 v13, 0x14

    aput-byte v13, v14, v16

    const/16 v19, 0x4b

    aput-byte v19, v14, v17

    const/16 v19, -0x51

    const/16 v20, 0x7

    aput-byte v19, v14, v20

    const/16 v19, 0x43

    aput-byte v19, v14, v15

    const/16 v19, -0x29

    const/16 v20, 0x9

    aput-byte v19, v14, v20

    new-array v13, v15, [B

    aput-byte v35, v13, v7

    const/16 v19, -0x4e

    aput-byte v19, v13, v6

    const/16 v19, -0x74

    aput-byte v19, v13, v9

    const/16 v19, 0x48

    aput-byte v19, v13, v11

    const/16 v19, 0x7b

    const/16 v20, 0x4

    aput-byte v19, v13, v20

    const/16 v19, 0x67

    aput-byte v19, v13, v16

    const/16 v19, 0x2a

    aput-byte v19, v13, v17

    const/16 v19, -0x33

    const/16 v20, 0x7

    aput-byte v19, v13, v20

    invoke-static {v14, v13}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v13

    invoke-virtual {v12, v13}, Lorg/json/JSONObject;->optBoolean(Ljava/lang/String;)Z

    move-result v13

    if-nez v13, :cond_51b

    const/16 v11, 0xa

    const/16 v13, 0x8

    const/16 v20, 0x3

    const/16 v21, 0x9

    const/16 v22, 0x4

    const/16 v23, 0x7

    goto/16 :goto_61a

    :cond_51b
    iget-object v13, v1, Lcom/github/catvod/spider/appysv2/b/U;->g:Ljava/util/HashMap;

    const/16 v14, 0xa

    new-array v15, v14, [B

    const/16 v14, -0x5d

    aput-byte v14, v15, v7

    const/16 v14, -0x3b

    aput-byte v14, v15, v6

    aput-byte v34, v15, v9

    const/16 v14, 0x6a

    aput-byte v14, v15, v11

    const/16 v20, 0x6b

    const/16 v23, 0x4

    aput-byte v20, v15, v23

    const/16 v20, -0xc

    aput-byte v20, v15, v16

    const/16 v20, 0x5d

    aput-byte v20, v15, v17

    const/16 v20, -0x37

    const/16 v23, 0x7

    aput-byte v20, v15, v23

    const/16 v20, -0x42

    const/16 v14, 0x8

    aput-byte v20, v15, v14

    const/16 v19, -0x32

    const/16 v20, 0x9

    aput-byte v19, v15, v20

    new-array v11, v14, [B

    const/16 v14, -0x2f

    aput-byte v14, v11, v7

    aput-byte v18, v11, v6

    const/16 v14, 0x5b

    aput-byte v14, v11, v9

    const/4 v14, 0x3

    aput-byte v16, v11, v14

    const/4 v14, 0x4

    const/16 v23, 0x7

    aput-byte v23, v11, v14

    const/16 v14, -0x7f

    aput-byte v14, v11, v16

    aput-byte v33, v11, v17

    aput-byte v18, v11, v23

    invoke-static {v15, v11}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v11

    invoke-virtual {v12, v11}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v11

    invoke-virtual {v13, v11}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v11

    check-cast v11, Ljava/lang/String;

    invoke-virtual {v8, v11}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    const/16 v11, 0xa

    new-array v13, v11, [B

    aput-byte v7, v13, v7

    const/16 v14, 0x78

    aput-byte v14, v13, v6

    const/16 v14, -0x7d

    aput-byte v14, v13, v9

    const/4 v14, 0x3

    aput-byte v27, v13, v14

    const/16 v14, -0x6f

    const/4 v15, 0x4

    aput-byte v14, v13, v15

    const/16 v14, -0x75

    aput-byte v14, v13, v16

    const/16 v14, 0x3c

    aput-byte v14, v13, v17

    const/16 v14, -0xf

    const/4 v15, 0x7

    aput-byte v14, v13, v15

    const/16 v14, 0x8

    aput-byte v25, v13, v14

    const/16 v15, 0x7e

    const/16 v21, 0x9

    aput-byte v15, v13, v21

    new-array v15, v14, [B

    const/16 v14, 0x76

    aput-byte v14, v15, v7

    aput-byte v28, v15, v6

    const/16 v14, -0x19

    aput-byte v14, v15, v9

    const/16 v14, 0x55

    const/16 v20, 0x3

    aput-byte v14, v15, v20

    const/4 v14, -0x2

    const/16 v22, 0x4

    aput-byte v14, v15, v22

    const/16 v14, -0x2c

    aput-byte v14, v15, v16

    const/16 v14, 0x55

    aput-byte v14, v15, v17

    const/16 v14, -0x61

    const/16 v22, 0x7

    aput-byte v14, v15, v22

    invoke-static {v13, v15}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v13

    invoke-virtual {v12, v13}, Lorg/json/JSONObject;->optJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v12

    const/4 v13, 0x3

    new-array v14, v13, [B

    const/16 v13, -0x6a

    aput-byte v13, v14, v7

    const/16 v13, -0x51

    aput-byte v13, v14, v6

    const/16 v13, -0x2e

    aput-byte v13, v14, v9

    const/16 v13, 0x8

    new-array v15, v13, [B

    const/16 v19, -0x1d

    aput-byte v19, v15, v7

    const/16 v19, -0x23

    aput-byte v19, v15, v6

    const/16 v19, -0x42

    aput-byte v19, v15, v9

    const/16 v19, 0x48

    const/16 v20, 0x3

    aput-byte v19, v15, v20

    const/16 v19, 0x6c

    const/16 v22, 0x4

    aput-byte v19, v15, v22

    const/16 v19, -0x53

    aput-byte v19, v15, v16

    const/16 v19, 0x7e

    aput-byte v19, v15, v17

    const/16 v19, -0x67

    const/16 v23, 0x7

    aput-byte v19, v15, v23

    invoke-static {v14, v15}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v14

    invoke-virtual {v12, v14}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v12

    invoke-virtual {v8, v12}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :goto_61a
    add-int/lit8 v10, v10, 0x1

    const/4 v11, 0x3

    const/4 v14, 0x4

    const/16 v15, 0x8

    goto/16 :goto_4a6

    :cond_622
    invoke-virtual/range {p4 .. p4}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v5

    if-eqz v5, :cond_634

    invoke-virtual {v8}, Ljava/util/ArrayList;->size()I

    move-result v5

    if-nez v5, :cond_634

    sget-object v5, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    invoke-virtual {v1, v2, v4, v3, v5}, Lcom/github/catvod/spider/appysv2/b/U;->A(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)Ljava/util/List;

    move-result-object v8
    :try_end_634
    .catch Ljava/lang/Exception; {:try_start_417 .. :try_end_634} :catch_63e
    .catchall {:try_start_417 .. :try_end_634} :catchall_664

    :cond_634
    invoke-static/range {p1 .. p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v2

    if-nez v2, :cond_63d

    invoke-direct {v1, v4}, Lcom/github/catvod/spider/appysv2/b/U;->r(Ljava/lang/String;)V

    :cond_63d
    return-object v8

    :catch_63e
    move-exception v0

    move-object v3, v0

    goto :goto_652

    :catchall_641
    move-exception v0

    :goto_642
    move-object v3, v0

    goto :goto_64b

    :catch_644
    move-exception v0

    :goto_645
    move-object v3, v0

    goto :goto_651

    :catchall_647
    move-exception v0

    move-object/from16 v5, p2

    goto :goto_642

    :goto_64b
    move-object v4, v5

    goto :goto_666

    :catch_64d
    move-exception v0

    move-object/from16 v5, p2

    goto :goto_645

    :goto_651
    move-object v4, v5

    :goto_652
    :try_start_652
    invoke-virtual {v3}, Ljava/lang/Throwable;->printStackTrace()V

    new-instance v3, Ljava/util/ArrayList;

    invoke-direct {v3}, Ljava/util/ArrayList;-><init>()V
    :try_end_65a
    .catchall {:try_start_652 .. :try_end_65a} :catchall_664

    invoke-static/range {p1 .. p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v2

    if-nez v2, :cond_663

    invoke-direct {v1, v4}, Lcom/github/catvod/spider/appysv2/b/U;->r(Ljava/lang/String;)V

    :cond_663
    return-object v3

    :catchall_664
    move-exception v0

    move-object v3, v0

    :goto_666
    invoke-static/range {p1 .. p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v2

    if-nez v2, :cond_66f

    invoke-direct {v1, v4}, Lcom/github/catvod/spider/appysv2/b/U;->r(Ljava/lang/String;)V

    :cond_66f
    goto :goto_671

    :goto_670
    throw v3

    :goto_671
    goto :goto_670
.end method

.method public final C()J
    .registers 4

    invoke-static {}, Ljava/util/TimeZone;->getDefault()Ljava/util/TimeZone;

    move-result-object v0

    invoke-static {v0}, Ljava/util/Calendar;->getInstance(Ljava/util/TimeZone;)Ljava/util/Calendar;

    move-result-object v0

    const/16 v1, 0xb

    const/4 v2, 0x0

    invoke-virtual {v0, v1, v2}, Ljava/util/Calendar;->set(II)V

    const/16 v1, 0xc

    invoke-virtual {v0, v1, v2}, Ljava/util/Calendar;->set(II)V

    const/16 v1, 0xd

    invoke-virtual {v0, v1, v2}, Ljava/util/Calendar;->set(II)V

    const/16 v1, 0xe

    invoke-virtual {v0, v1, v2}, Ljava/util/Calendar;->set(II)V

    invoke-virtual {v0}, Ljava/util/Calendar;->getTimeInMillis()J

    move-result-wide v0

    return-wide v0
.end method

.method public final D()V
    .registers 25

    const/16 v1, 0xd

    const/16 v2, 0x8

    :try_start_4
    invoke-static {}, Lcom/github/catvod/spider/Init;->checkPermission()V

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v4

    invoke-virtual {v3, v4, v5}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const-string v4, ""

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-static {v3}, Lcom/github/catvod/spider/appysv2/p/C;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    const/16 v5, 0x20

    new-array v5, v5, [B

    const/16 v6, 0x46

    const/4 v7, 0x0

    aput-byte v6, v5, v7

    const/16 v6, 0x54

    const/4 v8, 0x1

    aput-byte v6, v5, v8

    const/16 v6, 0x3b

    const/4 v9, 0x2

    aput-byte v6, v5, v9

    const/16 v6, -0x74

    const/4 v10, 0x3

    aput-byte v6, v5, v10

    const/16 v6, 0x6d

    const/4 v11, 0x4

    aput-byte v6, v5, v11

    const/16 v6, 0x4f

    const/4 v12, 0x5

    aput-byte v6, v5, v12

    const/16 v6, 0x60

    const/4 v13, 0x6

    aput-byte v6, v5, v13

    const/16 v6, -0x26

    const/4 v14, 0x7

    aput-byte v6, v5, v14

    const/16 v6, 0x41

    aput-byte v6, v5, v2

    const/16 v6, 0x9

    aput-byte v9, v5, v6

    const/16 v6, 0x3a

    const/16 v15, 0xa

    aput-byte v6, v5, v15

    const/16 v6, -0x23

    const/16 v15, 0xb

    aput-byte v6, v5, v15

    const/16 v6, 0x61

    const/16 v15, 0xc

    aput-byte v6, v5, v15

    const/16 v6, 0x42

    aput-byte v6, v5, v1

    const/16 v1, 0x62

    const/16 v6, 0xe

    aput-byte v1, v5, v6

    const/16 v1, -0x74

    const/16 v16, 0xf

    aput-byte v1, v5, v16

    const/16 v1, 0x11

    const/16 v16, 0x10

    aput-byte v1, v5, v16

    const/16 v1, 0x11

    aput-byte v9, v5, v1

    const/16 v1, 0x12

    const/16 v17, 0x68

    aput-byte v17, v5, v1

    const/16 v1, 0x13

    const/16 v17, -0x22

    aput-byte v17, v5, v1

    const/16 v1, 0x65

    const/16 v17, 0x14

    aput-byte v1, v5, v17

    const/16 v1, 0x15

    aput-byte v1, v5, v1

    const/16 v1, 0x16

    const/16 v18, 0x62

    aput-byte v18, v5, v1

    const/16 v1, 0x17

    const/16 v18, -0x23

    aput-byte v18, v5, v1

    const/16 v1, 0x18

    const/16 v18, 0x45

    aput-byte v18, v5, v1

    const/16 v1, 0x19

    aput-byte v7, v5, v1

    const/16 v18, 0x6d

    const/16 v19, 0x1a

    aput-byte v18, v5, v19

    const/16 v18, 0x1b

    const/16 v20, -0x25

    aput-byte v20, v5, v18

    const/16 v18, 0x1c

    const/16 v20, 0x6c

    aput-byte v20, v5, v18

    const/16 v18, 0x16

    const/16 v20, 0x1d

    aput-byte v18, v5, v20

    const/16 v18, 0x1e

    const/16 v21, 0x33

    aput-byte v21, v5, v18

    const/16 v18, 0x1f

    const/16 v21, -0x77

    aput-byte v21, v5, v18

    new-array v1, v2, [B

    const/16 v21, 0x73

    aput-byte v21, v1, v7

    const/16 v21, 0x35

    aput-byte v21, v1, v8

    const/16 v21, 0x58

    aput-byte v21, v1, v9

    const/16 v21, -0x16

    aput-byte v21, v1, v10

    const/16 v21, 0x55

    aput-byte v21, v1, v11

    const/16 v21, 0x77

    aput-byte v21, v1, v12

    const/16 v21, 0x52

    aput-byte v21, v1, v13

    const/16 v21, -0x42

    aput-byte v21, v1, v14

    invoke-static {v5, v1}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v1

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v5, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-static {v5}, Lcom/github/catvod/spider/appysv2/p/C;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    const/16 v6, 0x15e

    new-array v6, v6, [B

    const/16 v22, -0x23

    aput-byte v22, v6, v7

    const/16 v22, -0x4d

    aput-byte v22, v6, v8

    const/16 v22, 0x6f

    aput-byte v22, v6, v9

    const/16 v22, -0x5f

    aput-byte v22, v6, v10

    const/16 v22, -0x1f

    aput-byte v22, v6, v11

    const/16 v22, -0x61

    aput-byte v22, v6, v12

    const/16 v22, 0x53

    aput-byte v22, v6, v13

    const/16 v22, -0x75

    aput-byte v22, v6, v14

    const/16 v22, -0x26

    aput-byte v22, v6, v2

    const/16 v22, -0x49

    const/16 v23, 0x9

    aput-byte v22, v6, v23

    const/16 v22, 0x7e

    const/16 v23, 0xa

    aput-byte v22, v6, v23

    const/16 v22, -0x41

    const/16 v23, 0xb

    aput-byte v22, v6, v23

    const/16 v22, -0x41

    aput-byte v22, v6, v15

    const/16 v22, -0x3c

    const/16 v23, 0xd

    aput-byte v22, v6, v23

    const/16 v21, 0xe

    aput-byte v15, v6, v21

    const/16 v22, -0x33

    const/16 v23, 0xf

    aput-byte v22, v6, v23

    const/16 v22, -0x68

    aput-byte v22, v6, v16

    const/16 v22, 0x11

    const/16 v23, -0x5d

    aput-byte v23, v6, v22

    const/16 v22, 0x12

    const/16 v23, 0x69

    aput-byte v23, v6, v22

    const/16 v22, 0x13

    const/16 v23, -0x48

    aput-byte v23, v6, v22

    const/16 v22, -0x1c

    aput-byte v22, v6, v17

    const/16 v22, -0x40

    const/16 v23, 0x15

    aput-byte v22, v6, v23

    const/16 v22, 0x16

    const/16 v23, 0x52

    aput-byte v23, v6, v22

    const/16 v22, 0x17

    const/16 v23, -0x2f

    aput-byte v23, v6, v22

    const/16 v22, 0x18

    const/16 v23, -0x2a

    aput-byte v23, v6, v22

    const/16 v22, -0x17

    const/16 v18, 0x19

    aput-byte v22, v6, v18

    const/16 v22, 0x78

    aput-byte v22, v6, v19

    const/16 v22, 0x1b

    const/16 v23, -0x41

    aput-byte v23, v6, v22

    const/16 v22, 0x1c

    const/16 v23, -0x43

    aput-byte v23, v6, v22

    const/16 v22, -0x36

    aput-byte v22, v6, v20

    const/16 v22, 0x1e

    aput-byte v20, v6, v22

    const/16 v22, 0x1f

    const/16 v23, -0x2f

    aput-byte v23, v6, v22

    const/16 v22, 0x20

    const/16 v23, -0x3f

    aput-byte v23, v6, v22

    const/16 v22, 0x21

    const/16 v23, -0x51

    aput-byte v23, v6, v22

    const/16 v22, 0x22

    const/16 v23, 0x34

    aput-byte v23, v6, v22

    const/16 v22, 0x23

    const/16 v23, -0x50

    aput-byte v23, v6, v22

    const/16 v22, 0x24

    const/16 v23, -0x19

    aput-byte v23, v6, v22

    const/16 v22, 0x25

    const/16 v23, -0x2f

    aput-byte v23, v6, v22

    const/16 v22, 0x26

    aput-byte v17, v6, v22

    const/16 v22, 0x27

    const/16 v23, -0x35

    aput-byte v23, v6, v22

    const/16 v22, 0x28

    const/16 v23, -0x39

    aput-byte v23, v6, v22

    const/16 v22, 0x29

    const/16 v23, -0x52

    aput-byte v23, v6, v22

    const/16 v22, 0x2a

    const/16 v23, 0x61

    aput-byte v23, v6, v22

    const/16 v22, 0x2b

    const/16 v23, -0x4c

    aput-byte v23, v6, v22

    const/16 v22, 0x2c

    const/16 v23, -0x53

    aput-byte v23, v6, v22

    const/16 v22, 0x2d

    const/16 v23, -0x29

    aput-byte v23, v6, v22

    const/16 v22, 0x2e

    const/16 v18, 0x19

    aput-byte v18, v6, v22

    const/16 v22, 0x2f

    const/16 v23, -0x2b

    aput-byte v23, v6, v22

    const/16 v22, 0x30

    const/16 v23, -0x16

    aput-byte v23, v6, v22

    const/16 v22, 0x31

    const/16 v23, -0x52

    aput-byte v23, v6, v22

    const/16 v22, 0x32

    const/16 v23, 0x7f

    aput-byte v23, v6, v22

    const/16 v22, 0x33

    const/16 v23, -0x14

    aput-byte v23, v6, v22

    const/16 v22, 0x34

    const/16 v23, -0x49

    aput-byte v23, v6, v22

    const/16 v22, 0x35

    const/16 v23, -0x2a

    aput-byte v23, v6, v22

    const/16 v22, 0x36

    const/16 v23, 0x5a

    aput-byte v23, v6, v22

    const/16 v22, 0x37

    const/16 v23, -0x3b

    aput-byte v23, v6, v22

    const/16 v22, 0x38

    const/16 v23, -0x2a

    aput-byte v23, v6, v22

    const/16 v22, 0x39

    const/16 v23, -0x5c

    aput-byte v23, v6, v22

    const/16 v22, 0x3a

    const/16 v23, 0x7e

    aput-byte v23, v6, v22

    const/16 v22, 0x3b

    const/16 v23, -0x5e

    aput-byte v23, v6, v22

    const/16 v22, 0x3c

    const/16 v23, -0x1f

    aput-byte v23, v6, v22

    const/16 v22, 0x3d

    const/16 v23, -0x6

    aput-byte v23, v6, v22

    const/16 v22, 0x3e

    aput-byte v2, v6, v22

    const/16 v22, 0x3f

    const/16 v23, -0x35

    aput-byte v23, v6, v22

    const/16 v22, 0x40

    const/16 v23, -0x22

    aput-byte v23, v6, v22

    const/16 v22, 0x41

    const/16 v23, -0x5e

    aput-byte v23, v6, v22

    const/16 v22, 0x42

    const/16 v23, 0x75

    aput-byte v23, v6, v22

    const/16 v22, 0x43

    const/16 v23, -0x14

    aput-byte v23, v6, v22

    const/16 v22, 0x44

    const/16 v23, -0x4c

    aput-byte v23, v6, v22

    const/16 v22, 0x45

    const/16 v23, -0x3c

    aput-byte v23, v6, v22

    const/16 v22, 0x46

    aput-byte v15, v6, v22

    const/16 v22, 0x47

    const/16 v23, -0x2c

    aput-byte v23, v6, v22

    const/16 v22, 0x48

    const/16 v23, -0x16

    aput-byte v23, v6, v22

    const/16 v22, 0x49

    const/16 v23, -0x4f

    aput-byte v23, v6, v22

    const/16 v22, 0x4a

    const/16 v23, 0x7e

    aput-byte v23, v6, v22

    const/16 v22, 0x4b

    const/16 v23, -0x5d

    aput-byte v23, v6, v22

    const/16 v22, 0x4c

    const/16 v23, -0x51

    aput-byte v23, v6, v22

    const/16 v22, 0x4d

    const/16 v23, -0x6c

    aput-byte v23, v6, v22

    const/16 v22, 0x4e

    const/16 v23, 0x52

    aput-byte v23, v6, v22

    const/16 v22, 0x4f

    const/16 v23, -0x6e

    aput-byte v23, v6, v22

    const/16 v22, 0x50

    const/16 v23, -0x65

    aput-byte v23, v6, v22

    const/16 v22, 0x51

    const/16 v23, -0x1

    aput-byte v23, v6, v22

    const/16 v22, 0x52

    const/16 v23, 0x3d

    aput-byte v23, v6, v22

    const/16 v22, 0x53

    const/16 v23, -0x4b

    aput-byte v23, v6, v22

    const/16 v22, 0x54

    const/16 v23, -0x9

    aput-byte v23, v6, v22

    const/16 v22, 0x55

    const/16 v23, -0x2d

    aput-byte v23, v6, v22

    const/16 v22, 0x56

    const/16 v23, 0x15

    aput-byte v23, v6, v22

    const/16 v22, 0x57

    const/16 v23, -0x39

    aput-byte v23, v6, v22

    const/16 v22, 0x58

    const/16 v23, -0x30

    aput-byte v23, v6, v22

    const/16 v22, 0x59

    const/16 v23, -0x68

    aput-byte v23, v6, v22

    const/16 v22, 0x5a

    const/16 v23, 0x72

    aput-byte v23, v6, v22

    const/16 v22, 0x5b

    const/16 v23, -0x4b

    aput-byte v23, v6, v22

    const/16 v22, 0x5c

    const/16 v23, -0x51

    aput-byte v23, v6, v22

    const/16 v22, 0x5d

    const/16 v23, -0x80

    aput-byte v23, v6, v22

    const/16 v22, 0x5e

    const/16 v23, 0xf

    aput-byte v23, v6, v22

    const/16 v22, 0x5f

    const/16 v23, -0x7e

    aput-byte v23, v6, v22

    const/16 v22, 0x60

    const/16 v23, -0x2f

    aput-byte v23, v6, v22

    const/16 v22, 0x61

    const/16 v23, -0x5e

    aput-byte v23, v6, v22

    const/16 v22, 0x62

    const/16 v23, 0x6d

    aput-byte v23, v6, v22

    const/16 v22, 0x63

    const/16 v23, -0x48

    aput-byte v23, v6, v22

    const/16 v22, 0x64

    const/16 v23, -0xf

    aput-byte v23, v6, v22

    const/16 v22, 0x65

    const/16 v23, -0x40

    aput-byte v23, v6, v22

    const/16 v22, 0x66

    const/16 v23, 0x23

    aput-byte v23, v6, v22

    const/16 v22, 0x67

    const/16 v23, -0x3a

    aput-byte v23, v6, v22

    const/16 v22, 0x68

    const/16 v23, -0x39

    aput-byte v23, v6, v22

    const/16 v22, 0x69

    const/16 v23, -0x5a

    aput-byte v23, v6, v22

    const/16 v22, 0x6a

    const/16 v23, 0x75

    aput-byte v23, v6, v22

    const/16 v22, 0x6b

    const/16 v23, -0x4b

    aput-byte v23, v6, v22

    const/16 v22, 0x6c

    const/16 v23, -0x51

    aput-byte v23, v6, v22

    const/16 v22, 0x6d

    const/16 v23, -0x2d

    aput-byte v23, v6, v22

    const/16 v22, 0x6e

    const/16 v23, 0x15

    aput-byte v23, v6, v22

    const/16 v22, 0x6f

    const/16 v23, -0x2e

    aput-byte v23, v6, v22

    const/16 v22, 0x70

    const/16 v23, -0x26

    aput-byte v23, v6, v22

    const/16 v22, 0x71

    const/16 v23, -0x1f

    aput-byte v23, v6, v22

    const/16 v22, 0x72

    const/16 v23, 0x6b

    aput-byte v23, v6, v22

    const/16 v22, 0x73

    const/16 v23, -0x43

    aput-byte v23, v6, v22

    const/16 v22, 0x74

    const/16 v23, -0xd

    aput-byte v23, v6, v22

    const/16 v22, 0x75

    const/16 v23, -0x2f

    aput-byte v23, v6, v22

    const/16 v22, 0x76

    aput-byte v19, v6, v22

    const/16 v22, 0x77

    const/16 v23, -0x35

    aput-byte v23, v6, v22

    const/16 v22, 0x78

    const/16 v23, -0x39

    aput-byte v23, v6, v22

    const/16 v22, 0x79

    const/16 v23, -0x56

    aput-byte v23, v6, v22

    const/16 v22, 0x7a

    const/16 v23, 0x26

    aput-byte v23, v6, v22

    const/16 v22, 0x7b

    const/16 v23, -0x5b

    aput-byte v23, v6, v22

    const/16 v22, 0x7c

    const/16 v23, -0x1c

    aput-byte v23, v6, v22

    const/16 v22, 0x7d

    const/16 v23, -0x7d

    aput-byte v23, v6, v22

    const/16 v22, 0x7e

    const/16 v23, 0x18

    aput-byte v23, v6, v22

    const/16 v22, 0x7f

    const/16 v23, -0x3f

    aput-byte v23, v6, v22

    const/16 v22, 0x80

    const/16 v23, -0x3d

    aput-byte v23, v6, v22

    const/16 v22, 0x81

    const/16 v23, -0x52

    aput-byte v23, v6, v22

    const/16 v22, 0x82

    const/16 v23, 0x78

    aput-byte v23, v6, v22

    const/16 v22, 0x83

    const/16 v23, -0x4c

    aput-byte v23, v6, v22

    const/16 v22, 0x84

    const/16 v23, -0x33

    aput-byte v23, v6, v22

    const/16 v22, 0x85

    const/16 v23, -0x35

    aput-byte v23, v6, v22

    const/16 v22, 0x86

    aput-byte v20, v6, v22

    const/16 v22, 0x87

    const/16 v23, -0x37

    aput-byte v23, v6, v22

    const/16 v22, 0x88

    const/16 v23, -0x30

    aput-byte v23, v6, v22

    const/16 v22, 0x89

    const/16 v23, -0x6

    aput-byte v23, v6, v22

    const/16 v22, 0x8a

    const/16 v23, 0x4d

    aput-byte v23, v6, v22

    const/16 v22, 0x8b

    const/16 v23, -0x1d

    aput-byte v23, v6, v22

    const/16 v22, 0x8c

    const/16 v23, -0x60

    aput-byte v23, v6, v22

    const/16 v22, 0x8d

    const/16 v23, -0x6a

    aput-byte v23, v6, v22

    const/16 v22, 0x8e

    const/16 v23, 0x44

    aput-byte v23, v6, v22

    const/16 v22, 0x8f

    const/16 v23, -0x1b

    aput-byte v23, v6, v22

    const/16 v22, 0x90

    const/16 v23, -0x6d

    aput-byte v23, v6, v22

    const/16 v22, 0x91

    const/16 v23, -0x5d

    aput-byte v23, v6, v22

    const/16 v22, 0x92

    const/16 v23, 0x7e

    aput-byte v23, v6, v22

    const/16 v22, 0x93

    const/16 v23, -0x59

    aput-byte v23, v6, v22

    const/16 v22, 0x94

    const/16 v23, -0x5

    aput-byte v23, v6, v22

    const/16 v22, 0x95

    const/16 v23, -0x3a

    aput-byte v23, v6, v22

    const/16 v22, 0x96

    const/16 v18, 0x19

    aput-byte v18, v6, v22

    const/16 v22, 0x97

    const/16 v23, -0x5

    aput-byte v23, v6, v22

    const/16 v22, 0x98

    const/16 v23, -0x28

    aput-byte v23, v6, v22

    const/16 v22, 0x99

    const/16 v23, -0x58

    aput-byte v23, v6, v22

    const/16 v22, 0x9a

    const/16 v23, 0x7f

    aput-byte v23, v6, v22

    const/16 v22, 0x9b

    const/16 v23, -0x4c

    aput-byte v23, v6, v22

    const/16 v22, 0x9c

    const/16 v23, -0x2

    aput-byte v23, v6, v22

    const/16 v22, 0x9d

    const/16 v23, -0x68

    aput-byte v23, v6, v22

    const/16 v22, 0x9e

    const/16 v23, 0x2a

    aput-byte v23, v6, v22

    const/16 v22, 0x9f

    const/16 v23, -0x6a

    aput-byte v23, v6, v22

    const/16 v22, 0xa0

    const/16 v23, -0x79

    aput-byte v23, v6, v22

    const/16 v22, 0xa1

    const/16 v23, -0xc

    aput-byte v23, v6, v22

    const/16 v22, 0xa2

    const/16 v23, 0x23

    aput-byte v23, v6, v22

    const/16 v22, 0xa3

    const/16 v23, -0x70

    aput-byte v23, v6, v22

    const/16 v22, 0xa4

    const/16 v23, -0x4c

    aput-byte v23, v6, v22

    const/16 v22, 0xa5

    const/16 v23, -0x39

    aput-byte v23, v6, v22

    const/16 v22, 0xa6

    const/16 v23, 0x9

    aput-byte v23, v6, v22

    const/16 v22, 0xa7

    const/16 v23, -0x33

    aput-byte v23, v6, v22

    const/16 v22, 0xa8

    const/16 v23, -0x27

    aput-byte v23, v6, v22

    const/16 v22, 0xa9

    const/16 v23, -0x5d

    aput-byte v23, v6, v22

    const/16 v22, 0xaa

    const/16 v23, 0x44

    aput-byte v23, v6, v22

    const/16 v22, 0xab

    const/16 v23, -0x4b

    aput-byte v23, v6, v22

    const/16 v22, 0xac

    const/16 v23, -0x9

    aput-byte v23, v6, v22

    const/16 v22, 0xad

    const/16 v23, -0x2d

    aput-byte v23, v6, v22

    const/16 v22, 0xae

    const/16 v23, 0x15

    aput-byte v23, v6, v22

    const/16 v22, 0xaf

    const/16 v23, -0x39

    aput-byte v23, v6, v22

    const/16 v22, 0xb0

    const/16 v23, -0x30

    aput-byte v23, v6, v22

    const/16 v22, 0xb1

    const/16 v23, -0x6

    aput-byte v23, v6, v22

    const/16 v22, 0xb2

    const/16 v23, 0x4d

    aput-byte v23, v6, v22

    const/16 v22, 0xb3

    const/16 v23, -0x1d

    aput-byte v23, v6, v22

    const/16 v22, 0xb4

    const/16 v23, -0x60

    aput-byte v23, v6, v22

    const/16 v22, 0xb5

    const/16 v23, -0x6a

    aput-byte v23, v6, v22

    const/16 v22, 0xb6

    const/16 v23, 0x44

    aput-byte v23, v6, v22

    const/16 v22, 0xb7

    const/16 v23, -0x1b

    aput-byte v23, v6, v22

    const/16 v22, 0xb8

    const/16 v23, -0x6d

    aput-byte v23, v6, v22

    const/16 v22, 0xb9

    const/16 v23, -0x5b

    aput-byte v23, v6, v22

    const/16 v22, 0xba

    const/16 v23, 0x6e

    aput-byte v23, v6, v22

    const/16 v22, 0xbb

    const/16 v23, -0x48

    aput-byte v23, v6, v22

    const/16 v22, 0xbc

    const/16 v23, -0x2

    aput-byte v23, v6, v22

    const/16 v22, 0xbd

    const/16 v23, -0x3f

    aput-byte v23, v6, v22

    const/16 v22, 0xbe

    const/16 v23, 0x23

    aput-byte v23, v6, v22

    const/16 v22, 0xbf

    const/16 v23, -0x2c

    aput-byte v23, v6, v22

    const/16 v22, 0xc0

    const/16 v23, -0x39

    aput-byte v23, v6, v22

    const/16 v22, 0xc1

    const/16 v23, -0x58

    aput-byte v23, v6, v22

    const/16 v22, 0xc2

    const/16 v23, 0x7f

    aput-byte v23, v6, v22

    const/16 v22, 0xc3

    const/16 v23, -0x5c

    aput-byte v23, v6, v22

    const/16 v22, 0xc4

    const/16 v23, -0xf

    aput-byte v23, v6, v22

    const/16 v22, 0xc5

    const/16 v23, -0x2f

    aput-byte v23, v6, v22

    const/16 v22, 0xc6

    const/16 v23, 0x41

    aput-byte v23, v6, v22

    const/16 v22, 0xc7

    const/16 v23, -0xe

    aput-byte v23, v6, v22

    const/16 v22, 0xc8

    const/16 v23, -0x79

    aput-byte v23, v6, v22

    const/16 v22, 0xc9

    const/16 v23, -0xb

    aput-byte v23, v6, v22

    const/16 v22, 0xca

    const/16 v23, 0x28

    aput-byte v23, v6, v22

    const/16 v22, 0xcb

    const/16 v23, -0x17

    aput-byte v23, v6, v22

    const/16 v22, 0xcc

    const/16 v23, -0x2d

    aput-byte v23, v6, v22

    const/16 v22, 0xcd

    const/16 v23, -0x7d

    aput-byte v23, v6, v22

    const/16 v22, 0xce

    const/16 v23, 0x18

    aput-byte v23, v6, v22

    const/16 v22, 0xcf

    const/16 v23, -0x3f

    aput-byte v23, v6, v22

    const/16 v22, 0xd0

    const/16 v23, -0x3d

    aput-byte v23, v6, v22

    const/16 v22, 0xd1

    const/16 v23, -0x52

    aput-byte v23, v6, v22

    const/16 v22, 0xd2

    const/16 v23, 0x78

    aput-byte v23, v6, v22

    const/16 v22, 0xd3

    const/16 v23, -0x4c

    aput-byte v23, v6, v22

    const/16 v22, 0xd4

    const/16 v23, -0x33

    aput-byte v23, v6, v22

    const/16 v22, 0xd5

    const/16 v23, -0x3e

    aput-byte v23, v6, v22

    const/16 v22, 0xd6

    aput-byte v15, v6, v22

    const/16 v15, 0xd7

    const/16 v22, -0x2f

    aput-byte v22, v6, v15

    const/16 v15, 0xd8

    const/16 v22, -0x78

    aput-byte v22, v6, v15

    const/16 v15, 0xd9

    const/16 v22, -0x7a

    aput-byte v22, v6, v15

    const/16 v15, 0xda

    const/16 v22, 0x7f

    aput-byte v22, v6, v15

    const/16 v15, 0xdb

    const/16 v22, -0x5d

    aput-byte v22, v6, v15

    const/16 v15, 0xdc

    const/16 v22, -0x9

    aput-byte v22, v6, v15

    const/16 v15, 0xdd

    const/16 v22, -0x35

    aput-byte v22, v6, v15

    const/16 v15, 0xde

    const/16 v22, 0x13

    aput-byte v22, v6, v15

    const/16 v15, 0xdf

    const/16 v22, -0x74

    aput-byte v22, v6, v15

    const/16 v15, 0xe0

    const/16 v22, -0x1f

    aput-byte v22, v6, v15

    const/16 v15, 0xe1

    const/16 v22, -0x76

    aput-byte v22, v6, v15

    const/16 v15, 0xe2

    const/16 v22, 0x32

    aput-byte v22, v6, v15

    const/16 v15, 0xe3

    const/16 v22, -0x19

    aput-byte v22, v6, v15

    const/16 v15, 0xe4

    const/16 v22, -0x5a

    aput-byte v22, v6, v15

    const/16 v15, 0xe5

    const/16 v22, -0x6b

    aput-byte v22, v6, v15

    const/16 v15, 0xe6

    const/16 v22, 0x5a

    aput-byte v22, v6, v15

    const/16 v15, 0xe7

    const/16 v22, -0x3b

    aput-byte v22, v6, v15

    const/16 v15, 0xe8

    const/16 v22, -0x2a

    aput-byte v22, v6, v15

    const/16 v15, 0xe9

    const/16 v22, -0x4d

    aput-byte v22, v6, v15

    const/16 v15, 0xea

    const/16 v22, 0x72

    aput-byte v22, v6, v15

    const/16 v15, 0xeb

    const/16 v22, -0x59

    aput-byte v22, v6, v15

    const/16 v15, 0xec

    const/16 v22, -0x5

    aput-byte v22, v6, v15

    const/16 v15, 0xed

    const/16 v22, -0x2f

    aput-byte v22, v6, v15

    const/16 v15, 0xee

    aput-byte v12, v6, v15

    const/16 v15, 0xef

    const/16 v22, -0x5

    aput-byte v22, v6, v15

    const/16 v15, 0xf0

    const/16 v22, -0x39

    aput-byte v22, v6, v15

    const/16 v15, 0xf1

    const/16 v22, -0x5e

    aput-byte v22, v6, v15

    const/16 v15, 0xf2

    const/16 v22, 0x78

    aput-byte v22, v6, v15

    const/16 v15, 0xf3

    const/16 v22, -0x5b

    aput-byte v22, v6, v15

    const/16 v15, 0xf4

    const/16 v22, -0x51

    aput-byte v22, v6, v15

    const/16 v15, 0xf5

    const/16 v22, -0x6e

    aput-byte v22, v6, v15

    const/16 v15, 0xf6

    const/16 v22, 0x38

    aput-byte v22, v6, v15

    const/16 v15, 0xf7

    const/16 v22, -0x7e

    aput-byte v22, v6, v15

    const/16 v15, 0xf8

    const/16 v22, -0x2a

    aput-byte v22, v6, v15

    const/16 v15, 0xf9

    const/16 v22, -0x51

    aput-byte v22, v6, v15

    const/16 v15, 0xfa

    const/16 v22, 0x7a

    aput-byte v22, v6, v15

    const/16 v15, 0xfb

    const/16 v22, -0x41

    aput-byte v22, v6, v15

    const/16 v15, 0xfc

    const/16 v22, -0x4

    aput-byte v22, v6, v15

    const/16 v15, 0xfd

    const/16 v22, -0x40

    aput-byte v22, v6, v15

    const/16 v15, 0xfe

    aput-byte v16, v6, v15

    const/16 v15, 0xff

    const/16 v22, -0x67

    aput-byte v22, v6, v15

    const/16 v15, 0x100

    const/16 v22, -0x20

    aput-byte v22, v6, v15

    const/16 v15, 0x101

    const/16 v22, -0x7c

    aput-byte v22, v6, v15

    const/16 v15, 0x102

    const/16 v22, 0x4f

    aput-byte v22, v6, v15

    const/16 v15, 0x103

    const/16 v22, -0x79

    aput-byte v22, v6, v15

    const/16 v15, 0x104

    const/16 v22, -0x23

    aput-byte v22, v6, v15

    const/16 v15, 0x105

    const/16 v22, -0x1d

    aput-byte v22, v6, v15

    const/16 v15, 0x106

    const/16 v22, 0x3a

    aput-byte v22, v6, v15

    const/16 v15, 0x107

    const/16 v22, -0x13

    aput-byte v22, v6, v15

    const/16 v15, 0x108

    const/16 v22, -0xa

    aput-byte v22, v6, v15

    const/16 v15, 0x109

    const/16 v22, -0x72

    aput-byte v22, v6, v15

    const/16 v15, 0x10a

    const/16 v22, 0x5a

    aput-byte v22, v6, v15

    const/16 v15, 0x10b

    const/16 v22, -0x63

    aput-byte v22, v6, v15

    const/16 v15, 0x10c

    const/16 v22, -0x3b

    aput-byte v22, v6, v15

    const/16 v15, 0x10d

    const/16 v22, -0x20

    aput-byte v22, v6, v15

    const/16 v15, 0x10e

    const/16 v22, 0x3e

    aput-byte v22, v6, v15

    const/16 v15, 0x10f

    const/16 v22, -0x7e

    aput-byte v22, v6, v15

    const/16 v15, 0x110

    const/16 v22, -0x2c

    aput-byte v22, v6, v15

    const/16 v15, 0x111

    const/16 v22, -0x4e

    aput-byte v22, v6, v15

    const/16 v15, 0x112

    const/16 v22, 0x6f

    aput-byte v22, v6, v15

    const/16 v15, 0x113

    const/16 v22, -0x47

    aput-byte v22, v6, v15

    const/16 v15, 0x114

    const/16 v22, -0x33

    aput-byte v22, v6, v15

    const/16 v15, 0x115

    const/16 v22, -0x2f

    aput-byte v22, v6, v15

    const/16 v15, 0x116

    aput-byte v12, v6, v15

    const/16 v15, 0x117

    const/16 v22, -0x2c

    aput-byte v22, v6, v15

    const/16 v15, 0x118

    const/16 v22, -0x30

    aput-byte v22, v6, v15

    const/16 v15, 0x119

    const/16 v22, -0x6

    aput-byte v22, v6, v15

    const/16 v15, 0x11a

    const/16 v22, 0x78

    aput-byte v22, v6, v15

    const/16 v15, 0x11b

    const/16 v22, -0x42

    aput-byte v22, v6, v15

    const/16 v15, 0x11c

    const/16 v22, -0xa

    aput-byte v22, v6, v15

    const/16 v15, 0x11d

    const/16 v22, -0x40

    aput-byte v22, v6, v15

    const/16 v15, 0x11e

    const/16 v22, 0x5a

    aput-byte v22, v6, v15

    const/16 v15, 0x11f

    const/16 v22, -0x39

    aput-byte v22, v6, v15

    const/16 v15, 0x120

    const/16 v22, -0x27

    aput-byte v22, v6, v15

    const/16 v15, 0x121

    const/16 v22, -0x52

    aput-byte v22, v6, v15

    const/16 v15, 0x122

    const/16 v22, 0x7e

    aput-byte v22, v6, v15

    const/16 v15, 0x123

    const/16 v22, -0x41

    aput-byte v22, v6, v15

    const/16 v15, 0x124

    const/16 v22, -0x1a

    aput-byte v22, v6, v15

    const/16 v15, 0x125

    const/16 v22, -0x6

    aput-byte v22, v6, v15

    const/16 v15, 0x126

    const/16 v22, 0x15

    aput-byte v22, v6, v15

    const/16 v15, 0x127

    const/16 v22, -0x40

    aput-byte v22, v6, v15

    const/16 v15, 0x128

    const/16 v22, -0x78

    aput-byte v22, v6, v15

    const/16 v15, 0x129

    const/16 v22, -0x1e

    aput-byte v22, v6, v15

    const/16 v15, 0x12a

    const/16 v22, 0x68

    aput-byte v22, v6, v15

    const/16 v15, 0x12b

    const/16 v22, -0x1a

    aput-byte v22, v6, v15

    const/16 v15, 0x12c

    const/16 v22, -0x4c

    aput-byte v22, v6, v15

    const/16 v15, 0x12d

    const/16 v22, -0x2a

    aput-byte v22, v6, v15

    const/16 v15, 0x12e

    const/16 v22, 0x1f

    aput-byte v22, v6, v15

    const/16 v15, 0x12f

    const/16 v22, -0x35

    aput-byte v22, v6, v15

    const/16 v15, 0x130

    const/16 v22, -0x3b

    aput-byte v22, v6, v15

    const/16 v15, 0x131

    const/16 v22, -0x5e

    aput-byte v22, v6, v15

    const/16 v15, 0x132

    const/16 v22, 0x26

    aput-byte v22, v6, v15

    const/16 v15, 0x133

    const/16 v22, -0x41

    aput-byte v22, v6, v15

    const/16 v15, 0x134

    const/16 v22, -0x9

    aput-byte v22, v6, v15

    const/16 v15, 0x135

    const/16 v22, -0x2f

    aput-byte v22, v6, v15

    const/16 v15, 0x136

    const/16 v22, 0x18

    aput-byte v22, v6, v15

    const/16 v15, 0x137

    const/16 v22, -0x33

    aput-byte v22, v6, v15

    const/16 v15, 0x138

    const/16 v22, -0x3a

    aput-byte v22, v6, v15

    const/16 v15, 0x139

    const/16 v22, -0x54

    aput-byte v22, v6, v15

    const/16 v15, 0x13a

    const/16 v22, 0x3d

    aput-byte v22, v6, v15

    const/16 v15, 0x13b

    const/16 v22, -0x60

    aput-byte v22, v6, v15

    const/16 v15, 0x13c

    const/16 v22, -0x20

    aput-byte v22, v6, v15

    const/16 v15, 0x13d

    const/16 v22, -0x3a

    aput-byte v22, v6, v15

    const/16 v15, 0x13e

    const/16 v22, 0x13

    aput-byte v22, v6, v15

    const/16 v15, 0x13f

    const/16 v22, -0x40

    aput-byte v22, v6, v15

    const/16 v15, 0x140

    const/16 v22, -0x30

    aput-byte v22, v6, v15

    const/16 v15, 0x141

    const/16 v22, -0x6

    aput-byte v22, v6, v15

    const/16 v15, 0x142

    const/16 v22, 0x2a

    aput-byte v22, v6, v15

    const/16 v15, 0x143

    const/16 v22, -0x9

    aput-byte v22, v6, v15

    const/16 v15, 0x144

    const/16 v22, -0x1d

    aput-byte v22, v6, v15

    const/16 v15, 0x145

    const/16 v22, -0x29

    aput-byte v22, v6, v15

    const/16 v15, 0x146

    const/16 v22, 0x23

    aput-byte v22, v6, v15

    const/16 v15, 0x147

    const/16 v22, -0x2d

    aput-byte v22, v6, v15

    const/16 v15, 0x148

    const/16 v22, -0x24

    aput-byte v22, v6, v15

    const/16 v15, 0x149

    const/16 v22, -0x5d

    aput-byte v22, v6, v15

    const/16 v15, 0x14a

    const/16 v22, 0x6f

    aput-byte v22, v6, v15

    const/16 v15, 0x14b

    const/16 v22, -0x47

    aput-byte v22, v6, v15

    const/16 v15, 0x14c

    const/16 v22, -0x51

    aput-byte v22, v6, v15

    const/16 v15, 0x14d

    const/16 v22, -0x6f

    aput-byte v22, v6, v15

    const/16 v15, 0x14e

    const/16 v22, 0x4a

    aput-byte v22, v6, v15

    const/16 v15, 0x14f

    const/16 v22, -0x6c

    aput-byte v22, v6, v15

    const/16 v15, 0x150

    const/16 v22, -0x6d

    aput-byte v22, v6, v15

    const/16 v15, 0x151

    const/16 v22, -0x4a

    aput-byte v22, v6, v15

    const/16 v15, 0x152

    const/16 v22, 0x69

    aput-byte v22, v6, v15

    const/16 v15, 0x153

    const/16 v22, -0x72

    aput-byte v22, v6, v15

    const/16 v15, 0x154

    const/16 v22, -0x6

    aput-byte v22, v6, v15

    const/16 v15, 0x155

    const/16 v22, -0x40

    aput-byte v22, v6, v15

    const/16 v15, 0x156

    const/16 v22, 0x15

    aput-byte v22, v6, v15

    const/16 v15, 0x157

    const/16 v22, -0x3d

    aput-byte v22, v6, v15

    const/16 v15, 0x158

    const/16 v22, -0x23

    aput-byte v22, v6, v15

    const/16 v15, 0x159

    const/16 v22, -0x4d

    aput-byte v22, v6, v15

    const/16 v15, 0x15a

    const/16 v22, 0x26

    aput-byte v22, v6, v15

    const/16 v15, 0x15b

    const/16 v22, -0x1b

    aput-byte v22, v6, v15

    const/16 v15, 0x15c

    const/16 v22, -0x5c

    aput-byte v22, v6, v15

    const/16 v15, 0x15d

    const/16 v22, -0x6b

    aput-byte v22, v6, v15

    new-array v15, v2, [B

    const/16 v22, -0x4b

    aput-byte v22, v15, v7

    const/16 v22, -0x39

    aput-byte v22, v15, v8

    const/16 v22, 0x1b

    aput-byte v22, v15, v9

    const/16 v22, -0x2f

    aput-byte v22, v15, v10

    const/16 v22, -0x6e

    aput-byte v22, v15, v11

    const/16 v22, -0x5b

    aput-byte v22, v15, v12

    const/16 v22, 0x7c

    aput-byte v22, v15, v13

    const/16 v22, -0x5c

    aput-byte v22, v15, v14

    invoke-static {v6, v15}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v6

    new-array v15, v10, [Ljava/lang/Object;

    aput-object v5, v15, v7

    aput-object v4, v15, v8

    aput-object v1, v15, v9

    invoke-static {v6, v15}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v5

    const/16 v6, 0x38

    new-array v6, v6, [B

    const/16 v15, -0x4b

    aput-byte v15, v6, v7

    const/16 v15, -0x1d

    aput-byte v15, v6, v8

    const/16 v15, 0x22

    aput-byte v15, v6, v9

    const/16 v15, 0x7f

    aput-byte v15, v6, v10

    aput-byte v12, v6, v11

    const/4 v15, -0x7

    aput-byte v15, v6, v12

    const/16 v15, -0x72

    aput-byte v15, v6, v13

    const/16 v15, -0x1c

    aput-byte v15, v6, v14

    const/16 v15, -0x7a

    aput-byte v15, v6, v2

    const/16 v15, -0x32

    const/16 v22, 0x9

    aput-byte v15, v6, v22

    const/16 v15, 0x59

    const/16 v22, 0xa

    aput-byte v15, v6, v22

    const/16 v15, 0x38

    const/16 v22, 0xb

    aput-byte v15, v6, v22

    const/16 v15, 0x5f

    const/16 v22, 0xc

    aput-byte v15, v6, v22

    const/16 v15, -0x1e

    const/16 v22, 0xd

    aput-byte v15, v6, v22

    const/16 v15, -0x79

    const/16 v21, 0xe

    aput-byte v15, v6, v21

    const/4 v15, -0x2

    const/16 v22, 0xf

    aput-byte v15, v6, v22

    const/16 v15, -0x80

    aput-byte v15, v6, v16

    const/16 v15, 0x11

    const/16 v22, -0x31

    aput-byte v22, v6, v15

    const/16 v15, 0x12

    const/16 v22, 0xc

    aput-byte v22, v6, v15

    const/16 v15, 0x13

    const/16 v23, 0x3c

    aput-byte v23, v6, v15

    aput-byte v22, v6, v17

    const/16 v15, -0x4d

    const/16 v22, 0x15

    aput-byte v15, v6, v22

    const/16 v15, 0x16

    const/16 v22, -0x64

    aput-byte v22, v6, v15

    const/16 v15, 0x17

    const/16 v22, -0x49

    aput-byte v22, v6, v15

    const/16 v15, 0x18

    const/16 v22, -0x62

    aput-byte v22, v6, v15

    const/16 v15, -0x6b

    const/16 v18, 0x19

    aput-byte v15, v6, v18

    aput-byte v12, v6, v19

    const/16 v15, 0x1b

    const/16 v22, 0x2b

    aput-byte v22, v6, v15

    const/16 v15, 0x1c

    const/16 v22, 0x5c

    aput-byte v22, v6, v15

    const/16 v15, -0x1e

    aput-byte v15, v6, v20

    const/16 v15, 0x1e

    const/16 v22, -0x75

    aput-byte v22, v6, v15

    const/16 v15, 0x1f

    const/16 v22, -0x5a

    aput-byte v22, v6, v15

    const/16 v15, 0x20

    const/16 v22, -0x7e

    aput-byte v22, v6, v15

    const/16 v15, 0x21

    const/16 v22, -0x6e

    aput-byte v22, v6, v15

    const/16 v15, 0x22

    const/16 v22, 0x44

    aput-byte v22, v6, v15

    const/16 v15, 0x23

    const/16 v22, 0x35

    aput-byte v22, v6, v15

    const/16 v15, 0x24

    aput-byte v19, v6, v15

    const/16 v15, 0x25

    const/16 v22, -0xe

    aput-byte v22, v6, v15

    const/16 v15, 0x26

    const/16 v22, -0x21

    aput-byte v22, v6, v15

    const/16 v15, 0x27

    const/16 v22, -0x17

    aput-byte v22, v6, v15

    const/16 v15, 0x28

    const/16 v22, -0x3d

    aput-byte v22, v6, v15

    const/16 v15, 0x29

    const/16 v22, -0x2d

    aput-byte v22, v6, v15

    const/16 v15, 0x2a

    const/16 v22, 0x4e

    aput-byte v22, v6, v15

    const/16 v15, 0x2b

    const/16 v22, 0x3d

    aput-byte v22, v6, v15

    const/16 v15, 0x2c

    aput-byte v20, v6, v15

    const/16 v15, 0x2d

    const/16 v22, -0x11

    aput-byte v22, v6, v15

    const/16 v15, 0x2e

    const/16 v22, -0x74

    aput-byte v22, v6, v15

    const/16 v15, 0x2f

    const/16 v22, -0x57

    aput-byte v22, v6, v15

    const/16 v15, 0x30

    const/16 v22, -0x75

    aput-byte v22, v6, v15

    const/16 v15, 0x31

    const/16 v22, -0x3d

    aput-byte v22, v6, v15

    const/16 v15, 0x32

    const/16 v22, 0x4f

    aput-byte v22, v6, v15

    const/16 v15, 0x33

    const/16 v22, 0x32

    aput-byte v22, v6, v15

    const/16 v15, 0x34

    const/16 v22, 0x41

    aput-byte v22, v6, v15

    const/16 v15, 0x35

    const/16 v22, -0x1

    aput-byte v22, v6, v15

    const/16 v15, 0x36

    const/16 v22, -0x25

    aput-byte v22, v6, v15

    const/16 v15, 0x37

    const/16 v22, -0xb

    aput-byte v22, v6, v15

    new-array v2, v2, [B

    const/16 v15, -0xe

    aput-byte v15, v2, v7

    const/16 v15, -0x5a

    aput-byte v15, v2, v8

    const/16 v15, 0x76

    aput-byte v15, v2, v9

    const/16 v15, 0x59

    aput-byte v15, v2, v10

    const/16 v15, 0x2a

    aput-byte v15, v2, v11

    const/16 v15, -0x6a

    aput-byte v15, v2, v12

    const/16 v15, -0x11

    aput-byte v15, v2, v13

    const/16 v15, -0x6f

    aput-byte v15, v2, v14

    invoke-static {v6, v2}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v2

    new-array v6, v8, [Ljava/lang/Object;

    aput-object v3, v6, v7

    invoke-static {v2, v6}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Lcom/github/catvod/spider/appysv2/p/C;->b(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    new-instance v6, Ljava/util/HashMap;

    invoke-direct {v6}, Ljava/util/HashMap;-><init>()V

    const/16 v14, 0xa

    new-array v14, v14, [B

    const/16 v15, 0x38

    aput-byte v15, v14, v7

    const/16 v15, -0xc

    aput-byte v15, v14, v8

    const/16 v15, 0x7f

    aput-byte v15, v14, v9

    const/16 v15, 0x32

    aput-byte v15, v14, v10

    aput-byte v13, v14, v11

    const/16 v15, -0x2a

    aput-byte v15, v14, v12

    const/16 v15, 0x7b

    aput-byte v15, v14, v13

    const/16 v13, -0x6d

    const/4 v15, 0x7

    aput-byte v13, v14, v15

    const/16 v13, 0x8

    aput-byte v10, v14, v13

    const/16 v15, -0xd

    const/16 v22, 0x9

    aput-byte v15, v14, v22

    new-array v13, v13, [B

    const/16 v15, 0x6d

    aput-byte v15, v13, v7

    const/16 v15, -0x79

    aput-byte v15, v13, v8

    aput-byte v19, v13, v9

    const/16 v15, 0x40

    aput-byte v15, v13, v10

    const/16 v15, 0x2b

    aput-byte v15, v13, v11

    const/16 v15, -0x69

    aput-byte v15, v13, v12

    const/16 v15, 0x1c

    const/16 v22, 0x6

    aput-byte v15, v13, v22

    const/16 v15, -0xa

    const/16 v22, 0x7

    aput-byte v15, v13, v22

    invoke-static {v14, v13}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v13

    const/16 v14, 0x78

    new-array v14, v14, [B

    const/16 v15, 0x63

    aput-byte v15, v14, v7

    const/16 v15, 0x40

    aput-byte v15, v14, v8

    aput-byte v17, v14, v9

    const/16 v15, -0x75

    aput-byte v15, v14, v10

    const/16 v15, -0x45

    aput-byte v15, v14, v11

    const/16 v15, 0x19

    aput-byte v15, v14, v12

    const/16 v12, -0x23

    const/4 v15, 0x6

    aput-byte v12, v14, v15

    const/16 v12, 0x74

    const/4 v15, 0x7

    aput-byte v12, v14, v15

    const/16 v12, 0x1b

    const/16 v15, 0x8

    aput-byte v12, v14, v15

    const/16 v12, 0x9

    aput-byte v8, v14, v12

    const/16 v12, 0x5e

    const/16 v15, 0xa

    aput-byte v12, v14, v15

    const/16 v12, -0x3e

    const/16 v15, 0xb

    aput-byte v12, v14, v15

    const/4 v12, -0x1

    const/16 v15, 0xc

    aput-byte v12, v14, v15

    const/16 v12, 0x39

    const/16 v15, 0xd

    aput-byte v12, v14, v15

    const/16 v12, -0x2b

    const/16 v15, 0xe

    aput-byte v12, v14, v15

    const/16 v12, 0x35

    const/16 v15, 0xf

    aput-byte v12, v14, v15

    const/16 v12, 0x5b

    aput-byte v12, v14, v16

    const/16 v12, 0x11

    const/16 v15, 0x57

    aput-byte v15, v14, v12

    const/16 v12, 0x12

    const/16 v15, 0x55

    aput-byte v15, v14, v12

    const/16 v12, 0x13

    const/16 v15, -0x3e

    aput-byte v15, v14, v12

    const/16 v12, -0x7e

    aput-byte v12, v14, v17

    const/16 v12, 0x4e

    const/16 v15, 0x15

    aput-byte v12, v14, v15

    const/16 v12, 0x16

    const/16 v15, -0x64

    aput-byte v15, v14, v12

    const/16 v12, 0x17

    aput-byte v19, v14, v12

    const/16 v12, 0x18

    const/16 v15, 0x40

    aput-byte v15, v14, v12

    const/16 v12, 0x4b

    const/16 v15, 0x19

    aput-byte v12, v14, v15

    const/16 v12, 0x1c

    aput-byte v12, v14, v19

    const/16 v12, 0x1b

    const/16 v15, -0x73

    aput-byte v15, v14, v12

    const/16 v12, 0x1c

    const/16 v15, -0x42

    aput-byte v15, v14, v12

    const/16 v12, 0x11

    aput-byte v12, v14, v20

    const/16 v12, 0x1e

    const/16 v15, -0x64

    aput-byte v15, v14, v12

    const/16 v12, 0x1f

    const/16 v15, 0x6a

    aput-byte v15, v14, v12

    const/16 v12, 0x20

    const/16 v15, 0x1c

    aput-byte v15, v14, v12

    const/16 v12, 0x21

    aput-byte v17, v14, v12

    const/16 v12, 0x22

    const/16 v15, 0x4e

    aput-byte v15, v14, v12

    const/16 v12, 0x23

    const/16 v15, -0x68

    aput-byte v15, v14, v12

    const/16 v12, 0x24

    const/16 v15, -0x41

    aput-byte v15, v14, v12

    const/16 v12, 0x25

    const/16 v15, 0x58

    aput-byte v15, v14, v12

    const/16 v12, 0x26

    const/16 v15, -0x21

    aput-byte v15, v14, v12

    const/16 v12, 0x27

    const/16 v15, 0x35

    aput-byte v15, v14, v12

    const/16 v12, 0x28

    const/16 v15, 0x15

    aput-byte v15, v14, v12

    const/16 v12, 0x29

    const/16 v15, 0xf

    aput-byte v15, v14, v12

    const/16 v12, 0x2a

    const/16 v15, 0x38

    aput-byte v15, v14, v12

    const/16 v12, 0x2b

    const/16 v15, -0x30

    aput-byte v15, v14, v12

    const/16 v12, 0x2c

    const/16 v15, -0x1b

    aput-byte v15, v14, v12

    const/16 v12, 0x2d

    const/16 v15, 0x46

    aput-byte v15, v14, v12

    const/16 v12, 0x2e

    const/16 v15, -0x7c

    aput-byte v15, v14, v12

    const/16 v12, 0x2f

    aput-byte v19, v14, v12

    const/16 v12, 0x30

    const/16 v15, 0xe

    aput-byte v15, v14, v12

    const/16 v12, 0x31

    const/16 v15, 0x6d

    aput-byte v15, v14, v12

    const/16 v12, 0x32

    const/16 v15, 0x1b

    aput-byte v15, v14, v12

    const/16 v12, 0x33

    const/16 v15, -0x75

    aput-byte v15, v14, v12

    const/16 v12, 0x34

    const/16 v15, -0x45

    aput-byte v15, v14, v12

    const/16 v12, 0x35

    const/16 v15, 0x11

    aput-byte v15, v14, v12

    const/16 v12, 0x36

    const/16 v15, -0x6d

    aput-byte v15, v14, v12

    const/16 v12, 0x37

    const/16 v15, 0xd

    aput-byte v15, v14, v12

    const/16 v12, 0x38

    aput-byte v19, v14, v12

    const/16 v12, 0x39

    const/16 v15, 0x1e

    aput-byte v15, v14, v12

    const/16 v12, 0x3a

    const/16 v15, 0x59

    aput-byte v15, v14, v12

    const/16 v12, 0x3b

    const/16 v15, -0x55

    aput-byte v15, v14, v12

    const/16 v12, 0x3c

    const/16 v15, -0x7b

    aput-byte v15, v14, v12

    const/16 v12, 0x3d

    const/16 v15, 0x5c

    aput-byte v15, v14, v12

    const/16 v12, 0x3e

    const/16 v15, -0x64

    aput-byte v15, v14, v12

    const/16 v12, 0x3f

    aput-byte v19, v14, v12

    const/16 v12, 0x40

    const/16 v15, 0x5e

    aput-byte v15, v14, v12

    const/16 v12, 0x41

    const/16 v15, 0x5f

    aput-byte v15, v14, v12

    const/16 v12, 0x42

    aput-byte v9, v14, v12

    const/16 v12, 0x43

    const/16 v15, -0x79

    aput-byte v15, v14, v12

    const/16 v12, 0x44

    const/16 v15, -0x80

    aput-byte v15, v14, v12

    const/16 v12, 0x45

    aput-byte v16, v14, v12

    const/16 v12, 0x46

    const/16 v15, -0x22

    aput-byte v15, v14, v12

    const/16 v12, 0x47

    aput-byte v16, v14, v12

    const/16 v12, 0x48

    const/16 v15, 0x47

    aput-byte v15, v14, v12

    const/16 v12, 0x49

    const/16 v15, 0x5b

    aput-byte v15, v14, v12

    const/16 v12, 0x4a

    const/16 v15, 0x41

    aput-byte v15, v14, v12

    const/16 v12, 0x4b

    const/16 v15, -0x29

    aput-byte v15, v14, v12

    const/16 v12, 0x4c

    const/16 v15, -0x1c

    aput-byte v15, v14, v12

    const/16 v12, 0x4d

    const/16 v15, 0x46

    aput-byte v15, v14, v12

    const/16 v12, 0x4e

    const/16 v15, -0x6e

    aput-byte v15, v14, v12

    const/16 v12, 0x4f

    const/16 v15, 0x6a

    aput-byte v15, v14, v12

    const/16 v12, 0x50

    const/16 v15, 0xe

    aput-byte v15, v14, v12

    const/16 v12, 0x51

    const/4 v15, 0x7

    aput-byte v15, v14, v12

    const/16 v12, 0x52

    const/16 v15, 0x25

    aput-byte v15, v14, v12

    const/16 v12, 0x53

    const/16 v15, -0x56

    aput-byte v15, v14, v12

    const/16 v12, 0x54

    const/16 v15, -0x7d

    aput-byte v15, v14, v12

    const/16 v12, 0x55

    const/16 v15, 0x38

    aput-byte v15, v14, v12

    const/16 v12, 0x56

    const/16 v15, -0x10

    aput-byte v15, v14, v12

    const/16 v12, 0x57

    const/16 v15, 0x77

    aput-byte v15, v14, v12

    const/16 v12, 0x58

    const/16 v15, 0xe

    aput-byte v15, v14, v12

    const/16 v12, 0x59

    const/16 v15, 0x43

    aput-byte v15, v14, v12

    const/16 v12, 0x5a

    const/4 v15, 0x7

    aput-byte v15, v14, v12

    const/16 v12, 0x5b

    const/16 v15, -0x77

    aput-byte v15, v14, v12

    const/16 v12, 0x5c

    const/16 v15, -0x4e

    aput-byte v15, v14, v12

    const/16 v12, 0x5d

    const/16 v15, 0x55

    aput-byte v15, v14, v12

    const/16 v12, 0x5e

    const/4 v15, -0x5

    aput-byte v15, v14, v12

    const/16 v12, 0x5f

    const/16 v15, 0x3e

    aput-byte v15, v14, v12

    const/16 v12, 0x60

    const/16 v15, 0x4d

    aput-byte v15, v14, v12

    const/16 v12, 0x61

    const/16 v15, 0x44

    aput-byte v15, v14, v12

    const/16 v12, 0x62

    aput-byte v8, v14, v12

    const/16 v12, 0x63

    const/16 v15, -0x35

    aput-byte v15, v14, v12

    const/16 v12, 0x64

    const/16 v15, -0x9

    aput-byte v15, v14, v12

    const/16 v12, 0x65

    const/16 v15, 0x38

    aput-byte v15, v14, v12

    const/16 v12, 0x66

    const/16 v15, -0x2d

    aput-byte v15, v14, v12

    const/16 v12, 0x67

    const/16 v15, 0x39

    aput-byte v15, v14, v12

    const/16 v12, 0x68

    const/16 v15, 0x47

    aput-byte v15, v14, v12

    const/16 v12, 0x69

    const/16 v15, 0x43

    aput-byte v15, v14, v12

    const/16 v12, 0x6a

    const/16 v15, 0xb

    aput-byte v15, v14, v12

    const/16 v12, 0x6b

    const/16 v15, -0x3e

    aput-byte v15, v14, v12

    const/16 v12, 0x6c

    const/16 v15, -0x7c

    aput-byte v15, v14, v12

    const/16 v12, 0x6d

    aput-byte v17, v14, v12

    const/16 v12, 0x6e

    const/16 v15, -0x26

    aput-byte v15, v14, v12

    const/16 v12, 0x6f

    const/16 v15, 0x3a

    aput-byte v15, v14, v12

    const/16 v12, 0x70

    const/16 v15, 0x5c

    aput-byte v15, v14, v12

    const/16 v12, 0x71

    const/16 v15, 0x46

    aput-byte v15, v14, v12

    const/16 v12, 0x72

    const/16 v15, 0x41

    aput-byte v15, v14, v12

    const/16 v12, 0x73

    const/16 v15, -0x29

    aput-byte v15, v14, v12

    const/16 v12, 0x74

    const/16 v15, -0x1c

    aput-byte v15, v14, v12

    const/16 v12, 0x75

    const/16 v15, 0x46

    aput-byte v15, v14, v12

    const/16 v12, 0x76

    const/16 v15, -0x6e

    aput-byte v15, v14, v12

    const/16 v12, 0x77

    const/16 v15, 0x6a

    aput-byte v15, v14, v12

    const/16 v12, 0x8

    new-array v12, v12, [B

    const/16 v15, 0x2e

    aput-byte v15, v12, v7

    const/16 v15, 0x2f

    aput-byte v15, v12, v8

    const/16 v15, 0x6e

    aput-byte v15, v12, v9

    const/16 v15, -0x1e

    aput-byte v15, v12, v10

    const/16 v15, -0x29

    aput-byte v15, v12, v11

    const/16 v15, 0x75

    const/16 v22, 0x5

    aput-byte v15, v12, v22

    const/16 v15, -0x44

    const/16 v22, 0x6

    aput-byte v15, v12, v22

    const/16 v15, 0x5b

    const/16 v22, 0x7

    aput-byte v15, v12, v22

    invoke-static {v14, v12}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v12

    invoke-virtual {v6, v13, v12}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/16 v12, 0x8

    new-array v12, v12, [B

    const/4 v13, -0x4

    aput-byte v13, v12, v7

    const/16 v13, 0x31

    aput-byte v13, v12, v8

    const/16 v13, 0x3c

    aput-byte v13, v12, v9

    const/16 v13, -0x6d

    aput-byte v13, v12, v10

    const/16 v13, 0x68

    aput-byte v13, v12, v11

    const/4 v13, -0x3

    const/4 v14, 0x5

    aput-byte v13, v12, v14

    const/16 v13, 0x21

    const/4 v14, 0x6

    aput-byte v13, v12, v14

    const/16 v13, -0x50

    const/4 v14, 0x7

    aput-byte v13, v12, v14

    const/16 v13, 0x8

    new-array v13, v13, [B

    const/16 v14, -0x7c

    aput-byte v14, v13, v7

    const/16 v14, 0x1c

    aput-byte v14, v13, v8

    const/16 v14, 0x4c

    aput-byte v14, v13, v9

    const/16 v14, -0xe

    aput-byte v14, v13, v10

    const/4 v14, 0x6

    aput-byte v14, v13, v11

    const/16 v15, -0x30

    const/16 v22, 0x5

    aput-byte v15, v13, v22

    const/16 v15, 0x55

    aput-byte v15, v13, v14

    const/16 v14, -0x23

    const/4 v15, 0x7

    aput-byte v14, v13, v15

    invoke-static {v12, v13}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v12

    invoke-virtual {v6, v12, v3}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/16 v3, 0xb

    new-array v3, v3, [B

    const/4 v12, 0x6

    aput-byte v12, v3, v7

    const/16 v12, 0x7b

    aput-byte v12, v3, v8

    const/16 v12, -0x5b

    aput-byte v12, v3, v9

    const/16 v12, 0x67

    aput-byte v12, v3, v10

    const/16 v12, -0x59

    aput-byte v12, v3, v11

    const/16 v12, -0x50

    const/4 v13, 0x5

    aput-byte v12, v3, v13

    const/16 v12, 0x41

    const/4 v13, 0x6

    aput-byte v12, v3, v13

    const/16 v12, 0x2b

    const/4 v13, 0x7

    aput-byte v12, v3, v13

    const/16 v12, 0x15

    const/16 v13, 0x8

    aput-byte v12, v3, v13

    const/16 v12, 0x33

    const/16 v14, 0x9

    aput-byte v12, v3, v14

    const/16 v12, -0x45

    const/16 v14, 0xa

    aput-byte v12, v3, v14

    new-array v12, v13, [B

    const/16 v13, 0x7e

    aput-byte v13, v12, v7

    const/16 v13, 0x56

    aput-byte v13, v12, v8

    const/16 v13, -0x2b

    aput-byte v13, v12, v9

    const/4 v13, 0x6

    aput-byte v13, v12, v10

    const/16 v14, -0x37

    aput-byte v14, v12, v11

    const/16 v14, -0x63

    const/4 v15, 0x5

    aput-byte v14, v12, v15

    const/16 v14, 0x35

    aput-byte v14, v12, v13

    const/16 v13, 0x44

    const/4 v14, 0x7

    aput-byte v13, v12, v14

    invoke-static {v3, v12}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v6, v3, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/16 v2, 0xc

    new-array v2, v2, [B

    const/16 v3, 0x19

    aput-byte v3, v2, v7

    const/16 v3, -0x6f

    aput-byte v3, v2, v8

    const/16 v3, 0x9

    aput-byte v3, v2, v9

    const/16 v3, -0x6d

    aput-byte v3, v2, v10

    const/16 v3, -0x1f

    aput-byte v3, v2, v11

    const/4 v3, 0x5

    aput-byte v11, v2, v3

    const/16 v3, 0x20

    const/4 v12, 0x6

    aput-byte v3, v2, v12

    const/16 v3, 0x54

    const/4 v12, 0x7

    aput-byte v3, v2, v12

    const/16 v3, 0x8

    const/16 v12, 0xe

    aput-byte v12, v2, v3

    const/16 v12, -0x79

    const/16 v13, 0x9

    aput-byte v12, v2, v13

    const/16 v12, 0x17

    const/16 v13, 0xa

    aput-byte v12, v2, v13

    const/16 v12, -0x7e

    const/16 v13, 0xb

    aput-byte v12, v2, v13

    new-array v3, v3, [B

    const/16 v12, 0x7a

    aput-byte v12, v3, v7

    const/4 v12, -0x2

    aput-byte v12, v3, v8

    const/16 v12, 0x67

    aput-byte v12, v3, v9

    const/16 v12, -0x19

    aput-byte v12, v3, v10

    const/16 v12, -0x7c

    aput-byte v12, v3, v11

    const/16 v12, 0x6a

    const/4 v13, 0x5

    aput-byte v12, v3, v13

    const/16 v12, 0x54

    const/4 v13, 0x6

    aput-byte v12, v3, v13

    const/16 v12, 0x79

    const/4 v13, 0x7

    aput-byte v12, v3, v13

    invoke-static {v2, v3}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v2

    const/16 v3, 0x18

    new-array v3, v3, [B

    const/16 v12, -0x55

    aput-byte v12, v3, v7

    const/4 v12, -0x4

    aput-byte v12, v3, v8

    const/16 v12, 0x58

    aput-byte v12, v3, v9

    const/16 v12, -0x3d

    aput-byte v12, v3, v10

    const/16 v12, 0x2b

    aput-byte v12, v3, v11

    const/4 v12, 0x5

    aput-byte v16, v3, v12

    const/16 v12, 0x5f

    const/4 v13, 0x6

    aput-byte v12, v3, v13

    const/16 v12, 0x54

    const/4 v13, 0x7

    aput-byte v12, v3, v13

    const/16 v12, -0x4a

    const/16 v13, 0x8

    aput-byte v12, v3, v13

    const/16 v12, -0x9

    const/16 v13, 0x9

    aput-byte v12, v3, v13

    const/16 v12, 0x1b

    const/16 v13, 0xa

    aput-byte v12, v3, v13

    const/16 v12, -0x2c

    const/16 v13, 0xb

    aput-byte v12, v3, v13

    const/16 v12, 0x6c

    const/16 v13, 0xc

    aput-byte v12, v3, v13

    const/16 v12, 0xd

    aput-byte v8, v3, v12

    const/16 v12, 0x41

    const/16 v13, 0xe

    aput-byte v12, v3, v13

    const/16 v12, 0x46

    const/16 v13, 0xf

    aput-byte v12, v3, v13

    const/16 v12, -0x46

    aput-byte v12, v3, v16

    const/16 v12, 0x11

    const/16 v13, -0x13

    aput-byte v13, v3, v12

    const/16 v12, 0x12

    aput-byte v20, v3, v12

    const/16 v12, 0x13

    const/16 v13, -0x1e

    aput-byte v13, v3, v12

    const/16 v12, 0x50

    aput-byte v12, v3, v17

    const/16 v12, 0x26

    const/16 v13, 0x15

    aput-byte v12, v3, v13

    const/16 v12, 0x16

    const/16 v13, 0x1e

    aput-byte v13, v3, v12

    const/16 v12, 0x17

    const/16 v13, 0xd

    aput-byte v13, v3, v12

    const/16 v12, 0x8

    new-array v12, v12, [B

    const/16 v13, -0x21

    aput-byte v13, v12, v7

    const/16 v13, -0x67

    aput-byte v13, v12, v8

    const/16 v13, 0x20

    aput-byte v13, v12, v9

    const/16 v13, -0x49

    aput-byte v13, v12, v10

    aput-byte v11, v12, v11

    const/16 v13, 0x60

    const/4 v14, 0x5

    aput-byte v13, v12, v14

    const/16 v13, 0x33

    const/4 v14, 0x6

    aput-byte v13, v12, v14

    const/16 v13, 0x35

    const/4 v14, 0x7

    aput-byte v13, v12, v14

    invoke-static {v3, v12}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v6, v2, v3}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/16 v2, 0xf

    new-array v2, v2, [B

    const/16 v3, -0x1c

    aput-byte v3, v2, v7

    const/16 v3, 0x41

    aput-byte v3, v2, v8

    const/16 v3, 0x45

    aput-byte v3, v2, v9

    const/16 v3, 0x5f

    aput-byte v3, v2, v10

    const/16 v3, 0xa

    aput-byte v3, v2, v11

    const/16 v3, 0x38

    const/4 v12, 0x5

    aput-byte v3, v2, v12

    const/16 v3, 0x1e

    const/4 v12, 0x6

    aput-byte v3, v2, v12

    const/16 v3, 0x32

    const/4 v12, 0x7

    aput-byte v3, v2, v12

    const/16 v3, -0xb

    const/16 v12, 0x8

    aput-byte v3, v2, v12

    const/16 v3, 0x9

    aput-byte v3, v2, v3

    const/16 v3, 0x5b

    const/16 v12, 0xa

    aput-byte v3, v2, v12

    const/16 v3, 0x4a

    const/16 v12, 0xb

    aput-byte v3, v2, v12

    const/16 v3, 0x49

    const/16 v12, 0xc

    aput-byte v3, v2, v12

    const/16 v3, 0x7c

    const/16 v12, 0xd

    aput-byte v3, v2, v12

    const/16 v3, 0xe

    const/16 v12, 0x19

    aput-byte v12, v2, v3

    const/16 v3, 0x8

    new-array v3, v3, [B

    const/16 v12, -0x64

    aput-byte v12, v3, v7

    const/16 v12, 0x6c

    aput-byte v12, v3, v8

    const/16 v12, 0x35

    aput-byte v12, v3, v9

    const/16 v12, 0x3e

    aput-byte v12, v3, v10

    const/16 v12, 0x64

    aput-byte v12, v3, v11

    const/16 v12, 0x15

    const/4 v13, 0x5

    aput-byte v12, v3, v13

    const/16 v12, 0x7d

    const/4 v13, 0x6

    aput-byte v12, v3, v13

    const/16 v12, 0x5e

    const/4 v13, 0x7

    aput-byte v12, v3, v13

    invoke-static {v2, v3}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v6, v2, v1}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    invoke-static {v5, v6}, Lcom/github/catvod/spider/appysv2/n/c;->m(Ljava/lang/String;Ljava/util/Map;)Ljava/lang/String;

    move-result-object v2

    new-instance v3, Lorg/json/JSONObject;

    invoke-direct {v3, v2}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    const/16 v2, 0xb

    new-array v2, v2, [B

    const/16 v5, -0xf

    aput-byte v5, v2, v7

    const/16 v5, -0x33

    aput-byte v5, v2, v8

    const/16 v5, 0x6e

    aput-byte v5, v2, v9

    const/16 v5, 0x39

    aput-byte v5, v2, v10

    const/16 v5, 0x72

    aput-byte v5, v2, v11

    const/16 v5, -0x57

    const/4 v6, 0x5

    aput-byte v5, v2, v6

    const/16 v5, -0x3a

    const/4 v6, 0x6

    aput-byte v5, v2, v6

    const/16 v5, 0x6a

    const/4 v6, 0x7

    aput-byte v5, v2, v6

    const/16 v5, -0x15

    const/16 v6, 0x8

    aput-byte v5, v2, v6

    const/16 v5, -0x23

    const/16 v12, 0x9

    aput-byte v5, v2, v12

    const/16 v5, 0x65

    const/16 v12, 0xa

    aput-byte v5, v2, v12

    new-array v5, v6, [B

    const/16 v6, -0x80

    aput-byte v6, v5, v7

    const/16 v6, -0x48

    aput-byte v6, v5, v8

    const/16 v6, 0xb

    aput-byte v6, v5, v9

    const/16 v12, 0x4b

    aput-byte v12, v5, v10

    aput-byte v6, v5, v11

    const/16 v6, -0xa

    const/4 v12, 0x5

    aput-byte v6, v5, v12

    const/16 v6, -0x4e

    const/4 v13, 0x6

    aput-byte v6, v5, v13

    const/4 v6, 0x7

    aput-byte v12, v5, v6

    invoke-static {v2, v5}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v3, v2}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const/16 v5, 0x2d

    new-array v5, v5, [B

    aput-byte v8, v5, v7

    const/16 v6, -0x10

    aput-byte v6, v5, v8

    const/16 v6, -0xf

    aput-byte v6, v5, v9

    const/16 v6, 0x3b

    aput-byte v6, v5, v10

    const/16 v6, -0x21

    aput-byte v6, v5, v11

    const/16 v6, -0x24

    const/4 v12, 0x5

    aput-byte v6, v5, v12

    const/16 v6, 0x40

    const/4 v12, 0x6

    aput-byte v6, v5, v12

    const/16 v6, -0x44

    const/4 v12, 0x7

    aput-byte v6, v5, v12

    const/16 v6, 0x8

    aput-byte v19, v5, v6

    const/16 v6, -0xf

    const/16 v12, 0x9

    aput-byte v6, v5, v12

    const/16 v6, -0x55

    const/16 v12, 0xa

    aput-byte v6, v5, v12

    const/16 v6, 0x3e

    const/16 v12, 0xb

    aput-byte v6, v5, v12

    const/16 v6, -0x31

    const/16 v12, 0xc

    aput-byte v6, v5, v12

    const/16 v6, -0x38

    const/16 v13, 0xd

    aput-byte v6, v5, v13

    const/16 v6, 0xe

    aput-byte v12, v5, v6

    const/4 v6, -0x3

    const/16 v12, 0xf

    aput-byte v6, v5, v12

    const/16 v6, 0x46

    aput-byte v6, v5, v16

    const/16 v6, 0x11

    const/16 v12, -0x43

    aput-byte v12, v5, v6

    const/16 v6, 0x12

    const/16 v12, -0x26

    aput-byte v12, v5, v6

    const/16 v6, 0x13

    const/16 v12, 0x22

    aput-byte v12, v5, v6

    const/16 v6, -0x11

    aput-byte v6, v5, v17

    const/16 v6, -0x51

    const/16 v12, 0x15

    aput-byte v6, v5, v12

    const/16 v6, 0x16

    const/16 v12, 0x5c

    aput-byte v12, v5, v6

    const/16 v6, 0x17

    const/4 v12, -0x5

    aput-byte v12, v5, v6

    const/16 v6, 0x18

    const/16 v12, 0x56

    aput-byte v12, v5, v6

    const/16 v6, -0xf

    const/16 v12, 0x19

    aput-byte v6, v5, v12

    const/16 v6, -0x1a

    aput-byte v6, v5, v19

    const/16 v6, 0x1b

    aput-byte v17, v5, v6

    const/16 v6, 0x1c

    const/16 v12, -0x24

    aput-byte v12, v5, v6

    const/16 v6, -0x79

    aput-byte v6, v5, v20

    const/16 v6, 0x1e

    aput-byte v20, v5, v6

    const/16 v6, 0x1f

    const/16 v12, -0xe

    aput-byte v12, v5, v6

    const/16 v6, 0x20

    aput-byte v11, v5, v6

    const/16 v6, 0x21

    const/16 v12, -0x25

    aput-byte v12, v5, v6

    const/16 v6, 0x22

    const/16 v12, -0xa

    aput-byte v12, v5, v6

    const/16 v6, 0x23

    const/16 v12, 0x3f

    aput-byte v12, v5, v6

    const/16 v6, 0x24

    const/16 v12, -0x22

    aput-byte v12, v5, v6

    const/16 v6, 0x25

    const/16 v12, -0x25

    aput-byte v12, v5, v6

    const/16 v6, 0x26

    const/16 v12, 0x49

    aput-byte v12, v5, v6

    const/16 v6, 0x27

    const/16 v12, -0x19

    aput-byte v12, v5, v6

    const/16 v6, 0x28

    const/4 v12, 0x6

    aput-byte v12, v5, v6

    const/16 v6, 0x29

    const/16 v12, -0x11

    aput-byte v12, v5, v6

    const/16 v6, 0x2a

    const/16 v12, -0x20

    aput-byte v12, v5, v6

    const/16 v6, 0x2b

    const/16 v12, 0x25

    aput-byte v12, v5, v6

    const/16 v6, 0x2c

    const/16 v12, -0x6f

    aput-byte v12, v5, v6

    const/16 v6, 0x8

    new-array v6, v6, [B

    const/16 v12, 0x69

    aput-byte v12, v6, v7

    const/16 v12, -0x7c

    aput-byte v12, v6, v8

    const/16 v12, -0x7b

    aput-byte v12, v6, v9

    const/16 v12, 0x4b

    aput-byte v12, v6, v10

    const/16 v12, -0x54

    aput-byte v12, v6, v11

    const/16 v12, -0x1a

    const/4 v13, 0x5

    aput-byte v12, v6, v13

    const/16 v12, 0x6f

    const/4 v13, 0x6

    aput-byte v12, v6, v13

    const/16 v12, -0x6d

    const/4 v13, 0x7

    aput-byte v12, v6, v13

    invoke-static {v5, v6}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v5, 0x29

    new-array v5, v5, [B

    const/16 v6, -0x68

    aput-byte v6, v5, v7

    const/16 v6, -0x21

    aput-byte v6, v5, v8

    const/16 v6, 0x76

    aput-byte v6, v5, v9

    const/16 v6, -0x32

    aput-byte v6, v5, v10

    const/16 v6, 0x4a

    aput-byte v6, v5, v11

    const/16 v6, 0x4a

    const/4 v12, 0x5

    aput-byte v6, v5, v12

    const/16 v6, -0x3c

    const/4 v12, 0x6

    aput-byte v6, v5, v12

    const/16 v6, -0x3b

    const/4 v12, 0x7

    aput-byte v6, v5, v12

    const/16 v6, -0x33

    const/16 v12, 0x8

    aput-byte v6, v5, v12

    const/16 v6, -0x22

    const/16 v12, 0x9

    aput-byte v6, v5, v12

    const/16 v6, 0x67

    const/16 v12, 0xa

    aput-byte v6, v5, v12

    const/16 v6, -0x54

    const/16 v12, 0xb

    aput-byte v6, v5, v12

    const/16 v6, 0x7b

    const/16 v12, 0xc

    aput-byte v6, v5, v12

    const/16 v6, 0xd

    const/4 v12, 0x6

    aput-byte v12, v5, v6

    const/16 v6, -0x73

    const/16 v12, 0xe

    aput-byte v6, v5, v12

    const/16 v6, -0x25

    const/16 v12, 0xf

    aput-byte v6, v5, v12

    const/16 v6, -0x23

    aput-byte v6, v5, v16

    const/16 v6, 0x11

    const/16 v12, -0x21

    aput-byte v12, v5, v6

    const/16 v6, 0x12

    const/16 v12, 0x66

    aput-byte v12, v5, v6

    const/16 v6, 0x13

    const/16 v12, -0x1b

    aput-byte v12, v5, v6

    const/16 v6, 0x47

    aput-byte v6, v5, v17

    const/16 v6, 0x4e

    const/16 v12, 0x15

    aput-byte v6, v5, v12

    const/16 v6, 0x16

    const/16 v12, -0x65

    aput-byte v12, v5, v6

    const/16 v6, 0x17

    const/16 v12, -0x53

    aput-byte v12, v5, v6

    const/16 v6, 0x18

    const/4 v12, -0x3

    aput-byte v12, v5, v6

    const/16 v6, -0x17

    const/16 v12, 0x19

    aput-byte v6, v5, v12

    const/16 v6, 0x30

    aput-byte v6, v5, v19

    const/16 v6, 0x1b

    const/16 v12, -0x5e

    aput-byte v12, v5, v6

    const/16 v6, 0x1c

    const/16 v12, 0x69

    aput-byte v12, v5, v6

    const/16 v6, 0x57

    aput-byte v6, v5, v20

    const/16 v6, 0x1e

    const/16 v12, -0x29

    aput-byte v12, v5, v6

    const/16 v6, 0x1f

    const/16 v12, -0x12

    aput-byte v12, v5, v6

    const/16 v6, 0x20

    const/16 v12, -0x2e

    aput-byte v12, v5, v6

    const/16 v6, 0x21

    const/16 v12, -0x31

    aput-byte v12, v5, v6

    const/16 v6, 0x22

    const/16 v12, 0x77

    aput-byte v12, v5, v6

    const/16 v6, 0x23

    const/16 v12, -0x10

    aput-byte v12, v5, v6

    const/16 v6, 0x24

    const/16 v12, 0x5a

    aput-byte v12, v5, v6

    const/16 v6, 0x25

    const/16 v12, 0x7c

    aput-byte v12, v5, v6

    const/16 v6, 0x26

    const/16 v12, -0x28

    aput-byte v12, v5, v6

    const/16 v6, 0x27

    const/16 v12, -0xd

    aput-byte v12, v5, v6

    const/16 v6, 0x28

    const/16 v12, -0x3a

    aput-byte v12, v5, v6

    const/16 v6, 0x8

    new-array v6, v6, [B

    const/16 v12, -0x42

    aput-byte v12, v6, v7

    const/16 v12, -0x56

    aput-byte v12, v6, v8

    const/16 v12, 0x15

    aput-byte v12, v6, v9

    const/16 v12, -0x6f

    aput-byte v12, v6, v10

    const/16 v12, 0x28

    aput-byte v12, v6, v11

    const/16 v12, 0x23

    const/4 v13, 0x5

    aput-byte v12, v6, v13

    const/16 v12, -0x42

    const/4 v13, 0x6

    aput-byte v12, v6, v13

    const/16 v12, -0x66

    const/4 v13, 0x7

    aput-byte v12, v6, v13

    invoke-static {v5, v6}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    new-instance v5, Lorg/json/JSONObject;

    invoke-direct {v5}, Lorg/json/JSONObject;-><init>()V

    new-array v6, v10, [B

    aput-byte v17, v6, v7

    const/16 v12, 0x60

    aput-byte v12, v6, v8

    const/16 v12, 0x27

    aput-byte v12, v6, v9

    const/16 v12, 0x8

    new-array v12, v12, [B

    const/16 v13, 0x61

    aput-byte v13, v12, v7

    const/16 v13, 0x12

    aput-byte v13, v12, v8

    const/16 v13, 0x4b

    aput-byte v13, v12, v9

    const/16 v13, -0x79

    aput-byte v13, v12, v10

    const/16 v13, -0x60

    aput-byte v13, v12, v11

    const/16 v13, 0x46

    const/4 v14, 0x5

    aput-byte v13, v12, v14

    const/16 v13, 0xf

    const/4 v14, 0x6

    aput-byte v13, v12, v14

    const/16 v13, -0x51

    const/4 v14, 0x7

    aput-byte v13, v12, v14

    invoke-static {v6, v12}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v5, v6, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v3, 0x5

    new-array v3, v3, [B

    const/16 v6, 0x3f

    aput-byte v6, v3, v7

    aput-byte v11, v3, v8

    const/16 v6, 0x52

    aput-byte v6, v3, v9

    const/16 v6, -0x6e

    aput-byte v6, v3, v10

    const/16 v6, 0x24

    aput-byte v6, v3, v11

    const/16 v6, 0x8

    new-array v6, v6, [B

    const/16 v12, 0x4b

    aput-byte v12, v6, v7

    const/16 v12, 0x6b

    aput-byte v12, v6, v8

    const/16 v12, 0x39

    aput-byte v12, v6, v9

    const/16 v12, -0x9

    aput-byte v12, v6, v10

    const/16 v12, 0x4a

    aput-byte v12, v6, v11

    const/16 v12, -0x3f

    const/4 v13, 0x5

    aput-byte v12, v6, v13

    const/16 v12, -0x48

    const/4 v13, 0x6

    aput-byte v12, v6, v13

    const/16 v12, -0x7a

    const/4 v13, 0x7

    aput-byte v12, v6, v13

    invoke-static {v3, v6}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v5, v3, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/16 v2, 0x9

    new-array v2, v2, [B

    const/16 v3, 0x3d

    aput-byte v3, v2, v7

    const/16 v3, 0x6a

    aput-byte v3, v2, v8

    const/16 v3, -0x71

    aput-byte v3, v2, v9

    const/16 v3, -0xd

    aput-byte v3, v2, v10

    const/16 v3, -0x4a

    aput-byte v3, v2, v11

    const/16 v3, -0x68

    const/4 v6, 0x5

    aput-byte v3, v2, v6

    const/4 v3, -0x3

    const/4 v6, 0x6

    aput-byte v3, v2, v6

    const/4 v3, -0x5

    const/4 v6, 0x7

    aput-byte v3, v2, v6

    const/16 v3, 0x3d

    const/16 v6, 0x8

    aput-byte v3, v2, v6

    new-array v3, v6, [B

    const/16 v6, 0x59

    aput-byte v6, v3, v7

    const/16 v6, 0xf

    aput-byte v6, v3, v8

    const/4 v6, -0x7

    aput-byte v6, v3, v9

    const/16 v6, -0x66

    aput-byte v6, v3, v10

    const/16 v6, -0x2b

    aput-byte v6, v3, v11

    const/4 v6, -0x3

    const/4 v12, 0x5

    aput-byte v6, v3, v12

    const/16 v6, -0x5e

    const/4 v12, 0x6

    aput-byte v6, v3, v12

    const/16 v6, -0x6e

    const/4 v12, 0x7

    aput-byte v6, v3, v12

    invoke-static {v2, v3}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v5, v2, v4}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/16 v2, 0x9

    new-array v2, v2, [B

    const/16 v3, 0x7e

    aput-byte v3, v2, v7

    const/16 v3, 0x77

    aput-byte v3, v2, v8

    const/16 v3, 0x7b

    aput-byte v3, v2, v9

    const/16 v3, -0x69

    aput-byte v3, v2, v10

    const/16 v3, -0x79

    aput-byte v3, v2, v11

    const/4 v3, -0x3

    const/4 v4, 0x5

    aput-byte v3, v2, v4

    const/16 v3, 0x9

    const/4 v4, 0x6

    aput-byte v3, v2, v4

    const/16 v3, -0x10

    const/4 v4, 0x7

    aput-byte v3, v2, v4

    const/16 v3, 0x79

    const/16 v4, 0x8

    aput-byte v3, v2, v4

    new-array v3, v4, [B

    aput-byte v20, v3, v7

    const/16 v4, 0x1b

    aput-byte v4, v3, v8

    const/16 v4, 0x12

    aput-byte v4, v3, v9

    const/16 v4, -0xe

    aput-byte v4, v3, v10

    const/16 v4, -0x17

    aput-byte v4, v3, v11

    const/16 v4, -0x77

    const/4 v6, 0x5

    aput-byte v4, v3, v6

    const/16 v4, 0x56

    const/4 v6, 0x6

    aput-byte v4, v3, v6

    const/16 v4, -0x67

    const/4 v6, 0x7

    aput-byte v4, v3, v6

    invoke-static {v2, v3}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v5, v2, v1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    new-instance v1, Lcom/github/catvod/spider/appysv2/b/Q;
    :try_end_13df
    .catch Ljava/lang/Exception; {:try_start_4 .. :try_end_13df} :catch_13eb

    move-object/from16 v2, p0

    :try_start_13e1
    invoke-direct {v1, v2, v5, v7}, Lcom/github/catvod/spider/appysv2/b/Q;-><init>(Lcom/github/catvod/spider/appysv2/b/U;Lorg/json/JSONObject;I)V

    invoke-static {v1}, Lcom/github/catvod/spider/Init;->run(Ljava/lang/Runnable;)V
    :try_end_13e7
    .catch Ljava/lang/Exception; {:try_start_13e1 .. :try_end_13e7} :catch_13e8

    goto :goto_1405

    :catch_13e8
    move-exception v0

    :goto_13e9
    move-object v1, v0

    goto :goto_13ef

    :catch_13eb
    move-exception v0

    move-object/from16 v2, p0

    goto :goto_13e9

    :goto_13ef
    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const/16 v4, 0xd

    new-array v4, v4, [B

    fill-array-data v4, :array_1406

    const/16 v5, 0x8

    new-array v5, v5, [B

    fill-array-data v5, :array_1412

    .line 1
    invoke-static {v4, v5, v3, v1}, Lcom/github/catvod/spider/appysv2/b/y;->b([B[BLjava/lang/StringBuilder;Ljava/lang/Exception;)V

    :goto_1405
    return-void

    :array_1406
    .array-data 1
        0x2ct
        0x70t
        0x20t
        0x26t
        0x47t
        -0x61t
        -0x4at
        0x70t
        0x2et
        0x35t
        0x31t
        0x4dt
        0x35t
    .end array-data

    nop

    :array_1412
    .array-data 1
        0x4bt
        0x15t
        0x54t
        0x77t
        0x15t
        -0x24t
        -0x27t
        0x14t
    .end array-data
.end method

.method public final F(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lcom/github/catvod/spider/appysv2/c/k;
    .registers 16

    invoke-virtual {p0, p1}, Lcom/github/catvod/spider/appysv2/b/U;->N(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    if-eqz v0, :cond_f

    invoke-static {}, Lcom/github/catvod/spider/appysv2/p/C;->e()Lcom/github/catvod/spider/appysv2/c/k;

    move-result-object p1

    return-object p1

    :cond_f
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    new-instance v1, Lcom/github/catvod/spider/appysv2/l/a;

    invoke-direct {v1}, Lcom/github/catvod/spider/appysv2/l/a;-><init>()V

    invoke-virtual {v1, p2}, Lcom/github/catvod/spider/appysv2/l/a;->j(Ljava/lang/String;)Lcom/github/catvod/spider/appysv2/l/a;

    invoke-direct {p0, p1, v1, v0}, Lcom/github/catvod/spider/appysv2/b/U;->J(Ljava/lang/String;Lcom/github/catvod/spider/appysv2/l/a;Ljava/util/List;)V

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result p2

    const/4 v1, 0x1

    if-ge p2, v1, :cond_2b

    invoke-static {}, Lcom/github/catvod/spider/appysv2/p/C;->e()Lcom/github/catvod/spider/appysv2/c/k;

    move-result-object p1

    return-object p1

    :cond_2b
    iget-object p2, p0, Lcom/github/catvod/spider/appysv2/b/U;->e:Lcom/github/catvod/spider/appysv2/l/e;

    invoke-virtual {p2, v0}, Lcom/github/catvod/spider/appysv2/l/e;->d(Ljava/util/List;)V

    const/4 p2, 0x2

    new-array v2, p2, [Ljava/lang/String;

    const/16 v3, 0x8

    new-array v4, v3, [B

    fill-array-data v4, :array_1ec

    new-array v5, v3, [B

    fill-array-data v5, :array_1f4

    invoke-static {v4, v5}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v4

    const/4 v5, 0x0

    aput-object v4, v2, v5

    new-array v4, v3, [B

    fill-array-data v4, :array_1fc

    new-array v6, v3, [B

    fill-array-data v6, :array_204

    invoke-static {v4, v6}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v4

    aput-object v4, v2, v1

    invoke-static {v2}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v2

    new-instance v4, Ljava/util/ArrayList;

    invoke-direct {v4}, Ljava/util/ArrayList;-><init>()V

    new-instance v6, Ljava/util/ArrayList;

    invoke-direct {v6}, Ljava/util/ArrayList;-><init>()V

    invoke-virtual {v0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_68
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v7

    const-string v8, ""

    if-eqz v7, :cond_157

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Lcom/github/catvod/spider/appysv2/l/a;

    invoke-virtual {v7}, Lcom/github/catvod/spider/appysv2/l/a;->e()Ljava/lang/String;

    move-result-object v9

    if-eqz v9, :cond_b8

    invoke-virtual {v7}, Lcom/github/catvod/spider/appysv2/l/a;->e()Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v9}, Ljava/lang/String;->isEmpty()Z

    move-result v9

    if-eqz v9, :cond_87

    goto :goto_b8

    :cond_87
    new-instance v8, Ljava/lang/StringBuilder;

    invoke-direct {v8}, Ljava/lang/StringBuilder;-><init>()V

    new-array v9, v1, [B

    const/16 v10, -0x23

    aput-byte v10, v9, v5

    new-array v10, v3, [B

    fill-array-data v10, :array_20c

    invoke-static {v9, v10}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v7}, Lcom/github/catvod/spider/appysv2/l/a;->e()Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v9}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    new-array v9, v1, [B

    const/16 v10, -0x53

    aput-byte v10, v9, v5

    new-array v10, v3, [B

    fill-array-data v10, :array_214

    .line 1
    invoke-static {v9, v10, v8}, Lcom/github/catvod/spider/appysv2/b/t;->a([B[BLjava/lang/StringBuilder;)Ljava/lang/String;

    move-result-object v8

    .line 2
    :cond_b8
    :goto_b8
    invoke-static {v8}, Lcom/github/catvod/spider/appysv2/b/t;->b(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    .line 3
    invoke-virtual {v7}, Lcom/github/catvod/spider/appysv2/l/a;->c()Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v7}, Lcom/github/catvod/spider/appysv2/l/a;->g()Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    new-array v9, v1, [B

    const/4 v10, 0x6

    aput-byte v10, v9, v5

    new-array v10, v3, [B

    fill-array-data v10, :array_21c

    .line 4
    invoke-static {v9, v10, v8, p1}, Lcom/github/catvod/spider/appysv2/b/v;->c([B[BLjava/lang/StringBuilder;Ljava/lang/String;)V

    new-array v9, v1, [B

    const/16 v10, -0x2c

    aput-byte v10, v9, v5

    new-array v10, v3, [B

    .line 5
    fill-array-data v10, :array_224

    invoke-static {v9, v10}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v7}, Lcom/github/catvod/spider/appysv2/l/a;->b()Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    new-array v9, v1, [B

    aput-byte p2, v9, v5

    new-array v10, v3, [B

    fill-array-data v10, :array_22c

    invoke-static {v9, v10}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v7}, Lcom/github/catvod/spider/appysv2/l/a;->f()Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v8}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v8

    invoke-static {p3}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v9

    if-nez v9, :cond_152

    const/4 v9, 0x4

    new-array v10, v9, [B

    fill-array-data v10, :array_234

    new-array v11, v3, [B

    fill-array-data v11, :array_23a

    invoke-static {v10, v11}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v10

    invoke-virtual {p3, v10}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v10

    if-nez v10, :cond_152

    .line 6
    invoke-static {v8}, Lcom/github/catvod/spider/appysv2/b/t;->b(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    new-array v10, v1, [B

    const/4 v11, -0x4

    aput-byte v11, v10, v5

    new-array v11, v3, [B

    .line 7
    fill-array-data v11, :array_242

    .line 8
    invoke-static {v10, v11, v8, p3}, Lcom/github/catvod/spider/appysv2/b/v;->c([B[BLjava/lang/StringBuilder;Ljava/lang/String;)V

    new-array v10, v1, [B

    aput-byte v9, v10, v5

    new-array v9, v3, [B

    .line 9
    fill-array-data v9, :array_24a

    invoke-static {v10, v9}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v7}, Lcom/github/catvod/spider/appysv2/l/a;->c()Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v8, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v8}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v8

    :cond_152
    invoke-virtual {v4, v8}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto/16 :goto_68

    :cond_157
    const/4 p2, 0x0

    :goto_158
    invoke-interface {v2}, Ljava/util/List;->size()I

    move-result p3

    if-ge p2, p3, :cond_177

    new-array p3, v1, [B

    const/16 v0, 0x79

    aput-byte v0, p3, v5

    new-array v0, v3, [B

    fill-array-data v0, :array_252

    invoke-static {p3, v0}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object p3

    invoke-static {p3, v4}, Landroid/text/TextUtils;->join(Ljava/lang/CharSequence;Ljava/lang/Iterable;)Ljava/lang/String;

    move-result-object p3

    invoke-virtual {v6, p3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/lit8 p2, p2, 0x1

    goto :goto_158

    :cond_177
    new-instance p2, Lcom/github/catvod/spider/appysv2/c/k;

    invoke-direct {p2}, Lcom/github/catvod/spider/appysv2/c/k;-><init>()V

    invoke-virtual {p2, p1}, Lcom/github/catvod/spider/appysv2/c/k;->g(Ljava/lang/String;)V

    invoke-virtual {p2, p1}, Lcom/github/catvod/spider/appysv2/c/k;->e(Ljava/lang/String;)V

    invoke-virtual {p2, v8}, Lcom/github/catvod/spider/appysv2/c/k;->i(Ljava/lang/String;)V

    iget-object p1, p0, Lcom/github/catvod/spider/appysv2/b/U;->e:Lcom/github/catvod/spider/appysv2/l/e;

    invoke-virtual {p1}, Lcom/github/catvod/spider/appysv2/l/e;->b()Lcom/github/catvod/spider/appysv2/l/d;

    move-result-object p1

    if-nez p1, :cond_18e

    goto :goto_18f

    :cond_18e
    const/4 v1, 0x0

    :goto_18f
    if-eqz v1, :cond_1a2

    const/16 p1, 0x18

    new-array p1, p1, [B

    fill-array-data p1, :array_25a

    new-array p3, v3, [B

    fill-array-data p3, :array_26a

    invoke-static {p1, p3}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object p1

    goto :goto_1ac

    :cond_1a2
    iget-object p1, p0, Lcom/github/catvod/spider/appysv2/b/U;->e:Lcom/github/catvod/spider/appysv2/l/e;

    invoke-virtual {p1}, Lcom/github/catvod/spider/appysv2/l/e;->b()Lcom/github/catvod/spider/appysv2/l/d;

    move-result-object p1

    invoke-virtual {p1}, Lcom/github/catvod/spider/appysv2/l/d;->b()Ljava/lang/String;

    move-result-object p1

    :goto_1ac
    invoke-virtual {p2, p1}, Lcom/github/catvod/spider/appysv2/c/k;->h(Ljava/lang/String;)V

    const/4 p1, 0x3

    new-array p3, p1, [B

    fill-array-data p3, :array_272

    new-array v0, v3, [B

    fill-array-data v0, :array_278

    invoke-static {p3, v0}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object p3

    invoke-static {p3, v6}, Landroid/text/TextUtils;->join(Ljava/lang/CharSequence;Ljava/lang/Iterable;)Ljava/lang/String;

    move-result-object p3

    invoke-virtual {p2, p3}, Lcom/github/catvod/spider/appysv2/c/k;->k(Ljava/lang/String;)V

    new-array p1, p1, [B

    fill-array-data p1, :array_280

    new-array p3, v3, [B

    fill-array-data p3, :array_286

    invoke-static {p1, p3}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object p1

    invoke-static {p1, v2}, Landroid/text/TextUtils;->join(Ljava/lang/CharSequence;Ljava/lang/Iterable;)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p2, p1}, Lcom/github/catvod/spider/appysv2/c/k;->j(Ljava/lang/String;)V

    new-array p1, v3, [B

    fill-array-data p1, :array_28e

    new-array p3, v3, [B

    fill-array-data p3, :array_296

    invoke-static {p1, p3}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p2, p1}, Lcom/github/catvod/spider/appysv2/c/k;->b(Ljava/lang/String;)V

    return-object p2

    :array_1ec
    .array-data 1
        -0x1et
        -0x54t
        -0x5ct
        -0x37t
        0x7t
        -0x2t
        0x1dt
        -0x39t
    .end array-data

    :array_1f4
    .array-data 1
        -0x49t
        -0x11t
        0x41t
        0x47t
        -0x68t
        0x19t
        -0x77t
        0x7ct
    .end array-data

    :array_1fc
    .array-data 1
        0x4dt
        -0x33t
        -0x9t
        -0x36t
        0x54t
        -0x31t
        0x7ft
        -0x1ct
    .end array-data

    :array_204
    .array-data 1
        0x18t
        -0x72t
        0x1et
        0x68t
        -0x30t
        0x27t
        -0x28t
        0x6ct
    .end array-data

    :array_20c
    .array-data 1
        -0x7at
        -0x26t
        0xdt
        -0x7ft
        0x74t
        0x21t
        0x3et
        0x22t
    .end array-data

    :array_214
    .array-data 1
        -0x10t
        -0x29t
        -0x70t
        0x6bt
        0x58t
        -0x20t
        0x2at
        -0x29t
    .end array-data

    :array_21c
    .array-data 1
        0x22t
        -0x39t
        -0x4t
        -0x73t
        0x19t
        0x50t
        -0x6ct
        -0x15t
    .end array-data

    :array_224
    .array-data 1
        -0x1t
        -0x46t
        -0x48t
        -0x4bt
        0x1bt
        -0x33t
        0x0t
        0x15t
    .end array-data

    :array_22c
    .array-data 1
        0x29t
        0x39t
        -0x4dt
        -0x5et
        -0x3dt
        -0x1bt
        0x72t
        0x4ft
    .end array-data

    :array_234
    .array-data 1
        0x53t
        -0x1dt
        0x72t
        -0x18t
    .end array-data

    :array_23a
    .array-data 1
        0x3bt
        -0x69t
        0x6t
        -0x68t
        0x37t
        -0x22t
        -0x37t
        0x77t
    .end array-data

    :array_242
    .array-data 1
        -0x29t
        -0xat
        0xdt
        -0x9t
        -0x62t
        0x5dt
        0x21t
        0x1t
    .end array-data

    :array_24a
    .array-data 1
        0x2ft
        0x8t
        0x34t
        0x15t
        -0x22t
        -0x25t
        -0x33t
        0x26t
    .end array-data

    :array_252
    .array-data 1
        0x5at
        -0xet
        -0x68t
        0x4et
        -0x3et
        -0x42t
        -0x4dt
        -0x1at
    .end array-data

    :array_25a
    .array-data 1
        0x76t
        0x55t
        0x5et
        0x22t
        -0x2ft
        0x7ft
        0x2t
        0x55t
        0x18t
        0x32t
        0x4bt
        0x56t
        -0x45t
        0x79t
        0x67t
        0x15t
        0x39t
        0x6bt
        0xct
        0x63t
        -0x11t
        0x1t
        0x5et
        0x57t
    .end array-data

    :array_26a
    .array-data 1
        -0x62t
        -0x25t
        -0x17t
        -0x39t
        0x5et
        -0x17t
        -0x16t
        -0xet
    .end array-data

    :array_272
    .array-data 1
        0x7bt
        -0x1dt
        0x1bt
    .end array-data

    :array_278
    .array-data 1
        0x5ft
        -0x39t
        0x3ft
        -0x20t
        0x73t
        0x50t
        -0x20t
        -0x4et
    .end array-data

    :array_280
    .array-data 1
        -0x41t
        -0x42t
        0x7t
    .end array-data

    :array_286
    .array-data 1
        -0x65t
        -0x66t
        0x23t
        0x1ct
        0x0t
        0x20t
        0x78t
        -0x1ct
    .end array-data

    :array_28e
    .array-data 1
        0x5at
        -0x8t
        0x2bt
        0x47t
        0x35t
        -0x57t
        -0x1t
        -0x70t
    .end array-data

    :array_296
    .array-data 1
        0xft
        -0x45t
        -0x34t
        -0x6t
        -0x5ct
        0x4et
        0x64t
        0x8t
    .end array-data
.end method

.method public final K([Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    .registers 15

    iget-object v0, p0, Lcom/github/catvod/spider/appysv2/b/U;->a:Ljava/lang/String;

    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    if-eqz v0, :cond_b

    invoke-virtual {p0}, Lcom/github/catvod/spider/appysv2/b/U;->o()V

    .line 1
    :cond_b
    new-instance v0, Ljava/util/HashMap;

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    iget-object v1, p0, Lcom/github/catvod/spider/appysv2/b/U;->d:Ljava/lang/String;

    invoke-static {v1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    const/4 v2, 0x6

    const/16 v3, 0x8

    if-nez v1, :cond_2e

    new-array v1, v2, [B

    fill-array-data v1, :array_28a

    new-array v4, v3, [B

    fill-array-data v4, :array_292

    invoke-static {v1, v4}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v1

    iget-object v4, p0, Lcom/github/catvod/spider/appysv2/b/U;->d:Ljava/lang/String;

    invoke-virtual {v0, v1, v4}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_2e
    const/4 v1, 0x7

    new-array v4, v1, [B

    fill-array-data v4, :array_29a

    new-array v5, v3, [B

    fill-array-data v5, :array_2a2

    invoke-static {v4, v5}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v4

    const/16 v5, 0x13

    new-array v5, v5, [B

    fill-array-data v5, :array_2aa

    new-array v6, v3, [B

    fill-array-data v6, :array_2b8

    invoke-static {v5, v6}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v0, v4, v5}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/16 v4, 0xa

    new-array v5, v4, [B

    fill-array-data v5, :array_2c0

    new-array v6, v3, [B

    fill-array-data v6, :array_2ca

    invoke-static {v5, v6}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v5

    sget-object v6, Lcom/github/catvod/spider/appysv2/b/U;->i:Ljava/lang/String;

    invoke-virtual {v0, v5, v6}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v5, 0x1

    new-array v6, v5, [B

    const/16 v7, 0x9

    const/4 v8, 0x0

    aput-byte v7, v6, v8

    new-array v7, v3, [B

    .line 2
    fill-array-data v7, :array_2d2

    invoke-static {v6, v7}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {p2, v6}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object p2

    aget-object p2, p2, v8

    new-array v6, v2, [B

    fill-array-data v6, :array_2da

    new-array v7, v3, [B

    fill-array-data v7, :array_2e2

    invoke-static {v6, v7}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {p2, v6}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result p2

    const/4 v6, 0x3

    const/16 v7, 0x12

    const-string v9, ""

    const/4 v10, 0x4

    const/4 v11, 0x2

    if-eqz p2, :cond_1c9

    invoke-static {}, Lcom/github/catvod/spider/appysv2/p/m;->b()Ljava/lang/Boolean;

    move-result-object p2

    invoke-virtual {p2}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p2

    if-eqz p2, :cond_130

    const/16 p2, 0x37

    const/16 v0, 0x64

    aget-object v1, p1, v8

    aget-object v2, p1, v5

    array-length v5, p1

    if-le v5, v11, :cond_ae

    aget-object v9, p1, v11

    :cond_ae
    invoke-virtual {p0, v1, v2, v9}, Lcom/github/catvod/spider/appysv2/b/U;->w(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-static {v1, p2, v0}, Lcom/github/catvod/spider/appysv2/p/m;->d(Ljava/lang/String;II)Ljava/lang/String;

    move-result-object p2

    array-length v0, p1

    if-le v0, v10, :cond_119

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-static {}, Lcom/github/catvod/spider/Proxy;->getUrl()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    new-array v1, v7, [B

    fill-array-data v1, :array_2ea

    new-array v2, v3, [B

    fill-array-data v2, :array_2f8

    invoke-static {v1, v2}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    aget-object v1, p1, v6

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    new-array v1, v4, [B

    fill-array-data v1, :array_300

    new-array v2, v3, [B

    fill-array-data v2, :array_30a

    invoke-static {v1, v2}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    aget-object p1, p1, v10

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    new-array p1, v3, [B

    fill-array-data p1, :array_312

    new-array v1, v3, [B

    fill-array-data v1, :array_31a

    .line 3
    invoke-static {p1, v1, v0}, Lcom/github/catvod/spider/appysv2/b/t;->a([B[BLjava/lang/StringBuilder;)Ljava/lang/String;

    move-result-object p1

    .line 4
    new-instance v0, Lcom/github/catvod/spider/appysv2/c/h;

    invoke-direct {v0}, Lcom/github/catvod/spider/appysv2/c/h;-><init>()V

    .line 5
    invoke-virtual {v0, p2}, Lcom/github/catvod/spider/appysv2/c/h;->y(Ljava/lang/String;)Lcom/github/catvod/spider/appysv2/c/h;

    invoke-virtual {v0, p1}, Lcom/github/catvod/spider/appysv2/c/h;->a(Ljava/lang/String;)Lcom/github/catvod/spider/appysv2/c/h;

    invoke-virtual {v0}, Lcom/github/catvod/spider/appysv2/c/h;->j()Lcom/github/catvod/spider/appysv2/c/h;

    invoke-direct {p0}, Lcom/github/catvod/spider/appysv2/b/U;->z()Ljava/util/Map;

    move-result-object p1

    invoke-virtual {v0, p1}, Lcom/github/catvod/spider/appysv2/c/h;->f(Ljava/util/Map;)Lcom/github/catvod/spider/appysv2/c/h;

    .line 6
    invoke-virtual {v0}, Lcom/github/catvod/spider/appysv2/c/h;->toString()Ljava/lang/String;

    move-result-object p1

    return-object p1

    .line 7
    :cond_119
    new-instance p1, Lcom/github/catvod/spider/appysv2/c/h;

    invoke-direct {p1}, Lcom/github/catvod/spider/appysv2/c/h;-><init>()V

    .line 8
    invoke-virtual {p1, p2}, Lcom/github/catvod/spider/appysv2/c/h;->y(Ljava/lang/String;)Lcom/github/catvod/spider/appysv2/c/h;

    invoke-virtual {p1}, Lcom/github/catvod/spider/appysv2/c/h;->j()Lcom/github/catvod/spider/appysv2/c/h;

    invoke-direct {p0}, Lcom/github/catvod/spider/appysv2/b/U;->z()Ljava/util/Map;

    move-result-object p2

    invoke-virtual {p1, p2}, Lcom/github/catvod/spider/appysv2/c/h;->f(Ljava/util/Map;)Lcom/github/catvod/spider/appysv2/c/h;

    .line 9
    invoke-virtual {p1}, Lcom/github/catvod/spider/appysv2/c/h;->toString()Ljava/lang/String;

    move-result-object p1

    return-object p1

    .line 10
    :cond_130
    invoke-static {}, Lcom/github/catvod/spider/appysv2/p/m;->g()Ljava/lang/String;

    move-result-object p2

    invoke-static {p2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result p2

    if-nez p2, :cond_1c9

    aget-object p2, p1, v8

    aget-object v0, p1, v5

    array-length v1, p1

    if-le v1, v11, :cond_143

    aget-object v9, p1, v11

    :cond_143
    invoke-virtual {p0, p2, v0, v9}, Lcom/github/catvod/spider/appysv2/b/U;->w(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p2

    array-length v0, p1

    if-le v0, v10, :cond_1ae

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-static {}, Lcom/github/catvod/spider/Proxy;->getUrl()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    new-array v1, v7, [B

    fill-array-data v1, :array_322

    new-array v2, v3, [B

    fill-array-data v2, :array_330

    invoke-static {v1, v2}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    aget-object v1, p1, v6

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    new-array v1, v4, [B

    fill-array-data v1, :array_338

    new-array v2, v3, [B

    fill-array-data v2, :array_342

    invoke-static {v1, v2}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    aget-object p1, p1, v10

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    new-array p1, v3, [B

    fill-array-data p1, :array_34a

    new-array v1, v3, [B

    fill-array-data v1, :array_352

    .line 11
    invoke-static {p1, v1, v0}, Lcom/github/catvod/spider/appysv2/b/t;->a([B[BLjava/lang/StringBuilder;)Ljava/lang/String;

    move-result-object p1

    .line 12
    new-instance v0, Lcom/github/catvod/spider/appysv2/c/h;

    invoke-direct {v0}, Lcom/github/catvod/spider/appysv2/c/h;-><init>()V

    .line 13
    invoke-static {p2}, Lcom/github/catvod/spider/appysv2/p/m;->e(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p2

    invoke-virtual {v0, p2}, Lcom/github/catvod/spider/appysv2/c/h;->y(Ljava/lang/String;)Lcom/github/catvod/spider/appysv2/c/h;

    invoke-virtual {v0, p1}, Lcom/github/catvod/spider/appysv2/c/h;->a(Ljava/lang/String;)Lcom/github/catvod/spider/appysv2/c/h;

    invoke-virtual {v0}, Lcom/github/catvod/spider/appysv2/c/h;->j()Lcom/github/catvod/spider/appysv2/c/h;

    invoke-direct {p0}, Lcom/github/catvod/spider/appysv2/b/U;->z()Ljava/util/Map;

    move-result-object p1

    invoke-virtual {v0, p1}, Lcom/github/catvod/spider/appysv2/c/h;->f(Ljava/util/Map;)Lcom/github/catvod/spider/appysv2/c/h;

    .line 14
    invoke-virtual {v0}, Lcom/github/catvod/spider/appysv2/c/h;->toString()Ljava/lang/String;

    move-result-object p1

    return-object p1

    .line 15
    :cond_1ae
    new-instance p1, Lcom/github/catvod/spider/appysv2/c/h;

    invoke-direct {p1}, Lcom/github/catvod/spider/appysv2/c/h;-><init>()V

    .line 16
    invoke-static {p2}, Lcom/github/catvod/spider/appysv2/p/m;->e(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p2

    invoke-virtual {p1, p2}, Lcom/github/catvod/spider/appysv2/c/h;->y(Ljava/lang/String;)Lcom/github/catvod/spider/appysv2/c/h;

    invoke-virtual {p1}, Lcom/github/catvod/spider/appysv2/c/h;->j()Lcom/github/catvod/spider/appysv2/c/h;

    invoke-direct {p0}, Lcom/github/catvod/spider/appysv2/b/U;->z()Ljava/util/Map;

    move-result-object p2

    invoke-virtual {p1, p2}, Lcom/github/catvod/spider/appysv2/c/h;->f(Ljava/util/Map;)Lcom/github/catvod/spider/appysv2/c/h;

    .line 17
    invoke-virtual {p1}, Lcom/github/catvod/spider/appysv2/c/h;->toString()Ljava/lang/String;

    move-result-object p1

    return-object p1

    .line 18
    :cond_1c9
    invoke-virtual {p0}, Lcom/github/catvod/spider/appysv2/b/U;->Q()Z

    move-result p2

    if-eqz p2, :cond_1ff

    aget-object p2, p1, v8

    aget-object v5, p1, v5

    array-length v8, p1

    if-le v8, v11, :cond_1d8

    aget-object v9, p1, v11

    :cond_1d8
    invoke-virtual {p0, p2, v5, v9}, Lcom/github/catvod/spider/appysv2/b/U;->x(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/util/List;

    move-result-object p2

    new-array v2, v2, [B

    fill-array-data v2, :array_35a

    new-array v5, v3, [B

    fill-array-data v5, :array_362

    invoke-static {v2, v5}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Ljava/util/HashMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    new-array v1, v1, [B

    fill-array-data v1, :array_36a

    new-array v2, v3, [B

    fill-array-data v2, :array_372

    invoke-static {v1, v2}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/util/HashMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_20e

    :cond_1ff
    aget-object p2, p1, v8

    aget-object v1, p1, v5

    array-length v2, p1

    if-le v2, v11, :cond_208

    aget-object v9, p1, v11

    :cond_208
    sget-object v2, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    invoke-virtual {p0, p2, v1, v9, v2}, Lcom/github/catvod/spider/appysv2/b/U;->A(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)Ljava/util/List;

    move-result-object p2

    :goto_20e
    invoke-static {}, Lcom/github/catvod/spider/appysv2/p/m;->b()Ljava/lang/Boolean;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v1

    if-eqz v1, :cond_277

    array-length v1, p1

    if-le v1, v10, :cond_277

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-static {}, Lcom/github/catvod/spider/Proxy;->getUrl()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    new-array v2, v7, [B

    fill-array-data v2, :array_37a

    new-array v5, v3, [B

    fill-array-data v5, :array_388

    invoke-static {v2, v5}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    aget-object v2, p1, v6

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    new-array v2, v4, [B

    fill-array-data v2, :array_390

    new-array v4, v3, [B

    fill-array-data v4, :array_39a

    invoke-static {v2, v4}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    aget-object p1, p1, v10

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    new-array p1, v3, [B

    fill-array-data p1, :array_3a2

    new-array v2, v3, [B

    fill-array-data v2, :array_3aa

    .line 19
    invoke-static {p1, v2, v1}, Lcom/github/catvod/spider/appysv2/b/t;->a([B[BLjava/lang/StringBuilder;)Ljava/lang/String;

    move-result-object p1

    .line 20
    new-instance v1, Lcom/github/catvod/spider/appysv2/c/h;

    invoke-direct {v1}, Lcom/github/catvod/spider/appysv2/c/h;-><init>()V

    .line 21
    invoke-virtual {v1, p2}, Lcom/github/catvod/spider/appysv2/c/h;->z(Ljava/util/List;)Lcom/github/catvod/spider/appysv2/c/h;

    invoke-virtual {v1, p1}, Lcom/github/catvod/spider/appysv2/c/h;->a(Ljava/lang/String;)Lcom/github/catvod/spider/appysv2/c/h;

    invoke-virtual {v1}, Lcom/github/catvod/spider/appysv2/c/h;->j()Lcom/github/catvod/spider/appysv2/c/h;

    invoke-virtual {v1, v0}, Lcom/github/catvod/spider/appysv2/c/h;->f(Ljava/util/Map;)Lcom/github/catvod/spider/appysv2/c/h;

    .line 22
    invoke-virtual {v1}, Lcom/github/catvod/spider/appysv2/c/h;->toString()Ljava/lang/String;

    move-result-object p1

    return-object p1

    .line 23
    :cond_277
    new-instance p1, Lcom/github/catvod/spider/appysv2/c/h;

    invoke-direct {p1}, Lcom/github/catvod/spider/appysv2/c/h;-><init>()V

    .line 24
    invoke-virtual {p1, p2}, Lcom/github/catvod/spider/appysv2/c/h;->z(Ljava/util/List;)Lcom/github/catvod/spider/appysv2/c/h;

    invoke-virtual {p1}, Lcom/github/catvod/spider/appysv2/c/h;->j()Lcom/github/catvod/spider/appysv2/c/h;

    invoke-virtual {p1, v0}, Lcom/github/catvod/spider/appysv2/c/h;->f(Ljava/util/Map;)Lcom/github/catvod/spider/appysv2/c/h;

    .line 25
    invoke-virtual {p1}, Lcom/github/catvod/spider/appysv2/c/h;->toString()Ljava/lang/String;

    move-result-object p1

    return-object p1

    :array_28a
    .array-data 1
        -0x20t
        0x61t
        0x57t
        -0x16t
        -0x3t
        0x39t
    .end array-data

    nop

    :array_292
    .array-data 1
        -0x5dt
        0xet
        0x38t
        -0x7ft
        -0x6ct
        0x5ct
        0x3at
        -0x34t
    .end array-data

    :array_29a
    .array-data 1
        -0x3et
        0x42t
        -0xat
        0x20t
        -0x2bt
        -0x54t
        0x37t
    .end array-data

    :array_2a2
    .array-data 1
        -0x70t
        0x27t
        -0x70t
        0x45t
        -0x59t
        -0x37t
        0x45t
        -0x41t
    .end array-data

    :array_2aa
    .array-data 1
        0x6bt
        0xct
        0x5at
        -0x60t
        -0x35t
        0x69t
        0x43t
        -0x53t
        0x67t
        0xat
        0x47t
        -0x5at
        -0x23t
        0x7dt
        0x19t
        -0x1ft
        0x2dt
        0x1bt
        0x40t
    .end array-data

    :array_2b8
    .array-data 1
        0x3t
        0x78t
        0x2et
        -0x30t
        -0x48t
        0x53t
        0x6ct
        -0x7et
    .end array-data

    :array_2c0
    .array-data 1
        0x45t
        0x19t
        0x4dt
        -0x4at
        0x67t
        -0x6at
        0x1t
        -0x58t
        0x7et
        0x1et
    .end array-data

    nop

    :array_2ca
    .array-data 1
        0x10t
        0x6at
        0x28t
        -0x3ct
        0x4at
        -0x29t
        0x66t
        -0x33t
    .end array-data

    :array_2d2
    .array-data 1
        0x2at
        0x40t
        0x2et
        0x3at
        -0xat
        0x51t
        0x7dt
        0x5bt
    .end array-data

    :array_2da
    .array-data 1
        -0x2ft
        -0x64t
        -0x2at
        0x5at
        0x7dt
        -0x50t
    .end array-data

    nop

    :array_2e2
    .array-data 1
        0x34t
        0x12t
        0x49t
        -0x43t
        -0x17t
        0xbt
        -0x26t
        0x21t
    .end array-data

    :array_2ea
    .array-data 1
        0x50t
        0x3dt
        -0x28t
        0x29t
        0x44t
        -0x7dt
        0x29t
        0x74t
        0x1at
        0x7ft
        -0x3ft
        0x7bt
        0x44t
        -0x54t
        0x26t
        0x74t
        0xat
        0x64t
    .end array-data

    nop

    :array_2f8
    .array-data 1
        0x6ft
        0x59t
        -0x49t
        0x14t
        0x20t
        -0x1et
        0x47t
        0x19t
    .end array-data

    :array_300
    .array-data 1
        0x71t
        0x40t
        0x1t
        0x6et
        0x8t
        -0x60t
        0x4ft
        0x5bt
        0x2ft
        0xbt
    .end array-data

    nop

    :array_30a
    .array-data 1
        0x57t
        0x36t
        0x6et
        0xat
        0x41t
        -0x32t
        0x2bt
        0x3et
    .end array-data

    :array_312
    .array-data 1
        0x27t
        0x6t
        0x5ft
        -0x46t
        0x3et
        -0x37t
        0x60t
        0x62t
    .end array-data

    :array_31a
    .array-data 1
        0x1t
        0x70t
        0x30t
        -0x22t
        0x6bt
        -0x45t
        0xct
        0x5ft
    .end array-data

    :array_322
    .array-data 1
        -0x4at
        0x39t
        0x10t
        -0x4t
        0x43t
        -0x20t
        -0x2ft
        0x64t
        -0x4t
        0x7bt
        0x9t
        -0x52t
        0x43t
        -0x31t
        -0x22t
        0x64t
        -0x14t
        0x60t
    .end array-data

    nop

    :array_330
    .array-data 1
        -0x77t
        0x5dt
        0x7ft
        -0x3ft
        0x27t
        -0x7ft
        -0x41t
        0x9t
    .end array-data

    :array_338
    .array-data 1
        -0x44t
        -0x7et
        -0x80t
        0x39t
        -0x6et
        -0x69t
        0x1ft
        -0x2at
        -0x1et
        -0x37t
    .end array-data

    nop

    :array_342
    .array-data 1
        -0x66t
        -0xct
        -0x11t
        0x5dt
        -0x25t
        -0x7t
        0x7bt
        -0x4dt
    .end array-data

    :array_34a
    .array-data 1
        -0x1ft
        0x3dt
        -0x48t
        0x71t
        0x29t
        0x75t
        0x5at
        -0x56t
    .end array-data

    :array_352
    .array-data 1
        -0x39t
        0x4bt
        -0x29t
        0x15t
        0x7ct
        0x7t
        0x36t
        -0x69t
    .end array-data

    :array_35a
    .array-data 1
        0x16t
        0x42t
        0x78t
        0x27t
        -0x5ct
        -0x10t
    .end array-data

    nop

    :array_362
    .array-data 1
        0x55t
        0x2dt
        0x17t
        0x4ct
        -0x33t
        -0x6bt
        -0x22t
        0x7et
    .end array-data

    :array_36a
    .array-data 1
        -0x7bt
        -0x63t
        -0x6at
        -0x64t
        -0x73t
        -0x2ft
        -0x17t
    .end array-data

    :array_372
    .array-data 1
        -0x29t
        -0x8t
        -0x10t
        -0x7t
        -0x1t
        -0x4ct
        -0x65t
        -0x5bt
    .end array-data

    :array_37a
    .array-data 1
        0x31t
        -0x6t
        -0x2dt
        0x72t
        -0x5t
        0x38t
        0x47t
        0x30t
        0x7bt
        -0x48t
        -0x36t
        0x20t
        -0x5t
        0x17t
        0x48t
        0x30t
        0x6bt
        -0x5dt
    .end array-data

    nop

    :array_388
    .array-data 1
        0xet
        -0x62t
        -0x44t
        0x4ft
        -0x61t
        0x59t
        0x29t
        0x5dt
    .end array-data

    :array_390
    .array-data 1
        -0x49t
        -0xat
        -0x33t
        -0x58t
        -0x12t
        0x44t
        0x4et
        -0x40t
        -0x17t
        -0x43t
    .end array-data

    nop

    :array_39a
    .array-data 1
        -0x6ft
        -0x80t
        -0x5et
        -0x34t
        -0x59t
        0x2at
        0x2at
        -0x5bt
    .end array-data

    :array_3a2
    .array-data 1
        -0x7dt
        0x12t
        0x6et
        -0x3bt
        0x37t
        0x31t
        -0x58t
        0x6at
    .end array-data

    :array_3aa
    .array-data 1
        -0x5bt
        0x64t
        0x1t
        -0x5ft
        0x62t
        0x43t
        -0x3ct
        0x57t
    .end array-data
.end method

.method public final M(Ljava/util/Map;)[Ljava/lang/Object;
    .registers 31
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;)[",
            "Ljava/lang/Object;"
        }
    .end annotation

    move-object/from16 v0, p1

    const/4 v1, 0x0

    move-object/from16 v2, p0

    :try_start_5
    iget-object v3, v2, Lcom/github/catvod/spider/appysv2/b/U;->f:Landroid/app/AlertDialog;

    if-eqz v3, :cond_11

    invoke-virtual {v3}, Landroid/app/Dialog;->isShowing()Z

    move-result v3

    if-eqz v3, :cond_11

    const/4 v0, 0x0

    return-object v0

    :cond_11
    const/16 v3, 0xa

    new-array v4, v3, [B

    const/16 v5, -0x25

    aput-byte v5, v4, v1

    const/16 v6, 0x32

    const/4 v7, 0x1

    aput-byte v6, v4, v7

    const/16 v6, -0x60

    const/4 v8, 0x2

    aput-byte v6, v4, v8

    const/16 v6, 0x37

    const/4 v9, 0x3

    aput-byte v6, v4, v9

    const/16 v6, 0xd

    const/4 v10, 0x4

    aput-byte v6, v4, v10

    const/16 v11, -0x23

    const/4 v12, 0x5

    aput-byte v11, v4, v12

    const/16 v11, 0x74

    const/4 v13, 0x6

    aput-byte v11, v4, v13

    const/16 v14, -0x26

    const/4 v15, 0x7

    aput-byte v14, v4, v15

    const/16 v14, -0x1a

    const/16 v6, 0x8

    aput-byte v14, v4, v6

    const/16 v14, 0x33

    const/16 v17, 0x9

    aput-byte v14, v4, v17

    new-array v14, v6, [B

    const/16 v18, -0x51

    aput-byte v18, v14, v1

    const/16 v19, 0x57

    aput-byte v19, v14, v7

    const/16 v20, -0x33

    aput-byte v20, v14, v8

    const/16 v20, 0x47

    aput-byte v20, v14, v9

    const/16 v20, 0x61

    aput-byte v20, v14, v10

    const/16 v20, -0x44

    aput-byte v20, v14, v12

    aput-byte v1, v14, v13

    const/16 v20, -0x41

    aput-byte v20, v14, v15

    invoke-static {v4, v14}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-interface {v0, v4}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/lang/String;

    new-array v4, v15, [B

    const/16 v14, 0x10

    aput-byte v14, v4, v1

    const/16 v20, -0x7d

    aput-byte v20, v4, v7

    const/16 v20, -0x1d

    aput-byte v20, v4, v8

    const/16 v20, 0x2e

    aput-byte v20, v4, v9

    const/16 v21, -0x40

    aput-byte v21, v4, v10

    const/16 v21, -0x77

    aput-byte v21, v4, v12

    const/16 v21, -0x3e

    aput-byte v21, v4, v13

    new-array v11, v6, [B

    const/16 v22, 0x63

    aput-byte v22, v11, v1

    const/16 v22, -0x15

    aput-byte v22, v11, v7

    const/16 v22, -0x7e

    aput-byte v22, v11, v8

    const/16 v22, 0x5c

    aput-byte v22, v11, v9

    const/16 v22, -0x5b

    aput-byte v22, v11, v10

    const/16 v22, -0x40

    aput-byte v22, v11, v12

    const/16 v22, -0x5a

    aput-byte v22, v11, v13

    const/16 v22, 0x55

    aput-byte v22, v11, v15

    invoke-static {v4, v11}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-interface {v0, v4}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/lang/String;

    new-array v4, v15, [B

    const/16 v11, 0x50

    aput-byte v11, v4, v1

    const/4 v11, -0x2

    aput-byte v11, v4, v7

    const/16 v11, 0x7d

    aput-byte v11, v4, v8

    aput-byte v13, v4, v9

    const/4 v11, -0x2

    aput-byte v11, v4, v10

    const/16 v11, -0x75

    aput-byte v11, v4, v12

    const/16 v22, 0x7a

    aput-byte v22, v4, v13

    new-array v11, v6, [B

    const/16 v23, 0x3d

    aput-byte v23, v11, v1

    const/16 v23, -0x65

    aput-byte v23, v11, v7

    const/16 v23, 0x19

    aput-byte v23, v11, v8

    const/16 v23, 0x6f

    aput-byte v23, v11, v9

    const/16 v23, -0x61

    aput-byte v23, v11, v10

    const/16 v24, -0x3e

    aput-byte v24, v11, v12

    const/16 v24, 0x1e

    aput-byte v24, v11, v13

    const/16 v24, -0x77

    aput-byte v24, v11, v15

    invoke-static {v4, v11}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-interface {v0, v4}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/lang/String;

    new-array v4, v13, [B

    const/16 v11, -0x7c

    aput-byte v11, v4, v1

    aput-byte v6, v4, v7

    const/16 v24, 0x6b

    aput-byte v24, v4, v8

    const/16 v24, -0x4c

    aput-byte v24, v4, v9

    const/16 v24, -0x34

    aput-byte v24, v4, v10

    const/16 v24, 0x41

    aput-byte v24, v4, v12

    new-array v11, v6, [B

    const/16 v25, -0x1e

    aput-byte v25, v11, v1

    const/16 v25, 0x61

    aput-byte v25, v11, v7

    aput-byte v15, v11, v8

    const/16 v25, -0x2f

    aput-byte v25, v11, v9

    const/16 v25, -0x7b

    aput-byte v25, v11, v10

    const/16 v25, 0x25

    aput-byte v25, v11, v12

    const/16 v25, -0x4a

    aput-byte v25, v11, v13

    const/16 v25, -0x59

    aput-byte v25, v11, v15

    invoke-static {v4, v11}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-interface {v0, v4}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/lang/String;

    new-array v4, v10, [B

    const/16 v11, -0x17

    aput-byte v11, v4, v1

    const/16 v11, 0x3b

    aput-byte v11, v4, v7

    const/16 v11, 0x69

    aput-byte v11, v4, v8

    const/16 v11, 0x1a

    aput-byte v11, v4, v9

    new-array v11, v6, [B

    const/16 v25, -0x76

    aput-byte v25, v11, v1

    const/16 v25, 0x5a

    aput-byte v25, v11, v7

    const/16 v25, 0x1d

    aput-byte v25, v11, v8

    const/16 v25, 0x7f

    aput-byte v25, v11, v9

    const/16 v25, 0x44

    aput-byte v25, v11, v10

    const/16 v25, -0x69

    aput-byte v25, v11, v12

    const/16 v25, -0x53

    aput-byte v25, v11, v13

    const/16 v25, -0x43

    aput-byte v25, v11, v15

    invoke-static {v4, v11}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-interface {v0, v4}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/lang/String;

    new-array v11, v15, [B

    const/16 v25, -0x56

    aput-byte v25, v11, v1

    aput-byte v20, v11, v7

    const/16 v25, 0x56

    aput-byte v25, v11, v8

    const/16 v25, 0x54

    aput-byte v25, v11, v9

    const/16 v25, -0xf

    aput-byte v25, v11, v10

    const/16 v25, 0x2b

    aput-byte v25, v11, v12

    const/16 v25, 0x68

    aput-byte v25, v11, v13

    new-array v3, v6, [B

    const/16 v26, -0x22

    aput-byte v26, v3, v1

    const/16 v26, 0x41

    aput-byte v26, v3, v7

    const/16 v26, 0x3d

    aput-byte v26, v3, v8

    const/16 v26, 0x31

    aput-byte v26, v3, v9

    aput-byte v23, v3, v10

    const/16 v26, 0x62

    aput-byte v26, v3, v12

    const/16 v5, 0xc

    aput-byte v5, v3, v13

    aput-byte v5, v3, v15

    invoke-static {v11, v3}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v3

    invoke-interface {v0, v3}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/lang/String;

    new-array v3, v9, [B

    const/16 v11, -0xa

    aput-byte v11, v3, v1

    const/16 v11, -0x7f

    aput-byte v11, v3, v7

    const/16 v11, -0x38

    aput-byte v11, v3, v8

    new-array v11, v6, [B

    const/16 v27, -0x7d

    aput-byte v27, v11, v1

    const/16 v27, -0xd

    aput-byte v27, v11, v7

    const/16 v27, -0x5c

    aput-byte v27, v11, v8

    const/16 v27, 0x27

    aput-byte v27, v11, v9

    aput-byte v23, v11, v10

    const/16 v23, -0x4b

    aput-byte v23, v11, v12

    const/16 v23, 0x1a

    aput-byte v23, v11, v13

    aput-byte v14, v11, v15

    invoke-static {v3, v11}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v3

    invoke-interface {v0, v3}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/lang/String;

    const-string v11, ""

    new-array v14, v10, [B

    aput-byte v1, v14, v1

    const/16 v27, -0x2d

    aput-byte v27, v14, v7

    aput-byte v18, v14, v8

    const/16 v26, -0x25

    aput-byte v26, v14, v9

    new-array v5, v6, [B

    const/16 v28, 0x64

    aput-byte v28, v5, v1

    const/16 v28, -0x44

    aput-byte v28, v5, v7

    const/16 v28, -0x28

    aput-byte v28, v5, v8

    const/16 v28, -0x4b

    aput-byte v28, v5, v9

    const/16 v28, 0x73

    aput-byte v28, v5, v10

    const/16 v28, 0x56

    aput-byte v28, v5, v12

    const/16 v28, -0x3f

    aput-byte v28, v5, v13

    const/16 v28, -0x35

    aput-byte v28, v5, v15

    invoke-static {v14, v5}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v5, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_239

    goto :goto_23a

    :cond_239
    move-object v3, v11

    :goto_23a
    new-instance v4, Ljava/util/TreeMap;

    sget-object v5, Ljava/lang/String;->CASE_INSENSITIVE_ORDER:Ljava/util/Comparator;

    invoke-direct {v4, v5}, Ljava/util/TreeMap;-><init>(Ljava/util/Comparator;)V

    new-array v5, v15, [Ljava/lang/String;

    new-array v11, v15, [B

    const/16 v14, 0x28

    aput-byte v14, v11, v1

    const/16 v14, 0x24

    aput-byte v14, v11, v7

    aput-byte v10, v11, v8

    const/16 v14, -0x50

    aput-byte v14, v11, v9

    const/16 v14, 0x5c

    aput-byte v14, v11, v10

    const/16 v14, -0x2c

    aput-byte v14, v11, v12

    const/16 v14, -0x46

    aput-byte v14, v11, v13

    new-array v14, v6, [B

    const/16 v28, 0x5a

    aput-byte v28, v14, v1

    const/16 v28, 0x41

    aput-byte v28, v14, v7

    const/16 v28, 0x62

    aput-byte v28, v14, v8

    const/16 v28, -0x2b

    aput-byte v28, v14, v9

    aput-byte v20, v14, v10

    const/16 v28, -0x4f

    aput-byte v28, v14, v12

    const/16 v28, -0x38

    aput-byte v28, v14, v13

    const/16 v25, 0xa

    aput-byte v25, v14, v15

    invoke-static {v11, v14}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v11

    aput-object v11, v5, v1

    const/16 v11, 0xc

    new-array v14, v11, [B

    const/16 v11, 0x25

    aput-byte v11, v14, v1

    const/16 v11, -0x70

    aput-byte v11, v14, v7

    const/16 v11, -0x2a

    aput-byte v11, v14, v8

    const/16 v11, 0x23

    aput-byte v11, v14, v9

    const/16 v11, -0x3a

    aput-byte v11, v14, v10

    const/16 v11, 0x74

    aput-byte v11, v14, v12

    const/16 v11, -0x49

    aput-byte v11, v14, v13

    const/16 v11, -0x16

    aput-byte v11, v14, v15

    const/16 v11, 0x28

    aput-byte v11, v14, v6

    const/16 v11, -0x6e

    aput-byte v11, v14, v17

    const/16 v11, -0x25

    const/16 v25, 0xa

    aput-byte v11, v14, v25

    const/16 v11, 0xb

    const/16 v26, 0x6f

    aput-byte v26, v14, v11

    new-array v11, v6, [B

    const/16 v26, 0x4c

    aput-byte v26, v11, v1

    const/16 v26, -0xd

    aput-byte v26, v11, v7

    aput-byte v18, v11, v8

    const/16 v18, 0xe

    aput-byte v18, v11, v9

    const/16 v18, -0x55

    aput-byte v18, v11, v10

    const/16 v18, 0x11

    aput-byte v18, v11, v12

    const/16 v18, -0x3d

    aput-byte v18, v11, v13

    const/16 v18, -0x75

    aput-byte v18, v11, v15

    invoke-static {v14, v11}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v11

    aput-object v11, v5, v7

    new-array v11, v12, [B

    const/16 v14, -0x43

    aput-byte v14, v11, v1

    const/16 v14, -0x3f

    aput-byte v14, v11, v7

    const/16 v14, -0x5b

    aput-byte v14, v11, v8

    const/16 v14, -0x7e

    aput-byte v14, v11, v9

    const/16 v14, -0x67

    aput-byte v14, v11, v10

    new-array v14, v6, [B

    const/16 v18, -0x31

    aput-byte v18, v14, v1

    const/16 v18, -0x60

    aput-byte v18, v14, v7

    const/16 v18, -0x35

    aput-byte v18, v14, v8

    const/16 v18, -0x1b

    aput-byte v18, v14, v9

    const/16 v18, -0x4

    aput-byte v18, v14, v10

    const/16 v18, 0x19

    aput-byte v18, v14, v12

    const/16 v16, 0xd

    aput-byte v16, v14, v13

    const/16 v18, -0x34

    aput-byte v18, v14, v15

    invoke-static {v11, v14}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v11

    aput-object v11, v5, v8

    const/16 v11, 0xa

    new-array v14, v11, [B

    const/16 v11, -0x26

    aput-byte v11, v14, v1

    const/16 v11, -0x2c

    aput-byte v11, v14, v7

    const/16 v11, -0x59

    aput-byte v11, v14, v8

    const/16 v11, 0x68

    aput-byte v11, v14, v9

    const/16 v11, -0x10

    aput-byte v11, v14, v10

    aput-byte v15, v14, v12

    const/16 v11, 0x55

    aput-byte v11, v14, v13

    const/16 v11, -0x67

    aput-byte v11, v14, v15

    const/16 v11, -0x2a

    aput-byte v11, v14, v6

    const/16 v11, -0x2b

    aput-byte v11, v14, v17

    new-array v11, v6, [B

    const/16 v18, -0x47

    aput-byte v18, v11, v1

    const/16 v18, -0x45

    aput-byte v18, v11, v7

    const/16 v18, -0x37

    aput-byte v18, v11, v8

    aput-byte v13, v11, v9

    const/16 v18, -0x6b

    aput-byte v18, v11, v10

    const/16 v18, 0x64

    aput-byte v18, v11, v12

    const/16 v18, 0x21

    aput-byte v18, v11, v13

    const/16 v18, -0x10

    aput-byte v18, v11, v15

    invoke-static {v14, v11}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v11

    aput-object v11, v5, v9

    const/16 v11, 0xf

    new-array v11, v11, [B

    const/16 v14, -0x7b

    aput-byte v14, v11, v1

    aput-byte v19, v11, v7

    const/16 v14, 0x46

    aput-byte v14, v11, v8

    const/16 v14, 0x75

    aput-byte v14, v11, v9

    const/16 v14, -0xa

    aput-byte v14, v11, v10

    const/16 v14, 0x47

    aput-byte v14, v11, v12

    const/16 v14, -0x56

    aput-byte v14, v11, v13

    const/16 v14, 0x20

    aput-byte v14, v11, v15

    const/16 v14, -0x76

    aput-byte v14, v11, v6

    aput-byte v19, v11, v17

    const/16 v14, 0x4a

    const/16 v18, 0xa

    aput-byte v14, v11, v18

    const/16 v14, 0xb

    const/16 v18, 0x74

    aput-byte v18, v11, v14

    const/16 v14, -0x11

    const/16 v18, 0xc

    aput-byte v14, v11, v18

    const/16 v14, 0x5d

    const/16 v16, 0xd

    aput-byte v14, v11, v16

    const/16 v14, 0xe

    const/16 v16, -0x20

    aput-byte v16, v11, v14

    new-array v14, v6, [B

    const/16 v16, -0x1c

    aput-byte v16, v14, v1

    const/16 v16, 0x34

    aput-byte v16, v14, v7

    const/16 v16, 0x25

    aput-byte v16, v14, v8

    const/16 v16, 0x10

    aput-byte v16, v14, v9

    const/16 v16, -0x7a

    aput-byte v16, v14, v10

    const/16 v16, 0x33

    aput-byte v16, v14, v12

    const/16 v16, -0x79

    aput-byte v16, v14, v13

    const/16 v16, 0x45

    aput-byte v16, v14, v15

    invoke-static {v11, v14}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v11

    aput-object v11, v5, v10

    const/16 v11, 0xa

    new-array v11, v11, [B

    const/16 v14, -0x50

    aput-byte v14, v11, v1

    const/16 v14, -0x74

    aput-byte v14, v11, v7

    const/16 v14, -0x7c

    aput-byte v14, v11, v8

    const/16 v14, -0x6f

    aput-byte v14, v11, v9

    const/16 v14, -0x47

    aput-byte v14, v11, v10

    aput-byte v20, v11, v12

    const/16 v14, -0x2e

    aput-byte v14, v11, v13

    const/16 v14, 0x77

    aput-byte v14, v11, v15

    const/16 v14, -0x55

    aput-byte v14, v11, v6

    const/16 v14, -0x75

    aput-byte v14, v11, v17

    new-array v14, v6, [B

    const/16 v16, -0x3b

    aput-byte v16, v14, v1

    const/16 v16, -0x1

    aput-byte v16, v14, v7

    const/16 v16, -0x1f

    aput-byte v16, v14, v8

    const/16 v16, -0x1d

    aput-byte v16, v14, v9

    const/16 v16, -0x6c

    aput-byte v16, v14, v10

    const/16 v16, 0x4f

    aput-byte v16, v14, v12

    const/16 v16, -0x4b

    aput-byte v16, v14, v13

    const/16 v16, 0x12

    aput-byte v16, v14, v15

    invoke-static {v11, v14}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v11

    aput-object v11, v5, v12

    new-array v11, v13, [B

    const/16 v14, -0x6e

    aput-byte v14, v11, v1

    const/16 v14, 0x7d

    aput-byte v14, v11, v7

    const/16 v14, 0x38

    aput-byte v14, v11, v8

    const/16 v14, 0x60

    aput-byte v14, v11, v9

    const/16 v14, -0x7c

    aput-byte v14, v11, v10

    aput-byte v9, v11, v12

    new-array v6, v6, [B

    const/16 v14, -0xf

    aput-byte v14, v6, v1

    const/16 v14, 0x12

    aput-byte v14, v6, v7

    aput-byte v19, v6, v8

    const/16 v7, 0xb

    aput-byte v7, v6, v9

    const/16 v7, -0x13

    aput-byte v7, v6, v10

    const/16 v7, 0x66

    aput-byte v7, v6, v12

    const/16 v7, 0x11

    aput-byte v7, v6, v13

    const/16 v7, -0x11

    aput-byte v7, v6, v15

    invoke-static {v11, v6}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v6

    aput-object v6, v5, v13

    invoke-static {v5}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v5

    invoke-interface/range {p1 .. p1}, Ljava/util/Map;->keySet()Ljava/util/Set;

    move-result-object v6

    invoke-interface {v6}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v6

    :cond_47b
    :goto_47b
    invoke-interface {v6}, Ljava/util/Iterator;->hasNext()Z

    move-result v7

    if-eqz v7, :cond_497

    invoke-interface {v6}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Ljava/lang/String;

    invoke-interface {v5, v7}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    move-result v8

    if-eqz v8, :cond_47b

    invoke-interface {v0, v7}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v8

    check-cast v8, Ljava/lang/String;

    invoke-virtual {v4, v7, v8}, Ljava/util/TreeMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_47b

    :cond_497
    invoke-static {v3, v4}, Lcom/github/catvod/spider/appysv2/p/m;->h(Ljava/lang/String;Ljava/util/Map;)[Ljava/lang/Object;

    move-result-object v0
    :try_end_49b
    .catch Ljava/lang/Exception; {:try_start_5 .. :try_end_49b} :catch_49c

    return-object v0

    :catch_49c
    new-array v0, v1, [Ljava/lang/Object;

    return-object v0
.end method

.method public final N(Ljava/lang/String;)Ljava/lang/String;
    .registers 20

    move-object/from16 v1, p0

    move-object/from16 v0, p1

    sget-object v2, Lcom/github/catvod/spider/appysv2/b/U;->j:Ljava/util/HashMap;

    invoke-virtual {v2, v0}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcom/github/catvod/spider/appysv2/l/e;

    iput-object v2, v1, Lcom/github/catvod/spider/appysv2/b/U;->e:Lcom/github/catvod/spider/appysv2/l/e;

    const/16 v3, 0x8

    if-eqz v2, :cond_40

    invoke-virtual {v2, v0}, Lcom/github/catvod/spider/appysv2/l/e;->a(Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_40

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/16 v4, 0xe

    new-array v4, v4, [B

    fill-array-data v4, :array_18c

    new-array v5, v3, [B

    fill-array-data v5, :array_198

    invoke-static {v4, v5}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v4, v1, Lcom/github/catvod/spider/appysv2/b/U;->e:Lcom/github/catvod/spider/appysv2/l/e;

    invoke-virtual {v4}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Lcom/github/catvod/crawler/SpiderDebug;->log(Ljava/lang/String;)V

    :cond_40
    iget-object v2, v1, Lcom/github/catvod/spider/appysv2/b/U;->e:Lcom/github/catvod/spider/appysv2/l/e;

    if-eqz v2, :cond_55

    invoke-virtual {v2, v0}, Lcom/github/catvod/spider/appysv2/l/e;->a(Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_55

    iget-object v0, v1, Lcom/github/catvod/spider/appysv2/b/U;->e:Lcom/github/catvod/spider/appysv2/l/e;

    invoke-virtual {v0}, Lcom/github/catvod/spider/appysv2/l/e;->b()Lcom/github/catvod/spider/appysv2/l/d;

    move-result-object v0

    invoke-virtual {v0}, Lcom/github/catvod/spider/appysv2/l/d;->a()Ljava/lang/String;

    move-result-object v0

    return-object v0

    :cond_55
    const/16 v2, 0x4a

    new-array v2, v2, [B

    fill-array-data v2, :array_1a0

    new-array v4, v3, [B

    fill-array-data v4, :array_1ca

    invoke-static {v2, v4}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v2

    new-instance v4, Lcom/google/gson/JsonObject;

    invoke-direct {v4}, Lcom/google/gson/JsonObject;-><init>()V

    const/4 v5, 0x6

    new-array v6, v5, [B

    fill-array-data v6, :array_1d2

    new-array v7, v3, [B

    fill-array-data v7, :array_1da

    invoke-static {v6, v7}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v4, v6, v0}, Lcom/google/gson/JsonObject;->addProperty(Ljava/lang/String;Ljava/lang/String;)V

    new-array v6, v3, [B

    fill-array-data v6, :array_1e2

    new-array v7, v3, [B

    fill-array-data v7, :array_1ea

    invoke-static {v6, v7}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v6

    const-string v7, ""

    invoke-virtual {v4, v6, v7}, Lcom/google/gson/JsonObject;->addProperty(Ljava/lang/String;Ljava/lang/String;)V

    .line 1
    invoke-virtual {v4}, Lcom/google/gson/JsonElement;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-direct/range {p0 .. p0}, Lcom/github/catvod/spider/appysv2/b/U;->y()Ljava/util/Map;

    move-result-object v6

    invoke-static {v2, v4, v6}, Lcom/github/catvod/spider/appysv2/n/c;->g(Ljava/lang/String;Ljava/lang/String;Ljava/util/Map;)Lcom/github/catvod/spider/appysv2/n/e;

    move-result-object v2

    invoke-virtual {v2}, Lcom/github/catvod/spider/appysv2/n/e;->a()Ljava/lang/String;

    move-result-object v2

    .line 2
    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const/16 v6, 0x15

    new-array v8, v6, [B

    fill-array-data v8, :array_1f2

    new-array v9, v3, [B

    fill-array-data v9, :array_202

    .line 3
    invoke-static {v8, v9, v4, v0}, Lcom/github/catvod/spider/appysv2/b/v;->c([B[BLjava/lang/StringBuilder;Ljava/lang/String;)V

    const/4 v8, 0x4

    new-array v9, v8, [B

    .line 4
    fill-array-data v9, :array_20a

    new-array v10, v3, [B

    fill-array-data v10, :array_210

    invoke-static {v9, v10}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v4, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-static {v4}, Lcom/github/catvod/crawler/SpiderDebug;->log(Ljava/lang/String;)V

    .line 5
    :try_start_cf
    new-instance v4, Lcom/google/gson/Gson;

    invoke-direct {v4}, Lcom/google/gson/Gson;-><init>()V

    const-class v9, Lcom/github/catvod/spider/appysv2/l/e;

    invoke-virtual {v4, v2, v9}, Lcom/google/gson/Gson;->fromJson(Ljava/lang/String;Ljava/lang/Class;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcom/github/catvod/spider/appysv2/l/e;

    .line 6
    iput-object v2, v1, Lcom/github/catvod/spider/appysv2/b/U;->e:Lcom/github/catvod/spider/appysv2/l/e;

    invoke-virtual {v2, v0}, Lcom/github/catvod/spider/appysv2/l/e;->e(Ljava/lang/String;)Lcom/github/catvod/spider/appysv2/l/e;

    invoke-virtual {v2}, Lcom/github/catvod/spider/appysv2/l/e;->f()Lcom/github/catvod/spider/appysv2/l/e;

    sget-object v2, Lcom/github/catvod/spider/appysv2/b/U;->j:Ljava/util/HashMap;

    iget-object v4, v1, Lcom/github/catvod/spider/appysv2/b/U;->e:Lcom/github/catvod/spider/appysv2/l/e;

    invoke-virtual {v2, v0, v4}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    iget-object v0, v1, Lcom/github/catvod/spider/appysv2/b/U;->e:Lcom/github/catvod/spider/appysv2/l/e;

    invoke-virtual {v0}, Lcom/github/catvod/spider/appysv2/l/e;->b()Lcom/github/catvod/spider/appysv2/l/d;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v4, 0x1

    if-nez v0, :cond_f7

    const/4 v0, 0x1

    goto :goto_f8

    :cond_f7
    const/4 v0, 0x0

    :goto_f8
    if-eqz v0, :cond_fb

    return-object v7

    :cond_fb
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/16 v9, 0xb

    new-array v9, v9, [B

    const/16 v10, -0x39

    aput-byte v10, v9, v2

    aput-byte v2, v9, v4

    const/4 v10, 0x2

    aput-byte v3, v9, v10

    const/16 v11, 0x7e

    const/4 v12, 0x3

    aput-byte v11, v9, v12

    const/16 v11, -0x22

    aput-byte v11, v9, v8

    const/16 v11, -0x75

    const/4 v13, 0x5

    aput-byte v11, v9, v13

    const/16 v11, 0x70

    aput-byte v11, v9, v5

    const/16 v11, -0x4e

    const/4 v14, 0x7

    aput-byte v11, v9, v14

    const/16 v15, -0x29

    aput-byte v15, v9, v3

    const/16 v15, 0x9

    const/16 v16, 0xd

    aput-byte v16, v9, v15

    const/16 v15, 0xa

    const/16 v17, 0x12

    aput-byte v17, v9, v15

    new-array v15, v3, [B

    aput-byte v11, v15, v2

    const/16 v2, 0x63

    aput-byte v2, v15, v4

    const/16 v2, 0x28

    aput-byte v2, v15, v10

    aput-byte v16, v15, v12

    const/16 v2, -0x56

    aput-byte v2, v15, v8

    const/16 v2, -0x21

    aput-byte v2, v15, v13

    const/16 v2, 0x1f

    aput-byte v2, v15, v5

    const/16 v2, -0x27

    aput-byte v2, v15, v14

    invoke-static {v9, v15}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v2, v1, Lcom/github/catvod/spider/appysv2/b/U;->e:Lcom/github/catvod/spider/appysv2/l/e;

    invoke-virtual {v2}, Lcom/github/catvod/spider/appysv2/l/e;->b()Lcom/github/catvod/spider/appysv2/l/d;

    move-result-object v2

    invoke-virtual {v2}, Lcom/github/catvod/spider/appysv2/l/d;->a()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lcom/github/catvod/crawler/SpiderDebug;->log(Ljava/lang/String;)V

    iget-object v0, v1, Lcom/github/catvod/spider/appysv2/b/U;->e:Lcom/github/catvod/spider/appysv2/l/e;

    invoke-virtual {v0}, Lcom/github/catvod/spider/appysv2/l/e;->b()Lcom/github/catvod/spider/appysv2/l/d;

    move-result-object v0

    invoke-virtual {v0}, Lcom/github/catvod/spider/appysv2/l/d;->a()Ljava/lang/String;

    move-result-object v0
    :try_end_177
    .catch Ljava/lang/Exception; {:try_start_cf .. :try_end_177} :catch_178

    return-object v0

    :catch_178
    move-exception v0

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    new-array v4, v6, [B

    fill-array-data v4, :array_218

    new-array v3, v3, [B

    fill-array-data v3, :array_228

    .line 7
    invoke-static {v4, v3, v2, v0}, Lcom/github/catvod/spider/appysv2/b/y;->b([B[BLjava/lang/StringBuilder;Ljava/lang/Exception;)V

    return-object v7

    :array_18c
    .array-data 1
        0xbt
        0x62t
        0x3at
        0x1bt
        0x2bt
        -0x7bt
        -0x3ct
        0x3ft
        0x2at
        0x6et
        0x71t
        0xdt
        0x2dt
        -0x22t
    .end array-data

    nop

    :array_198
    .array-data 1
        0x7et
        0x1t
        0x1at
        0x68t
        0x43t
        -0x1ct
        -0x4at
        0x5at
    .end array-data

    :array_1a0
    .array-data 1
        0x5t
        0x29t
        0x50t
        -0x1bt
        -0x70t
        -0x5t
        -0x73t
        -0x5et
        0x1dt
        0x3et
        0x9t
        -0xct
        -0x6dt
        -0x58t
        -0x74t
        -0x8t
        0xet
        0x73t
        0x47t
        -0x5t
        -0x34t
        -0x10t
        -0x73t
        -0x12t
        0x1t
        0x32t
        0x51t
        -0xft
        -0x79t
        -0x4dt
        -0x35t
        -0x5t
        0x8t
        0x72t
        0x57t
        -0x3t
        -0x7et
        -0x4dt
        -0x39t
        -0x5et
        0x1et
        0x35t
        0x45t
        -0x19t
        -0x7at
        -0x4ft
        -0x3dt
        -0x16t
        0x8t
        0x72t
        0x50t
        -0x6t
        -0x78t
        -0x5ct
        -0x34t
        -0x4et
        0x1dt
        0x2ft
        0x19t
        -0x40t
        -0x60t
        -0x7dt
        -0x30t
        -0x1et
        0x1at
        0x2et
        0x41t
        -0x19t
        -0x3bt
        -0x59t
        -0x30t
        -0x50t
        0x1dt
        0x3et
    .end array-data

    nop

    :array_1ca
    .array-data 1
        0x6dt
        0x5dt
        0x24t
        -0x6bt
        -0x1dt
        -0x3ft
        -0x5et
        -0x73t
    .end array-data

    :array_1d2
    .array-data 1
        -0x2et
        -0x54t
        -0x43t
        -0x32t
        0x35t
        0x42t
    .end array-data

    nop

    :array_1da
    .array-data 1
        -0x5et
        -0x25t
        -0x27t
        -0x6ft
        0x5ct
        0x26t
        0x3ct
        -0x4ct
    .end array-data

    :array_1e2
    .array-data 1
        0x9t
        0x10t
        0x16t
        0x35t
        0x2dt
        -0x35t
        0x36t
        -0x68t
    .end array-data

    :array_1ea
    .array-data 1
        0x79t
        0x71t
        0x65t
        0x46t
        0x4et
        -0x5ct
        0x52t
        -0x3t
    .end array-data

    :array_1f2
    .array-data 1
        -0x1at
        0x46t
        -0x2at
        -0x50t
        -0xbt
        0x74t
        -0x13t
        0x4bt
        -0x40t
        0x6dt
        -0x5bt
        -0x56t
        -0xft
        0x60t
        -0x6t
        0x7at
        -0x24t
        0x6et
        -0x6dt
        -0x54t
        -0x35t
    .end array-data

    nop

    :array_202
    .array-data 1
        -0x4dt
        0x5t
        -0xat
        -0x3et
        -0x70t
        0x12t
        -0x61t
        0x2et
    .end array-data

    :array_20a
    .array-data 1
        0x61t
        -0x55t
        0x7ft
        0x20t
    .end array-data

    :array_210
    .array-data 1
        0x3ct
        -0x7bt
        0x51t
        0xet
        -0x6ct
        -0x6ct
        -0x1et
        0x6ct
    .end array-data

    :array_218
    .array-data 1
        0x70t
        0x46t
        -0x5et
        0x3ct
        0x22t
        0x16t
        0x66t
        0x4bt
        0x6at
        0x42t
        -0x4at
        0x2bt
        0x13t
        0xat
        0x65t
        0x7dt
        0x6ct
        0x3t
        -0x6ft
        0x2dt
        0x7dt
    .end array-data

    nop

    :array_228
    .array-data 1
        0x2t
        0x23t
        -0x3ct
        0x4et
        0x47t
        0x65t
        0xet
        0x18t
    .end array-data
.end method

.method public final Q()Z
    .registers 22

    move-object/from16 v1, p0

    const-string v0, ""

    const/16 v2, 0x8

    const/4 v3, 0x0

    :try_start_7
    iget-object v4, v1, Lcom/github/catvod/spider/appysv2/b/U;->b:Lorg/json/JSONObject;

    const/16 v5, -0x46

    const/16 v6, 0x22

    const/16 v7, 0x56

    const/16 v8, -0x6b

    const/4 v9, 0x6

    const/4 v10, 0x3

    const/4 v11, 0x2

    const/4 v12, 0x5

    const/4 v13, 0x4

    const/4 v14, 0x1

    if-eqz v4, :cond_5a

    new-array v15, v9, [B

    const/16 v16, 0x21

    aput-byte v16, v15, v3

    const/16 v16, 0xd

    aput-byte v16, v15, v14

    const/16 v16, 0x28

    aput-byte v16, v15, v11

    aput-byte v6, v15, v10

    const/4 v6, -0x4

    aput-byte v6, v15, v13

    const/16 v6, -0x37

    aput-byte v6, v15, v12

    new-array v6, v2, [B

    const/16 v16, 0x52

    aput-byte v16, v6, v3

    const/16 v16, 0x79

    aput-byte v16, v6, v14

    const/16 v16, 0x49

    aput-byte v16, v6, v11

    aput-byte v7, v6, v10

    const/16 v16, -0x77

    aput-byte v16, v6, v13

    aput-byte v5, v6, v12

    aput-byte v8, v6, v9

    const/16 v5, -0x2b

    const/16 v16, 0x7

    aput-byte v5, v6, v16

    invoke-static {v15, v6}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;)I

    move-result v4

    if-eqz v4, :cond_59

    goto :goto_5a

    :cond_59
    return v14

    :cond_5a
    :goto_5a
    new-array v4, v12, [B

    aput-byte v2, v4, v3

    aput-byte v13, v4, v14

    const/16 v5, -0x4b

    aput-byte v5, v4, v11

    const/16 v5, 0x61

    aput-byte v5, v4, v10

    const/16 v5, -0x5e

    aput-byte v5, v4, v13

    new-array v5, v2, [B

    const/16 v6, 0x26

    aput-byte v6, v5, v3

    const/16 v15, 0x71

    aput-byte v15, v5, v14

    const/16 v15, -0x2a

    aput-byte v15, v5, v11

    const/16 v15, 0x15

    aput-byte v15, v5, v10

    const/16 v15, -0x2c

    aput-byte v15, v5, v13

    aput-byte v8, v5, v12

    const/16 v8, -0xb

    aput-byte v8, v5, v9

    const/16 v8, -0x42

    const/4 v15, 0x7

    aput-byte v8, v5, v15

    invoke-static {v4, v5}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-static {v4}, Lcom/github/catvod/spider/appysv2/p/C;->q(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-static {v4}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v5

    const/16 v8, 0x76

    const/16 v15, 0xa

    const/16 v17, 0x9

    if-nez v5, :cond_1de

    new-instance v5, Lorg/json/JSONObject;

    invoke-direct {v5, v4}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    iput-object v5, v1, Lcom/github/catvod/spider/appysv2/b/U;->b:Lorg/json/JSONObject;

    new-array v4, v15, [B

    const/16 v18, -0x41

    aput-byte v18, v4, v3

    const/16 v18, 0x3b

    aput-byte v18, v4, v14

    const/16 v18, -0x44

    aput-byte v18, v4, v11

    const/16 v18, 0x54

    aput-byte v18, v4, v10

    const/16 v18, -0x70

    aput-byte v18, v4, v13

    const/16 v18, -0x6c

    aput-byte v18, v4, v12

    aput-byte v7, v4, v9

    const/4 v7, 0x7

    aput-byte v8, v4, v7

    const/16 v7, -0x5f

    aput-byte v7, v4, v2

    const/16 v7, 0x2a

    aput-byte v7, v4, v17

    new-array v7, v2, [B

    const/16 v8, -0x34

    aput-byte v8, v7, v3

    const/16 v8, 0x4f

    aput-byte v8, v7, v14

    const/16 v8, -0x23

    aput-byte v8, v7, v11

    aput-byte v6, v7, v10

    const/16 v6, -0x1c

    aput-byte v6, v7, v13

    const/16 v6, -0x35

    aput-byte v6, v7, v12

    const/16 v6, 0x22

    aput-byte v6, v7, v9

    const/16 v6, 0x1f

    const/16 v18, 0x7

    aput-byte v6, v7, v18

    invoke-static {v4, v7}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v5, v4}, Lorg/json/JSONObject;->optLong(Ljava/lang/String;)J

    move-result-wide v4

    iget-object v6, v1, Lcom/github/catvod/spider/appysv2/b/U;->b:Lorg/json/JSONObject;

    new-array v7, v15, [B

    const/16 v15, -0x2d

    aput-byte v15, v7, v3

    const/16 v15, -0x71

    aput-byte v15, v7, v14

    const/16 v15, -0x46

    aput-byte v15, v7, v11

    const/16 v15, -0x9

    aput-byte v15, v7, v10

    const/16 v18, -0x65

    aput-byte v18, v7, v13

    const/16 v18, 0xb

    aput-byte v18, v7, v12

    const/16 v16, -0x1a

    aput-byte v16, v7, v9

    const/16 v16, 0x34

    const/16 v18, 0x7

    aput-byte v16, v7, v18

    const/16 v16, -0x21

    aput-byte v16, v7, v2

    const/16 v16, -0x67

    aput-byte v16, v7, v17

    new-array v8, v2, [B

    const/16 v17, -0x4a

    aput-byte v17, v8, v3

    aput-byte v15, v8, v14

    const/16 v15, -0x36

    aput-byte v15, v8, v11

    const/16 v15, -0x62

    aput-byte v15, v8, v10

    const/16 v15, -0x17

    aput-byte v15, v8, v13

    const/16 v15, 0x6e

    aput-byte v15, v8, v12

    const/16 v15, -0x6b

    aput-byte v15, v8, v9

    const/16 v15, 0x6b

    const/16 v17, 0x7

    aput-byte v15, v8, v17

    invoke-static {v7, v8}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v6, v7}, Lorg/json/JSONObject;->optLong(Ljava/lang/String;)J

    move-result-wide v6

    const-wide/16 v17, 0x1c20

    add-long/2addr v4, v6

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v6

    const-wide/16 v19, 0x3e8

    div-long v6, v6, v19
    :try_end_15c
    .catch Ljava/lang/Exception; {:try_start_7 .. :try_end_15c} :catch_233

    sub-long/2addr v4, v6

    cmp-long v6, v4, v17

    if-lez v6, :cond_162

    return v14

    :cond_162
    :try_start_162
    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v5

    invoke-virtual {v4, v5, v6}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    iget-object v5, v1, Lcom/github/catvod/spider/appysv2/b/U;->b:Lorg/json/JSONObject;

    const/16 v6, 0x9

    new-array v6, v6, [B

    const/4 v7, -0x8

    aput-byte v7, v6, v3

    const/16 v8, -0x72

    aput-byte v8, v6, v14

    const/16 v8, 0x43

    aput-byte v8, v6, v11

    const/16 v8, -0x4c

    aput-byte v8, v6, v10

    const/16 v8, -0x7e

    aput-byte v8, v6, v13

    const/16 v8, -0xc

    aput-byte v8, v6, v12

    const/4 v8, -0x7

    aput-byte v8, v6, v9

    const/16 v8, 0x23

    const/4 v15, 0x7

    aput-byte v8, v6, v15

    aput-byte v7, v6, v2

    new-array v2, v2, [B

    const/16 v7, -0x64

    aput-byte v7, v2, v3

    const/16 v3, -0x15

    aput-byte v3, v2, v14

    const/16 v3, 0x35

    aput-byte v3, v2, v11

    const/16 v3, -0x23

    aput-byte v3, v2, v10

    const/16 v3, -0x1f

    aput-byte v3, v2, v13

    const/16 v3, -0x6f

    aput-byte v3, v2, v12

    const/16 v3, -0x5a

    aput-byte v3, v2, v9

    const/16 v3, 0x4a

    const/4 v7, 0x7

    aput-byte v3, v2, v7

    invoke-static {v6, v2}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v5, v2}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-static {v3}, Lcom/github/catvod/spider/appysv2/p/C;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-direct {v1, v3, v2, v0}, Lcom/github/catvod/spider/appysv2/b/U;->G(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    :try_end_1dd
    .catch Ljava/lang/Exception; {:try_start_162 .. :try_end_1dd} :catch_1dd

    :catch_1dd
    return v14

    :cond_1de
    :try_start_1de
    new-instance v0, Ljava/lang/Exception;

    new-array v4, v15, [B

    const/16 v5, 0x3c

    aput-byte v5, v4, v3

    const/16 v5, 0x7a

    aput-byte v5, v4, v14

    const/16 v5, 0x5e

    aput-byte v5, v4, v11

    const/16 v5, -0x1a

    aput-byte v5, v4, v10

    const/16 v5, 0x1e

    aput-byte v5, v4, v13

    aput-byte v7, v4, v12

    const/4 v5, -0x1

    aput-byte v5, v4, v9

    const/16 v5, -0x32

    const/4 v6, 0x7

    aput-byte v5, v4, v6

    const/16 v5, 0x2c

    aput-byte v5, v4, v2

    const/16 v5, 0x74

    const/16 v6, 0x9

    aput-byte v5, v4, v6

    new-array v5, v2, [B

    const/16 v6, 0x59

    aput-byte v6, v5, v3

    const/16 v6, 0x17

    aput-byte v6, v5, v14

    const/16 v6, 0x2e

    aput-byte v6, v5, v11

    const/16 v6, -0x6e

    aput-byte v6, v5, v10

    const/16 v6, 0x67

    aput-byte v6, v5, v13

    aput-byte v8, v5, v12

    const/16 v6, -0x75

    aput-byte v6, v5, v9

    const/16 v6, -0x48

    const/4 v7, 0x7

    aput-byte v6, v5, v7

    invoke-static {v4, v5}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-direct {v0, v4}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V

    throw v0
    :try_end_233
    .catch Ljava/lang/Exception; {:try_start_1de .. :try_end_233} :catch_233

    :catch_233
    move-exception v0

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const/16 v5, 0xe

    new-array v5, v5, [B

    fill-array-data v5, :array_24a

    new-array v2, v2, [B

    fill-array-data v2, :array_256

    .line 1
    invoke-static {v5, v2, v4, v0}, Lcom/github/catvod/spider/appysv2/b/y;->b([B[BLjava/lang/StringBuilder;Ljava/lang/Exception;)V

    return v3

    nop

    :array_24a
    .array-data 1
        0x38t
        0x2et
        -0x6ft
        -0x1at
        -0x7dt
        -0x27t
        0x69t
        -0x62t
        0x2et
        0x28t
        -0x6ft
        -0x6et
        -0x70t
        -0x54t
    .end array-data

    nop

    :array_256
    .array-data 1
        0x4bt
        0x4bt
        -0x1bt
        -0x4et
        -0xbt
        -0x6at
        0xbt
        -0xct
    .end array-data
.end method

.method public final R()V
    .registers 29

    move-object/from16 v1, p0

    const/16 v2, 0xf

    const/16 v0, 0x10

    const/16 v3, 0x8

    :try_start_8
    invoke-static {v0}, Lcom/github/catvod/spider/appysv2/a/a;->b(I)I

    move-result v4

    new-instance v5, Landroid/widget/FrameLayout$LayoutParams;

    const/4 v6, -0x1

    const/4 v7, -0x2

    invoke-direct {v5, v6, v7}, Landroid/widget/FrameLayout$LayoutParams;-><init>(II)V

    new-instance v6, Landroid/widget/FrameLayout;

    invoke-static {}, Lcom/github/catvod/spider/Init;->context()Landroid/app/Application;

    move-result-object v7

    invoke-direct {v6, v7}, Landroid/widget/FrameLayout;-><init>(Landroid/content/Context;)V

    invoke-virtual {v5, v4, v4, v4, v4}, Landroid/view/ViewGroup$MarginLayoutParams;->setMargins(IIII)V

    new-instance v4, Landroid/widget/EditText;

    invoke-static {}, Lcom/github/catvod/spider/Init;->context()Landroid/app/Application;

    move-result-object v7

    invoke-direct {v4, v7}, Landroid/widget/EditText;-><init>(Landroid/content/Context;)V

    invoke-virtual {v6, v4, v5}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    new-instance v5, Landroid/app/AlertDialog$Builder;

    invoke-static {}, Lcom/github/catvod/spider/Init;->getActivity()Landroid/app/Activity;

    move-result-object v7

    invoke-direct {v5, v7}, Landroid/app/AlertDialog$Builder;-><init>(Landroid/content/Context;)V

    const/16 v7, 0x2e

    new-array v7, v7, [B

    const/16 v8, 0x6d

    const/4 v9, 0x0

    aput-byte v8, v7, v9

    const/16 v8, -0x39

    const/4 v10, 0x1

    aput-byte v8, v7, v10

    const/16 v8, -0xd

    const/4 v11, 0x2

    aput-byte v8, v7, v11

    const/16 v8, -0x58

    const/4 v12, 0x3

    aput-byte v8, v7, v12

    const/16 v8, -0x49

    const/4 v13, 0x4

    aput-byte v8, v7, v13

    const/16 v14, 0x4e

    const/4 v15, 0x5

    aput-byte v14, v7, v15

    const/16 v14, 0x37

    const/16 v16, 0x6

    aput-byte v14, v7, v16

    const/16 v14, -0x62

    const/16 v17, 0x7

    aput-byte v14, v7, v17

    const/16 v18, 0x20

    aput-byte v18, v7, v3

    const/16 v19, 0x3d

    const/16 v20, 0x9

    aput-byte v19, v7, v20

    const/16 v19, 0xa

    aput-byte v17, v7, v19

    const/16 v21, 0x60

    const/16 v22, 0xb

    aput-byte v21, v7, v22

    const/16 v21, 0x4a

    const/16 v23, 0xc

    aput-byte v21, v7, v23

    const/16 v21, -0x4e

    const/16 v24, 0xd

    aput-byte v21, v7, v24

    const/16 v21, 0xe

    const/16 v25, -0x43

    aput-byte v25, v7, v21

    const/16 v21, 0x70

    aput-byte v21, v7, v2

    const/16 v21, -0x14

    aput-byte v21, v7, v0

    const/16 v21, 0x11

    aput-byte v24, v7, v21

    const/16 v21, 0x12

    const/16 v25, -0x59

    aput-byte v25, v7, v21

    const/16 v21, 0x13

    const/16 v25, -0x40

    aput-byte v25, v7, v21

    const/16 v21, 0x14

    const/16 v25, -0x67

    aput-byte v25, v7, v21

    const/16 v21, 0x15

    const/16 v25, 0x3b

    aput-byte v25, v7, v21

    const/16 v21, 0x16

    const/16 v25, 0x46

    aput-byte v25, v7, v21

    const/16 v21, 0x17

    const/16 v25, -0x4c

    aput-byte v25, v7, v21

    const/16 v21, 0x18

    const/16 v25, 0x63

    aput-byte v25, v7, v21

    const/16 v21, 0x19

    const/16 v25, -0x1c

    aput-byte v25, v7, v21

    const/16 v21, 0x1a

    const/16 v25, -0x3b

    aput-byte v25, v7, v21

    const/16 v21, -0x5b

    const/16 v14, 0x1b

    aput-byte v21, v7, v14

    const/16 v21, -0x5c

    const/16 v26, 0x1c

    aput-byte v21, v7, v26

    const/16 v21, 0x1d

    const/16 v27, 0x4a

    aput-byte v27, v7, v21

    const/16 v21, 0x1e

    const/16 v27, 0x35

    aput-byte v27, v7, v21

    const/16 v21, 0x1f

    aput-byte v8, v7, v21

    const/16 v21, 0x23

    aput-byte v21, v7, v18

    const/16 v18, 0x21

    const/16 v21, -0x74

    aput-byte v21, v7, v18

    const/16 v18, 0x22

    const/16 v21, -0x4

    aput-byte v21, v7, v18

    const/16 v18, 0x23

    const/16 v21, -0xe

    aput-byte v21, v7, v18

    const/16 v18, 0x24

    const/16 v21, -0x14

    aput-byte v21, v7, v18

    const/16 v18, 0x25

    const/16 v21, 0x4f

    aput-byte v21, v7, v18

    const/16 v18, 0x26

    const/16 v21, 0x5e

    aput-byte v21, v7, v18

    const/16 v18, 0x27

    const/16 v21, 0x53

    aput-byte v21, v7, v18

    const/16 v18, 0x28

    const/16 v21, -0xf

    aput-byte v21, v7, v18

    const/16 v18, 0x29

    aput-byte v26, v7, v18

    const/16 v18, 0x2a

    const/16 v21, 0x34

    aput-byte v21, v7, v18

    const/16 v18, 0x2b

    const/16 v21, -0x5d

    aput-byte v21, v7, v18

    const/16 v18, 0x2c

    const/16 v21, -0x77

    aput-byte v21, v7, v18

    const/16 v18, 0x2d

    const/16 v21, 0x4c

    aput-byte v21, v7, v18

    new-array v0, v3, [B

    const/16 v21, -0x7b

    aput-byte v21, v0, v9

    const/16 v21, 0x68

    aput-byte v21, v0, v10

    const/16 v21, 0x44

    aput-byte v21, v0, v11

    const/16 v21, 0x40

    aput-byte v21, v0, v12

    aput-byte v20, v0, v13

    const/16 v21, -0x23

    aput-byte v21, v0, v15

    const/16 v21, -0x2e

    aput-byte v21, v0, v16

    aput-byte v14, v0, v17

    invoke-static {v7, v0}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v5, v0}, Landroid/app/AlertDialog$Builder;->setTitle(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    move-result-object v0

    invoke-virtual {v0, v6}, Landroid/app/AlertDialog$Builder;->setView(Landroid/view/View;)Landroid/app/AlertDialog$Builder;

    move-result-object v0

    new-array v5, v14, [B

    const/16 v6, 0x6b

    aput-byte v6, v5, v9

    aput-byte v24, v5, v10

    const/16 v7, -0x5a

    aput-byte v7, v5, v11

    const/16 v7, 0x59

    aput-byte v7, v5, v12

    aput-byte v26, v5, v13

    aput-byte v8, v5, v15

    const/16 v7, 0x29

    aput-byte v7, v5, v16

    const/16 v7, 0x70

    aput-byte v7, v5, v17

    aput-byte v9, v5, v3

    aput-byte v6, v5, v20

    const/16 v7, -0x5e

    aput-byte v7, v5, v19

    aput-byte v9, v5, v22

    const/16 v7, 0x73

    aput-byte v7, v5, v23

    const/16 v7, -0x4e

    aput-byte v7, v5, v24

    const/16 v7, 0xe

    const/16 v8, 0x6e

    aput-byte v8, v5, v7

    const/16 v7, -0x67

    aput-byte v7, v5, v2

    const/16 v7, -0x31

    const/16 v8, 0x10

    aput-byte v7, v5, v8

    const/16 v7, 0x11

    const/16 v8, -0x51

    aput-byte v8, v5, v7

    const/16 v7, 0x12

    const/16 v8, 0x5e

    aput-byte v8, v5, v7

    const/16 v7, 0x13

    const/16 v8, -0x11

    aput-byte v8, v5, v7

    const/16 v7, 0x14

    const/16 v8, -0x3c

    aput-byte v8, v5, v7

    const/16 v7, 0x15

    const/16 v8, -0x40

    aput-byte v8, v5, v7

    const/16 v7, 0x16

    const/16 v8, 0x4f

    aput-byte v8, v5, v7

    const/16 v7, 0x17

    const/16 v8, 0x67

    aput-byte v8, v5, v7

    const/16 v7, 0x18

    aput-byte v6, v5, v7

    const/16 v6, 0x19

    const/16 v7, 0x2f

    aput-byte v7, v5, v6

    const/16 v6, 0x1a

    const/16 v7, -0x62

    aput-byte v7, v5, v6

    new-array v6, v3, [B

    const/16 v7, -0x74

    aput-byte v7, v6, v9

    const/16 v7, -0x71

    aput-byte v7, v6, v10

    const/16 v7, 0x1f

    aput-byte v7, v6, v11

    const/16 v7, -0x41

    aput-byte v7, v6, v12

    const/16 v7, -0x6c

    aput-byte v7, v6, v13

    const/16 v7, 0x26

    aput-byte v7, v6, v15

    const/16 v7, -0x3a

    aput-byte v7, v6, v16

    const/16 v7, -0x34

    aput-byte v7, v6, v17

    invoke-static {v5, v6}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v5

    new-instance v6, Lcom/github/catvod/spider/appysv2/b/B;

    invoke-direct {v6, v1, v10}, Lcom/github/catvod/spider/appysv2/b/B;-><init>(Ljava/lang/Object;I)V

    invoke-virtual {v0, v5, v6}, Landroid/app/AlertDialog$Builder;->setNeutralButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object v0

    const/high16 v5, 0x1040000

    const/4 v6, 0x0

    invoke-virtual {v0, v5, v6}, Landroid/app/AlertDialog$Builder;->setNegativeButton(ILandroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object v0

    const v5, 0x104000a

    new-instance v6, Lcom/github/catvod/spider/appysv2/b/O;

    invoke-direct {v6, v1, v4}, Lcom/github/catvod/spider/appysv2/b/O;-><init>(Lcom/github/catvod/spider/appysv2/b/U;Landroid/widget/EditText;)V

    invoke-virtual {v0, v5, v6}, Landroid/app/AlertDialog$Builder;->setPositiveButton(ILandroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object v0

    invoke-virtual {v0}, Landroid/app/AlertDialog$Builder;->show()Landroid/app/AlertDialog;

    move-result-object v0

    iput-object v0, v1, Lcom/github/catvod/spider/appysv2/b/U;->f:Landroid/app/AlertDialog;
    :try_end_220
    .catch Ljava/lang/Exception; {:try_start_8 .. :try_end_220} :catch_221

    goto :goto_249

    :catch_221
    move-exception v0

    invoke-virtual {v0}, Ljava/lang/Throwable;->printStackTrace()V

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    new-array v2, v2, [B

    fill-array-data v2, :array_24a

    new-array v3, v3, [B

    fill-array-data v3, :array_256

    invoke-static {v2, v3}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lcom/github/catvod/crawler/SpiderDebug;->log(Ljava/lang/String;)V

    :goto_249
    return-void

    :array_24a
    .array-data 1
        0x15t
        0x58t
        -0x5et
        0x33t
        -0x5ct
        -0x7ft
        0x2t
        0x1dt
        0x12t
        0x2t
        -0x13t
        0x21t
        -0x6bt
        -0x2bt
        0x52t
    .end array-data

    :array_256
    .array-data 1
        0x66t
        0x30t
        -0x33t
        0x44t
        -0x13t
        -0x11t
        0x72t
        0x68t
    .end array-data
.end method

.method public final o()V
    .registers 26

    move-object/from16 v1, p0

    const/16 v4, 0xb

    const-wide/16 v6, 0x12c

    const/16 v8, 0xd

    const/16 v9, 0x46

    const/16 v10, 0x9

    const/16 v11, 0x49

    const/16 v12, 0x29

    const/16 v13, 0xa

    const/4 v14, 0x6

    const/4 v15, 0x5

    const/16 v16, 0x4

    const/16 v17, 0x0

    const/16 v2, 0x8

    const/16 v19, 0x7

    const/4 v3, 0x2

    const/16 v20, 0x1

    const/4 v5, 0x3

    :try_start_20
    iget-object v0, v1, Lcom/github/catvod/spider/appysv2/b/U;->a:Ljava/lang/String;

    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    const/16 v22, 0x6e

    const/16 v23, 0x40

    if-eqz v0, :cond_59

    new-array v0, v5, [B

    aput-byte v12, v0, v17

    aput-byte v23, v0, v20

    aput-byte v8, v0, v3

    new-array v8, v2, [B

    aput-byte v19, v8, v17

    const/16 v24, 0x35

    aput-byte v24, v8, v20

    aput-byte v22, v8, v3

    const/16 v24, 0x69

    aput-byte v24, v8, v5

    const/16 v24, -0x23

    aput-byte v24, v8, v16

    const/16 v24, -0x4e

    aput-byte v24, v8, v15

    aput-byte v5, v8, v14

    const/16 v24, 0x6a

    aput-byte v24, v8, v19

    invoke-static {v0, v8}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lcom/github/catvod/spider/appysv2/p/C;->q(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    goto :goto_5b

    :cond_59
    iget-object v0, v1, Lcom/github/catvod/spider/appysv2/b/U;->a:Ljava/lang/String;

    :goto_5b
    iput-object v0, v1, Lcom/github/catvod/spider/appysv2/b/U;->a:Ljava/lang/String;

    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    const/16 v8, 0x7e

    if-nez v0, :cond_d6

    invoke-direct/range {p0 .. p0}, Lcom/github/catvod/spider/appysv2/b/U;->I()Z

    move-result v0
    :try_end_69
    .catch Ljava/lang/Exception; {:try_start_20 .. :try_end_69} :catch_136
    .catchall {:try_start_20 .. :try_end_69} :catchall_133

    if-eqz v0, :cond_78

    :goto_6b
    iget-object v0, v1, Lcom/github/catvod/spider/appysv2/b/U;->a:Ljava/lang/String;

    invoke-virtual {v0}, Ljava/lang/String;->isEmpty()Z

    move-result v0

    if-eqz v0, :cond_77

    invoke-static {v6, v7}, Landroid/os/SystemClock;->sleep(J)V

    goto :goto_6b

    :cond_77
    return-void

    :cond_78
    :try_start_78
    new-instance v0, Ljava/lang/Exception;

    const/16 v6, 0xe

    new-array v6, v6, [B

    aput-byte v22, v6, v17

    const/16 v7, 0x79

    aput-byte v7, v6, v20

    aput-byte v11, v6, v3

    const/16 v7, 0x1f

    aput-byte v7, v6, v5

    aput-byte v9, v6, v16

    aput-byte v12, v6, v15

    const/16 v7, 0x3e

    aput-byte v7, v6, v14

    const/16 v7, 0x4f

    aput-byte v7, v6, v19

    const/16 v7, 0x64

    aput-byte v7, v6, v2

    const/16 v7, 0x78

    aput-byte v7, v6, v10

    const/16 v7, 0x50

    aput-byte v7, v6, v13

    const/16 v7, 0x15

    aput-byte v7, v6, v4

    const/16 v7, 0x43

    const/16 v21, 0xc

    aput-byte v7, v6, v21

    const/16 v7, 0x25

    const/16 v22, 0xd

    aput-byte v7, v6, v22

    new-array v7, v2, [B

    aput-byte v19, v7, v17

    const/16 v22, 0x17

    aput-byte v22, v7, v20

    const/16 v22, 0x3f

    aput-byte v22, v7, v3

    aput-byte v8, v7, v5

    const/16 v8, 0x2a

    aput-byte v8, v7, v16

    aput-byte v23, v7, v15

    const/16 v8, 0x5a

    aput-byte v8, v7, v14

    const/16 v8, 0x6f

    aput-byte v8, v7, v19

    invoke-static {v6, v7}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v6

    invoke-direct {v0, v6}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_d6
    new-instance v0, Ljava/lang/Exception;

    const/16 v6, 0xc

    new-array v7, v6, [B

    const/16 v6, 0x28

    aput-byte v6, v7, v17

    const/16 v6, -0x27

    aput-byte v6, v7, v20

    const/16 v6, -0x41

    aput-byte v6, v7, v3

    const/16 v6, 0x44

    aput-byte v6, v7, v5

    const/16 v6, -0x5d

    aput-byte v6, v7, v16

    const/16 v6, -0x12

    aput-byte v6, v7, v15

    const/16 v6, -0x64

    aput-byte v6, v7, v14

    aput-byte v8, v7, v19

    const/16 v6, 0x22

    aput-byte v6, v7, v2

    const/16 v6, -0x21

    aput-byte v6, v7, v10

    const/16 v6, -0x5a

    aput-byte v6, v7, v13

    const/16 v6, 0x55

    aput-byte v6, v7, v4

    new-array v6, v2, [B

    const/16 v8, 0x4d

    aput-byte v8, v6, v17

    const/16 v8, -0x4c

    aput-byte v8, v6, v20

    const/16 v8, -0x31

    aput-byte v8, v6, v3

    const/16 v8, 0x30

    aput-byte v8, v6, v5

    const/16 v8, -0x26

    aput-byte v8, v6, v16

    const/16 v8, -0x32

    aput-byte v8, v6, v15

    const/4 v8, -0x1

    aput-byte v8, v6, v14

    const/16 v8, 0x11

    aput-byte v8, v6, v19

    invoke-static {v7, v6}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v6

    invoke-direct {v0, v6}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V

    throw v0
    :try_end_133
    .catch Ljava/lang/Exception; {:try_start_78 .. :try_end_133} :catch_136
    .catchall {:try_start_78 .. :try_end_133} :catchall_133

    :catchall_133
    move-exception v0

    goto/16 :goto_1d5

    :catch_136
    move-exception v0

    :try_start_137
    const-string v6, ""

    .line 1
    iput-object v6, v1, Lcom/github/catvod/spider/appysv2/b/U;->a:Ljava/lang/String;

    new-array v6, v5, [B

    fill-array-data v6, :array_1e6

    new-array v7, v2, [B

    fill-array-data v7, :array_1ec

    invoke-static {v6, v7}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v6

    iget-object v7, v1, Lcom/github/catvod/spider/appysv2/b/U;->a:Ljava/lang/String;

    invoke-static {v6, v7}, Lcom/github/catvod/spider/appysv2/p/C;->u(Ljava/lang/String;Ljava/lang/String;)V

    const-wide/16 v6, 0x190

    .line 2
    invoke-static {v6, v7}, Landroid/os/SystemClock;->sleep(J)V

    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    const/16 v7, 0xd

    new-array v7, v7, [B

    const/16 v8, -0x26

    aput-byte v8, v7, v17

    const/16 v8, -0x79

    aput-byte v8, v7, v20

    const/16 v8, -0x61

    aput-byte v8, v7, v3

    const/16 v18, -0x73

    aput-byte v18, v7, v5

    const/16 v18, -0x50

    aput-byte v18, v7, v16

    aput-byte v11, v7, v15

    const/16 v18, 0x26

    aput-byte v18, v7, v14

    aput-byte v9, v7, v19

    const/16 v9, -0x2e

    aput-byte v9, v7, v2

    const/16 v9, -0x7a

    aput-byte v9, v7, v10

    aput-byte v8, v7, v13

    const/16 v8, -0x2c

    aput-byte v8, v7, v4

    const/4 v4, -0x5

    const/16 v8, 0xc

    aput-byte v4, v7, v8

    new-array v2, v2, [B

    const/16 v4, -0x47

    aput-byte v4, v2, v17

    const/16 v4, -0x11

    aput-byte v4, v2, v20

    const/4 v4, -0x6

    aput-byte v4, v2, v3

    const/16 v4, -0x12

    aput-byte v4, v2, v5

    const/16 v4, -0x25

    aput-byte v4, v2, v16

    aput-byte v13, v2, v15

    aput-byte v11, v2, v14

    aput-byte v12, v2, v19

    invoke-static {v7, v2}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v6, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v6, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lcom/github/catvod/crawler/SpiderDebug;->log(Ljava/lang/String;)V

    invoke-direct/range {p0 .. p0}, Lcom/github/catvod/spider/appysv2/b/U;->S()V

    .line 3
    new-instance v0, Lcom/github/catvod/spider/appysv2/b/b;

    invoke-direct {v0, v1, v3}, Lcom/github/catvod/spider/appysv2/b/b;-><init>(Ljava/lang/Object;I)V

    invoke-static {v0}, Lcom/github/catvod/spider/Init;->run(Ljava/lang/Runnable;)V
    :try_end_1c6
    .catchall {:try_start_137 .. :try_end_1c6} :catchall_133

    .line 4
    :goto_1c6
    iget-object v0, v1, Lcom/github/catvod/spider/appysv2/b/U;->a:Ljava/lang/String;

    invoke-virtual {v0}, Ljava/lang/String;->isEmpty()Z

    move-result v0

    if-eqz v0, :cond_1d4

    const-wide/16 v2, 0x12c

    invoke-static {v2, v3}, Landroid/os/SystemClock;->sleep(J)V

    goto :goto_1c6

    :cond_1d4
    return-void

    :goto_1d5
    iget-object v2, v1, Lcom/github/catvod/spider/appysv2/b/U;->a:Ljava/lang/String;

    invoke-virtual {v2}, Ljava/lang/String;->isEmpty()Z

    move-result v2

    if-eqz v2, :cond_1e3

    const-wide/16 v2, 0x12c

    invoke-static {v2, v3}, Landroid/os/SystemClock;->sleep(J)V

    goto :goto_1d5

    :cond_1e3
    goto :goto_1e5

    :goto_1e4
    throw v0

    :goto_1e5
    goto :goto_1e4

    :array_1e6
    .array-data 1
        0x57t
        -0x5et
        0x34t
    .end array-data

    :array_1ec
    .array-data 1
        0x79t
        -0x29t
        0x57t
        0x53t
        -0x14t
        0x48t
        -0x4ct
        0x63t
    .end array-data
.end method

.method public final p()V
    .registers 4

    const-string v0, ""

    iput-object v0, p0, Lcom/github/catvod/spider/appysv2/b/U;->a:Ljava/lang/String;

    const/4 v0, 0x0

    iput-object v0, p0, Lcom/github/catvod/spider/appysv2/b/U;->b:Lorg/json/JSONObject;

    const/4 v0, 0x3

    new-array v0, v0, [B

    fill-array-data v0, :array_2e

    const/16 v1, 0x8

    new-array v2, v1, [B

    fill-array-data v2, :array_34

    invoke-static {v0, v2}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lcom/github/catvod/spider/appysv2/p/C;->c(Ljava/lang/String;)V

    const/4 v0, 0x5

    new-array v0, v0, [B

    fill-array-data v0, :array_3c

    new-array v1, v1, [B

    fill-array-data v1, :array_44

    invoke-static {v0, v1}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lcom/github/catvod/spider/appysv2/p/C;->c(Ljava/lang/String;)V

    return-void

    :array_2e
    .array-data 1
        -0x4t
        0x7at
        -0x40t
    .end array-data

    :array_34
    .array-data 1
        -0x2et
        0xft
        -0x5dt
        0x3bt
        0x1et
        -0x2at
        -0x24t
        -0x50t
    .end array-data

    :array_3c
    .array-data 1
        -0x1bt
        -0x6t
        0x5ft
        -0xat
        -0x22t
    .end array-data

    nop

    :array_44
    .array-data 1
        -0x35t
        -0x71t
        0x3ct
        -0x7et
        -0x58t
        0x48t
        -0x50t
        -0x4et
    .end array-data
.end method

.method public final w(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    .registers 31

    move-object/from16 v1, p0

    const-string v0, ""

    :try_start_4
    invoke-direct/range {p0 .. p0}, Lcom/github/catvod/spider/appysv2/b/U;->E()Ljava/lang/String;

    move-result-object v2

    invoke-virtual/range {p0 .. p1}, Lcom/github/catvod/spider/appysv2/b/U;->N(Ljava/lang/String;)Ljava/lang/String;

    sget-object v3, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;
    :try_end_d
    .catch Ljava/lang/Exception; {:try_start_4 .. :try_end_d} :catch_3df
    .catchall {:try_start_4 .. :try_end_d} :catchall_3cf

    move-object/from16 v4, p1

    move-object/from16 v5, p2

    move-object/from16 v6, p3

    :try_start_13
    invoke-direct {v1, v4, v5, v6, v3}, Lcom/github/catvod/spider/appysv2/b/U;->q(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)Ljava/lang/String;

    move-result-object v3
    :try_end_17
    .catch Ljava/lang/Exception; {:try_start_13 .. :try_end_17} :catch_3e3
    .catchall {:try_start_13 .. :try_end_17} :catchall_3cd

    :try_start_17
    invoke-static {v3}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v5
    :try_end_1b
    .catch Ljava/lang/Exception; {:try_start_17 .. :try_end_1b} :catch_3e4
    .catchall {:try_start_17 .. :try_end_1b} :catchall_3cb

    if-eqz v5, :cond_27

    invoke-static/range {p1 .. p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v2

    if-nez v2, :cond_26

    invoke-direct {v1, v3}, Lcom/github/catvod/spider/appysv2/b/U;->r(Ljava/lang/String;)V

    :cond_26
    return-object v0

    :cond_27
    :try_start_27
    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    const/16 v6, 0x59

    new-array v6, v6, [B

    const/16 v7, 0x24

    const/4 v8, 0x0

    aput-byte v7, v6, v8

    const/16 v7, -0x3c

    const/4 v9, 0x1

    aput-byte v7, v6, v9

    const/16 v10, 0x34

    const/4 v11, 0x2

    aput-byte v10, v6, v11

    const/16 v10, 0x7f

    const/4 v12, 0x3

    aput-byte v10, v6, v12

    const/16 v10, -0xb

    const/4 v13, 0x4

    aput-byte v10, v6, v13

    const/16 v10, -0x74

    const/4 v14, 0x5

    aput-byte v10, v6, v14

    const/16 v10, 0x55

    const/4 v15, 0x6

    aput-byte v10, v6, v15

    const/16 v16, -0xa

    const/16 v17, 0x7

    aput-byte v16, v6, v17

    const/16 v16, 0x3c

    const/16 v15, 0x8

    aput-byte v16, v6, v15

    const/16 v18, 0x9

    const/16 v19, -0x2d

    aput-byte v19, v6, v18

    const/16 v18, 0xa

    const/16 v20, 0x6d

    aput-byte v20, v6, v18

    const/16 v18, 0xb

    const/16 v20, 0x6e

    aput-byte v20, v6, v18

    const/16 v18, -0xa

    const/16 v14, 0xc

    aput-byte v18, v6, v14

    const/16 v18, 0xd

    const/16 v20, -0x21

    aput-byte v20, v6, v18

    const/16 v18, 0xe

    const/16 v21, 0x54

    aput-byte v21, v6, v18

    const/16 v18, -0x54

    const/16 v21, 0xf

    aput-byte v18, v6, v21

    const/16 v18, 0x10

    const/16 v22, 0x2f

    aput-byte v22, v6, v18

    const/16 v18, 0x11

    const/16 v22, -0x62

    aput-byte v22, v6, v18

    const/16 v18, 0x12

    const/16 v23, 0x23

    aput-byte v23, v6, v18

    const/16 v18, 0x61

    const/16 v24, 0x13

    aput-byte v18, v6, v24

    const/16 v18, 0x14

    const/16 v25, -0x57

    aput-byte v25, v6, v18

    const/16 v18, 0x15

    const/16 v25, -0x79

    aput-byte v25, v6, v18

    const/16 v18, 0x16

    aput-byte v10, v6, v18

    const/16 v18, 0x17

    const/16 v25, -0x46

    aput-byte v25, v6, v18

    const/16 v18, 0x18

    const/16 v25, 0x20

    aput-byte v25, v6, v18

    const/16 v18, 0x19

    aput-byte v20, v6, v18

    const/16 v18, 0x1a

    const/16 v25, 0x35

    aput-byte v25, v6, v18

    const/16 v18, 0x1b

    const/16 v25, 0x6b

    aput-byte v25, v6, v18

    const/16 v18, 0x1c

    const/16 v25, -0x1e

    aput-byte v25, v6, v18

    const/16 v18, 0x1d

    aput-byte v7, v6, v18

    const/16 v18, 0x1e

    aput-byte v24, v6, v18

    const/16 v18, 0x1f

    const/16 v25, -0x51

    aput-byte v25, v6, v18

    const/16 v18, 0x20

    const/16 v25, 0x29

    aput-byte v25, v6, v18

    const/16 v18, 0x21

    const/16 v25, -0x61

    aput-byte v25, v6, v18

    const/16 v18, 0x22

    const/16 v25, 0x26

    aput-byte v25, v6, v18

    const/16 v18, 0x66

    aput-byte v18, v6, v23

    const/16 v18, 0x24

    const/16 v25, -0x16

    aput-byte v25, v6, v18

    const/16 v18, 0x25

    aput-byte v19, v6, v18

    const/16 v25, 0x26

    aput-byte v10, v6, v25

    const/16 v25, 0x27

    const/16 v26, -0x43

    aput-byte v26, v6, v25

    const/16 v25, 0x28

    aput-byte v23, v6, v25

    const/16 v23, 0x29

    const/16 v25, -0x39

    aput-byte v25, v6, v23

    const/16 v23, 0x2a

    const/16 v25, 0x2e

    aput-byte v25, v6, v23

    const/16 v23, 0x2b

    const/16 v25, 0x63

    aput-byte v25, v6, v23

    const/16 v23, 0x2c

    const/16 v25, -0x17

    aput-byte v25, v6, v23

    const/16 v23, 0x2d

    const/16 v25, -0x29

    aput-byte v25, v6, v23

    const/16 v23, 0x2e

    const/16 v25, 0x1e

    aput-byte v25, v6, v23

    const/16 v23, 0x2f

    const/16 v25, -0x1a

    aput-byte v25, v6, v23

    const/16 v23, 0x30

    aput-byte v16, v6, v23

    const/16 v23, 0x31

    const/16 v25, -0x3e

    aput-byte v25, v6, v23

    const/16 v23, 0x32

    const/16 v25, 0x7d

    aput-byte v25, v6, v23

    const/16 v23, 0x33

    const/16 v25, 0x5a

    aput-byte v25, v6, v23

    const/16 v23, 0x34

    const/16 v25, -0x3b

    aput-byte v25, v6, v23

    const/16 v23, 0x35

    const/16 v25, -0xc

    aput-byte v25, v6, v23

    const/16 v23, 0x36

    aput-byte v15, v6, v23

    const/16 v23, 0x37

    const/16 v25, -0x4a

    aput-byte v25, v6, v23

    const/16 v23, 0x38

    const/16 v25, 0x3b

    aput-byte v25, v6, v23

    const/16 v23, 0x39

    const/16 v25, -0x3d

    aput-byte v25, v6, v23

    const/16 v23, 0x3a

    aput-byte v18, v6, v23

    const/16 v23, 0x3b

    const/16 v25, 0x7d

    aput-byte v25, v6, v23

    const/16 v23, -0x60

    aput-byte v23, v6, v16

    const/16 v23, 0x3d

    const/16 v25, -0x30

    aput-byte v25, v6, v23

    const/16 v23, 0x3e

    aput-byte v15, v6, v23

    const/16 v25, 0x3f

    const/16 v26, -0x1c

    aput-byte v26, v6, v25

    const/16 v25, 0x40

    aput-byte v16, v6, v25

    const/16 v16, 0x41

    aput-byte v19, v6, v16

    const/16 v16, 0x42

    const/16 v19, 0x66

    aput-byte v19, v6, v16

    const/16 v16, 0x43

    const/16 v19, 0x7c

    aput-byte v19, v6, v16

    const/16 v16, 0x44

    const/16 v19, -0x1

    aput-byte v19, v6, v16

    const/16 v16, 0x45

    const/16 v19, -0x3b

    aput-byte v19, v6, v16

    const/16 v16, 0x46

    const/16 v19, 0x47

    aput-byte v19, v6, v16

    const/16 v16, 0x47

    const/16 v19, -0x52

    aput-byte v19, v6, v16

    const/16 v16, 0x48

    aput-byte v18, v6, v16

    const/16 v16, 0x49

    const/16 v19, -0x22

    aput-byte v19, v6, v16

    const/16 v16, 0x4a

    const/16 v19, 0x73

    aput-byte v19, v6, v16

    const/16 v16, 0x4b

    const/16 v19, 0x3d

    aput-byte v19, v6, v16

    const/16 v16, 0x4c

    const/16 v19, -0x60

    aput-byte v19, v6, v16

    const/16 v16, 0x4d

    const/16 v19, -0x40

    aput-byte v19, v6, v16

    const/16 v16, 0x4e

    const/16 v19, 0x1f

    aput-byte v19, v6, v16

    const/16 v16, 0x4f

    const/16 v19, -0x1c

    aput-byte v19, v6, v16

    const/16 v16, 0x50

    const/16 v19, 0x7d

    aput-byte v19, v6, v16

    const/16 v16, 0x51

    aput-byte v22, v6, v16

    const/16 v16, 0x52

    const/16 v19, 0x78

    aput-byte v19, v6, v16

    const/16 v16, 0x53

    const/16 v19, 0x21

    aput-byte v19, v6, v16

    const/16 v16, 0x54

    const/16 v19, -0x4d

    aput-byte v19, v6, v16

    const/16 v16, -0x70

    aput-byte v16, v6, v10

    const/16 v10, 0x56

    aput-byte v21, v6, v10

    const/16 v10, 0x57

    const/16 v16, -0x53

    aput-byte v16, v6, v10

    const/16 v10, 0x58

    const/16 v16, 0x71

    aput-byte v16, v6, v10

    new-array v10, v15, [B

    const/16 v16, 0x4c

    aput-byte v16, v10, v8

    const/16 v16, -0x50

    aput-byte v16, v10, v9

    const/16 v16, 0x40

    aput-byte v16, v10, v11

    aput-byte v21, v10, v12

    const/16 v16, -0x7a

    aput-byte v16, v10, v13

    const/16 v16, -0x4a

    const/16 v19, 0x5

    aput-byte v16, v10, v19

    const/16 v16, 0x7a

    const/16 v19, 0x6

    aput-byte v16, v10, v19

    const/16 v16, -0x27

    aput-byte v16, v10, v17

    invoke-static {v6, v10}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    new-instance v5, Ljava/util/HashMap;

    invoke-direct {v5}, Ljava/util/HashMap;-><init>()V

    new-instance v6, Ljava/util/ArrayList;

    invoke-direct {v6}, Ljava/util/ArrayList;-><init>()V

    invoke-virtual {v6, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    new-array v10, v13, [B

    const/16 v16, -0x26

    aput-byte v16, v10, v8

    const/16 v16, 0x4c

    aput-byte v16, v10, v9

    const/16 v16, 0x35

    aput-byte v16, v10, v11

    const/16 v16, 0x64

    aput-byte v16, v10, v12

    new-array v7, v15, [B

    const/16 v19, -0x44

    aput-byte v19, v7, v8

    aput-byte v18, v7, v9

    const/16 v18, 0x51

    aput-byte v18, v7, v11

    const/16 v18, 0x17

    aput-byte v18, v7, v12

    const/16 v18, 0x6c

    aput-byte v18, v7, v13

    const/16 v18, 0x5

    aput-byte v23, v7, v18

    const/16 v18, -0x73

    const/16 v19, 0x6

    aput-byte v18, v7, v19

    const/16 v18, -0x5

    aput-byte v18, v7, v17

    invoke-static {v10, v7}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v5, v7, v6}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    new-instance v6, Lorg/json/JSONObject;

    invoke-direct {v1, v2, v5}, Lcom/github/catvod/spider/appysv2/b/U;->L(Ljava/lang/String;Ljava/util/Map;)Ljava/lang/String;

    move-result-object v2

    invoke-direct {v6, v2}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x6

    new-array v5, v2, [B

    aput-byte v20, v5, v8

    const/16 v2, -0x16

    aput-byte v2, v5, v9

    const/16 v2, -0x7d

    aput-byte v2, v5, v11

    const/16 v2, 0x6a

    aput-byte v2, v5, v12

    const/16 v2, -0x19

    aput-byte v2, v5, v13

    const/4 v2, 0x5

    aput-byte v24, v5, v2

    new-array v2, v15, [B

    const/16 v7, -0x54

    aput-byte v7, v2, v8

    aput-byte v22, v2, v9

    const/16 v7, -0x1e

    aput-byte v7, v2, v11

    const/16 v7, 0x1e

    aput-byte v7, v2, v12

    const/16 v7, -0x6e

    aput-byte v7, v2, v13

    const/16 v7, 0x60

    const/4 v10, 0x5

    aput-byte v7, v2, v10

    const/4 v7, 0x6

    aput-byte v23, v2, v7

    const/16 v7, 0x36

    aput-byte v7, v2, v17

    invoke-static {v5, v2}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v6, v2}, Lorg/json/JSONObject;->getInt(Ljava/lang/String;)I

    move-result v2

    const/16 v5, 0xc8

    if-ne v2, v5, :cond_3c1

    new-array v2, v13, [B

    const/16 v5, 0x30

    aput-byte v5, v2, v8

    const/16 v5, 0x6c

    aput-byte v5, v2, v9

    const/16 v5, -0x66

    aput-byte v5, v2, v11

    const/16 v5, -0x6a

    aput-byte v5, v2, v12

    new-array v5, v15, [B

    const/16 v7, 0x53

    aput-byte v7, v5, v8

    aput-byte v12, v5, v9

    const/4 v7, -0x2

    aput-byte v7, v5, v11

    const/16 v7, -0xd

    aput-byte v7, v5, v12

    const/16 v7, 0x79

    aput-byte v7, v5, v13

    const/16 v7, 0x72

    const/4 v10, 0x5

    aput-byte v7, v5, v10

    const/16 v7, 0x71

    const/4 v10, 0x6

    aput-byte v7, v5, v10

    aput-byte v10, v5, v17

    invoke-static {v2, v5}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v6, v2}, Lorg/json/JSONObject;->getInt(Ljava/lang/String;)I

    move-result v2

    if-eqz v2, :cond_31d

    goto/16 :goto_3c1

    :cond_31d
    new-array v2, v13, [B

    const/16 v5, 0x66

    aput-byte v5, v2, v8

    const/16 v5, 0x7c

    aput-byte v5, v2, v9

    const/16 v5, -0x64

    aput-byte v5, v2, v11

    const/16 v5, 0x5f

    aput-byte v5, v2, v12

    new-array v5, v15, [B

    aput-byte v11, v5, v8

    const/16 v7, 0x1d

    aput-byte v7, v5, v9

    const/16 v7, -0x18

    aput-byte v7, v5, v11

    aput-byte v23, v5, v12

    const/16 v7, -0x39

    aput-byte v7, v5, v13

    const/16 v7, -0x44

    const/4 v10, 0x5

    aput-byte v7, v5, v10

    const/4 v7, 0x6

    aput-byte v21, v5, v7

    const/16 v7, 0x69

    aput-byte v7, v5, v17

    invoke-static {v2, v5}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v6, v2}, Lorg/json/JSONObject;->optJSONArray(Ljava/lang/String;)Lorg/json/JSONArray;

    move-result-object v2

    invoke-virtual {v2, v8}, Lorg/json/JSONArray;->optJSONObject(I)Lorg/json/JSONObject;

    move-result-object v2

    new-array v5, v14, [B

    const/16 v6, -0x7e

    aput-byte v6, v5, v8

    aput-byte v14, v5, v9

    const/4 v6, 0x5

    aput-byte v6, v5, v11

    const/16 v7, 0x5c

    aput-byte v7, v5, v12

    const/16 v7, 0x51

    aput-byte v7, v5, v13

    const/16 v7, -0x3c

    aput-byte v7, v5, v6

    const/16 v6, 0x65

    const/4 v7, 0x6

    aput-byte v6, v5, v7

    const/16 v6, -0x74

    aput-byte v6, v5, v17

    const/16 v6, -0x47

    aput-byte v6, v5, v15

    const/16 v6, 0x9

    const/16 v7, 0x16

    aput-byte v7, v5, v6

    const/16 v6, 0xa

    aput-byte v8, v5, v6

    const/16 v6, 0xb

    const/16 v7, 0x5e

    aput-byte v7, v5, v6

    new-array v6, v15, [B

    const/16 v7, -0x1a

    aput-byte v7, v6, v8

    const/16 v7, 0x63

    aput-byte v7, v6, v9

    const/16 v7, 0x72

    aput-byte v7, v6, v11

    const/16 v7, 0x32

    aput-byte v7, v6, v12

    const/16 v7, 0x3d

    aput-byte v7, v6, v13

    const/16 v7, -0x55

    const/4 v8, 0x5

    aput-byte v7, v6, v8

    const/4 v7, 0x6

    aput-byte v13, v6, v7

    const/16 v7, -0x18

    aput-byte v7, v6, v17

    invoke-static {v5, v6}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v2, v5}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0
    :try_end_3b7
    .catch Ljava/lang/Exception; {:try_start_27 .. :try_end_3b7} :catch_3e4
    .catchall {:try_start_27 .. :try_end_3b7} :catchall_3cb

    invoke-static/range {p1 .. p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v2

    if-nez v2, :cond_3c0

    invoke-direct {v1, v3}, Lcom/github/catvod/spider/appysv2/b/U;->r(Ljava/lang/String;)V

    :cond_3c0
    return-object v0

    :cond_3c1
    :goto_3c1
    invoke-static/range {p1 .. p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v2

    if-nez v2, :cond_3ca

    invoke-direct {v1, v3}, Lcom/github/catvod/spider/appysv2/b/U;->r(Ljava/lang/String;)V

    :cond_3ca
    return-object v0

    :catchall_3cb
    move-exception v0

    goto :goto_3d5

    :catchall_3cd
    move-exception v0

    goto :goto_3d4

    :catchall_3cf
    move-exception v0

    move-object/from16 v4, p1

    move-object/from16 v5, p2

    :goto_3d4
    move-object v3, v5

    :goto_3d5
    invoke-static/range {p1 .. p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v2

    if-nez v2, :cond_3de

    invoke-direct {v1, v3}, Lcom/github/catvod/spider/appysv2/b/U;->r(Ljava/lang/String;)V

    :cond_3de
    throw v0

    :catch_3df
    move-object/from16 v4, p1

    move-object/from16 v5, p2

    :catch_3e3
    move-object v3, v5

    :catch_3e4
    invoke-static/range {p1 .. p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v2

    if-nez v2, :cond_3ed

    invoke-direct {v1, v3}, Lcom/github/catvod/spider/appysv2/b/U;->r(Ljava/lang/String;)V

    :cond_3ed
    return-object v0
.end method

.method public final x(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/util/List;
    .registers 43
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ")",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    move-object/from16 v0, p0

    :try_start_2
    invoke-virtual/range {p0 .. p1}, Lcom/github/catvod/spider/appysv2/b/U;->N(Ljava/lang/String;)Ljava/lang/String;

    sget-object v1, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    move-object/from16 v2, p1

    move-object/from16 v3, p2

    move-object/from16 v4, p3

    invoke-direct {v0, v2, v3, v4, v1}, Lcom/github/catvod/spider/appysv2/b/U;->q(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v2

    if-eqz v2, :cond_1d

    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    return-object v1

    :cond_1d
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v3

    invoke-virtual {v2, v3, v4}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const-string v3, ""

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    iget-object v3, v0, Lcom/github/catvod/spider/appysv2/b/U;->b:Lorg/json/JSONObject;

    const/16 v4, 0x9

    new-array v5, v4, [B

    const/16 v6, 0x1a

    const/4 v7, 0x0

    aput-byte v6, v5, v7

    const/16 v6, -0x9

    const/4 v8, 0x1

    aput-byte v6, v5, v8

    const/16 v6, 0x59

    const/4 v9, 0x2

    aput-byte v6, v5, v9

    const/16 v6, -0x7b

    const/4 v10, 0x3

    aput-byte v6, v5, v10

    const/16 v6, -0x3b

    const/4 v11, 0x4

    aput-byte v6, v5, v11

    const/16 v6, 0x65

    const/4 v12, 0x5

    aput-byte v6, v5, v12

    const/16 v6, -0x63

    const/4 v13, 0x6

    aput-byte v6, v5, v13

    const/16 v6, 0x37

    const/4 v14, 0x7

    aput-byte v6, v5, v14

    const/16 v6, 0x1a

    const/16 v15, 0x8

    aput-byte v6, v5, v15

    new-array v6, v15, [B

    const/16 v16, 0x7e

    aput-byte v16, v6, v7

    const/16 v16, -0x6e

    aput-byte v16, v6, v8

    const/16 v16, 0x2f

    aput-byte v16, v6, v9

    const/16 v16, -0x14

    aput-byte v16, v6, v10

    const/16 v16, -0x5a

    aput-byte v16, v6, v11

    aput-byte v7, v6, v12

    const/16 v16, -0x3e

    aput-byte v16, v6, v13

    const/16 v16, 0x5e

    aput-byte v16, v6, v14

    invoke-static {v5, v6}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v3, v5}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    const/16 v5, 0x20

    new-array v5, v5, [B

    const/16 v6, -0x54

    aput-byte v6, v5, v7

    const/16 v6, -0x4b

    aput-byte v6, v5, v8

    const/16 v6, 0x65

    aput-byte v6, v5, v9

    const/16 v6, -0x50

    aput-byte v6, v5, v10

    const/16 v6, 0x17

    aput-byte v6, v5, v11

    const/16 v16, -0x73

    aput-byte v16, v5, v12

    const/16 v16, 0x41

    aput-byte v16, v5, v13

    const/16 v16, -0x5c

    aput-byte v16, v5, v14

    const/16 v16, -0x55

    aput-byte v16, v5, v15

    const/16 v16, -0x1d

    aput-byte v16, v5, v4

    const/16 v16, 0x64

    const/16 v4, 0xa

    aput-byte v16, v5, v4

    const/16 v16, -0x1f

    const/16 v4, 0xb

    aput-byte v16, v5, v4

    const/16 v16, 0x1b

    const/16 v4, 0xc

    aput-byte v16, v5, v4

    const/16 v17, -0x80

    const/16 v18, 0xd

    aput-byte v17, v5, v18

    const/16 v17, 0x43

    const/16 v4, 0xe

    aput-byte v17, v5, v4

    const/16 v17, -0xe

    const/16 v4, 0xf

    aput-byte v17, v5, v4

    const/16 v17, 0x10

    const/16 v21, -0x5

    aput-byte v21, v5, v17

    const/16 v17, -0x1d

    const/16 v21, 0x11

    aput-byte v17, v5, v21

    const/16 v17, 0x36

    const/16 v22, 0x12

    aput-byte v17, v5, v22

    const/16 v17, 0x13

    const/16 v23, -0x1e

    aput-byte v23, v5, v17

    const/16 v17, 0x1f

    const/16 v23, 0x14

    aput-byte v17, v5, v23

    const/16 v17, -0x29

    const/16 v24, 0x15

    aput-byte v17, v5, v24

    const/16 v17, 0x43

    const/16 v25, 0x16

    aput-byte v17, v5, v25

    const/16 v17, -0x5d

    aput-byte v17, v5, v6

    const/16 v17, -0x51

    const/16 v6, 0x18

    aput-byte v17, v5, v6

    const/16 v17, 0x19

    const/16 v27, -0x1f

    aput-byte v27, v5, v17

    const/16 v17, 0x1a

    const/16 v27, 0x33

    aput-byte v27, v5, v17

    const/16 v17, -0x19

    aput-byte v17, v5, v16

    const/16 v17, 0x1c

    aput-byte v25, v5, v17

    const/16 v27, -0x2c

    const/16 v28, 0x1d

    aput-byte v27, v5, v28

    const/16 v27, 0x1e

    aput-byte v22, v5, v27

    const/16 v27, 0x1f

    const/16 v29, -0x9

    aput-byte v29, v5, v27

    new-array v6, v15, [B

    const/16 v29, -0x67

    aput-byte v29, v6, v7

    const/16 v29, -0x2c

    aput-byte v29, v6, v8

    aput-byte v13, v6, v9

    const/16 v29, -0x2a

    aput-byte v29, v6, v10

    const/16 v29, 0x2f

    aput-byte v29, v6, v11

    const/16 v29, -0x4b

    aput-byte v29, v6, v12

    const/16 v29, 0x73

    aput-byte v29, v6, v13

    const/16 v29, -0x40

    aput-byte v29, v6, v14

    invoke-static {v5, v6}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v5

    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v6, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v6, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    invoke-static {v6}, Lcom/github/catvod/spider/appysv2/p/C;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    iget-object v4, v0, Lcom/github/catvod/spider/appysv2/b/U;->b:Lorg/json/JSONObject;

    const/16 v15, 0xc

    new-array v14, v15, [B

    const/16 v15, -0x4b

    aput-byte v15, v14, v7

    const/16 v15, -0x43

    aput-byte v15, v14, v8

    const/16 v15, -0x65

    aput-byte v15, v14, v9

    const/16 v15, 0x31

    aput-byte v15, v14, v10

    const/16 v15, 0x2b

    aput-byte v15, v14, v11

    const/16 v15, 0x38

    aput-byte v15, v14, v12

    const/16 v15, 0x2f

    aput-byte v15, v14, v13

    const/16 v15, -0x49

    const/16 v31, 0x7

    aput-byte v15, v14, v31

    const/16 v15, -0x45

    const/16 v13, 0x8

    aput-byte v15, v14, v13

    const/16 v15, -0x4b

    const/16 v30, 0x9

    aput-byte v15, v14, v30

    const/16 v15, -0x63

    const/16 v30, 0xa

    aput-byte v15, v14, v30

    const/16 v15, 0x3a

    const/16 v30, 0xb

    aput-byte v15, v14, v30

    new-array v15, v13, [B

    const/16 v13, -0x2c

    aput-byte v13, v15, v7

    const/16 v13, -0x22

    aput-byte v13, v15, v8

    const/4 v13, -0x8

    aput-byte v13, v15, v9

    const/16 v13, 0x54

    aput-byte v13, v15, v10

    const/16 v13, 0x58

    aput-byte v13, v15, v11

    const/16 v13, 0x4b

    aput-byte v13, v15, v12

    const/16 v13, 0x70

    const/16 v32, 0x6

    aput-byte v13, v15, v32

    const/16 v13, -0x3d

    const/16 v31, 0x7

    aput-byte v13, v15, v31

    invoke-static {v14, v15}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v13

    invoke-virtual {v4, v13}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    const/16 v13, 0x2d

    new-array v13, v13, [B

    aput-byte v28, v13, v7

    const/16 v14, -0x3c

    aput-byte v14, v13, v8

    const/16 v14, -0x43

    aput-byte v14, v13, v9

    const/16 v14, 0x37

    aput-byte v14, v13, v10

    const/16 v14, -0x22

    aput-byte v14, v13, v11

    const/16 v14, -0x7d

    aput-byte v14, v13, v12

    const/16 v14, 0xf

    const/4 v15, 0x6

    aput-byte v14, v13, v15

    const/4 v14, 0x7

    aput-byte v21, v13, v14

    const/16 v14, 0x3f

    const/16 v15, 0x8

    aput-byte v14, v13, v15

    const/16 v14, -0x59

    const/16 v15, 0x9

    aput-byte v14, v13, v15

    const/16 v14, -0x34

    const/16 v15, 0xa

    aput-byte v14, v13, v15

    const/16 v14, 0x62

    const/16 v15, 0xb

    aput-byte v14, v13, v15

    const/16 v14, -0x29

    const/16 v15, 0xc

    aput-byte v14, v13, v15

    const/16 v14, -0x77

    aput-byte v14, v13, v18

    const/16 v14, 0x55

    const/16 v15, 0xe

    aput-byte v14, v13, v15

    const/16 v14, 0xf

    aput-byte v15, v13, v14

    const/16 v14, 0x10

    const/16 v15, 0x28

    aput-byte v15, v13, v14

    const/16 v14, -0x9

    aput-byte v14, v13, v21

    const/16 v14, -0x63

    aput-byte v14, v13, v22

    const/16 v14, 0x13

    const/16 v33, 0x75

    aput-byte v33, v13, v14

    const/16 v14, -0x3a

    aput-byte v14, v13, v23

    const/16 v14, -0x6b

    aput-byte v14, v13, v24

    const/16 v14, 0x52

    aput-byte v14, v13, v25

    const/16 v14, 0x4f

    const/16 v26, 0x17

    aput-byte v14, v13, v26

    const/16 v14, 0x36

    const/16 v27, 0x18

    aput-byte v14, v13, v27

    const/16 v14, 0x19

    const/16 v33, -0x4f

    aput-byte v33, v13, v14

    const/16 v14, 0x1a

    const/16 v33, -0x73

    aput-byte v33, v13, v14

    const/16 v14, 0x21

    aput-byte v14, v13, v16

    const/16 v14, -0x77

    aput-byte v14, v13, v17

    const/16 v14, -0x2c

    aput-byte v14, v13, v28

    const/16 v14, 0x1e

    const/16 v33, 0x13

    aput-byte v33, v13, v14

    const/16 v14, 0x1f

    const/16 v33, 0x45

    aput-byte v33, v13, v14

    const/16 v14, 0x20

    const/16 v33, 0x3e

    aput-byte v33, v13, v14

    const/16 v14, 0x21

    const/16 v33, -0x4a

    aput-byte v33, v13, v14

    const/16 v14, 0x22

    const/16 v33, -0x70

    aput-byte v33, v13, v14

    const/16 v14, 0x23

    const/16 v34, 0x72

    aput-byte v34, v13, v14

    const/16 v14, 0x24

    const/16 v34, -0x37

    aput-byte v34, v13, v14

    const/16 v14, 0x25

    const/16 v34, -0x64

    aput-byte v34, v13, v14

    const/16 v14, 0x26

    aput-byte v10, v13, v14

    const/16 v34, 0x27

    const/16 v35, 0x44

    aput-byte v35, v13, v34

    const/16 v34, 0x31

    aput-byte v34, v13, v15

    const/16 v34, 0x29

    const/16 v35, -0x16

    aput-byte v35, v13, v34

    const/16 v34, 0x2a

    const/16 v35, -0x80

    aput-byte v35, v13, v34

    const/16 v34, 0x2b

    const/16 v35, 0x25

    aput-byte v35, v13, v34

    const/16 v34, -0x6b

    const/16 v35, 0x2c

    aput-byte v34, v13, v35

    const/16 v15, 0x8

    new-array v14, v15, [B

    const/16 v15, 0x5a

    aput-byte v15, v14, v7

    const/16 v15, -0x7f

    aput-byte v15, v14, v8

    const/16 v15, -0x17

    aput-byte v15, v14, v9

    aput-byte v21, v14, v10

    const/16 v15, -0xf

    aput-byte v15, v14, v11

    const/16 v15, -0x1b

    aput-byte v15, v14, v12

    const/16 v15, 0x66

    const/16 v32, 0x6

    aput-byte v15, v14, v32

    const/16 v15, 0x7d

    const/16 v31, 0x7

    aput-byte v15, v14, v31

    invoke-static {v13, v14}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v13

    new-array v14, v8, [Ljava/lang/Object;

    aput-object v2, v14, v7

    invoke-static {v13, v14}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v13

    invoke-static {v13}, Lcom/github/catvod/spider/appysv2/p/C;->b(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v13

    new-instance v14, Ljava/lang/StringBuilder;

    invoke-direct {v14}, Ljava/lang/StringBuilder;-><init>()V

    const/16 v15, 0x29

    new-array v15, v15, [B

    const/16 v37, -0x3b

    aput-byte v37, v15, v7

    const/16 v37, 0x52

    aput-byte v37, v15, v8

    const/16 v37, 0x49

    aput-byte v37, v15, v9

    const/16 v37, -0x61

    aput-byte v37, v15, v10

    const/16 v37, -0xc

    aput-byte v37, v15, v11

    const/16 v37, 0x2f

    aput-byte v37, v15, v12

    const/16 v37, 0x6a

    const/16 v32, 0x6

    aput-byte v37, v15, v32

    const/16 v37, 0x46

    const/16 v31, 0x7

    aput-byte v37, v15, v31

    const/16 v37, -0x3e

    const/16 v30, 0x8

    aput-byte v37, v15, v30

    const/16 v37, 0x56

    const/16 v38, 0x9

    aput-byte v37, v15, v38

    const/16 v37, 0x58

    const/16 v38, 0xa

    aput-byte v37, v15, v38

    const/16 v37, -0x7f

    const/16 v38, 0xb

    aput-byte v37, v15, v38

    const/16 v37, -0x56

    const/16 v19, 0xc

    aput-byte v37, v15, v19

    const/16 v37, 0x74

    aput-byte v37, v15, v18

    const/16 v37, 0x35

    const/16 v20, 0xe

    aput-byte v37, v15, v20

    const/16 v29, 0xf

    aput-byte v7, v15, v29

    const/16 v37, 0x10

    const/16 v38, -0x80

    aput-byte v38, v15, v37

    const/16 v37, 0x42

    aput-byte v37, v15, v21

    const/16 v37, 0x4f

    aput-byte v37, v15, v22

    const/16 v37, 0x13

    const/16 v38, -0x7a

    aput-byte v38, v15, v37

    const/16 v37, -0xf

    aput-byte v37, v15, v23

    const/16 v37, 0x70

    aput-byte v37, v15, v24

    const/16 v37, 0x6b

    aput-byte v37, v15, v25

    const/16 v26, 0x17

    aput-byte v17, v15, v26

    const/16 v37, -0x32

    const/16 v27, 0x18

    aput-byte v37, v15, v27

    const/16 v37, 0x19

    const/16 v30, 0x8

    aput-byte v30, v15, v37

    const/16 v37, 0x1a

    const/16 v38, 0x5e

    aput-byte v38, v15, v37

    const/16 v37, -0x7f

    aput-byte v37, v15, v16

    const/16 v37, -0x58

    aput-byte v37, v15, v17

    const/16 v37, 0x73

    aput-byte v37, v15, v28

    const/16 v37, 0x1e

    aput-byte v35, v15, v37

    const/16 v37, 0x1f

    aput-byte v12, v15, v37

    const/16 v37, 0x20

    const/16 v38, -0x38

    aput-byte v38, v15, v37

    const/16 v37, 0x21

    const/16 v38, 0x19

    aput-byte v38, v15, v37

    const/16 v37, 0x22

    const/16 v38, 0x4f

    aput-byte v38, v15, v37

    const/16 v37, 0x23

    const/16 v38, -0x76

    aput-byte v38, v15, v37

    const/16 v37, 0x24

    const/16 v38, -0xa

    aput-byte v38, v15, v37

    const/16 v37, 0x25

    const/16 v38, 0x4a

    aput-byte v38, v15, v37

    const/16 v36, 0x26

    aput-byte v35, v15, v36

    const/16 v37, 0x27

    aput-byte v18, v15, v37

    const/16 v34, 0x28

    aput-byte v33, v15, v34

    const/16 v12, 0x8

    new-array v11, v12, [B

    const/16 v12, -0x53

    aput-byte v12, v11, v7

    const/16 v12, 0x26

    aput-byte v12, v11, v8

    const/16 v12, 0x3d

    aput-byte v12, v11, v9

    const/16 v12, -0x11

    aput-byte v12, v11, v10

    const/16 v12, -0x79

    const/16 v38, 0x4

    aput-byte v12, v11, v38

    const/4 v12, 0x5

    aput-byte v24, v11, v12

    const/16 v12, 0x45

    const/16 v32, 0x6

    aput-byte v12, v11, v32

    const/16 v12, 0x69

    const/16 v31, 0x7

    aput-byte v12, v11, v31

    invoke-static {v15, v11}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v11

    invoke-virtual {v14, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v14, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v6, 0xe

    new-array v11, v6, [B

    aput-byte v28, v11, v7

    const/16 v6, -0x34

    aput-byte v6, v11, v8

    const/16 v6, 0xc

    aput-byte v6, v11, v9

    const/16 v6, -0x7f

    aput-byte v6, v11, v10

    const/16 v6, 0x63

    const/4 v12, 0x4

    aput-byte v6, v11, v12

    const/16 v6, -0x59

    const/4 v12, 0x5

    aput-byte v6, v11, v12

    const/16 v6, -0x33

    const/4 v12, 0x6

    aput-byte v6, v11, v12

    const/16 v6, 0x5f

    const/4 v12, 0x7

    aput-byte v6, v11, v12

    const/16 v6, 0x4f

    const/16 v12, 0x8

    aput-byte v6, v11, v12

    const/16 v6, -0x3e

    const/16 v12, 0x9

    aput-byte v6, v11, v12

    const/16 v6, 0xa

    const/4 v12, 0x4

    aput-byte v12, v11, v6

    const/16 v6, -0x79

    const/16 v12, 0xb

    aput-byte v6, v11, v12

    const/16 v6, 0x68

    const/16 v12, 0xc

    aput-byte v6, v11, v12

    const/16 v6, -0x17

    aput-byte v6, v11, v18

    const/16 v6, 0x8

    new-array v12, v6, [B

    const/16 v6, 0x3b

    aput-byte v6, v12, v7

    const/16 v6, -0x53

    aput-byte v6, v12, v8

    const/16 v6, 0x6f

    aput-byte v6, v12, v9

    const/16 v6, -0x1e

    aput-byte v6, v12, v10

    const/4 v6, 0x4

    const/4 v15, 0x6

    aput-byte v15, v12, v6

    const/16 v6, -0x2c

    const/16 v32, 0x5

    aput-byte v6, v12, v32

    const/16 v6, -0x42

    aput-byte v6, v12, v15

    const/4 v6, 0x7

    aput-byte v7, v12, v6

    invoke-static {v11, v12}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v14, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v14, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v4, 0x19

    new-array v4, v4, [B

    const/16 v6, -0x80

    aput-byte v6, v4, v7

    const/16 v6, -0x47

    aput-byte v6, v4, v8

    const/16 v6, 0x58

    aput-byte v6, v4, v9

    const/16 v6, -0x66

    aput-byte v6, v4, v10

    const/16 v6, 0x5b

    const/4 v11, 0x4

    aput-byte v6, v4, v11

    const/16 v6, 0x26

    const/4 v11, 0x5

    aput-byte v6, v4, v11

    const/16 v6, 0x54

    const/4 v11, 0x6

    aput-byte v6, v4, v11

    const/16 v6, -0x2c

    const/4 v12, 0x7

    aput-byte v6, v4, v12

    const/16 v6, -0x65

    const/16 v12, 0x8

    aput-byte v6, v4, v12

    const/16 v6, -0x17

    const/16 v12, 0x9

    aput-byte v6, v4, v12

    const/16 v6, 0xa

    aput-byte v11, v4, v6

    const/16 v6, -0x24

    const/16 v11, 0xb

    aput-byte v6, v4, v11

    const/16 v6, 0x2a

    const/16 v11, 0xc

    aput-byte v6, v4, v11

    const/16 v6, 0x68

    aput-byte v6, v4, v18

    const/16 v6, 0x17

    const/16 v11, 0xe

    aput-byte v6, v4, v11

    const/16 v6, -0x3e

    const/16 v11, 0xf

    aput-byte v6, v4, v11

    const/16 v6, 0x10

    const/16 v11, -0x3d

    aput-byte v11, v4, v6

    const/16 v6, -0x52

    aput-byte v6, v4, v21

    const/16 v6, 0x41

    aput-byte v6, v4, v22

    const/16 v6, 0x13

    const/16 v11, -0x77

    aput-byte v11, v4, v6

    const/16 v6, 0x61

    aput-byte v6, v4, v23

    const/16 v6, 0xf

    aput-byte v6, v4, v24

    const/16 v6, 0x58

    aput-byte v6, v4, v25

    const/16 v6, -0x3e

    const/16 v11, 0x17

    aput-byte v6, v4, v11

    const/16 v6, -0x65

    const/16 v11, 0x18

    aput-byte v6, v4, v11

    const/16 v6, 0x8

    new-array v11, v6, [B

    const/16 v6, -0x5a

    aput-byte v6, v11, v7

    const/16 v6, -0x28

    aput-byte v6, v11, v8

    const/16 v6, 0x28

    aput-byte v6, v11, v9

    const/16 v6, -0x16

    aput-byte v6, v11, v10

    const/4 v6, 0x4

    aput-byte v6, v11, v6

    const/16 v6, 0x50

    const/4 v12, 0x5

    aput-byte v6, v11, v12

    const/16 v6, 0x31

    const/4 v12, 0x6

    aput-byte v6, v11, v12

    const/16 v6, -0x5a

    const/4 v12, 0x7

    aput-byte v6, v11, v12

    invoke-static {v4, v11}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v14, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v14, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v3, 0xe0

    new-array v3, v3, [B

    const/16 v4, -0x2d

    aput-byte v4, v3, v7

    const/16 v4, -0x25

    aput-byte v4, v3, v8

    const/16 v4, 0x24

    aput-byte v4, v3, v9

    const/16 v4, 0x6e

    aput-byte v4, v3, v10

    const/16 v4, -0x25

    const/4 v6, 0x4

    aput-byte v4, v3, v6

    const/16 v4, 0xa

    const/4 v6, 0x5

    aput-byte v4, v3, v6

    const/4 v4, 0x6

    aput-byte v6, v3, v4

    const/16 v4, -0x46

    const/4 v6, 0x7

    aput-byte v4, v3, v6

    const/16 v4, -0x69

    const/16 v6, 0x8

    aput-byte v4, v3, v6

    const/16 v4, -0x33

    const/16 v6, 0x9

    aput-byte v4, v3, v6

    const/16 v4, 0x20

    const/16 v6, 0xa

    aput-byte v4, v3, v6

    const/16 v4, 0x76

    const/16 v6, 0xb

    aput-byte v4, v3, v6

    const/16 v4, -0x2a

    const/16 v6, 0xc

    aput-byte v4, v3, v6

    const/16 v4, 0x54

    aput-byte v4, v3, v18

    const/16 v4, 0xe

    aput-byte v25, v3, v4

    const/16 v4, -0x74

    const/16 v6, 0xf

    aput-byte v4, v3, v6

    const/16 v4, 0x10

    const/16 v6, -0x7d

    aput-byte v6, v3, v4

    const/16 v4, -0x30

    aput-byte v4, v3, v21

    const/16 v4, 0x67

    aput-byte v4, v3, v22

    const/16 v4, 0x13

    const/16 v6, 0x68

    aput-byte v6, v3, v4

    const/16 v4, -0x22

    aput-byte v4, v3, v23

    const/16 v4, 0x8

    aput-byte v4, v3, v24

    aput-byte v23, v3, v25

    const/16 v4, -0x7d

    const/16 v6, 0x17

    aput-byte v4, v3, v6

    const/16 v4, -0x66

    const/16 v6, 0x18

    aput-byte v4, v3, v6

    const/16 v4, 0x19

    const/16 v6, -0x33

    aput-byte v6, v3, v4

    const/16 v4, 0x1a

    aput-byte v35, v3, v4

    const/16 v4, 0x25

    aput-byte v4, v3, v16

    const/16 v4, -0x3a

    aput-byte v4, v3, v17

    const/16 v4, 0x1f

    aput-byte v4, v3, v28

    const/16 v4, 0x1e

    const/16 v6, 0x46

    aput-byte v6, v3, v4

    const/16 v4, 0x1f

    const/16 v6, -0x7f

    aput-byte v6, v3, v4

    const/16 v4, 0x20

    aput-byte v33, v3, v4

    const/16 v4, 0x21

    const/16 v6, -0x37

    aput-byte v6, v3, v4

    const/16 v4, 0x22

    const/16 v6, 0x28

    aput-byte v6, v3, v4

    const/16 v4, 0x23

    const/16 v6, 0x7b

    aput-byte v6, v3, v4

    const/16 v4, 0x24

    const/16 v6, -0x29

    aput-byte v6, v3, v4

    const/16 v4, 0x25

    const/16 v6, 0x36

    aput-byte v6, v3, v4

    const/16 v4, 0x26

    const/16 v6, 0xe

    aput-byte v6, v3, v4

    const/16 v4, 0x27

    const/16 v6, -0x7c

    aput-byte v6, v3, v4

    const/16 v4, -0x68

    const/16 v6, 0x28

    aput-byte v4, v3, v6

    const/16 v4, 0x29

    const/16 v6, -0x26

    aput-byte v6, v3, v4

    const/16 v4, 0x2a

    const/16 v6, 0x7c

    aput-byte v6, v3, v4

    const/16 v4, 0x2b

    const/16 v6, 0x4e

    aput-byte v6, v3, v4

    const/16 v4, -0x80

    aput-byte v4, v3, v35

    const/16 v4, 0x2d

    const/16 v6, 0x5b

    aput-byte v6, v3, v4

    const/16 v4, 0x2e

    const/16 v6, 0x53

    aput-byte v6, v3, v4

    const/16 v4, 0x2f

    const/16 v6, -0x23

    aput-byte v6, v3, v4

    const/16 v4, 0x30

    const/16 v6, -0x4c

    aput-byte v6, v3, v4

    const/16 v4, 0x31

    const/16 v6, -0x67

    aput-byte v6, v3, v4

    const/16 v4, 0x32

    const/16 v6, 0x25

    aput-byte v6, v3, v4

    const/16 v4, 0x33

    const/16 v6, 0x7d

    aput-byte v6, v3, v4

    const/16 v4, 0x34

    const/16 v6, -0x3c

    aput-byte v6, v3, v4

    const/16 v4, 0x35

    aput-byte v7, v3, v4

    const/16 v4, 0x36

    aput-byte v10, v3, v4

    const/16 v4, 0x37

    const/16 v6, -0x80

    aput-byte v6, v3, v4

    const/16 v4, 0x38

    const/16 v6, -0x56

    aput-byte v6, v3, v4

    const/16 v4, 0x39

    const/16 v6, -0x2e

    aput-byte v6, v3, v4

    const/16 v4, 0x3a

    const/16 v6, 0x2e

    aput-byte v6, v3, v4

    const/16 v4, 0x3b

    const/16 v6, 0x7c

    aput-byte v6, v3, v4

    const/16 v4, 0x3c

    const/16 v6, -0x29

    aput-byte v6, v3, v4

    const/16 v4, 0x3d

    const/4 v6, 0x5

    aput-byte v6, v3, v4

    const/16 v4, 0x3e

    const/16 v6, 0x5d

    aput-byte v6, v3, v4

    const/16 v4, 0x3f

    const/16 v6, -0x4d

    aput-byte v6, v3, v4

    const/16 v4, 0x40

    const/16 v6, -0x39

    aput-byte v6, v3, v4

    const/16 v4, 0x41

    const/16 v6, -0x73

    aput-byte v6, v3, v4

    const/16 v4, 0x42

    const/16 v6, 0x72

    aput-byte v6, v3, v4

    const/16 v4, 0x43

    const/16 v6, 0x20

    aput-byte v6, v3, v4

    const/16 v4, 0x44

    const/16 v6, -0xd

    aput-byte v6, v3, v4

    const/16 v4, 0x45

    const/16 v6, 0x4f

    aput-byte v6, v3, v4

    const/16 v4, 0x46

    aput-byte v9, v3, v4

    const/16 v4, 0x47

    aput-byte v33, v3, v4

    const/16 v4, 0x48

    const/16 v6, -0x64

    aput-byte v6, v3, v4

    const/16 v4, 0x49

    const/16 v6, -0x2d

    aput-byte v6, v3, v4

    const/16 v4, 0x4a

    const/16 v6, 0x25

    aput-byte v6, v3, v4

    const/16 v4, 0x4b

    const/16 v6, 0x47

    aput-byte v6, v3, v4

    const/16 v4, 0x4c

    const/16 v6, -0x2a

    aput-byte v6, v3, v4

    const/16 v4, 0x4d

    const/16 v6, 0xc

    aput-byte v6, v3, v4

    const/16 v4, 0x4e

    aput-byte v25, v3, v4

    const/16 v4, 0x4f

    const/16 v6, -0x74

    aput-byte v6, v3, v4

    const/16 v4, 0x50

    const/16 v6, -0x6a

    aput-byte v6, v3, v4

    const/16 v4, 0x51

    const/16 v6, -0x26

    aput-byte v6, v3, v4

    const/16 v4, 0x52

    const/16 v6, 0x7c

    aput-byte v6, v3, v4

    const/16 v4, 0x53

    const/16 v6, 0x4e

    aput-byte v6, v3, v4

    const/16 v4, 0x54

    const/16 v6, -0x80

    aput-byte v6, v3, v4

    const/16 v4, 0x55

    const/16 v6, 0x5b

    aput-byte v6, v3, v4

    const/16 v4, 0x56

    const/16 v6, 0x53

    aput-byte v6, v3, v4

    const/16 v4, 0x57

    const/16 v6, -0x23

    aput-byte v6, v3, v4

    const/16 v4, 0x58

    const/16 v6, -0x4c

    aput-byte v6, v3, v4

    const/16 v4, 0x59

    const/16 v6, -0x67

    aput-byte v6, v3, v4

    const/16 v4, 0x5a

    const/16 v6, 0x23

    aput-byte v6, v3, v4

    const/16 v4, 0x5b

    const/16 v6, 0x6d

    aput-byte v6, v3, v4

    const/16 v4, 0x5c

    const/16 v6, -0x25

    aput-byte v6, v3, v4

    const/16 v4, 0x5d

    const/4 v6, 0x5

    aput-byte v6, v3, v4

    const/16 v4, 0x5e

    const/4 v6, 0x4

    aput-byte v6, v3, v4

    const/16 v4, 0x5f

    const/16 v6, -0x46

    aput-byte v6, v3, v4

    const/16 v4, 0x60

    const/16 v6, -0x7b

    aput-byte v6, v3, v4

    const/16 v4, 0x61

    const/16 v6, -0x33

    aput-byte v6, v3, v4

    const/16 v4, 0x62

    const/16 v6, 0x2e

    aput-byte v6, v3, v4

    const/16 v4, 0x63

    const/16 v6, 0x7c

    aput-byte v6, v3, v4

    const/16 v4, 0x64

    const/16 v6, -0x39

    aput-byte v6, v3, v4

    const/16 v4, 0x65

    const/16 v6, 0xa

    aput-byte v6, v3, v4

    const/16 v4, 0x66

    aput-byte v23, v3, v4

    const/16 v4, 0x67

    const/16 v6, -0x28

    aput-byte v6, v3, v4

    const/16 v4, 0x68

    const/16 v6, -0x5d

    aput-byte v6, v3, v4

    const/16 v4, 0x69

    const/16 v6, -0x73

    aput-byte v6, v3, v4

    const/16 v4, 0x6a

    const/16 v6, 0x73

    aput-byte v6, v3, v4

    const/16 v4, 0x6b

    const/16 v6, 0x2b

    aput-byte v6, v3, v4

    const/16 v4, 0x6c

    const/16 v6, -0x76

    aput-byte v6, v3, v4

    const/16 v4, 0x6d

    const/16 v6, 0x28

    aput-byte v6, v3, v4

    const/16 v4, 0x6e

    const/16 v6, 0x46

    aput-byte v6, v3, v4

    const/16 v4, 0x6f

    const/16 v6, -0x7f

    aput-byte v6, v3, v4

    const/16 v4, 0x70

    aput-byte v33, v3, v4

    const/16 v4, 0x71

    const/16 v6, -0x37

    aput-byte v6, v3, v4

    const/16 v4, 0x72

    const/16 v6, 0x28

    aput-byte v6, v3, v4

    const/16 v4, 0x73

    const/16 v6, 0x7b

    aput-byte v6, v3, v4

    const/16 v4, 0x74

    const/16 v6, -0x29

    aput-byte v6, v3, v4

    const/16 v4, 0x75

    const/16 v6, 0x36

    aput-byte v6, v3, v4

    const/16 v4, 0x76

    const/4 v6, 0x7

    aput-byte v6, v3, v4

    const/16 v4, 0x77

    const/16 v6, -0x6b

    aput-byte v6, v3, v4

    const/16 v4, 0x78

    const/16 v6, -0x80

    aput-byte v6, v3, v4

    const/16 v4, 0x79

    const/16 v6, -0x7e

    aput-byte v6, v3, v4

    const/16 v4, 0x7a

    aput-byte v7, v3, v4

    const/16 v4, 0x7b

    const/16 v6, 0x7c

    aput-byte v6, v3, v4

    const/16 v4, 0x7c

    const/16 v6, -0x40

    aput-byte v6, v3, v4

    const/16 v4, 0x7d

    const/16 v6, 0xc

    aput-byte v6, v3, v4

    const/16 v4, 0x7e

    const/16 v6, 0xe

    aput-byte v6, v3, v4

    const/16 v4, 0x7f

    const/16 v6, -0x76

    aput-byte v6, v3, v4

    const/16 v4, 0x80

    const/16 v6, -0x30

    aput-byte v6, v3, v4

    const/16 v4, 0x81

    const/16 v6, -0x73

    aput-byte v6, v3, v4

    const/16 v4, 0x82

    const/16 v6, 0x71

    aput-byte v6, v3, v4

    const/16 v4, 0x83

    const/16 v6, 0x30

    aput-byte v6, v3, v4

    const/16 v4, 0x84

    const/16 v6, -0x1a

    aput-byte v6, v3, v4

    const/16 v4, 0x85

    const/16 v6, 0x24

    aput-byte v6, v3, v4

    const/16 v4, 0x86

    const/16 v6, 0x49

    aput-byte v6, v3, v4

    const/16 v4, 0x87

    const/16 v6, -0x40

    aput-byte v6, v3, v4

    const/16 v4, 0x88

    const/16 v6, -0x39

    aput-byte v6, v3, v4

    const/16 v4, 0x89

    const/16 v6, -0x71

    aput-byte v6, v3, v4

    const/16 v4, 0x8a

    const/16 v6, 0x77

    aput-byte v6, v3, v4

    const/16 v4, 0x8b

    aput-byte v35, v3, v4

    const/16 v4, 0x8c

    const/16 v6, -0x7e

    aput-byte v6, v3, v4

    const/16 v4, 0x8d

    const/16 v6, 0x4f

    aput-byte v6, v3, v4

    const/16 v4, 0x8e

    aput-byte v8, v3, v4

    const/16 v4, 0x8f

    const/16 v6, -0x7a

    aput-byte v6, v3, v4

    const/16 v4, 0x90

    const/16 v6, -0x7f

    aput-byte v6, v3, v4

    const/16 v4, 0x91

    const/16 v6, -0x2a

    aput-byte v6, v3, v4

    const/16 v4, 0x92

    const/16 v6, 0x37

    aput-byte v6, v3, v4

    const/16 v4, 0x93

    const/16 v6, 0x71

    aput-byte v6, v3, v4

    const/16 v4, 0x94

    const/16 v6, -0x3a

    aput-byte v6, v3, v4

    const/16 v4, 0x95

    const/16 v6, 0x10

    aput-byte v6, v3, v4

    const/16 v4, 0x96

    const/16 v6, 0x3f

    aput-byte v6, v3, v4

    const/16 v4, 0x97

    const/16 v6, -0x69

    aput-byte v6, v3, v4

    const/16 v4, 0x98

    aput-byte v33, v3, v4

    const/16 v4, 0x99

    const/16 v6, -0x24

    aput-byte v6, v3, v4

    const/16 v4, 0x9a

    const/16 v6, 0x35

    aput-byte v6, v3, v4

    const/16 v4, 0x9b

    const/16 v6, 0x25

    aput-byte v6, v3, v4

    const/16 v4, 0x9c

    const/16 v6, -0x69

    aput-byte v6, v3, v4

    const/16 v4, 0x9d

    const/16 v6, 0x5e

    aput-byte v6, v3, v4

    const/16 v4, 0x9e

    const/16 v6, 0x22

    aput-byte v6, v3, v4

    const/16 v4, 0x9f

    const/16 v6, -0x40

    aput-byte v6, v3, v4

    const/16 v4, 0xa0

    const/16 v6, -0x3e

    aput-byte v6, v3, v4

    const/16 v4, 0xa1

    const/4 v6, -0x5

    aput-byte v6, v3, v4

    const/16 v4, 0xa2

    const/16 v6, 0x67

    aput-byte v6, v3, v4

    const/16 v4, 0xa3

    const/16 v6, 0x7b

    aput-byte v6, v3, v4

    const/16 v4, 0xa4

    const/16 v6, -0x26

    aput-byte v6, v3, v4

    const/16 v4, 0xa5

    const/16 v6, 0x8

    aput-byte v6, v3, v4

    const/16 v4, 0xa6

    const/16 v6, 0xe

    aput-byte v6, v3, v4

    const/16 v4, 0xa7

    const/16 v6, -0x75

    aput-byte v6, v3, v4

    const/16 v4, 0xa8

    aput-byte v33, v3, v4

    const/16 v4, 0xa9

    const/16 v6, -0x2d

    aput-byte v6, v3, v4

    const/16 v4, 0xaa

    const/16 v6, 0x7c

    aput-byte v6, v3, v4

    const/16 v4, 0xab

    const/16 v6, 0x4d

    aput-byte v6, v3, v4

    const/16 v4, 0xac

    const/16 v6, -0xf

    aput-byte v6, v3, v4

    const/16 v4, 0xad

    const/16 v6, 0x3d

    aput-byte v6, v3, v4

    const/16 v4, 0xae

    const/16 v6, 0x36

    aput-byte v6, v3, v4

    const/16 v4, 0xaf

    const/16 v6, -0x56

    aput-byte v6, v3, v4

    const/16 v4, 0xb0

    const/16 v6, -0x4d

    aput-byte v6, v3, v4

    const/16 v4, 0xb1

    const/4 v6, -0x7

    aput-byte v6, v3, v4

    const/16 v4, 0xb2

    const/16 v6, 0x8

    aput-byte v6, v3, v4

    const/16 v4, 0xb3

    const/16 v6, 0x5b

    aput-byte v6, v3, v4

    const/16 v4, 0xb4

    const/4 v6, -0x5

    aput-byte v6, v3, v4

    const/16 v4, 0xb5

    const/16 v6, 0x28

    aput-byte v6, v3, v4

    const/16 v4, 0xb6

    aput-byte v35, v3, v4

    const/16 v4, 0xb7

    const/16 v6, -0x4e

    aput-byte v6, v3, v4

    const/16 v4, 0xb8

    const/16 v6, -0x50

    aput-byte v6, v3, v4

    const/16 v4, 0xb9

    const/4 v6, -0x3

    aput-byte v6, v3, v4

    const/16 v4, 0xba

    const/16 v6, 0x67

    aput-byte v6, v3, v4

    const/16 v4, 0xbb

    const/16 v6, 0x75

    aput-byte v6, v3, v4

    const/16 v4, 0xbc

    const/16 v6, -0x29

    aput-byte v6, v3, v4

    const/16 v4, 0xbd

    aput-byte v28, v3, v4

    const/16 v4, 0xbe

    const/16 v6, 0x8

    aput-byte v6, v3, v4

    const/16 v4, 0xbf

    const/16 v6, -0x76

    aput-byte v6, v3, v4

    const/16 v4, 0xc0

    const/16 v6, -0x6f

    aput-byte v6, v3, v4

    const/16 v4, 0xc1

    const/16 v6, -0x7e

    aput-byte v6, v3, v4

    const/16 v4, 0xc2

    const/16 v6, 0x32

    aput-byte v6, v3, v4

    const/16 v4, 0xc3

    const/16 v6, 0x6c

    aput-byte v6, v3, v4

    const/16 v4, 0xc4

    const/16 v6, -0x40

    aput-byte v6, v3, v4

    const/16 v4, 0xc5

    const/16 v6, 0xc

    aput-byte v6, v3, v4

    const/16 v4, 0xc6

    aput-byte v8, v3, v4

    const/16 v4, 0xc7

    const/16 v6, -0x78

    aput-byte v6, v3, v4

    const/16 v4, 0xc8

    const/16 v6, -0x64

    aput-byte v6, v3, v4

    const/16 v4, 0xc9

    const/16 v6, -0x2f

    aput-byte v6, v3, v4

    const/16 v4, 0xca

    const/16 v6, 0x26

    aput-byte v6, v3, v4

    const/16 v4, 0xcb

    const/16 v6, 0x3e

    aput-byte v6, v3, v4

    const/16 v4, 0xcc

    const/16 v6, -0x2b

    aput-byte v6, v3, v4

    const/16 v4, 0xcd

    aput-byte v16, v3, v4

    const/16 v4, 0xce

    const/16 v6, 0xf

    aput-byte v6, v3, v4

    const/16 v4, 0xcf

    aput-byte v33, v3, v4

    const/16 v4, 0xd0

    const/16 v6, -0x7b

    aput-byte v6, v3, v4

    const/16 v4, 0xd1

    const/16 v6, -0x20

    aput-byte v6, v3, v4

    const/16 v4, 0xd2

    const/16 v6, 0x23

    aput-byte v6, v3, v4

    const/16 v4, 0xd3

    const/16 v6, 0x61

    aput-byte v6, v3, v4

    const/16 v4, 0xd4

    const/16 v6, -0x71

    aput-byte v6, v3, v4

    const/16 v4, 0xd5

    const/16 v6, 0x1a

    aput-byte v6, v3, v4

    const/16 v4, 0xd6

    const/16 v6, 0xf

    aput-byte v6, v3, v4

    const/16 v4, 0xd7

    aput-byte v33, v3, v4

    const/16 v4, 0xd8

    const/16 v6, -0x79

    aput-byte v6, v3, v4

    const/16 v4, 0xd9

    const/16 v6, -0x24

    aput-byte v6, v3, v4

    const/16 v4, 0xda

    const/16 v6, 0x24

    aput-byte v6, v3, v4

    const/16 v4, 0xdb

    const/16 v6, 0x3e

    aput-byte v6, v3, v4

    const/16 v4, 0xdc

    const/16 v6, -0x2c

    aput-byte v6, v3, v4

    const/16 v4, 0xdd

    aput-byte v7, v3, v4

    const/16 v4, 0xde

    const/4 v6, 0x4

    aput-byte v6, v3, v4

    const/16 v4, 0xdf

    const/16 v6, -0x28

    aput-byte v6, v3, v4

    const/16 v4, 0x8

    new-array v6, v4, [B

    const/16 v4, -0xb

    aput-byte v4, v6, v7

    const/16 v4, -0x41

    aput-byte v4, v6, v8

    const/16 v4, 0x41

    aput-byte v4, v6, v9

    const/16 v4, 0x18

    aput-byte v4, v6, v10

    const/16 v4, -0x4e

    const/4 v11, 0x4

    aput-byte v4, v6, v11

    const/16 v4, 0x69

    const/4 v11, 0x5

    aput-byte v4, v6, v11

    const/16 v4, 0x60

    const/4 v11, 0x6

    aput-byte v4, v6, v11

    const/16 v4, -0x1b

    const/4 v11, 0x7

    aput-byte v4, v6, v11

    invoke-static {v3, v6}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v14, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v14, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v1, 0x3c

    new-array v1, v1, [B

    const/16 v3, 0x57

    aput-byte v3, v1, v7

    const/16 v3, -0x47

    aput-byte v3, v1, v8

    const/16 v3, 0x71

    aput-byte v3, v1, v9

    const/16 v3, -0x76

    aput-byte v3, v1, v10

    const/16 v3, -0x63

    const/4 v4, 0x4

    aput-byte v3, v1, v4

    const/16 v3, 0x62

    const/4 v4, 0x5

    aput-byte v3, v1, v4

    const/16 v3, 0x45

    const/4 v4, 0x6

    aput-byte v3, v1, v4

    const/16 v3, -0x19

    const/4 v4, 0x7

    aput-byte v3, v1, v4

    const/16 v3, 0x18

    const/16 v4, 0x8

    aput-byte v3, v1, v4

    const/16 v3, -0x5c

    const/16 v4, 0x9

    aput-byte v3, v1, v4

    const/16 v3, 0x7a

    const/16 v4, 0xa

    aput-byte v3, v1, v4

    const/16 v3, -0x3c

    const/16 v4, 0xb

    aput-byte v3, v1, v4

    const/16 v3, -0x62

    const/16 v4, 0xc

    aput-byte v3, v1, v4

    const/16 v3, 0x61

    aput-byte v3, v1, v18

    const/16 v3, 0x47

    const/16 v4, 0xe

    aput-byte v3, v1, v4

    const/16 v3, -0x41

    const/16 v4, 0xf

    aput-byte v3, v1, v4

    const/16 v3, 0x10

    const/16 v4, 0x1f

    aput-byte v4, v1, v3

    const/16 v3, -0x5c

    aput-byte v3, v1, v21

    const/16 v3, 0x66

    aput-byte v3, v1, v22

    const/16 v3, 0x13

    const/16 v4, -0x6c

    aput-byte v4, v1, v3

    const/16 v3, -0x6d

    aput-byte v3, v1, v23

    const/16 v3, 0x62

    aput-byte v3, v1, v24

    aput-byte v17, v1, v25

    const/4 v3, -0x5

    const/16 v4, 0x17

    aput-byte v3, v1, v4

    const/16 v3, 0x18

    aput-byte v3, v1, v3

    const/16 v3, 0x19

    const/16 v4, -0x54

    aput-byte v4, v1, v3

    const/16 v3, 0x1a

    const/16 v4, 0x7c

    aput-byte v4, v1, v3

    const/16 v3, -0x2b

    aput-byte v3, v1, v16

    const/16 v3, -0x7f

    aput-byte v3, v1, v17

    const/16 v3, 0x7b

    aput-byte v3, v1, v28

    const/16 v3, 0x1e

    const/16 v4, 0x40

    aput-byte v4, v1, v3

    const/16 v3, 0x1f

    const/16 v4, -0xa

    aput-byte v4, v1, v3

    const/16 v3, 0x20

    aput-byte v10, v1, v3

    const/16 v3, 0x21

    const/16 v4, -0x19

    aput-byte v4, v1, v3

    const/16 v3, 0x22

    const/16 v4, 0x26

    aput-byte v4, v1, v3

    const/16 v3, 0x23

    const/16 v4, -0x6e

    aput-byte v4, v1, v3

    const/16 v3, 0x24

    const/16 v4, -0x22

    aput-byte v4, v1, v3

    const/16 v3, 0x25

    const/16 v4, 0x3a

    aput-byte v4, v1, v3

    const/16 v3, 0x5b

    const/16 v4, 0x26

    aput-byte v3, v1, v4

    const/16 v3, 0x27

    const/16 v4, -0x4b

    aput-byte v4, v1, v3

    const/16 v3, 0x28

    aput-byte v9, v1, v3

    const/16 v3, 0x29

    const/16 v4, -0x42

    aput-byte v4, v1, v3

    const/16 v3, 0x2a

    const/16 v4, 0x64

    aput-byte v4, v1, v3

    const/16 v3, 0x2b

    const/16 v4, -0x77

    aput-byte v4, v1, v3

    const/16 v3, -0x63

    aput-byte v3, v1, v35

    const/16 v3, 0x2d

    const/16 v4, 0x7c

    aput-byte v4, v1, v3

    const/16 v3, 0x2e

    const/16 v4, 0x44

    aput-byte v4, v1, v3

    const/16 v3, 0x2f

    const/16 v4, -0x52

    aput-byte v4, v1, v3

    const/16 v3, 0x30

    aput-byte v24, v1, v3

    const/16 v3, 0x31

    const/16 v4, -0x5c

    aput-byte v4, v1, v3

    const/16 v3, 0x32

    const/16 v4, 0x78

    aput-byte v4, v1, v3

    const/16 v3, 0x33

    const/16 v4, -0x65

    aput-byte v4, v1, v3

    const/16 v3, 0x34

    const/16 v4, -0x75

    aput-byte v4, v1, v3

    const/16 v3, 0x35

    const/16 v4, 0x51

    aput-byte v4, v1, v3

    const/16 v3, 0x36

    const/16 v4, 0x46

    aput-byte v4, v1, v3

    const/16 v3, 0x37

    const/4 v4, -0x6

    aput-byte v4, v1, v3

    const/16 v3, 0x38

    aput-byte v9, v1, v3

    const/16 v3, 0x39

    const/16 v4, -0x5e

    aput-byte v4, v1, v3

    const/16 v3, 0x3a

    const/16 v4, 0x7b

    aput-byte v4, v1, v3

    const/16 v3, 0x3b

    const/16 v4, -0x69

    aput-byte v4, v1, v3

    const/16 v3, 0x8

    new-array v4, v3, [B

    const/16 v3, 0x71

    aput-byte v3, v4, v7

    const/16 v3, -0x35

    aput-byte v3, v4, v8

    aput-byte v23, v4, v9

    const/4 v3, -0x7

    aput-byte v3, v4, v10

    const/16 v3, -0xe

    const/4 v6, 0x4

    aput-byte v3, v4, v6

    const/16 v3, 0xe

    const/4 v6, 0x5

    aput-byte v3, v4, v6

    const/16 v3, 0x30

    const/4 v6, 0x6

    aput-byte v3, v4, v6

    const/16 v3, -0x6d

    const/4 v6, 0x7

    aput-byte v3, v4, v6

    invoke-static {v1, v4}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v14, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v14}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    new-instance v3, Ljava/util/HashMap;

    invoke-direct {v3}, Ljava/util/HashMap;-><init>()V

    const/16 v4, 0xa

    new-array v6, v4, [B

    const/4 v4, 0x6

    aput-byte v4, v6, v7

    const/16 v4, -0x66

    aput-byte v4, v6, v8

    const/16 v4, 0x48

    aput-byte v4, v6, v9

    const/16 v4, -0x3f

    aput-byte v4, v6, v10

    const/16 v4, -0x41

    const/4 v11, 0x4

    aput-byte v4, v6, v11

    const/16 v4, 0x76

    const/4 v12, 0x5

    aput-byte v4, v6, v12

    const/16 v4, -0x4a

    const/4 v12, 0x6

    aput-byte v4, v6, v12

    const/4 v4, 0x7

    aput-byte v11, v6, v4

    const/16 v4, 0x3d

    const/16 v11, 0x8

    aput-byte v4, v6, v11

    const/16 v4, -0x63

    const/16 v12, 0x9

    aput-byte v4, v6, v12

    new-array v4, v11, [B

    const/16 v11, 0x53

    aput-byte v11, v4, v7

    const/16 v11, -0x17

    aput-byte v11, v4, v8

    const/16 v11, 0x2d

    aput-byte v11, v4, v9

    const/16 v11, -0x4d

    aput-byte v11, v4, v10

    const/16 v11, -0x6e

    const/4 v12, 0x4

    aput-byte v11, v4, v12

    const/16 v11, 0x37

    const/4 v12, 0x5

    aput-byte v11, v4, v12

    const/16 v11, -0x2f

    const/4 v12, 0x6

    aput-byte v11, v4, v12

    const/16 v11, 0x61

    const/4 v12, 0x7

    aput-byte v11, v4, v12

    invoke-static {v6, v4}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v4

    const/16 v6, 0x78

    new-array v6, v6, [B

    const/16 v11, 0x38

    aput-byte v11, v6, v7

    const/16 v11, -0x1b

    aput-byte v11, v6, v8

    const/16 v11, -0x4c

    aput-byte v11, v6, v9

    const/16 v11, -0x41

    aput-byte v11, v6, v10

    const/4 v11, -0x1

    const/4 v12, 0x4

    aput-byte v11, v6, v12

    const/16 v11, 0x4b

    const/4 v12, 0x5

    aput-byte v11, v6, v12

    const/16 v11, 0x56

    const/4 v12, 0x6

    aput-byte v11, v6, v12

    const/16 v11, -0x56

    const/4 v12, 0x7

    aput-byte v11, v6, v12

    const/16 v11, 0x40

    const/16 v12, 0x8

    aput-byte v11, v6, v12

    const/16 v11, -0x5c

    const/16 v12, 0x9

    aput-byte v11, v6, v12

    const/4 v11, -0x2

    const/16 v12, 0xa

    aput-byte v11, v6, v12

    const/16 v11, -0xa

    const/16 v12, 0xb

    aput-byte v11, v6, v12

    const/16 v11, -0x45

    const/16 v12, 0xc

    aput-byte v11, v6, v12

    const/16 v11, 0x6b

    aput-byte v11, v6, v18

    const/16 v11, 0x5e

    const/16 v12, 0xe

    aput-byte v11, v6, v12

    const/16 v11, -0x15

    const/16 v12, 0xf

    aput-byte v11, v6, v12

    const/16 v11, 0x10

    aput-byte v7, v6, v11

    const/16 v11, -0xe

    aput-byte v11, v6, v21

    const/16 v11, -0xb

    aput-byte v11, v6, v22

    const/16 v11, 0x13

    const/16 v12, -0xa

    aput-byte v12, v6, v11

    const/16 v11, -0x3a

    aput-byte v11, v6, v23

    aput-byte v17, v6, v24

    const/16 v11, 0x17

    aput-byte v11, v6, v25

    const/16 v12, -0x3c

    aput-byte v12, v6, v11

    const/16 v11, 0x18

    aput-byte v16, v6, v11

    const/16 v11, 0x19

    const/16 v12, -0x12

    aput-byte v12, v6, v11

    const/16 v11, 0x1a

    const/16 v12, -0x44

    aput-byte v12, v6, v11

    const/16 v11, -0x47

    aput-byte v11, v6, v16

    const/4 v11, -0x6

    aput-byte v11, v6, v17

    const/16 v11, 0x43

    aput-byte v11, v6, v28

    const/16 v11, 0x1e

    const/16 v12, 0x17

    aput-byte v12, v6, v11

    const/16 v11, 0x1f

    const/16 v12, -0x4c

    aput-byte v12, v6, v11

    const/16 v11, 0x20

    const/16 v12, 0x47

    aput-byte v12, v6, v11

    const/16 v11, 0x21

    const/16 v12, -0x4f

    aput-byte v12, v6, v11

    const/16 v11, 0x22

    const/16 v12, -0x12

    aput-byte v12, v6, v11

    const/16 v11, 0x23

    const/16 v12, -0x54

    aput-byte v12, v6, v11

    const/16 v11, 0x24

    const/4 v12, -0x5

    aput-byte v12, v6, v11

    const/16 v11, 0x25

    const/16 v12, 0xa

    aput-byte v12, v6, v11

    const/16 v11, 0x54

    const/16 v12, 0x26

    aput-byte v11, v6, v12

    const/16 v11, 0x27

    const/16 v12, -0x15

    aput-byte v12, v6, v11

    const/16 v11, 0x4e

    const/16 v12, 0x28

    aput-byte v11, v6, v12

    const/16 v11, 0x29

    const/16 v12, -0x56

    aput-byte v12, v6, v11

    const/16 v11, 0x2a

    const/16 v12, -0x68

    aput-byte v12, v6, v11

    const/16 v11, 0x2b

    const/16 v12, -0x1c

    aput-byte v12, v6, v11

    const/16 v11, -0x5f

    aput-byte v11, v6, v35

    const/16 v11, 0x2d

    aput-byte v23, v6, v11

    const/16 v11, 0x2e

    const/16 v12, 0xf

    aput-byte v12, v6, v11

    const/16 v11, 0x2f

    const/16 v12, -0x3c

    aput-byte v12, v6, v11

    const/16 v11, 0x30

    const/16 v12, 0x55

    aput-byte v12, v6, v11

    const/16 v11, 0x31

    const/16 v12, -0x38

    aput-byte v12, v6, v11

    const/16 v11, 0x32

    const/16 v12, -0x45

    aput-byte v12, v6, v11

    const/16 v11, 0x33

    const/16 v12, -0x41

    aput-byte v12, v6, v11

    const/16 v11, 0x34

    const/4 v12, -0x1

    aput-byte v12, v6, v11

    const/16 v11, 0x35

    const/16 v12, 0x43

    aput-byte v12, v6, v11

    const/16 v11, 0x36

    const/16 v12, 0x18

    aput-byte v12, v6, v11

    const/16 v11, 0x37

    const/16 v12, -0x2d

    aput-byte v12, v6, v11

    const/16 v11, 0x38

    const/16 v12, 0x41

    aput-byte v12, v6, v11

    const/16 v11, 0x39

    const/16 v12, -0x45

    aput-byte v12, v6, v11

    const/16 v11, 0x3a

    const/4 v12, -0x7

    aput-byte v12, v6, v11

    const/16 v11, 0x3b

    const/16 v12, -0x61

    aput-byte v12, v6, v11

    const/16 v11, 0x3c

    const/16 v12, -0x3f

    aput-byte v12, v6, v11

    const/16 v11, 0x3d

    const/16 v12, 0xe

    aput-byte v12, v6, v11

    const/16 v11, 0x3e

    const/16 v12, 0x17

    aput-byte v12, v6, v11

    const/16 v11, 0x3f

    const/16 v12, -0x3c

    aput-byte v12, v6, v11

    const/16 v11, 0x40

    const/4 v12, 0x5

    aput-byte v12, v6, v11

    const/16 v11, 0x41

    const/4 v12, -0x6

    aput-byte v12, v6, v11

    const/16 v11, 0x42

    const/16 v12, -0x5e

    aput-byte v12, v6, v11

    const/16 v11, 0x43

    const/16 v12, -0x4d

    aput-byte v12, v6, v11

    const/16 v11, 0x44

    const/16 v12, -0x3c

    aput-byte v12, v6, v11

    const/16 v11, 0x45

    const/16 v12, 0x42

    aput-byte v12, v6, v11

    const/16 v11, 0x46

    const/16 v12, 0x55

    aput-byte v12, v6, v11

    const/16 v11, 0x47

    const/16 v12, -0x32

    aput-byte v12, v6, v11

    const/16 v11, 0x48

    aput-byte v17, v6, v11

    const/16 v11, 0x49

    const/4 v12, -0x2

    aput-byte v12, v6, v11

    const/16 v11, 0x4a

    const/16 v12, -0x1f

    aput-byte v12, v6, v11

    const/16 v11, 0x4b

    const/16 v12, -0x1d

    aput-byte v12, v6, v11

    const/16 v11, 0x4c

    const/16 v12, -0x60

    aput-byte v12, v6, v11

    const/16 v11, 0x4d

    aput-byte v23, v6, v11

    const/16 v11, 0x4e

    const/16 v12, 0x19

    aput-byte v12, v6, v11

    const/16 v11, 0x4f

    const/16 v12, -0x4c

    aput-byte v12, v6, v11

    const/16 v11, 0x50

    const/16 v12, 0x55

    aput-byte v12, v6, v11

    const/16 v11, 0x51

    const/16 v12, -0x5e

    aput-byte v12, v6, v11

    const/16 v11, 0x52

    const/16 v12, -0x7b

    aput-byte v12, v6, v11

    const/16 v11, 0x53

    const/16 v12, -0x62

    aput-byte v12, v6, v11

    const/16 v11, 0x54

    const/16 v12, -0x39

    aput-byte v12, v6, v11

    const/16 v11, 0x55

    const/16 v12, 0x6a

    aput-byte v12, v6, v11

    const/16 v11, 0x56

    const/16 v12, 0x7b

    aput-byte v12, v6, v11

    const/16 v11, 0x57

    const/16 v12, -0x57

    aput-byte v12, v6, v11

    const/16 v11, 0x58

    const/16 v12, 0x55

    aput-byte v12, v6, v11

    const/16 v11, 0x59

    const/16 v12, -0x1a

    aput-byte v12, v6, v11

    const/16 v11, 0x5a

    const/16 v12, -0x59

    aput-byte v12, v6, v11

    const/16 v11, 0x5b

    const/16 v12, -0x43

    aput-byte v12, v6, v11

    const/16 v11, 0x5c

    const/16 v12, -0xa

    aput-byte v12, v6, v11

    const/16 v11, 0x5d

    const/4 v12, 0x7

    aput-byte v12, v6, v11

    const/16 v11, 0x5e

    const/16 v12, 0x70

    aput-byte v12, v6, v11

    const/16 v11, 0x5f

    const/16 v12, -0x20

    aput-byte v12, v6, v11

    const/16 v11, 0x60

    aput-byte v25, v6, v11

    const/16 v11, 0x61

    const/16 v12, -0x1f

    aput-byte v12, v6, v11

    const/16 v11, 0x62

    const/16 v12, -0x5f

    aput-byte v12, v6, v11

    const/16 v11, 0x63

    const/4 v12, -0x1

    aput-byte v12, v6, v11

    const/16 v11, 0x64

    const/16 v12, -0x4d

    aput-byte v12, v6, v11

    const/16 v11, 0x65

    const/16 v12, 0x6a

    aput-byte v12, v6, v11

    const/16 v11, 0x66

    const/16 v12, 0x58

    aput-byte v12, v6, v11

    const/16 v11, 0x67

    const/16 v12, -0x19

    aput-byte v12, v6, v11

    const/16 v11, 0x68

    aput-byte v17, v6, v11

    const/16 v11, 0x69

    const/16 v12, -0x1a

    aput-byte v12, v6, v11

    const/16 v11, 0x6a

    const/16 v12, -0x55

    aput-byte v12, v6, v11

    const/16 v11, 0x6b

    const/16 v12, -0xa

    aput-byte v12, v6, v11

    const/16 v11, 0x6c

    const/16 v12, -0x40

    aput-byte v12, v6, v11

    const/16 v11, 0x6d

    const/16 v12, 0x46

    aput-byte v12, v6, v11

    const/16 v11, 0x6e

    const/16 v12, 0x51

    aput-byte v12, v6, v11

    const/16 v11, 0x6f

    const/16 v12, -0x1c

    aput-byte v12, v6, v11

    const/16 v11, 0x70

    const/4 v12, 0x7

    aput-byte v12, v6, v11

    const/16 v11, 0x71

    const/16 v12, -0x1d

    aput-byte v12, v6, v11

    const/16 v11, 0x72

    const/16 v12, -0x1f

    aput-byte v12, v6, v11

    const/16 v11, 0x73

    const/16 v12, -0x1d

    aput-byte v12, v6, v11

    const/16 v11, 0x74

    const/16 v12, -0x60

    aput-byte v12, v6, v11

    const/16 v11, 0x75

    aput-byte v23, v6, v11

    const/16 v11, 0x76

    const/16 v12, 0x19

    aput-byte v12, v6, v11

    const/16 v11, 0x77

    const/16 v12, -0x4c

    aput-byte v12, v6, v11

    const/16 v11, 0x8

    new-array v12, v11, [B

    const/16 v11, 0x75

    aput-byte v11, v12, v7

    const/16 v11, -0x76

    aput-byte v11, v12, v8

    const/16 v11, -0x32

    aput-byte v11, v12, v9

    const/16 v11, -0x2a

    aput-byte v11, v12, v10

    const/16 v11, -0x6d

    const/4 v14, 0x4

    aput-byte v11, v12, v14

    const/16 v11, 0x27

    const/4 v14, 0x5

    aput-byte v11, v12, v14

    const/16 v11, 0x37

    const/4 v14, 0x6

    aput-byte v11, v12, v14

    const/16 v11, -0x7b

    const/4 v14, 0x7

    aput-byte v11, v12, v14

    invoke-static {v6, v12}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v3, v4, v6}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/16 v4, 0x8

    new-array v6, v4, [B

    aput-byte v18, v6, v7

    const/4 v4, -0x7

    aput-byte v4, v6, v8

    const/16 v4, 0x51

    aput-byte v4, v6, v9

    aput-byte v7, v6, v10

    const/16 v4, 0x56

    const/4 v11, 0x4

    aput-byte v4, v6, v11

    const/16 v4, 0x21

    const/4 v11, 0x5

    aput-byte v4, v6, v11

    const/16 v4, -0x73

    const/4 v11, 0x6

    aput-byte v4, v6, v11

    const/16 v4, -0x2e

    const/4 v11, 0x7

    aput-byte v4, v6, v11

    const/16 v4, 0x8

    new-array v11, v4, [B

    const/16 v4, 0x75

    aput-byte v4, v11, v7

    const/16 v4, -0x2c

    aput-byte v4, v11, v8

    const/16 v4, 0x21

    aput-byte v4, v11, v9

    const/16 v4, 0x61

    aput-byte v4, v11, v10

    const/16 v4, 0x38

    const/4 v12, 0x4

    aput-byte v4, v11, v12

    const/16 v4, 0xc

    const/4 v12, 0x5

    aput-byte v4, v11, v12

    const/4 v4, -0x7

    const/4 v12, 0x6

    aput-byte v4, v11, v12

    const/16 v4, -0x41

    const/4 v12, 0x7

    aput-byte v4, v11, v12

    invoke-static {v6, v11}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/16 v2, 0xb

    new-array v4, v2, [B

    const/4 v2, -0x6

    aput-byte v2, v4, v7

    const/16 v2, 0x54

    aput-byte v2, v4, v8

    const/16 v2, -0x72

    aput-byte v2, v4, v9

    const/16 v2, -0x60

    aput-byte v2, v4, v10

    const/4 v2, -0x1

    const/4 v6, 0x4

    aput-byte v2, v4, v6

    const/16 v2, -0x3b

    const/4 v6, 0x5

    aput-byte v2, v4, v6

    const/16 v2, 0x4a

    const/4 v6, 0x6

    aput-byte v2, v4, v6

    const/4 v2, 0x7

    aput-byte v28, v4, v2

    const/16 v2, -0x17

    const/16 v6, 0x8

    aput-byte v2, v4, v6

    const/16 v2, 0x9

    aput-byte v17, v4, v2

    const/16 v2, 0xa

    aput-byte v33, v4, v2

    new-array v2, v6, [B

    const/16 v6, -0x7e

    aput-byte v6, v2, v7

    const/16 v6, 0x79

    aput-byte v6, v2, v8

    const/4 v6, -0x2

    aput-byte v6, v2, v9

    const/16 v6, -0x3f

    aput-byte v6, v2, v10

    const/16 v6, -0x6f

    const/4 v11, 0x4

    aput-byte v6, v2, v11

    const/16 v6, -0x18

    const/4 v11, 0x5

    aput-byte v6, v2, v11

    const/16 v6, 0x3e

    const/4 v11, 0x6

    aput-byte v6, v2, v11

    const/16 v6, 0x72

    const/4 v11, 0x7

    aput-byte v6, v2, v11

    invoke-static {v4, v2}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v3, v2, v13}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/16 v2, 0xc

    new-array v4, v2, [B

    const/16 v2, -0x61

    aput-byte v2, v4, v7

    const/16 v2, -0x3f

    aput-byte v2, v4, v8

    const/16 v2, 0x33

    aput-byte v2, v4, v9

    aput-byte v25, v4, v10

    const/4 v2, 0x4

    aput-byte v33, v4, v2

    const/4 v2, 0x5

    aput-byte v16, v4, v2

    const/16 v2, 0x71

    const/4 v6, 0x6

    aput-byte v2, v4, v6

    const/16 v2, -0x7d

    const/4 v6, 0x7

    aput-byte v2, v4, v6

    const/16 v2, -0x78

    const/16 v11, 0x8

    aput-byte v2, v4, v11

    const/16 v2, -0x29

    const/16 v12, 0x9

    aput-byte v2, v4, v12

    const/16 v2, 0x2d

    const/16 v12, 0xa

    aput-byte v2, v4, v12

    const/16 v2, 0xb

    aput-byte v6, v4, v2

    new-array v2, v11, [B

    const/4 v6, -0x4

    aput-byte v6, v2, v7

    const/16 v6, -0x52

    aput-byte v6, v2, v8

    const/16 v6, 0x5d

    aput-byte v6, v2, v9

    const/16 v6, 0x62

    aput-byte v6, v2, v10

    const/16 v6, -0xb

    const/4 v11, 0x4

    aput-byte v6, v2, v11

    const/16 v6, 0x75

    const/4 v11, 0x5

    aput-byte v6, v2, v11

    const/4 v6, 0x6

    aput-byte v11, v2, v6

    const/16 v6, -0x52

    const/4 v11, 0x7

    aput-byte v6, v2, v11

    invoke-static {v4, v2}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v2

    const/16 v4, 0x18

    new-array v6, v4, [B

    const/16 v4, -0xa

    aput-byte v4, v6, v7

    const/16 v4, 0x4d

    aput-byte v4, v6, v8

    const/16 v4, 0x5e

    aput-byte v4, v6, v9

    const/16 v4, -0x6c

    aput-byte v4, v6, v10

    const/4 v4, 0x4

    aput-byte v25, v6, v4

    const/16 v4, -0x13

    const/4 v11, 0x5

    aput-byte v4, v6, v11

    const/16 v4, 0x3c

    const/4 v11, 0x6

    aput-byte v4, v6, v11

    const/16 v4, 0x29

    const/4 v11, 0x7

    aput-byte v4, v6, v11

    const/16 v4, -0x15

    const/16 v11, 0x8

    aput-byte v4, v6, v11

    const/16 v4, 0x46

    const/16 v11, 0x9

    aput-byte v4, v6, v11

    const/16 v4, 0xa

    aput-byte v28, v6, v4

    const/16 v4, -0x7d

    const/16 v11, 0xb

    aput-byte v4, v6, v11

    const/16 v4, 0x51

    const/16 v11, 0xc

    aput-byte v4, v6, v11

    const/4 v4, -0x4

    aput-byte v4, v6, v18

    const/16 v4, 0x22

    const/16 v11, 0xe

    aput-byte v4, v6, v11

    const/16 v4, 0x3b

    const/16 v11, 0xf

    aput-byte v4, v6, v11

    const/16 v4, 0x10

    const/16 v11, -0x19

    aput-byte v11, v6, v4

    const/16 v4, 0x5c

    aput-byte v4, v6, v21

    aput-byte v16, v6, v22

    const/16 v4, 0x13

    const/16 v11, -0x4b

    aput-byte v11, v6, v4

    const/16 v4, 0x6d

    aput-byte v4, v6, v23

    const/16 v4, -0x25

    aput-byte v4, v6, v24

    const/16 v4, 0x7d

    aput-byte v4, v6, v25

    const/16 v4, 0x70

    const/16 v11, 0x17

    aput-byte v4, v6, v11

    const/16 v4, 0x8

    new-array v11, v4, [B

    const/16 v4, -0x7e

    aput-byte v4, v11, v7

    const/16 v4, 0x28

    aput-byte v4, v11, v8

    const/16 v4, 0x26

    aput-byte v4, v11, v9

    const/16 v4, -0x20

    aput-byte v4, v11, v10

    const/16 v4, 0x39

    const/4 v12, 0x4

    aput-byte v4, v11, v12

    const/16 v4, -0x63

    const/4 v12, 0x5

    aput-byte v4, v11, v12

    const/16 v4, 0x50

    const/4 v12, 0x6

    aput-byte v4, v11, v12

    const/16 v4, 0x48

    const/4 v12, 0x7

    aput-byte v4, v11, v12

    invoke-static {v6, v11}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v2, v4}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/16 v2, 0xf

    new-array v2, v2, [B

    const/16 v4, 0x54

    aput-byte v4, v2, v7

    const/16 v4, 0x59

    aput-byte v4, v2, v8

    const/16 v4, 0x7b

    aput-byte v4, v2, v9

    const/16 v4, 0x60

    aput-byte v4, v2, v10

    const/16 v4, -0x50

    const/4 v6, 0x4

    aput-byte v4, v2, v6

    const/4 v4, 0x5

    aput-byte v21, v2, v4

    const/16 v4, 0x3e

    const/4 v6, 0x6

    aput-byte v4, v2, v6

    const/16 v4, 0x18

    const/4 v6, 0x7

    aput-byte v4, v2, v6

    const/16 v4, 0x45

    const/16 v6, 0x8

    aput-byte v4, v2, v6

    const/16 v4, 0x9

    aput-byte v21, v2, v4

    const/16 v4, 0x65

    const/16 v6, 0xa

    aput-byte v4, v2, v6

    const/16 v4, 0x75

    const/16 v6, 0xb

    aput-byte v4, v2, v6

    const/16 v4, -0xd

    const/16 v6, 0xc

    aput-byte v4, v2, v6

    const/16 v4, 0x55

    aput-byte v4, v2, v18

    const/16 v4, 0x39

    const/16 v6, 0xe

    aput-byte v4, v2, v6

    const/16 v4, 0x8

    new-array v6, v4, [B

    aput-byte v35, v6, v7

    const/16 v4, 0x74

    aput-byte v4, v6, v8

    const/16 v4, 0xb

    aput-byte v4, v6, v9

    aput-byte v8, v6, v10

    const/16 v4, -0x22

    const/4 v11, 0x4

    aput-byte v4, v6, v11

    const/16 v4, 0x3c

    const/4 v11, 0x5

    aput-byte v4, v6, v11

    const/16 v4, 0x5d

    const/4 v11, 0x6

    aput-byte v4, v6, v11

    const/16 v4, 0x74

    const/4 v11, 0x7

    aput-byte v4, v6, v11

    invoke-static {v2, v6}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v3, v2, v5}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    invoke-static {v1, v3}, Lcom/github/catvod/spider/appysv2/n/c;->m(Ljava/lang/String;Ljava/util/Map;)Ljava/lang/String;

    move-result-object v1

    new-instance v2, Lorg/json/JSONObject;

    invoke-direct {v2, v1}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    const/4 v1, 0x6

    new-array v3, v1, [B

    aput-byte v7, v3, v7

    const/16 v1, -0x49

    aput-byte v1, v3, v8

    const/16 v1, -0x3a

    aput-byte v1, v3, v9

    const/16 v1, -0x2a

    aput-byte v1, v3, v10

    const/16 v1, -0x71

    const/4 v4, 0x4

    aput-byte v1, v3, v4

    const/16 v1, -0x9

    const/4 v4, 0x5

    aput-byte v1, v3, v4

    const/16 v1, 0x8

    new-array v4, v1, [B

    const/16 v1, 0x73

    aput-byte v1, v4, v7

    const/16 v1, -0x3d

    aput-byte v1, v4, v8

    const/16 v1, -0x59

    aput-byte v1, v4, v9

    const/16 v1, -0x5e

    aput-byte v1, v4, v10

    const/4 v1, -0x6

    const/4 v5, 0x4

    aput-byte v1, v4, v5

    const/16 v1, -0x7c

    const/4 v5, 0x5

    aput-byte v1, v4, v5

    const/4 v1, -0x1

    const/4 v5, 0x6

    aput-byte v1, v4, v5

    const/16 v1, 0x24

    const/4 v5, 0x7

    aput-byte v1, v4, v5

    invoke-static {v3, v4}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v2, v1}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;)I

    move-result v1

    if-eqz v1, :cond_1155

    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    return-object v1

    :cond_1155
    const/4 v1, 0x4

    new-array v3, v1, [B

    const/16 v1, 0x47

    aput-byte v1, v3, v7

    aput-byte v35, v3, v8

    const/16 v1, -0x11

    aput-byte v1, v3, v9

    const/16 v1, -0x5e

    aput-byte v1, v3, v10

    const/16 v1, 0x8

    new-array v4, v1, [B

    const/16 v1, 0x23

    aput-byte v1, v4, v7

    const/16 v1, 0x4d

    aput-byte v1, v4, v8

    const/16 v1, -0x65

    aput-byte v1, v4, v9

    const/16 v1, -0x3d

    aput-byte v1, v4, v10

    const/4 v1, -0x3

    const/4 v5, 0x4

    aput-byte v1, v4, v5

    const/16 v1, -0x4c

    const/4 v5, 0x5

    aput-byte v1, v4, v5

    const/16 v1, -0x35

    const/4 v5, 0x6

    aput-byte v1, v4, v5

    const/16 v1, -0x45

    const/4 v5, 0x7

    aput-byte v1, v4, v5

    invoke-static {v3, v4}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v2, v1}, Lorg/json/JSONObject;->optJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v1

    const/16 v2, 0xa

    new-array v3, v2, [B

    const/16 v2, -0x62

    aput-byte v2, v3, v7

    const/16 v2, -0x23

    aput-byte v2, v3, v8

    const/16 v2, -0x7d

    aput-byte v2, v3, v9

    const/16 v2, -0x21

    aput-byte v2, v3, v10

    const/16 v2, -0x76

    const/4 v4, 0x4

    aput-byte v2, v3, v4

    const/16 v2, -0x7d

    const/4 v4, 0x5

    aput-byte v2, v3, v4

    const/16 v2, -0x5f

    const/4 v4, 0x6

    aput-byte v2, v3, v4

    const/16 v2, 0x40

    const/4 v4, 0x7

    aput-byte v2, v3, v4

    const/16 v2, -0x72

    const/16 v4, 0x8

    aput-byte v2, v3, v4

    const/16 v2, -0x25

    const/16 v5, 0x9

    aput-byte v2, v3, v5

    new-array v2, v4, [B

    const/16 v4, -0x18

    aput-byte v4, v2, v7

    const/16 v4, -0x4c

    aput-byte v4, v2, v8

    const/16 v4, -0x19

    aput-byte v4, v2, v9

    const/16 v4, -0x46

    aput-byte v4, v2, v10

    const/16 v4, -0x1b

    const/4 v5, 0x4

    aput-byte v4, v2, v5

    const/16 v4, -0x24

    const/4 v5, 0x5

    aput-byte v4, v2, v5

    const/16 v4, -0x38

    const/4 v5, 0x6

    aput-byte v4, v2, v5

    const/16 v4, 0x2e

    const/4 v5, 0x7

    aput-byte v4, v2, v5

    invoke-static {v3, v2}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Lorg/json/JSONObject;->optJSONArray(Ljava/lang/String;)Lorg/json/JSONArray;

    move-result-object v1

    new-instance v2, Ljava/util/ArrayList;

    invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V

    const/4 v3, 0x0

    :goto_11fd
    invoke-virtual {v1}, Lorg/json/JSONArray;->length()I

    move-result v4

    if-ge v3, v4, :cond_1330

    invoke-virtual {v1, v3}, Lorg/json/JSONArray;->optJSONObject(I)Lorg/json/JSONObject;

    move-result-object v4

    const/16 v5, 0xa

    new-array v6, v5, [B

    const/16 v5, -0x6b

    aput-byte v5, v6, v7

    const/16 v5, 0x7b

    aput-byte v5, v6, v8

    const/16 v5, 0x41

    aput-byte v5, v6, v9

    const/16 v5, 0x1e

    aput-byte v5, v6, v10

    const/4 v5, 0x4

    aput-byte v22, v6, v5

    const/4 v5, 0x5

    aput-byte v33, v6, v5

    const/16 v5, -0x46

    const/4 v11, 0x6

    aput-byte v5, v6, v11

    const/4 v5, -0x2

    const/4 v11, 0x7

    aput-byte v5, v6, v11

    const/16 v5, -0x68

    const/16 v11, 0x8

    aput-byte v5, v6, v11

    const/16 v5, 0x7d

    const/16 v12, 0x9

    aput-byte v5, v6, v12

    new-array v5, v11, [B

    const/16 v11, -0xc

    aput-byte v11, v5, v7

    const/16 v11, 0x18

    aput-byte v11, v5, v8

    const/16 v12, 0x22

    aput-byte v12, v5, v9

    const/16 v12, 0x7b

    aput-byte v12, v5, v10

    const/16 v12, 0x61

    const/4 v13, 0x4

    aput-byte v12, v5, v13

    const/16 v12, -0x1d

    const/4 v13, 0x5

    aput-byte v12, v5, v13

    const/16 v12, -0x25

    const/4 v13, 0x6

    aput-byte v12, v5, v13

    const/16 v12, -0x64

    const/4 v13, 0x7

    aput-byte v12, v5, v13

    invoke-static {v6, v5}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;)I

    move-result v5

    if-eq v5, v8, :cond_127a

    const/16 v6, 0xa

    const/16 v12, 0xe

    const/16 v13, 0x8

    const/16 v15, 0x9

    const/16 v16, 0x26

    const/16 v17, 0x4

    const/16 v19, 0x5

    const/16 v20, 0x6

    const/16 v21, 0x7

    goto/16 :goto_132c

    :cond_127a
    iget-object v5, v0, Lcom/github/catvod/spider/appysv2/b/U;->g:Ljava/util/HashMap;

    const/16 v6, 0xa

    new-array v12, v6, [B

    const/16 v13, 0x59

    aput-byte v13, v12, v7

    const/16 v13, 0x42

    aput-byte v13, v12, v8

    const/16 v13, -0x5a

    aput-byte v13, v12, v9

    const/16 v13, 0x27

    aput-byte v13, v12, v10

    const/4 v13, 0x4

    aput-byte v25, v12, v13

    const/16 v13, -0x4d

    const/4 v14, 0x5

    aput-byte v13, v12, v14

    const/4 v13, 0x6

    aput-byte v33, v12, v13

    const/16 v13, -0x62

    const/4 v14, 0x7

    aput-byte v13, v12, v14

    const/16 v13, 0x44

    const/16 v14, 0x8

    aput-byte v13, v12, v14

    const/16 v13, 0x49

    const/16 v15, 0x9

    aput-byte v13, v12, v15

    new-array v13, v14, [B

    const/16 v14, 0x2b

    aput-byte v14, v13, v7

    const/16 v14, 0x27

    aput-byte v14, v13, v8

    const/16 v14, -0x2b

    aput-byte v14, v13, v9

    const/16 v14, 0x48

    aput-byte v14, v13, v10

    const/16 v14, 0x7a

    const/16 v16, 0x4

    aput-byte v14, v13, v16

    const/16 v14, -0x3a

    const/16 v16, 0x5

    aput-byte v14, v13, v16

    const/16 v14, -0x1c

    const/16 v16, 0x6

    aput-byte v14, v13, v16

    const/16 v14, -0x9

    const/16 v16, 0x7

    aput-byte v14, v13, v16

    invoke-static {v12, v13}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v12

    invoke-virtual {v4, v12}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v12

    invoke-virtual {v5, v12}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/lang/String;

    invoke-virtual {v2, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    new-array v5, v10, [B

    const/16 v12, 0x5e

    aput-byte v12, v5, v7

    const/16 v12, 0x29

    aput-byte v12, v5, v8

    const/16 v12, 0xe

    aput-byte v12, v5, v9

    const/16 v13, 0x8

    new-array v14, v13, [B

    const/16 v16, 0x2b

    aput-byte v16, v14, v7

    const/16 v16, 0x5b

    aput-byte v16, v14, v8

    const/16 v16, 0x62

    aput-byte v16, v14, v9

    const/16 v16, -0x2a

    aput-byte v16, v14, v10

    const/16 v16, 0x26

    const/16 v17, 0x4

    aput-byte v16, v14, v17

    const/16 v18, 0x3e

    const/16 v19, 0x5

    aput-byte v18, v14, v19

    const/16 v18, 0x43

    const/16 v20, 0x6

    aput-byte v18, v14, v20

    const/16 v18, -0xb

    const/16 v21, 0x7

    aput-byte v18, v14, v21

    invoke-static {v5, v14}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v2, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    :try_end_132c
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_132c} :catch_1331

    :goto_132c
    add-int/lit8 v3, v3, 0x1

    goto/16 :goto_11fd

    :cond_1330
    return-object v2

    :catch_1331
    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    return-object v1
.end method
