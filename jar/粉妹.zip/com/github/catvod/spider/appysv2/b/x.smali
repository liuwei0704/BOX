.class public final Lcom/github/catvod/spider/appysv2/b/x;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field private final a:Ljava/util/HashMap;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;>;"
        }
    .end annotation
.end field

.field private final b:Ljava/util/HashMap;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field private final c:Ljava/util/HashMap;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field private final d:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field private final e:Ljava/util/concurrent/locks/ReentrantLock;

.field private final f:Lcom/github/catvod/spider/appysv2/d/c;

.field private g:Ljava/util/concurrent/ScheduledExecutorService;

.field private h:Ljava/lang/String;

.field private i:Landroid/app/AlertDialog;

.field private j:Lcom/github/catvod/spider/appysv2/d/o;


# direct methods
.method constructor <init>()V
    .registers 3

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    invoke-static {}, Lcom/github/catvod/spider/Init;->checkPermission()V

    new-instance v0, Ljava/util/concurrent/locks/ReentrantLock;

    invoke-direct {v0}, Ljava/util/concurrent/locks/ReentrantLock;-><init>()V

    iput-object v0, p0, Lcom/github/catvod/spider/appysv2/b/x;->e:Ljava/util/concurrent/locks/ReentrantLock;

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lcom/github/catvod/spider/appysv2/b/x;->d:Ljava/util/ArrayList;

    new-instance v0, Ljava/util/HashMap;

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    iput-object v0, p0, Lcom/github/catvod/spider/appysv2/b/x;->c:Ljava/util/HashMap;

    new-instance v0, Ljava/util/HashMap;

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    iput-object v0, p0, Lcom/github/catvod/spider/appysv2/b/x;->a:Ljava/util/HashMap;

    new-instance v0, Ljava/util/HashMap;

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    iput-object v0, p0, Lcom/github/catvod/spider/appysv2/b/x;->b:Ljava/util/HashMap;

    invoke-virtual {p0}, Lcom/github/catvod/spider/appysv2/b/x;->q()Ljava/io/File;

    move-result-object v0

    invoke-static {v0}, Lcom/github/catvod/spider/appysv2/p/a;->k(Ljava/io/File;)Ljava/lang/String;

    move-result-object v0

    .line 2
    const-class v1, Lcom/github/catvod/spider/appysv2/d/c;

    .line 3
    invoke-static {v0, v1}, Lcom/github/catvod/spider/appysv2/b/s;->a(Ljava/lang/String;Ljava/lang/Class;)Ljava/lang/Object;

    move-result-object v0

    .line 4
    check-cast v0, Lcom/github/catvod/spider/appysv2/d/c;

    if-nez v0, :cond_40

    new-instance v0, Lcom/github/catvod/spider/appysv2/d/c;

    invoke-direct {v0}, Lcom/github/catvod/spider/appysv2/d/c;-><init>()V

    .line 5
    :cond_40
    iput-object v0, p0, Lcom/github/catvod/spider/appysv2/b/x;->f:Lcom/github/catvod/spider/appysv2/d/c;

    return-void
.end method

.method private static A(Ljava/lang/String;)Z
    .registers 9

    new-instance v0, Landroid/net/UrlQuerySanitizer;

    invoke-direct {v0, p0}, Landroid/net/UrlQuerySanitizer;-><init>(Ljava/lang/String;)V

    const/16 p0, 0xd

    new-array p0, p0, [B

    fill-array-data p0, :array_38

    const/16 v1, 0x8

    new-array v1, v1, [B

    fill-array-data v1, :array_44

    invoke-static {p0, v1}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object p0

    invoke-virtual {v0, p0}, Landroid/net/UrlQuerySanitizer;->getValue(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    invoke-static {p0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v1, 0x0

    if-eqz v0, :cond_23

    return v1

    :cond_23
    invoke-static {p0}, Ljava/lang/Long;->parseLong(Ljava/lang/String;)J

    move-result-wide v2

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v4

    const-wide/16 v6, 0x3e8

    div-long/2addr v4, v6

    sub-long/2addr v2, v4

    const-wide/16 v4, 0x3c

    cmp-long p0, v2, v4

    if-gtz p0, :cond_36

    const/4 v1, 0x1

    :cond_36
    return v1

    nop

    :array_38
    .array-data 1
        0x7at
        -0x25t
        0x7bt
        -0x51t
        -0x39t
        0x57t
        -0x15t
        0x17t
        0x72t
        -0x61t
        0x66t
        -0x47t
        -0x39t
    .end array-data

    nop

    :array_44
    .array-data 1
        0x2t
        -0xat
        0x14t
        -0x24t
        -0x4ct
        0x7at
        -0x72t
        0x6ft
    .end array-data
.end method

.method private B(Ljava/lang/String;Lcom/github/catvod/spider/appysv2/d/h;Ljava/util/List;Ljava/util/List;)V
    .registers 11
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Lcom/github/catvod/spider/appysv2/d/h;",
            "Ljava/util/List<",
            "Lcom/github/catvod/spider/appysv2/d/h;",
            ">;",
            "Ljava/util/List<",
            "Lcom/github/catvod/spider/appysv2/d/h;",
            ">;)V"
        }
    .end annotation

    const-string v5, ""

    move-object v0, p0

    move-object v1, p1

    move-object v2, p2

    move-object v3, p3

    move-object v4, p4

    invoke-direct/range {v0 .. v5}, Lcom/github/catvod/spider/appysv2/b/x;->C(Ljava/lang/String;Lcom/github/catvod/spider/appysv2/d/h;Ljava/util/List;Ljava/util/List;Ljava/lang/String;)V

    return-void
.end method

.method private C(Ljava/lang/String;Lcom/github/catvod/spider/appysv2/d/h;Ljava/util/List;Ljava/util/List;Ljava/lang/String;)V
    .registers 15
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Lcom/github/catvod/spider/appysv2/d/h;",
            "Ljava/util/List<",
            "Lcom/github/catvod/spider/appysv2/d/h;",
            ">;",
            "Ljava/util/List<",
            "Lcom/github/catvod/spider/appysv2/d/h;",
            ">;",
            "Ljava/lang/String;",
            ")V"
        }
    .end annotation

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    new-instance v1, Lcom/google/gson/JsonObject;

    invoke-direct {v1}, Lcom/google/gson/JsonObject;-><init>()V

    const/4 v2, 0x5

    new-array v3, v2, [B

    fill-array-data v3, :array_16c

    const/16 v4, 0x8

    new-array v5, v4, [B

    fill-array-data v5, :array_174

    invoke-static {v3, v5}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v3

    const/16 v5, 0xc8

    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    invoke-virtual {v1, v3, v5}, Lcom/google/gson/JsonObject;->addProperty(Ljava/lang/String;Ljava/lang/Number;)V

    new-array v3, v4, [B

    fill-array-data v3, :array_17c

    new-array v5, v4, [B

    fill-array-data v5, :array_184

    invoke-static {v3, v5}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v1, v3, p1}, Lcom/google/gson/JsonObject;->addProperty(Ljava/lang/String;Ljava/lang/String;)V

    const/16 v3, 0xe

    new-array v3, v3, [B

    fill-array-data v3, :array_18c

    new-array v5, v4, [B

    fill-array-data v5, :array_198

    invoke-static {v3, v5}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {p2}, Lcom/github/catvod/spider/appysv2/d/h;->d()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v1, v3, v5}, Lcom/google/gson/JsonObject;->addProperty(Ljava/lang/String;Ljava/lang/String;)V

    new-array v3, v4, [B

    fill-array-data v3, :array_1a0

    new-array v5, v4, [B

    fill-array-data v5, :array_1a8

    invoke-static {v3, v5}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v3

    const/4 v5, 0x4

    new-array v5, v5, [B

    fill-array-data v5, :array_1b0

    new-array v6, v4, [B

    fill-array-data v6, :array_1b6

    invoke-static {v5, v6}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v1, v3, v5}, Lcom/google/gson/JsonObject;->addProperty(Ljava/lang/String;Ljava/lang/String;)V

    const/16 v3, 0xf

    new-array v3, v3, [B

    fill-array-data v3, :array_1be

    new-array v5, v4, [B

    fill-array-data v5, :array_1ca

    invoke-static {v3, v5}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v3

    const/4 v5, 0x3

    new-array v5, v5, [B

    fill-array-data v5, :array_1d2

    new-array v6, v4, [B

    fill-array-data v6, :array_1d8

    invoke-static {v5, v6}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v1, v3, v5}, Lcom/google/gson/JsonObject;->addProperty(Ljava/lang/String;Ljava/lang/String;)V

    invoke-virtual {p5}, Ljava/lang/String;->length()I

    move-result v3

    const/4 v5, 0x6

    if-lez v3, :cond_a6

    new-array v3, v5, [B

    fill-array-data v3, :array_1e0

    new-array v6, v4, [B

    fill-array-data v6, :array_1e8

    invoke-static {v3, v6}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v1, v3, p5}, Lcom/google/gson/JsonObject;->addProperty(Ljava/lang/String;Ljava/lang/String;)V

    :cond_a6
    const/16 p5, 0x13

    new-array p5, p5, [B

    fill-array-data p5, :array_1f0

    new-array v3, v4, [B

    fill-array-data v3, :array_1fe

    invoke-static {p5, v3}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object p5

    invoke-virtual {v1}, Lcom/google/gson/JsonElement;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v3, 0x1

    invoke-direct {p0, p5, v1, v3}, Lcom/github/catvod/spider/appysv2/b/x;->m(Ljava/lang/String;Ljava/lang/String;Z)Ljava/lang/String;

    move-result-object p5

    .line 1
    const-class v1, Lcom/github/catvod/spider/appysv2/d/h;

    .line 2
    invoke-static {p5, v1}, Lcom/github/catvod/spider/appysv2/b/s;->a(Ljava/lang/String;Ljava/lang/Class;)Ljava/lang/Object;

    move-result-object p5

    .line 3
    check-cast p5, Lcom/github/catvod/spider/appysv2/d/h;

    .line 4
    invoke-virtual {p5}, Lcom/github/catvod/spider/appysv2/d/h;->e()Ljava/util/List;

    move-result-object v1

    invoke-interface {v1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :cond_cf
    :goto_cf
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_141

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lcom/github/catvod/spider/appysv2/d/h;

    invoke-virtual {v3}, Lcom/github/catvod/spider/appysv2/d/h;->j()Ljava/lang/String;

    move-result-object v6

    new-array v7, v5, [B

    fill-array-data v7, :array_206

    new-array v8, v4, [B

    fill-array-data v8, :array_20e

    invoke-static {v7, v8}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v6, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_f7

    invoke-virtual {v0, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_cf

    :cond_f7
    invoke-virtual {v3}, Lcom/github/catvod/spider/appysv2/d/h;->a()Ljava/lang/String;

    move-result-object v6

    new-array v7, v2, [B

    fill-array-data v7, :array_216

    new-array v8, v4, [B

    fill-array-data v8, :array_21e

    invoke-static {v7, v8}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v6, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v6

    if-nez v6, :cond_136

    invoke-virtual {v3}, Lcom/github/catvod/spider/appysv2/d/h;->a()Ljava/lang/String;

    move-result-object v6

    new-array v7, v2, [B

    fill-array-data v7, :array_226

    new-array v8, v4, [B

    fill-array-data v8, :array_22e

    invoke-static {v7, v8}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v6, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_128

    goto :goto_136

    :cond_128
    invoke-virtual {v3}, Lcom/github/catvod/spider/appysv2/d/h;->c()Ljava/lang/String;

    move-result-object v6

    invoke-static {v6}, Lcom/github/catvod/spider/appysv2/p/C;->n(Ljava/lang/String;)Z

    move-result v6

    if-eqz v6, :cond_cf

    invoke-interface {p4, v3}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    goto :goto_cf

    :cond_136
    :goto_136
    invoke-virtual {p2}, Lcom/github/catvod/spider/appysv2/d/h;->f()Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v3, v6}, Lcom/github/catvod/spider/appysv2/d/h;->k(Ljava/lang/String;)Lcom/github/catvod/spider/appysv2/d/h;

    invoke-interface {p3, v3}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    goto :goto_cf

    :cond_141
    invoke-virtual {p5}, Lcom/github/catvod/spider/appysv2/d/h;->g()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/String;->length()I

    move-result v1

    if-lez v1, :cond_157

    invoke-virtual {p5}, Lcom/github/catvod/spider/appysv2/d/h;->g()Ljava/lang/String;

    move-result-object v7

    move-object v2, p0

    move-object v3, p1

    move-object v4, p2

    move-object v5, p3

    move-object v6, p4

    invoke-direct/range {v2 .. v7}, Lcom/github/catvod/spider/appysv2/b/x;->C(Ljava/lang/String;Lcom/github/catvod/spider/appysv2/d/h;Ljava/util/List;Ljava/util/List;Ljava/lang/String;)V

    :cond_157
    invoke-virtual {v0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object p2

    :goto_15b
    invoke-interface {p2}, Ljava/util/Iterator;->hasNext()Z

    move-result p5

    if-eqz p5, :cond_16b

    invoke-interface {p2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object p5

    check-cast p5, Lcom/github/catvod/spider/appysv2/d/h;

    invoke-direct {p0, p1, p5, p3, p4}, Lcom/github/catvod/spider/appysv2/b/x;->B(Ljava/lang/String;Lcom/github/catvod/spider/appysv2/d/h;Ljava/util/List;Ljava/util/List;)V

    goto :goto_15b

    :cond_16b
    return-void

    :array_16c
    .array-data 1
        -0x42t
        -0x5at
        -0x78t
        -0xdt
        0x18t
    .end array-data

    nop

    :array_174
    .array-data 1
        -0x2et
        -0x31t
        -0x1bt
        -0x66t
        0x6ct
        0x3bt
        -0x19t
        0x6et
    .end array-data

    :array_17c
    .array-data 1
        -0x64t
        0x64t
        0x74t
        0x39t
        0x5bt
        -0x57t
        0x3ft
        0x71t
    .end array-data

    :array_184
    .array-data 1
        -0x11t
        0xct
        0x15t
        0x4bt
        0x3et
        -0xat
        0x56t
        0x15t
    .end array-data

    :array_18c
    .array-data 1
        0x4ft
        -0x29t
        -0xbt
        -0x14t
        0x2et
        -0x4ct
        0x6ft
        0x5et
        0x56t
        -0x26t
        -0x1et
        -0x2at
        0x29t
        -0x5ct
    .end array-data

    nop

    :array_198
    .array-data 1
        0x3ft
        -0x4at
        -0x79t
        -0x77t
        0x40t
        -0x40t
        0x30t
        0x38t
    .end array-data

    :array_1a0
    .array-data 1
        0x35t
        0x73t
        0xdt
        -0x50t
        -0x34t
        0x15t
        -0x1bt
        0x53t
    .end array-data

    :array_1a8
    .array-data 1
        0x5at
        0x1t
        0x69t
        -0x2bt
        -0x42t
        0x4at
        -0x79t
        0x2at
    .end array-data

    :array_1b0
    .array-data 1
        -0x7ct
        -0x3et
        0x58t
        0x6ft
    .end array-data

    :array_1b6
    .array-data 1
        -0x16t
        -0x5dt
        0x35t
        0xat
        -0x36t
        -0x1ft
        0x1dt
        0x40t
    .end array-data

    :array_1be
    .array-data 1
        0xft
        -0xft
        0xbt
        -0x47t
        0x62t
        0x3ft
        -0x57t
        0x77t
        0x12t
        -0x1at
        0xct
        -0x58t
        0x79t
        0xft
        -0x5dt
    .end array-data

    :array_1ca
    .array-data 1
        0x60t
        -0x7dt
        0x6ft
        -0x24t
        0x10t
        0x60t
        -0x33t
        0x1et
    .end array-data

    :array_1d2
    .array-data 1
        0x35t
        -0x14t
        -0xat
    .end array-data

    :array_1d8
    .array-data 1
        0x74t
        -0x41t
        -0x4bt
        0x75t
        -0x20t
        -0x28t
        0x6bt
        0x49t
    .end array-data

    :array_1e0
    .array-data 1
        0x56t
        0x5ft
        -0x5ct
        -0x7at
        0x2bt
        -0x3bt
    .end array-data

    nop

    :array_1e8
    .array-data 1
        0x3bt
        0x3et
        -0x2at
        -0x13t
        0x4et
        -0x49t
        -0x1ft
        0x65t
    .end array-data

    :array_1f0
    .array-data 1
        0x3bt
        0x77t
        -0x4bt
        0x6dt
        -0x41t
        0x1dt
        -0x3at
        -0x2ct
        0x69t
        0x3ct
        -0x5ft
        0x6dt
        -0x5bt
        0x1dt
        -0x3at
        -0x32t
        0x33t
        0x60t
        -0x4dt
    .end array-data

    :array_1fe
    .array-data 1
        0x5at
        0x13t
        -0x39t
        0x4t
        -0x37t
        0x78t
        -0x17t
        -0x5et
    .end array-data

    :array_206
    .array-data 1
        0x5bt
        0x29t
        0x41t
        -0x29t
        -0x3ft
        0x65t
    .end array-data

    nop

    :array_20e
    .array-data 1
        0x3dt
        0x46t
        0x2dt
        -0x4dt
        -0x5ct
        0x17t
        -0x5bt
        0x18t
    .end array-data

    :array_216
    .array-data 1
        -0x50t
        -0x53t
        0x21t
        0x69t
        0x58t
    .end array-data

    nop

    :array_21e
    .array-data 1
        -0x3at
        -0x3ct
        0x45t
        0xct
        0x37t
        0x30t
        -0xbt
        0x3et
    .end array-data

    :array_226
    .array-data 1
        -0x56t
        0x7bt
        0x23t
        -0x72t
        -0x42t
    .end array-data

    nop

    :array_22e
    .array-data 1
        -0x35t
        0xet
        0x47t
        -0x19t
        -0x2ft
        0x48t
        -0x37t
        0x55t
    .end array-data
.end method

.method private D(Ljava/lang/String;Ljava/lang/String;Z)Ljava/lang/String;
    .registers 13

    const/4 v0, 0x5

    new-array v1, v0, [B

    fill-array-data v1, :array_1f4

    const/16 v2, 0x8

    new-array v3, v2, [B

    fill-array-data v3, :array_1fc

    invoke-static {v1, v3}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {p1, v1}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_18

    goto :goto_2d

    :cond_18
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/16 v3, 0x29

    new-array v3, v3, [B

    fill-array-data v3, :array_204

    new-array v4, v2, [B

    fill-array-data v4, :array_21e

    .line 1
    invoke-static {v3, v4, v1, p1}, Lcom/github/catvod/spider/appysv2/b/u;->a([B[BLjava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    .line 2
    :goto_2d
    invoke-virtual {p0}, Lcom/github/catvod/spider/appysv2/b/x;->s()Ljava/util/HashMap;

    move-result-object v1

    const/16 v3, 0xd

    new-array v4, v3, [B

    fill-array-data v4, :array_226

    new-array v5, v2, [B

    fill-array-data v5, :array_232

    invoke-static {v4, v5}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v4

    iget-object v5, p0, Lcom/github/catvod/spider/appysv2/b/x;->f:Lcom/github/catvod/spider/appysv2/d/c;

    invoke-virtual {v5}, Lcom/github/catvod/spider/appysv2/d/c;->b()Lcom/github/catvod/spider/appysv2/d/i;

    move-result-object v5

    invoke-virtual {v5}, Lcom/github/catvod/spider/appysv2/d/i;->b()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v1, v4, v5}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 3
    invoke-static {p1, p2, v1}, Lcom/github/catvod/spider/appysv2/n/c;->g(Ljava/lang/String;Ljava/lang/String;Ljava/util/Map;)Lcom/github/catvod/spider/appysv2/n/e;

    move-result-object v1

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v1}, Lcom/github/catvod/spider/appysv2/n/e;->b()I

    move-result v5

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v5, 0x1

    new-array v6, v5, [B

    const/16 v7, -0x22

    const/4 v8, 0x0

    aput-byte v7, v6, v8

    new-array v7, v2, [B

    fill-array-data v7, :array_23a

    .line 4
    invoke-static {v6, v7, v4, p1}, Lcom/github/catvod/spider/appysv2/b/v;->c([B[BLjava/lang/StringBuilder;Ljava/lang/String;)V

    new-array v6, v5, [B

    const/16 v7, -0x55

    aput-byte v7, v6, v8

    new-array v7, v2, [B

    .line 5
    fill-array-data v7, :array_242

    invoke-static {v6, v7}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v4, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Lcom/github/catvod/spider/appysv2/n/e;->a()Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v4, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-static {v4}, Lcom/github/catvod/crawler/SpiderDebug;->log(Ljava/lang/String;)V

    if-eqz p3, :cond_1ef

    invoke-virtual {v1}, Lcom/github/catvod/spider/appysv2/n/e;->b()I

    move-result p3

    const/16 v4, 0x190

    if-eq p3, v4, :cond_a0

    invoke-virtual {v1}, Lcom/github/catvod/spider/appysv2/n/e;->b()I

    move-result p3

    const/16 v4, 0x191

    if-ne p3, v4, :cond_1ef

    .line 6
    :cond_a0
    iget-object p3, p0, Lcom/github/catvod/spider/appysv2/b/x;->f:Lcom/github/catvod/spider/appysv2/d/c;

    invoke-virtual {p3}, Lcom/github/catvod/spider/appysv2/d/c;->b()Lcom/github/catvod/spider/appysv2/d/i;

    move-result-object p3

    invoke-virtual {p3}, Lcom/github/catvod/spider/appysv2/d/i;->c()Ljava/lang/String;

    move-result-object p3

    invoke-virtual {p3}, Ljava/lang/String;->isEmpty()Z

    move-result p3

    const/16 v4, 0xa

    if-eqz p3, :cond_184

    const/16 p3, 0x10

    new-array p3, p3, [B

    .line 7
    fill-array-data p3, :array_24a

    new-array v3, v2, [B

    fill-array-data v3, :array_256

    invoke-static {p3, v3}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object p3

    invoke-static {p3}, Lcom/github/catvod/crawler/SpiderDebug;->log(Ljava/lang/String;)V

    new-instance p3, Lcom/google/gson/JsonObject;

    invoke-direct {p3}, Lcom/google/gson/JsonObject;-><init>()V

    const/16 v3, 0x9

    new-array v3, v3, [B

    fill-array-data v3, :array_25e

    new-array v6, v2, [B

    fill-array-data v6, :array_268

    invoke-static {v3, v6}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v3

    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v6

    invoke-virtual {p3, v3, v6}, Lcom/google/gson/JsonObject;->addProperty(Ljava/lang/String;Ljava/lang/Number;)V

    new-array v0, v0, [B

    fill-array-data v0, :array_270

    new-array v3, v2, [B

    fill-array-data v3, :array_278

    invoke-static {v0, v3}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v0

    const/16 v3, 0x26

    new-array v3, v3, [B

    fill-array-data v3, :array_280

    new-array v6, v2, [B

    fill-array-data v6, :array_298

    invoke-static {v3, v6}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {p3, v0, v3}, Lcom/google/gson/JsonObject;->addProperty(Ljava/lang/String;Ljava/lang/String;)V

    const/16 v0, 0xcc

    new-array v0, v0, [B

    fill-array-data v0, :array_2a0

    new-array v3, v2, [B

    fill-array-data v3, :array_30a

    invoke-static {v0, v3}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p3}, Lcom/google/gson/JsonElement;->toString()Ljava/lang/String;

    move-result-object p3

    invoke-direct {p0, v0, p3, v5}, Lcom/github/catvod/spider/appysv2/b/x;->m(Ljava/lang/String;Ljava/lang/String;Z)Ljava/lang/String;

    move-result-object p3

    .line 8
    const-class v0, Lcom/github/catvod/spider/appysv2/d/d;

    .line 9
    invoke-static {p3, v0}, Lcom/github/catvod/spider/appysv2/b/s;->a(Ljava/lang/String;Ljava/lang/Class;)Ljava/lang/Object;

    move-result-object p3

    .line 10
    check-cast p3, Lcom/github/catvod/spider/appysv2/d/d;

    .line 11
    invoke-virtual {p3}, Lcom/github/catvod/spider/appysv2/d/d;->a()Ljava/lang/String;

    move-result-object p3

    const/16 v0, 0x11

    new-array v0, v0, [B

    .line 12
    fill-array-data v0, :array_312

    new-array v3, v2, [B

    fill-array-data v3, :array_320

    invoke-static {v0, v3}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lcom/github/catvod/crawler/SpiderDebug;->log(Ljava/lang/String;)V

    new-instance v0, Lcom/google/gson/JsonObject;

    invoke-direct {v0}, Lcom/google/gson/JsonObject;-><init>()V

    const/4 v3, 0x4

    new-array v5, v3, [B

    fill-array-data v5, :array_328

    new-array v6, v2, [B

    fill-array-data v6, :array_32e

    invoke-static {v5, v6}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v0, v5, p3}, Lcom/google/gson/JsonObject;->addProperty(Ljava/lang/String;Ljava/lang/String;)V

    new-array p3, v4, [B

    fill-array-data p3, :array_336

    new-array v4, v2, [B

    fill-array-data v4, :array_340

    invoke-static {p3, v4}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object p3

    const/16 v4, 0x12

    new-array v4, v4, [B

    fill-array-data v4, :array_348

    new-array v5, v2, [B

    fill-array-data v5, :array_356

    invoke-static {v4, v5}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v0, p3, v4}, Lcom/google/gson/JsonObject;->addProperty(Ljava/lang/String;Ljava/lang/String;)V

    new-array p3, v3, [B

    fill-array-data p3, :array_35e

    new-array v2, v2, [B

    fill-array-data v2, :array_364

    invoke-static {p3, v2}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object p3

    invoke-direct {p0, p3, v0}, Lcom/github/catvod/spider/appysv2/b/x;->l(Ljava/lang/String;Lcom/google/gson/JsonObject;)Z

    move-result p3

    goto :goto_1e8

    :cond_184
    const/16 p3, 0x13

    new-array p3, p3, [B

    .line 13
    fill-array-data p3, :array_36c

    new-array v5, v2, [B

    fill-array-data v5, :array_37a

    invoke-static {p3, v5}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object p3

    invoke-static {p3}, Lcom/github/catvod/crawler/SpiderDebug;->log(Ljava/lang/String;)V

    new-instance p3, Lcom/google/gson/JsonObject;

    invoke-direct {p3}, Lcom/google/gson/JsonObject;-><init>()V

    new-array v4, v4, [B

    fill-array-data v4, :array_382

    new-array v5, v2, [B

    fill-array-data v5, :array_38c

    invoke-static {v4, v5}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v4

    new-array v5, v3, [B

    fill-array-data v5, :array_394

    new-array v6, v2, [B

    fill-array-data v6, :array_3a0

    invoke-static {v5, v6}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {p3, v4, v5}, Lcom/google/gson/JsonObject;->addProperty(Ljava/lang/String;Ljava/lang/String;)V

    new-array v3, v3, [B

    fill-array-data v3, :array_3a8

    new-array v4, v2, [B

    fill-array-data v4, :array_3b4

    invoke-static {v3, v4}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v3

    iget-object v4, p0, Lcom/github/catvod/spider/appysv2/b/x;->f:Lcom/github/catvod/spider/appysv2/d/c;

    invoke-virtual {v4}, Lcom/github/catvod/spider/appysv2/d/c;->b()Lcom/github/catvod/spider/appysv2/d/i;

    move-result-object v4

    invoke-virtual {v4}, Lcom/github/catvod/spider/appysv2/d/i;->c()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {p3, v3, v4}, Lcom/google/gson/JsonObject;->addProperty(Ljava/lang/String;Ljava/lang/String;)V

    new-array v0, v0, [B

    fill-array-data v0, :array_3bc

    new-array v2, v2, [B

    fill-array-data v2, :array_3c4

    invoke-static {v0, v2}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-direct {p0, v0, p3}, Lcom/github/catvod/spider/appysv2/b/x;->l(Ljava/lang/String;Lcom/google/gson/JsonObject;)Z

    move-result p3

    :goto_1e8
    if-eqz p3, :cond_1ef

    .line 14
    invoke-direct {p0, p1, p2, v8}, Lcom/github/catvod/spider/appysv2/b/x;->D(Ljava/lang/String;Ljava/lang/String;Z)Ljava/lang/String;

    move-result-object p1

    return-object p1

    :cond_1ef
    invoke-virtual {v1}, Lcom/github/catvod/spider/appysv2/n/e;->a()Ljava/lang/String;

    move-result-object p1

    return-object p1

    :array_1f4
    .array-data 1
        -0x5bt
        -0x3dt
        0x3ct
        -0x6at
        0x2dt
    .end array-data

    nop

    :array_1fc
    .array-data 1
        -0x33t
        -0x49t
        0x48t
        -0x1at
        0x5et
        -0x18t
        0xct
        0x15t
    .end array-data

    :array_204
    .array-data 1
        0x54t
        -0x5et
        0x77t
        0x65t
        -0x3t
        -0x6dt
        0x7ct
        -0x70t
        0x53t
        -0x5at
        0x66t
        0x7bt
        -0x60t
        -0x38t
        0x3ft
        -0x2at
        0x45t
        -0x5dt
        0x6dt
        0x71t
        -0x4t
        -0x40t
        0x25t
        -0x26t
        0x12t
        -0x4bt
        0x6ct
        0x78t
        -0x5ft
        -0x38t
        0x37t
        -0x33t
        0x55t
        -0x60t
        0x66t
        0x3at
        -0x8t
        -0x68t
        0x7dt
        -0x71t
        0x13t
    .end array-data

    nop

    :array_21e
    .array-data 1
        0x3ct
        -0x2at
        0x3t
        0x15t
        -0x72t
        -0x57t
        0x53t
        -0x41t
    .end array-data

    :array_226
    .array-data 1
        -0x57t
        -0x6at
        -0x2bt
        0x37t
        -0x39t
        -0x7et
        -0x37t
        0x9t
        -0x57t
        -0x69t
        -0x38t
        0x30t
        -0x3at
    .end array-data

    nop

    :array_232
    .array-data 1
        -0x38t
        -0x1dt
        -0x5ft
        0x5ft
        -0x58t
        -0x10t
        -0x60t
        0x73t
    .end array-data

    :array_23a
    .array-data 1
        -0xet
        -0x4ft
        0x6bt
        -0x3t
        0x2dt
        -0x4dt
        -0x26t
        0x75t
    .end array-data

    :array_242
    .array-data 1
        -0x79t
        -0x2dt
        0x10t
        -0x6at
        -0x6et
        -0x7at
        -0xdt
        -0x25t
    .end array-data

    :array_24a
    .array-data 1
        0x76t
        -0x8t
        -0x51t
        -0x50t
        -0x4ct
        0x65t
        -0x5dt
        0x7ft
        0x48t
        -0x34t
        -0x41t
        -0x49t
        -0x58t
        0x6bt
        -0x21t
        0x34t
    .end array-data

    :array_256
    .array-data 1
        0x39t
        -0x47t
        -0x26t
        -0x3ct
        -0x24t
        0x45t
        -0xft
        0x1at
    .end array-data

    :array_25e
    .array-data 1
        -0x2bt
        0x4t
        -0x3ct
        -0x13t
        0x13t
        0x60t
        -0x32t
        -0x2et
        -0x2ft
    .end array-data

    nop

    :array_268
    .array-data 1
        -0x4ct
        0x71t
        -0x50t
        -0x7bt
        0x7ct
        0x12t
        -0x59t
        -0x58t
    .end array-data

    :array_270
    .array-data 1
        -0x1bt
        -0x28t
        0x2ct
        0x3at
        -0x7t
    .end array-data

    nop

    :array_278
    .array-data 1
        -0x6at
        -0x45t
        0x43t
        0x4at
        -0x64t
        -0x5et
        0x8t
        -0x10t
    .end array-data

    :array_280
    .array-data 1
        0x2bt
        -0x2at
        -0x2dt
        0x1dt
        -0x25t
        0x52t
        -0x65t
        -0x46t
        0x3bt
        -0x77t
        -0x30t
        0x6t
        -0x73t
        0x55t
        -0x40t
        -0x58t
        0x32t
        -0x37t
        -0x74t
        0x1dt
        -0x7ct
        0x51t
        -0x62t
        -0x1bt
        0x38t
        -0x34t
        -0x26t
        0xat
        -0x25t
        0x51t
        -0x6at
        -0x5bt
        0x64t
        -0x2et
        -0x3ct
        0x6t
        -0x6bt
        0x55t
    .end array-data

    nop

    :array_298
    .array-data 1
        0x5et
        -0x5bt
        -0x4at
        0x6ft
        -0x1ft
        0x30t
        -0x6t
        -0x37t
    .end array-data

    :array_2a0
    .array-data 1
        0x2bt
        0x2dt
        0x4et
        0x1ft
        -0x13t
        0x75t
        0x5et
        -0x10t
        0x2ct
        0x29t
        0x5ft
        0x1t
        -0x50t
        0x2et
        0x1dt
        -0x4at
        0x3at
        0x2ct
        0x54t
        0xbt
        -0x14t
        0x26t
        0x7t
        -0x46t
        0x6dt
        0x3at
        0x55t
        0x2t
        -0x4ft
        0x20t
        0x10t
        -0x56t
        0x37t
        0x31t
        0x15t
        0x1at
        -0x13t
        0x2at
        0x3t
        -0x54t
        0x6ct
        0x38t
        0x4ft
        0x1bt
        -0xat
        0x20t
        0x3t
        -0x4at
        0x39t
        0x3ct
        0x5t
        0xct
        -0xet
        0x26t
        0x14t
        -0x4ft
        0x37t
        0x6t
        0x53t
        0xbt
        -0x5dt
        0x78t
        0x47t
        -0x1at
        0x72t
        0x6et
        0x59t
        0xct
        -0x3t
        0x2ct
        0x15t
        -0x15t
        0x77t
        0x6dt
        0xbt
        0xct
        -0x53t
        0x76t
        0x45t
        -0x16t
        0x74t
        0x38t
        0xat
        0x5bt
        -0x8t
        0x79t
        0x41t
        -0x19t
        0x77t
        0x3ft
        0x58t
        0x5dt
        -0x8t
        0x69t
        0x3t
        -0x46t
        0x27t
        0x30t
        0x48t
        0xat
        -0x3t
        0x3bt
        0x2et
        -0x56t
        0x31t
        0x30t
        0x7t
        0x7t
        -0x16t
        0x3bt
        0x1t
        -0x54t
        0x79t
        0x76t
        0x15t
        0xet
        -0xet
        0x26t
        0x2t
        -0x55t
        0x6dt
        0x37t
        0x54t
        0x41t
        -0x3t
        0x26t
        0x5et
        -0x55t
        0x2ct
        0x36t
        0x56t
        0x40t
        -0x1t
        0x23t
        0x18t
        -0x5at
        0x36t
        0x37t
        0x5et
        0x1dt
        -0x9t
        0x39t
        0x14t
        -0x10t
        0x20t
        0x38t
        0x56t
        0x3t
        -0x4t
        0x2et
        0x12t
        -0x4ct
        0x65t
        0x2at
        0x59t
        0x0t
        -0x12t
        0x2at
        0x4ct
        -0x56t
        0x30t
        0x3ct
        0x48t
        0x55t
        -0x4t
        0x2et
        0x2t
        -0x46t
        0x6ft
        0x3ft
        0x53t
        0x3t
        -0x5t
        0x75t
        0x10t
        -0x4dt
        0x2ft
        0x63t
        0x48t
        0xat
        -0x1t
        0x2bt
        0x5dt
        -0x47t
        0x2at
        0x35t
        0x5ft
        0x55t
        -0x1t
        0x23t
        0x1dt
        -0x1bt
        0x34t
        0x2bt
        0x53t
        0x1bt
        -0x5t
        0x69t
        0x2t
        -0x55t
        0x22t
        0x2dt
        0x5ft
        0x52t
    .end array-data

    :array_30a
    .array-data 1
        0x43t
        0x59t
        0x3at
        0x6ft
        -0x62t
        0x4ft
        0x71t
        -0x21t
    .end array-data

    :array_312
    .array-data 1
        -0x69t
        -0x31t
        0x4dt
        -0x9t
        0x7t
        0x5ft
        -0x57t
        0x15t
        -0x44t
        -0x19t
        0x4at
        -0x1at
        0xct
        0xbt
        -0x2bt
        0x5et
        -0xat
    .end array-data

    nop

    :array_320
    .array-data 1
        -0x28t
        -0x72t
        0x38t
        -0x7dt
        0x6ft
        0x7ft
        -0x5t
        0x70t
    .end array-data

    :array_328
    .array-data 1
        -0x65t
        0x7bt
        0x7bt
        0x6at
    .end array-data

    :array_32e
    .array-data 1
        -0x8t
        0x14t
        0x1ft
        0xft
        -0x25t
        0x2ft
        0x9t
        0x74t
    .end array-data

    :array_336
    .array-data 1
        -0x29t
        -0x40t
        -0x65t
        0xet
        0x42t
        0x20t
        -0x75t
        -0x46t
        -0x40t
        -0x29t
    .end array-data

    nop

    :array_340
    .array-data 1
        -0x50t
        -0x4et
        -0x6t
        0x60t
        0x36t
        0x7ft
        -0x1t
        -0x3dt
    .end array-data

    :array_348
    .array-data 1
        -0x2at
        -0x1et
        0x4ct
        0x47t
        0x7ft
        -0x7dt
        0x5dt
        -0x27t
        -0x2at
        -0x1dt
        0x51t
        0x40t
        0x7et
        -0x52t
        0x57t
        -0x34t
        -0x2dt
        -0xet
    .end array-data

    nop

    :array_356
    .array-data 1
        -0x49t
        -0x69t
        0x38t
        0x2ft
        0x10t
        -0xft
        0x34t
        -0x5dt
    .end array-data

    :array_35e
    .array-data 1
        -0x75t
        -0x3ct
        -0x16t
        0x8t
    .end array-data

    :array_364
    .array-data 1
        -0x18t
        -0x55t
        -0x72t
        0x6dt
        -0x66t
        -0x75t
        -0x6bt
        -0x47t
    .end array-data

    :array_36c
    .array-data 1
        -0x49t
        0x4t
        0x6et
        0x3et
        -0x25t
        0x5ct
        0x25t
        -0x49t
        -0x4bt
        0x4t
        0x66t
        0x18t
        -0x2ft
        0x44t
        0x28t
        -0x6at
        -0x15t
        0x4ft
        0x26t
    .end array-data

    :array_37a
    .array-data 1
        -0x3bt
        0x61t
        0x8t
        0x4ct
        -0x42t
        0x2ft
        0x4dt
        -0x8t
    .end array-data

    :array_382
    .array-data 1
        0x44t
        -0x3at
        0x1t
        0x11t
        -0x5et
        0x3et
        -0x35t
        -0x20t
        0x53t
        -0x2ft
    .end array-data

    nop

    :array_38c
    .array-data 1
        0x23t
        -0x4ct
        0x60t
        0x7ft
        -0x2at
        0x61t
        -0x41t
        -0x67t
    .end array-data

    :array_394
    .array-data 1
        0x5t
        -0x48t
        -0x68t
        0x4ft
        -0x47t
        0x3t
        0x1bt
        -0x72t
        0x3t
        -0x4et
        -0x6bt
        0x58t
        -0x4et
    .end array-data

    nop

    :array_3a0
    .array-data 1
        0x77t
        -0x23t
        -0x2t
        0x3dt
        -0x24t
        0x70t
        0x73t
        -0x2ft
    .end array-data

    :array_3a8
    .array-data 1
        0x56t
        0x3at
        -0x20t
        0x41t
        -0x52t
        -0x10t
        0x67t
        -0x35t
        0x50t
        0x30t
        -0x13t
        0x56t
        -0x5bt
    .end array-data

    nop

    :array_3b4
    .array-data 1
        0x24t
        0x5ft
        -0x7at
        0x33t
        -0x35t
        -0x7dt
        0xft
        -0x6ct
    .end array-data

    :array_3bc
    .array-data 1
        0x47t
        0x6at
        0x41t
        -0x59t
        0x64t
    .end array-data

    nop

    :array_3c4
    .array-data 1
        0x33t
        0x5t
        0x2at
        -0x3et
        0xat
        0x40t
        -0x5ft
        -0xet
    .end array-data
.end method

.method private F(Ljava/lang/String;Lcom/google/gson/JsonObject;)Ljava/lang/String;
    .registers 9

    const/4 v0, 0x5

    new-array v0, v0, [B

    fill-array-data v0, :array_7a

    const/16 v1, 0x8

    new-array v2, v1, [B

    fill-array-data v2, :array_82

    invoke-static {v0, v2}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_18

    goto :goto_2d

    :cond_18
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/16 v2, 0x1c

    new-array v2, v2, [B

    fill-array-data v2, :array_8a

    new-array v3, v1, [B

    fill-array-data v3, :array_9c

    .line 1
    invoke-static {v2, v3, v0, p1}, Lcom/github/catvod/spider/appysv2/b/u;->a([B[BLjava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    .line 2
    :goto_2d
    invoke-virtual {p2}, Lcom/google/gson/JsonElement;->toString()Ljava/lang/String;

    move-result-object p2

    invoke-virtual {p0}, Lcom/github/catvod/spider/appysv2/b/x;->s()Ljava/util/HashMap;

    move-result-object v0

    invoke-static {p1, p2, v0}, Lcom/github/catvod/spider/appysv2/n/c;->g(Ljava/lang/String;Ljava/lang/String;Ljava/util/Map;)Lcom/github/catvod/spider/appysv2/n/e;

    move-result-object p2

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {p2}, Lcom/github/catvod/spider/appysv2/n/e;->b()I

    move-result v2

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v2, 0x1

    new-array v3, v2, [B

    const/4 v4, 0x2

    const/4 v5, 0x0

    aput-byte v4, v3, v5

    new-array v4, v1, [B

    fill-array-data v4, :array_a4

    .line 3
    invoke-static {v3, v4, v0, p1}, Lcom/github/catvod/spider/appysv2/b/v;->c([B[BLjava/lang/StringBuilder;Ljava/lang/String;)V

    new-array p1, v2, [B

    const/16 v2, 0x55

    aput-byte v2, p1, v5

    new-array v1, v1, [B

    .line 4
    fill-array-data v1, :array_ac

    invoke-static {p1, v1}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p2}, Lcom/github/catvod/spider/appysv2/n/e;->a()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-static {p1}, Lcom/github/catvod/crawler/SpiderDebug;->log(Ljava/lang/String;)V

    invoke-virtual {p2}, Lcom/github/catvod/spider/appysv2/n/e;->a()Ljava/lang/String;

    move-result-object p1

    return-object p1

    nop

    :array_7a
    .array-data 1
        0x0t
        0x20t
        0x47t
        0x7et
        -0x6dt
    .end array-data

    nop

    :array_82
    .array-data 1
        0x68t
        0x54t
        0x33t
        0xet
        -0x20t
        -0x7bt
        -0x23t
        -0xbt
    .end array-data

    :array_8a
    .array-data 1
        0x7ct
        -0x52t
        0x3et
        0x64t
        -0x34t
        -0x61t
        -0x3at
        0x3dt
        0x75t
        -0x56t
        0x23t
        0x3at
        -0x22t
        -0x37t
        -0x80t
        0x6bt
        0x61t
        -0x4ct
        0x2et
        0x66t
        -0x2at
        -0x2dt
        -0x74t
        0x3ct
        0x77t
        -0x4bt
        0x27t
        0x3bt
    .end array-data

    :array_9c
    .array-data 1
        0x14t
        -0x26t
        0x4at
        0x14t
        -0x41t
        -0x5bt
        -0x17t
        0x12t
    .end array-data

    :array_a4
    .array-data 1
        0x2et
        0xft
        0x1dt
        -0x27t
        -0x29t
        -0x5et
        -0x3ft
        -0xat
    .end array-data

    :array_ac
    .array-data 1
        0x79t
        -0x78t
        0x44t
        -0x24t
        0x74t
        0x16t
        -0x3et
        0x2ct
    .end array-data
.end method

.method private I()Z
    .registers 26

    move-object/from16 v1, p0

    const/16 v0, 0x15

    const/4 v4, 0x0

    const/4 v5, 0x1

    :try_start_6
    new-array v0, v0, [B

    const/16 v6, -0x74

    aput-byte v6, v0, v4

    const/16 v6, -0x3c

    aput-byte v6, v0, v5

    const/16 v6, -0x34

    const/4 v7, 0x2

    aput-byte v6, v0, v7

    const/16 v6, 0x52

    const/4 v8, 0x3

    aput-byte v6, v0, v8

    const/4 v6, 0x4

    aput-byte v5, v0, v6

    const/16 v9, -0x2e

    const/4 v10, 0x5

    aput-byte v9, v0, v10

    const/16 v9, 0x2e

    const/4 v11, 0x6

    aput-byte v9, v0, v11

    const/16 v12, 0x58

    const/4 v13, 0x7

    aput-byte v12, v0, v13

    const/16 v12, -0x63

    const/16 v14, 0x8

    aput-byte v12, v0, v14

    const/16 v15, -0x3e

    const/16 v16, 0x9

    aput-byte v15, v0, v16

    const/16 v15, -0x31

    const/16 v2, 0xa

    aput-byte v15, v0, v2

    const/16 v3, 0x53

    const/16 v15, 0xb

    aput-byte v3, v0, v15

    const/16 v3, 0x17

    const/16 v17, 0xc

    aput-byte v3, v0, v17

    const/16 v3, -0xb

    const/16 v9, 0xd

    aput-byte v3, v0, v9

    const/16 v3, 0x29

    const/16 v18, 0xe

    aput-byte v3, v0, v18

    const/16 v3, 0xf

    const/16 v19, 0x72

    aput-byte v19, v0, v3

    const/16 v3, 0x10

    const/16 v19, -0x65

    aput-byte v19, v0, v3

    const/16 v3, -0x31

    const/16 v19, 0x11

    aput-byte v3, v0, v19

    const/16 v3, 0x12

    const/16 v20, -0x7c

    aput-byte v20, v0, v3

    const/16 v3, 0x13

    aput-byte v18, v0, v3

    const/16 v3, 0x14

    const/16 v20, 0x4a

    aput-byte v20, v0, v3

    new-array v3, v14, [B

    const/16 v20, -0x2

    aput-byte v20, v3, v4

    const/16 v20, -0x5f

    aput-byte v20, v3, v5

    const/16 v20, -0x56

    aput-byte v20, v3, v7

    const/16 v21, 0x20

    aput-byte v21, v3, v8

    const/16 v21, 0x64

    aput-byte v21, v3, v6

    const/16 v21, -0x5f

    aput-byte v21, v3, v10

    const/16 v21, 0x46

    aput-byte v21, v3, v11

    const/16 v21, 0x19

    aput-byte v21, v3, v13

    invoke-static {v0, v3}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lcom/github/catvod/crawler/SpiderDebug;->log(Ljava/lang/String;)V

    new-instance v0, Lcom/google/gson/JsonObject;

    invoke-direct {v0}, Lcom/google/gson/JsonObject;-><init>()V

    iget-object v3, v1, Lcom/github/catvod/spider/appysv2/b/x;->f:Lcom/github/catvod/spider/appysv2/d/c;

    invoke-virtual {v3}, Lcom/github/catvod/spider/appysv2/d/c;->c()Lcom/github/catvod/spider/appysv2/d/p;

    move-result-object v3

    invoke-virtual {v3}, Lcom/github/catvod/spider/appysv2/d/p;->d()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/String;->isEmpty()Z

    move-result v21

    if-eqz v21, :cond_b8

    iget-object v3, v1, Lcom/github/catvod/spider/appysv2/b/x;->h:Ljava/lang/String;

    :cond_b8
    const/16 v21, 0x1a

    if-eqz v3, :cond_103

    new-array v2, v6, [B

    const/16 v23, 0x2c

    aput-byte v23, v2, v4

    const/16 v23, -0x6b

    aput-byte v23, v2, v5

    const/16 v23, -0x7b

    aput-byte v23, v2, v7

    const/16 v23, -0x13

    aput-byte v23, v2, v8

    new-array v15, v14, [B

    const/16 v24, 0x44

    aput-byte v24, v15, v4

    const/16 v24, -0x1f

    aput-byte v24, v15, v5

    const/16 v24, -0xf

    aput-byte v24, v15, v7

    aput-byte v12, v15, v8

    const/16 v24, -0x76

    aput-byte v24, v15, v6

    const/16 v24, -0x2b

    aput-byte v24, v15, v10

    const/16 v24, -0x37

    aput-byte v24, v15, v11

    aput-byte v21, v15, v13

    invoke-static {v2, v15}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v3, v2}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_103

    const/4 v2, 0x0

    .line 1
    invoke-static {v3, v2}, Lcom/github/catvod/spider/appysv2/n/c;->m(Ljava/lang/String;Ljava/util/Map;)Ljava/lang/String;

    move-result-object v2

    .line 2
    invoke-virtual {v2}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v3

    goto :goto_103

    :catchall_100
    move-exception v0

    goto/16 :goto_3a6

    :cond_103
    :goto_103
    new-array v2, v9, [B

    aput-byte v9, v2, v4

    const/16 v15, 0x7f

    aput-byte v15, v2, v5

    const/16 v15, 0x7c

    aput-byte v15, v2, v7

    const/16 v15, -0xb

    aput-byte v15, v2, v8

    const/16 v15, 0x4e

    aput-byte v15, v2, v6

    const/16 v15, -0x12

    aput-byte v15, v2, v10

    const/16 v15, -0x6b

    aput-byte v15, v2, v11

    const/16 v15, -0x7f

    aput-byte v15, v2, v13

    const/16 v15, 0xb

    aput-byte v15, v2, v14

    const/16 v23, 0x75

    aput-byte v23, v2, v16

    const/16 v23, 0x71

    const/16 v22, 0xa

    aput-byte v23, v2, v22

    const/16 v23, -0x1e

    aput-byte v23, v2, v15

    const/16 v15, 0x45

    aput-byte v15, v2, v17

    new-array v15, v14, [B

    const/16 v24, 0x7f

    aput-byte v24, v15, v4

    aput-byte v21, v15, v5

    aput-byte v21, v15, v7

    const/16 v24, -0x79

    aput-byte v24, v15, v8

    const/16 v24, 0x2b

    aput-byte v24, v15, v6

    aput-byte v12, v15, v10

    const/16 v24, -0x3

    aput-byte v24, v15, v11

    const/16 v24, -0x22

    aput-byte v24, v15, v13

    invoke-static {v2, v15}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2, v3}, Lcom/google/gson/JsonObject;->addProperty(Ljava/lang/String;Ljava/lang/String;)V

    const/16 v2, 0xa

    new-array v3, v2, [B

    aput-byte v2, v3, v4

    const/16 v2, -0x68

    aput-byte v2, v3, v5

    const/16 v2, -0x51

    aput-byte v2, v3, v7

    const/16 v2, 0x37

    aput-byte v2, v3, v8

    const/16 v2, 0x16

    aput-byte v2, v3, v6

    const/16 v2, -0x2c

    aput-byte v2, v3, v10

    const/16 v2, -0x7d

    aput-byte v2, v3, v11

    const/16 v2, 0x51

    aput-byte v2, v3, v13

    const/16 v2, 0x1d

    aput-byte v2, v3, v14

    const/16 v2, -0x71

    aput-byte v2, v3, v16

    new-array v2, v14, [B

    const/16 v15, 0x6d

    aput-byte v15, v2, v4

    const/16 v15, -0x16

    aput-byte v15, v2, v5

    const/16 v15, -0x32

    aput-byte v15, v2, v7

    const/16 v15, 0x59

    aput-byte v15, v2, v8

    const/16 v15, 0x62

    aput-byte v15, v2, v6

    const/16 v15, -0x75

    aput-byte v15, v2, v10

    const/16 v15, -0x9

    aput-byte v15, v2, v11

    const/16 v15, 0x28

    aput-byte v15, v2, v13

    invoke-static {v3, v2}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v2

    new-array v3, v9, [B

    aput-byte v21, v3, v4

    const/16 v15, -0x4b

    aput-byte v15, v3, v5

    const/16 v15, -0x7a

    aput-byte v15, v3, v7

    aput-byte v11, v3, v8

    const/16 v15, -0x7a

    aput-byte v15, v3, v6

    const/16 v15, 0x37

    aput-byte v15, v3, v10

    const/4 v15, -0x2

    aput-byte v15, v3, v11

    const/16 v15, 0x21

    aput-byte v15, v3, v13

    const/16 v15, 0x1c

    aput-byte v15, v3, v14

    const/16 v15, -0x41

    aput-byte v15, v3, v16

    const/16 v15, -0x75

    const/16 v22, 0xa

    aput-byte v15, v3, v22

    const/16 v15, 0xb

    aput-byte v19, v3, v15

    const/16 v15, -0x73

    aput-byte v15, v3, v17

    new-array v15, v14, [B

    const/16 v24, 0x68

    aput-byte v24, v15, v4

    const/16 v24, -0x30

    aput-byte v24, v15, v5

    const/16 v24, -0x20

    aput-byte v24, v15, v7

    const/16 v24, 0x74

    aput-byte v24, v15, v8

    const/16 v24, -0x1d

    aput-byte v24, v15, v6

    const/16 v24, 0x44

    aput-byte v24, v15, v10

    const/16 v24, -0x6a

    aput-byte v24, v15, v11

    const/16 v24, 0x7e

    aput-byte v24, v15, v13

    invoke-static {v3, v15}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v0, v2, v3}, Lcom/google/gson/JsonObject;->addProperty(Ljava/lang/String;Ljava/lang/String;)V

    const/16 v2, 0x2d

    new-array v2, v2, [B

    const/16 v3, 0x27

    aput-byte v3, v2, v4

    const/16 v3, -0x55

    aput-byte v3, v2, v5

    const/16 v3, 0x23

    aput-byte v3, v2, v7

    const/16 v3, -0x1b

    aput-byte v3, v2, v8

    const/16 v3, -0x80

    aput-byte v3, v2, v6

    const/16 v3, -0x79

    aput-byte v3, v2, v10

    const/16 v3, -0x3a

    aput-byte v3, v2, v11

    const/16 v3, 0x2a

    aput-byte v3, v2, v13

    const/16 v15, 0x2e

    aput-byte v15, v2, v14

    aput-byte v20, v2, v16

    const/16 v15, 0x23

    const/16 v16, 0xa

    aput-byte v15, v2, v16

    const/4 v15, -0x3

    const/16 v16, 0xb

    aput-byte v15, v2, v16

    const/16 v15, -0x23

    aput-byte v15, v2, v17

    const/16 v15, -0x24

    aput-byte v15, v2, v9

    const/16 v9, -0x7b

    aput-byte v9, v2, v18

    const/16 v9, 0xf

    const/16 v15, 0x6c

    aput-byte v15, v2, v9

    const/16 v9, 0x10

    const/16 v15, 0x36

    aput-byte v15, v2, v9

    aput-byte v20, v2, v19

    const/16 v9, 0x12

    const/16 v15, 0x39

    aput-byte v15, v2, v9

    const/16 v9, 0x13

    const/16 v15, -0xf

    aput-byte v15, v2, v9

    const/16 v9, 0x14

    const/16 v15, -0x7f

    aput-byte v15, v2, v9

    const/16 v9, 0x15

    const/16 v15, -0x2c

    aput-byte v15, v2, v9

    const/16 v9, 0x16

    const/16 v15, -0x61

    aput-byte v15, v2, v9

    const/16 v9, 0x17

    const/16 v15, 0x60

    aput-byte v15, v2, v9

    const/16 v9, 0x18

    const/16 v15, 0x61

    aput-byte v15, v2, v9

    const/16 v9, 0x19

    const/16 v15, -0x44

    aput-byte v15, v2, v9

    const/16 v9, 0x38

    aput-byte v9, v2, v21

    const/16 v9, 0x1b

    const/4 v15, -0x8

    aput-byte v15, v2, v9

    const/16 v9, 0x1c

    const/16 v15, -0x24

    aput-byte v15, v2, v9

    const/16 v9, 0x1d

    const/16 v15, -0x35

    aput-byte v15, v2, v9

    const/16 v9, 0x1e

    const/16 v15, -0x25

    aput-byte v15, v2, v9

    const/16 v9, 0x1f

    aput-byte v3, v2, v9

    const/16 v9, 0x20

    const/16 v15, 0x2e

    aput-byte v15, v2, v9

    const/16 v9, 0x21

    const/16 v15, -0x44

    aput-byte v15, v2, v9

    const/16 v9, 0x22

    const/16 v15, 0x34

    aput-byte v15, v2, v9

    const/16 v9, 0x23

    const/4 v15, -0x6

    aput-byte v15, v2, v9

    const/16 v9, 0x24

    const/16 v15, -0x7a

    aput-byte v15, v2, v9

    const/16 v9, 0x25

    const/16 v15, -0x2d

    aput-byte v15, v2, v9

    const/16 v9, 0x26

    aput-byte v12, v2, v9

    const/16 v9, 0x27

    aput-byte v3, v2, v9

    const/16 v9, 0x28

    const/16 v15, 0x3b

    aput-byte v15, v2, v9

    const/16 v9, 0x29

    const/16 v15, -0x50

    aput-byte v15, v2, v9

    const/16 v9, 0x3c

    aput-byte v9, v2, v3

    const/16 v3, 0x2b

    const/16 v9, -0x10

    aput-byte v9, v2, v3

    const/16 v3, 0x2c

    aput-byte v12, v2, v3

    new-array v3, v14, [B

    const/16 v9, 0x4f

    aput-byte v9, v3, v4

    const/16 v9, -0x21

    aput-byte v9, v3, v5

    const/16 v9, 0x57

    aput-byte v9, v3, v7

    const/16 v7, -0x6b

    aput-byte v7, v3, v8

    const/16 v7, -0xd

    aput-byte v7, v3, v6

    const/16 v6, -0x43

    aput-byte v6, v3, v10

    const/16 v6, -0x17

    aput-byte v6, v3, v11

    aput-byte v10, v3, v13

    invoke-static {v2, v3}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-direct {v1, v2, v0}, Lcom/github/catvod/spider/appysv2/b/x;->F(Ljava/lang/String;Lcom/google/gson/JsonObject;)Ljava/lang/String;

    move-result-object v0

    iget-object v2, v1, Lcom/github/catvod/spider/appysv2/b/x;->f:Lcom/github/catvod/spider/appysv2/d/c;

    .line 3
    new-instance v3, Lcom/google/gson/Gson;

    invoke-direct {v3}, Lcom/google/gson/Gson;-><init>()V

    const-class v6, Lcom/github/catvod/spider/appysv2/d/p;

    invoke-virtual {v3, v0, v6}, Lcom/google/gson/Gson;->fromJson(Ljava/lang/String;Ljava/lang/Class;)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lcom/github/catvod/spider/appysv2/d/p;

    if-nez v3, :cond_329

    new-instance v3, Lcom/github/catvod/spider/appysv2/d/p;

    invoke-direct {v3}, Lcom/github/catvod/spider/appysv2/d/p;-><init>()V

    .line 4
    :cond_329
    invoke-virtual {v2, v3}, Lcom/github/catvod/spider/appysv2/d/c;->g(Lcom/github/catvod/spider/appysv2/d/p;)V

    iget-object v2, v1, Lcom/github/catvod/spider/appysv2/b/x;->f:Lcom/github/catvod/spider/appysv2/d/c;

    invoke-virtual {v2}, Lcom/github/catvod/spider/appysv2/d/c;->c()Lcom/github/catvod/spider/appysv2/d/p;

    move-result-object v2

    invoke-virtual {v2}, Lcom/github/catvod/spider/appysv2/d/p;->b()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/String;->isEmpty()Z

    move-result v2
    :try_end_33a
    .catch Ljava/lang/Exception; {:try_start_6 .. :try_end_33a} :catch_359
    .catchall {:try_start_6 .. :try_end_33a} :catchall_100

    if-nez v2, :cond_353

    :goto_33c
    iget-object v0, v1, Lcom/github/catvod/spider/appysv2/b/x;->f:Lcom/github/catvod/spider/appysv2/d/c;

    invoke-virtual {v0}, Lcom/github/catvod/spider/appysv2/d/c;->c()Lcom/github/catvod/spider/appysv2/d/p;

    move-result-object v0

    invoke-virtual {v0}, Lcom/github/catvod/spider/appysv2/d/p;->b()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/String;->isEmpty()Z

    move-result v0

    if-eqz v0, :cond_352

    const-wide/16 v2, 0xfa

    invoke-static {v2, v3}, Landroid/os/SystemClock;->sleep(J)V

    goto :goto_33c

    :cond_352
    return v5

    :cond_353
    :try_start_353
    new-instance v2, Ljava/lang/Exception;

    invoke-direct {v2, v0}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V

    throw v2
    :try_end_359
    .catch Ljava/lang/Exception; {:try_start_353 .. :try_end_359} :catch_359
    .catchall {:try_start_353 .. :try_end_359} :catchall_100

    :catch_359
    move-exception v0

    :try_start_35a
    instance-of v2, v0, Ljava/util/concurrent/TimeoutException;

    if-eqz v2, :cond_378

    .line 5
    invoke-direct/range {p0 .. p0}, Lcom/github/catvod/spider/appysv2/b/x;->O()V
    :try_end_361
    .catchall {:try_start_35a .. :try_end_361} :catchall_100

    .line 6
    :goto_361
    iget-object v0, v1, Lcom/github/catvod/spider/appysv2/b/x;->f:Lcom/github/catvod/spider/appysv2/d/c;

    invoke-virtual {v0}, Lcom/github/catvod/spider/appysv2/d/c;->c()Lcom/github/catvod/spider/appysv2/d/p;

    move-result-object v0

    invoke-virtual {v0}, Lcom/github/catvod/spider/appysv2/d/p;->b()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/String;->isEmpty()Z

    move-result v0

    if-eqz v0, :cond_377

    const-wide/16 v2, 0xfa

    invoke-static {v2, v3}, Landroid/os/SystemClock;->sleep(J)V

    goto :goto_361

    :cond_377
    return v4

    :cond_378
    :try_start_378
    iget-object v2, v1, Lcom/github/catvod/spider/appysv2/b/x;->f:Lcom/github/catvod/spider/appysv2/d/c;

    invoke-virtual {v2}, Lcom/github/catvod/spider/appysv2/d/c;->c()Lcom/github/catvod/spider/appysv2/d/p;

    move-result-object v2

    invoke-virtual {v2}, Lcom/github/catvod/spider/appysv2/d/p;->a()V

    invoke-virtual {v0}, Ljava/lang/Throwable;->printStackTrace()V

    invoke-direct/range {p0 .. p0}, Lcom/github/catvod/spider/appysv2/b/x;->O()V

    .line 7
    new-instance v0, Lcom/github/catvod/spider/appysv2/b/e;

    invoke-direct {v0, v1, v4}, Lcom/github/catvod/spider/appysv2/b/e;-><init>(Ljava/lang/Object;I)V

    invoke-static {v0}, Lcom/github/catvod/spider/Init;->run(Ljava/lang/Runnable;)V
    :try_end_38f
    .catchall {:try_start_378 .. :try_end_38f} :catchall_100

    .line 8
    :goto_38f
    iget-object v0, v1, Lcom/github/catvod/spider/appysv2/b/x;->f:Lcom/github/catvod/spider/appysv2/d/c;

    invoke-virtual {v0}, Lcom/github/catvod/spider/appysv2/d/c;->c()Lcom/github/catvod/spider/appysv2/d/p;

    move-result-object v0

    invoke-virtual {v0}, Lcom/github/catvod/spider/appysv2/d/p;->b()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/String;->isEmpty()Z

    move-result v0

    if-eqz v0, :cond_3a5

    const-wide/16 v2, 0xfa

    invoke-static {v2, v3}, Landroid/os/SystemClock;->sleep(J)V

    goto :goto_38f

    :cond_3a5
    return v5

    :goto_3a6
    iget-object v2, v1, Lcom/github/catvod/spider/appysv2/b/x;->f:Lcom/github/catvod/spider/appysv2/d/c;

    invoke-virtual {v2}, Lcom/github/catvod/spider/appysv2/d/c;->c()Lcom/github/catvod/spider/appysv2/d/p;

    move-result-object v2

    invoke-virtual {v2}, Lcom/github/catvod/spider/appysv2/d/p;->b()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/String;->isEmpty()Z

    move-result v2

    if-eqz v2, :cond_3bc

    const-wide/16 v2, 0xfa

    invoke-static {v2, v3}, Landroid/os/SystemClock;->sleep(J)V

    goto :goto_3a6

    :cond_3bc
    goto :goto_3be

    :goto_3bd
    throw v0

    :goto_3be
    goto :goto_3bd
.end method

.method private J(Ljava/lang/String;)V
    .registers 6

    iget-object v0, p0, Lcom/github/catvod/spider/appysv2/b/x;->j:Lcom/github/catvod/spider/appysv2/d/o;

    if-eqz v0, :cond_b

    invoke-virtual {v0, p1}, Lcom/github/catvod/spider/appysv2/d/o;->a(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_b

    return-void

    :cond_b
    new-instance v0, Lcom/google/gson/JsonObject;

    invoke-direct {v0}, Lcom/google/gson/JsonObject;-><init>()V

    const/16 v1, 0x8

    new-array v2, v1, [B

    fill-array-data v2, :array_7a

    new-array v3, v1, [B

    fill-array-data v3, :array_82

    invoke-static {v2, v3}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2, p1}, Lcom/google/gson/JsonObject;->addProperty(Ljava/lang/String;Ljava/lang/String;)V

    const/16 v2, 0x9

    new-array v2, v2, [B

    fill-array-data v2, :array_8a

    new-array v3, v1, [B

    fill-array-data v3, :array_94

    invoke-static {v2, v3}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v2

    const-string v3, ""

    invoke-virtual {v0, v2, v3}, Lcom/google/gson/JsonObject;->addProperty(Ljava/lang/String;Ljava/lang/String;)V

    const/16 v2, 0x1d

    new-array v2, v2, [B

    fill-array-data v2, :array_9c

    new-array v3, v1, [B

    fill-array-data v3, :array_b0

    invoke-static {v2, v3}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-direct {p0, v2, v0}, Lcom/github/catvod/spider/appysv2/b/x;->F(Ljava/lang/String;Lcom/google/gson/JsonObject;)Ljava/lang/String;

    move-result-object v0

    .line 1
    const-class v2, Lcom/github/catvod/spider/appysv2/d/o;

    .line 2
    invoke-static {v0, v2}, Lcom/github/catvod/spider/appysv2/b/s;->a(Ljava/lang/String;Ljava/lang/Class;)Ljava/lang/Object;

    move-result-object v0

    .line 3
    check-cast v0, Lcom/github/catvod/spider/appysv2/d/o;

    .line 4
    invoke-virtual {v0, p1}, Lcom/github/catvod/spider/appysv2/d/o;->f(Ljava/lang/String;)Lcom/github/catvod/spider/appysv2/d/o;

    invoke-virtual {v0}, Lcom/github/catvod/spider/appysv2/d/o;->g()Lcom/github/catvod/spider/appysv2/d/o;

    iput-object v0, p0, Lcom/github/catvod/spider/appysv2/b/x;->j:Lcom/github/catvod/spider/appysv2/d/o;

    invoke-virtual {v0}, Lcom/github/catvod/spider/appysv2/d/o;->e()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/String;->isEmpty()Z

    move-result p1

    if-eqz p1, :cond_79

    const/16 p1, 0x21

    new-array p1, p1, [B

    fill-array-data p1, :array_b8

    new-array v0, v1, [B

    fill-array-data v0, :array_ce

    invoke-static {p1, v0}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object p1

    invoke-static {p1}, Lcom/github/catvod/spider/appysv2/p/j;->b(Ljava/lang/String;)V

    :cond_79
    return-void

    :array_7a
    .array-data 1
        0x48t
        0x29t
        -0x3dt
        -0x40t
        -0x7dt
        0x14t
        -0x69t
        -0x13t
    .end array-data

    :array_82
    .array-data 1
        0x3bt
        0x41t
        -0x5et
        -0x4et
        -0x1at
        0x4bt
        -0x2t
        -0x77t
    .end array-data

    :array_8a
    .array-data 1
        -0x3et
        0x40t
        -0x6dt
        -0xft
        -0x33t
        0x49t
        0x2dt
        0x15t
        -0x2bt
    .end array-data

    nop

    :array_94
    .array-data 1
        -0x4ft
        0x28t
        -0xet
        -0x7dt
        -0x58t
        0x16t
        0x5dt
        0x62t
    .end array-data

    :array_9c
    .array-data 1
        0x34t
        -0x18t
        0x3dt
        -0x56t
        0x11t
        0x3ct
        -0x7et
        0xdt
        0x1dt
        -0x4at
        0x7bt
        -0x49t
        0x12t
        0x72t
        -0x69t
        0xdt
        0x36t
        -0x7bt
        0x61t
        -0x4ft
        0x18t
        0x2ft
        -0x6bt
        0x37t
        0x36t
        -0x4bt
        0x79t
        -0x44t
        0x17t
    .end array-data

    nop

    :array_b0
    .array-data 1
        0x42t
        -0x26t
        0x12t
        -0x27t
        0x79t
        0x5dt
        -0x10t
        0x68t
    .end array-data

    :array_b8
    .array-data 1
        -0x3at
        0x39t
        -0xft
        -0x1ct
        0x32t
        -0x41t
        0x69t
        0x6dt
        -0x7at
        0x4bt
        -0x18t
        -0x72t
        0x43t
        -0x76t
        0x29t
        0x1dt
        -0x58t
        0x22t
        -0x50t
        -0x48t
        0x0t
        -0x40t
        0x3bt
        0x4at
        -0x3bt
        0x0t
        -0x1bt
        -0x1ct
        0x3et
        -0x53t
        0x63t
        0x44t
        -0x5ft
    .end array-data

    nop

    :array_ce
    .array-data 1
        0x20t
        -0x5ct
        0x54t
        0x2t
        -0x55t
        0x25t
        -0x74t
        -0x8t
    .end array-data
.end method

.method private M(Ljava/lang/String;)V
    .registers 7

    iget-object v0, p0, Lcom/github/catvod/spider/appysv2/b/x;->f:Lcom/github/catvod/spider/appysv2/d/c;

    invoke-virtual {v0}, Lcom/github/catvod/spider/appysv2/d/c;->c()Lcom/github/catvod/spider/appysv2/d/p;

    move-result-object v0

    invoke-virtual {v0, p1}, Lcom/github/catvod/spider/appysv2/d/p;->f(Ljava/lang/String;)V

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v1, 0x6

    new-array v2, v1, [B

    fill-array-data v2, :array_54

    const/16 v3, 0x8

    new-array v4, v3, [B

    fill-array-data v4, :array_5c

    invoke-static {v2, v4}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lcom/github/catvod/crawler/SpiderDebug;->log(Ljava/lang/String;)V

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    new-array v1, v1, [B

    fill-array-data v1, :array_64

    new-array v2, v3, [B

    fill-array-data v2, :array_6c

    invoke-static {v1, v2}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-static {p1}, Lcom/github/catvod/spider/appysv2/p/j;->b(Ljava/lang/String;)V

    invoke-direct {p0}, Lcom/github/catvod/spider/appysv2/b/x;->I()Z

    invoke-direct {p0}, Lcom/github/catvod/spider/appysv2/b/x;->O()V

    return-void

    nop

    :array_54
    .array-data 1
        -0x19t
        0x4t
        -0x5ct
        -0x36t
        0x12t
        -0x29t
    .end array-data

    nop

    :array_5c
    .array-data 1
        -0x4dt
        0x6bt
        -0x31t
        -0x51t
        0x7ct
        -0x13t
        0x5t
        -0x1ct
    .end array-data

    :array_64
    .array-data 1
        0x31t
        0x0t
        -0x6ct
        -0x2dt
        -0x6dt
        -0x71t
    .end array-data

    nop

    :array_6c
    .array-data 1
        0x65t
        0x6ft
        -0x1t
        -0x4at
        -0x3t
        -0x4bt
        -0x64t
        -0x66t
    .end array-data
.end method

.method private N(Lcom/github/catvod/spider/appysv2/d/e;)V
    .registers 23

    move-object/from16 v0, p0

    const/16 v1, 0xf0

    :try_start_4
    invoke-static {v1}, Lcom/github/catvod/spider/appysv2/a/a;->b(I)I

    move-result v1

    new-instance v2, Landroid/widget/FrameLayout$LayoutParams;

    invoke-direct {v2, v1, v1}, Landroid/widget/FrameLayout$LayoutParams;-><init>(II)V

    new-instance v3, Landroid/widget/ImageView;

    invoke-static {}, Lcom/github/catvod/spider/Init;->context()Landroid/app/Application;

    move-result-object v4

    invoke-direct {v3, v4}, Landroid/widget/ImageView;-><init>(Landroid/content/Context;)V

    sget-object v4, Landroid/widget/ImageView$ScaleType;->CENTER_CROP:Landroid/widget/ImageView$ScaleType;

    invoke-virtual {v3, v4}, Landroid/widget/ImageView;->setScaleType(Landroid/widget/ImageView$ScaleType;)V

    invoke-virtual/range {p1 .. p1}, Lcom/github/catvod/spider/appysv2/d/e;->a()Ljava/lang/String;

    move-result-object v4

    const/4 v5, 0x2

    invoke-static {v4, v1}, Lcom/github/catvod/spider/appysv2/B/l;->e(Ljava/lang/String;I)Landroid/graphics/Bitmap;

    move-result-object v1

    invoke-virtual {v3, v1}, Landroid/widget/ImageView;->setImageBitmap(Landroid/graphics/Bitmap;)V

    new-instance v1, Landroid/widget/FrameLayout;

    invoke-static {}, Lcom/github/catvod/spider/Init;->context()Landroid/app/Application;

    move-result-object v4

    invoke-direct {v1, v4}, Landroid/widget/FrameLayout;-><init>(Landroid/content/Context;)V

    const/16 v4, 0x11

    iput v4, v2, Landroid/widget/FrameLayout$LayoutParams;->gravity:I

    invoke-virtual {v1, v3, v2}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    new-instance v2, Landroid/app/AlertDialog$Builder;

    invoke-static {}, Lcom/github/catvod/spider/Init;->getActivity()Landroid/app/Activity;

    move-result-object v3

    invoke-direct {v2, v3}, Landroid/app/AlertDialog$Builder;-><init>(Landroid/content/Context;)V

    invoke-virtual {v2, v1}, Landroid/app/AlertDialog$Builder;->setView(Landroid/view/View;)Landroid/app/AlertDialog$Builder;

    move-result-object v1

    new-instance v2, Lcom/github/catvod/spider/appysv2/b/m;

    const/4 v3, 0x0

    invoke-direct {v2, v0, v3}, Lcom/github/catvod/spider/appysv2/b/m;-><init>(Ljava/lang/Object;I)V

    invoke-virtual {v1, v2}, Landroid/app/AlertDialog$Builder;->setOnCancelListener(Landroid/content/DialogInterface$OnCancelListener;)Landroid/app/AlertDialog$Builder;

    move-result-object v1

    new-instance v2, Lcom/github/catvod/spider/appysv2/b/p;

    invoke-direct {v2, v0, v3}, Lcom/github/catvod/spider/appysv2/b/p;-><init>(Ljava/lang/Object;I)V

    invoke-virtual {v1, v2}, Landroid/app/AlertDialog$Builder;->setOnDismissListener(Landroid/content/DialogInterface$OnDismissListener;)Landroid/app/AlertDialog$Builder;

    move-result-object v1

    invoke-virtual {v1}, Landroid/app/AlertDialog$Builder;->show()Landroid/app/AlertDialog;

    move-result-object v1

    iput-object v1, v0, Lcom/github/catvod/spider/appysv2/b/x;->i:Landroid/app/AlertDialog;

    invoke-virtual {v1}, Landroid/app/Dialog;->getWindow()Landroid/view/Window;

    move-result-object v1

    new-instance v2, Landroid/graphics/drawable/ColorDrawable;

    invoke-direct {v2, v3}, Landroid/graphics/drawable/ColorDrawable;-><init>(I)V

    invoke-virtual {v1, v2}, Landroid/view/Window;->setBackgroundDrawable(Landroid/graphics/drawable/Drawable;)V

    const/16 v1, 0x29

    new-array v1, v1, [B

    const/16 v2, 0x77

    aput-byte v2, v1, v3

    const/16 v2, -0x3d

    const/4 v6, 0x1

    aput-byte v2, v1, v6

    const/16 v2, 0x2d

    aput-byte v2, v1, v5

    const/16 v2, 0x17

    const/4 v7, 0x3

    aput-byte v2, v1, v7

    const/16 v8, -0x45

    const/4 v9, 0x4

    aput-byte v8, v1, v9

    const/4 v8, 0x5

    const/16 v10, 0x16

    aput-byte v10, v1, v8

    const/16 v11, -0x3b

    const/4 v12, 0x6

    aput-byte v11, v1, v12

    const/4 v13, 0x7

    const/16 v14, 0x8

    aput-byte v14, v1, v13

    const/16 v15, 0x37

    aput-byte v15, v1, v14

    const/16 v15, 0x9

    const/16 v16, -0x7b

    aput-byte v16, v1, v15

    const/16 v15, 0xa

    aput-byte v5, v1, v15

    const/16 v15, 0xb

    const/16 v16, 0x4c

    aput-byte v16, v1, v15

    const/16 v15, 0xc

    const/16 v17, -0x11

    aput-byte v17, v1, v15

    const/16 v15, 0xd

    const/16 v18, 0x2e

    aput-byte v18, v1, v15

    const/16 v15, 0xe

    const/16 v18, -0x52

    aput-byte v18, v1, v15

    const/16 v15, 0xf

    const/16 v18, 0x78

    aput-byte v18, v1, v15

    const/16 v15, 0x10

    const/16 v18, 0x25

    aput-byte v18, v1, v15

    const/4 v15, -0x3

    aput-byte v15, v1, v4

    const/16 v4, 0x12

    const/16 v15, 0x7d

    aput-byte v15, v1, v4

    const/16 v4, 0x68

    const/16 v15, 0x13

    aput-byte v4, v1, v15

    const/16 v4, -0x62

    const/16 v19, 0x14

    aput-byte v4, v1, v19

    const/16 v4, 0x15

    const/16 v20, -0x77

    aput-byte v20, v1, v4

    const/16 v4, 0x63

    aput-byte v4, v1, v10

    const/16 v4, -0x14

    aput-byte v4, v1, v2

    const/16 v2, 0x18

    aput-byte v17, v1, v2

    const/16 v2, 0x19

    aput-byte v16, v1, v2

    const/16 v2, 0x1a

    const/16 v4, 0x7c

    aput-byte v4, v1, v2

    const/16 v2, 0x1b

    const/16 v4, 0x7a

    aput-byte v4, v1, v2

    const/16 v2, 0x1c

    const/16 v4, -0x53

    aput-byte v4, v1, v2

    const/16 v2, 0x4f

    const/16 v16, 0x1d

    aput-byte v2, v1, v16

    const/16 v2, 0x1e

    aput-byte v4, v1, v2

    const/16 v4, 0x1f

    aput-byte v15, v1, v4

    const/16 v4, 0x20

    const/16 v15, 0x7b

    aput-byte v15, v1, v4

    const/16 v4, 0x21

    const/16 v15, -0x2a

    aput-byte v15, v1, v4

    const/16 v4, 0x22

    aput-byte v10, v1, v4

    const/16 v10, 0x23

    aput-byte v19, v1, v10

    const/16 v10, 0x24

    const/16 v15, -0x43

    aput-byte v15, v1, v10

    aput-byte v16, v1, v18

    const/16 v10, 0x26

    aput-byte v11, v1, v10

    const/16 v10, 0x27

    const/16 v11, 0x3c

    aput-byte v11, v1, v10

    const/16 v10, 0x28

    aput-byte v2, v1, v10

    new-array v2, v14, [B

    const/16 v10, -0x61

    aput-byte v10, v2, v3

    const/16 v3, 0x6c

    aput-byte v3, v2, v6

    const/16 v3, -0x66

    aput-byte v3, v2, v5

    const/16 v3, -0xd

    aput-byte v3, v2, v7

    aput-byte v12, v2, v9

    const/16 v3, -0x57

    aput-byte v3, v2, v8

    aput-byte v4, v2, v12

    const/16 v3, -0x64

    aput-byte v3, v2, v13

    invoke-static {v1, v2}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Lcom/github/catvod/spider/appysv2/p/j;->b(Ljava/lang/String;)V
    :try_end_15f
    .catch Ljava/lang/Exception; {:try_start_4 .. :try_end_15f} :catch_15f

    :catch_15f
    return-void
.end method

.method private O()V
    .registers 3

    iget-object v0, p0, Lcom/github/catvod/spider/appysv2/b/x;->g:Ljava/util/concurrent/ScheduledExecutorService;

    if-eqz v0, :cond_7

    invoke-interface {v0}, Ljava/util/concurrent/ExecutorService;->shutdownNow()Ljava/util/List;

    :cond_7
    new-instance v0, Lcom/github/catvod/spider/appysv2/b/r;

    const/4 v1, 0x1

    invoke-direct {v0, p0, v1}, Lcom/github/catvod/spider/appysv2/b/r;-><init>(Ljava/lang/Object;I)V

    invoke-static {v0}, Lcom/github/catvod/spider/Init;->run(Ljava/lang/Runnable;)V

    return-void
.end method

.method public static a(Lcom/github/catvod/spider/appysv2/b/x;Ljava/lang/String;)V
    .registers 4

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v0, 0x4

    new-array v0, v0, [B

    .line 1
    fill-array-data v0, :array_24

    const/16 v1, 0x8

    new-array v1, v1, [B

    fill-array-data v1, :array_2a

    invoke-static {v0, v1}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_1f

    const/4 v0, 0x0

    .line 2
    invoke-static {p1, v0}, Lcom/github/catvod/spider/appysv2/n/c;->m(Ljava/lang/String;Ljava/util/Map;)Ljava/lang/String;

    move-result-object p1

    .line 3
    :cond_1f
    invoke-direct {p0, p1}, Lcom/github/catvod/spider/appysv2/b/x;->M(Ljava/lang/String;)V

    return-void

    nop

    :array_24
    .array-data 1
        0x9t
        -0x21t
        0x42t
        0x4dt
    .end array-data

    :array_2a
    .array-data 1
        0x61t
        -0x55t
        0x36t
        0x3dt
        -0x59t
        -0x31t
        -0x76t
        -0x2bt
    .end array-data
.end method

.method public static b(Lcom/github/catvod/spider/appysv2/b/x;)V
    .registers 9

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1
    new-instance v0, Ljava/util/ArrayList;

    iget-object v1, p0, Lcom/github/catvod/spider/appysv2/b/x;->d:Ljava/util/ArrayList;

    invoke-direct {v0, v1}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    invoke-virtual {v0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :cond_e
    :goto_e
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_9a

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    .line 2
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/16 v3, 0x9

    new-array v3, v3, [B

    fill-array-data v3, :array_9c

    const/16 v4, 0x8

    new-array v5, v4, [B

    fill-array-data v5, :array_a6

    invoke-static {v3, v5}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Lcom/github/catvod/crawler/SpiderDebug;->log(Ljava/lang/String;)V

    const/16 v2, 0xa7

    new-array v2, v2, [B

    fill-array-data v2, :array_ae

    new-array v3, v4, [B

    fill-array-data v3, :array_106

    invoke-static {v2, v3}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v2

    const/4 v3, 0x3

    new-array v3, v3, [Ljava/lang/Object;

    iget-object v5, p0, Lcom/github/catvod/spider/appysv2/b/x;->f:Lcom/github/catvod/spider/appysv2/d/c;

    invoke-virtual {v5}, Lcom/github/catvod/spider/appysv2/d/c;->a()Lcom/github/catvod/spider/appysv2/d/g;

    move-result-object v5

    invoke-virtual {v5}, Lcom/github/catvod/spider/appysv2/d/g;->a()Ljava/lang/String;

    move-result-object v5

    const/4 v6, 0x0

    aput-object v5, v3, v6

    const/4 v5, 0x1

    aput-object v1, v3, v5

    const/4 v7, 0x2

    aput-object v1, v3, v7

    invoke-static {v2, v3}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v2

    const/16 v3, 0xf

    new-array v3, v3, [B

    fill-array-data v3, :array_10e

    new-array v4, v4, [B

    fill-array-data v4, :array_11a

    invoke-static {v3, v4}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v3

    invoke-direct {p0, v3, v2, v5}, Lcom/github/catvod/spider/appysv2/b/x;->m(Ljava/lang/String;Ljava/lang/String;Z)Ljava/lang/String;

    move-result-object v2

    .line 3
    const-class v3, Lcom/github/catvod/spider/appysv2/d/n;

    .line 4
    invoke-static {v2, v3}, Lcom/github/catvod/spider/appysv2/b/s;->a(Ljava/lang/String;Ljava/lang/Class;)Ljava/lang/Object;

    move-result-object v2

    .line 5
    check-cast v2, Lcom/github/catvod/spider/appysv2/d/n;

    .line 6
    invoke-virtual {v2}, Lcom/github/catvod/spider/appysv2/d/n;->b()Lcom/github/catvod/spider/appysv2/d/n;

    move-result-object v2

    invoke-virtual {v2}, Lcom/github/catvod/spider/appysv2/d/n;->c()I

    move-result v2

    const/16 v3, 0x194

    if-ne v2, v3, :cond_91

    const/4 v6, 0x1

    :cond_91
    if-eqz v6, :cond_e

    .line 7
    iget-object v2, p0, Lcom/github/catvod/spider/appysv2/b/x;->d:Ljava/util/ArrayList;

    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->remove(Ljava/lang/Object;)Z

    goto/16 :goto_e

    :cond_9a
    return-void

    nop

    :array_9c
    .array-data 1
        -0x78t
        -0x4at
        -0x21t
        -0x2t
        0x41t
        -0x55t
        -0x58t
        0x15t
        -0x1et
    .end array-data

    nop

    :array_a6
    .array-data 1
        -0x34t
        -0x2dt
        -0x4dt
        -0x65t
        0x35t
        -0x32t
        -0x7at
        0x3bt
    .end array-data

    :array_ae
    .array-data 1
        -0x11t
        0x79t
        -0x5t
        0x77t
        -0x3ct
        0x72t
        -0xet
        -0x23t
        -0x20t
        0x28t
        -0x55t
        0x28t
        -0x12t
        0x7ct
        -0x4bt
        -0x34t
        -0x5t
        0x3ft
        -0x10t
        0x30t
        -0x71t
        0x7ct
        -0x4bt
        -0x36t
        -0x1at
        0x32t
        -0x1t
        0x77t
        -0x16t
        0x6et
        -0xdt
        -0x74t
        -0x52t
        0x79t
        -0x54t
        0x61t
        -0x69t
        0x2bt
        -0x4bt
        -0x38t
        -0x3t
        0x37t
        -0x14t
        0x4dt
        -0x24t
        0x63t
        -0x4bt
        -0x6ct
        -0x4at
        0x7et
        -0x6t
        0x30t
        -0x38t
        0x2bt
        -0x4bt
        -0x3at
        -0xft
        0x3at
        -0x13t
        0x77t
        -0x39t
        0x74t
        -0x4bt
        -0x6ct
        -0x11t
        0x79t
        -0x36t
        0x7dt
        -0x25t
        0x73t
        -0xet
        -0x40t
        -0x20t
        0x76t
        -0x23t
        0x6bt
        -0x3bt
        0x62t
        -0x4bt
        -0x6ct
        -0x4at
        0x3at
        -0x7t
        0x62t
        -0x27t
        0x6et
        -0xct
        -0x31t
        -0x20t
        0x32t
        -0x1at
        0x7ct
        -0x66t
        0x6dt
        -0x1ct
        -0x3ft
        -0x6t
        0x79t
        -0xct
        0x3et
        -0x69t
        0x6et
        -0xdt
        -0x74t
        -0x52t
        0x79t
        -0x54t
        0x61t
        -0x69t
        0x2bt
        -0x4bt
        -0x3dt
        -0xft
        0x2ft
        -0x1ft
        0x7dt
        -0x2ft
        0x25t
        -0x53t
        -0x74t
        -0x3ct
        0x14t
        -0x26t
        0x46t
        -0x69t
        0x2bt
        -0x4bt
        -0x25t
        -0x1at
        0x37t
        -0x55t
        0x28t
        -0x69t
        0x28t
        -0xft
        -0x39t
        -0x8t
        0x3et
        -0x5at
        0x76t
        -0x30t
        0x6bt
        -0xet
        -0x26t
        -0xft
        0x79t
        -0xct
        0x4ft
        -0x67t
        0x25t
        -0x1bt
        -0x35t
        -0x19t
        0x34t
        -0x4t
        0x60t
        -0x2at
        0x62t
        -0x4bt
        -0x6ct
        -0x4at
        0x3dt
        -0x20t
        0x7et
        -0x30t
        0x25t
        -0x16t
    .end array-data

    :array_106
    .array-data 1
        -0x6ct
        0x5bt
        -0x77t
        0x12t
        -0x4bt
        0x7t
        -0x69t
        -0x52t
    .end array-data

    :array_10e
    .array-data 1
        -0x2at
        0x29t
        0xbt
        0x1et
        0x24t
        -0x4bt
        0x27t
        -0x39t
        -0x7bt
        0x62t
        0x1bt
        0x16t
        0x26t
        -0x4dt
        0x60t
    .end array-data

    :array_11a
    .array-data 1
        -0x49t
        0x4dt
        0x79t
        0x77t
        0x52t
        -0x30t
        0x8t
        -0x4ft
    .end array-data
.end method

.method public static c(Lcom/github/catvod/spider/appysv2/b/x;)V
    .registers 1

    invoke-direct {p0}, Lcom/github/catvod/spider/appysv2/b/x;->O()V

    return-void
.end method

.method public static synthetic d(Lcom/github/catvod/spider/appysv2/b/x;Ljava/util/Map;)V
    .registers 4

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0x66

    new-array v0, v0, [B

    fill-array-data v0, :array_34

    const/16 v1, 0x8

    new-array v1, v1, [B

    fill-array-data v1, :array_6c

    invoke-static {v0, v1}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0, p1}, Lcom/github/catvod/spider/appysv2/n/c;->i(Ljava/lang/String;Ljava/util/Map;)Ljava/lang/String;

    move-result-object p1

    invoke-static {p1}, Lcom/github/catvod/spider/appysv2/d/e;->g(Ljava/lang/String;)Lcom/github/catvod/spider/appysv2/d/e;

    move-result-object p1

    invoke-virtual {p1}, Lcom/github/catvod/spider/appysv2/d/e;->b()Lcom/github/catvod/spider/appysv2/d/e;

    move-result-object p1

    invoke-virtual {p1}, Lcom/github/catvod/spider/appysv2/d/e;->c()Lcom/github/catvod/spider/appysv2/d/e;

    move-result-object p1

    invoke-virtual {p1}, Lcom/github/catvod/spider/appysv2/d/e;->f()Z

    move-result v0

    if-eqz v0, :cond_32

    invoke-virtual {p1}, Lcom/github/catvod/spider/appysv2/d/e;->e()Ljava/lang/String;

    move-result-object p1

    invoke-direct {p0, p1}, Lcom/github/catvod/spider/appysv2/b/x;->M(Ljava/lang/String;)V

    :cond_32
    return-void

    nop

    :array_34
    .array-data 1
        0x8t
        0x21t
        -0x53t
        0x7dt
        -0x60t
        -0xft
        -0x39t
        -0x45t
        0x10t
        0x34t
        -0x56t
        0x7et
        -0x5dt
        -0x5ct
        -0x66t
        -0x20t
        0x4et
        0x34t
        -0x4bt
        0x64t
        -0x56t
        -0x42t
        -0x7at
        -0x10t
        0x12t
        0x3ct
        -0x51t
        0x68t
        -0x3t
        -0x58t
        -0x79t
        -0x7t
        0x4ft
        0x3bt
        -0x44t
        0x7at
        -0x41t
        -0x5ct
        -0x71t
        -0x3t
        0xet
        0x7at
        -0x58t
        0x7ft
        -0x50t
        -0x5ct
        -0x74t
        -0xft
        0x4ft
        0x24t
        -0x54t
        0x68t
        -0x5ft
        -0x4et
        -0x3at
        -0x10t
        0xft
        0x6at
        -0x48t
        0x7dt
        -0x5dt
        -0x7bt
        -0x77t
        -0x7t
        0x5t
        0x68t
        -0x48t
        0x61t
        -0x46t
        -0x4et
        -0x63t
        -0x6t
        0x3ft
        0x31t
        -0x55t
        0x64t
        -0x5bt
        -0x52t
        -0x32t
        -0xet
        0x12t
        0x3at
        -0x4ct
        0x5et
        -0x46t
        -0x41t
        -0x73t
        -0x57t
        0x55t
        0x67t
        -0x1t
        0x52t
        -0x4ft
        -0x4dt
        -0x3bt
        -0x1et
        0x5dt
        0x67t
        -0x9t
        0x3ft
        -0x3t
        -0x8t
    .end array-data

    nop

    :array_6c
    .array-data 1
        0x60t
        0x55t
        -0x27t
        0xdt
        -0x2dt
        -0x35t
        -0x18t
        -0x6ct
    .end array-data
.end method

.method public static synthetic e(Lcom/github/catvod/spider/appysv2/b/x;)V
    .registers 1

    invoke-direct {p0}, Lcom/github/catvod/spider/appysv2/b/x;->o()V

    return-void
.end method

.method public static f(Lcom/github/catvod/spider/appysv2/b/x;)V
    .registers 3

    invoke-direct {p0}, Lcom/github/catvod/spider/appysv2/b/x;->o()V

    new-instance v0, Lcom/github/catvod/spider/appysv2/b/q;

    const/4 v1, 0x1

    invoke-direct {v0, p0, v1}, Lcom/github/catvod/spider/appysv2/b/q;-><init>(Lcom/github/catvod/spider/appysv2/b/x;I)V

    invoke-static {v0}, Lcom/github/catvod/spider/Init;->execute(Ljava/lang/Runnable;)V

    return-void
.end method

.method public static g(Lcom/github/catvod/spider/appysv2/b/x;)V
    .registers 1

    invoke-direct {p0}, Lcom/github/catvod/spider/appysv2/b/x;->O()V

    return-void
.end method

.method public static h(Lcom/github/catvod/spider/appysv2/b/x;Landroid/widget/EditText;)V
    .registers 4

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1
    invoke-virtual {p1}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p1

    .line 2
    invoke-direct {p0}, Lcom/github/catvod/spider/appysv2/b/x;->o()V

    new-instance v0, Lcom/github/catvod/spider/appysv2/b/j;

    const/4 v1, 0x0

    invoke-direct {v0, p0, p1, v1}, Lcom/github/catvod/spider/appysv2/b/j;-><init>(Ljava/lang/Object;Ljava/lang/Object;I)V

    invoke-static {v0}, Lcom/github/catvod/spider/Init;->execute(Ljava/lang/Runnable;)V

    return-void
.end method

.method public static i(Lcom/github/catvod/spider/appysv2/b/x;Lcom/github/catvod/spider/appysv2/d/e;)V
    .registers 10

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1
    invoke-virtual {p1}, Lcom/github/catvod/spider/appysv2/d/e;->d()Ljava/util/Map;

    move-result-object p1

    const/4 v0, 0x1

    .line 2
    invoke-static {v0}, Ljava/util/concurrent/Executors;->newScheduledThreadPool(I)Ljava/util/concurrent/ScheduledExecutorService;

    move-result-object v1

    iput-object v1, p0, Lcom/github/catvod/spider/appysv2/b/x;->g:Ljava/util/concurrent/ScheduledExecutorService;

    new-instance v2, Lcom/github/catvod/spider/appysv2/b/k;

    const/4 v0, 0x0

    invoke-direct {v2, p0, p1, v0}, Lcom/github/catvod/spider/appysv2/b/k;-><init>(Ljava/lang/Object;Ljava/lang/Object;I)V

    sget-object v7, Ljava/util/concurrent/TimeUnit;->SECONDS:Ljava/util/concurrent/TimeUnit;

    const-wide/16 v3, 0x1

    const-wide/16 v5, 0x1

    invoke-interface/range {v1 .. v7}, Ljava/util/concurrent/ScheduledExecutorService;->scheduleAtFixedRate(Ljava/lang/Runnable;JJLjava/util/concurrent/TimeUnit;)Ljava/util/concurrent/ScheduledFuture;

    return-void
.end method

.method public static j(Lcom/github/catvod/spider/appysv2/b/x;Ljava/lang/String;Lcom/github/catvod/spider/appysv2/d/e;)V
    .registers 53

    move-object/from16 v1, p0

    move-object/from16 v2, p2

    invoke-virtual/range {p0 .. p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v3, 0x0

    :try_start_8
    new-instance v0, Landroid/content/Intent;

    const/16 v4, 0x1a

    new-array v5, v4, [B

    const/16 v6, -0x60

    aput-byte v6, v5, v3

    const/4 v7, 0x1

    const/16 v8, -0x1e

    aput-byte v8, v5, v7

    const/4 v9, 0x2

    aput-byte v6, v5, v9

    const/4 v6, 0x3

    const/16 v10, -0x7d

    aput-byte v10, v5, v6

    const/16 v11, -0x45

    const/4 v12, 0x4

    aput-byte v11, v5, v12

    const/4 v11, 0x5

    const/16 v13, -0x27

    aput-byte v13, v5, v11

    const/4 v14, 0x6

    const/16 v15, -0x79

    aput-byte v15, v5, v14

    const/16 v16, 0x42

    const/16 v17, 0x7

    aput-byte v16, v5, v17

    const/16 v16, -0x58

    const/16 v10, 0x8

    aput-byte v16, v5, v10

    const/16 v16, 0x9

    aput-byte v8, v5, v16

    const/16 v18, 0xa

    const/16 v19, -0x50

    aput-byte v19, v5, v18

    const/16 v20, -0x6c

    const/16 v21, 0xb

    aput-byte v20, v5, v21

    const/16 v22, -0x46

    const/16 v23, 0xc

    aput-byte v22, v5, v23

    const/16 v24, -0x3c

    const/16 v8, 0xd

    aput-byte v24, v5, v8

    const/16 v25, 0xe

    const/16 v26, -0x33

    aput-byte v26, v5, v25

    const/16 v27, 0xf

    aput-byte v8, v5, v27

    const/16 v28, -0x5e

    const/16 v29, 0x10

    aput-byte v28, v5, v29

    const/16 v28, -0x8

    const/16 v30, 0x11

    aput-byte v28, v5, v30

    const/16 v31, 0x12

    const/16 v32, -0x53

    aput-byte v32, v5, v31

    const/16 v33, -0x62

    const/16 v34, 0x13

    aput-byte v33, v5, v34

    const/16 v15, 0x14

    aput-byte v22, v5, v15

    const/16 v35, 0x15

    aput-byte v33, v5, v35

    const/16 v33, -0x4b

    const/16 v36, 0x16

    aput-byte v33, v5, v36

    const/16 v33, 0x25

    const/16 v37, 0x17

    aput-byte v33, v5, v37

    const/16 v38, -0x7c

    const/16 v39, 0x18

    aput-byte v38, v5, v39

    const/16 v38, -0x25

    const/16 v40, 0x19

    aput-byte v38, v5, v40

    new-array v4, v10, [B

    const/16 v41, -0x3f

    aput-byte v41, v4, v3

    const/16 v41, -0x74

    aput-byte v41, v4, v7

    aput-byte v24, v4, v9

    const/16 v24, -0xf

    aput-byte v24, v4, v6

    const/16 v24, -0x2c

    aput-byte v24, v4, v12

    aput-byte v19, v4, v11

    const/16 v19, -0x1d

    aput-byte v19, v4, v14

    const/16 v24, 0x6c

    aput-byte v24, v4, v17

    invoke-static {v5, v4}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-direct {v0, v4}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    new-array v4, v15, [B

    const/16 v5, -0x9

    aput-byte v5, v4, v3

    const/16 v24, 0x7d

    aput-byte v24, v4, v7

    const/16 v41, 0x24

    aput-byte v41, v4, v9

    aput-byte v18, v4, v6

    const/16 v42, 0x67

    aput-byte v42, v4, v12

    const/16 v42, -0x2f

    aput-byte v42, v4, v11

    const/16 v42, -0x70

    aput-byte v42, v4, v14

    const/16 v42, -0x52

    aput-byte v42, v4, v17

    aput-byte v28, v4, v10

    aput-byte v24, v4, v16

    const/16 v24, 0x3c

    aput-byte v24, v4, v18

    const/16 v42, 0x40

    aput-byte v42, v4, v21

    const/16 v42, 0x28

    aput-byte v42, v4, v23

    aput-byte v13, v4, v8

    const/16 v43, -0x68

    aput-byte v43, v4, v25

    const/16 v43, -0x47

    aput-byte v43, v4, v27

    const/16 v44, -0xb

    aput-byte v44, v4, v29

    const/16 v45, 0x70

    aput-byte v45, v4, v30

    const/16 v45, 0x26

    aput-byte v45, v4, v31

    const/16 v46, 0x5c

    aput-byte v46, v4, v34

    new-array v13, v10, [B

    aput-byte v20, v13, v3

    aput-byte v31, v13, v7

    const/16 v47, 0x49

    aput-byte v47, v13, v9

    aput-byte v41, v13, v6

    aput-byte v14, v13, v12

    const/16 v47, -0x43

    aput-byte v47, v13, v11

    const/16 v47, -0x7

    aput-byte v47, v13, v14

    aput-byte v26, v13, v17

    invoke-static {v4, v13}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v4

    const/16 v13, 0x2c

    new-array v15, v13, [B

    const/16 v48, -0x26

    aput-byte v48, v15, v3

    const/16 v48, -0x1b

    aput-byte v48, v15, v7

    const/16 v49, -0x4c

    aput-byte v49, v15, v9

    const/16 v49, 0x34

    aput-byte v49, v15, v6

    aput-byte v46, v15, v12

    const/16 v46, 0x50

    aput-byte v46, v15, v11

    const/16 v46, -0x32

    aput-byte v46, v15, v14

    aput-byte v13, v15, v17

    const/16 v13, -0x28

    aput-byte v13, v15, v10

    aput-byte v48, v15, v16

    aput-byte v5, v15, v18

    const/16 v5, 0x76

    aput-byte v5, v15, v21

    const/16 v5, 0x47

    aput-byte v5, v15, v23

    const/16 v5, 0x56

    aput-byte v5, v15, v8

    const/16 v5, -0x38

    aput-byte v5, v15, v25

    const/16 v13, 0x20

    aput-byte v13, v15, v27

    const/16 v25, -0x73

    aput-byte v25, v15, v29

    const/16 v25, -0x15

    aput-byte v25, v15, v30

    const/16 v25, -0x49

    aput-byte v25, v15, v31

    const/16 v25, 0x7e

    aput-byte v25, v15, v34

    const/16 v25, 0x5a

    const/16 v26, 0x14

    aput-byte v25, v15, v26

    const/16 v25, 0x5e

    aput-byte v25, v15, v35

    aput-byte v5, v15, v36

    const/16 v5, 0x2a

    aput-byte v5, v15, v37

    const/16 v5, -0x69

    aput-byte v5, v15, v39

    aput-byte v47, v15, v40

    const/16 v5, 0x1a

    aput-byte v22, v15, v5

    const/16 v5, 0x1b

    const/16 v22, 0x7b

    aput-byte v22, v15, v5

    const/16 v5, 0x1c

    const/16 v22, 0x46

    aput-byte v22, v15, v5

    const/16 v5, 0x1d

    const/16 v22, 0x1f

    aput-byte v22, v15, v5

    const/16 v5, 0x1e

    const/16 v22, -0x10

    aput-byte v22, v15, v5

    const/16 v5, 0x1f

    aput-byte v24, v15, v5

    const/16 v5, -0x16

    aput-byte v5, v15, v13

    const/16 v5, 0x21

    const/16 v13, -0x17

    aput-byte v13, v15, v5

    const/16 v5, 0x22

    const/16 v13, -0x48

    aput-byte v13, v15, v5

    const/16 v5, 0x23

    const/16 v13, 0x74

    aput-byte v13, v15, v5

    const/16 v5, 0x69

    aput-byte v5, v15, v41

    const/16 v5, 0x52

    aput-byte v5, v15, v33

    const/16 v5, -0x2b

    aput-byte v5, v15, v45

    const/16 v5, 0x27

    const/16 v13, 0x27

    aput-byte v13, v15, v5

    const/16 v5, -0x31

    aput-byte v5, v15, v42

    const/16 v5, 0x29

    aput-byte v19, v15, v5

    const/16 v5, 0x2a

    aput-byte v32, v15, v5

    const/16 v5, 0x2b

    const/16 v13, 0x63

    aput-byte v13, v15, v5

    new-array v5, v10, [B

    aput-byte v43, v5, v3

    const/16 v13, -0x76

    aput-byte v13, v5, v7

    const/16 v13, -0x27

    aput-byte v13, v5, v9

    const/16 v13, 0x1a

    aput-byte v13, v5, v6

    aput-byte v42, v5, v12

    const/16 v13, 0x31

    aput-byte v13, v5, v11

    const/16 v13, -0x5f

    aput-byte v13, v5, v14

    const/16 v13, 0x4e

    aput-byte v13, v5, v17

    invoke-static {v15, v5}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v0, v4, v5}, Landroid/content/Intent;->setClassName(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    new-array v4, v8, [B

    const/16 v5, 0x66

    aput-byte v5, v4, v3

    const/16 v5, -0x79

    aput-byte v5, v4, v7

    const/16 v5, -0x2a

    aput-byte v5, v4, v9

    const/16 v5, -0x56

    aput-byte v5, v4, v6

    const/16 v5, 0x55

    aput-byte v5, v4, v12

    const/16 v5, 0x3d

    aput-byte v5, v4, v11

    aput-byte v28, v4, v14

    const/16 v5, 0x39

    aput-byte v5, v4, v17

    const/16 v5, 0x5d

    aput-byte v5, v4, v10

    const/16 v5, -0x7d

    aput-byte v5, v4, v16

    const/16 v5, -0x23

    aput-byte v5, v4, v18

    aput-byte v20, v4, v21

    const/16 v5, 0x4b

    aput-byte v5, v4, v23

    new-array v5, v10, [B

    aput-byte v8, v5, v3

    const/16 v8, -0x1e

    aput-byte v8, v5, v7

    const/16 v7, -0x51

    aput-byte v7, v5, v9

    aput-byte v44, v5, v6

    aput-byte v45, v5, v12

    aput-byte v25, v5, v11

    const/16 v6, -0x67

    aput-byte v6, v5, v14

    const/16 v6, 0x57

    aput-byte v6, v5, v17

    invoke-static {v4, v5}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v4

    move-object/from16 v5, p1

    invoke-virtual {v0, v4, v5}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    invoke-static {}, Lcom/github/catvod/spider/Init;->getActivity()Landroid/app/Activity;

    move-result-object v4

    invoke-virtual {v4, v0}, Landroid/app/Activity;->startActivity(Landroid/content/Intent;)V
    :try_end_260
    .catch Ljava/lang/Exception; {:try_start_8 .. :try_end_260} :catch_268
    .catchall {:try_start_8 .. :try_end_260} :catchall_266

    new-instance v0, Lcom/github/catvod/spider/appysv2/b/g;

    invoke-direct {v0, v1, v2, v3}, Lcom/github/catvod/spider/appysv2/b/g;-><init>(Ljava/lang/Object;Ljava/lang/Object;I)V

    goto :goto_270

    :catchall_266
    move-exception v0

    goto :goto_274

    :catch_268
    :try_start_268
    invoke-direct {v1, v2}, Lcom/github/catvod/spider/appysv2/b/x;->N(Lcom/github/catvod/spider/appysv2/d/e;)V
    :try_end_26b
    .catchall {:try_start_268 .. :try_end_26b} :catchall_266

    new-instance v0, Lcom/github/catvod/spider/appysv2/b/h;

    invoke-direct {v0, v1, v2, v3}, Lcom/github/catvod/spider/appysv2/b/h;-><init>(Ljava/lang/Object;Ljava/lang/Object;I)V

    :goto_270
    invoke-static {v0}, Lcom/github/catvod/spider/Init;->execute(Ljava/lang/Runnable;)V

    return-void

    :goto_274
    new-instance v4, Lcom/github/catvod/spider/appysv2/b/i;

    invoke-direct {v4, v1, v2, v3}, Lcom/github/catvod/spider/appysv2/b/i;-><init>(Ljava/lang/Object;Ljava/lang/Object;I)V

    invoke-static {v4}, Lcom/github/catvod/spider/Init;->execute(Ljava/lang/Runnable;)V

    throw v0
.end method

.method public static k(Lcom/github/catvod/spider/appysv2/b/x;)V
    .registers 32

    move-object/from16 v0, p0

    invoke-virtual/range {p0 .. p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v1, 0x10

    :try_start_7
    invoke-static {v1}, Lcom/github/catvod/spider/appysv2/a/a;->b(I)I

    move-result v2

    new-instance v3, Landroid/widget/FrameLayout$LayoutParams;

    const/4 v4, -0x2

    const/4 v5, -0x1

    invoke-direct {v3, v5, v4}, Landroid/widget/FrameLayout$LayoutParams;-><init>(II)V

    new-instance v4, Landroid/widget/FrameLayout;

    invoke-static {}, Lcom/github/catvod/spider/Init;->context()Landroid/app/Application;

    move-result-object v6

    invoke-direct {v4, v6}, Landroid/widget/FrameLayout;-><init>(Landroid/content/Context;)V

    invoke-virtual {v3, v2, v2, v2, v2}, Landroid/view/ViewGroup$MarginLayoutParams;->setMargins(IIII)V

    new-instance v2, Landroid/widget/EditText;

    invoke-static {}, Lcom/github/catvod/spider/Init;->context()Landroid/app/Application;

    move-result-object v6

    invoke-direct {v2, v6}, Landroid/widget/EditText;-><init>(Landroid/content/Context;)V

    invoke-virtual {v4, v2, v3}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    new-instance v3, Landroid/app/AlertDialog$Builder;

    invoke-static {}, Lcom/github/catvod/spider/Init;->getActivity()Landroid/app/Activity;

    move-result-object v6

    invoke-direct {v3, v6}, Landroid/app/AlertDialog$Builder;-><init>(Landroid/content/Context;)V

    const/16 v6, 0x26

    new-array v6, v6, [B

    const/16 v7, 0x4d

    const/4 v8, 0x0

    aput-byte v7, v6, v8

    const/4 v7, 0x1

    const/16 v9, 0x2e

    aput-byte v9, v6, v7

    const/16 v10, -0x36

    const/4 v11, 0x2

    aput-byte v10, v6, v11

    const/16 v10, -0x48

    const/4 v12, 0x3

    aput-byte v10, v6, v12

    const/16 v10, -0x4c

    const/4 v13, 0x4

    aput-byte v10, v6, v13

    const/16 v10, -0x2f

    const/4 v14, 0x5

    aput-byte v10, v6, v14

    const/16 v15, -0x14

    const/16 v16, 0x6

    aput-byte v15, v6, v16

    const/16 v17, 0x58

    const/16 v18, 0x7

    aput-byte v17, v6, v18

    const/16 v9, 0x8

    aput-byte v8, v6, v9

    const/16 v19, -0x2b

    const/16 v20, 0x9

    aput-byte v19, v6, v20

    const/16 v19, 0x12

    const/16 v21, 0xa

    aput-byte v19, v6, v21

    const/16 v22, 0x3b

    const/16 v23, 0xb

    aput-byte v22, v6, v23

    const/16 v24, 0x6f

    const/16 v25, 0xc

    aput-byte v24, v6, v25

    const/16 v26, 0x2c

    const/16 v27, 0xd

    aput-byte v26, v6, v27

    const/16 v26, -0x16

    const/16 v28, 0xe

    aput-byte v26, v6, v28

    const/16 v26, 0x5d

    const/16 v14, 0xf

    aput-byte v26, v6, v14

    const/16 v26, 0x35

    aput-byte v26, v6, v1

    const/16 v1, 0x11

    const/16 v26, 0x67

    aput-byte v26, v6, v1

    const/16 v1, -0x17

    aput-byte v1, v6, v19

    const/16 v1, 0x13

    aput-byte v5, v6, v1

    const/16 v1, 0x14

    aput-byte v15, v6, v1

    const/16 v1, 0x15

    const/16 v5, -0x32

    aput-byte v5, v6, v1

    const/16 v1, 0x16

    const/16 v5, -0x78

    aput-byte v5, v6, v1

    const/16 v1, 0x17

    const/16 v5, -0x12

    aput-byte v5, v6, v1

    const/16 v1, 0x18

    const/16 v5, -0x69

    aput-byte v5, v6, v1

    const/16 v1, 0x19

    const/16 v5, 0x65

    aput-byte v5, v6, v1

    const/16 v1, -0x40

    const/16 v5, 0x1a

    aput-byte v1, v6, v5

    const/16 v1, 0x1b

    const/16 v19, -0x23

    aput-byte v19, v6, v1

    const/16 v1, 0x1c

    const/16 v26, -0x11

    aput-byte v26, v6, v1

    const/16 v1, 0x1d

    const/16 v26, -0x30

    aput-byte v26, v6, v1

    const/16 v1, 0x1e

    const/16 v26, -0x7b

    aput-byte v26, v6, v1

    const/16 v1, -0x6b

    const/16 v26, 0x1f

    aput-byte v1, v6, v26

    const/16 v1, 0x20

    aput-byte v10, v6, v1

    const/16 v1, 0x21

    const/16 v10, -0xb

    aput-byte v10, v6, v1

    const/16 v1, 0x22

    aput-byte v27, v6, v1

    const/16 v1, 0x23

    const/16 v10, -0x4d

    aput-byte v10, v6, v1

    const/16 v1, 0x24

    const/16 v10, -0x76

    aput-byte v10, v6, v1

    const/16 v1, 0x25

    const/16 v10, -0x2d

    aput-byte v10, v6, v1

    new-array v1, v9, [B

    const/16 v10, -0x5b

    aput-byte v10, v1, v8

    const/16 v10, -0x7f

    aput-byte v10, v1, v7

    const/16 v10, 0x7d

    aput-byte v10, v1, v11

    const/16 v10, 0x50

    aput-byte v10, v1, v12

    aput-byte v21, v1, v13

    const/16 v30, 0x42

    const/16 v29, 0x5

    aput-byte v30, v1, v29

    aput-byte v20, v1, v16

    aput-byte v19, v1, v18

    invoke-static {v6, v1}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v3, v1}, Landroid/app/AlertDialog$Builder;->setTitle(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    move-result-object v1

    invoke-virtual {v1, v4}, Landroid/app/AlertDialog$Builder;->setView(Landroid/view/View;)Landroid/app/AlertDialog$Builder;

    move-result-object v1

    new-array v3, v14, [B

    const/16 v4, -0x21

    aput-byte v4, v3, v8

    const/16 v4, -0x47

    aput-byte v4, v3, v7

    const/16 v4, -0x3f

    aput-byte v4, v3, v11

    const/16 v4, -0x79

    aput-byte v4, v3, v12

    const/16 v6, -0x55

    aput-byte v6, v3, v13

    const/4 v6, 0x5

    aput-byte v26, v3, v6

    const/16 v6, 0x2e

    aput-byte v6, v3, v16

    const/16 v6, -0x65

    aput-byte v6, v3, v18

    const/16 v6, 0x4b

    aput-byte v6, v3, v9

    const/16 v6, -0x1b

    aput-byte v6, v3, v20

    const/16 v6, -0x22

    aput-byte v6, v3, v21

    const/16 v6, -0x18

    aput-byte v6, v3, v23

    const/16 v6, -0x2a

    aput-byte v6, v3, v25

    aput-byte v5, v3, v27

    aput-byte v15, v3, v28

    new-array v5, v9, [B

    aput-byte v22, v5, v8

    aput-byte v12, v5, v7

    aput-byte v10, v5, v11

    const/16 v6, 0x60

    aput-byte v6, v5, v12

    const/16 v6, 0x30

    aput-byte v6, v5, v13

    const/4 v6, 0x5

    aput-byte v4, v5, v6

    aput-byte v24, v5, v16

    const/16 v4, -0x15

    aput-byte v4, v5, v18

    invoke-static {v3, v5}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v3

    new-instance v4, Lcom/github/catvod/spider/appysv2/b/o;

    invoke-direct {v4, v0}, Lcom/github/catvod/spider/appysv2/b/o;-><init>(Lcom/github/catvod/spider/appysv2/b/x;)V

    invoke-virtual {v1, v3, v4}, Landroid/app/AlertDialog$Builder;->setNeutralButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object v1

    const/high16 v3, 0x1040000

    const/4 v4, 0x0

    invoke-virtual {v1, v3, v4}, Landroid/app/AlertDialog$Builder;->setNegativeButton(ILandroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object v1

    const v3, 0x104000a

    new-instance v4, Lcom/github/catvod/spider/appysv2/b/n;

    invoke-direct {v4, v0, v2, v8}, Lcom/github/catvod/spider/appysv2/b/n;-><init>(Ljava/lang/Object;Ljava/lang/Object;I)V

    invoke-virtual {v1, v3, v4}, Landroid/app/AlertDialog$Builder;->setPositiveButton(ILandroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object v1

    invoke-virtual {v1}, Landroid/app/AlertDialog$Builder;->show()Landroid/app/AlertDialog;

    move-result-object v1

    iput-object v1, v0, Lcom/github/catvod/spider/appysv2/b/x;->i:Landroid/app/AlertDialog;
    :try_end_1a9
    .catch Ljava/lang/Exception; {:try_start_7 .. :try_end_1a9} :catch_1a9

    :catch_1a9
    return-void
.end method

.method private l(Ljava/lang/String;Lcom/google/gson/JsonObject;)Z
    .registers 9

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/16 v1, 0x25

    new-array v1, v1, [B

    fill-array-data v1, :array_b4

    const/16 v2, 0x8

    new-array v3, v2, [B

    fill-array-data v3, :array_cc

    .line 1
    invoke-static {v1, v3, v0, p1}, Lcom/github/catvod/spider/appysv2/b/u;->a([B[BLjava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    .line 2
    invoke-virtual {p2}, Lcom/google/gson/JsonElement;->toString()Ljava/lang/String;

    move-result-object p2

    invoke-virtual {p0}, Lcom/github/catvod/spider/appysv2/b/x;->s()Ljava/util/HashMap;

    move-result-object v0

    invoke-static {p1, p2, v0}, Lcom/github/catvod/spider/appysv2/n/c;->g(Ljava/lang/String;Ljava/lang/String;Ljava/util/Map;)Lcom/github/catvod/spider/appysv2/n/e;

    move-result-object p2

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {p2}, Lcom/github/catvod/spider/appysv2/n/e;->b()I

    move-result v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v1, 0x1

    new-array v3, v1, [B

    const/4 v4, 0x0

    const/16 v5, -0x7e

    aput-byte v5, v3, v4

    new-array v5, v2, [B

    fill-array-data v5, :array_d4

    .line 3
    invoke-static {v3, v5, v0, p1}, Lcom/github/catvod/spider/appysv2/b/v;->c([B[BLjava/lang/StringBuilder;Ljava/lang/String;)V

    new-array p1, v1, [B

    const/16 v3, 0x7d

    aput-byte v3, p1, v4

    new-array v3, v2, [B

    .line 4
    fill-array-data v3, :array_dc

    invoke-static {p1, v3}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p2}, Lcom/github/catvod/spider/appysv2/n/e;->a()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-static {p1}, Lcom/github/catvod/crawler/SpiderDebug;->log(Ljava/lang/String;)V

    invoke-virtual {p2}, Lcom/github/catvod/spider/appysv2/n/e;->a()Ljava/lang/String;

    move-result-object p1

    const/16 v0, 0x11

    new-array v0, v0, [B

    .line 5
    fill-array-data v0, :array_e4

    new-array v3, v2, [B

    fill-array-data v3, :array_f2

    invoke-static {v0, v3}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result p1

    if-nez p1, :cond_7b

    const/4 p1, 0x0

    goto :goto_98

    :cond_7b
    const/16 p1, 0x21

    new-array p1, p1, [B

    fill-array-data p1, :array_fa

    new-array v0, v2, [B

    fill-array-data v0, :array_110

    invoke-static {p1, v0}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object p1

    invoke-static {p1}, Lcom/github/catvod/spider/appysv2/p/j;->b(Ljava/lang/String;)V

    iget-object p1, p0, Lcom/github/catvod/spider/appysv2/b/x;->f:Lcom/github/catvod/spider/appysv2/d/c;

    invoke-virtual {p1}, Lcom/github/catvod/spider/appysv2/d/c;->b()Lcom/github/catvod/spider/appysv2/d/i;

    move-result-object p1

    invoke-virtual {p1}, Lcom/github/catvod/spider/appysv2/d/i;->a()V

    const/4 p1, 0x1

    :goto_98
    if-eqz p1, :cond_9b

    return v4

    .line 6
    :cond_9b
    iget-object p1, p0, Lcom/github/catvod/spider/appysv2/b/x;->f:Lcom/github/catvod/spider/appysv2/d/c;

    invoke-virtual {p2}, Lcom/github/catvod/spider/appysv2/n/e;->a()Ljava/lang/String;

    move-result-object p2

    .line 7
    const-class v0, Lcom/github/catvod/spider/appysv2/d/i;

    .line 8
    invoke-static {p2, v0}, Lcom/github/catvod/spider/appysv2/b/s;->a(Ljava/lang/String;Ljava/lang/Class;)Ljava/lang/Object;

    move-result-object p2

    .line 9
    check-cast p2, Lcom/github/catvod/spider/appysv2/d/i;

    if-nez p2, :cond_b0

    new-instance p2, Lcom/github/catvod/spider/appysv2/d/i;

    invoke-direct {p2}, Lcom/github/catvod/spider/appysv2/d/i;-><init>()V

    .line 10
    :cond_b0
    invoke-virtual {p1, p2}, Lcom/github/catvod/spider/appysv2/d/c;->f(Lcom/github/catvod/spider/appysv2/d/i;)V

    return v1

    :array_b4
    .array-data 1
        0x1bt
        0x45t
        0x32t
        -0x55t
        -0x1at
        0x77t
        0xat
        0x42t
        0x12t
        0x41t
        0x2ft
        -0xbt
        -0x13t
        0x25t
        0x4at
        0xbt
        0x16t
        0x1ft
        0x32t
        -0x4ct
        -0x1bt
        0x62t
        0x44t
        0x1t
        0x1at
        0x42t
        0x32t
        -0xct
        -0xct
        0x21t
        0x4ct
        0x32t
        0x1ct
        0x41t
        0x23t
        -0x4bt
        -0x46t
    .end array-data

    nop

    :array_cc
    .array-data 1
        0x73t
        0x31t
        0x46t
        -0x25t
        -0x6bt
        0x4dt
        0x25t
        0x6dt
    .end array-data

    :array_d4
    .array-data 1
        -0x52t
        -0x35t
        0x69t
        0x20t
        0x37t
        -0x8t
        0x10t
        0x69t
    .end array-data

    :array_dc
    .array-data 1
        0x51t
        -0x36t
        -0x28t
        0x2et
        0x66t
        -0x6t
        0x4dt
        -0xct
    .end array-data

    :array_e4
    .array-data 1
        0x3bt
        0x24t
        -0x22t
        -0x59t
        0x52t
        -0x7ft
        -0x22t
        -0x22t
        0x4ft
        0x19t
        -0x2ct
        -0xat
        0x6at
        -0x7bt
        -0x3dt
        -0x2dt
        0x1ct
    .end array-data

    nop

    :array_f2
    .array-data 1
        0x6ft
        0x4bt
        -0x4ft
        -0x79t
        0x1ft
        -0x20t
        -0x50t
        -0x59t
    .end array-data

    :array_fa
    .array-data 1
        0x79t
        -0x72t
        0x13t
        -0x67t
        0x32t
        0x43t
        -0x2ct
        0x66t
        0x3et
        -0x21t
        0x14t
        -0x28t
        0x69t
        0x68t
        -0x41t
        0x1dt
        0x3dt
        -0x64t
        0x6dt
        -0x8t
        0xat
        0x31t
        -0x5at
        0x5et
        0x76t
        -0x47t
        0x39t
        -0x67t
        0x1at
        0x5dt
        -0x24t
        0x47t
        0x1et
    .end array-data

    nop

    :array_110
    .array-data 1
        -0x61t
        0x3at
        -0x7ct
        0x7ft
        -0x7at
        -0x2ct
        0x33t
        -0x5t
    .end array-data
.end method

.method private m(Ljava/lang/String;Ljava/lang/String;Z)Ljava/lang/String;
    .registers 11

    const/4 v0, 0x5

    new-array v0, v0, [B

    fill-array-data v0, :array_f0

    const/16 v1, 0x8

    new-array v2, v1, [B

    fill-array-data v2, :array_f8

    invoke-static {v0, v2}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_18

    goto :goto_2d

    :cond_18
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/16 v2, 0x1c

    new-array v2, v2, [B

    fill-array-data v2, :array_100

    new-array v3, v1, [B

    fill-array-data v3, :array_112

    .line 1
    invoke-static {v2, v3, v0, p1}, Lcom/github/catvod/spider/appysv2/b/u;->a([B[BLjava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    :goto_2d
    const/16 v0, 0x9

    new-array v0, v0, [B

    .line 2
    fill-array-data v0, :array_11a

    new-array v2, v1, [B

    fill-array-data v2, :array_124

    invoke-static {v0, v2}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    if-eqz v0, :cond_82

    .line 3
    invoke-virtual {p0}, Lcom/github/catvod/spider/appysv2/b/x;->s()Ljava/util/HashMap;

    move-result-object v0

    const/16 v2, 0xd

    new-array v2, v2, [B

    fill-array-data v2, :array_12c

    new-array v3, v1, [B

    fill-array-data v3, :array_138

    invoke-static {v2, v3}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v2

    iget-object v3, p0, Lcom/github/catvod/spider/appysv2/b/x;->j:Lcom/github/catvod/spider/appysv2/d/o;

    invoke-virtual {v3}, Lcom/github/catvod/spider/appysv2/d/o;->e()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v0, v2, v3}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    new-array v2, v1, [B

    fill-array-data v2, :array_140

    new-array v3, v1, [B

    fill-array-data v3, :array_148

    invoke-static {v2, v3}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v2

    const/16 v3, 0x28

    new-array v3, v3, [B

    fill-array-data v3, :array_150

    new-array v4, v1, [B

    fill-array-data v4, :array_168

    invoke-static {v3, v4}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v0, v2, v3}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_86

    .line 4
    :cond_82
    invoke-direct {p0}, Lcom/github/catvod/spider/appysv2/b/x;->t()Ljava/util/HashMap;

    move-result-object v0

    :goto_86
    invoke-static {p1, p2, v0}, Lcom/github/catvod/spider/appysv2/n/c;->g(Ljava/lang/String;Ljava/lang/String;Ljava/util/Map;)Lcom/github/catvod/spider/appysv2/n/e;

    move-result-object v0

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v0}, Lcom/github/catvod/spider/appysv2/n/e;->b()I

    move-result v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v3, 0x1

    new-array v4, v3, [B

    const/16 v5, 0x50

    const/4 v6, 0x0

    aput-byte v5, v4, v6

    new-array v5, v1, [B

    fill-array-data v5, :array_170

    .line 5
    invoke-static {v4, v5, v2, p1}, Lcom/github/catvod/spider/appysv2/b/v;->c([B[BLjava/lang/StringBuilder;Ljava/lang/String;)V

    new-array v3, v3, [B

    const/16 v4, -0x3c

    aput-byte v4, v3, v6

    new-array v1, v1, [B

    .line 6
    fill-array-data v1, :array_178

    invoke-static {v3, v1}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Lcom/github/catvod/spider/appysv2/n/e;->a()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Lcom/github/catvod/crawler/SpiderDebug;->log(Ljava/lang/String;)V

    if-eqz p3, :cond_db

    invoke-virtual {v0}, Lcom/github/catvod/spider/appysv2/n/e;->b()I

    move-result v1

    const/16 v2, 0x191

    if-ne v1, v2, :cond_db

    invoke-direct {p0}, Lcom/github/catvod/spider/appysv2/b/x;->I()Z

    move-result v1

    if-eqz v1, :cond_db

    invoke-direct {p0, p1, p2, v6}, Lcom/github/catvod/spider/appysv2/b/x;->m(Ljava/lang/String;Ljava/lang/String;Z)Ljava/lang/String;

    move-result-object p1

    return-object p1

    :cond_db
    if-eqz p3, :cond_ea

    invoke-virtual {v0}, Lcom/github/catvod/spider/appysv2/n/e;->b()I

    move-result p3

    const/16 v1, 0x1ad

    if-ne p3, v1, :cond_ea

    invoke-direct {p0, p1, p2, v6}, Lcom/github/catvod/spider/appysv2/b/x;->m(Ljava/lang/String;Ljava/lang/String;Z)Ljava/lang/String;

    move-result-object p1

    return-object p1

    :cond_ea
    invoke-virtual {v0}, Lcom/github/catvod/spider/appysv2/n/e;->a()Ljava/lang/String;

    move-result-object p1

    return-object p1

    nop

    :array_f0
    .array-data 1
        -0x26t
        -0x14t
        0xbt
        -0x5dt
        -0x72t
    .end array-data

    nop

    :array_f8
    .array-data 1
        -0x4et
        -0x68t
        0x7ft
        -0x2dt
        -0x3t
        -0x7t
        -0x6dt
        0x59t
    .end array-data

    :array_100
    .array-data 1
        0x5ct
        -0x5at
        -0x21t
        0x79t
        0x21t
        0x6t
        0x64t
        -0x10t
        0x55t
        -0x5et
        -0x3et
        0x27t
        0x33t
        0x50t
        0x22t
        -0x5at
        0x41t
        -0x44t
        -0x31t
        0x7bt
        0x3bt
        0x4at
        0x2et
        -0xft
        0x57t
        -0x43t
        -0x3at
        0x26t
    .end array-data

    :array_112
    .array-data 1
        0x34t
        -0x2et
        -0x55t
        0x9t
        0x52t
        0x3ct
        0x4bt
        -0x21t
    .end array-data

    :array_11a
    .array-data 1
        -0x6t
        0x6et
        -0x59t
        -0x33t
        0x62t
        -0x64t
        -0x69t
        -0x3ft
        -0x18t
    .end array-data

    nop

    :array_124
    .array-data 1
        -0x64t
        0x7t
        -0x35t
        -0x58t
        0x4dt
        -0x10t
        -0x2t
        -0x4et
    .end array-data

    :array_12c
    .array-data 1
        0x27t
        -0x4et
        0x46t
        0x1ct
        -0x61t
        0x59t
        -0x7ct
        -0x6et
        0x2bt
        -0x10t
        0x5et
        0x11t
        -0x70t
    .end array-data

    nop

    :array_138
    .array-data 1
        0x5ft
        -0x61t
        0x35t
        0x74t
        -0x2t
        0x2bt
        -0x1ft
        -0x41t
    .end array-data

    :array_140
    .array-data 1
        0x6ct
        0x30t
        -0x47t
        -0x6ft
        0x44t
        -0xct
        -0x21t
        -0x48t
    .end array-data

    :array_148
    .array-data 1
        0x34t
        0x1dt
        -0x6t
        -0x10t
        0x2at
        -0x6bt
        -0x53t
        -0x3ft
    .end array-data

    :array_150
    .array-data 1
        0x76t
        0x69t
        0x24t
        0x60t
        0x69t
        0x5ct
        -0x51t
        -0x61t
        0x7bt
        0x61t
        0x3ft
        0x6at
        0x6et
        0x4ct
        -0x42t
        -0x41t
        0x65t
        0x75t
        0x70t
        0x64t
        0x63t
        0x5at
        -0x5t
        -0x58t
        0x70t
        0x29t
        0x3bt
        0x60t
        0x75t
        0x5bt
        -0x5t
        -0x4ft
        0x7bt
        0x38t
        0x3bt
        0x31t
        0x29t
        0x1bt
        -0x44t
        -0x11t
    .end array-data

    :array_168
    .array-data 1
        0x15t
        0x5t
        0x4dt
        0x5t
        0x7t
        0x28t
        -0x6et
        -0x22t
    .end array-data

    :array_170
    .array-data 1
        0x7ct
        -0x39t
        0x67t
        0x7t
        0x6bt
        0x4ft
        -0x66t
        -0x50t
    .end array-data

    :array_178
    .array-data 1
        -0x18t
        0x14t
        -0x4ct
        -0x34t
        0x4at
        -0xft
        -0x7ct
        -0xdt
    .end array-data
.end method

.method private n(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    .registers 10

    iget-object v0, p0, Lcom/github/catvod/spider/appysv2/b/x;->f:Lcom/github/catvod/spider/appysv2/d/c;

    invoke-virtual {v0}, Lcom/github/catvod/spider/appysv2/d/c;->a()Lcom/github/catvod/spider/appysv2/d/g;

    move-result-object v0

    invoke-virtual {v0}, Lcom/github/catvod/spider/appysv2/d/g;->a()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/String;->isEmpty()Z

    move-result v0

    const/16 v1, 0xf

    const/4 v2, 0x2

    const/4 v3, 0x1

    const/16 v4, 0x8

    if-eqz v0, :cond_5d

    new-array v0, v1, [B

    .line 1
    fill-array-data v0, :array_ce

    new-array v5, v4, [B

    fill-array-data v5, :array_da

    invoke-static {v0, v5}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lcom/github/catvod/crawler/SpiderDebug;->log(Ljava/lang/String;)V

    const/16 v0, 0x28

    new-array v0, v0, [B

    fill-array-data v0, :array_e2

    new-array v5, v4, [B

    fill-array-data v5, :array_fa

    invoke-static {v0, v5}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v0

    new-array v5, v2, [B

    fill-array-data v5, :array_102

    new-array v6, v4, [B

    fill-array-data v6, :array_108

    invoke-static {v5, v6}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-direct {p0, v0, v5, v3}, Lcom/github/catvod/spider/appysv2/b/x;->m(Ljava/lang/String;Ljava/lang/String;Z)Ljava/lang/String;

    move-result-object v0

    iget-object v5, p0, Lcom/github/catvod/spider/appysv2/b/x;->f:Lcom/github/catvod/spider/appysv2/d/c;

    .line 2
    const-class v6, Lcom/github/catvod/spider/appysv2/d/g;

    .line 3
    invoke-static {v0, v6}, Lcom/github/catvod/spider/appysv2/b/s;->a(Ljava/lang/String;Ljava/lang/Class;)Ljava/lang/Object;

    move-result-object v0

    .line 4
    check-cast v0, Lcom/github/catvod/spider/appysv2/d/g;

    if-nez v0, :cond_5a

    new-instance v0, Lcom/github/catvod/spider/appysv2/d/g;

    invoke-direct {v0}, Lcom/github/catvod/spider/appysv2/d/g;-><init>()V

    .line 5
    :cond_5a
    invoke-virtual {v5, v0}, Lcom/github/catvod/spider/appysv2/d/c;->e(Lcom/github/catvod/spider/appysv2/d/g;)V

    .line 6
    :cond_5d
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x7

    new-array v5, v5, [B

    fill-array-data v5, :array_110

    new-array v6, v4, [B

    fill-array-data v6, :array_118

    invoke-static {v5, v6}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v0, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lcom/github/catvod/crawler/SpiderDebug;->log(Ljava/lang/String;)V

    const/16 v0, 0xe5

    new-array v0, v0, [B

    fill-array-data v0, :array_120

    new-array v5, v4, [B

    fill-array-data v5, :array_198

    invoke-static {v0, v5}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v0

    const/4 v5, 0x3

    new-array v5, v5, [Ljava/lang/Object;

    const/4 v6, 0x0

    aput-object p2, v5, v6

    aput-object p1, v5, v3

    iget-object p1, p0, Lcom/github/catvod/spider/appysv2/b/x;->f:Lcom/github/catvod/spider/appysv2/d/c;

    invoke-virtual {p1}, Lcom/github/catvod/spider/appysv2/d/c;->a()Lcom/github/catvod/spider/appysv2/d/g;

    move-result-object p1

    invoke-virtual {p1}, Lcom/github/catvod/spider/appysv2/d/g;->a()Ljava/lang/String;

    move-result-object p1

    aput-object p1, v5, v2

    invoke-static {v0, v5}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    new-array p2, v1, [B

    fill-array-data p2, :array_1a0

    new-array v0, v4, [B

    fill-array-data v0, :array_1ac

    invoke-static {p2, v0}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object p2

    invoke-direct {p0, p2, p1, v3}, Lcom/github/catvod/spider/appysv2/b/x;->m(Ljava/lang/String;Ljava/lang/String;Z)Ljava/lang/String;

    move-result-object p1

    .line 7
    const-class p2, Lcom/github/catvod/spider/appysv2/d/n;

    .line 8
    invoke-static {p1, p2}, Lcom/github/catvod/spider/appysv2/b/s;->a(Ljava/lang/String;Ljava/lang/Class;)Ljava/lang/Object;

    move-result-object p1

    .line 9
    check-cast p1, Lcom/github/catvod/spider/appysv2/d/n;

    .line 10
    invoke-virtual {p1}, Lcom/github/catvod/spider/appysv2/d/n;->b()Lcom/github/catvod/spider/appysv2/d/n;

    move-result-object p1

    invoke-virtual {p1}, Lcom/github/catvod/spider/appysv2/d/n;->a()Lcom/github/catvod/spider/appysv2/d/m;

    move-result-object p1

    invoke-virtual {p1}, Lcom/github/catvod/spider/appysv2/d/m;->a()Ljava/lang/String;

    move-result-object p1

    return-object p1

    nop

    :array_ce
    .array-data 1
        -0xdt
        -0x3at
        -0xft
        0x57t
        0x5dt
        0x73t
        0x17t
        0x36t
        -0x2ft
        -0x7dt
        -0x34t
        0x13t
        0x37t
        0x2ft
        0x50t
    .end array-data

    :array_da
    .array-data 1
        -0x4ct
        -0x5dt
        -0x7bt
        0x77t
        0x19t
        0x1t
        0x7et
        0x40t
    .end array-data

    :array_e2
    .array-data 1
        0x60t
        0x2dt
        0x2t
        -0x7bt
        0x6bt
        0x48t
        0x21t
        0x7dt
        0x7dt
        0x2at
        0x13t
        -0x79t
        0x36t
        0x13t
        0x62t
        0x3bt
        0x71t
        0x2ct
        0x18t
        -0x6ft
        0x6at
        0x1bt
        0x78t
        0x37t
        0x26t
        0x3at
        0x19t
        -0x68t
        0x37t
        0x4t
        0x3ct
        0x7dt
        0x7dt
        0x2at
        0x13t
        -0x79t
        0x37t
        0x15t
        0x6bt
        0x26t
    .end array-data

    :array_fa
    .array-data 1
        0x8t
        0x59t
        0x76t
        -0xbt
        0x18t
        0x72t
        0xet
        0x52t
    .end array-data

    :array_102
    .array-data 1
        -0x4ct
        0x4t
    .end array-data

    nop

    :array_108
    .array-data 1
        -0x31t
        0x79t
        -0x66t
        -0x5bt
        -0x7et
        0x5dt
        0xat
        0x1et
    .end array-data

    :array_110
    .array-data 1
        0x70t
        0x28t
        0x4t
        0x63t
        0xft
        -0x59t
        0x54t
    .end array-data

    :array_118
    .array-data 1
        0x33t
        0x47t
        0x74t
        0x1at
        0x21t
        -0x77t
        0x7at
        -0x34t
    .end array-data

    :array_120
    .array-data 1
        -0x1at
        -0x80t
        0x7dt
        -0x45t
        -0x65t
        0x36t
        -0x66t
        0x2bt
        -0x17t
        -0x2ft
        0x2dt
        -0x1ct
        -0x4ft
        0x38t
        -0x23t
        0x3at
        -0xet
        -0x3at
        0x76t
        -0x4t
        -0x30t
        0x38t
        -0x23t
        0x3et
        -0xct
        -0x32t
        0x6at
        -0x7ft
        -0x7dt
        0x27t
        -0x23t
        0x62t
        -0x41t
        -0x79t
        0x7ct
        -0x4t
        -0x3at
        0x61t
        -0x74t
        0x30t
        -0x4t
        -0x30t
        0x6at
        -0x7ft
        -0x7dt
        0x27t
        -0x23t
        0x62t
        -0x41t
        -0x79t
        0x7ct
        -0x4t
        -0x3at
        0x61t
        -0x62t
        0x2dt
        -0x17t
        -0x33t
        0x50t
        -0x54t
        -0x71t
        0x2dt
        -0x62t
        0x35t
        -0x8t
        -0x80t
        0x35t
        -0x56t
        -0x68t
        0x36t
        -0x66t
        0x74t
        -0x41t
        -0x2at
        0x60t
        -0x7ft
        -0x66t
        0x22t
        -0x73t
        0x3dt
        -0xdt
        -0x2at
        0x50t
        -0x48t
        -0x7dt
        0x2ft
        -0x66t
        0x7t
        -0xct
        -0x3at
        0x2dt
        -0x1ct
        -0x38t
        0x31t
        -0x70t
        0x37t
        -0x17t
        -0x80t
        0x23t
        -0x4t
        -0x62t
        0x2ct
        -0x60t
        0x3ct
        -0x11t
        -0x35t
        0x79t
        -0x45t
        -0x4bt
        0x2at
        -0x65t
        0x7at
        -0x59t
        -0x80t
        0x2at
        -0x53t
        -0x38t
        0x3et
        -0x2dt
        0x7at
        -0xbt
        -0x39t
        0x6et
        -0x46t
        -0x71t
        0x31t
        -0x74t
        0x7at
        -0x59t
        -0x27t
        0x2dt
        -0x63t
        -0x7bt
        0x2dt
        -0x75t
        0x3dt
        -0xdt
        -0x2at
        0x22t
        -0x76t
        -0x6dt
        0x33t
        -0x66t
        0x7at
        -0x59t
        -0x80t
        0x6et
        -0x52t
        -0x66t
        0x2ft
        -0x6at
        0x3bt
        -0x4t
        -0x2at
        0x66t
        -0x4ft
        -0x7ct
        0x6ct
        -0x6bt
        0x2bt
        -0xet
        -0x34t
        0x2dt
        -0x5dt
        -0x3at
        0x61t
        -0x6at
        0x3ct
        -0x41t
        -0x68t
        0x2dt
        -0x12t
        -0x38t
        0x6ft
        -0x23t
        0x35t
        -0x8t
        -0x2at
        0x67t
        -0x4ft
        -0x72t
        0x61t
        -0x3bt
        0x7at
        -0x33t
        -0x13t
        0x5ct
        -0x76t
        -0x38t
        0x6ft
        -0x23t
        0x2dt
        -0x11t
        -0x32t
        0x2dt
        -0x1ct
        -0x38t
        0x6ct
        -0x67t
        0x31t
        -0xft
        -0x39t
        0x20t
        -0x43t
        -0x7bt
        0x33t
        -0x7at
        0x7at
        -0x20t
        -0x1t
        0x23t
        -0x4t
        -0x68t
        0x26t
        -0x74t
        0x37t
        -0x18t
        -0x30t
        0x6ct
        -0x45t
        -0x38t
        0x79t
        -0x23t
        0x3et
        -0xct
        -0x32t
        0x6at
        -0x4t
        -0x69t
    .end array-data

    nop

    :array_198
    .array-data 1
        -0x63t
        -0x5et
        0xft
        -0x22t
        -0x16t
        0x43t
        -0x1t
        0x58t
    .end array-data

    :array_1a0
    .array-data 1
        0x8t
        -0x34t
        -0x30t
        0x20t
        0x4ft
        -0x3dt
        0x38t
        -0x40t
        0x5bt
        -0x79t
        -0x40t
        0x28t
        0x4dt
        -0x3bt
        0x7ft
    .end array-data

    :array_1ac
    .array-data 1
        0x69t
        -0x58t
        -0x5et
        0x49t
        0x39t
        -0x5at
        0x17t
        -0x4at
    .end array-data
.end method

.method private o()V
    .registers 2

    :try_start_0
    iget-object v0, p0, Lcom/github/catvod/spider/appysv2/b/x;->i:Landroid/app/AlertDialog;

    if-eqz v0, :cond_7

    invoke-virtual {v0}, Landroid/app/Dialog;->dismiss()V
    :try_end_7
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_7} :catch_7

    :catch_7
    :cond_7
    return-void
.end method

.method public static p()Lcom/github/catvod/spider/appysv2/b/x;
    .registers 1

    sget-object v0, Lcom/github/catvod/spider/appysv2/b/w;->a:Lcom/github/catvod/spider/appysv2/b/x;

    return-object v0
.end method

.method private t()Ljava/util/HashMap;
    .registers 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/HashMap<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    invoke-virtual {p0}, Lcom/github/catvod/spider/appysv2/b/x;->s()Ljava/util/HashMap;

    move-result-object v0

    const/16 v1, 0xd

    new-array v2, v1, [B

    fill-array-data v2, :array_68

    const/16 v3, 0x8

    new-array v4, v3, [B

    fill-array-data v4, :array_74

    invoke-static {v2, v4}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v2

    iget-object v4, p0, Lcom/github/catvod/spider/appysv2/b/x;->j:Lcom/github/catvod/spider/appysv2/d/o;

    invoke-virtual {v4}, Lcom/github/catvod/spider/appysv2/d/o;->e()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v0, v2, v4}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    new-array v2, v3, [B

    fill-array-data v2, :array_7c

    new-array v4, v3, [B

    fill-array-data v4, :array_84

    invoke-static {v2, v4}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v2

    const/16 v4, 0x28

    new-array v4, v4, [B

    fill-array-data v4, :array_8c

    new-array v5, v3, [B

    fill-array-data v5, :array_a4

    invoke-static {v4, v5}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v0, v2, v4}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    iget-object v2, p0, Lcom/github/catvod/spider/appysv2/b/x;->f:Lcom/github/catvod/spider/appysv2/d/c;

    invoke-virtual {v2}, Lcom/github/catvod/spider/appysv2/d/c;->c()Lcom/github/catvod/spider/appysv2/d/p;

    move-result-object v2

    invoke-virtual {v2}, Lcom/github/catvod/spider/appysv2/d/p;->e()Z

    move-result v2

    if-eqz v2, :cond_67

    new-array v1, v1, [B

    fill-array-data v1, :array_ac

    new-array v2, v3, [B

    fill-array-data v2, :array_b8

    invoke-static {v1, v2}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v1

    iget-object v2, p0, Lcom/github/catvod/spider/appysv2/b/x;->f:Lcom/github/catvod/spider/appysv2/d/c;

    invoke-virtual {v2}, Lcom/github/catvod/spider/appysv2/d/c;->c()Lcom/github/catvod/spider/appysv2/d/p;

    move-result-object v2

    invoke-virtual {v2}, Lcom/github/catvod/spider/appysv2/d/p;->c()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v1, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_67
    return-object v0

    :array_68
    .array-data 1
        0x1at
        0x38t
        0x59t
        0x27t
        -0x1ft
        -0x34t
        -0x32t
        0x48t
        0x16t
        0x7at
        0x41t
        0x2at
        -0x12t
    .end array-data

    nop

    :array_74
    .array-data 1
        0x62t
        0x15t
        0x2at
        0x4ft
        -0x80t
        -0x42t
        -0x55t
        0x65t
    .end array-data

    :array_7c
    .array-data 1
        0xct
        0x2bt
        -0x4et
        -0x21t
        -0x50t
        0x6t
        -0x27t
        0x18t
    .end array-data

    :array_84
    .array-data 1
        0x54t
        0x6t
        -0xft
        -0x42t
        -0x22t
        0x67t
        -0x55t
        0x61t
    .end array-data

    :array_8c
    .array-data 1
        -0x59t
        0x4bt
        0x17t
        -0x36t
        -0x5ct
        0x31t
        0x49t
        0x1t
        -0x56t
        0x43t
        0xct
        -0x40t
        -0x5dt
        0x21t
        0x58t
        0x21t
        -0x4ct
        0x57t
        0x43t
        -0x32t
        -0x52t
        0x37t
        0x1dt
        0x36t
        -0x5ft
        0xbt
        0x8t
        -0x36t
        -0x48t
        0x36t
        0x1dt
        0x2ft
        -0x56t
        0x1at
        0x8t
        -0x65t
        -0x1ct
        0x76t
        0x5at
        0x71t
    .end array-data

    :array_a4
    .array-data 1
        -0x3ct
        0x27t
        0x7et
        -0x51t
        -0x36t
        0x45t
        0x74t
        0x40t
    .end array-data

    :array_ac
    .array-data 1
        -0x5dt
        -0x79t
        0x73t
        -0x45t
        0x3et
        -0x5at
        -0x3dt
        -0x71t
        -0x5dt
        -0x7at
        0x6et
        -0x44t
        0x3ft
    .end array-data

    nop

    :array_b8
    .array-data 1
        -0x3et
        -0xet
        0x7t
        -0x2dt
        0x51t
        -0x2ct
        -0x56t
        -0xbt
    .end array-data
.end method

.method private u(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    .registers 21

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move-object/from16 v2, p2

    move-object/from16 v3, p3

    .line 1
    invoke-virtual/range {p0 .. p2}, Lcom/github/catvod/spider/appysv2/b/x;->y(Ljava/lang/String;Ljava/lang/String;)Lcom/github/catvod/spider/appysv2/d/j;

    move-result-object v4

    const/4 v5, 0x0

    invoke-direct {v0, v4, v1, v2, v5}, Lcom/github/catvod/spider/appysv2/b/x;->v(Lcom/github/catvod/spider/appysv2/d/j;Ljava/lang/String;Ljava/lang/String;Z)Ljava/util/List;

    move-result-object v4

    new-instance v6, Ljava/util/HashMap;

    invoke-direct {v6}, Ljava/util/HashMap;-><init>()V

    const/4 v7, 0x0

    :goto_17
    move-object v8, v4

    check-cast v8, Ljava/util/ArrayList;

    invoke-virtual {v8}, Ljava/util/ArrayList;->size()I

    move-result v9

    if-ge v7, v9, :cond_34

    invoke-virtual {v8, v7}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v9

    check-cast v9, Ljava/lang/String;

    add-int/lit8 v10, v7, 0x1

    invoke-virtual {v8, v10}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v8

    check-cast v8, Ljava/lang/String;

    invoke-virtual {v6, v9, v8}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    add-int/lit8 v7, v7, 0x2

    goto :goto_17

    :cond_34
    invoke-virtual {v6, v3}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/lang/String;

    .line 2
    invoke-virtual/range {p0 .. p0}, Lcom/github/catvod/spider/appysv2/b/x;->s()Ljava/util/HashMap;

    move-result-object v6

    invoke-static {v4, v6}, Lcom/github/catvod/spider/appysv2/n/c;->m(Ljava/lang/String;Ljava/util/Map;)Ljava/lang/String;

    move-result-object v6

    const-string v7, "4D"

    invoke-static {v7}, Lcom/github/catvod/spider/appysv2/KKB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v6, v7}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v6

    new-instance v8, Ljava/util/ArrayList;

    invoke-direct {v8}, Ljava/util/ArrayList;-><init>()V

    new-instance v9, Ljava/util/HashMap;

    invoke-direct {v9}, Ljava/util/HashMap;-><init>()V

    new-instance v10, Ljava/lang/StringBuilder;

    invoke-direct {v10}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v11, 0x1

    new-array v12, v11, [B

    const/16 v13, 0x5b

    aput-byte v13, v12, v5

    const/16 v13, 0x8

    new-array v14, v13, [B

    fill-array-data v14, :array_11e

    invoke-static {v12, v14}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v12

    invoke-virtual {v4, v12}, Ljava/lang/String;->lastIndexOf(Ljava/lang/String;)I

    move-result v12

    invoke-virtual {v4, v5, v12}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v10, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    new-array v4, v11, [B

    const/16 v11, -0x1b

    aput-byte v11, v4, v5

    new-array v5, v13, [B

    fill-array-data v5, :array_126

    .line 3
    invoke-static {v4, v5, v10}, Lcom/github/catvod/spider/appysv2/b/t;->a([B[BLjava/lang/StringBuilder;)Ljava/lang/String;

    move-result-object v4

    .line 4
    array-length v5, v6

    const/4 v10, 0x0

    const/4 v11, 0x0

    :goto_8a
    if-ge v10, v5, :cond_113

    aget-object v12, v6, v10

    const/16 v14, 0xd

    new-array v14, v14, [B

    fill-array-data v14, :array_12e

    new-array v15, v13, [B

    fill-array-data v15, :array_13a

    invoke-static {v14, v15}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v14

    invoke-virtual {v12, v14}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v14

    if-eqz v14, :cond_106

    invoke-static {v11}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v14

    new-instance v15, Ljava/lang/StringBuilder;

    invoke-direct {v15}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v15, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v15, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v15}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v12

    invoke-virtual {v9, v14, v12}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v12, 0x4

    new-array v12, v12, [B

    fill-array-data v12, :array_142

    new-array v13, v13, [B

    fill-array-data v13, :array_148

    invoke-static {v12, v13}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v12

    invoke-static {v11}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v13

    .line 5
    new-instance v14, Ljava/lang/StringBuilder;

    invoke-direct {v14}, Ljava/lang/StringBuilder;-><init>()V

    invoke-static {}, Lcom/github/catvod/spider/Proxy;->getUrl()Ljava/lang/String;

    move-result-object v15

    invoke-virtual {v14, v15}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v15, 0x48

    new-array v15, v15, [B

    fill-array-data v15, :array_150

    move-object/from16 v16, v4

    const/16 v4, 0x8

    new-array v4, v4, [B

    fill-array-data v4, :array_178

    .line 6
    invoke-static {v15, v4, v14}, Lcom/github/catvod/spider/appysv2/b/t;->a([B[BLjava/lang/StringBuilder;)Ljava/lang/String;

    move-result-object v4

    const/4 v14, 0x5

    new-array v14, v14, [Ljava/lang/Object;

    const/4 v15, 0x0

    aput-object v12, v14, v15

    const/4 v12, 0x1

    aput-object v1, v14, v12

    const/4 v12, 0x2

    aput-object v2, v14, v12

    const/4 v12, 0x3

    aput-object v3, v14, v12

    const/4 v12, 0x4

    aput-object v13, v14, v12

    .line 7
    invoke-static {v4, v14}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v12

    add-int/lit8 v11, v11, 0x1

    goto :goto_108

    :cond_106
    move-object/from16 v16, v4

    .line 8
    :goto_108
    invoke-virtual {v8, v12}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/lit8 v10, v10, 0x1

    const/16 v13, 0x8

    move-object/from16 v4, v16

    goto/16 :goto_8a

    :cond_113
    iget-object v1, v0, Lcom/github/catvod/spider/appysv2/b/x;->a:Ljava/util/HashMap;

    invoke-virtual {v1, v2, v9}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    invoke-static {v7, v8}, Landroid/text/TextUtils;->join(Ljava/lang/CharSequence;Ljava/lang/Iterable;)Ljava/lang/String;

    move-result-object v1

    return-object v1

    nop

    :array_11e
    .array-data 1
        0x74t
        0x10t
        0x51t
        -0x3dt
        0x7ft
        -0x63t
        0x22t
        0x77t
    .end array-data

    :array_126
    .array-data 1
        -0x36t
        0x35t
        -0x1et
        0x66t
        -0x5t
        -0x62t
        0x0t
        0xet
    .end array-data

    :array_12e
    .array-data 1
        0x49t
        -0x63t
        -0x1bt
        -0x80t
        -0x3et
        0x56t
        0x2at
        0x1at
        0x41t
        -0x27t
        -0x8t
        -0x6at
        -0x3et
    .end array-data

    nop

    :array_13a
    .array-data 1
        0x31t
        -0x50t
        -0x76t
        -0xdt
        -0x4ft
        0x7bt
        0x4ft
        0x62t
    .end array-data

    :array_142
    .array-data 1
        0x3et
        -0x2ct
        0xat
        0x61t
    .end array-data

    :array_148
    .array-data 1
        0x53t
        -0x19t
        0x7ft
        0x59t
        -0x19t
        0x79t
        -0x47t
        0x6bt
    .end array-data

    :array_150
    .array-data 1
        0x8t
        0x21t
        -0x16t
        -0x16t
        -0x60t
        0xat
        -0x67t
        0x5ct
        0x43t
        0x3ct
        -0xbt
        -0x4et
        -0x4t
        0x10t
        -0x67t
        0x1et
        0x52t
        0x2at
        -0x5dt
        -0x4ct
        -0x60t
        0x12t
        -0x6bt
        0x47t
        0x12t
        0x36t
        -0x5dt
        -0x5ct
        -0x57t
        0x7t
        -0x7et
        0x1ft
        0x7et
        0x21t
        -0x48t
        -0xet
        -0x4et
        0x40t
        -0x6at
        0x13t
        0x5bt
        0x20t
        -0x34t
        -0x4dt
        -0x4t
        0x43t
        -0x7dt
        0x5ct
        0x43t
        0x20t
        -0x18t
        -0x59t
        -0x53t
        0x7t
        -0x7ct
        0x1ft
        0x7et
        0x21t
        -0x48t
        -0xet
        -0x4et
        0x40t
        -0x63t
        0x1ft
        0x53t
        0x2ct
        -0x1ct
        -0x62t
        -0x5bt
        0x5bt
        -0x2bt
        0x9t
    .end array-data

    :array_178
    .array-data 1
        0x37t
        0x45t
        -0x7bt
        -0x29t
        -0x3ft
        0x66t
        -0x10t
        0x7at
    .end array-data
.end method

.method private v(Lcom/github/catvod/spider/appysv2/d/j;Ljava/lang/String;Ljava/lang/String;Z)Ljava/util/List;
    .registers 13
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/github/catvod/spider/appysv2/d/j;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Z)",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    invoke-virtual {p1}, Lcom/github/catvod/spider/appysv2/d/j;->b()Ljava/util/List;

    move-result-object p1

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result v1

    const/4 v2, 0x1

    sub-int/2addr v1, v2

    :goto_f
    if-ltz v1, :cond_7a

    invoke-interface {p1, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lcom/github/catvod/spider/appysv2/d/k;

    invoke-virtual {v3}, Lcom/github/catvod/spider/appysv2/d/k;->b()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v0, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    if-eqz p4, :cond_6a

    const/4 v3, 0x7

    new-array v3, v3, [B

    fill-array-data v3, :array_7c

    const/16 v4, 0x8

    new-array v5, v4, [B

    fill-array-data v5, :array_84

    invoke-static {v3, v5}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v3

    invoke-interface {p1, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Lcom/github/catvod/spider/appysv2/d/k;

    invoke-virtual {v5}, Lcom/github/catvod/spider/appysv2/d/k;->b()Ljava/lang/String;

    move-result-object v5

    .line 1
    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    invoke-static {}, Lcom/github/catvod/spider/Proxy;->getUrl()Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v7, 0x3d

    new-array v7, v7, [B

    fill-array-data v7, :array_8c

    new-array v4, v4, [B

    fill-array-data v4, :array_b0

    .line 2
    invoke-static {v7, v4, v6}, Lcom/github/catvod/spider/appysv2/b/t;->a([B[BLjava/lang/StringBuilder;)Ljava/lang/String;

    move-result-object v4

    const/4 v6, 0x4

    new-array v6, v6, [Ljava/lang/Object;

    const/4 v7, 0x0

    aput-object v3, v6, v7

    aput-object p2, v6, v2

    const/4 v3, 0x2

    aput-object p3, v6, v3

    const/4 v3, 0x3

    aput-object v5, v6, v3

    .line 3
    invoke-static {v4, v6}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v3

    goto :goto_74

    .line 4
    :cond_6a
    invoke-interface {p1, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lcom/github/catvod/spider/appysv2/d/k;

    invoke-virtual {v3}, Lcom/github/catvod/spider/appysv2/d/k;->c()Ljava/lang/String;

    move-result-object v3

    :goto_74
    invoke-virtual {v0, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/lit8 v1, v1, -0x1

    goto :goto_f

    :cond_7a
    return-object v0

    nop

    :array_7c
    .array-data 1
        -0x46t
        0x20t
        0x6et
        0x52t
        -0x75t
        -0x33t
        0x71t
    .end array-data

    :array_84
    .array-data 1
        -0x36t
        0x52t
        0xbt
        0x24t
        -0x1et
        -0x58t
        0x6t
        -0x46t
    .end array-data

    :array_8c
    .array-data 1
        0x17t
        0x11t
        0x42t
        -0x7ft
        -0x60t
        0x1et
        -0x57t
        0x29t
        0x5ct
        0xct
        0x5dt
        -0x27t
        -0x4t
        0x4t
        -0x57t
        0x6bt
        0x4dt
        0x1at
        0xbt
        -0x21t
        -0x60t
        0x6t
        -0x5bt
        0x32t
        0xdt
        0x6t
        0xbt
        -0x31t
        -0x57t
        0x13t
        -0x4et
        0x6at
        0x61t
        0x11t
        0x10t
        -0x67t
        -0x4et
        0x54t
        -0x5at
        0x66t
        0x44t
        0x10t
        0x64t
        -0x28t
        -0x4t
        0x57t
        -0x4dt
        0x29t
        0x5ct
        0x10t
        0x40t
        -0x34t
        -0x53t
        0x13t
        -0x4ct
        0x6at
        0x61t
        0x11t
        0x10t
        -0x67t
        -0x4et
    .end array-data

    nop

    :array_b0
    .array-data 1
        0x28t
        0x75t
        0x2dt
        -0x44t
        -0x3ft
        0x72t
        -0x40t
        0xft
    .end array-data
.end method


# virtual methods
.method public final E([Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    .registers 11

    const/4 v0, 0x1

    new-array v1, v0, [B

    const/4 v2, 0x0

    const/16 v3, -0x78

    aput-byte v3, v1, v2

    const/16 v3, 0x8

    new-array v4, v3, [B

    fill-array-data v4, :array_10c

    invoke-static {v1, v4}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {p2, v1}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v1

    aget-object v1, v1, v2

    const/16 v4, 0xc

    new-array v5, v4, [B

    fill-array-data v5, :array_114

    new-array v6, v3, [B

    fill-array-data v6, :array_11e

    invoke-static {v5, v6}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v1, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_84

    .line 1
    aget-object p2, p1, v2

    aget-object v1, p1, v0

    invoke-virtual {p0, p2, v1}, Lcom/github/catvod/spider/appysv2/b/x;->y(Ljava/lang/String;Ljava/lang/String;)Lcom/github/catvod/spider/appysv2/d/j;

    move-result-object p2

    aget-object v1, p1, v2

    aget-object v2, p1, v0

    invoke-direct {p0, p2, v1, v2, v0}, Lcom/github/catvod/spider/appysv2/b/x;->v(Lcom/github/catvod/spider/appysv2/d/j;Ljava/lang/String;Ljava/lang/String;Z)Ljava/util/List;

    move-result-object v0

    invoke-virtual {p0, p1}, Lcom/github/catvod/spider/appysv2/b/x;->x([Ljava/lang/String;)Ljava/util/List;

    move-result-object p1

    .line 2
    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    invoke-virtual {p2}, Lcom/github/catvod/spider/appysv2/d/j;->a()Ljava/util/List;

    move-result-object p2

    invoke-interface {p2}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object p2

    :goto_50
    invoke-interface {p2}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_64

    invoke-interface {p2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcom/github/catvod/spider/appysv2/d/k;

    invoke-virtual {v2}, Lcom/github/catvod/spider/appysv2/d/k;->a()Lcom/github/catvod/spider/appysv2/c/i;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_50

    .line 3
    :cond_64
    move-object p2, p1

    check-cast p2, Ljava/util/ArrayList;

    invoke-virtual {p2, v1}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    .line 4
    new-instance p2, Lcom/github/catvod/spider/appysv2/c/h;

    invoke-direct {p2}, Lcom/github/catvod/spider/appysv2/c/h;-><init>()V

    .line 5
    invoke-virtual {p2, v0}, Lcom/github/catvod/spider/appysv2/c/h;->z(Ljava/util/List;)Lcom/github/catvod/spider/appysv2/c/h;

    invoke-virtual {p2}, Lcom/github/catvod/spider/appysv2/c/h;->h()Lcom/github/catvod/spider/appysv2/c/h;

    invoke-virtual {p2, p1}, Lcom/github/catvod/spider/appysv2/c/h;->x(Ljava/util/List;)Lcom/github/catvod/spider/appysv2/c/h;

    invoke-virtual {p0}, Lcom/github/catvod/spider/appysv2/b/x;->s()Ljava/util/HashMap;

    move-result-object p1

    invoke-virtual {p2, p1}, Lcom/github/catvod/spider/appysv2/c/h;->f(Ljava/util/Map;)Lcom/github/catvod/spider/appysv2/c/h;

    .line 6
    invoke-virtual {p2}, Lcom/github/catvod/spider/appysv2/c/h;->toString()Ljava/lang/String;

    move-result-object p1

    return-object p1

    :cond_84
    new-array v1, v0, [B

    const/16 v5, 0x74

    aput-byte v5, v1, v2

    new-array v5, v3, [B

    .line 7
    fill-array-data v5, :array_126

    invoke-static {v1, v5}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {p2, v1}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object p2

    aget-object p2, p2, v2

    new-array v1, v4, [B

    fill-array-data v1, :array_12e

    new-array v4, v3, [B

    fill-array-data v4, :array_138

    invoke-static {v1, v4}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {p2, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result p2

    if-eqz p2, :cond_108

    .line 8
    new-instance p2, Lcom/github/catvod/spider/appysv2/c/h;

    invoke-direct {p2}, Lcom/github/catvod/spider/appysv2/c/h;-><init>()V

    const/4 v1, 0x4

    new-array v1, v1, [B

    .line 9
    fill-array-data v1, :array_140

    new-array v4, v3, [B

    fill-array-data v4, :array_146

    invoke-static {v1, v4}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v1

    aget-object v4, p1, v2

    aget-object v5, p1, v0

    .line 10
    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    invoke-static {}, Lcom/github/catvod/spider/Proxy;->getUrl()Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v7, 0x2f

    new-array v7, v7, [B

    fill-array-data v7, :array_14e

    new-array v3, v3, [B

    fill-array-data v3, :array_16a

    .line 11
    invoke-static {v7, v3, v6}, Lcom/github/catvod/spider/appysv2/b/t;->a([B[BLjava/lang/StringBuilder;)Ljava/lang/String;

    move-result-object v3

    const/4 v6, 0x3

    new-array v6, v6, [Ljava/lang/Object;

    aput-object v1, v6, v2

    aput-object v4, v6, v0

    const/4 v0, 0x2

    aput-object v5, v6, v0

    .line 12
    invoke-static {v3, v6}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    .line 13
    invoke-virtual {p2, v0}, Lcom/github/catvod/spider/appysv2/c/h;->y(Ljava/lang/String;)Lcom/github/catvod/spider/appysv2/c/h;

    invoke-virtual {p2}, Lcom/github/catvod/spider/appysv2/c/h;->j()Lcom/github/catvod/spider/appysv2/c/h;

    invoke-virtual {p0, p1}, Lcom/github/catvod/spider/appysv2/b/x;->x([Ljava/lang/String;)Ljava/util/List;

    move-result-object p1

    invoke-virtual {p2, p1}, Lcom/github/catvod/spider/appysv2/c/h;->x(Ljava/util/List;)Lcom/github/catvod/spider/appysv2/c/h;

    invoke-virtual {p0}, Lcom/github/catvod/spider/appysv2/b/x;->s()Ljava/util/HashMap;

    move-result-object p1

    invoke-virtual {p2, p1}, Lcom/github/catvod/spider/appysv2/c/h;->f(Ljava/util/Map;)Lcom/github/catvod/spider/appysv2/c/h;

    .line 14
    invoke-virtual {p2}, Lcom/github/catvod/spider/appysv2/c/h;->toString()Ljava/lang/String;

    move-result-object p1

    return-object p1

    :cond_108
    const-string p1, ""

    return-object p1

    nop

    :array_10c
    .array-data 1
        -0x55t
        0x77t
        -0x80t
        -0x61t
        0x4at
        0x6bt
        0x6ft
        0x28t
    .end array-data

    :array_114
    .array-data 1
        -0x7dt
        0x57t
        -0x55t
        -0x7t
        0x54t
        0x1bt
        0x2at
        0x5ct
        -0x3ct
        0x28t
        -0x80t
        -0x55t
    .end array-data

    :array_11e
    .array-data 1
        0x6at
        -0x31t
        0x14t
        0x10t
        -0x2dt
        -0x69t
        -0x34t
        -0x3bt
    .end array-data

    :array_126
    .array-data 1
        0x57t
        0x6bt
        0x3ct
        0x29t
        0x30t
        -0x51t
        -0x2t
        -0x72t
    .end array-data

    :array_12e
    .array-data 1
        0x5ct
        0x20t
        -0x49t
        -0x1et
        0x7t
        -0x3bt
        0x4et
        0x3bt
        0x2at
        0x5ft
        -0x64t
        -0x50t
    .end array-data

    :array_138
    .array-data 1
        -0x4bt
        -0x48t
        0x8t
        0xbt
        -0x80t
        0x49t
        -0x55t
        -0x4bt
    .end array-data

    :array_140
    .array-data 1
        0x2ft
        0x22t
        -0x56t
        0xct
    .end array-data

    :array_146
    .array-data 1
        0x40t
        0x52t
        -0x31t
        0x62t
        0x41t
        0x1ft
        -0x33t
        0x7et
    .end array-data

    :array_14e
    .array-data 1
        -0x53t
        0x53t
        0x7ft
        0x41t
        0x77t
        -0x63t
        0x19t
        -0x7t
        -0x1at
        0x4et
        0x60t
        0x19t
        0x2bt
        -0x79t
        0x19t
        -0x45t
        -0x9t
        0x58t
        0x36t
        0x1ft
        0x77t
        -0x7bt
        0x15t
        -0x1et
        -0x49t
        0x44t
        0x36t
        0xft
        0x7et
        -0x70t
        0x2t
        -0x46t
        -0x25t
        0x53t
        0x2dt
        0x59t
        0x65t
        -0x29t
        0x16t
        -0x4at
        -0x2t
        0x52t
        0x59t
        0x18t
        0x2bt
        -0x2ct
        0x3t
    .end array-data

    :array_16a
    .array-data 1
        -0x6et
        0x37t
        0x10t
        0x7ct
        0x16t
        -0xft
        0x70t
        -0x21t
    .end array-data
.end method

.method public final G(Ljava/util/Map;)[Ljava/lang/Object;
    .registers 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;)[",
            "Ljava/lang/Object;"
        }
    .end annotation

    const/4 v0, 0x6

    new-array v0, v0, [B

    fill-array-data v0, :array_6c

    const/16 v1, 0x8

    new-array v2, v1, [B

    fill-array-data v2, :array_74

    invoke-static {v0, v2}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-interface {p1, v0}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    const/4 v2, 0x7

    new-array v2, v2, [B

    fill-array-data v2, :array_7c

    new-array v3, v1, [B

    fill-array-data v3, :array_84

    invoke-static {v2, v3}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-interface {p1, v2}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/lang/String;

    invoke-virtual {p0, p1, v0}, Lcom/github/catvod/spider/appysv2/b/x;->r(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    invoke-direct {p0}, Lcom/github/catvod/spider/appysv2/b/x;->t()Ljava/util/HashMap;

    move-result-object v0

    invoke-static {p1, v0}, Lcom/github/catvod/spider/appysv2/n/c;->e(Ljava/lang/String;Ljava/util/Map;)Lokhttp3/Response;

    move-result-object p1

    invoke-virtual {p1}, Lokhttp3/Response;->body()Lokhttp3/ResponseBody;

    move-result-object p1

    invoke-virtual {p1}, Lokhttp3/ResponseBody;->bytes()[B

    move-result-object p1

    invoke-static {p1}, Lcom/github/catvod/spider/appysv2/p/C;->t([B)[B

    move-result-object p1

    const/4 v0, 0x3

    new-array v0, v0, [Ljava/lang/Object;

    const/16 v2, 0xc8

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    const/4 v3, 0x0

    aput-object v2, v0, v3

    const/16 v2, 0x18

    new-array v2, v2, [B

    fill-array-data v2, :array_8c

    new-array v1, v1, [B

    fill-array-data v1, :array_9c

    invoke-static {v2, v1}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v1

    const/4 v2, 0x1

    aput-object v1, v0, v2

    new-instance v1, Ljava/io/ByteArrayInputStream;

    invoke-direct {v1, p1}, Ljava/io/ByteArrayInputStream;-><init>([B)V

    const/4 p1, 0x2

    aput-object v1, v0, p1

    return-object v0

    :array_6c
    .array-data 1
        0x47t
        0x4at
        -0x10t
        -0x39t
        0x4at
        -0x5ft
    .end array-data

    nop

    :array_74
    .array-data 1
        0x21t
        0x23t
        -0x64t
        -0x5et
        0x3t
        -0x3bt
        0xat
        0x7ct
    .end array-data

    :array_7c
    .array-data 1
        0x65t
        0x38t
        0x50t
        -0x52t
        -0x80t
        0x75t
        -0x3et
    .end array-data

    :array_84
    .array-data 1
        0x16t
        0x50t
        0x31t
        -0x24t
        -0x1bt
        0x3ct
        -0x5at
        0xct
    .end array-data

    :array_8c
    .array-data 1
        -0x6dt
        0x2at
        0x7et
        -0x5ft
        0x36t
        0x29t
        0x40t
        0x33t
        -0x65t
        0x35t
        0x60t
        -0x1et
        0x30t
        0x29t
        0x55t
        0x22t
        -0x7at
        0x77t
        0x7dt
        -0x47t
        0x2dt
        0x2ft
        0x40t
        0x2at
    .end array-data

    :array_9c
    .array-data 1
        -0xet
        0x5at
        0xet
        -0x33t
        0x5ft
        0x4at
        0x21t
        0x47t
    .end array-data
.end method

.method public final H(Ljava/util/Map;)[Ljava/lang/Object;
    .registers 19
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;)[",
            "Ljava/lang/Object;"
        }
    .end annotation

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    iget-object v2, v0, Lcom/github/catvod/spider/appysv2/b/x;->i:Landroid/app/AlertDialog;

    if-eqz v2, :cond_10

    invoke-virtual {v2}, Landroid/app/Dialog;->isShowing()Z

    move-result v2

    if-eqz v2, :cond_10

    const/4 v1, 0x0

    return-object v1

    :cond_10
    const/16 v2, 0xa

    new-array v3, v2, [B

    fill-array-data v3, :array_1da

    const/16 v4, 0x8

    new-array v5, v4, [B

    fill-array-data v5, :array_1e4

    invoke-static {v3, v5}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v3

    invoke-interface {v1, v3}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/lang/String;

    const/4 v5, 0x7

    new-array v6, v5, [B

    fill-array-data v6, :array_1ec

    new-array v7, v4, [B

    fill-array-data v7, :array_1f4

    invoke-static {v6, v7}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v6

    invoke-interface {v1, v6}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Ljava/lang/String;

    new-array v7, v5, [B

    fill-array-data v7, :array_1fc

    new-array v8, v4, [B

    fill-array-data v8, :array_204

    invoke-static {v7, v8}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v7

    invoke-interface {v1, v7}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Ljava/lang/String;

    const/4 v8, 0x6

    new-array v9, v8, [B

    fill-array-data v9, :array_20c

    new-array v10, v4, [B

    fill-array-data v10, :array_214

    invoke-static {v9, v10}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v9

    invoke-interface {v1, v9}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v9

    check-cast v9, Ljava/lang/String;

    const/4 v10, 0x4

    new-array v11, v10, [B

    fill-array-data v11, :array_21c

    new-array v12, v4, [B

    fill-array-data v12, :array_222

    invoke-static {v11, v12}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v11

    invoke-interface {v1, v11}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v11

    check-cast v11, Ljava/lang/String;

    new-array v12, v5, [B

    fill-array-data v12, :array_22a

    new-array v13, v4, [B

    fill-array-data v13, :array_232

    invoke-static {v12, v13}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v12

    invoke-virtual {v12, v11}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v12

    const/4 v13, 0x1

    const/4 v14, 0x0

    const/4 v15, 0x3

    const/16 v16, 0x2

    if-eqz v12, :cond_c0

    new-array v1, v15, [Ljava/lang/Object;

    const/16 v2, 0xc8

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    aput-object v2, v1, v14

    const/16 v2, 0x1d

    new-array v2, v2, [B

    fill-array-data v2, :array_23a

    new-array v4, v4, [B

    fill-array-data v4, :array_24e

    invoke-static {v2, v4}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v2

    aput-object v2, v1, v13

    new-instance v2, Ljava/io/ByteArrayInputStream;

    invoke-direct {v0, v6, v9, v3}, Lcom/github/catvod/spider/appysv2/b/x;->u(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/String;->getBytes()[B

    move-result-object v3

    invoke-direct {v2, v3}, Ljava/io/ByteArrayInputStream;-><init>([B)V

    aput-object v2, v1, v16

    return-object v1

    :cond_c0
    new-array v12, v10, [B

    fill-array-data v12, :array_256

    new-array v15, v4, [B

    fill-array-data v15, :array_25c

    invoke-static {v12, v15}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v12

    invoke-virtual {v12, v11}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v12

    const/4 v15, 0x5

    if-eqz v12, :cond_da

    invoke-virtual {v0, v6, v9}, Lcom/github/catvod/spider/appysv2/b/x;->r(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    goto :goto_13a

    :cond_da
    new-array v12, v15, [B

    fill-array-data v12, :array_264

    new-array v2, v4, [B

    fill-array-data v2, :array_26c

    invoke-static {v12, v2}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v2, v11}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_f3

    invoke-virtual {v0, v6, v9}, Lcom/github/catvod/spider/appysv2/b/x;->w(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    goto :goto_13a

    :cond_f3
    new-array v2, v10, [B

    fill-array-data v2, :array_274

    new-array v12, v4, [B

    fill-array-data v12, :array_27a

    invoke-static {v2, v12}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v2, v11}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_138

    iget-object v2, v0, Lcom/github/catvod/spider/appysv2/b/x;->e:Ljava/util/concurrent/locks/ReentrantLock;

    invoke-virtual {v2}, Ljava/util/concurrent/locks/ReentrantLock;->lock()V

    iget-object v2, v0, Lcom/github/catvod/spider/appysv2/b/x;->a:Ljava/util/HashMap;

    invoke-virtual {v2, v9}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/util/Map;

    invoke-interface {v2, v7}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/String;

    invoke-static {v2}, Lcom/github/catvod/spider/appysv2/b/x;->A(Ljava/lang/String;)Z

    move-result v11

    if-eqz v11, :cond_131

    invoke-direct {v0, v6, v9, v3}, Lcom/github/catvod/spider/appysv2/b/x;->u(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    iget-object v2, v0, Lcom/github/catvod/spider/appysv2/b/x;->a:Ljava/util/HashMap;

    invoke-virtual {v2, v9}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/util/Map;

    invoke-interface {v2, v7}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/String;

    :cond_131
    move-object v3, v2

    iget-object v2, v0, Lcom/github/catvod/spider/appysv2/b/x;->e:Ljava/util/concurrent/locks/ReentrantLock;

    invoke-virtual {v2}, Ljava/util/concurrent/locks/ReentrantLock;->unlock()V

    goto :goto_13a

    :cond_138
    const-string v3, ""

    :goto_13a
    new-instance v2, Ljava/util/TreeMap;

    sget-object v6, Ljava/lang/String;->CASE_INSENSITIVE_ORDER:Ljava/util/Comparator;

    invoke-direct {v2, v6}, Ljava/util/TreeMap;-><init>(Ljava/util/Comparator;)V

    new-array v6, v8, [Ljava/lang/String;

    new-array v5, v5, [B

    fill-array-data v5, :array_282

    new-array v7, v4, [B

    fill-array-data v7, :array_28a

    invoke-static {v5, v7}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v5

    aput-object v5, v6, v14

    const/16 v5, 0xc

    new-array v5, v5, [B

    fill-array-data v5, :array_292

    new-array v7, v4, [B

    fill-array-data v7, :array_29c

    invoke-static {v5, v7}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v5

    aput-object v5, v6, v13

    new-array v5, v15, [B

    fill-array-data v5, :array_2a4

    new-array v7, v4, [B

    fill-array-data v7, :array_2ac

    invoke-static {v5, v7}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v5

    aput-object v5, v6, v16

    const/16 v5, 0xa

    new-array v7, v5, [B

    fill-array-data v7, :array_2b4

    new-array v5, v4, [B

    fill-array-data v5, :array_2be

    invoke-static {v7, v5}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v5

    const/4 v7, 0x3

    aput-object v5, v6, v7

    const/16 v5, 0xf

    new-array v5, v5, [B

    fill-array-data v5, :array_2c6

    new-array v7, v4, [B

    fill-array-data v7, :array_2d2

    invoke-static {v5, v7}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v5

    aput-object v5, v6, v10

    const/16 v5, 0xa

    new-array v5, v5, [B

    fill-array-data v5, :array_2da

    new-array v4, v4, [B

    fill-array-data v4, :array_2e4

    invoke-static {v5, v4}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v4

    aput-object v4, v6, v15

    invoke-static {v6}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v4

    invoke-interface/range {p1 .. p1}, Ljava/util/Map;->keySet()Ljava/util/Set;

    move-result-object v5

    invoke-interface {v5}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v5

    :cond_1b8
    :goto_1b8
    invoke-interface {v5}, Ljava/util/Iterator;->hasNext()Z

    move-result v6

    if-eqz v6, :cond_1d4

    invoke-interface {v5}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Ljava/lang/String;

    invoke-interface {v4, v6}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    move-result v7

    if-eqz v7, :cond_1b8

    invoke-interface {v1, v6}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Ljava/lang/String;

    invoke-virtual {v2, v6, v7}, Ljava/util/TreeMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_1b8

    :cond_1d4
    invoke-static {v3, v2}, Lcom/github/catvod/spider/appysv2/p/m;->h(Ljava/lang/String;Ljava/util/Map;)[Ljava/lang/Object;

    move-result-object v1

    return-object v1

    nop

    :array_1da
    .array-data 1
        0x1ct
        -0x68t
        0x3at
        0x22t
        -0x3bt
        -0x20t
        -0x56t
        -0x21t
        0x21t
        -0x67t
    .end array-data

    nop

    :array_1e4
    .array-data 1
        0x68t
        -0x3t
        0x57t
        0x52t
        -0x57t
        -0x7ft
        -0x22t
        -0x46t
    .end array-data

    :array_1ec
    .array-data 1
        -0x73t
        -0x7bt
        -0x2et
        0x2t
        -0x59t
        -0x60t
        0x7et
    .end array-data

    :array_1f4
    .array-data 1
        -0x2t
        -0x13t
        -0x4dt
        0x70t
        -0x3et
        -0x17t
        0x1at
        0x50t
    .end array-data

    :array_1fc
    .array-data 1
        0x1bt
        0x54t
        0x48t
        -0x7at
        -0x48t
        0x42t
        0xat
    .end array-data

    :array_204
    .array-data 1
        0x76t
        0x31t
        0x2ct
        -0x11t
        -0x27t
        0xbt
        0x6et
        0x26t
    .end array-data

    :array_20c
    .array-data 1
        -0x9t
        -0x39t
        -0x68t
        -0x18t
        -0x14t
        -0x29t
    .end array-data

    nop

    :array_214
    .array-data 1
        -0x6ft
        -0x52t
        -0xct
        -0x73t
        -0x5bt
        -0x4dt
        0x18t
        0x1at
    .end array-data

    :array_21c
    .array-data 1
        0x5bt
        -0x14t
        0x63t
        -0x3dt
    .end array-data

    :array_222
    .array-data 1
        0x38t
        -0x73t
        0x17t
        -0x5at
        0x1t
        -0x30t
        0x7at
        0x7ft
    .end array-data

    :array_22a
    .array-data 1
        -0x1et
        -0x3ct
        -0x46t
        -0x5et
        0x30t
        -0x77t
        -0x5dt
    .end array-data

    :array_232
    .array-data 1
        -0x6et
        -0x4at
        -0x21t
        -0x2ct
        0x59t
        -0x14t
        -0x2ct
        0x28t
    .end array-data

    :array_23a
    .array-data 1
        0x23t
        0x34t
        -0xct
        -0xft
        0x2ft
        0x54t
        -0x39t
        0x40t
        0x2bt
        0x2bt
        -0x16t
        -0x4et
        0x30t
        0x59t
        -0x3et
        0x1at
        0x23t
        0x34t
        -0xct
        -0xft
        0x23t
        0x19t
        -0x35t
        0x44t
        0x27t
        0x23t
        -0xft
        -0x11t
        0x2at
    .end array-data

    nop

    :array_24e
    .array-data 1
        0x42t
        0x44t
        -0x7ct
        -0x63t
        0x46t
        0x37t
        -0x5at
        0x34t
    .end array-data

    :array_256
    .array-data 1
        0x75t
        0x61t
        0x18t
        -0x2t
    .end array-data

    :array_25c
    .array-data 1
        0x1at
        0x11t
        0x7dt
        -0x70t
        0x51t
        0x28t
        0xbt
        -0x6et
    .end array-data

    :array_264
    .array-data 1
        0x14t
        0x37t
        0x4et
        -0x3at
        0x5ft
    .end array-data

    nop

    :array_26c
    .array-data 1
        0x67t
        0x5ft
        0x2ft
        -0x4ct
        0x3at
        0x36t
        0x4dt
        -0x14t
    .end array-data

    :array_274
    .array-data 1
        0x79t
        -0x53t
        -0x4t
        -0x6ct
    .end array-data

    :array_27a
    .array-data 1
        0x14t
        -0x62t
        -0x77t
        -0x54t
        -0x17t
        -0x65t
        -0x33t
        0x51t
    .end array-data

    :array_282
    .array-data 1
        0x69t
        0x68t
        0x50t
        0x64t
        -0x7et
        -0x1ct
        -0x4ct
    .end array-data

    :array_28a
    .array-data 1
        0x1bt
        0xdt
        0x36t
        0x1t
        -0x10t
        -0x7ft
        -0x3at
        0xbt
    .end array-data

    :array_292
    .array-data 1
        0x52t
        -0x29t
        -0x5ct
        0x11t
        0x2ct
        -0x6ft
        -0x78t
        -0x29t
        0x5ft
        -0x2bt
        -0x57t
        0x5dt
    .end array-data

    :array_29c
    .array-data 1
        0x3bt
        -0x4ct
        -0x23t
        0x3ct
        0x41t
        -0xct
        -0x4t
        -0x4at
    .end array-data

    :array_2a4
    .array-data 1
        0x65t
        0x51t
        -0x46t
        -0x70t
        0x1ft
    .end array-data

    nop

    :array_2ac
    .array-data 1
        0x17t
        0x30t
        -0x2ct
        -0x9t
        0x7at
        0x18t
        0x7at
        -0x40t
    .end array-data

    :array_2b4
    .array-data 1
        0x79t
        -0x67t
        0x44t
        0x39t
        -0x38t
        -0x2t
        0x3dt
        -0x42t
        0x75t
        -0x68t
    .end array-data

    nop

    :array_2be
    .array-data 1
        0x1at
        -0xat
        0x2at
        0x57t
        -0x53t
        -0x63t
        0x49t
        -0x29t
    .end array-data

    :array_2c6
    .array-data 1
        -0xat
        -0x7t
        -0x79t
        -0x5ft
        -0x7t
        0x6dt
        0x59t
        0x24t
        -0x7t
        -0x7t
        -0x75t
        -0x60t
        -0x20t
        0x77t
        0x13t
    .end array-data

    :array_2d2
    .array-data 1
        -0x69t
        -0x66t
        -0x1ct
        -0x3ct
        -0x77t
        0x19t
        0x74t
        0x41t
    .end array-data

    :array_2da
    .array-data 1
        0x37t
        -0x19t
        0x16t
        0x54t
        0x9t
        -0x77t
        -0x62t
        -0x7ct
        0x2ct
        -0x20t
    .end array-data

    nop

    :array_2e4
    .array-data 1
        0x42t
        -0x6ct
        0x73t
        0x26t
        0x24t
        -0x18t
        -0x7t
        -0x1ft
    .end array-data
.end method

.method public final K()V
    .registers 1

    invoke-static {}, Lcom/github/catvod/spider/Init;->checkPermission()V

    invoke-direct {p0}, Lcom/github/catvod/spider/appysv2/b/x;->I()Z

    return-void
.end method

.method public final L(Ljava/lang/String;)V
    .registers 2

    iput-object p1, p0, Lcom/github/catvod/spider/appysv2/b/x;->h:Ljava/lang/String;

    return-void
.end method

.method public final q()Ljava/io/File;
    .registers 3

    const/4 v0, 0x6

    new-array v0, v0, [B

    fill-array-data v0, :array_16

    const/16 v1, 0x8

    new-array v1, v1, [B

    fill-array-data v1, :array_1e

    invoke-static {v0, v1}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lcom/github/catvod/spider/appysv2/p/a;->n(Ljava/lang/String;)Ljava/io/File;

    move-result-object v0

    return-object v0

    :array_16
    .array-data 1
        -0x3ct
        0x7bt
        0x19t
        0x42t
        -0x5at
        0xdt
    .end array-data

    nop

    :array_1e
    .array-data 1
        -0x5bt
        0x17t
        0x70t
        0x3bt
        -0x2dt
        0x63t
        -0x24t
        -0x77t
    .end array-data
.end method

.method public final r(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    .registers 36

    move-object/from16 v1, p0

    move-object/from16 v0, p2

    const/4 v2, 0x0

    :try_start_5
    iget-object v3, v1, Lcom/github/catvod/spider/appysv2/b/x;->c:Ljava/util/HashMap;

    invoke-virtual {v3, v0}, Ljava/util/HashMap;->containsKey(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_32

    iget-object v3, v1, Lcom/github/catvod/spider/appysv2/b/x;->c:Ljava/util/HashMap;

    invoke-virtual {v3, v0}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v3

    if-eqz v3, :cond_32

    iget-object v3, v1, Lcom/github/catvod/spider/appysv2/b/x;->c:Ljava/util/HashMap;

    invoke-virtual {v3, v0}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/lang/String;

    invoke-static {v3}, Lcom/github/catvod/spider/appysv2/b/x;->A(Ljava/lang/String;)Z

    move-result v3

    if-nez v3, :cond_32

    iget-object v3, v1, Lcom/github/catvod/spider/appysv2/b/x;->c:Ljava/util/HashMap;

    invoke-virtual {v3, v0}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;
    :try_end_2b
    .catch Ljava/lang/Exception; {:try_start_5 .. :try_end_2b} :catch_26a
    .catchall {:try_start_5 .. :try_end_2b} :catchall_268

    new-instance v3, Lcom/github/catvod/spider/appysv2/b/r;

    invoke-direct {v3, v1, v2}, Lcom/github/catvod/spider/appysv2/b/r;-><init>(Ljava/lang/Object;I)V

    goto/16 :goto_275

    :cond_32
    :try_start_32
    invoke-direct/range {p0 .. p1}, Lcom/github/catvod/spider/appysv2/b/x;->J(Ljava/lang/String;)V

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const/16 v4, 0x11

    new-array v5, v4, [B

    const/16 v6, -0x56

    aput-byte v6, v5, v2

    const/16 v6, 0x72

    const/4 v7, 0x1

    aput-byte v6, v5, v7

    const/4 v6, 0x2

    const/16 v8, 0x51

    aput-byte v8, v5, v6

    const/4 v9, 0x3

    const/16 v10, 0x7a

    aput-byte v10, v5, v9

    const/16 v11, -0x42

    const/4 v12, 0x4

    aput-byte v11, v5, v12

    const/16 v11, -0x5d

    const/4 v13, 0x5

    aput-byte v11, v5, v13

    const/16 v14, -0x2f

    const/4 v15, 0x6

    aput-byte v14, v5, v15

    const/16 v16, -0x40

    const/4 v10, 0x7

    aput-byte v16, v5, v10

    const/16 v16, -0x5e

    const/16 v8, 0x8

    aput-byte v16, v5, v8

    const/16 v16, 0x76

    const/16 v18, 0x9

    aput-byte v16, v5, v18

    const/16 v16, 0x41

    const/16 v4, 0xa

    aput-byte v16, v5, v4

    const/16 v16, 0x6b

    const/16 v20, 0xb

    aput-byte v16, v5, v20

    const/16 v16, 0xc

    aput-byte v11, v5, v16

    const/16 v11, -0x48

    const/16 v21, 0xd

    aput-byte v11, v5, v21

    const/16 v11, 0xe

    const/16 v22, -0x6f

    aput-byte v22, v5, v11

    const/16 v23, 0xf

    const/16 v24, -0x7e

    aput-byte v24, v5, v23

    const/16 v25, -0x1d

    const/16 v26, 0x10

    aput-byte v25, v5, v26

    new-array v11, v8, [B

    const/16 v27, -0x33

    aput-byte v27, v11, v2

    const/16 v4, 0x17

    aput-byte v4, v11, v7

    const/16 v28, 0x25

    aput-byte v28, v11, v6

    const/16 v29, 0x3e

    aput-byte v29, v11, v9

    aput-byte v14, v11, v12

    const/16 v14, -0x2c

    aput-byte v14, v11, v13

    const/16 v14, -0x41

    aput-byte v14, v11, v15

    const/16 v14, -0x54

    aput-byte v14, v11, v10

    invoke-static {v5, v11}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-static {v3}, Lcom/github/catvod/crawler/SpiderDebug;->log(Ljava/lang/String;)V

    iget-object v3, v1, Lcom/github/catvod/spider/appysv2/b/x;->d:Ljava/util/ArrayList;

    invoke-direct/range {p0 .. p2}, Lcom/github/catvod/spider/appysv2/b/x;->n(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v3, v2, v5}, Ljava/util/ArrayList;->add(ILjava/lang/Object;)V

    new-instance v3, Lcom/google/gson/JsonObject;

    invoke-direct {v3}, Lcom/google/gson/JsonObject;-><init>()V

    new-array v5, v10, [B

    aput-byte v15, v5, v2

    const/16 v11, 0x61

    aput-byte v11, v5, v7

    const/16 v11, -0x3e

    aput-byte v11, v5, v6

    const/16 v11, 0x74

    aput-byte v11, v5, v9

    const/16 v11, -0x3a

    aput-byte v11, v5, v12

    const/16 v11, -0x76

    aput-byte v11, v5, v13

    const/16 v14, -0x60

    aput-byte v14, v5, v15

    new-array v14, v8, [B

    const/16 v29, 0x60

    aput-byte v29, v14, v2

    aput-byte v8, v14, v7

    const/16 v29, -0x52

    aput-byte v29, v14, v6

    const/16 v19, 0x11

    aput-byte v19, v14, v9

    const/16 v29, -0x67

    aput-byte v29, v14, v12

    aput-byte v25, v14, v13

    const/16 v25, -0x3c

    aput-byte v25, v14, v15

    const/16 v25, -0x23

    aput-byte v25, v14, v10

    invoke-static {v5, v14}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v5

    iget-object v14, v1, Lcom/github/catvod/spider/appysv2/b/x;->d:Ljava/util/ArrayList;

    invoke-virtual {v14, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v14

    check-cast v14, Ljava/lang/String;

    invoke-virtual {v3, v5, v14}, Lcom/google/gson/JsonObject;->addProperty(Ljava/lang/String;Ljava/lang/String;)V

    new-array v5, v8, [B

    const/16 v14, 0x4b

    aput-byte v14, v5, v2

    aput-byte v11, v5, v7

    const/16 v11, 0x4e

    aput-byte v11, v5, v6

    const/16 v11, 0x6c

    aput-byte v11, v5, v9

    const/16 v14, 0x51

    aput-byte v14, v5, v12

    const/16 v14, 0x75

    aput-byte v14, v5, v13

    const/16 v14, 0x56

    aput-byte v14, v5, v15

    const/16 v14, -0x77

    aput-byte v14, v5, v10

    new-array v14, v8, [B

    const/16 v25, 0x2f

    aput-byte v25, v14, v2

    const/16 v25, -0x8

    aput-byte v25, v14, v7

    const/16 v29, 0x27

    aput-byte v29, v14, v6

    const/16 v30, 0x1a

    aput-byte v30, v14, v9

    const/16 v31, 0x34

    aput-byte v31, v14, v12

    const/16 v31, 0x2a

    aput-byte v31, v14, v13

    const/16 v31, 0x3f

    aput-byte v31, v14, v15

    const/16 v31, -0x13

    aput-byte v31, v14, v10

    invoke-static {v5, v14}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v5

    iget-object v14, v1, Lcom/github/catvod/spider/appysv2/b/x;->f:Lcom/github/catvod/spider/appysv2/d/c;

    invoke-virtual {v14}, Lcom/github/catvod/spider/appysv2/d/c;->a()Lcom/github/catvod/spider/appysv2/d/g;

    move-result-object v14

    invoke-virtual {v14}, Lcom/github/catvod/spider/appysv2/d/g;->a()Ljava/lang/String;

    move-result-object v14

    invoke-virtual {v3, v5, v14}, Lcom/google/gson/JsonObject;->addProperty(Ljava/lang/String;Ljava/lang/String;)V

    const/16 v5, 0xa

    new-array v14, v5, [B

    const/16 v5, -0xc

    aput-byte v5, v14, v2

    const/16 v31, 0x14

    aput-byte v31, v14, v7

    const/16 v32, -0x1c

    aput-byte v32, v14, v6

    const/16 v32, 0x73

    aput-byte v32, v14, v9

    const/16 v32, -0x31

    aput-byte v32, v14, v12

    const/16 v32, 0x4c

    aput-byte v32, v14, v13

    aput-byte v28, v14, v15

    aput-byte v20, v14, v10

    aput-byte v5, v14, v8

    aput-byte v23, v14, v18

    new-array v5, v8, [B

    aput-byte v22, v5, v2

    aput-byte v11, v5, v7

    const/16 v11, -0x6c

    aput-byte v11, v5, v6

    aput-byte v30, v5, v9

    const/16 v11, -0x43

    aput-byte v11, v5, v12

    const/16 v22, 0x29

    aput-byte v22, v5, v13

    const/16 v17, 0x7a

    aput-byte v17, v5, v15

    const/16 v22, 0x78

    aput-byte v22, v5, v10

    invoke-static {v14, v5}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v5

    const/16 v14, 0x384

    invoke-static {v14}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v14

    invoke-virtual {v3, v5, v14}, Lcom/google/gson/JsonObject;->addProperty(Ljava/lang/String;Ljava/lang/Number;)V

    new-array v4, v4, [B

    const/16 v5, 0x79

    aput-byte v5, v4, v2

    aput-byte v27, v4, v7

    aput-byte v25, v4, v6

    const/16 v5, 0x49

    aput-byte v5, v4, v9

    const/16 v5, -0x66

    aput-byte v5, v4, v12

    const/16 v5, -0x60

    aput-byte v5, v4, v13

    const/16 v5, -0x29

    aput-byte v5, v4, v15

    const/16 v14, -0x19

    aput-byte v14, v4, v10

    const/16 v14, 0x39

    aput-byte v14, v4, v8

    const/16 v14, -0x26

    aput-byte v14, v4, v18

    const/16 v14, 0xa

    aput-byte v25, v4, v14

    const/16 v14, 0x53

    aput-byte v14, v4, v20

    const/16 v14, -0x68

    aput-byte v14, v4, v16

    const/16 v14, -0x5a

    aput-byte v14, v4, v21

    const/16 v14, -0x34

    const/16 v16, 0xe

    aput-byte v14, v4, v16

    const/16 v14, -0x14

    aput-byte v14, v4, v23

    const/16 v14, 0x7a

    aput-byte v14, v4, v26

    const/16 v14, -0x2e

    const/16 v16, 0x11

    aput-byte v14, v4, v16

    const/16 v14, 0x12

    const/16 v16, -0x4

    aput-byte v16, v4, v14

    const/16 v14, 0x13

    const/16 v16, 0x43

    aput-byte v16, v4, v14

    const/16 v14, -0x77

    aput-byte v14, v4, v31

    const/16 v14, 0x15

    const/16 v16, -0x45

    aput-byte v16, v4, v14

    const/16 v14, 0x16

    aput-byte v5, v4, v14

    new-array v5, v8, [B

    aput-byte v14, v5, v2

    aput-byte v11, v5, v7

    const/16 v8, -0x63

    aput-byte v8, v5, v6

    aput-byte v29, v5, v9

    const/16 v6, -0x24

    aput-byte v6, v5, v12

    const/16 v6, -0x37

    aput-byte v6, v5, v13

    aput-byte v16, v5, v15

    aput-byte v24, v5, v10

    invoke-static {v4, v5}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3}, Lcom/google/gson/JsonElement;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-direct {v1, v4, v3, v7}, Lcom/github/catvod/spider/appysv2/b/x;->D(Ljava/lang/String;Ljava/lang/String;Z)Ljava/lang/String;

    move-result-object v3

    .line 1
    new-instance v4, Lcom/google/gson/Gson;

    invoke-direct {v4}, Lcom/google/gson/Gson;-><init>()V

    const-class v5, Lcom/github/catvod/spider/appysv2/d/f;

    invoke-virtual {v4, v3, v5}, Lcom/google/gson/Gson;->fromJson(Ljava/lang/String;Ljava/lang/Class;)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lcom/github/catvod/spider/appysv2/d/f;

    .line 2
    invoke-virtual {v3}, Lcom/github/catvod/spider/appysv2/d/f;->a()Ljava/lang/String;

    move-result-object v3

    iget-object v4, v1, Lcom/github/catvod/spider/appysv2/b/x;->c:Ljava/util/HashMap;

    invoke-virtual {v4, v0, v3}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_25f
    .catch Ljava/lang/Exception; {:try_start_32 .. :try_end_25f} :catch_26a
    .catchall {:try_start_32 .. :try_end_25f} :catchall_268

    new-instance v0, Lcom/github/catvod/spider/appysv2/b/b;

    invoke-direct {v0, v1, v2}, Lcom/github/catvod/spider/appysv2/b/b;-><init>(Ljava/lang/Object;I)V

    invoke-static {v0}, Lcom/github/catvod/spider/Init;->execute(Ljava/lang/Runnable;)V

    return-object v3

    :catchall_268
    move-exception v0

    goto :goto_279

    :catch_26a
    move-exception v0

    :try_start_26b
    invoke-virtual {v0}, Ljava/lang/Throwable;->printStackTrace()V

    const-string v0, ""
    :try_end_270
    .catchall {:try_start_26b .. :try_end_270} :catchall_268

    new-instance v3, Lcom/github/catvod/spider/appysv2/b/f;

    invoke-direct {v3, v1, v2}, Lcom/github/catvod/spider/appysv2/b/f;-><init>(Ljava/lang/Object;I)V

    .line 3
    :goto_275
    invoke-static {v3}, Lcom/github/catvod/spider/Init;->execute(Ljava/lang/Runnable;)V

    return-object v0

    .line 4
    :goto_279
    new-instance v3, Lcom/github/catvod/spider/appysv2/b/q;

    invoke-direct {v3, v1, v2}, Lcom/github/catvod/spider/appysv2/b/q;-><init>(Lcom/github/catvod/spider/appysv2/b/x;I)V

    invoke-static {v3}, Lcom/github/catvod/spider/Init;->execute(Ljava/lang/Runnable;)V

    throw v0
.end method

.method public final s()Ljava/util/HashMap;
    .registers 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/HashMap<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    new-instance v0, Ljava/util/HashMap;

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    const/16 v1, 0xa

    new-array v1, v1, [B

    fill-array-data v1, :array_4e

    const/16 v2, 0x8

    new-array v3, v2, [B

    fill-array-data v3, :array_58

    invoke-static {v1, v3}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v1

    const/16 v3, 0x6f

    new-array v3, v3, [B

    fill-array-data v3, :array_60

    new-array v4, v2, [B

    fill-array-data v4, :array_9c

    invoke-static {v3, v4}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v0, v1, v3}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v1, 0x7

    new-array v1, v1, [B

    fill-array-data v1, :array_a4

    new-array v3, v2, [B

    fill-array-data v3, :array_ac

    invoke-static {v1, v3}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v1

    const/16 v3, 0x1c

    new-array v3, v3, [B

    fill-array-data v3, :array_b4

    new-array v2, v2, [B

    fill-array-data v2, :array_c6

    invoke-static {v3, v2}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v1, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    return-object v0

    nop

    :array_4e
    .array-data 1
        -0x54t
        -0x67t
        -0x70t
        -0x5t
        -0x54t
        0x5bt
        0x4ft
        -0x3ct
        -0x69t
        -0x62t
    .end array-data

    nop

    :array_58
    .array-data 1
        -0x7t
        -0x16t
        -0xbt
        -0x77t
        -0x7ft
        0x1at
        0x28t
        -0x5ft
    .end array-data

    :array_60
    .array-data 1
        -0x7ft
        0x79t
        -0x37t
        0x56t
        -0x70t
        0x79t
        0x57t
        0x15t
        -0x7t
        0x38t
        -0x7dt
        0x1ft
        -0x2ct
        0x42t
        0x5ft
        0x54t
        -0x58t
        0x79t
        -0x3ct
        0x4ct
        -0x24t
        0x5bt
        0x62t
        0x1at
        -0x3t
        0x26t
        -0x63t
        0xft
        -0x39t
        0x35t
        0x61t
        0x53t
        -0x5et
        0x20t
        -0x79t
        0x4t
        -0x24t
        0x6dt
        0x0t
        0xet
        -0x1bt
        0x36t
        -0xet
        0x4ft
        -0x74t
        0x79t
        0x53t
        0x6dt
        -0x57t
        0x74t
        -0x8t
        0x56t
        -0x78t
        0x3at
        0x3t
        0x9t
        -0x5t
        0x38t
        -0x80t
        0x9t
        -0x24t
        0x3dt
        0x7dt
        0x72t
        -0x68t
        0x5bt
        -0x1t
        0x13t
        -0x24t
        0x79t
        0x5ft
        0x51t
        -0x57t
        0x36t
        -0xct
        0x5at
        -0x61t
        0x7et
        0x59t
        0x13t
        -0x14t
        0x55t
        -0x25t
        0x4dt
        -0x6dt
        0x78t
        0x53t
        0x15t
        -0x3t
        0x27t
        -0x7ct
        0x11t
        -0x34t
        0x3bt
        0x6t
        0x14t
        -0x4t
        0x36t
        -0x20t
        0x5et
        -0x66t
        0x74t
        0x44t
        0x53t
        -0x1dt
        0x23t
        -0x80t
        0x8t
        -0x2et
        0x26t
        0x0t
    .end array-data

    :array_9c
    .array-data 1
        -0x34t
        0x16t
        -0x4dt
        0x3ft
        -0x4t
        0x15t
        0x36t
        0x3at
    .end array-data

    :array_a4
    .array-data 1
        0x4t
        -0xet
        0x7dt
        -0x77t
        0x3ft
        0x12t
        -0x71t
    .end array-data

    :array_ac
    .array-data 1
        0x56t
        -0x69t
        0x1bt
        -0x14t
        0x4dt
        0x77t
        -0x3t
        0x1t
    .end array-data

    :array_b4
    .array-data 1
        0x57t
        0x22t
        -0x32t
        -0x3at
        -0x40t
        0x50t
        -0x1dt
        0x6t
        0x48t
        0x21t
        -0x33t
        -0x68t
        -0x2et
        0x6t
        -0x5bt
        0x50t
        0x4at
        0x38t
        -0x22t
        -0x3ct
        -0x26t
        0x1ct
        -0x57t
        0x7t
        0x5ct
        0x39t
        -0x29t
        -0x67t
    .end array-data

    :array_c6
    .array-data 1
        0x3ft
        0x56t
        -0x46t
        -0x4at
        -0x4dt
        0x6at
        -0x34t
        0x29t
    .end array-data
.end method

.method public final w(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    .registers 41

    move-object/from16 v1, p0

    move-object/from16 v0, p2

    :try_start_4
    iget-object v2, v1, Lcom/github/catvod/spider/appysv2/b/x;->b:Ljava/util/HashMap;

    invoke-virtual {v2, v0}, Ljava/util/HashMap;->containsKey(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_2b

    iget-object v2, v1, Lcom/github/catvod/spider/appysv2/b/x;->b:Ljava/util/HashMap;

    invoke-virtual {v2, v0}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    if-eqz v2, :cond_2b

    iget-object v2, v1, Lcom/github/catvod/spider/appysv2/b/x;->b:Ljava/util/HashMap;

    invoke-virtual {v2, v0}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/String;

    invoke-static {v2}, Lcom/github/catvod/spider/appysv2/b/x;->A(Ljava/lang/String;)Z

    move-result v2

    if-nez v2, :cond_2b

    iget-object v2, v1, Lcom/github/catvod/spider/appysv2/b/x;->b:Ljava/util/HashMap;

    invoke-virtual {v2, v0}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    return-object v0

    :cond_2b
    invoke-direct/range {p0 .. p1}, Lcom/github/catvod/spider/appysv2/b/x;->J(Ljava/lang/String;)V

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/16 v3, 0x16

    new-array v4, v3, [B

    const/4 v5, 0x0

    const/16 v6, -0x7b

    aput-byte v6, v4, v5

    const/16 v7, 0x2c

    const/4 v8, 0x1

    aput-byte v7, v4, v8

    const/4 v7, 0x2

    const/16 v9, -0x37

    aput-byte v9, v4, v7

    const/16 v10, 0x56

    const/4 v11, 0x3

    aput-byte v10, v4, v11

    const/4 v10, 0x4

    const/16 v12, 0x2e

    aput-byte v12, v4, v10

    const/16 v13, 0x68

    const/4 v14, 0x5

    aput-byte v13, v4, v14

    const/16 v15, -0x41

    const/16 v16, 0x6

    aput-byte v15, v4, v16

    const/16 v15, -0x5c

    const/4 v6, 0x7

    aput-byte v15, v4, v6

    const/16 v15, -0x5a

    const/16 v9, 0x8

    aput-byte v15, v4, v9

    const/16 v15, 0x26

    const/16 v18, 0x9

    aput-byte v15, v4, v18

    const/16 v15, -0x36

    const/16 v3, 0xa

    aput-byte v15, v4, v3

    const/16 v19, 0x6b

    const/16 v20, 0xb

    aput-byte v19, v4, v20

    const/16 v19, 0x2a

    const/16 v15, 0xc

    aput-byte v19, v4, v15

    const/16 v19, 0x66

    const/16 v21, 0xd

    aput-byte v19, v4, v21

    const/16 v19, -0x54

    const/16 v22, 0xe

    aput-byte v19, v4, v22

    const/16 v19, -0x5b

    const/16 v23, 0xf

    aput-byte v19, v4, v23

    const/16 v19, -0x49

    const/16 v24, 0x10

    aput-byte v19, v4, v24

    const/16 v25, 0x3b

    const/16 v26, 0x11

    aput-byte v25, v4, v26

    const/16 v27, -0x2f

    const/16 v28, 0x12

    aput-byte v27, v4, v28

    const/16 v27, 0x2b

    const/16 v29, 0x13

    aput-byte v27, v4, v29

    const/16 v27, 0x14

    aput-byte v13, v4, v27

    const/16 v30, 0x27

    const/16 v31, 0x15

    aput-byte v30, v4, v31

    new-array v15, v9, [B

    const/16 v32, -0x1e

    aput-byte v32, v15, v5

    const/16 v32, 0x49

    aput-byte v32, v15, v8

    const/16 v32, -0x43

    aput-byte v32, v15, v7

    aput-byte v14, v15, v11

    const/16 v33, 0x46

    aput-byte v33, v15, v10

    aput-byte v18, v15, v14

    const/16 v33, -0x33

    aput-byte v33, v15, v16

    const/16 v33, -0x3f

    aput-byte v33, v15, v6

    invoke-static {v4, v15}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Lcom/github/catvod/crawler/SpiderDebug;->log(Ljava/lang/String;)V

    new-instance v2, Lcom/google/gson/JsonObject;

    invoke-direct {v2}, Lcom/google/gson/JsonObject;-><init>()V

    new-array v4, v6, [B

    const/16 v15, 0x48

    aput-byte v15, v4, v5

    const/16 v15, -0x7d

    aput-byte v15, v4, v8

    const/16 v15, -0x23

    aput-byte v15, v4, v7

    const/16 v15, 0x1b

    aput-byte v15, v4, v11

    const/16 v33, 0x71

    aput-byte v33, v4, v10

    const/16 v33, -0xc

    aput-byte v33, v4, v14

    const/16 v33, -0x77

    aput-byte v33, v4, v16

    new-array v15, v9, [B

    aput-byte v12, v15, v5

    const/16 v34, -0x16

    aput-byte v34, v15, v8

    const/16 v34, -0x4f

    aput-byte v34, v15, v7

    const/16 v34, 0x7e

    aput-byte v34, v15, v11

    aput-byte v12, v15, v10

    const/16 v34, -0x63

    aput-byte v34, v15, v14

    const/16 v34, -0x13

    aput-byte v34, v15, v16

    const/16 v34, 0x75

    aput-byte v34, v15, v6

    invoke-static {v4, v15}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v2, v4, v0}, Lcom/google/gson/JsonObject;->addProperty(Ljava/lang/String;Ljava/lang/String;)V

    new-array v4, v9, [B

    const/16 v15, -0x14

    aput-byte v15, v4, v5

    const/4 v15, -0x8

    aput-byte v15, v4, v8

    const/16 v15, -0x19

    aput-byte v15, v4, v7

    const/16 v34, 0x6a

    aput-byte v34, v4, v11

    aput-byte v15, v4, v10

    const/16 v15, 0x77

    aput-byte v15, v4, v14

    aput-byte v12, v4, v16

    const/16 v12, 0x5b

    aput-byte v12, v4, v6

    new-array v12, v9, [B

    const/16 v34, -0x61

    aput-byte v34, v12, v5

    const/16 v35, -0x70

    aput-byte v35, v12, v8

    const/16 v35, -0x7a

    aput-byte v35, v12, v7

    const/16 v35, 0x18

    aput-byte v35, v12, v11

    const/16 v36, -0x7e

    aput-byte v36, v12, v10

    const/16 v36, 0x28

    aput-byte v36, v12, v14

    const/16 v37, 0x47

    aput-byte v37, v12, v16

    const/16 v37, 0x3f

    aput-byte v37, v12, v6

    invoke-static {v4, v12}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v4

    move-object/from16 v12, p1

    invoke-virtual {v2, v4, v12}, Lcom/google/gson/JsonObject;->addProperty(Ljava/lang/String;Ljava/lang/String;)V

    new-array v4, v3, [B

    aput-byte v28, v4, v5

    const/16 v12, 0x3f

    aput-byte v12, v4, v8

    aput-byte v3, v4, v7

    const/16 v12, 0x16

    aput-byte v12, v4, v11

    const/16 v12, 0x70

    aput-byte v12, v4, v10

    const/16 v12, 0x65

    aput-byte v12, v4, v14

    const/16 v12, 0x31

    aput-byte v12, v4, v16

    aput-byte v13, v4, v6

    aput-byte v28, v4, v9

    const/16 v37, 0x24

    aput-byte v37, v4, v18

    new-array v13, v9, [B

    aput-byte v15, v13, v5

    const/16 v15, 0x47

    aput-byte v15, v13, v8

    const/16 v15, 0x7a

    aput-byte v15, v13, v7

    const/16 v15, 0x7f

    aput-byte v15, v13, v11

    aput-byte v7, v13, v10

    aput-byte v5, v13, v14

    const/16 v15, 0x6e

    aput-byte v15, v13, v16

    const/16 v33, 0x1b

    aput-byte v33, v13, v6

    invoke-static {v4, v13}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v4

    const/16 v13, 0x258

    invoke-static {v13}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v13

    invoke-virtual {v2, v4, v13}, Lcom/google/gson/JsonObject;->addProperty(Ljava/lang/String;Ljava/lang/Number;)V

    const/16 v4, 0x23

    new-array v4, v4, [B

    const/16 v13, 0x23

    aput-byte v13, v4, v5

    aput-byte v34, v4, v8

    const/16 v13, 0x43

    aput-byte v13, v4, v7

    aput-byte v32, v4, v11

    aput-byte v15, v4, v10

    const/16 v13, -0x32

    aput-byte v13, v4, v14

    aput-byte v20, v4, v16

    const/16 v13, -0x79

    aput-byte v13, v4, v6

    const/16 v13, 0x32

    aput-byte v13, v4, v9

    const/16 v13, -0x38

    aput-byte v13, v4, v18

    aput-byte v35, v4, v3

    const/16 v13, -0x7c

    aput-byte v13, v4, v20

    const/16 v13, 0x74

    const/16 v30, 0xc

    aput-byte v13, v4, v30

    const/16 v13, -0x36

    aput-byte v13, v4, v21

    aput-byte v23, v4, v22

    const/16 v13, -0x26

    aput-byte v13, v4, v23

    const/16 v13, 0x30

    aput-byte v13, v4, v24

    const/16 v13, -0xe

    aput-byte v13, v4, v26

    aput-byte v5, v4, v28

    const/16 v13, -0x4e

    aput-byte v13, v4, v29

    const/16 v13, 0x69

    aput-byte v13, v4, v27

    const/16 v13, -0x37

    aput-byte v13, v4, v31

    const/16 v13, 0x16

    aput-byte v12, v4, v13

    const/16 v13, 0x17

    const/16 v17, -0x34

    aput-byte v17, v4, v13

    const/16 v13, 0x3a

    aput-byte v13, v4, v35

    const/16 v13, 0x19

    const/16 v17, -0x26

    aput-byte v17, v4, v13

    const/16 v13, 0x1a

    aput-byte v7, v4, v13

    const/16 v13, 0x1b

    aput-byte v19, v4, v13

    const/16 v13, 0x1c

    const/16 v17, 0x68

    aput-byte v17, v4, v13

    const/16 v13, 0x1d

    const/16 v17, -0x3d

    aput-byte v17, v4, v13

    const/16 v13, 0x1e

    aput-byte v3, v4, v13

    const/16 v13, 0x1f

    const/16 v17, -0x9

    aput-byte v17, v4, v13

    const/16 v13, 0x20

    const/16 v17, 0x20

    aput-byte v17, v4, v13

    const/16 v13, 0x21

    const/16 v17, -0x21

    aput-byte v17, v4, v13

    const/16 v13, 0x22

    aput-byte v5, v4, v13

    new-array v13, v9, [B

    const/16 v17, 0x55

    aput-byte v17, v13, v5

    const/16 v17, -0x53

    aput-byte v17, v13, v8

    const/16 v17, 0x6c

    aput-byte v17, v13, v7

    const/16 v17, -0x25

    aput-byte v17, v13, v11

    aput-byte v6, v13, v10

    const/16 v17, -0x5e

    aput-byte v17, v13, v14

    aput-byte v15, v13, v16

    const/16 v15, -0x58

    aput-byte v15, v13, v6

    invoke-static {v4, v13}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v2}, Lcom/google/gson/JsonElement;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-direct {v1, v4, v2, v5}, Lcom/github/catvod/spider/appysv2/b/x;->m(Ljava/lang/String;Ljava/lang/String;Z)Ljava/lang/String;

    move-result-object v2
    :try_end_278
    .catch Ljava/lang/Exception; {:try_start_4 .. :try_end_278} :catch_2e6

    .line 1
    :try_start_278
    invoke-static {v2}, Lcom/google/gson/JsonParser;->parseString(Ljava/lang/String;)Lcom/google/gson/JsonElement;

    move-result-object v2
    :try_end_27c
    .catchall {:try_start_278 .. :try_end_27c} :catchall_27d

    goto :goto_286

    :catchall_27d
    :try_start_27d
    new-instance v4, Lcom/google/gson/JsonParser;

    invoke-direct {v4}, Lcom/google/gson/JsonParser;-><init>()V

    invoke-virtual {v4, v2}, Lcom/google/gson/JsonParser;->parse(Ljava/lang/String;)Lcom/google/gson/JsonElement;

    move-result-object v2

    .line 2
    :goto_286
    invoke-virtual {v2}, Lcom/google/gson/JsonElement;->getAsJsonObject()Lcom/google/gson/JsonObject;

    move-result-object v2

    const/16 v4, 0xc

    new-array v4, v4, [B

    const/16 v13, -0x7b

    aput-byte v13, v4, v5

    aput-byte v32, v4, v8

    aput-byte v25, v4, v7

    const/16 v13, 0x7a

    aput-byte v13, v4, v11

    const/16 v13, 0x5d

    aput-byte v13, v4, v10

    const/16 v13, 0x6f

    aput-byte v13, v4, v14

    const/16 v13, -0x46

    aput-byte v13, v4, v16

    const/16 v13, 0x4c

    aput-byte v13, v4, v6

    const/16 v13, -0x42

    aput-byte v13, v4, v9

    const/16 v13, -0x59

    aput-byte v13, v4, v18

    const/16 v13, 0x3e

    aput-byte v13, v4, v3

    const/16 v3, 0x78

    aput-byte v3, v4, v20

    new-array v3, v9, [B

    const/16 v9, -0x1f

    aput-byte v9, v3, v5

    const/16 v9, -0x2e

    aput-byte v9, v3, v8

    const/16 v8, 0x4c

    aput-byte v8, v3, v7

    aput-byte v27, v3, v11

    aput-byte v12, v3, v10

    aput-byte v5, v3, v14

    const/16 v5, -0x25

    aput-byte v5, v3, v16

    aput-byte v36, v3, v6

    invoke-static {v4, v3}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Lcom/google/gson/JsonObject;->get(Ljava/lang/String;)Lcom/google/gson/JsonElement;

    move-result-object v2

    invoke-virtual {v2}, Lcom/google/gson/JsonElement;->getAsString()Ljava/lang/String;

    move-result-object v2

    iget-object v3, v1, Lcom/github/catvod/spider/appysv2/b/x;->b:Ljava/util/HashMap;

    invoke-virtual {v3, v0, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_2e5
    .catch Ljava/lang/Exception; {:try_start_27d .. :try_end_2e5} :catch_2e6

    return-object v2

    :catch_2e6
    move-exception v0

    invoke-virtual {v0}, Ljava/lang/Throwable;->printStackTrace()V

    const-string v0, ""

    return-object v0
.end method

.method public final x([Ljava/lang/String;)Ljava/util/List;
    .registers 13
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "([",
            "Ljava/lang/String;",
            ")",
            "Ljava/util/List<",
            "Lcom/github/catvod/spider/appysv2/c/i;",
            ">;"
        }
    .end annotation

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    array-length v1, p1

    const/4 v2, 0x0

    const/4 v3, 0x0

    :goto_8
    if-ge v3, v1, :cond_90

    aget-object v4, p1, v3

    const/4 v5, 0x3

    new-array v6, v5, [B

    fill-array-data v6, :array_92

    const/16 v7, 0x8

    new-array v8, v7, [B

    fill-array-data v8, :array_98

    invoke-static {v6, v8}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v4, v6}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v6

    if-nez v6, :cond_24

    goto :goto_8c

    :cond_24
    new-array v5, v5, [B

    fill-array-data v5, :array_a0

    new-array v6, v7, [B

    fill-array-data v6, :array_a6

    invoke-static {v5, v6}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v4

    aget-object v5, v4, v2

    const/4 v6, 0x1

    aget-object v6, v4, v6

    new-instance v8, Ljava/lang/StringBuilder;

    invoke-direct {v8}, Ljava/lang/StringBuilder;-><init>()V

    invoke-static {}, Lcom/github/catvod/spider/Proxy;->getUrl()Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v9, 0x19

    new-array v9, v9, [B

    fill-array-data v9, :array_ae

    new-array v10, v7, [B

    fill-array-data v10, :array_c0

    invoke-static {v9, v10}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    aget-object v9, p1, v2

    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    new-array v9, v7, [B

    fill-array-data v9, :array_c8

    new-array v7, v7, [B

    fill-array-data v7, :array_d0

    invoke-static {v9, v7}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v8, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x2

    aget-object v4, v4, v7

    invoke-virtual {v8, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v8}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    .line 1
    new-instance v7, Lcom/github/catvod/spider/appysv2/c/i;

    invoke-direct {v7}, Lcom/github/catvod/spider/appysv2/c/i;-><init>()V

    .line 2
    invoke-virtual {v7, v5}, Lcom/github/catvod/spider/appysv2/c/i;->c(Ljava/lang/String;)Lcom/github/catvod/spider/appysv2/c/i;

    invoke-virtual {v7, v6}, Lcom/github/catvod/spider/appysv2/c/i;->a(Ljava/lang/String;)Lcom/github/catvod/spider/appysv2/c/i;

    move-result-object v5

    invoke-virtual {v5, v4}, Lcom/github/catvod/spider/appysv2/c/i;->d(Ljava/lang/String;)Lcom/github/catvod/spider/appysv2/c/i;

    invoke-virtual {v0, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :goto_8c
    add-int/lit8 v3, v3, 0x1

    goto/16 :goto_8

    :cond_90
    return-object v0

    nop

    :array_92
    .array-data 1
        -0x6dt
        0x26t
        -0x79t
    .end array-data

    :array_98
    .array-data 1
        -0x2dt
        0x66t
        -0x39t
        -0x75t
        0x47t
        -0x61t
        0x44t
        -0x37t
    .end array-data

    :array_a0
    .array-data 1
        0x73t
        -0x57t
        -0x27t
    .end array-data

    :array_a6
    .array-data 1
        0x33t
        -0x17t
        -0x67t
        -0x36t
        0x71t
        0x6dt
        0x7ct
        0x75t
    .end array-data

    :array_ae
    .array-data 1
        0x5et
        0x68t
        0x5bt
        0x1et
        0x71t
        -0x4ft
        -0x61t
        -0x4t
        0x15t
        0x75t
        0x44t
        0x46t
        0x2dt
        -0x52t
        -0x7dt
        -0x48t
        0x47t
        0x7ft
        0x5ct
        0x42t
        0x62t
        -0x48t
        -0x41t
        -0x42t
        0x5ct
    .end array-data

    nop

    :array_c0
    .array-data 1
        0x61t
        0xct
        0x34t
        0x23t
        0x10t
        -0x23t
        -0xat
        -0x26t
    .end array-data

    :array_c8
    .array-data 1
        0x61t
        0x59t
        -0x9t
        0x25t
        -0x60t
        -0x63t
        -0x46t
        -0x7et
    .end array-data

    :array_d0
    .array-data 1
        0x47t
        0x3ft
        -0x62t
        0x49t
        -0x3bt
        -0x2ct
        -0x22t
        -0x41t
    .end array-data
.end method

.method public final y(Ljava/lang/String;Ljava/lang/String;)Lcom/github/catvod/spider/appysv2/d/j;
    .registers 38

    move-object/from16 v1, p0

    const/4 v2, 0x0

    :try_start_3
    invoke-direct/range {p0 .. p1}, Lcom/github/catvod/spider/appysv2/b/x;->J(Ljava/lang/String;)V

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/16 v3, 0x1a

    new-array v4, v3, [B

    const/16 v5, -0x33

    aput-byte v5, v4, v2

    const/16 v5, 0x8

    const/4 v6, 0x1

    aput-byte v5, v4, v6

    const/4 v7, 0x2

    const/16 v8, 0x30

    aput-byte v8, v4, v7

    const/4 v9, 0x3

    const/16 v10, -0x6c

    aput-byte v10, v4, v9

    const/16 v11, 0x5d

    const/4 v12, 0x4

    aput-byte v11, v4, v12

    const/4 v13, 0x5

    const/16 v14, -0x7b

    aput-byte v14, v4, v13

    const/4 v15, 0x6

    const/16 v16, 0x63

    aput-byte v16, v4, v15

    const/4 v3, 0x7

    const/16 v17, -0x80

    aput-byte v17, v4, v3

    const/16 v18, -0x6

    aput-byte v18, v4, v5

    const/16 v19, 0x1f

    const/16 v20, 0x9

    aput-byte v19, v4, v20

    const/16 v21, 0x21

    const/16 v22, 0xa

    aput-byte v21, v4, v22

    const/16 v21, -0x4c

    const/16 v23, 0xb

    aput-byte v21, v4, v23

    const/16 v21, 0xc

    aput-byte v11, v4, v21

    const/16 v24, -0x7c

    const/16 v25, 0xd

    aput-byte v24, v4, v25

    const/16 v24, 0x71

    const/16 v10, 0xe

    aput-byte v24, v4, v10

    const/16 v24, -0x41

    const/16 v26, 0xf

    aput-byte v24, v4, v26

    const/16 v24, -0x3a

    const/16 v8, 0x10

    aput-byte v24, v4, v8

    const/16 v24, 0x11

    aput-byte v21, v4, v24

    const/16 v27, 0x3d

    const/16 v28, 0x12

    aput-byte v27, v4, v28

    const/16 v27, 0x13

    const/16 v29, -0x75

    aput-byte v29, v4, v27

    const/16 v27, 0x5a

    const/16 v29, 0x14

    aput-byte v27, v4, v29

    const/16 v27, -0x79

    const/16 v30, 0x15

    aput-byte v27, v4, v30

    const/16 v27, 0x16

    const/16 v31, 0x69

    aput-byte v31, v4, v27

    const/16 v27, -0x3f

    const/16 v31, 0x17

    aput-byte v27, v4, v31

    const/16 v27, 0x18

    const/16 v32, -0x7c

    aput-byte v32, v4, v27

    const/16 v27, 0x19

    const/16 v32, 0x43

    aput-byte v32, v4, v27

    new-array v11, v5, [B

    const/16 v32, -0x56

    aput-byte v32, v11, v2

    const/16 v32, 0x6d

    aput-byte v32, v11, v6

    const/16 v32, 0x44

    aput-byte v32, v11, v7

    const/16 v33, -0x3e

    aput-byte v33, v11, v9

    const/16 v33, 0x34

    aput-byte v33, v11, v12

    const/16 v33, -0x1f

    aput-byte v33, v11, v13

    aput-byte v15, v11, v15

    const/16 v33, -0x11

    aput-byte v33, v11, v3

    invoke-static {v4, v11}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-object/from16 v4, p2

    invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lcom/github/catvod/crawler/SpiderDebug;->log(Ljava/lang/String;)V

    iget-object v0, v1, Lcom/github/catvod/spider/appysv2/b/x;->d:Ljava/util/ArrayList;

    invoke-direct/range {p0 .. p2}, Lcom/github/catvod/spider/appysv2/b/x;->n(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v0, v2, v4}, Ljava/util/ArrayList;->add(ILjava/lang/Object;)V

    new-instance v0, Lcom/google/gson/JsonObject;

    invoke-direct {v0}, Lcom/google/gson/JsonObject;-><init>()V

    new-array v4, v3, [B

    const/16 v11, -0x1d

    aput-byte v11, v4, v2

    aput-byte v8, v4, v6

    aput-byte v5, v4, v7

    const/16 v11, 0x72

    aput-byte v11, v4, v9

    const/16 v33, -0x5

    aput-byte v33, v4, v12

    const/16 v33, 0x7c

    aput-byte v33, v4, v13

    const/16 v33, 0x70

    aput-byte v33, v4, v15

    new-array v11, v5, [B

    aput-byte v14, v11, v2

    const/16 v14, 0x79

    aput-byte v14, v11, v6

    const/16 v14, 0x64

    aput-byte v14, v11, v7

    aput-byte v31, v11, v9

    const/16 v33, -0x5c

    aput-byte v33, v11, v12

    aput-byte v30, v11, v13

    aput-byte v29, v11, v15

    const/16 v33, -0x11

    aput-byte v33, v11, v3

    invoke-static {v4, v11}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v4

    iget-object v11, v1, Lcom/github/catvod/spider/appysv2/b/x;->d:Ljava/util/ArrayList;

    invoke-virtual {v11, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v11

    check-cast v11, Ljava/lang/String;

    invoke-virtual {v0, v4, v11}, Lcom/google/gson/JsonObject;->addProperty(Ljava/lang/String;Ljava/lang/String;)V

    new-array v4, v5, [B

    const/16 v11, 0x3c

    aput-byte v11, v4, v2

    const/16 v33, -0x30

    aput-byte v33, v4, v6

    const/16 v33, -0x61

    aput-byte v33, v4, v7

    const/16 v33, -0x1

    aput-byte v33, v4, v9

    const/16 v33, 0x6b

    aput-byte v33, v4, v12

    aput-byte v28, v4, v13

    const/16 v33, -0x17

    aput-byte v33, v4, v15

    const/16 v33, -0x16

    aput-byte v33, v4, v3

    new-array v14, v5, [B

    const/16 v33, 0x58

    aput-byte v33, v14, v2

    const/16 v33, -0x5e

    aput-byte v33, v14, v6

    const/16 v33, -0xa

    aput-byte v33, v14, v7

    const/16 v33, -0x77

    aput-byte v33, v14, v9

    aput-byte v10, v14, v12

    const/16 v33, 0x4d

    aput-byte v33, v14, v13

    aput-byte v17, v14, v15

    const/16 v17, -0x72

    aput-byte v17, v14, v3

    invoke-static {v4, v14}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v4

    iget-object v14, v1, Lcom/github/catvod/spider/appysv2/b/x;->f:Lcom/github/catvod/spider/appysv2/d/c;

    invoke-virtual {v14}, Lcom/github/catvod/spider/appysv2/d/c;->a()Lcom/github/catvod/spider/appysv2/d/g;

    move-result-object v14

    invoke-virtual {v14}, Lcom/github/catvod/spider/appysv2/d/g;->a()Ljava/lang/String;

    move-result-object v14

    invoke-virtual {v0, v4, v14}, Lcom/google/gson/JsonObject;->addProperty(Ljava/lang/String;Ljava/lang/String;)V

    new-array v4, v5, [B

    const/16 v14, 0x4e

    aput-byte v14, v4, v2

    aput-byte v11, v4, v6

    const/16 v14, -0x70

    aput-byte v14, v4, v7

    const/16 v17, -0x8

    aput-byte v17, v4, v9

    const/16 v17, -0x5f

    aput-byte v17, v4, v12

    const/16 v17, -0x2b

    aput-byte v17, v4, v13

    const/16 v17, -0x1b

    aput-byte v17, v4, v15

    const/16 v17, 0x2a

    aput-byte v17, v4, v3

    new-array v11, v5, [B

    const/16 v33, 0x2d

    aput-byte v33, v11, v2

    const/16 v27, 0x5d

    aput-byte v27, v11, v6

    const/16 v33, -0x1c

    aput-byte v33, v11, v7

    const/16 v33, -0x63

    aput-byte v33, v11, v9

    const/16 v33, -0x3a

    aput-byte v33, v11, v12

    const/16 v33, -0x46

    aput-byte v33, v11, v13

    const/16 v33, -0x69

    aput-byte v33, v11, v15

    const/16 v34, 0x53

    aput-byte v34, v11, v3

    invoke-static {v4, v11}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v4

    new-array v11, v8, [B

    const/16 v34, 0x32

    aput-byte v34, v11, v2

    const/16 v34, 0x39

    aput-byte v34, v11, v6

    const/16 v34, 0x67

    aput-byte v34, v11, v7

    const/16 v34, -0x4e

    aput-byte v34, v11, v9

    const/16 v34, 0x66

    aput-byte v34, v11, v12

    aput-byte v16, v11, v13

    const/16 v16, -0x1a

    aput-byte v16, v11, v15

    const/16 v16, 0x59

    aput-byte v16, v11, v3

    const/16 v16, 0x30

    aput-byte v16, v11, v5

    const/16 v16, 0x23

    aput-byte v16, v11, v20

    const/16 v16, 0x72

    aput-byte v16, v11, v22

    const/16 v16, -0x48

    aput-byte v16, v11, v23

    const/16 v16, 0x5d

    aput-byte v16, v11, v21

    const/16 v16, 0x7e

    aput-byte v16, v11, v25

    aput-byte v18, v11, v10

    const/16 v16, 0x5f

    aput-byte v16, v11, v26

    new-array v8, v5, [B

    const/16 v18, 0x5e

    aput-byte v18, v8, v2

    const/16 v18, 0x50

    aput-byte v18, v8, v6

    aput-byte v24, v8, v7

    const/16 v18, -0x29

    aput-byte v18, v8, v9

    const/16 v18, 0x39

    aput-byte v18, v8, v12

    aput-byte v31, v8, v13

    const/16 v18, -0x6c

    aput-byte v18, v8, v15

    const/16 v18, 0x38

    aput-byte v18, v8, v3

    invoke-static {v11, v8}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v0, v4, v8}, Lcom/google/gson/JsonObject;->addProperty(Ljava/lang/String;Ljava/lang/String;)V

    new-array v4, v10, [B

    aput-byte v25, v4, v2

    const/16 v8, -0x1f

    aput-byte v8, v4, v6

    const/16 v8, -0x5c

    aput-byte v8, v4, v7

    const/16 v8, 0x2d

    aput-byte v8, v4, v9

    const/16 v8, 0x27

    aput-byte v8, v4, v12

    const/16 v8, -0x18

    aput-byte v8, v4, v13

    const/16 v8, 0x34

    aput-byte v8, v4, v15

    const/16 v8, 0x79

    aput-byte v8, v4, v3

    aput-byte v22, v4, v5

    const/16 v8, -0xa

    aput-byte v8, v4, v20

    aput-byte v33, v4, v22

    aput-byte v6, v4, v23

    const/16 v8, 0x27

    aput-byte v8, v4, v21

    const/16 v8, -0xd

    aput-byte v8, v4, v25

    new-array v8, v5, [B

    const/16 v11, 0x78

    aput-byte v11, v8, v2

    const/16 v11, -0x6d

    aput-byte v11, v8, v6

    const/16 v11, -0x38

    aput-byte v11, v8, v7

    const/16 v11, 0x72

    aput-byte v11, v8, v9

    const/16 v11, 0x42

    aput-byte v11, v8, v12

    aput-byte v14, v8, v13

    aput-byte v32, v8, v15

    const/16 v11, 0x10

    aput-byte v11, v8, v3

    invoke-static {v4, v8}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v4

    const/16 v8, 0x384

    invoke-static {v8}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v8

    invoke-virtual {v0, v4, v8}, Lcom/google/gson/JsonObject;->addProperty(Ljava/lang/String;Ljava/lang/Number;)V

    const/16 v4, 0x20

    new-array v4, v4, [B

    const/16 v8, 0x3a

    aput-byte v8, v4, v2

    const/16 v8, 0x5f

    aput-byte v8, v4, v6

    const/16 v8, 0x3c

    aput-byte v8, v4, v7

    aput-byte v34, v4, v9

    const/16 v8, 0x54

    aput-byte v8, v4, v12

    aput-byte v33, v4, v13

    const/16 v8, 0x6e

    aput-byte v8, v4, v15

    const/4 v8, -0x2

    aput-byte v8, v4, v3

    const/16 v11, 0x7a

    aput-byte v11, v4, v5

    const/16 v11, 0x48

    aput-byte v11, v4, v20

    const/16 v11, 0x3c

    aput-byte v11, v4, v22

    const/16 v11, 0x7c

    aput-byte v11, v4, v23

    aput-byte v32, v4, v21

    aput-byte v33, v4, v25

    aput-byte v34, v4, v10

    aput-byte v8, v4, v26

    const/16 v10, 0x3a

    const/16 v11, 0x10

    aput-byte v10, v4, v11

    const/16 v10, 0x7f

    aput-byte v10, v4, v24

    const/16 v10, 0x2b

    aput-byte v10, v4, v28

    const/16 v10, 0x13

    const/16 v11, 0x6d

    aput-byte v11, v4, v10

    const/16 v10, 0x64

    aput-byte v10, v4, v29

    aput-byte v33, v4, v30

    const/16 v10, 0x16

    const/16 v11, 0x67

    aput-byte v11, v4, v10

    const/16 v10, -0x14

    aput-byte v10, v4, v31

    const/16 v10, 0x18

    aput-byte v13, v4, v10

    const/16 v10, 0x19

    const/16 v11, 0x43

    aput-byte v11, v4, v10

    const/16 v10, 0x38

    const/16 v11, 0x1a

    aput-byte v10, v4, v11

    const/16 v10, 0x1b

    const/16 v11, 0x71

    aput-byte v11, v4, v10

    const/16 v10, 0x1c

    const/16 v11, 0x5b

    aput-byte v11, v4, v10

    const/16 v10, 0x1d

    aput-byte v14, v4, v10

    const/16 v10, 0x1e

    const/16 v11, 0x64

    aput-byte v11, v4, v10

    const/16 v10, -0xc

    aput-byte v10, v4, v19

    new-array v10, v5, [B

    const/16 v11, 0x55

    aput-byte v11, v10, v2

    const/16 v11, 0x2f

    aput-byte v11, v10, v6

    const/16 v11, 0x59

    aput-byte v11, v10, v7

    aput-byte v5, v10, v9

    aput-byte v28, v10, v12

    aput-byte v8, v10, v13

    aput-byte v7, v10, v15

    const/16 v5, -0x65

    aput-byte v5, v10, v3

    invoke-static {v4, v10}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v0}, Lcom/google/gson/JsonElement;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-direct {v1, v3, v0, v6}, Lcom/github/catvod/spider/appysv2/b/x;->D(Ljava/lang/String;Ljava/lang/String;Z)Ljava/lang/String;

    move-result-object v0

    .line 1
    new-instance v3, Lcom/google/gson/Gson;

    invoke-direct {v3}, Lcom/google/gson/Gson;-><init>()V

    const-class v4, Lcom/github/catvod/spider/appysv2/d/l;

    invoke-virtual {v3, v0, v4}, Lcom/google/gson/Gson;->fromJson(Ljava/lang/String;Ljava/lang/Class;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/github/catvod/spider/appysv2/d/l;

    .line 2
    invoke-virtual {v0}, Lcom/github/catvod/spider/appysv2/d/l;->a()Lcom/github/catvod/spider/appysv2/d/j;

    move-result-object v0
    :try_end_331
    .catch Ljava/lang/Exception; {:try_start_3 .. :try_end_331} :catch_339
    .catchall {:try_start_3 .. :try_end_331} :catchall_337

    new-instance v3, Lcom/github/catvod/spider/appysv2/b/d;

    invoke-direct {v3, v1, v2}, Lcom/github/catvod/spider/appysv2/b/d;-><init>(Ljava/lang/Object;I)V

    goto :goto_347

    :catchall_337
    move-exception v0

    goto :goto_34b

    :catch_339
    move-exception v0

    :try_start_33a
    invoke-virtual {v0}, Ljava/lang/Throwable;->printStackTrace()V

    new-instance v0, Lcom/github/catvod/spider/appysv2/d/j;

    invoke-direct {v0}, Lcom/github/catvod/spider/appysv2/d/j;-><init>()V
    :try_end_342
    .catchall {:try_start_33a .. :try_end_342} :catchall_337

    new-instance v3, Lcom/github/catvod/spider/appysv2/b/c;

    invoke-direct {v3, v1, v2}, Lcom/github/catvod/spider/appysv2/b/c;-><init>(Ljava/lang/Object;I)V

    :goto_347
    invoke-static {v3}, Lcom/github/catvod/spider/Init;->execute(Ljava/lang/Runnable;)V

    return-object v0

    :goto_34b
    new-instance v3, Lcom/github/catvod/spider/appysv2/b/a;

    invoke-direct {v3, v1, v2}, Lcom/github/catvod/spider/appysv2/b/a;-><init>(Ljava/lang/Object;I)V

    invoke-static {v3}, Lcom/github/catvod/spider/Init;->execute(Ljava/lang/Runnable;)V

    throw v0
.end method

.method public final z(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lcom/github/catvod/spider/appysv2/c/k;
    .registers 21

    move-object/from16 v6, p0

    move-object/from16 v7, p1

    move-object/from16 v8, p2

    invoke-direct {v6, v8}, Lcom/github/catvod/spider/appysv2/b/x;->J(Ljava/lang/String;)V

    new-instance v0, Lcom/google/gson/JsonObject;

    invoke-direct {v0}, Lcom/google/gson/JsonObject;-><init>()V

    const/16 v9, 0x8

    new-array v1, v9, [B

    fill-array-data v1, :array_25e

    new-array v2, v9, [B

    fill-array-data v2, :array_266

    invoke-static {v1, v2}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1, v8}, Lcom/google/gson/JsonObject;->addProperty(Ljava/lang/String;Ljava/lang/String;)V

    const/16 v1, 0x2b

    new-array v1, v1, [B

    fill-array-data v1, :array_26e

    new-array v2, v9, [B

    fill-array-data v2, :array_288

    invoke-static {v1, v2}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-direct {v6, v1, v0}, Lcom/github/catvod/spider/appysv2/b/x;->F(Ljava/lang/String;Lcom/google/gson/JsonObject;)Ljava/lang/String;

    move-result-object v0

    .line 1
    const-class v1, Lcom/github/catvod/spider/appysv2/d/o;

    .line 2
    invoke-static {v0, v1}, Lcom/github/catvod/spider/appysv2/b/s;->a(Ljava/lang/String;Ljava/lang/Class;)Ljava/lang/Object;

    move-result-object v0

    .line 3
    move-object v10, v0

    check-cast v10, Lcom/github/catvod/spider/appysv2/d/o;

    .line 4
    new-instance v11, Ljava/util/ArrayList;

    invoke-direct {v11}, Ljava/util/ArrayList;-><init>()V

    new-instance v12, Ljava/util/ArrayList;

    invoke-direct {v12}, Ljava/util/ArrayList;-><init>()V

    new-instance v2, Lcom/github/catvod/spider/appysv2/d/h;

    .line 5
    invoke-static/range {p3 .. p3}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v13, 0x0

    if-nez v0, :cond_54

    move-object/from16 v0, p3

    goto :goto_98

    :cond_54
    invoke-virtual {v10}, Lcom/github/catvod/spider/appysv2/d/o;->c()Ljava/util/List;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/List;->isEmpty()Z

    move-result v0

    if-eqz v0, :cond_61

    const-string v0, ""

    goto :goto_98

    :cond_61
    invoke-virtual {v10}, Lcom/github/catvod/spider/appysv2/d/o;->c()Ljava/util/List;

    move-result-object v0

    invoke-interface {v0, v13}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/github/catvod/spider/appysv2/d/h;

    invoke-virtual {v0}, Lcom/github/catvod/spider/appysv2/d/h;->j()Ljava/lang/String;

    move-result-object v1

    const/4 v3, 0x6

    new-array v3, v3, [B

    fill-array-data v3, :array_290

    new-array v4, v9, [B

    fill-array-data v4, :array_298

    invoke-static {v3, v4}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_89

    invoke-virtual {v0}, Lcom/github/catvod/spider/appysv2/d/h;->d()Ljava/lang/String;

    move-result-object v0

    goto :goto_98

    :cond_89
    const/4 v0, 0x4

    new-array v0, v0, [B

    fill-array-data v0, :array_2a0

    new-array v1, v9, [B

    fill-array-data v1, :array_2a6

    invoke-static {v0, v1}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v0

    .line 6
    :goto_98
    invoke-direct {v2, v0}, Lcom/github/catvod/spider/appysv2/d/h;-><init>(Ljava/lang/String;)V

    const-string v5, ""

    move-object/from16 v0, p0

    move-object/from16 v1, p2

    move-object v3, v11

    move-object v4, v12

    .line 7
    invoke-direct/range {v0 .. v5}, Lcom/github/catvod/spider/appysv2/b/x;->C(Ljava/lang/String;Lcom/github/catvod/spider/appysv2/d/h;Ljava/util/List;Ljava/util/List;Ljava/lang/String;)V

    .line 8
    invoke-static {v11}, Ljava/util/Collections;->sort(Ljava/util/List;)V

    const/4 v0, 0x2

    new-array v0, v0, [Ljava/lang/String;

    const/16 v1, 0xc

    new-array v2, v1, [B

    fill-array-data v2, :array_2ae

    new-array v3, v9, [B

    fill-array-data v3, :array_2b8

    invoke-static {v2, v3}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v2

    aput-object v2, v0, v13

    new-array v1, v1, [B

    fill-array-data v1, :array_2c0

    new-array v2, v9, [B

    fill-array-data v2, :array_2ca

    invoke-static {v1, v2}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v1

    const/4 v2, 0x1

    aput-object v1, v0, v2

    invoke-static {v0}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v0

    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    new-instance v3, Ljava/util/ArrayList;

    invoke-direct {v3}, Ljava/util/ArrayList;-><init>()V

    invoke-virtual {v11}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v4

    :goto_e1
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    move-result v5

    if-eqz v5, :cond_1e2

    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Lcom/github/catvod/spider/appysv2/d/h;

    new-instance v11, Ljava/lang/StringBuilder;

    invoke-direct {v11}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v5}, Lcom/github/catvod/spider/appysv2/d/h;->b()Ljava/lang/String;

    move-result-object v14

    invoke-virtual {v11, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    new-array v14, v2, [B

    const/16 v15, -0x4b

    aput-byte v15, v14, v13

    new-array v15, v9, [B

    fill-array-data v15, :array_2d2

    .line 9
    invoke-static {v14, v15, v11, v8}, Lcom/github/catvod/spider/appysv2/b/v;->c([B[BLjava/lang/StringBuilder;Ljava/lang/String;)V

    .line 10
    new-array v14, v2, [B

    const/16 v15, 0x2e

    aput-byte v15, v14, v13

    new-array v9, v9, [B

    fill-array-data v9, :array_2da

    invoke-static {v14, v9}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v11, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5}, Lcom/github/catvod/spider/appysv2/d/h;->d()Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v11, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5}, Lcom/github/catvod/spider/appysv2/d/h;->f()Ljava/lang/String;

    move-result-object v5

    .line 11
    new-instance v9, Ljava/util/ArrayList;

    invoke-direct {v9}, Ljava/util/ArrayList;-><init>()V

    invoke-static {v5}, Lcom/github/catvod/spider/appysv2/p/C;->r(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object v5

    .line 12
    invoke-virtual {v12}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v13

    :cond_135
    :goto_135
    invoke-interface {v13}, Ljava/util/Iterator;->hasNext()Z

    move-result v14

    if-eqz v14, :cond_15d

    invoke-interface {v13}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v14

    check-cast v14, Lcom/github/catvod/spider/appysv2/d/h;

    invoke-virtual {v14}, Lcom/github/catvod/spider/appysv2/d/h;->f()Ljava/lang/String;

    move-result-object v15

    invoke-static {v15}, Lcom/github/catvod/spider/appysv2/p/C;->r(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v15

    invoke-virtual {v15}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object v15

    invoke-virtual {v5, v15}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v16

    if-nez v16, :cond_159

    invoke-virtual {v15, v5}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v15

    if-eqz v15, :cond_135

    :cond_159
    invoke-virtual {v9, v14}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_135

    .line 13
    :cond_15d
    invoke-virtual {v9}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v5

    if-eqz v5, :cond_166

    invoke-virtual {v9, v12}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    :cond_166
    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v9}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v9

    :goto_16f
    invoke-interface {v9}, Ljava/util/Iterator;->hasNext()Z

    move-result v13

    if-eqz v13, :cond_1ce

    invoke-interface {v9}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v13

    check-cast v13, Lcom/github/catvod/spider/appysv2/d/h;

    new-array v2, v2, [B

    const/4 v14, -0x7

    const/4 v15, 0x0

    aput-byte v14, v2, v15

    const/16 v14, 0x8

    new-array v15, v14, [B

    fill-array-data v15, :array_2e2

    invoke-static {v2, v15}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v5, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v13}, Lcom/github/catvod/spider/appysv2/d/h;->f()Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Lcom/github/catvod/spider/appysv2/p/C;->r(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v5, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x3

    new-array v2, v2, [B

    fill-array-data v2, :array_2ea

    new-array v15, v14, [B

    fill-array-data v15, :array_2f0

    invoke-static {v2, v15}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v5, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v13}, Lcom/github/catvod/spider/appysv2/d/h;->c()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v5, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x3

    new-array v2, v2, [B

    fill-array-data v2, :array_2f8

    new-array v14, v14, [B

    fill-array-data v14, :array_2fe

    invoke-static {v2, v14}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v5, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v13}, Lcom/github/catvod/spider/appysv2/d/h;->d()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v5, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x1

    goto :goto_16f

    :cond_1ce
    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    .line 14
    invoke-virtual {v11, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v11}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    const/4 v2, 0x1

    const/16 v9, 0x8

    const/4 v13, 0x0

    goto/16 :goto_e1

    :cond_1e2
    const/4 v2, 0x0

    :goto_1e3
    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v4

    if-ge v2, v4, :cond_204

    const/4 v4, 0x1

    new-array v4, v4, [B

    const/4 v5, 0x0

    const/16 v8, 0x8

    aput-byte v8, v4, v5

    new-array v5, v8, [B

    fill-array-data v5, :array_306

    invoke-static {v4, v5}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-static {v4, v1}, Landroid/text/TextUtils;->join(Ljava/lang/CharSequence;Ljava/lang/Iterable;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/lit8 v2, v2, 0x1

    goto :goto_1e3

    :cond_204
    new-instance v1, Lcom/github/catvod/spider/appysv2/c/k;

    invoke-direct {v1}, Lcom/github/catvod/spider/appysv2/c/k;-><init>()V

    invoke-virtual {v1, v7}, Lcom/github/catvod/spider/appysv2/c/k;->g(Ljava/lang/String;)V

    invoke-virtual {v1, v7}, Lcom/github/catvod/spider/appysv2/c/k;->e(Ljava/lang/String;)V

    invoke-virtual {v10}, Lcom/github/catvod/spider/appysv2/d/o;->b()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Lcom/github/catvod/spider/appysv2/c/k;->i(Ljava/lang/String;)V

    invoke-virtual {v10}, Lcom/github/catvod/spider/appysv2/d/o;->d()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Lcom/github/catvod/spider/appysv2/c/k;->h(Ljava/lang/String;)V

    const/4 v2, 0x3

    new-array v4, v2, [B

    fill-array-data v4, :array_30e

    const/16 v5, 0x8

    new-array v7, v5, [B

    fill-array-data v7, :array_314

    invoke-static {v4, v7}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-static {v4, v3}, Landroid/text/TextUtils;->join(Ljava/lang/CharSequence;Ljava/lang/Iterable;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v1, v3}, Lcom/github/catvod/spider/appysv2/c/k;->k(Ljava/lang/String;)V

    new-array v2, v2, [B

    fill-array-data v2, :array_31c

    new-array v3, v5, [B

    fill-array-data v3, :array_322

    invoke-static {v2, v3}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-static {v2, v0}, Landroid/text/TextUtils;->join(Ljava/lang/CharSequence;Ljava/lang/Iterable;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v1, v0}, Lcom/github/catvod/spider/appysv2/c/k;->j(Ljava/lang/String;)V

    const/16 v0, 0xc

    new-array v0, v0, [B

    fill-array-data v0, :array_32a

    new-array v2, v5, [B

    fill-array-data v2, :array_334

    invoke-static {v0, v2}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v1, v0}, Lcom/github/catvod/spider/appysv2/c/k;->b(Ljava/lang/String;)V

    return-object v1

    :array_25e
    .array-data 1
        0x68t
        -0x49t
        -0x6bt
        0x74t
        -0x3t
        -0x66t
        0x33t
        0x5bt
    .end array-data

    :array_266
    .array-data 1
        0x1bt
        -0x21t
        -0xct
        0x6t
        -0x68t
        -0x3bt
        0x5at
        0x3ft
    .end array-data

    :array_26e
    .array-data 1
        0x25t
        -0x31t
        0x5et
        -0x23t
        0x2t
        -0x4bt
        -0x12t
        0x47t
        0x77t
        -0x7ct
        0x5ft
        -0x24t
        0x15t
        -0x5et
        -0x5ct
        0x6et
        0x28t
        -0x3et
        0x42t
        -0x21t
        0x5bt
        -0x49t
        -0x5ct
        0x45t
        0x1bt
        -0x28t
        0x44t
        -0x2bt
        0x6t
        -0x4bt
        -0x62t
        0x53t
        0x3dt
        -0xct
        0x4dt
        -0x26t
        0x1bt
        -0x42t
        -0x48t
        0x5ct
        0x2bt
        -0x22t
        0x5ft
    .end array-data

    :array_288
    .array-data 1
        0x44t
        -0x55t
        0x2ct
        -0x4ct
        0x74t
        -0x30t
        -0x3ft
        0x31t
    .end array-data

    :array_290
    .array-data 1
        0x39t
        -0x12t
        0x64t
        0x4ft
        -0x27t
        -0x49t
    .end array-data

    nop

    :array_298
    .array-data 1
        0x5ft
        -0x7ft
        0x8t
        0x2bt
        -0x44t
        -0x3bt
        0xft
        -0x51t
    .end array-data

    :array_2a0
    .array-data 1
        -0x37t
        0x61t
        0xft
        -0x20t
    .end array-data

    :array_2a6
    .array-data 1
        -0x45t
        0xet
        0x60t
        -0x6ct
        0x7t
        0x75t
        -0x6ct
        0x4dt
    .end array-data

    :array_2ae
    .array-data 1
        -0x5ft
        0x40t
        -0x2t
        0x63t
        -0x24t
        -0x3t
        -0x40t
        0x6ft
        -0x29t
        0x3ft
        -0x2bt
        0x31t
    .end array-data

    :array_2b8
    .array-data 1
        0x48t
        -0x28t
        0x41t
        -0x76t
        0x5bt
        0x71t
        0x25t
        -0x1ft
    .end array-data

    :array_2c0
    .array-data 1
        0x72t
        -0x1ft
        -0x40t
        -0x6bt
        -0x4t
        -0x29t
        -0x48t
        0x72t
        0x35t
        -0x62t
        -0x15t
        -0x39t
    .end array-data

    :array_2ca
    .array-data 1
        -0x65t
        0x79t
        0x7ft
        0x7ct
        0x7bt
        0x5bt
        0x5et
        -0x15t
    .end array-data

    :array_2d2
    .array-data 1
        -0x6ft
        -0x5ft
        0x7et
        -0x3ct
        0x2t
        0x77t
        0x54t
        0x68t
    .end array-data

    :array_2da
    .array-data 1
        0x5t
        -0x1t
        0x7ft
        0x0t
        0x5at
        0x45t
        0x1ft
        -0x1et
    .end array-data

    :array_2e2
    .array-data 1
        -0x2et
        -0x71t
        0x54t
        0x45t
        0x7bt
        -0x27t
        0x6at
        0x41t
    .end array-data

    :array_2ea
    .array-data 1
        -0x4dt
        -0x5ft
        -0x48t
    .end array-data

    :array_2f0
    .array-data 1
        -0xdt
        -0x1ft
        -0x8t
        0x10t
        -0x43t
        0x67t
        -0x8t
        -0x20t
    .end array-data

    :array_2f8
    .array-data 1
        0x7bt
        0x2dt
        0x24t
    .end array-data

    :array_2fe
    .array-data 1
        0x3bt
        0x6dt
        0x64t
        0x68t
        0x49t
        0xat
        0x7dt
        -0x73t
    .end array-data

    :array_306
    .array-data 1
        0x2bt
        -0xbt
        0x44t
        -0x60t
        -0x25t
        0x43t
        0x33t
        -0x22t
    .end array-data

    :array_30e
    .array-data 1
        0x49t
        -0x36t
        -0x5t
    .end array-data

    :array_314
    .array-data 1
        0x6dt
        -0x12t
        -0x21t
        -0x6dt
        -0x4bt
        0x14t
        0x78t
        -0x1ct
    .end array-data

    :array_31c
    .array-data 1
        -0x55t
        0x4bt
        0x34t
    .end array-data

    :array_322
    .array-data 1
        -0x71t
        0x6ft
        0x10t
        -0x66t
        -0x6ct
        -0x79t
        -0x19t
        -0x10t
    .end array-data

    :array_32a
    .array-data 1
        0x3t
        0x76t
        0x40t
        -0x1dt
        -0x3t
        -0x4at
        -0x71t
        0x7at
        0x7bt
        0x9t
        0x64t
        -0x6et
    .end array-data

    :array_334
    .array-data 1
        -0x16t
        -0x12t
        -0x1t
        0xat
        0x7at
        0x3at
        0x6bt
        -0x40t
    .end array-data
.end method
