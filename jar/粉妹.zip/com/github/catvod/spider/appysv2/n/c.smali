.class public final Lcom/github/catvod/spider/appysv2/n/c;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final b:Ljava/lang/String;

.field public static final c:Ljava/lang/String;


# instance fields
.field private a:Lokhttp3/OkHttpClient;


# direct methods
.method static constructor <clinit>()V
    .registers 3

    const/4 v0, 0x4

    new-array v0, v0, [B

    fill-array-data v0, :array_26

    const/16 v1, 0x8

    new-array v2, v1, [B

    fill-array-data v2, :array_2c

    invoke-static {v0, v2}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lcom/github/catvod/spider/appysv2/n/c;->b:Ljava/lang/String;

    const/4 v0, 0x3

    new-array v0, v0, [B

    fill-array-data v0, :array_34

    new-array v1, v1, [B

    fill-array-data v1, :array_3a

    invoke-static {v0, v1}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lcom/github/catvod/spider/appysv2/n/c;->c:Ljava/lang/String;

    return-void

    nop

    :array_26
    .array-data 1
        -0x72t
        0x46t
        0x11t
        0x5ct
    .end array-data

    :array_2c
    .array-data 1
        -0x22t
        0x9t
        0x42t
        0x8t
        -0x3at
        0x31t
        -0x65t
        0x2t
    .end array-data

    :array_34
    .array-data 1
        0x3t
        -0x7dt
        -0x36t
    .end array-data

    :array_3a
    .array-data 1
        0x44t
        -0x3at
        -0x62t
        -0x58t
        -0x6at
        -0x44t
        0x5dt
        -0x3et
    .end array-data
.end method

.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static a()Lokhttp3/OkHttpClient;
    .registers 5

    .line 1
    sget-object v0, Lcom/github/catvod/spider/appysv2/n/b;->a:Lcom/github/catvod/spider/appysv2/n/c;

    .line 2
    iget-object v0, v0, Lcom/github/catvod/spider/appysv2/n/c;->a:Lokhttp3/OkHttpClient;

    if-eqz v0, :cond_b

    .line 3
    sget-object v0, Lcom/github/catvod/spider/appysv2/n/b;->a:Lcom/github/catvod/spider/appysv2/n/c;

    .line 4
    iget-object v0, v0, Lcom/github/catvod/spider/appysv2/n/c;->a:Lokhttp3/OkHttpClient;

    return-object v0

    .line 5
    :cond_b
    sget-object v0, Lcom/github/catvod/spider/appysv2/n/b;->a:Lcom/github/catvod/spider/appysv2/n/c;

    .line 6
    new-instance v1, Lokhttp3/OkHttpClient$Builder;

    invoke-direct {v1}, Lokhttp3/OkHttpClient$Builder;-><init>()V

    .line 7
    :try_start_12
    invoke-static {}, Lcom/github/catvod/crawler/Spider;->safeDns()Lokhttp3/Dns;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    :try_end_19
    .catchall {:try_start_12 .. :try_end_19} :catchall_1a

    goto :goto_1c

    :catchall_1a
    sget-object v2, Lokhttp3/Dns;->SYSTEM:Lokhttp3/Dns;

    .line 8
    :goto_1c
    invoke-virtual {v1, v2}, Lokhttp3/OkHttpClient$Builder;->dns(Lokhttp3/Dns;)Lokhttp3/OkHttpClient$Builder;

    move-result-object v1

    sget-object v2, Ljava/util/concurrent/TimeUnit;->SECONDS:Ljava/util/concurrent/TimeUnit;

    const-wide/16 v3, 0x1e

    invoke-virtual {v1, v3, v4, v2}, Lokhttp3/OkHttpClient$Builder;->connectTimeout(JLjava/util/concurrent/TimeUnit;)Lokhttp3/OkHttpClient$Builder;

    move-result-object v1

    invoke-virtual {v1, v3, v4, v2}, Lokhttp3/OkHttpClient$Builder;->readTimeout(JLjava/util/concurrent/TimeUnit;)Lokhttp3/OkHttpClient$Builder;

    move-result-object v1

    invoke-virtual {v1, v3, v4, v2}, Lokhttp3/OkHttpClient$Builder;->writeTimeout(JLjava/util/concurrent/TimeUnit;)Lokhttp3/OkHttpClient$Builder;

    move-result-object v1

    sget-object v2, Lcom/github/catvod/spider/appysv2/n/a;->a:Lcom/github/catvod/spider/appysv2/n/a;

    invoke-virtual {v1, v2}, Lokhttp3/OkHttpClient$Builder;->hostnameVerifier(Ljavax/net/ssl/HostnameVerifier;)Lokhttp3/OkHttpClient$Builder;

    move-result-object v1

    new-instance v2, Lcom/github/catvod/spider/appysv2/n/g;

    invoke-direct {v2}, Lcom/github/catvod/spider/appysv2/n/g;-><init>()V

    sget-object v3, Lcom/github/catvod/spider/appysv2/n/g;->d:Ljavax/net/ssl/X509TrustManager;

    invoke-virtual {v1, v2, v3}, Lokhttp3/OkHttpClient$Builder;->sslSocketFactory(Ljavax/net/ssl/SSLSocketFactory;Ljavax/net/ssl/X509TrustManager;)Lokhttp3/OkHttpClient$Builder;

    move-result-object v1

    .line 9
    invoke-virtual {v1}, Lokhttp3/OkHttpClient$Builder;->build()Lokhttp3/OkHttpClient;

    move-result-object v1

    iput-object v1, v0, Lcom/github/catvod/spider/appysv2/n/c;->a:Lokhttp3/OkHttpClient;

    return-object v1
.end method

.method public static b(Ljava/lang/String;Ljava/util/Map;)Lcom/github/catvod/spider/appysv2/n/e;
    .registers 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;)",
            "Lcom/github/catvod/spider/appysv2/n/e;"
        }
    .end annotation

    new-instance v0, Lcom/github/catvod/spider/appysv2/n/d;

    sget-object v1, Lcom/github/catvod/spider/appysv2/n/c;->c:Ljava/lang/String;

    const/4 v2, 0x0

    invoke-direct {v0, v1, p0, v2, p1}, Lcom/github/catvod/spider/appysv2/n/d;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/util/Map;Ljava/util/Map;)V

    invoke-static {}, Lcom/github/catvod/spider/appysv2/n/c;->a()Lokhttp3/OkHttpClient;

    move-result-object p0

    invoke-virtual {v0, p0}, Lcom/github/catvod/spider/appysv2/n/d;->a(Lokhttp3/OkHttpClient;)Lcom/github/catvod/spider/appysv2/n/e;

    move-result-object p0

    return-object p0
.end method

.method public static c(Ljava/lang/String;Ljava/util/Map;)Ljava/lang/String;
    .registers 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;)",
            "Ljava/lang/String;"
        }
    .end annotation

    invoke-static {}, Lcom/github/catvod/spider/appysv2/n/c;->f()Lokhttp3/OkHttpClient;

    move-result-object v0

    new-instance v1, Lokhttp3/Request$Builder;

    invoke-direct {v1}, Lokhttp3/Request$Builder;-><init>()V

    invoke-virtual {v1, p0}, Lokhttp3/Request$Builder;->url(Ljava/lang/String;)Lokhttp3/Request$Builder;

    move-result-object p0

    invoke-static {p1}, Lokhttp3/Headers;->of(Ljava/util/Map;)Lokhttp3/Headers;

    move-result-object p1

    invoke-virtual {p0, p1}, Lokhttp3/Request$Builder;->headers(Lokhttp3/Headers;)Lokhttp3/Request$Builder;

    move-result-object p0

    invoke-virtual {p0}, Lokhttp3/Request$Builder;->build()Lokhttp3/Request;

    move-result-object p0

    invoke-virtual {v0, p0}, Lokhttp3/OkHttpClient;->newCall(Lokhttp3/Request;)Lokhttp3/Call;

    move-result-object p0

    invoke-interface {p0}, Lokhttp3/Call;->execute()Lokhttp3/Response;

    move-result-object p0

    invoke-virtual {p0}, Lokhttp3/Response;->headers()Lokhttp3/Headers;

    move-result-object p0

    invoke-virtual {p0}, Lokhttp3/Headers;->toMultimap()Ljava/util/Map;

    move-result-object p0

    if-nez p0, :cond_2c

    goto :goto_81

    :cond_2c
    const/16 p1, 0x8

    new-array v0, p1, [B

    fill-array-data v0, :array_84

    new-array v1, p1, [B

    fill-array-data v1, :array_8c

    invoke-static {v0, v1}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-interface {p0, v0}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    move-result v0

    const/4 v1, 0x0

    if-eqz v0, :cond_52

    new-array v0, p1, [B

    fill-array-data v0, :array_94

    new-array p1, p1, [B

    fill-array-data p1, :array_9c

    invoke-static {v0, p1}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object p1

    goto :goto_74

    :cond_52
    new-array v0, p1, [B

    fill-array-data v0, :array_a4

    new-array v2, p1, [B

    fill-array-data v2, :array_ac

    invoke-static {v0, v2}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-interface {p0, v0}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_81

    new-array v0, p1, [B

    fill-array-data v0, :array_b4

    new-array p1, p1, [B

    fill-array-data p1, :array_bc

    invoke-static {v0, p1}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object p1

    :goto_74
    invoke-interface {p0, p1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/util/List;

    invoke-interface {p0, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/String;

    goto :goto_82

    :cond_81
    :goto_81
    const/4 p0, 0x0

    :goto_82
    return-object p0

    nop

    :array_84
    .array-data 1
        0x56t
        -0x2et
        -0x28t
        0x12t
        0x2bt
        0x46t
        0x3bt
        0x2bt
    .end array-data

    :array_8c
    .array-data 1
        0x3at
        -0x43t
        -0x45t
        0x73t
        0x5ft
        0x2ft
        0x54t
        0x45t
    .end array-data

    :array_94
    .array-data 1
        -0x4ft
        0x4et
        -0x57t
        0x0t
        0x64t
        0x30t
        0x58t
        -0x12t
    .end array-data

    :array_9c
    .array-data 1
        -0x23t
        0x21t
        -0x36t
        0x61t
        0x10t
        0x59t
        0x37t
        -0x80t
    .end array-data

    :array_a4
    .array-data 1
        0x22t
        -0x7ft
        -0x56t
        0x54t
        -0x75t
        -0x6dt
        -0x3t
        0x5dt
    .end array-data

    :array_ac
    .array-data 1
        0x6et
        -0x12t
        -0x37t
        0x35t
        -0x1t
        -0x6t
        -0x6et
        0x33t
    .end array-data

    :array_b4
    .array-data 1
        -0x49t
        -0x5bt
        -0x38t
        -0x68t
        0x6bt
        -0x73t
        -0x2ft
        -0x50t
    .end array-data

    :array_bc
    .array-data 1
        -0x5t
        -0x36t
        -0x55t
        -0x7t
        0x1ft
        -0x1ct
        -0x42t
        -0x22t
    .end array-data
.end method

.method public static d(Ljava/lang/String;)Lokhttp3/Response;
    .registers 3

    invoke-static {}, Lcom/github/catvod/spider/appysv2/n/c;->a()Lokhttp3/OkHttpClient;

    move-result-object v0

    new-instance v1, Lokhttp3/Request$Builder;

    invoke-direct {v1}, Lokhttp3/Request$Builder;-><init>()V

    invoke-virtual {v1, p0}, Lokhttp3/Request$Builder;->url(Ljava/lang/String;)Lokhttp3/Request$Builder;

    move-result-object p0

    invoke-virtual {p0}, Lokhttp3/Request$Builder;->build()Lokhttp3/Request;

    move-result-object p0

    invoke-virtual {v0, p0}, Lokhttp3/OkHttpClient;->newCall(Lokhttp3/Request;)Lokhttp3/Call;

    move-result-object p0

    invoke-interface {p0}, Lokhttp3/Call;->execute()Lokhttp3/Response;

    move-result-object p0

    return-object p0
.end method

.method public static e(Ljava/lang/String;Ljava/util/Map;)Lokhttp3/Response;
    .registers 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;)",
            "Lokhttp3/Response;"
        }
    .end annotation

    invoke-static {}, Lcom/github/catvod/spider/appysv2/n/c;->a()Lokhttp3/OkHttpClient;

    move-result-object v0

    new-instance v1, Lokhttp3/Request$Builder;

    invoke-direct {v1}, Lokhttp3/Request$Builder;-><init>()V

    invoke-virtual {v1, p0}, Lokhttp3/Request$Builder;->url(Ljava/lang/String;)Lokhttp3/Request$Builder;

    move-result-object p0

    invoke-static {p1}, Lokhttp3/Headers;->of(Ljava/util/Map;)Lokhttp3/Headers;

    move-result-object p1

    invoke-virtual {p0, p1}, Lokhttp3/Request$Builder;->headers(Lokhttp3/Headers;)Lokhttp3/Request$Builder;

    move-result-object p0

    invoke-virtual {p0}, Lokhttp3/Request$Builder;->build()Lokhttp3/Request;

    move-result-object p0

    invoke-virtual {v0, p0}, Lokhttp3/OkHttpClient;->newCall(Lokhttp3/Request;)Lokhttp3/Call;

    move-result-object p0

    invoke-interface {p0}, Lokhttp3/Call;->execute()Lokhttp3/Response;

    move-result-object p0

    return-object p0
.end method

.method public static f()Lokhttp3/OkHttpClient;
    .registers 2

    invoke-static {}, Lcom/github/catvod/spider/appysv2/n/c;->a()Lokhttp3/OkHttpClient;

    move-result-object v0

    invoke-virtual {v0}, Lokhttp3/OkHttpClient;->newBuilder()Lokhttp3/OkHttpClient$Builder;

    move-result-object v0

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Lokhttp3/OkHttpClient$Builder;->followRedirects(Z)Lokhttp3/OkHttpClient$Builder;

    move-result-object v0

    invoke-virtual {v0, v1}, Lokhttp3/OkHttpClient$Builder;->followSslRedirects(Z)Lokhttp3/OkHttpClient$Builder;

    move-result-object v0

    invoke-virtual {v0}, Lokhttp3/OkHttpClient$Builder;->build()Lokhttp3/OkHttpClient;

    move-result-object v0

    return-object v0
.end method

.method public static g(Ljava/lang/String;Ljava/lang/String;Ljava/util/Map;)Lcom/github/catvod/spider/appysv2/n/e;
    .registers 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;)",
            "Lcom/github/catvod/spider/appysv2/n/e;"
        }
    .end annotation

    invoke-static {}, Lcom/github/catvod/spider/appysv2/n/c;->a()Lokhttp3/OkHttpClient;

    move-result-object v0

    new-instance v1, Lcom/github/catvod/spider/appysv2/n/d;

    sget-object v2, Lcom/github/catvod/spider/appysv2/n/c;->b:Ljava/lang/String;

    invoke-direct {v1, v2, p0, p1, p2}, Lcom/github/catvod/spider/appysv2/n/d;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/util/Map;)V

    invoke-virtual {v1, v0}, Lcom/github/catvod/spider/appysv2/n/d;->a(Lokhttp3/OkHttpClient;)Lcom/github/catvod/spider/appysv2/n/e;

    move-result-object p0

    return-object p0
.end method

.method public static h(Ljava/lang/String;Ljava/util/Map;Ljava/util/Map;)Lcom/github/catvod/spider/appysv2/n/e;
    .registers 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;)",
            "Lcom/github/catvod/spider/appysv2/n/e;"
        }
    .end annotation

    invoke-static {}, Lcom/github/catvod/spider/appysv2/n/c;->a()Lokhttp3/OkHttpClient;

    move-result-object v0

    new-instance v1, Lcom/github/catvod/spider/appysv2/n/d;

    sget-object v2, Lcom/github/catvod/spider/appysv2/n/c;->b:Ljava/lang/String;

    invoke-direct {v1, v2, p0, p1, p2}, Lcom/github/catvod/spider/appysv2/n/d;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/util/Map;Ljava/util/Map;)V

    invoke-virtual {v1, v0}, Lcom/github/catvod/spider/appysv2/n/d;->a(Lokhttp3/OkHttpClient;)Lcom/github/catvod/spider/appysv2/n/e;

    move-result-object p0

    return-object p0
.end method

.method public static i(Ljava/lang/String;Ljava/util/Map;)Ljava/lang/String;
    .registers 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;)",
            "Ljava/lang/String;"
        }
    .end annotation

    invoke-static {}, Lcom/github/catvod/spider/appysv2/n/c;->a()Lokhttp3/OkHttpClient;

    move-result-object v0

    .line 1
    new-instance v1, Lcom/github/catvod/spider/appysv2/n/d;

    sget-object v2, Lcom/github/catvod/spider/appysv2/n/c;->b:Ljava/lang/String;

    const/4 v3, 0x0

    invoke-direct {v1, v2, p0, p1, v3}, Lcom/github/catvod/spider/appysv2/n/d;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/util/Map;Ljava/util/Map;)V

    invoke-virtual {v1, v0}, Lcom/github/catvod/spider/appysv2/n/d;->a(Lokhttp3/OkHttpClient;)Lcom/github/catvod/spider/appysv2/n/e;

    move-result-object p0

    .line 2
    invoke-virtual {p0}, Lcom/github/catvod/spider/appysv2/n/e;->a()Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method public static j(Ljava/lang/String;Ljava/lang/String;)Lokhttp3/Response;
    .registers 7

    invoke-static {}, Lcom/github/catvod/spider/appysv2/n/c;->a()Lokhttp3/OkHttpClient;

    move-result-object v0

    const/16 v1, 0xa

    new-array v2, v1, [B

    fill-array-data v2, :array_7e

    const/16 v3, 0x8

    new-array v4, v3, [B

    fill-array-data v4, :array_88

    invoke-static {v2, v4}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Lokhttp3/MediaType;->parse(Ljava/lang/String;)Lokhttp3/MediaType;

    move-result-object v2

    invoke-static {v2, p1}, Lokhttp3/RequestBody;->create(Lokhttp3/MediaType;Ljava/lang/String;)Lokhttp3/RequestBody;

    move-result-object p1

    new-instance v2, Lokhttp3/Request$Builder;

    invoke-direct {v2}, Lokhttp3/Request$Builder;-><init>()V

    invoke-virtual {v2, p0}, Lokhttp3/Request$Builder;->url(Ljava/lang/String;)Lokhttp3/Request$Builder;

    move-result-object p0

    sget-object v2, Lcom/github/catvod/spider/appysv2/n/c;->b:Ljava/lang/String;

    invoke-virtual {p0, v2, p1}, Lokhttp3/Request$Builder;->method(Ljava/lang/String;Lokhttp3/RequestBody;)Lokhttp3/Request$Builder;

    move-result-object p0

    const/16 p1, 0xc

    new-array p1, p1, [B

    fill-array-data p1, :array_90

    new-array v2, v3, [B

    fill-array-data v2, :array_9a

    invoke-static {p1, v2}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object p1

    new-array v1, v1, [B

    fill-array-data v1, :array_a2

    new-array v2, v3, [B

    fill-array-data v2, :array_ac

    invoke-static {v1, v2}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {p0, p1, v1}, Lokhttp3/Request$Builder;->addHeader(Ljava/lang/String;Ljava/lang/String;)Lokhttp3/Request$Builder;

    move-result-object p0

    const/4 p1, 0x6

    new-array p1, p1, [B

    fill-array-data p1, :array_b4

    new-array v1, v3, [B

    fill-array-data v1, :array_bc

    invoke-static {p1, v1}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object p1

    const/4 v1, 0x3

    new-array v1, v1, [B

    fill-array-data v1, :array_c4

    new-array v2, v3, [B

    fill-array-data v2, :array_ca

    invoke-static {v1, v2}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {p0, p1, v1}, Lokhttp3/Request$Builder;->addHeader(Ljava/lang/String;Ljava/lang/String;)Lokhttp3/Request$Builder;

    move-result-object p0

    invoke-virtual {p0}, Lokhttp3/Request$Builder;->build()Lokhttp3/Request;

    move-result-object p0

    invoke-virtual {v0, p0}, Lokhttp3/OkHttpClient;->newCall(Lokhttp3/Request;)Lokhttp3/Call;

    move-result-object p0

    invoke-interface {p0}, Lokhttp3/Call;->execute()Lokhttp3/Response;

    move-result-object p0

    return-object p0

    :array_7e
    .array-data 1
        -0x6bt
        -0x6t
        -0x13t
        0x1dt
        -0x65t
        0x10t
        -0x2ct
        -0x7et
        -0x78t
        -0xft
    .end array-data

    nop

    :array_88
    .array-data 1
        -0x1ft
        -0x61t
        -0x6bt
        0x69t
        -0x4ct
        0x60t
        -0x48t
        -0x1dt
    .end array-data

    :array_90
    .array-data 1
        -0x6ct
        0x2ft
        -0x3at
        -0x2dt
        -0x2bt
        0x2at
        0x7bt
        -0xat
        -0x7dt
        0x39t
        -0x28t
        -0x3et
    .end array-data

    :array_9a
    .array-data 1
        -0x29t
        0x40t
        -0x58t
        -0x59t
        -0x50t
        0x44t
        0xft
        -0x25t
    .end array-data

    :array_a2
    .array-data 1
        0x5t
        0x51t
        -0x56t
        0x28t
        0x13t
        0x41t
        -0x3dt
        -0x28t
        0x18t
        0x5at
    .end array-data

    nop

    :array_ac
    .array-data 1
        0x71t
        0x34t
        -0x2et
        0x5ct
        0x3ct
        0x31t
        -0x51t
        -0x47t
    .end array-data

    :array_b4
    .array-data 1
        -0x6dt
        0x17t
        -0x55t
        -0xet
        -0x1ct
        -0x3ct
    .end array-data

    nop

    :array_bc
    .array-data 1
        -0x24t
        0x65t
        -0x3et
        -0x6bt
        -0x73t
        -0x56t
        -0x27t
        -0x6at
    .end array-data

    :array_c4
    .array-data 1
        -0xbt
        -0x20t
        -0x2bt
    .end array-data

    :array_ca
    .array-data 1
        -0x80t
        -0x6et
        -0x47t
        0x34t
        0x22t
        0x7ft
        0x1t
        -0x77t
    .end array-data
.end method

.method public static k(Lokhttp3/OkHttpClient;Ljava/lang/String;Ljava/util/Map;Ljava/util/Map;)Lcom/github/catvod/spider/appysv2/n/e;
    .registers 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lokhttp3/OkHttpClient;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;)",
            "Lcom/github/catvod/spider/appysv2/n/e;"
        }
    .end annotation

    new-instance v0, Lcom/github/catvod/spider/appysv2/n/d;

    sget-object v1, Lcom/github/catvod/spider/appysv2/n/c;->c:Ljava/lang/String;

    invoke-direct {v0, v1, p1, p2, p3}, Lcom/github/catvod/spider/appysv2/n/d;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/util/Map;Ljava/util/Map;)V

    invoke-virtual {v0, p0}, Lcom/github/catvod/spider/appysv2/n/d;->a(Lokhttp3/OkHttpClient;)Lcom/github/catvod/spider/appysv2/n/e;

    move-result-object p0

    return-object p0
.end method

.method public static l(Ljava/lang/String;)Ljava/lang/String;
    .registers 2

    const/4 v0, 0x0

    invoke-static {p0, v0}, Lcom/github/catvod/spider/appysv2/n/c;->m(Ljava/lang/String;Ljava/util/Map;)Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method public static m(Ljava/lang/String;Ljava/util/Map;)Ljava/lang/String;
    .registers 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;)",
            "Ljava/lang/String;"
        }
    .end annotation

    invoke-static {}, Lcom/github/catvod/spider/appysv2/n/c;->a()Lokhttp3/OkHttpClient;

    move-result-object v0

    const/4 v1, 0x4

    new-array v1, v1, [B

    fill-array-data v1, :array_30

    const/16 v2, 0x8

    new-array v2, v2, [B

    fill-array-data v2, :array_36

    invoke-static {v1, v2}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {p0, v1}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_2c

    new-instance v1, Lcom/github/catvod/spider/appysv2/n/d;

    sget-object v2, Lcom/github/catvod/spider/appysv2/n/c;->c:Ljava/lang/String;

    const/4 v3, 0x0

    invoke-direct {v1, v2, p0, v3, p1}, Lcom/github/catvod/spider/appysv2/n/d;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/util/Map;Ljava/util/Map;)V

    invoke-virtual {v1, v0}, Lcom/github/catvod/spider/appysv2/n/d;->a(Lokhttp3/OkHttpClient;)Lcom/github/catvod/spider/appysv2/n/e;

    move-result-object p0

    invoke-virtual {p0}, Lcom/github/catvod/spider/appysv2/n/e;->a()Ljava/lang/String;

    move-result-object p0

    goto :goto_2e

    :cond_2c
    const-string p0, ""

    :goto_2e
    return-object p0

    nop

    :array_30
    .array-data 1
        0x22t
        -0x7et
        0x38t
        -0x4ft
    .end array-data

    :array_36
    .array-data 1
        0x4at
        -0xat
        0x4ct
        -0x3ft
        0x59t
        0x6ct
        -0x59t
        -0x50t
    .end array-data
.end method
