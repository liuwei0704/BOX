.class public final Lcom/github/catvod/spider/appysv2/n/g;
.super Ljavax/net/ssl/SSLSocketFactory;
.source "SourceFile"


# static fields
.field public static final d:Ljavax/net/ssl/X509TrustManager;
    .annotation build Landroid/annotation/SuppressLint;
        value = {
            "TrustAllX509TrustManager",
            "CustomX509TrustManager"
        }
    .end annotation
.end field


# instance fields
.field private a:Ljavax/net/ssl/SSLSocketFactory;

.field private b:[Ljava/lang/String;

.field private c:[Ljava/lang/String;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    new-instance v0, Lcom/github/catvod/spider/appysv2/n/f;

    invoke-direct {v0}, Lcom/github/catvod/spider/appysv2/n/f;-><init>()V

    sput-object v0, Lcom/github/catvod/spider/appysv2/n/g;->d:Ljavax/net/ssl/X509TrustManager;

    return-void
.end method

.method public constructor <init>()V
    .registers 30

    move-object/from16 v1, p0

    invoke-direct/range {p0 .. p0}, Ljavax/net/ssl/SSLSocketFactory;-><init>()V

    :try_start_5
    new-instance v2, Ljava/util/LinkedList;

    invoke-direct {v2}, Ljava/util/LinkedList;-><init>()V

    invoke-static {}, Ljavax/net/ssl/SSLSocketFactory;->getDefault()Ljavax/net/SocketFactory;

    move-result-object v3

    invoke-virtual {v3}, Ljavax/net/SocketFactory;->createSocket()Ljava/net/Socket;

    move-result-object v3

    check-cast v3, Ljavax/net/ssl/SSLSocket;

    invoke-virtual {v3}, Ljavax/net/ssl/SSLSocket;->getSupportedProtocols()[Ljava/lang/String;

    move-result-object v4

    array-length v5, v4

    const/4 v6, 0x0

    const/4 v7, 0x0

    :goto_1b
    const/4 v11, 0x4

    const/16 v12, 0x8

    const/4 v13, 0x2

    const/4 v14, 0x3

    const/4 v15, 0x1

    if-ge v7, v5, :cond_6c

    aget-object v10, v4, v7

    invoke-virtual {v10}, Ljava/lang/String;->toUpperCase()Ljava/lang/String;

    move-result-object v9

    new-array v8, v14, [B

    const/16 v19, 0x1d

    aput-byte v19, v8, v6

    const/16 v19, 0x76

    aput-byte v19, v8, v15

    const/16 v19, -0x2f

    aput-byte v19, v8, v13

    new-array v12, v12, [B

    const/16 v19, 0x4e

    aput-byte v19, v12, v6

    const/16 v19, 0x25

    aput-byte v19, v12, v15

    const/16 v15, -0x63

    aput-byte v15, v12, v13

    const/16 v13, 0x4e

    aput-byte v13, v12, v14

    const/16 v13, -0x63

    aput-byte v13, v12, v11

    const/16 v11, 0x4e

    const/4 v13, 0x5

    aput-byte v11, v12, v13

    const/16 v11, -0x4a

    const/4 v13, 0x6

    aput-byte v11, v12, v13

    const/16 v11, 0x51

    const/4 v13, 0x7

    aput-byte v11, v12, v13

    invoke-static {v8, v12}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v9, v8}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v8

    if-nez v8, :cond_69

    invoke-virtual {v2, v10}, Ljava/util/LinkedList;->add(Ljava/lang/Object;)Z

    :cond_69
    add-int/lit8 v7, v7, 0x1

    goto :goto_1b

    :cond_6c
    new-array v4, v6, [Ljava/lang/String;

    invoke-virtual {v2, v4}, Ljava/util/LinkedList;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;

    move-result-object v2

    check-cast v2, [Ljava/lang/String;

    iput-object v2, v1, Lcom/github/catvod/spider/appysv2/n/g;->c:[Ljava/lang/String;

    const/16 v2, 0xe

    new-array v4, v2, [Ljava/lang/String;

    const/16 v5, 0x1f

    new-array v7, v5, [B

    const/16 v8, 0x55

    aput-byte v8, v7, v6

    const/16 v8, 0x54

    aput-byte v8, v7, v15

    const/16 v8, -0x54

    aput-byte v8, v7, v13

    const/16 v8, 0x5d

    aput-byte v8, v7, v14

    const/16 v8, -0x79

    aput-byte v8, v7, v11

    const/16 v8, 0x52

    const/4 v9, 0x5

    aput-byte v8, v7, v9

    const/16 v8, -0x5e

    const/4 v9, 0x6

    aput-byte v8, v7, v9

    const/16 v8, -0x3e

    const/4 v9, 0x7

    aput-byte v8, v7, v9

    const/16 v8, 0x56

    aput-byte v8, v7, v12

    const/16 v8, 0x51

    const/16 v9, 0x9

    aput-byte v8, v7, v9

    const/16 v8, -0x55

    const/16 v10, 0xa

    aput-byte v8, v7, v10

    const/16 v8, 0x4a

    const/16 v19, 0xb

    aput-byte v8, v7, v19

    const/16 v8, -0x76

    const/16 v20, 0xc

    aput-byte v8, v7, v20

    const/16 v8, 0x40

    const/16 v21, 0xd

    aput-byte v8, v7, v21

    const/16 v8, -0x5a

    aput-byte v8, v7, v2

    const/16 v8, -0x32

    const/16 v22, 0xf

    aput-byte v8, v7, v22

    const/16 v8, 0x5e

    const/16 v23, 0x10

    aput-byte v8, v7, v23

    const/16 v8, 0x11

    const/16 v24, 0x2a

    aput-byte v24, v7, v8

    const/16 v8, -0x36

    const/16 v24, 0x12

    aput-byte v8, v7, v24

    const/16 v8, 0x13

    const/16 v25, 0x34

    aput-byte v25, v7, v8

    const/16 v8, 0x14

    const/16 v25, -0x76

    aput-byte v25, v7, v8

    const/16 v8, 0x15

    const/16 v25, 0x46

    aput-byte v25, v7, v8

    const/16 v8, -0x60

    const/16 v25, 0x16

    aput-byte v8, v7, v25

    const/16 v8, -0x30

    const/16 v26, 0x17

    aput-byte v8, v7, v26

    const/16 v8, 0x18

    const/16 v27, 0x5e

    aput-byte v27, v7, v8

    const/16 v8, 0x19

    const/16 v27, 0x4b

    aput-byte v27, v7, v8

    const/16 v8, 0x1a

    const/16 v27, -0x49

    aput-byte v27, v7, v8

    const/16 v8, 0x1b

    const/16 v27, 0x43

    aput-byte v27, v7, v8

    const/16 v8, -0x1a

    const/16 v2, 0x1c

    aput-byte v8, v7, v2

    const/16 v8, 0x1d

    const/16 v28, 0x39

    aput-byte v28, v7, v8

    const/16 v8, 0x1e

    const/16 v28, -0x29

    aput-byte v28, v7, v8

    new-array v8, v12, [B

    aput-byte v15, v8, v6

    const/16 v28, 0x18

    aput-byte v28, v8, v15

    const/16 v28, -0x1

    aput-byte v28, v8, v13

    aput-byte v13, v8, v14

    const/16 v28, -0x2b

    aput-byte v28, v8, v11

    const/16 v18, 0x5

    aput-byte v15, v8, v18

    const/16 v28, -0x1d

    const/16 v17, 0x6

    aput-byte v28, v8, v17

    const/16 v28, -0x63

    const/16 v16, 0x7

    aput-byte v28, v8, v16

    invoke-static {v7, v8}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v7

    aput-object v7, v4, v6

    new-array v7, v5, [B

    const/16 v8, -0x1c

    aput-byte v8, v7, v6

    const/16 v8, 0x53

    aput-byte v8, v7, v15

    const/16 v8, -0x6a

    aput-byte v8, v7, v13

    const/16 v8, -0x61

    aput-byte v8, v7, v14

    const/16 v8, 0x70

    aput-byte v8, v7, v11

    const/16 v8, -0x64

    const/16 v18, 0x5

    aput-byte v8, v7, v18

    const/4 v8, 0x6

    aput-byte v9, v7, v8

    const/16 v8, 0x65

    const/16 v16, 0x7

    aput-byte v8, v7, v16

    const/16 v8, -0x19

    aput-byte v8, v7, v12

    const/16 v8, 0x56

    aput-byte v8, v7, v9

    const/16 v8, -0x6f

    aput-byte v8, v7, v10

    const/16 v8, -0x78

    aput-byte v8, v7, v19

    const/16 v8, 0x7d

    aput-byte v8, v7, v20

    const/16 v8, -0x72

    aput-byte v8, v7, v21

    const/16 v8, 0xe

    aput-byte v21, v7, v8

    const/16 v8, 0x69

    aput-byte v8, v7, v22

    const/16 v8, -0x11

    aput-byte v8, v7, v23

    const/16 v8, 0x11

    const/16 v28, 0x2e

    aput-byte v28, v7, v8

    const/16 v8, -0x9

    aput-byte v8, v7, v24

    const/16 v8, 0x13

    const/16 v28, -0x8

    aput-byte v28, v7, v8

    const/16 v8, 0x14

    const/16 v28, 0x7d

    aput-byte v28, v7, v8

    const/16 v8, 0x15

    const/16 v28, -0x78

    aput-byte v28, v7, v8

    aput-byte v19, v7, v25

    const/16 v8, 0x77

    aput-byte v8, v7, v26

    const/16 v8, 0x18

    const/16 v28, -0x11

    aput-byte v28, v7, v8

    const/16 v8, 0x19

    const/16 v28, 0x4c

    aput-byte v28, v7, v8

    const/16 v8, 0x1a

    const/16 v28, -0x73

    aput-byte v28, v7, v8

    const/16 v8, 0x1b

    const/16 v28, -0x7f

    aput-byte v28, v7, v8

    aput-byte v23, v7, v2

    const/16 v8, 0x1d

    const/16 v28, -0x6

    aput-byte v28, v7, v8

    const/16 v8, 0x1e

    const/16 v28, 0x7e

    aput-byte v28, v7, v8

    new-array v8, v12, [B

    const/16 v28, -0x50

    aput-byte v28, v8, v6

    aput-byte v5, v8, v15

    const/16 v28, -0x3b

    aput-byte v28, v8, v13

    const/16 v28, -0x40

    aput-byte v28, v8, v14

    const/16 v28, 0x22

    aput-byte v28, v8, v11

    const/16 v28, -0x31

    const/16 v18, 0x5

    aput-byte v28, v8, v18

    const/16 v28, 0x48

    const/16 v17, 0x6

    aput-byte v28, v8, v17

    const/16 v28, 0x3a

    const/16 v16, 0x7

    aput-byte v28, v8, v16

    invoke-static {v7, v8}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v7

    aput-object v7, v4, v15

    const/16 v7, 0x27

    new-array v7, v7, [B

    const/16 v8, -0x10

    aput-byte v8, v7, v6

    const/16 v8, -0x35

    aput-byte v8, v7, v15

    const/16 v8, -0x4a

    aput-byte v8, v7, v13

    const/16 v8, -0x76

    aput-byte v8, v7, v14

    const/16 v8, 0x46

    aput-byte v8, v7, v11

    const/16 v8, 0x33

    const/16 v18, 0x5

    aput-byte v8, v7, v18

    const/16 v8, -0x15

    const/16 v17, 0x6

    aput-byte v8, v7, v17

    const/4 v8, -0x5

    const/16 v16, 0x7

    aput-byte v8, v7, v16

    const/16 v8, -0x1f

    aput-byte v8, v7, v12

    const/16 v8, -0x28

    aput-byte v8, v7, v9

    const/16 v8, -0x60

    aput-byte v8, v7, v10

    const/16 v8, -0x6a

    aput-byte v8, v7, v19

    const/16 v8, 0x47

    aput-byte v8, v7, v20

    const/16 v8, 0x23

    aput-byte v8, v7, v21

    const/16 v8, -0x12

    const/16 v27, 0xe

    aput-byte v8, v7, v27

    const/16 v8, -0x14

    aput-byte v8, v7, v22

    const/16 v8, -0xd

    aput-byte v8, v7, v23

    const/16 v8, 0x11

    const/16 v28, -0x32

    aput-byte v28, v7, v8

    const/16 v8, -0x4f

    aput-byte v8, v7, v24

    const/16 v8, 0x13

    const/16 v28, -0x63

    aput-byte v28, v7, v8

    const/16 v8, 0x14

    const/16 v28, 0x5c

    aput-byte v28, v7, v8

    const/16 v8, 0x15

    const/16 v28, 0x31

    aput-byte v28, v7, v8

    const/16 v8, -0x16

    aput-byte v8, v7, v25

    const/16 v8, -0x20

    aput-byte v8, v7, v26

    const/16 v8, 0x18

    const/16 v28, -0x5

    aput-byte v28, v7, v8

    const/16 v8, 0x19

    const/16 v28, -0x4a

    aput-byte v28, v7, v8

    const/16 v8, 0x1a

    const/16 v28, -0x29

    aput-byte v28, v7, v8

    const/16 v8, 0x1b

    const/16 v28, -0x13

    aput-byte v28, v7, v8

    const/16 v8, 0x5c

    aput-byte v8, v7, v2

    const/16 v8, 0x1d

    const/16 v28, 0x33

    aput-byte v28, v7, v8

    const/16 v8, 0x1e

    const/16 v28, -0x13

    aput-byte v28, v7, v8

    const/16 v8, -0x10

    aput-byte v8, v7, v5

    const/16 v8, 0x20

    const/16 v28, -0x5

    aput-byte v28, v7, v8

    const/16 v8, 0x21

    const/16 v28, -0x2c

    aput-byte v28, v7, v8

    const/16 v8, 0x22

    const/16 v28, -0x53

    aput-byte v28, v7, v8

    const/16 v8, 0x23

    const/16 v28, -0x6c

    aput-byte v28, v7, v8

    const/16 v8, 0x24

    const/16 v28, 0x31

    aput-byte v28, v7, v8

    const/16 v8, 0x25

    const/16 v28, 0x45

    aput-byte v28, v7, v8

    const/16 v8, 0x26

    const/16 v28, -0x67

    aput-byte v28, v7, v8

    new-array v8, v12, [B

    const/16 v28, -0x5c

    aput-byte v28, v8, v6

    const/16 v28, -0x79

    aput-byte v28, v8, v15

    const/16 v28, -0x1b

    aput-byte v28, v8, v13

    const/16 v28, -0x2b

    aput-byte v28, v8, v14

    aput-byte v14, v8, v11

    const/16 v28, 0x70

    const/16 v18, 0x5

    aput-byte v28, v8, v18

    const/16 v28, -0x51

    const/16 v17, 0x6

    aput-byte v28, v8, v17

    const/16 v28, -0x4d

    const/16 v16, 0x7

    aput-byte v28, v8, v16

    invoke-static {v7, v8}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v7

    aput-object v7, v4, v13

    const/16 v7, 0x27

    new-array v7, v7, [B

    const/16 v8, -0x5f

    aput-byte v8, v7, v6

    const/16 v8, 0x79

    aput-byte v8, v7, v15

    aput-byte v11, v7, v13

    const/16 v8, 0x2a

    aput-byte v8, v7, v14

    const/16 v8, 0x4b

    aput-byte v8, v7, v11

    const/16 v8, 0x5a

    const/16 v18, 0x5

    aput-byte v8, v7, v18

    const/16 v8, 0x78

    const/16 v17, 0x6

    aput-byte v8, v7, v17

    const/16 v8, 0x36

    const/16 v16, 0x7

    aput-byte v8, v7, v16

    const/16 v8, -0x50

    aput-byte v8, v7, v12

    const/16 v8, 0x6a

    aput-byte v8, v7, v9

    aput-byte v24, v7, v10

    const/16 v8, 0x36

    aput-byte v8, v7, v19

    const/16 v8, 0x4a

    aput-byte v8, v7, v20

    const/16 v8, 0x4a

    aput-byte v8, v7, v21

    const/16 v8, 0x7d

    const/16 v27, 0xe

    aput-byte v8, v7, v27

    const/16 v8, 0x21

    aput-byte v8, v7, v22

    const/16 v8, -0x5e

    aput-byte v8, v7, v23

    const/16 v8, 0x11

    const/16 v28, 0x7c

    aput-byte v28, v7, v8

    aput-byte v14, v7, v24

    const/16 v8, 0x13

    const/16 v28, 0x3d

    aput-byte v28, v7, v8

    const/16 v8, 0x14

    const/16 v28, 0x51

    aput-byte v28, v7, v8

    const/16 v8, 0x15

    const/16 v28, 0x58

    aput-byte v28, v7, v8

    const/16 v8, 0x79

    aput-byte v8, v7, v25

    const/16 v8, 0x2d

    aput-byte v8, v7, v26

    const/16 v8, 0x18

    const/16 v28, -0x56

    aput-byte v28, v7, v8

    const/16 v8, 0x19

    aput-byte v11, v7, v8

    const/16 v8, 0x1a

    const/16 v28, 0x65

    aput-byte v28, v7, v8

    const/16 v8, 0x1b

    const/16 v28, 0x4d

    aput-byte v28, v7, v8

    const/16 v8, 0x51

    aput-byte v8, v7, v2

    const/16 v8, 0x1d

    const/16 v28, 0x5e

    aput-byte v28, v7, v8

    const/16 v8, 0x1e

    const/16 v28, 0x7f

    aput-byte v28, v7, v8

    const/16 v8, 0x33

    aput-byte v8, v7, v5

    const/16 v8, 0x20

    const/16 v28, -0x56

    aput-byte v28, v7, v8

    const/16 v8, 0x21

    const/16 v28, 0x66

    aput-byte v28, v7, v8

    const/16 v8, 0x22

    aput-byte v5, v7, v8

    const/16 v8, 0x23

    const/16 v28, 0x34

    aput-byte v28, v7, v8

    const/16 v8, 0x24

    const/16 v28, 0x3c

    aput-byte v28, v7, v8

    const/16 v8, 0x25

    const/16 v28, 0x2c

    aput-byte v28, v7, v8

    const/16 v8, 0x26

    aput-byte v10, v7, v8

    new-array v8, v12, [B

    const/16 v28, -0xb

    aput-byte v28, v8, v6

    const/16 v28, 0x35

    aput-byte v28, v8, v15

    const/16 v28, 0x57

    aput-byte v28, v8, v13

    const/16 v28, 0x75

    aput-byte v28, v8, v14

    const/16 v27, 0xe

    aput-byte v27, v8, v11

    const/16 v28, 0x19

    const/16 v18, 0x5

    aput-byte v28, v8, v18

    const/16 v28, 0x3c

    const/16 v17, 0x6

    aput-byte v28, v8, v17

    const/16 v28, 0x7e

    const/16 v16, 0x7

    aput-byte v28, v8, v16

    invoke-static {v7, v8}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v7

    aput-object v7, v4, v14

    const/16 v7, 0x27

    new-array v7, v7, [B

    aput-byte v2, v7, v6

    const/16 v8, 0x76

    aput-byte v8, v7, v15

    const/16 v8, -0x6a

    aput-byte v8, v7, v13

    aput-byte v15, v7, v14

    const/16 v8, -0x5f

    aput-byte v8, v7, v11

    const/16 v8, -0x66

    const/16 v18, 0x5

    aput-byte v8, v7, v18

    const/4 v8, 0x6

    const/16 v16, 0x7

    aput-byte v16, v7, v8

    const/16 v8, -0x37

    aput-byte v8, v7, v16

    aput-byte v21, v7, v12

    const/16 v8, 0x65

    aput-byte v8, v7, v9

    const/16 v8, -0x80

    aput-byte v8, v7, v10

    const/16 v8, 0x1d

    aput-byte v8, v7, v19

    const/16 v8, -0x60

    aput-byte v8, v7, v20

    const/16 v8, -0x76

    aput-byte v8, v7, v21

    const/16 v8, 0xe

    aput-byte v13, v7, v8

    const/16 v8, -0x22

    aput-byte v8, v7, v22

    aput-byte v5, v7, v23

    const/16 v8, 0x11

    const/16 v28, 0x73

    aput-byte v28, v7, v8

    const/16 v8, -0x6f

    aput-byte v8, v7, v24

    const/16 v8, 0x13

    aput-byte v25, v7, v8

    const/16 v8, 0x14

    const/16 v28, -0x45

    aput-byte v28, v7, v8

    const/16 v8, 0x15

    const/16 v28, -0x68

    aput-byte v28, v7, v8

    const/4 v8, 0x6

    aput-byte v8, v7, v25

    const/16 v8, -0x2e

    aput-byte v8, v7, v26

    const/16 v8, 0x18

    aput-byte v26, v7, v8

    const/16 v8, 0x19

    aput-byte v12, v7, v8

    const/16 v8, 0x1a

    const/16 v28, -0x10

    aput-byte v28, v7, v8

    const/16 v8, 0x1b

    const/16 v28, 0x68

    aput-byte v28, v7, v8

    const/16 v8, -0x45

    aput-byte v8, v7, v2

    const/16 v8, 0x1d

    const/16 v28, -0x62

    aput-byte v28, v7, v8

    const/16 v8, 0x1e

    aput-byte v6, v7, v8

    const/16 v8, -0x34

    aput-byte v8, v7, v5

    const/16 v8, 0x20

    aput-byte v26, v7, v8

    const/16 v8, 0x21

    const/16 v28, 0x69

    aput-byte v28, v7, v8

    const/16 v8, 0x22

    const/16 v28, -0x73

    aput-byte v28, v7, v8

    const/16 v8, 0x23

    aput-byte v5, v7, v8

    const/16 v8, 0x24

    const/16 v28, -0x29

    aput-byte v28, v7, v8

    const/16 v8, 0x25

    const/16 v28, -0x1f

    aput-byte v28, v7, v8

    const/16 v8, 0x26

    const/16 v28, 0x77

    aput-byte v28, v7, v8

    new-array v8, v12, [B

    const/16 v28, 0x48

    aput-byte v28, v8, v6

    const/16 v28, 0x3a

    aput-byte v28, v8, v15

    const/16 v28, -0x3b

    aput-byte v28, v8, v13

    const/16 v28, 0x5e

    aput-byte v28, v8, v14

    const/16 v28, -0x1c

    aput-byte v28, v8, v11

    const/16 v28, -0x27

    const/16 v18, 0x5

    aput-byte v28, v8, v18

    const/16 v28, 0x43

    const/16 v17, 0x6

    aput-byte v28, v8, v17

    const/16 v28, -0x7f

    const/16 v16, 0x7

    aput-byte v28, v8, v16

    invoke-static {v7, v8}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v7

    aput-object v7, v4, v11

    const/16 v7, 0x25

    new-array v7, v7, [B

    const/16 v8, 0x57

    aput-byte v8, v7, v6

    const/16 v8, 0x79

    aput-byte v8, v7, v15

    const/16 v8, 0x2c

    aput-byte v8, v7, v13

    const/16 v8, 0x3a

    aput-byte v8, v7, v14

    const/16 v8, -0x2a

    aput-byte v8, v7, v11

    const/16 v8, -0x10

    const/16 v18, 0x5

    aput-byte v8, v7, v18

    const/16 v8, 0x46

    const/16 v17, 0x6

    aput-byte v8, v7, v17

    const/16 v8, -0x73

    const/16 v16, 0x7

    aput-byte v8, v7, v16

    const/16 v8, 0x46

    aput-byte v8, v7, v12

    const/16 v8, 0x6a

    aput-byte v8, v7, v9

    const/16 v8, 0x2d

    aput-byte v8, v7, v10

    const/16 v8, 0x36

    aput-byte v8, v7, v19

    const/16 v8, -0x2e

    aput-byte v8, v7, v20

    const/16 v8, -0x14

    aput-byte v8, v7, v21

    const/16 v8, 0x55

    const/16 v27, 0xe

    aput-byte v8, v7, v27

    const/16 v8, -0x74

    aput-byte v8, v7, v22

    const/16 v8, 0x57

    aput-byte v8, v7, v23

    const/16 v8, 0x11

    const/16 v28, 0x7d

    aput-byte v28, v7, v8

    const/16 v8, 0x20

    aput-byte v8, v7, v24

    const/16 v8, 0x13

    const/16 v28, 0x24

    aput-byte v28, v7, v8

    const/16 v8, 0x14

    const/16 v28, -0x2a

    aput-byte v28, v7, v8

    const/16 v8, 0x15

    const/16 v28, -0x20

    aput-byte v28, v7, v8

    const/16 v8, 0x5d

    aput-byte v8, v7, v25

    const/16 v8, -0xc

    aput-byte v8, v7, v26

    const/16 v8, 0x18

    const/16 v28, 0x31

    aput-byte v28, v7, v8

    const/16 v8, 0x19

    aput-byte v21, v7, v8

    const/16 v8, 0x1a

    const/16 v28, 0x20

    aput-byte v28, v7, v8

    const/16 v8, 0x1b

    const/16 v28, 0x26

    aput-byte v28, v7, v8

    const/16 v8, -0x2f

    aput-byte v8, v7, v2

    const/16 v8, 0x1d

    const/16 v28, -0x10

    aput-byte v28, v7, v8

    const/16 v8, 0x1e

    const/16 v28, 0x5d

    aput-byte v28, v7, v8

    const/16 v8, -0x6a

    aput-byte v8, v7, v5

    const/16 v8, 0x20

    const/16 v28, 0x4b

    aput-byte v28, v7, v8

    const/16 v8, 0x21

    const/16 v28, 0x74

    aput-byte v28, v7, v8

    const/16 v8, 0x22

    const/16 v28, 0x4d

    aput-byte v28, v7, v8

    const/16 v8, 0x23

    const/16 v28, 0x50

    aput-byte v28, v7, v8

    const/16 v8, 0x24

    const/16 v28, -0x5b

    aput-byte v28, v7, v8

    new-array v8, v12, [B

    aput-byte v14, v8, v6

    const/16 v28, 0x35

    aput-byte v28, v8, v15

    const/16 v28, 0x7f

    aput-byte v28, v8, v13

    const/16 v28, 0x65

    aput-byte v28, v8, v14

    const/16 v28, -0x6d

    aput-byte v28, v8, v11

    const/16 v28, -0x4d

    const/16 v18, 0x5

    aput-byte v28, v8, v18

    const/16 v17, 0x6

    aput-byte v13, v8, v17

    const/16 v28, -0x3b

    const/16 v16, 0x7

    aput-byte v28, v8, v16

    invoke-static {v7, v8}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v7

    aput-object v7, v4, v18

    const/16 v7, 0x25

    new-array v7, v7, [B

    const/16 v8, -0x20

    aput-byte v8, v7, v6

    const/16 v8, 0x62

    aput-byte v8, v7, v15

    aput-byte v11, v7, v13

    const/16 v8, -0x26

    aput-byte v8, v7, v14

    const/16 v8, -0x2e

    aput-byte v8, v7, v11

    const/4 v8, 0x5

    aput-byte v23, v7, v8

    const/16 v8, -0x3f

    const/16 v17, 0x6

    aput-byte v8, v7, v17

    const/16 v8, -0x4d

    const/16 v16, 0x7

    aput-byte v8, v7, v16

    const/16 v8, -0xf

    aput-byte v8, v7, v12

    const/16 v8, 0x71

    aput-byte v8, v7, v9

    const/4 v8, 0x5

    aput-byte v8, v7, v10

    const/16 v8, -0x2a

    aput-byte v8, v7, v19

    const/16 v8, -0x2a

    aput-byte v8, v7, v20

    aput-byte v20, v7, v21

    const/16 v8, -0x22

    const/16 v27, 0xe

    aput-byte v8, v7, v27

    const/16 v8, -0x42

    aput-byte v8, v7, v22

    const/16 v8, -0x20

    aput-byte v8, v7, v23

    const/16 v8, 0x11

    const/16 v28, 0x66

    aput-byte v28, v7, v8

    aput-byte v12, v7, v24

    const/16 v8, 0x13

    const/16 v28, -0x3c

    aput-byte v28, v7, v8

    const/16 v8, 0x14

    const/16 v28, -0x2e

    aput-byte v28, v7, v8

    const/16 v8, 0x15

    aput-byte v6, v7, v8

    const/16 v8, -0x2a

    aput-byte v8, v7, v25

    const/16 v8, -0x3a

    aput-byte v8, v7, v26

    const/16 v8, 0x18

    const/16 v28, -0x7a

    aput-byte v28, v7, v8

    const/16 v8, 0x19

    aput-byte v25, v7, v8

    const/16 v8, 0x1a

    aput-byte v12, v7, v8

    const/16 v8, 0x1b

    const/16 v28, -0x3e

    aput-byte v28, v7, v8

    const/16 v8, -0x2c

    aput-byte v8, v7, v2

    const/16 v8, 0x1d

    const/16 v28, 0x1e

    aput-byte v28, v7, v8

    const/16 v8, 0x1e

    const/16 v28, -0x2a

    aput-byte v28, v7, v8

    const/16 v8, -0x5c

    aput-byte v8, v7, v5

    const/16 v8, 0x20

    const/16 v28, -0x4

    aput-byte v28, v7, v8

    const/16 v8, 0x21

    const/16 v28, 0x6f

    aput-byte v28, v7, v8

    const/16 v8, 0x22

    const/16 v28, 0x65

    aput-byte v28, v7, v8

    const/16 v8, 0x23

    const/16 v28, -0x50

    aput-byte v28, v7, v8

    const/16 v8, 0x24

    const/16 v28, -0x5f

    aput-byte v28, v7, v8

    new-array v8, v12, [B

    const/16 v28, -0x4c

    aput-byte v28, v8, v6

    const/16 v28, 0x2e

    aput-byte v28, v8, v15

    const/16 v28, 0x57

    aput-byte v28, v8, v13

    const/16 v28, -0x7b

    aput-byte v28, v8, v14

    const/16 v28, -0x69

    aput-byte v28, v8, v11

    const/16 v28, 0x53

    const/16 v18, 0x5

    aput-byte v28, v8, v18

    const/16 v28, -0x77

    const/16 v17, 0x6

    aput-byte v28, v8, v17

    const/16 v28, -0x9

    const/16 v16, 0x7

    aput-byte v28, v8, v16

    invoke-static {v7, v8}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v7

    aput-object v7, v4, v17

    const/16 v7, 0x1d

    new-array v7, v7, [B

    const/16 v8, 0x7b

    aput-byte v8, v7, v6

    const/16 v8, -0x18

    aput-byte v8, v7, v15

    const/16 v8, -0x2e

    aput-byte v8, v7, v13

    const/16 v8, -0x79

    aput-byte v8, v7, v14

    const/16 v8, -0x1d

    aput-byte v8, v7, v11

    const/16 v8, -0x37

    const/16 v18, 0x5

    aput-byte v8, v7, v18

    const/16 v8, 0x30

    const/16 v17, 0x6

    aput-byte v8, v7, v17

    const/16 v8, 0x72

    const/16 v16, 0x7

    aput-byte v8, v7, v16

    const/16 v8, 0x78

    aput-byte v8, v7, v12

    const/16 v8, -0x13

    aput-byte v8, v7, v9

    const/16 v8, -0x2b

    aput-byte v8, v7, v10

    const/16 v8, -0x70

    aput-byte v8, v7, v19

    const/16 v8, -0x12

    aput-byte v8, v7, v20

    const/16 v8, -0x57

    aput-byte v8, v7, v21

    const/16 v8, 0x35

    const/16 v27, 0xe

    aput-byte v8, v7, v27

    const/16 v8, 0x68

    aput-byte v8, v7, v22

    const/16 v8, 0x7c

    aput-byte v8, v7, v23

    const/16 v8, 0x11

    const/16 v28, -0x5

    aput-byte v28, v7, v8

    const/16 v8, -0x3c

    aput-byte v8, v7, v24

    const/16 v8, 0x13

    const/16 v28, -0x64

    aput-byte v28, v7, v8

    const/16 v8, 0x14

    const/16 v28, -0xc

    aput-byte v28, v7, v8

    const/16 v8, 0x15

    const/16 v28, -0x3b

    aput-byte v28, v7, v8

    const/16 v8, 0x32

    aput-byte v8, v7, v25

    const/16 v8, 0x6f

    aput-byte v8, v7, v26

    const/16 v8, 0x18

    const/16 v28, 0x6c

    aput-byte v28, v7, v8

    const/16 v8, 0x19

    const/16 v28, -0x5

    aput-byte v28, v7, v8

    const/16 v8, 0x1a

    const/16 v28, -0x2e

    aput-byte v28, v7, v8

    const/16 v8, 0x1b

    const/16 v28, -0x70

    aput-byte v28, v7, v8

    const/16 v8, -0x10

    aput-byte v8, v7, v2

    new-array v8, v12, [B

    const/16 v28, 0x2f

    aput-byte v28, v8, v6

    const/16 v28, -0x5c

    aput-byte v28, v8, v15

    const/16 v28, -0x7f

    aput-byte v28, v8, v13

    const/16 v28, -0x28

    aput-byte v28, v8, v14

    const/16 v28, -0x4f

    aput-byte v28, v8, v11

    const/16 v28, -0x66

    const/16 v18, 0x5

    aput-byte v28, v8, v18

    const/16 v28, 0x71

    const/16 v17, 0x6

    aput-byte v28, v8, v17

    const/16 v28, 0x2d

    const/16 v16, 0x7

    aput-byte v28, v8, v16

    invoke-static {v7, v8}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v7

    aput-object v7, v4, v16

    new-array v7, v2, [B

    aput-byte v16, v7, v6

    const/16 v8, -0x3b

    aput-byte v8, v7, v15

    const/16 v8, 0x44

    aput-byte v8, v7, v13

    const/16 v8, 0x55

    aput-byte v8, v7, v14

    const/16 v8, -0x2b

    aput-byte v8, v7, v11

    const/16 v8, 0x58

    const/16 v18, 0x5

    aput-byte v8, v7, v18

    const/16 v8, 0x78

    const/16 v17, 0x6

    aput-byte v8, v7, v17

    const/4 v8, -0x8

    const/16 v16, 0x7

    aput-byte v8, v7, v16

    aput-byte v11, v7, v12

    const/16 v8, -0x40

    aput-byte v8, v7, v9

    const/16 v8, 0x43

    aput-byte v8, v7, v10

    const/16 v8, 0x42

    aput-byte v8, v7, v19

    const/16 v8, -0x28

    aput-byte v8, v7, v20

    const/16 v8, 0x4a

    aput-byte v8, v7, v21

    const/16 v8, 0x7c

    const/16 v27, 0xe

    aput-byte v8, v7, v27

    const/16 v8, -0xc

    aput-byte v8, v7, v22

    aput-byte v20, v7, v23

    const/16 v8, 0x11

    const/16 v28, -0x48

    aput-byte v28, v7, v8

    const/16 v8, 0x25

    aput-byte v8, v7, v24

    const/16 v8, 0x13

    const/16 v28, 0x32

    aput-byte v28, v7, v8

    const/16 v8, 0x14

    const/16 v28, -0x28

    aput-byte v28, v7, v8

    const/16 v8, 0x15

    const/16 v28, 0x48

    aput-byte v28, v7, v8

    const/16 v8, 0x7b

    aput-byte v8, v7, v25

    const/16 v8, -0x1c

    aput-byte v8, v7, v26

    const/16 v8, 0x18

    aput-byte v20, v7, v8

    const/16 v8, 0x19

    const/16 v28, -0x26

    aput-byte v28, v7, v8

    const/16 v8, 0x1a

    const/16 v28, 0x5f

    aput-byte v28, v7, v8

    const/16 v8, 0x1b

    const/16 v28, 0x4b

    aput-byte v28, v7, v8

    new-array v8, v12, [B

    const/16 v28, 0x53

    aput-byte v28, v8, v6

    const/16 v28, -0x77

    aput-byte v28, v8, v15

    aput-byte v26, v8, v13

    aput-byte v10, v8, v14

    const/16 v28, -0x79

    aput-byte v28, v8, v11

    const/16 v18, 0x5

    aput-byte v19, v8, v18

    const/16 v28, 0x39

    const/16 v17, 0x6

    aput-byte v28, v8, v17

    const/16 v28, -0x59

    const/16 v16, 0x7

    aput-byte v28, v8, v16

    invoke-static {v7, v8}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v7

    aput-object v7, v4, v12

    new-array v7, v2, [B

    const/16 v8, -0x49

    aput-byte v8, v7, v6

    const/16 v8, -0x49

    aput-byte v8, v7, v15

    const/16 v8, -0x6e

    aput-byte v8, v7, v13

    const/16 v8, -0x33

    aput-byte v8, v7, v14

    const/4 v8, 0x7

    aput-byte v8, v7, v11

    const/16 v16, 0x13

    const/16 v18, 0x5

    aput-byte v16, v7, v18

    const/16 v16, -0x73

    const/16 v17, 0x6

    aput-byte v16, v7, v17

    const/16 v16, -0x7c

    aput-byte v16, v7, v8

    const/16 v8, -0x4c

    aput-byte v8, v7, v12

    const/16 v8, -0x4e

    aput-byte v8, v7, v9

    const/16 v8, -0x6b

    aput-byte v8, v7, v10

    const/16 v8, -0x26

    aput-byte v8, v7, v19

    aput-byte v10, v7, v20

    aput-byte v15, v7, v21

    const/16 v8, -0x77

    const/16 v27, 0xe

    aput-byte v8, v7, v27

    const/16 v8, -0x78

    aput-byte v8, v7, v22

    const/16 v8, -0x44

    aput-byte v8, v7, v23

    const/16 v8, 0x11

    const/16 v28, -0x37

    aput-byte v28, v7, v8

    const/16 v8, -0xc

    aput-byte v8, v7, v24

    const/16 v8, 0x13

    const/16 v28, -0x5c

    aput-byte v28, v7, v8

    const/16 v8, 0x14

    aput-byte v10, v7, v8

    const/16 v8, 0x15

    aput-byte v14, v7, v8

    const/16 v8, -0x72

    aput-byte v8, v7, v25

    const/16 v8, -0x68

    aput-byte v8, v7, v26

    const/16 v8, 0x18

    const/16 v28, -0x44

    aput-byte v28, v7, v8

    const/16 v8, 0x19

    const/16 v28, -0x58

    aput-byte v28, v7, v8

    const/16 v8, 0x1a

    const/16 v28, -0x77

    aput-byte v28, v7, v8

    const/16 v8, 0x1b

    const/16 v28, -0x2d

    aput-byte v28, v7, v8

    new-array v8, v12, [B

    const/16 v28, -0x1d

    aput-byte v28, v8, v6

    const/16 v28, -0x5

    aput-byte v28, v8, v15

    const/16 v28, -0x3f

    aput-byte v28, v8, v13

    const/16 v28, -0x6e

    aput-byte v28, v8, v14

    const/16 v28, 0x55

    aput-byte v28, v8, v11

    const/16 v28, 0x40

    const/16 v18, 0x5

    aput-byte v28, v8, v18

    const/16 v28, -0x34

    const/16 v17, 0x6

    aput-byte v28, v8, v17

    const/16 v28, -0x25

    const/16 v16, 0x7

    aput-byte v28, v8, v16

    invoke-static {v7, v8}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v7

    aput-object v7, v4, v9

    const/16 v7, 0x25

    new-array v7, v7, [B

    const/16 v8, -0x21

    aput-byte v8, v7, v6

    const/16 v8, -0x25

    aput-byte v8, v7, v15

    const/16 v8, -0x5e

    aput-byte v8, v7, v13

    const/16 v8, -0x23

    aput-byte v8, v7, v14

    const/16 v8, 0x20

    aput-byte v8, v7, v11

    const/16 v8, 0x64

    const/16 v18, 0x5

    aput-byte v8, v7, v18

    const/16 v8, -0xb

    const/16 v17, 0x6

    aput-byte v8, v7, v17

    const/16 v8, -0x3c

    const/16 v16, 0x7

    aput-byte v8, v7, v16

    const/16 v8, -0x32

    aput-byte v8, v7, v12

    const/16 v8, -0x38

    aput-byte v8, v7, v9

    const/16 v8, -0x4c

    aput-byte v8, v7, v10

    const/16 v8, -0x3f

    aput-byte v8, v7, v19

    const/16 v8, 0x21

    aput-byte v8, v7, v20

    const/16 v8, 0x74

    aput-byte v8, v7, v21

    const/16 v8, -0x10

    const/16 v27, 0xe

    aput-byte v8, v7, v27

    const/16 v8, -0x2d

    aput-byte v8, v7, v22

    const/16 v8, -0x24

    aput-byte v8, v7, v23

    const/16 v8, 0x11

    const/16 v28, -0x22

    aput-byte v28, v7, v8

    const/16 v8, -0x5b

    aput-byte v8, v7, v24

    const/16 v8, 0x13

    const/16 v28, -0x36

    aput-byte v28, v7, v8

    const/16 v8, 0x14

    const/16 v28, 0x3a

    aput-byte v28, v7, v8

    const/16 v8, 0x15

    const/16 v28, 0x14

    aput-byte v28, v7, v8

    const/16 v8, -0xb

    aput-byte v8, v7, v25

    const/16 v8, -0x37

    aput-byte v8, v7, v26

    const/16 v8, 0x18

    const/16 v28, -0x28

    aput-byte v28, v7, v8

    const/16 v8, 0x19

    const/16 v28, -0x38

    aput-byte v28, v7, v8

    const/16 v8, 0x1a

    const/16 v28, -0x4c

    aput-byte v28, v7, v8

    const/16 v8, 0x1b

    const/16 v28, -0x3a

    aput-byte v28, v7, v8

    const/16 v8, 0x20

    aput-byte v8, v7, v2

    const/16 v8, 0x1d

    const/16 v28, 0x78

    aput-byte v28, v7, v8

    const/16 v8, 0x1e

    const/16 v28, -0xe

    aput-byte v28, v7, v8

    const/16 v8, -0x32

    aput-byte v8, v7, v5

    const/16 v8, 0x20

    const/16 v28, -0x38

    aput-byte v28, v7, v8

    const/16 v8, 0x21

    const/16 v28, -0x38

    aput-byte v28, v7, v8

    const/16 v8, 0x22

    const/16 v28, -0x5e

    aput-byte v28, v7, v8

    const/16 v8, 0x23

    const/16 v28, -0x36

    aput-byte v28, v7, v8

    const/16 v8, 0x24

    const/16 v28, 0x24

    aput-byte v28, v7, v8

    new-array v8, v12, [B

    const/16 v28, -0x75

    aput-byte v28, v8, v6

    const/16 v28, -0x69

    aput-byte v28, v8, v15

    const/16 v28, -0xf

    aput-byte v28, v8, v13

    const/16 v28, -0x7e

    aput-byte v28, v8, v14

    const/16 v28, 0x65

    aput-byte v28, v8, v11

    const/16 v28, 0x27

    const/16 v18, 0x5

    aput-byte v28, v8, v18

    const/16 v28, -0x4f

    const/16 v17, 0x6

    aput-byte v28, v8, v17

    const/16 v28, -0x74

    const/16 v16, 0x7

    aput-byte v28, v8, v16

    invoke-static {v7, v8}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v7

    aput-object v7, v4, v10

    const/16 v7, 0x24

    new-array v7, v7, [B

    const/16 v8, -0x6f

    aput-byte v8, v7, v6

    const/16 v8, 0x47

    aput-byte v8, v7, v15

    const/16 v8, -0x52

    aput-byte v8, v7, v13

    aput-byte v13, v7, v14

    const/16 v8, 0x44

    aput-byte v8, v7, v11

    const/16 v8, -0x59

    const/16 v18, 0x5

    aput-byte v8, v7, v18

    const/16 v8, -0x55

    const/16 v17, 0x6

    aput-byte v8, v7, v17

    const/16 v8, 0x40

    const/16 v16, 0x7

    aput-byte v8, v7, v16

    const/16 v8, -0x80

    aput-byte v8, v7, v12

    const/16 v8, 0x54

    aput-byte v8, v7, v9

    const/16 v8, -0x48

    aput-byte v8, v7, v10

    const/16 v8, 0x1e

    aput-byte v8, v7, v19

    const/16 v8, 0x45

    aput-byte v8, v7, v20

    const/16 v8, -0x49

    aput-byte v8, v7, v21

    const/16 v8, -0x52

    const/16 v27, 0xe

    aput-byte v8, v7, v27

    const/16 v8, 0x57

    aput-byte v8, v7, v22

    const/16 v8, -0x6e

    aput-byte v8, v7, v23

    const/16 v8, 0x11

    const/16 v28, 0x42

    aput-byte v28, v7, v8

    const/16 v8, -0x57

    aput-byte v8, v7, v24

    const/16 v8, 0x13

    const/16 v28, 0x15

    aput-byte v28, v7, v8

    const/16 v8, 0x14

    const/16 v28, 0x5e

    aput-byte v28, v7, v8

    const/16 v8, 0x15

    const/16 v28, -0x5b

    aput-byte v28, v7, v8

    const/16 v8, -0x56

    aput-byte v8, v7, v25

    const/16 v8, 0x5b

    aput-byte v8, v7, v26

    const/16 v8, 0x18

    const/16 v28, -0x66

    aput-byte v28, v7, v8

    const/16 v8, 0x19

    const/16 v28, 0x3a

    aput-byte v28, v7, v8

    const/16 v8, 0x1a

    const/16 v28, -0x31

    aput-byte v28, v7, v8

    const/16 v8, 0x1b

    const/16 v28, 0x65

    aput-byte v28, v7, v8

    const/16 v8, 0x5e

    aput-byte v8, v7, v2

    const/16 v8, 0x1d

    const/16 v28, -0x59

    aput-byte v28, v7, v8

    const/16 v8, 0x1e

    const/16 v28, -0x53

    aput-byte v28, v7, v8

    const/16 v8, 0x4b

    aput-byte v8, v7, v5

    const/16 v8, 0x20

    const/16 v28, -0x66

    aput-byte v28, v7, v8

    const/16 v8, 0x21

    const/16 v28, 0x58

    aput-byte v28, v7, v8

    const/16 v8, 0x22

    const/16 v28, -0x4b

    aput-byte v28, v7, v8

    const/16 v8, 0x23

    aput-byte v2, v7, v8

    new-array v8, v12, [B

    const/16 v28, -0x3b

    aput-byte v28, v8, v6

    aput-byte v19, v8, v15

    const/16 v28, -0x3

    aput-byte v28, v8, v13

    const/16 v28, 0x5d

    aput-byte v28, v8, v14

    aput-byte v15, v8, v11

    const/16 v28, -0x1c

    const/16 v18, 0x5

    aput-byte v28, v8, v18

    const/16 v28, -0x11

    const/16 v17, 0x6

    aput-byte v28, v8, v17

    const/16 v16, 0x7

    aput-byte v12, v8, v16

    invoke-static {v7, v8}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v7

    aput-object v7, v4, v19

    const/16 v7, 0x23

    new-array v7, v7, [B

    const/16 v8, -0x17

    aput-byte v8, v7, v6

    const/16 v8, 0x43

    aput-byte v8, v7, v15

    const/16 v8, -0x7a

    aput-byte v8, v7, v13

    const/16 v8, 0x51

    aput-byte v8, v7, v14

    const/16 v8, -0x64

    aput-byte v8, v7, v11

    const/16 v8, -0x23

    const/16 v18, 0x5

    aput-byte v8, v7, v18

    const/16 v8, 0x47

    const/16 v17, 0x6

    aput-byte v8, v7, v17

    const/16 v8, -0x51

    const/16 v16, 0x7

    aput-byte v8, v7, v16

    const/4 v8, -0x8

    aput-byte v8, v7, v12

    const/16 v8, 0x50

    aput-byte v8, v7, v9

    const/16 v8, -0x79

    aput-byte v8, v7, v10

    const/16 v8, 0x5d

    aput-byte v8, v7, v19

    const/16 v8, -0x68

    aput-byte v8, v7, v20

    const/16 v8, -0x3f

    aput-byte v8, v7, v21

    const/16 v8, 0x54

    const/16 v27, 0xe

    aput-byte v8, v7, v27

    const/16 v8, -0x52

    aput-byte v8, v7, v22

    const/16 v8, -0x17

    aput-byte v8, v7, v23

    const/16 v8, 0x11

    const/16 v28, 0x47

    aput-byte v28, v7, v8

    const/16 v8, -0x76

    aput-byte v8, v7, v24

    const/16 v8, 0x13

    const/16 v28, 0x3d

    aput-byte v28, v7, v8

    const/16 v8, 0x14

    const/16 v28, -0x63

    aput-byte v28, v7, v8

    const/16 v8, 0x15

    const/16 v28, -0x25

    aput-byte v28, v7, v8

    const/16 v8, 0x50

    aput-byte v8, v7, v25

    const/16 v8, -0x48

    aput-byte v8, v7, v26

    const/16 v8, 0x18

    const/16 v28, -0x8

    aput-byte v28, v7, v8

    const/16 v8, 0x19

    const/16 v28, 0x4b

    aput-byte v28, v7, v8

    const/16 v8, 0x1a

    const/16 v28, -0x70

    aput-byte v28, v7, v8

    const/16 v8, 0x1b

    const/16 v28, 0x51

    aput-byte v28, v7, v8

    const/16 v8, -0x66

    aput-byte v8, v7, v2

    const/16 v8, 0x1d

    const/16 v28, -0x24

    aput-byte v28, v7, v8

    const/16 v8, 0x1e

    const/16 v28, 0x40

    aput-byte v28, v7, v8

    const/16 v8, -0x48

    aput-byte v8, v7, v5

    const/16 v8, 0x20

    const/16 v28, -0x12

    aput-byte v28, v7, v8

    const/16 v8, 0x21

    const/16 v28, 0x47

    aput-byte v28, v7, v8

    const/16 v8, 0x22

    const/16 v28, -0x6c

    aput-byte v28, v7, v8

    new-array v8, v12, [B

    const/16 v28, -0x43

    aput-byte v28, v8, v6

    aput-byte v22, v8, v15

    const/16 v28, -0x2b

    aput-byte v28, v8, v13

    const/16 v27, 0xe

    aput-byte v27, v8, v14

    const/16 v28, -0x27

    aput-byte v28, v8, v11

    const/16 v28, -0x62

    const/16 v18, 0x5

    aput-byte v28, v8, v18

    const/16 v17, 0x6

    aput-byte v14, v8, v17

    const/16 v28, -0x19

    const/16 v16, 0x7

    aput-byte v28, v8, v16

    invoke-static {v7, v8}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v7

    aput-object v7, v4, v20

    const/16 v7, 0x22

    new-array v7, v7, [B

    aput-byte v26, v7, v6

    const/16 v8, -0x45

    aput-byte v8, v7, v15

    const/16 v8, 0x74

    aput-byte v8, v7, v13

    const/4 v8, -0x5

    aput-byte v8, v7, v14

    const/16 v8, 0x4b

    aput-byte v8, v7, v11

    const/16 v8, -0x7d

    const/16 v18, 0x5

    aput-byte v8, v7, v18

    const/16 v8, 0x62

    const/16 v17, 0x6

    aput-byte v8, v7, v17

    const/16 v8, -0x2d

    const/16 v16, 0x7

    aput-byte v8, v7, v16

    aput-byte v17, v7, v12

    const/16 v8, -0x58

    aput-byte v8, v7, v9

    const/16 v8, 0x75

    aput-byte v8, v7, v10

    const/16 v8, -0x9

    aput-byte v8, v7, v19

    const/16 v8, 0x4f

    aput-byte v8, v7, v20

    const/16 v8, -0x61

    aput-byte v8, v7, v21

    const/16 v8, 0x71

    const/16 v9, 0xe

    aput-byte v8, v7, v9

    const/16 v8, -0x2e

    aput-byte v8, v7, v22

    aput-byte v26, v7, v23

    const/16 v8, 0x11

    const/16 v9, -0x41

    aput-byte v9, v7, v8

    const/16 v8, 0x78

    aput-byte v8, v7, v24

    const/16 v8, 0x13

    const/16 v9, -0x1b

    aput-byte v9, v7, v8

    const/16 v8, 0x14

    const/16 v9, 0x4b

    aput-byte v9, v7, v8

    const/16 v8, 0x15

    const/16 v9, -0x6d

    aput-byte v9, v7, v8

    const/16 v8, 0x79

    aput-byte v8, v7, v25

    const/16 v8, -0x56

    aput-byte v8, v7, v26

    const/16 v8, 0x18

    const/16 v9, 0x71

    aput-byte v9, v7, v8

    const/16 v8, 0x19

    const/16 v9, -0x31

    aput-byte v9, v7, v8

    const/16 v8, 0x1a

    const/16 v9, 0x78

    aput-byte v9, v7, v8

    const/16 v8, 0x1b

    const/16 v9, -0x19

    aput-byte v9, v7, v8

    const/16 v8, 0x4c

    aput-byte v8, v7, v2

    const/16 v2, 0x1d

    const/16 v8, -0x7d

    aput-byte v8, v7, v2

    const/16 v2, 0x1e

    const/16 v8, 0x79

    aput-byte v8, v7, v2

    const/16 v2, -0x38

    aput-byte v2, v7, v5

    const/16 v2, 0x20

    aput-byte v19, v7, v2

    const/16 v2, 0x21

    const/16 v5, -0x4a

    aput-byte v5, v7, v2

    new-array v2, v12, [B

    const/16 v5, 0x43

    aput-byte v5, v2, v6

    const/16 v5, -0x9

    aput-byte v5, v2, v15

    const/16 v5, 0x27

    aput-byte v5, v2, v13

    const/16 v5, -0x5c

    aput-byte v5, v2, v14

    const/16 v5, 0xe

    aput-byte v5, v2, v11

    const/16 v5, -0x40

    const/4 v8, 0x5

    aput-byte v5, v2, v8

    const/16 v5, 0x26

    const/4 v8, 0x6

    aput-byte v5, v2, v8

    const/16 v5, -0x65

    const/4 v8, 0x7

    aput-byte v5, v2, v8

    invoke-static {v7, v2}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v2

    aput-object v2, v4, v21

    invoke-static {v4}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v2

    invoke-virtual {v3}, Ljavax/net/ssl/SSLSocket;->getSupportedCipherSuites()[Ljava/lang/String;

    move-result-object v4

    invoke-static {v4}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v4

    new-instance v5, Ljava/util/HashSet;

    invoke-direct {v5, v2}, Ljava/util/HashSet;-><init>(Ljava/util/Collection;)V

    invoke-virtual {v5, v4}, Ljava/util/AbstractCollection;->retainAll(Ljava/util/Collection;)Z

    new-instance v2, Ljava/util/HashSet;

    invoke-virtual {v3}, Ljavax/net/ssl/SSLSocket;->getEnabledCipherSuites()[Ljava/lang/String;

    move-result-object v3

    invoke-static {v3}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v3

    invoke-direct {v2, v3}, Ljava/util/HashSet;-><init>(Ljava/util/Collection;)V

    invoke-virtual {v5, v2}, Ljava/util/AbstractCollection;->addAll(Ljava/util/Collection;)Z

    new-array v2, v6, [Ljava/lang/String;

    invoke-virtual {v5, v2}, Ljava/util/AbstractCollection;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;

    move-result-object v2

    check-cast v2, [Ljava/lang/String;

    iput-object v2, v1, Lcom/github/catvod/spider/appysv2/n/g;->b:[Ljava/lang/String;

    new-array v2, v14, [B

    const/16 v3, -0x47

    aput-byte v3, v2, v6

    const/16 v3, -0x21

    aput-byte v3, v2, v15

    const/4 v3, -0x8

    aput-byte v3, v2, v13

    new-array v3, v12, [B

    const/16 v4, -0x13

    aput-byte v4, v3, v6

    const/16 v4, -0x6d

    aput-byte v4, v3, v15

    const/16 v4, -0x55

    aput-byte v4, v3, v13

    aput-byte v14, v3, v14

    const/16 v4, -0x1c

    aput-byte v4, v3, v11

    const/4 v4, 0x5

    aput-byte v25, v3, v4

    const/16 v4, -0x71

    const/4 v5, 0x6

    aput-byte v4, v3, v5

    const/16 v4, -0x75

    const/4 v5, 0x7

    aput-byte v4, v3, v5

    invoke-static {v2, v3}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Ljavax/net/ssl/SSLContext;->getInstance(Ljava/lang/String;)Ljavax/net/ssl/SSLContext;

    move-result-object v2

    const/4 v3, 0x0

    new-array v4, v15, [Ljavax/net/ssl/X509TrustManager;

    sget-object v5, Lcom/github/catvod/spider/appysv2/n/g;->d:Ljavax/net/ssl/X509TrustManager;

    aput-object v5, v4, v6

    const/4 v5, 0x0

    invoke-virtual {v2, v3, v4, v5}, Ljavax/net/ssl/SSLContext;->init([Ljavax/net/ssl/KeyManager;[Ljavax/net/ssl/TrustManager;Ljava/security/SecureRandom;)V

    invoke-virtual {v2}, Ljavax/net/ssl/SSLContext;->getSocketFactory()Ljavax/net/ssl/SSLSocketFactory;

    move-result-object v2

    iput-object v2, v1, Lcom/github/catvod/spider/appysv2/n/g;->a:Ljavax/net/ssl/SSLSocketFactory;

    invoke-static {v2}, Ljavax/net/ssl/HttpsURLConnection;->setDefaultSSLSocketFactory(Ljavax/net/ssl/SSLSocketFactory;)V
    :try_end_c8a
    .catch Ljava/lang/Exception; {:try_start_5 .. :try_end_c8a} :catch_c8b

    goto :goto_c90

    :catch_c8b
    move-exception v0

    move-object v2, v0

    invoke-virtual {v2}, Ljava/lang/Throwable;->printStackTrace()V

    :goto_c90
    return-void
.end method

.method private a(Ljavax/net/ssl/SSLSocket;)V
    .registers 3

    iget-object v0, p0, Lcom/github/catvod/spider/appysv2/n/g;->c:[Ljava/lang/String;

    if-eqz v0, :cond_7

    invoke-virtual {p1, v0}, Ljavax/net/ssl/SSLSocket;->setEnabledProtocols([Ljava/lang/String;)V

    :cond_7
    iget-object v0, p0, Lcom/github/catvod/spider/appysv2/n/g;->b:[Ljava/lang/String;

    if-eqz v0, :cond_e

    invoke-virtual {p1, v0}, Ljavax/net/ssl/SSLSocket;->setEnabledCipherSuites([Ljava/lang/String;)V

    :cond_e
    return-void
.end method


# virtual methods
.method public final createSocket(Ljava/lang/String;I)Ljava/net/Socket;
    .registers 4

    iget-object v0, p0, Lcom/github/catvod/spider/appysv2/n/g;->a:Ljavax/net/ssl/SSLSocketFactory;

    invoke-virtual {v0, p1, p2}, Ljavax/net/SocketFactory;->createSocket(Ljava/lang/String;I)Ljava/net/Socket;

    move-result-object p1

    instance-of p2, p1, Ljavax/net/ssl/SSLSocket;

    if-eqz p2, :cond_10

    move-object p2, p1

    check-cast p2, Ljavax/net/ssl/SSLSocket;

    invoke-direct {p0, p2}, Lcom/github/catvod/spider/appysv2/n/g;->a(Ljavax/net/ssl/SSLSocket;)V

    :cond_10
    return-object p1
.end method

.method public final createSocket(Ljava/lang/String;ILjava/net/InetAddress;I)Ljava/net/Socket;
    .registers 6

    iget-object v0, p0, Lcom/github/catvod/spider/appysv2/n/g;->a:Ljavax/net/ssl/SSLSocketFactory;

    invoke-virtual {v0, p1, p2, p3, p4}, Ljavax/net/SocketFactory;->createSocket(Ljava/lang/String;ILjava/net/InetAddress;I)Ljava/net/Socket;

    move-result-object p1

    instance-of p2, p1, Ljavax/net/ssl/SSLSocket;

    if-eqz p2, :cond_10

    move-object p2, p1

    check-cast p2, Ljavax/net/ssl/SSLSocket;

    invoke-direct {p0, p2}, Lcom/github/catvod/spider/appysv2/n/g;->a(Ljavax/net/ssl/SSLSocket;)V

    :cond_10
    return-object p1
.end method

.method public final createSocket(Ljava/net/InetAddress;I)Ljava/net/Socket;
    .registers 4

    iget-object v0, p0, Lcom/github/catvod/spider/appysv2/n/g;->a:Ljavax/net/ssl/SSLSocketFactory;

    invoke-virtual {v0, p1, p2}, Ljavax/net/SocketFactory;->createSocket(Ljava/net/InetAddress;I)Ljava/net/Socket;

    move-result-object p1

    instance-of p2, p1, Ljavax/net/ssl/SSLSocket;

    if-eqz p2, :cond_10

    move-object p2, p1

    check-cast p2, Ljavax/net/ssl/SSLSocket;

    invoke-direct {p0, p2}, Lcom/github/catvod/spider/appysv2/n/g;->a(Ljavax/net/ssl/SSLSocket;)V

    :cond_10
    return-object p1
.end method

.method public final createSocket(Ljava/net/InetAddress;ILjava/net/InetAddress;I)Ljava/net/Socket;
    .registers 6

    iget-object v0, p0, Lcom/github/catvod/spider/appysv2/n/g;->a:Ljavax/net/ssl/SSLSocketFactory;

    invoke-virtual {v0, p1, p2, p3, p4}, Ljavax/net/SocketFactory;->createSocket(Ljava/net/InetAddress;ILjava/net/InetAddress;I)Ljava/net/Socket;

    move-result-object p1

    instance-of p2, p1, Ljavax/net/ssl/SSLSocket;

    if-eqz p2, :cond_10

    move-object p2, p1

    check-cast p2, Ljavax/net/ssl/SSLSocket;

    invoke-direct {p0, p2}, Lcom/github/catvod/spider/appysv2/n/g;->a(Ljavax/net/ssl/SSLSocket;)V

    :cond_10
    return-object p1
.end method

.method public final createSocket(Ljava/net/Socket;Ljava/lang/String;IZ)Ljava/net/Socket;
    .registers 6

    iget-object v0, p0, Lcom/github/catvod/spider/appysv2/n/g;->a:Ljavax/net/ssl/SSLSocketFactory;

    invoke-virtual {v0, p1, p2, p3, p4}, Ljavax/net/ssl/SSLSocketFactory;->createSocket(Ljava/net/Socket;Ljava/lang/String;IZ)Ljava/net/Socket;

    move-result-object p1

    instance-of p2, p1, Ljavax/net/ssl/SSLSocket;

    if-eqz p2, :cond_10

    move-object p2, p1

    check-cast p2, Ljavax/net/ssl/SSLSocket;

    invoke-direct {p0, p2}, Lcom/github/catvod/spider/appysv2/n/g;->a(Ljavax/net/ssl/SSLSocket;)V

    :cond_10
    return-object p1
.end method

.method public final getDefaultCipherSuites()[Ljava/lang/String;
    .registers 2

    iget-object v0, p0, Lcom/github/catvod/spider/appysv2/n/g;->b:[Ljava/lang/String;

    return-object v0
.end method

.method public final getSupportedCipherSuites()[Ljava/lang/String;
    .registers 2

    iget-object v0, p0, Lcom/github/catvod/spider/appysv2/n/g;->b:[Ljava/lang/String;

    return-object v0
.end method
