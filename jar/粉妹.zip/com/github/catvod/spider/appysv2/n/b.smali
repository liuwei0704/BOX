.class final Lcom/github/catvod/spider/appysv2/n/b;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field static volatile a:Lcom/github/catvod/spider/appysv2/n/c;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    new-instance v0, Lcom/github/catvod/spider/appysv2/n/c;

    invoke-direct {v0}, Lcom/github/catvod/spider/appysv2/n/c;-><init>()V

    sput-object v0, Lcom/github/catvod/spider/appysv2/n/b;->a:Lcom/github/catvod/spider/appysv2/n/c;

    return-void
.end method
