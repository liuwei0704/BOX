.class final Lcom/github/catvod/spider/appysv2/n/d;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field private final a:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field private final b:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field private final c:Ljava/lang/String;

.field private final d:Ljava/lang/String;

.field private e:Lokhttp3/Request;

.field private f:Ljava/lang/String;


# direct methods
.method constructor <init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/util/Map;)V
    .registers 11
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;)V"
        }
    .end annotation

    const/4 v4, 0x0

    move-object v0, p0

    move-object v1, p1

    move-object v2, p2

    move-object v3, p3

    move-object v5, p4

    invoke-direct/range {v0 .. v5}, Lcom/github/catvod/spider/appysv2/n/d;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/util/Map;Ljava/util/Map;)V

    return-void
.end method

.method private constructor <init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/util/Map;Ljava/util/Map;)V
    .registers 11
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;)V"
        }
    .end annotation

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p2, p0, Lcom/github/catvod/spider/appysv2/n/d;->f:Ljava/lang/String;

    iput-object p3, p0, Lcom/github/catvod/spider/appysv2/n/d;->d:Ljava/lang/String;

    iput-object p1, p0, Lcom/github/catvod/spider/appysv2/n/d;->c:Ljava/lang/String;

    iput-object p4, p0, Lcom/github/catvod/spider/appysv2/n/d;->b:Ljava/util/Map;

    iput-object p5, p0, Lcom/github/catvod/spider/appysv2/n/d;->a:Ljava/util/Map;

    .line 1
    new-instance p2, Lokhttp3/Request$Builder;

    invoke-direct {p2}, Lokhttp3/Request$Builder;-><init>()V

    const/4 p3, 0x3

    new-array p3, p3, [B

    fill-array-data p3, :array_140

    const/16 p5, 0x8

    new-array v0, p5, [B

    fill-array-data v0, :array_146

    invoke-static {p3, v0}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object p3

    invoke-virtual {p1, p3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_a4

    if-eqz p4, :cond_a4

    .line 2
    new-instance p1, Ljava/lang/StringBuilder;

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    iget-object p3, p0, Lcom/github/catvod/spider/appysv2/n/d;->f:Ljava/lang/String;

    invoke-virtual {p1, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 p3, 0x1

    new-array v0, p3, [B

    const/16 v1, 0x29

    const/4 v2, 0x0

    aput-byte v1, v0, v2

    new-array v1, p5, [B

    fill-array-data v1, :array_14e

    .line 3
    invoke-static {v0, v1, p1}, Lcom/github/catvod/spider/appysv2/b/t;->a([B[BLjava/lang/StringBuilder;)Ljava/lang/String;

    move-result-object p1

    .line 4
    iput-object p1, p0, Lcom/github/catvod/spider/appysv2/n/d;->f:Ljava/lang/String;

    invoke-interface {p4}, Ljava/util/Map;->keySet()Ljava/util/Set;

    move-result-object p1

    invoke-interface {p1}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :goto_50
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result p4

    if-eqz p4, :cond_9c

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object p4

    check-cast p4, Ljava/lang/String;

    iget-object v0, p0, Lcom/github/catvod/spider/appysv2/n/d;->f:Ljava/lang/String;

    .line 5
    invoke-static {p4}, Lcom/github/catvod/spider/appysv2/b/t;->b(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    new-array v3, p3, [B

    const/16 v4, 0x17

    aput-byte v4, v3, v2

    new-array v4, p5, [B

    .line 6
    fill-array-data v4, :array_156

    invoke-static {v3, v4}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v3, p0, Lcom/github/catvod/spider/appysv2/n/d;->b:Ljava/util/Map;

    invoke-interface {v3, p4}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p4

    check-cast p4, Ljava/lang/String;

    invoke-virtual {v1, p4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    new-array p4, p3, [B

    const/16 v3, -0x2c

    aput-byte v3, p4, v2

    new-array v3, p5, [B

    fill-array-data v3, :array_15e

    invoke-static {p4, v3}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object p4

    invoke-virtual {v1, p4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p4

    invoke-virtual {v0, p4}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p4

    iput-object p4, p0, Lcom/github/catvod/spider/appysv2/n/d;->f:Ljava/lang/String;

    goto :goto_50

    :cond_9c
    iget-object p1, p0, Lcom/github/catvod/spider/appysv2/n/d;->f:Ljava/lang/String;

    invoke-static {p1}, Lcom/github/catvod/spider/appysv2/p/C;->s(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    iput-object p1, p0, Lcom/github/catvod/spider/appysv2/n/d;->f:Ljava/lang/String;

    .line 7
    :cond_a4
    iget-object p1, p0, Lcom/github/catvod/spider/appysv2/n/d;->c:Ljava/lang/String;

    const/4 p3, 0x4

    new-array p3, p3, [B

    fill-array-data p3, :array_166

    new-array p4, p5, [B

    fill-array-data p4, :array_16c

    invoke-static {p3, p4}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object p3

    invoke-virtual {p1, p3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_10e

    .line 8
    iget-object p1, p0, Lcom/github/catvod/spider/appysv2/n/d;->d:Ljava/lang/String;

    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result p1

    if-nez p1, :cond_de

    const/16 p1, 0x1f

    new-array p1, p1, [B

    fill-array-data p1, :array_174

    new-array p3, p5, [B

    fill-array-data p3, :array_188

    invoke-static {p1, p3}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object p1

    invoke-static {p1}, Lokhttp3/MediaType;->get(Ljava/lang/String;)Lokhttp3/MediaType;

    move-result-object p1

    iget-object p3, p0, Lcom/github/catvod/spider/appysv2/n/d;->d:Ljava/lang/String;

    invoke-static {p1, p3}, Lokhttp3/RequestBody;->create(Lokhttp3/MediaType;Ljava/lang/String;)Lokhttp3/RequestBody;

    move-result-object p1

    goto :goto_10b

    :cond_de
    new-instance p1, Lokhttp3/FormBody$Builder;

    invoke-direct {p1}, Lokhttp3/FormBody$Builder;-><init>()V

    iget-object p3, p0, Lcom/github/catvod/spider/appysv2/n/d;->b:Ljava/util/Map;

    if-eqz p3, :cond_107

    invoke-interface {p3}, Ljava/util/Map;->keySet()Ljava/util/Set;

    move-result-object p3

    invoke-interface {p3}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object p3

    :goto_ef
    invoke-interface {p3}, Ljava/util/Iterator;->hasNext()Z

    move-result p4

    if-eqz p4, :cond_107

    invoke-interface {p3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object p4

    check-cast p4, Ljava/lang/String;

    iget-object p5, p0, Lcom/github/catvod/spider/appysv2/n/d;->b:Ljava/util/Map;

    invoke-interface {p5, p4}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p5

    check-cast p5, Ljava/lang/String;

    invoke-virtual {p1, p4, p5}, Lokhttp3/FormBody$Builder;->add(Ljava/lang/String;Ljava/lang/String;)Lokhttp3/FormBody$Builder;

    goto :goto_ef

    :cond_107
    invoke-virtual {p1}, Lokhttp3/FormBody$Builder;->build()Lokhttp3/FormBody;

    move-result-object p1

    .line 9
    :goto_10b
    invoke-virtual {p2, p1}, Lokhttp3/Request$Builder;->post(Lokhttp3/RequestBody;)Lokhttp3/Request$Builder;

    :cond_10e
    iget-object p1, p0, Lcom/github/catvod/spider/appysv2/n/d;->a:Ljava/util/Map;

    if-eqz p1, :cond_132

    invoke-interface {p1}, Ljava/util/Map;->keySet()Ljava/util/Set;

    move-result-object p1

    invoke-interface {p1}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :goto_11a
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result p3

    if-eqz p3, :cond_132

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object p3

    check-cast p3, Ljava/lang/String;

    iget-object p4, p0, Lcom/github/catvod/spider/appysv2/n/d;->a:Ljava/util/Map;

    invoke-interface {p4, p3}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p4

    check-cast p4, Ljava/lang/String;

    invoke-virtual {p2, p3, p4}, Lokhttp3/Request$Builder;->addHeader(Ljava/lang/String;Ljava/lang/String;)Lokhttp3/Request$Builder;

    goto :goto_11a

    :cond_132
    iget-object p1, p0, Lcom/github/catvod/spider/appysv2/n/d;->f:Ljava/lang/String;

    invoke-virtual {p2, p1}, Lokhttp3/Request$Builder;->url(Ljava/lang/String;)Lokhttp3/Request$Builder;

    move-result-object p1

    invoke-virtual {p1}, Lokhttp3/Request$Builder;->build()Lokhttp3/Request;

    move-result-object p1

    iput-object p1, p0, Lcom/github/catvod/spider/appysv2/n/d;->e:Lokhttp3/Request;

    return-void

    nop

    :array_140
    .array-data 1
        -0x4bt
        -0x62t
        0x42t
    .end array-data

    :array_146
    .array-data 1
        -0xet
        -0x25t
        0x16t
        0x48t
        -0x1at
        -0x51t
        0x10t
        0x3at
    .end array-data

    :array_14e
    .array-data 1
        0x16t
        0x6at
        0x7t
        -0x3ft
        0x54t
        0x33t
        0x40t
        0x54t
    .end array-data

    :array_156
    .array-data 1
        0x2at
        0x3et
        -0x2bt
        -0x1dt
        0x27t
        0x71t
        0x5et
        0x6bt
    .end array-data

    :array_15e
    .array-data 1
        -0xet
        0x42t
        -0x44t
        -0x41t
        -0x68t
        0x73t
        0x67t
        0x3dt
    .end array-data

    :array_166
    .array-data 1
        0x21t
        0x30t
        0x3t
        -0x7et
    .end array-data

    :array_16c
    .array-data 1
        0x71t
        0x7ft
        0x50t
        -0x2at
        -0x19t
        0x4ct
        -0x4ct
        -0x70t
    .end array-data

    :array_174
    .array-data 1
        -0xct
        -0x15t
        0x7ct
        0x44t
        0x3ct
        -0x61t
        -0x5ct
        0x52t
        -0x4t
        -0xct
        0x62t
        0x7t
        0x3ft
        -0x71t
        -0x56t
        0x48t
        -0x52t
        -0x45t
        0x6ft
        0x40t
        0x34t
        -0x72t
        -0x4at
        0x43t
        -0x1ft
        -0x5at
        0x79t
        0x5ct
        0x33t
        -0x2ft
        -0x3t
    .end array-data

    :array_188
    .array-data 1
        -0x6bt
        -0x65t
        0xct
        0x28t
        0x55t
        -0x4t
        -0x3bt
        0x26t
    .end array-data
.end method

.method constructor <init>(Ljava/lang/String;Ljava/lang/String;Ljava/util/Map;Ljava/util/Map;)V
    .registers 11
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;)V"
        }
    .end annotation

    const/4 v3, 0x0

    move-object v0, p0

    move-object v1, p1

    move-object v2, p2

    move-object v4, p3

    move-object v5, p4

    invoke-direct/range {v0 .. v5}, Lcom/github/catvod/spider/appysv2/n/d;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/util/Map;Ljava/util/Map;)V

    return-void
.end method


# virtual methods
.method public final a(Lokhttp3/OkHttpClient;)Lcom/github/catvod/spider/appysv2/n/e;
    .registers 5

    :try_start_0
    iget-object v0, p0, Lcom/github/catvod/spider/appysv2/n/d;->e:Lokhttp3/Request;

    invoke-virtual {p1, v0}, Lokhttp3/OkHttpClient;->newCall(Lokhttp3/Request;)Lokhttp3/Call;

    move-result-object p1

    invoke-interface {p1}, Lokhttp3/Call;->execute()Lokhttp3/Response;

    move-result-object p1

    new-instance v0, Lcom/github/catvod/spider/appysv2/n/e;

    invoke-virtual {p1}, Lokhttp3/Response;->code()I

    move-result v1

    invoke-virtual {p1}, Lokhttp3/Response;->body()Lokhttp3/ResponseBody;

    move-result-object v2

    invoke-virtual {v2}, Lokhttp3/ResponseBody;->string()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {p1}, Lokhttp3/Response;->headers()Lokhttp3/Headers;

    move-result-object p1

    invoke-virtual {p1}, Lokhttp3/Headers;->toMultimap()Ljava/util/Map;

    move-result-object p1

    invoke-direct {v0, v1, v2, p1}, Lcom/github/catvod/spider/appysv2/n/e;-><init>(ILjava/lang/String;Ljava/util/Map;)V
    :try_end_23
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_23} :catch_24

    return-object v0

    :catch_24
    new-instance p1, Lcom/github/catvod/spider/appysv2/n/e;

    invoke-direct {p1}, Lcom/github/catvod/spider/appysv2/n/e;-><init>()V

    return-object p1
.end method
