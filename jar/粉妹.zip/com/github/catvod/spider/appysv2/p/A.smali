.class final Lcom/github/catvod/spider/appysv2/p/A;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field static volatile a:Lcom/github/catvod/spider/appysv2/p/B;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    new-instance v0, Lcom/github/catvod/spider/appysv2/p/B;

    invoke-direct {v0}, Lcom/github/catvod/spider/appysv2/p/B;-><init>()V

    sput-object v0, Lcom/github/catvod/spider/appysv2/p/A;->a:Lcom/github/catvod/spider/appysv2/p/B;

    return-void
.end method
