.class public final synthetic Lcom/github/catvod/spider/appysv2/p/u;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/content/DialogInterface$OnClickListener;


# instance fields
.field public final synthetic a:Lcom/github/catvod/spider/appysv2/p/B;

.field public final synthetic b:Ljava/util/Map;


# direct methods
.method public synthetic constructor <init>(Lcom/github/catvod/spider/appysv2/p/B;Ljava/util/Map;)V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/github/catvod/spider/appysv2/p/u;->a:Lcom/github/catvod/spider/appysv2/p/B;

    iput-object p2, p0, Lcom/github/catvod/spider/appysv2/p/u;->b:Ljava/util/Map;

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/content/DialogInterface;I)V
    .registers 6

    iget-object p1, p0, Lcom/github/catvod/spider/appysv2/p/u;->a:Lcom/github/catvod/spider/appysv2/p/B;

    iget-object p2, p0, Lcom/github/catvod/spider/appysv2/p/u;->b:Ljava/util/Map;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v0, 0x5

    new-array v0, v0, [B

    fill-array-data v0, :array_4a

    const/16 v1, 0x8

    new-array v2, v1, [B

    fill-array-data v2, :array_52

    invoke-static {v0, v2}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v0

    const-string v2, ""

    invoke-interface {p2, v0, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v0, 0x4

    new-array v0, v0, [B

    fill-array-data v0, :array_5a

    new-array v2, v1, [B

    fill-array-data v2, :array_60

    invoke-static {v0, v2}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v0

    const/16 v2, 0x21

    new-array v2, v2, [B

    fill-array-data v2, :array_68

    new-array v1, v1, [B

    fill-array-data v1, :array_7e

    invoke-static {v2, v1}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-interface {p2, v0, v1}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    new-instance v0, Lcom/github/catvod/spider/appysv2/p/z;

    const/4 v1, 0x2

    invoke-direct {v0, p1, p2, v1}, Lcom/github/catvod/spider/appysv2/p/z;-><init>(Ljava/lang/Object;Ljava/lang/Object;I)V

    invoke-static {v0}, Lcom/github/catvod/spider/Init;->execute(Ljava/lang/Runnable;)V

    return-void

    nop

    :array_4a
    .array-data 1
        0x7bt
        0x44t
        -0x47t
        -0x2ct
        -0x66t
    .end array-data

    nop

    :array_52
    .array-data 1
        0x16t
        0x2bt
        -0x23t
        -0x4ft
        -0xat
        -0x79t
        -0x28t
        -0xat
    .end array-data

    :array_5a
    .array-data 1
        -0x49t
        -0x4dt
        -0x40t
        -0x2ft
    .end array-data

    :array_60
    .array-data 1
        -0x2ft
        -0x21t
        -0x5ft
        -0x4at
        0x3et
        0x3bt
        0x58t
        -0x5et
    .end array-data

    :array_68
    .array-data 1
        0x7t
        -0x72t
        -0x7et
        -0x48t
        -0x28t
        -0x2ft
        0x18t
        -0x5bt
        0x4at
        -0x3ct
        -0x6ft
        -0x7t
        -0x7ft
        -0x3t
        0x41t
        -0x3ct
        0x55t
        -0x50t
        -0x2et
        -0x35t
        -0x2t
        -0x56t
        0x49t
        -0x7at
        0xat
        -0x52t
        -0x7et
        -0x4bt
        -0x37t
        -0x3ct
        0x1at
        -0x80t
        0x6et
    .end array-data

    nop

    :array_7e
    .array-data 1
        -0x11t
        0x21t
        0x35t
        0x50t
        0x66t
        0x42t
        -0x3t
        0x20t
    .end array-data
.end method
