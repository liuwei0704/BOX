.class public final Lcom/github/catvod/spider/appysv2/p/e;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field private static final a:Ljava/util/regex/Pattern;

.field public static final b:Ljava/lang/String;


# direct methods
.method static constructor <clinit>()V
    .registers 3

    const/16 v0, 0x72

    new-array v0, v0, [B

    fill-array-data v0, :array_3e

    const/16 v1, 0x8

    new-array v2, v1, [B

    fill-array-data v2, :array_7c

    invoke-static {v0, v2}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    const/16 v0, 0x7a

    new-array v0, v0, [B

    fill-array-data v0, :array_84

    new-array v2, v1, [B

    fill-array-data v2, :array_c6

    invoke-static {v0, v2}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lcom/github/catvod/spider/appysv2/p/e;->b:Ljava/lang/String;

    const/16 v0, 0x1ca

    new-array v0, v0, [B

    fill-array-data v0, :array_ce

    new-array v1, v1, [B

    fill-array-data v1, :array_1b8

    invoke-static {v0, v1}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    move-result-object v0

    sput-object v0, Lcom/github/catvod/spider/appysv2/p/e;->a:Ljava/util/regex/Pattern;

    sget-object v0, Ljava/nio/charset/StandardCharsets;->UTF_8:Ljava/nio/charset/Charset;

    sget-object v0, Ljava/nio/charset/StandardCharsets;->ISO_8859_1:Ljava/nio/charset/Charset;

    return-void

    :array_3e
    .array-data 1
        -0x5bt
        -0x53t
        0x60t
        0x1at
        0x10t
        0x2dt
        0x18t
        -0x5t
        -0x23t
        -0x14t
        0x2at
        0x53t
        0x54t
        0x16t
        0x10t
        -0x46t
        -0x74t
        -0x53t
        0x6dt
        0x0t
        0x5ct
        0xft
        0x2dt
        -0xct
        -0x27t
        -0xet
        0x34t
        0x43t
        0x47t
        0x61t
        0x2et
        -0x43t
        -0x7at
        -0xct
        0x2et
        0x48t
        0x5ct
        0x39t
        0x4ft
        -0x20t
        -0x3ft
        -0x1et
        0x5bt
        0x3t
        0xct
        0x2dt
        0x1ct
        -0x7dt
        -0x73t
        -0x60t
        0x51t
        0x1at
        0x8t
        0x6et
        0x4ct
        -0x19t
        -0x21t
        -0x14t
        0x29t
        0x45t
        0x5ct
        0x69t
        0x32t
        -0x64t
        -0x44t
        -0x71t
        0x56t
        0x5ft
        0x5ct
        0x2dt
        0x10t
        -0x41t
        -0x73t
        -0x1et
        0x5dt
        0x16t
        0x1ft
        0x2at
        0x16t
        -0x3t
        -0x38t
        -0x7ft
        0x72t
        0x1t
        0x13t
        0x2ct
        0x1ct
        -0x5t
        -0x2ft
        -0xat
        0x34t
        0x43t
        0x52t
        0x75t
        0x4ft
        -0x1ct
        -0x22t
        -0x14t
        0x2ft
        0x47t
        0x5ct
        0x12t
        0x18t
        -0x4et
        -0x77t
        -0x50t
        0x73t
        0x5ct
        0x49t
        0x72t
        0x4et
        -0x6t
        -0x25t
        -0xct
    .end array-data

    nop

    :array_7c
    .array-data 1
        -0x18t
        -0x3et
        0x1at
        0x73t
        0x7ct
        0x41t
        0x79t
        -0x2ct
    .end array-data

    :array_84
    .array-data 1
        0x3ct
        0x50t
        -0x6t
        0x79t
        0x75t
        0x43t
        0x5et
        -0x63t
        0x44t
        0x11t
        -0x50t
        0x30t
        0x31t
        0x63t
        0x56t
        -0x24t
        0x4t
        0x47t
        -0x45t
        0x30t
        0x58t
        0x41t
        0x5bt
        -0x40t
        0x1et
        0x56t
        -0x1ct
        0x30t
        0x28t
        0x1ft
        0x4t
        -0x6et
        0x22t
        0x72t
        -0x53t
        0x57t
        0x20t
        0x18t
        0xat
        -0xct
        0x58t
        0x1ft
        -0x3ft
        0x60t
        0x69t
        0x43t
        0x5at
        -0x1bt
        0x14t
        0x5dt
        -0x35t
        0x79t
        0x6dt
        0x0t
        0xat
        -0x7ft
        0x46t
        0x11t
        -0x4dt
        0x26t
        0x39t
        0x7t
        0x74t
        -0x6t
        0x25t
        0x72t
        -0x34t
        0x3ct
        0x39t
        0x43t
        0x56t
        -0x27t
        0x14t
        0x1ft
        -0x39t
        0x75t
        0x7at
        0x44t
        0x50t
        -0x65t
        0x51t
        0x7ct
        -0x18t
        0x62t
        0x76t
        0x42t
        0x5at
        -0x63t
        0x48t
        0xet
        -0x52t
        0x20t
        0x37t
        0x1bt
        0xbt
        -0x7bt
        0x43t
        0x11t
        -0x4ft
        0x22t
        0x29t
        0xft
        0x72t
        -0x23t
        0x13t
        0x56t
        -0x14t
        0x75t
        0x39t
        0x7ct
        0x5et
        -0x2ct
        0x10t
        0x4dt
        -0x17t
        0x3ft
        0x2ct
        0x1ct
        0x8t
        -0x64t
        0x42t
        0x9t
    .end array-data

    nop

    :array_c6
    .array-data 1
        0x71t
        0x3ft
        -0x80t
        0x10t
        0x19t
        0x2ft
        0x3ft
        -0x4et
    .end array-data

    :array_ce
    .array-data 1
        -0x7bt
        -0x77t
        0x4ct
        -0x67t
        0x73t
        0x5bt
        -0x25t
        0x73t
        -0x7bt
        -0x77t
        0x4ct
        -0x67t
        0x72t
        0x5dt
        -0x33t
        0x29t
        -0x21t
        -0x35t
        0x14t
        -0x6ct
        0x64t
        0x2ft
        -0x36t
        0x7at
        -0x80t
        -0x32t
        0x4dt
        -0x2ft
        0x27t
        0x1et
        -0x6ct
        0x66t
        -0x3ct
        -0x5ft
        0x7t
        -0x39t
        0x71t
        0xft
        -0x74t
        0x26t
        -0x67t
        -0x73t
        0x10t
        -0x3ft
        0x64t
        0x52t
        -0x74t
        0x26t
        -0x67t
        -0x73t
        0x11t
        -0x39t
        0x72t
        0x8t
        -0x2at
        0x64t
        -0x3ft
        -0x80t
        0x64t
        -0x39t
        0x73t
        0x1et
        -0x29t
        0x27t
        -0x2bt
        -0x7ft
        0x55t
        -0x67t
        0x6ft
        0x5at
        -0x68t
        0x3at
        -0x67t
        -0x77t
        0x48t
        -0x3ft
        0x73t
        0x4ct
        -0x3bt
        0x3at
        -0x67t
        -0x77t
        0x48t
        -0x40t
        0x75t
        0x5at
        -0x61t
        0x60t
        -0x25t
        -0x2ft
        0x45t
        -0x2at
        0x74t
        0x1et
        -0x29t
        0x27t
        -0x2bt
        -0x5ft
        0x7t
        -0x67t
        0x2ft
        0x4et
        -0x77t
        0x61t
        -0x68t
        -0x3bt
        0x16t
        -0x3dt
        0x27t
        0x1bt
        -0x70t
        0x26t
        -0x63t
        -0x2bt
        0x10t
        -0x2at
        0x7at
        0x1bt
        -0x70t
        0x26t
        -0x63t
        -0x2ct
        0x16t
        -0x40t
        0x71t
        0x4ct
        -0x80t
        0x37t
        -0x75t
        -0x64t
        0x4dt
        -0x7bt
        0x2ft
        0x2ft
        -0x36t
        0x3bt
        -0x6bt
        -0x6ct
        0x5ft
        -0x64t
        0x3at
        0x2ft
        -0x36t
        0x31t
        -0x7et
        -0x70t
        0x17t
        -0x39t
        0x71t
        0xft
        -0x74t
        0x26t
        -0x67t
        -0x73t
        0x10t
        -0x3ft
        0x64t
        0x52t
        -0x74t
        0x26t
        -0x67t
        -0x73t
        0x11t
        -0x39t
        0x72t
        0x59t
        -0x25t
        0x31t
        -0x77t
        -0x6dt
        0x15t
        -0x63t
        0x34t
        0x0t
        -0x41t
        0xct
        -0x4ft
        -0x3et
        0x65t
        -0x3dt
        0x27t
        0x1bt
        -0x70t
        0x26t
        -0x63t
        -0x2bt
        0x10t
        -0x2at
        0x7at
        0x1bt
        -0x70t
        0x26t
        -0x63t
        -0x2ct
        0x16t
        -0x40t
        0x71t
        0x4ct
        -0x35t
        0x3dt
        -0x71t
        -0x69t
        0x17t
        -0x63t
        0x34t
        0x0t
        -0x41t
        0xct
        -0x4ft
        -0x3et
        0x65t
        -0x3dt
        0x27t
        0x1bt
        -0x70t
        0x26t
        -0x63t
        -0x2dt
        0x12t
        -0x2at
        0x74t
        0x3t
        -0x78t
        0x33t
        -0x6ct
        -0x68t
        0x4at
        -0x3at
        0x36t
        0x40t
        -0x6ft
        0x6at
        -0x63t
        -0x6ft
        0x59t
        -0x70t
        0x7t
        0x5dt
        -0x6ct
        0x3at
        -0x63t
        -0x5ft
        0x7t
        -0x64t
        0x29t
        0x1ft
        -0x27t
        0x7ct
        -0x39t
        -0x7ft
        0x50t
        -0x63t
        0x2ft
        0x3t
        -0x36t
        0x78t
        -0x2et
        -0x2et
        0x48t
        -0x7bt
        0x3at
        0xat
        -0x7ft
        0x20t
        -0x3et
        -0x2dt
        0x12t
        -0x2at
        0x0t
        0x3t
        -0x4ct
        0xft
        -0x7ft
        -0x64t
        0x41t
        -0x4bt
        0x75t
        0x3t
        -0x74t
        0x22t
        -0x4ft
        -0x3et
        0x4dt
        -0x65t
        0x37t
        0x4et
        -0x36t
        0x78t
        -0x6ft
        -0x6bt
        0x4ct
        -0x63t
        0x2bt
        0x5dt
        -0x32t
        0x6dt
        -0x3et
        -0x73t
        0x54t
        -0x78t
        0x22t
        0x1ft
        -0x73t
        0x21t
        -0x67t
        -0x2et
        0x55t
        -0x26t
        0x2et
        0x4bt
        -0x35t
        0xet
        -0x2et
        -0x75t
        0x51t
        -0x73t
        0x66t
        0x5dt
        -0x32t
        0x2et
        -0x7bt
        -0x77t
        0x4ct
        -0x67t
        0x75t
        0x59t
        -0x25t
        0xet
        -0x3dt
        -0x73t
        0x50t
        -0x67t
        0x7t
        0x4ct
        -0x70t
        0x2bt
        -0x63t
        -0x68t
        0x5t
        -0x7ct
        0x68t
        0x6t
        -0x24t
        0x74t
        -0x3dt
        -0x29t
        0x44t
        -0x7ft
        0x2ft
        0x7t
        -0x6ct
        0x7ct
        -0x39t
        -0x3et
        0x17t
        -0x73t
        0x34t
        0x4t
        -0x76t
        0x3et
        -0x7et
        -0x64t
        0x5ct
        -0x39t
        0x3at
        0x0t
        -0x6ct
        0x2at
        -0x4ft
        -0x3et
        0x16t
        -0x3dt
        0x27t
        0x1bt
        -0x70t
        0x26t
        -0x63t
        -0x2dt
        0x12t
        -0x2at
        0x74t
        0x12t
        -0x6ct
        0x3bt
        -0x3et
        -0x78t
        0x48t
        -0x4at
        0x3at
        0x3t
        -0x73t
        0x7ct
        -0x63t
        -0x6bt
        0x48t
        -0x4bt
        0x64t
        0x5dt
        -0x32t
        0x2et
        -0x7bt
        -0x77t
        0x4ct
        -0x67t
        0x28t
        0x5dt
        -0x32t
        0x6dt
        -0x4ft
        -0x2dt
        0xet
        -0x21t
        0x22t
        0x18t
        -0x48t
        0x7ct
        -0x72t
        -0x6dt
        0x16t
        -0x3dt
        0x27t
        0x1bt
        -0x70t
        0x26t
        -0x63t
        -0x2bt
        0x10t
        -0x2at
        0x7at
        0x1bt
        -0x70t
        0x26t
        -0x63t
        -0x2ct
        0x16t
        -0x40t
        0x71t
        0x4ct
        -0x76t
        0x37t
        -0x67t
        -0x68t
        0x59t
        -0x66t
        0x3et
        0x2ft
        -0x36t
        0x31t
        -0x7et
        -0x70t
        0x17t
        -0x71t
        0x32t
        0x1ft
        -0x7ft
        0x7dt
        -0x3dt
        -0x29t
    .end array-data

    nop

    :array_1b8
    .array-data 1
        -0x13t
        -0x3t
        0x38t
        -0x17t
        0x5bt
        0x73t
        -0x1ct
        0x52t
    .end array-data
.end method

.method public static a(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    .registers 16

    const/4 v0, 0x2

    :try_start_1
    new-array v1, v0, [B

    const/16 v2, -0x74

    const/4 v3, 0x0

    aput-byte v2, v1, v3

    const/16 v4, 0x61

    const/4 v5, 0x1

    aput-byte v4, v1, v5

    const/16 v4, 0x8

    new-array v6, v4, [B

    const/16 v7, -0x5d

    aput-byte v7, v6, v3

    const/16 v7, 0x4e

    aput-byte v7, v6, v5

    const/16 v7, 0x33

    aput-byte v7, v6, v0

    const/16 v7, -0x30

    const/4 v8, 0x3

    aput-byte v7, v6, v8

    const/16 v7, 0x32

    const/4 v9, 0x4

    aput-byte v7, v6, v9

    const/16 v7, 0x36

    const/4 v10, 0x5

    aput-byte v7, v6, v10

    const/16 v11, -0x36

    const/4 v12, 0x6

    aput-byte v11, v6, v12

    const/16 v11, -0x75

    const/4 v13, 0x7

    aput-byte v11, v6, v13

    invoke-static {v1, v6}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {p1, v1}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_81

    invoke-static {p0}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object p0

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {p0}, Landroid/net/Uri;->getScheme()Ljava/lang/String;

    move-result-object p0

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    new-array p0, v5, [B

    const/16 v6, 0x77

    aput-byte v6, p0, v3

    new-array v4, v4, [B

    const/16 v6, 0x4d

    aput-byte v6, v4, v3

    const/16 v3, -0x58

    aput-byte v3, v4, v5

    aput-byte v9, v4, v0

    aput-byte v7, v4, v8

    aput-byte v2, v4, v9

    const/16 v0, -0x40

    aput-byte v0, v4, v10

    aput-byte v8, v4, v12

    const/16 v0, -0x54

    aput-byte v0, v4, v13

    invoke-static {p0, v4}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object p0

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    :goto_7a
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    move-object p1, p0

    goto/16 :goto_112

    :cond_81
    new-array v1, v8, [B

    const/16 v2, 0x17

    aput-byte v2, v1, v3

    const/16 v2, 0x11

    aput-byte v2, v1, v5

    const/16 v2, -0x5b

    aput-byte v2, v1, v0

    new-array v2, v4, [B

    const/16 v6, 0x2d

    aput-byte v6, v2, v3

    const/16 v6, 0x3e

    aput-byte v6, v2, v5

    const/16 v6, -0x76

    aput-byte v6, v2, v0

    const/16 v6, -0x7d

    aput-byte v6, v2, v8

    const/16 v6, -0x38

    aput-byte v6, v2, v9

    const/16 v6, 0x73

    aput-byte v6, v2, v10

    const/16 v6, 0x24

    aput-byte v6, v2, v12

    const/16 v6, -0x59

    aput-byte v6, v2, v13

    invoke-static {v1, v2}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {p1, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_112

    invoke-static {p0}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object p0

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {p0}, Landroid/net/Uri;->getScheme()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    new-array v2, v8, [B

    const/16 v6, 0x5c

    aput-byte v6, v2, v3

    const/16 v6, -0x3d

    aput-byte v6, v2, v5

    const/16 v6, -0x37

    aput-byte v6, v2, v0

    new-array v4, v4, [B

    const/16 v6, 0x66

    aput-byte v6, v4, v3

    const/16 v3, -0x14

    aput-byte v3, v4, v5

    const/16 v3, -0x1a

    aput-byte v3, v4, v0

    const/16 v0, -0x35

    aput-byte v0, v4, v8

    const/16 v0, 0x2e

    aput-byte v0, v4, v9

    const/16 v0, 0x22

    aput-byte v0, v4, v10

    const/16 v0, 0x63

    aput-byte v0, v4, v12

    const/16 v0, -0x25

    aput-byte v0, v4, v13

    invoke-static {v2, v4}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, Landroid/net/Uri;->getHost()Ljava/lang/String;

    move-result-object p0

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    :try_end_10c
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_10c} :catch_10e

    goto/16 :goto_7a

    :catch_10e
    move-exception p0

    invoke-static {p0}, Lcom/github/catvod/crawler/SpiderDebug;->log(Ljava/lang/Throwable;)V

    :cond_112
    :goto_112
    return-object p1
.end method

.method public static b(Ljava/lang/String;)Z
    .registers 29

    move-object/from16 v0, p0

    const/4 v1, 0x0

    :try_start_3
    invoke-static/range {p0 .. p0}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v2

    invoke-virtual {v2}, Landroid/net/Uri;->getHost()Ljava/lang/String;

    move-result-object v2

    const/16 v3, 0xb

    new-array v4, v3, [Ljava/lang/String;

    const/16 v5, 0x9

    new-array v6, v5, [B

    const/16 v7, -0x73

    aput-byte v7, v6, v1

    const/16 v7, -0x52

    const/4 v8, 0x1

    aput-byte v7, v6, v8

    const/16 v7, 0x75

    const/4 v9, 0x2

    aput-byte v7, v6, v9

    const/16 v10, -0x59

    const/4 v11, 0x3

    aput-byte v10, v6, v11

    const/16 v10, 0x23

    const/4 v12, 0x4

    aput-byte v10, v6, v12

    const/16 v10, 0x61

    const/4 v13, 0x5

    aput-byte v10, v6, v13

    const/16 v10, -0x14

    const/4 v14, 0x6

    aput-byte v10, v6, v14

    const/16 v10, 0x1a

    const/4 v15, 0x7

    aput-byte v10, v6, v15

    const/16 v10, -0x77

    const/16 v3, 0x8

    aput-byte v10, v6, v3

    new-array v10, v3, [B

    const/16 v18, -0x1c

    aput-byte v18, v10, v1

    const/16 v18, -0x21

    aput-byte v18, v10, v8

    const/16 v18, 0x1c

    aput-byte v18, v10, v9

    const/16 v18, -0x22

    aput-byte v18, v10, v11

    const/16 v18, 0x4a

    aput-byte v18, v10, v12

    const/16 v18, 0x4f

    aput-byte v18, v10, v13

    const/16 v18, -0x71

    aput-byte v18, v10, v14

    aput-byte v7, v10, v15

    invoke-static {v6, v10}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v6

    aput-object v6, v4, v1

    new-array v6, v3, [B

    const/16 v10, 0x5d

    aput-byte v10, v6, v1

    const/16 v10, 0x2f

    aput-byte v10, v6, v8

    const/16 v18, -0x6e

    aput-byte v18, v6, v9

    const/16 v18, -0x64

    aput-byte v18, v6, v11

    const/16 v10, 0xc

    aput-byte v10, v6, v12

    const/16 v20, 0xa

    aput-byte v20, v6, v13

    const/16 v21, 0x45

    aput-byte v21, v6, v14

    const/16 v22, -0x6c

    aput-byte v22, v6, v15

    new-array v10, v3, [B

    const/16 v23, 0x2b

    aput-byte v23, v10, v1

    aput-byte v8, v10, v8

    const/16 v23, -0x1d

    aput-byte v23, v10, v9

    const/16 v23, -0x13

    aput-byte v23, v10, v11

    const/16 v24, 0x22

    aput-byte v24, v10, v12

    const/16 v24, 0x69

    aput-byte v24, v10, v13

    const/16 v24, 0x2a

    aput-byte v24, v10, v14

    const/16 v25, -0x7

    aput-byte v25, v10, v15

    invoke-static {v6, v10}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v6

    aput-object v6, v4, v8

    new-array v6, v5, [B

    const/16 v10, 0x60

    aput-byte v10, v6, v1

    const/16 v10, -0x2f

    aput-byte v10, v6, v8

    aput-byte v18, v6, v9

    const/16 v10, 0x38

    aput-byte v10, v6, v11

    const/4 v10, -0x6

    aput-byte v10, v6, v12

    aput-byte v7, v6, v13

    const/16 v10, 0x6b

    aput-byte v10, v6, v14

    const/16 v10, 0x18

    aput-byte v10, v6, v15

    const/16 v10, 0x74

    aput-byte v10, v6, v3

    new-array v10, v3, [B

    const/16 v25, 0x19

    aput-byte v25, v10, v1

    const/16 v25, -0x42

    aput-byte v25, v10, v8

    const/16 v25, -0x17

    aput-byte v25, v10, v9

    const/16 v25, 0x53

    aput-byte v25, v10, v11

    const/16 v25, -0x71

    aput-byte v25, v10, v12

    const/16 v25, 0x5b

    aput-byte v25, v10, v13

    aput-byte v3, v10, v14

    const/16 v25, 0x77

    aput-byte v25, v10, v15

    invoke-static {v6, v10}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v6

    aput-object v6, v4, v9

    new-array v6, v14, [B

    const/16 v10, -0x54

    aput-byte v10, v6, v1

    const/16 v10, -0x7a

    aput-byte v10, v6, v8

    const/16 v10, 0x29

    aput-byte v10, v6, v9

    const/16 v25, -0x1b

    aput-byte v25, v6, v11

    const/16 v25, -0x22

    aput-byte v25, v6, v12

    const/16 v25, -0x32

    aput-byte v25, v6, v13

    new-array v10, v3, [B

    const/16 v26, -0x40

    aput-byte v26, v10, v1

    const/16 v26, -0x1d

    aput-byte v26, v10, v8

    aput-byte v15, v10, v9

    const/16 v26, -0x7a

    aput-byte v26, v10, v11

    const/16 v26, -0x4f

    aput-byte v26, v10, v12

    const/16 v26, -0x5d

    aput-byte v26, v10, v13

    const/16 v26, 0x1e

    aput-byte v26, v10, v14

    aput-byte v7, v10, v15

    invoke-static {v6, v10}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v6

    aput-object v6, v4, v11

    new-array v6, v5, [B

    const/16 v10, 0x5b

    aput-byte v10, v6, v1

    const/16 v10, -0x5d

    aput-byte v10, v6, v8

    const/16 v10, 0x2c

    aput-byte v10, v6, v9

    aput-byte v21, v6, v11

    const/16 v10, 0x67

    aput-byte v10, v6, v12

    const/16 v10, -0x65

    aput-byte v10, v6, v13

    const/16 v10, 0x13

    aput-byte v10, v6, v14

    const/16 v10, 0x42

    aput-byte v10, v6, v15

    aput-byte v10, v6, v3

    new-array v10, v3, [B

    const/16 v19, 0x2f

    aput-byte v19, v10, v1

    const/16 v27, -0x2a

    aput-byte v27, v10, v8

    const/16 v27, 0x48

    aput-byte v27, v10, v9

    aput-byte v24, v10, v11

    const/16 v27, 0x12

    aput-byte v27, v10, v12

    const/16 v27, -0x4b

    aput-byte v27, v10, v13

    const/16 v27, 0x70

    aput-byte v27, v10, v14

    const/16 v27, 0x2d

    aput-byte v27, v10, v15

    invoke-static {v6, v10}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v6

    aput-object v6, v4, v12

    new-array v6, v3, [B

    const/16 v10, -0x7d

    aput-byte v10, v6, v1

    const/16 v10, 0x12

    aput-byte v10, v6, v8

    const/16 v10, 0x47

    aput-byte v10, v6, v9

    const/16 v10, 0x1f

    aput-byte v10, v6, v11

    aput-byte v8, v6, v12

    const/16 v10, -0x4e

    aput-byte v10, v6, v13

    const/16 v10, -0x60

    aput-byte v10, v6, v14

    const/16 v10, 0x7e

    aput-byte v10, v6, v15

    new-array v10, v3, [B

    const/16 v27, -0x12

    aput-byte v27, v10, v1

    aput-byte v7, v10, v8

    const/16 v27, 0x33

    aput-byte v27, v10, v9

    const/16 v27, 0x69

    aput-byte v27, v10, v11

    const/16 v19, 0x2f

    aput-byte v19, v10, v12

    const/16 v27, -0x2f

    aput-byte v27, v10, v13

    const/16 v27, -0x31

    aput-byte v27, v10, v14

    const/16 v27, 0x13

    aput-byte v27, v10, v15

    invoke-static {v6, v10}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v6

    aput-object v6, v4, v13

    new-array v6, v3, [B

    const/16 v10, 0x57

    aput-byte v10, v6, v1

    const/16 v10, 0x4b

    aput-byte v10, v6, v8

    const/16 v10, -0x65

    aput-byte v10, v6, v9

    const/16 v10, -0x54

    aput-byte v10, v6, v11

    const/16 v10, -0xd

    aput-byte v10, v6, v12

    const/16 v10, -0x3c

    aput-byte v10, v6, v13

    const/16 v10, -0x41

    aput-byte v10, v6, v14

    const/4 v10, -0x7

    aput-byte v10, v6, v15

    new-array v10, v3, [B

    const/16 v27, 0x24

    aput-byte v27, v10, v1

    const/16 v27, 0x24

    aput-byte v27, v10, v8

    const/16 v27, -0xd

    aput-byte v27, v10, v9

    const/16 v27, -0x27

    aput-byte v27, v10, v11

    const/16 v27, -0x23

    aput-byte v27, v10, v12

    const/16 v27, -0x59

    aput-byte v27, v10, v13

    const/16 v27, -0x30

    aput-byte v27, v10, v14

    const/16 v27, -0x6c

    aput-byte v27, v10, v15

    invoke-static {v6, v10}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v6

    aput-object v6, v4, v14

    new-array v6, v3, [B

    aput-byte v24, v6, v1

    const/16 v10, -0x1f

    aput-byte v10, v6, v8

    const/16 v10, 0x6d

    aput-byte v10, v6, v9

    const/16 v10, 0x5c

    aput-byte v10, v6, v11

    const/16 v10, -0x3d

    aput-byte v10, v6, v12

    const/16 v10, 0x5a

    aput-byte v10, v6, v13

    const/16 v10, 0x29

    aput-byte v10, v6, v14

    const/16 v10, 0x60

    aput-byte v10, v6, v15

    new-array v10, v3, [B

    const/16 v24, 0x4b

    aput-byte v24, v10, v1

    const/16 v24, -0x7e

    aput-byte v24, v10, v8

    const/16 v16, 0xb

    aput-byte v16, v10, v9

    const/16 v24, 0x29

    aput-byte v24, v10, v11

    const/16 v24, -0x53

    aput-byte v24, v10, v12

    const/16 v24, 0x74

    aput-byte v24, v10, v13

    const/16 v24, 0x4a

    aput-byte v24, v10, v14

    const/16 v24, 0xe

    aput-byte v24, v10, v15

    invoke-static {v6, v10}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v6

    aput-object v6, v4, v15

    const/16 v6, 0xc

    new-array v10, v6, [B

    const/16 v6, 0x76

    aput-byte v6, v10, v1

    aput-byte v23, v10, v8

    const/16 v6, 0x19

    aput-byte v6, v10, v9

    const/16 v6, -0x6d

    aput-byte v6, v10, v11

    const/16 v6, -0x33

    aput-byte v6, v10, v12

    const/16 v6, -0x57

    aput-byte v6, v10, v13

    const/4 v6, -0x1

    aput-byte v6, v10, v14

    aput-byte v21, v10, v15

    const/16 v6, 0x3a

    aput-byte v6, v10, v3

    const/16 v6, -0x19

    aput-byte v6, v10, v5

    const/16 v6, 0x1a

    aput-byte v6, v10, v20

    const/16 v6, -0x69

    const/16 v16, 0xb

    aput-byte v6, v10, v16

    new-array v6, v3, [B

    const/16 v24, 0x14

    aput-byte v24, v6, v1

    const/16 v24, -0x7c

    aput-byte v24, v6, v8

    aput-byte v7, v6, v9

    const/4 v7, -0x6

    aput-byte v7, v6, v11

    const/16 v7, -0x51

    aput-byte v7, v6, v12

    const/16 v7, -0x40

    aput-byte v7, v6, v13

    const/16 v7, -0x6d

    aput-byte v7, v6, v14

    const/16 v7, 0x2c

    aput-byte v7, v6, v15

    invoke-static {v10, v6}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v6

    aput-object v6, v4, v3

    const/16 v6, 0xb

    new-array v7, v6, [B

    const/16 v6, -0x45

    aput-byte v6, v7, v1

    const/16 v6, -0xe

    aput-byte v6, v7, v8

    const/16 v6, 0x72

    aput-byte v6, v7, v9

    const/16 v6, -0x33

    aput-byte v6, v7, v11

    const/16 v6, -0x76

    aput-byte v6, v7, v12

    const/16 v6, -0x46

    aput-byte v6, v7, v13

    const/16 v6, -0x74

    aput-byte v6, v7, v14

    const/16 v6, 0x54

    aput-byte v6, v7, v15

    const/16 v6, -0x46

    aput-byte v6, v7, v3

    const/4 v6, -0x4

    aput-byte v6, v7, v5

    const/16 v6, 0x70

    aput-byte v6, v7, v20

    new-array v6, v3, [B

    const/16 v10, -0x27

    aput-byte v10, v6, v1

    const/16 v10, -0x6d

    aput-byte v10, v6, v8

    const/16 v10, 0x1d

    aput-byte v10, v6, v9

    const/16 v10, -0x55

    aput-byte v10, v6, v11

    const/16 v10, -0x11

    aput-byte v10, v6, v12

    const/16 v10, -0x2c

    aput-byte v10, v6, v13

    const/16 v10, -0x15

    aput-byte v10, v6, v14

    const/16 v10, 0x7a

    aput-byte v10, v6, v15

    invoke-static {v7, v6}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v6

    aput-object v6, v4, v5

    new-array v6, v3, [B

    const/16 v7, 0x43

    aput-byte v7, v6, v1

    const/16 v7, -0x47

    aput-byte v7, v6, v8

    const/16 v7, -0x75

    aput-byte v7, v6, v9

    const/16 v7, 0x59

    aput-byte v7, v6, v11

    const/16 v7, 0x30

    aput-byte v7, v6, v12

    const/16 v7, -0x56

    aput-byte v7, v6, v13

    const/16 v7, 0x79

    aput-byte v7, v6, v14

    const/16 v7, -0x2d

    aput-byte v7, v6, v15

    new-array v7, v3, [B

    const/16 v10, 0x33

    aput-byte v10, v7, v1

    const/16 v10, -0x37

    aput-byte v10, v7, v8

    const/4 v10, -0x1

    aput-byte v10, v7, v9

    const/16 v10, 0x2f

    aput-byte v10, v7, v11

    const/16 v10, 0x1e

    aput-byte v10, v7, v12

    const/16 v10, -0x37

    aput-byte v10, v7, v13

    const/16 v10, 0x16

    aput-byte v10, v7, v14

    const/16 v10, -0x42

    aput-byte v10, v7, v15

    invoke-static {v6, v7}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v6

    aput-object v6, v4, v20

    const/4 v6, 0x0

    :goto_349
    const/16 v7, 0xb

    if-ge v6, v7, :cond_4d9

    aget-object v7, v4, v6

    invoke-virtual {v2, v7}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v7

    if-eqz v7, :cond_4cb

    new-array v7, v5, [B

    const/16 v10, 0x41

    aput-byte v10, v7, v1

    const/16 v10, 0x55

    aput-byte v10, v7, v8

    const/16 v10, 0x5a

    aput-byte v10, v7, v9

    const/16 v10, -0x44

    aput-byte v10, v7, v11

    const/16 v10, -0x42

    aput-byte v10, v7, v12

    const/16 v10, 0x7a

    aput-byte v10, v7, v13

    const/16 v10, -0x4b

    aput-byte v10, v7, v14

    const/16 v10, 0x51

    aput-byte v10, v7, v15

    aput-byte v21, v7, v3

    new-array v10, v3, [B

    const/16 v19, 0x28

    aput-byte v19, v10, v1

    const/16 v19, 0x24

    aput-byte v19, v10, v8

    const/16 v19, 0x33

    aput-byte v19, v10, v9

    const/16 v19, -0x3b

    aput-byte v19, v10, v11

    const/16 v19, -0x29

    aput-byte v19, v10, v12

    const/16 v19, 0x54

    aput-byte v19, v10, v13

    const/16 v19, -0x2a

    aput-byte v19, v10, v14

    const/16 v19, 0x3e

    aput-byte v19, v10, v15

    invoke-static {v7, v10}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v7

    aget-object v10, v4, v6

    invoke-virtual {v7, v10}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v7

    if-eqz v7, :cond_4c9

    const/16 v7, 0xc

    new-array v10, v7, [B

    const/16 v7, -0x38

    aput-byte v7, v10, v1

    aput-byte v18, v10, v8

    const/16 v7, -0x18

    aput-byte v7, v10, v9

    const/16 v7, 0x4e

    aput-byte v7, v10, v11

    const/16 v7, 0x29

    aput-byte v7, v10, v12

    const/16 v19, -0x3e

    aput-byte v19, v10, v13

    const/16 v19, 0x74

    aput-byte v19, v10, v14

    const/16 v19, -0x18

    aput-byte v19, v10, v15

    const/16 v19, -0x34

    aput-byte v19, v10, v3

    const/16 v19, -0x3e

    aput-byte v19, v10, v5

    const/16 v19, -0x20

    aput-byte v19, v10, v20

    const/16 v19, 0x68

    const/16 v16, 0xb

    aput-byte v19, v10, v16

    new-array v7, v3, [B

    const/16 v19, -0x5f

    aput-byte v19, v7, v1

    aput-byte v23, v7, v8

    const/16 v19, -0x7f

    aput-byte v19, v7, v9

    const/16 v19, 0x37

    aput-byte v19, v7, v11

    const/16 v19, 0x40

    aput-byte v19, v7, v12

    const/16 v19, -0x14

    aput-byte v19, v7, v13

    const/16 v19, 0x17

    aput-byte v19, v7, v14

    const/16 v19, -0x79

    aput-byte v19, v7, v15

    invoke-static {v10, v7}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v0, v7}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v7

    if-nez v7, :cond_4c9

    const/16 v7, 0xc

    new-array v10, v7, [B

    const/16 v7, -0x3b

    aput-byte v7, v10, v1

    const/16 v7, 0x52

    aput-byte v7, v10, v8

    const/16 v7, -0x77

    aput-byte v7, v10, v9

    const/16 v7, 0x64

    aput-byte v7, v10, v11

    const/16 v7, 0x5f

    aput-byte v7, v10, v12

    const/16 v7, 0x72

    aput-byte v7, v10, v13

    const/16 v7, 0x2d

    aput-byte v7, v10, v14

    const/16 v7, -0x1a

    aput-byte v7, v10, v15

    const/16 v7, -0x3f

    aput-byte v7, v10, v3

    const/16 v7, 0xc

    aput-byte v7, v10, v5

    const/16 v7, -0x69

    aput-byte v7, v10, v20

    const/16 v7, 0x42

    const/16 v16, 0xb

    aput-byte v7, v10, v16

    new-array v7, v3, [B

    const/16 v19, -0x54

    aput-byte v19, v7, v1

    const/16 v19, 0x23

    aput-byte v19, v7, v8

    const/16 v19, -0x20

    aput-byte v19, v7, v9

    const/16 v19, 0x1d

    aput-byte v19, v7, v11

    const/16 v19, 0x36

    aput-byte v19, v7, v12

    const/16 v19, 0x5c

    aput-byte v19, v7, v13

    const/16 v19, 0x4e

    aput-byte v19, v7, v14

    const/16 v17, -0x77

    aput-byte v17, v7, v15

    invoke-static {v10, v7}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v0, v7}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v7

    if-nez v7, :cond_4c9

    const/16 v7, 0xc

    new-array v10, v7, [B

    const/16 v19, -0x5f

    aput-byte v19, v10, v1

    const/16 v19, 0x47

    aput-byte v19, v10, v8

    const/16 v19, -0x43

    aput-byte v19, v10, v9

    const/16 v19, -0x23

    aput-byte v19, v10, v11

    const/16 v19, -0x2f

    aput-byte v19, v10, v12

    const/16 v19, 0x13

    aput-byte v19, v10, v13

    const/16 v19, -0x60

    aput-byte v19, v10, v14

    const/16 v19, 0x2d

    aput-byte v19, v10, v15

    const/16 v19, -0x5b

    aput-byte v19, v10, v3

    const/16 v19, 0x19

    aput-byte v19, v10, v5

    const/16 v19, -0x5e

    aput-byte v19, v10, v20

    const/16 v19, -0x5

    const/16 v16, 0xb

    aput-byte v19, v10, v16

    new-array v5, v3, [B

    const/16 v22, -0x38

    aput-byte v22, v5, v1

    const/16 v22, 0x36

    aput-byte v22, v5, v8

    const/16 v22, -0x2c

    aput-byte v22, v5, v9

    const/16 v22, -0x5c

    aput-byte v22, v5, v11

    const/16 v22, -0x48

    aput-byte v22, v5, v12

    const/16 v22, 0x3d

    aput-byte v22, v5, v13

    const/16 v22, -0x3d

    aput-byte v22, v5, v14

    const/16 v22, 0x42

    aput-byte v22, v5, v15

    invoke-static {v10, v5}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v0, v5}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v5
    :try_end_4c7
    .catch Ljava/lang/Exception; {:try_start_3 .. :try_end_4c7} :catch_4d9

    if-eqz v5, :cond_4d3

    :cond_4c9
    const/4 v1, 0x1

    goto :goto_4d9

    :cond_4cb
    const/16 v7, 0xc

    const/16 v16, 0xb

    const/16 v17, -0x77

    const/16 v22, 0x42

    :cond_4d3
    add-int/lit8 v6, v6, 0x1

    const/16 v5, 0x9

    goto/16 :goto_349

    :catch_4d9
    :cond_4d9
    :goto_4d9
    return v1
.end method

.method public static c(Ljava/lang/String;Ljava/lang/String;)Lorg/json/JSONObject;
    .registers 14

    new-instance v0, Lorg/json/JSONObject;

    invoke-direct {v0, p1}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    const/4 p1, 0x4

    new-array v1, p1, [B

    fill-array-data v1, :array_2ba

    const/16 v2, 0x8

    new-array v3, v2, [B

    fill-array-data v3, :array_2c0

    invoke-static {v1, v3}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Lorg/json/JSONObject;->has(Ljava/lang/String;)Z

    move-result v1

    const/4 v3, 0x3

    if-eqz v1, :cond_42

    new-array v1, p1, [B

    fill-array-data v1, :array_2c8

    new-array v4, v2, [B

    fill-array-data v4, :array_2ce

    invoke-static {v1, v4}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Lorg/json/JSONObject;->getJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v1

    new-array v4, v3, [B

    fill-array-data v4, :array_2d6

    new-array v5, v2, [B

    fill-array-data v5, :array_2dc

    invoke-static {v4, v5}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v1, v4}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    goto :goto_54

    :cond_42
    new-array v1, v3, [B

    fill-array-data v1, :array_2e4

    new-array v4, v2, [B

    fill-array-data v4, :array_2ea

    invoke-static {v1, v4}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    :goto_54
    const/4 v4, 0x2

    new-array v4, v4, [B

    fill-array-data v4, :array_2f2

    new-array v5, v2, [B

    fill-array-data v5, :array_2f8

    invoke-static {v4, v5}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v1, v4}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v4

    const/4 v5, 0x6

    if-eqz v4, :cond_7d

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    new-array v6, v5, [B

    fill-array-data v6, :array_300

    new-array v7, v2, [B

    fill-array-data v7, :array_308

    .line 1
    invoke-static {v6, v7, v4, v1}, Lcom/github/catvod/spider/appysv2/b/u;->a([B[BLjava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    :cond_7d
    new-array p1, p1, [B

    .line 2
    fill-array-data p1, :array_310

    new-array v4, v2, [B

    fill-array-data v4, :array_316

    invoke-static {p1, v4}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v1, p1}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result p1

    const/4 v4, 0x0

    if-nez p1, :cond_93

    return-object v4

    :cond_93
    invoke-virtual {v1, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    const/4 v6, 0x0

    const/4 v7, 0x7

    if-eqz p1, :cond_db

    invoke-static {v1}, Lcom/github/catvod/spider/appysv2/p/e;->b(Ljava/lang/String;)Z

    move-result p1

    if-nez p1, :cond_da

    .line 3
    sget-object p1, Lcom/github/catvod/spider/appysv2/p/e;->a:Ljava/util/regex/Pattern;

    invoke-virtual {p1, v1}, Ljava/util/regex/Pattern;->matcher(Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;

    move-result-object p1

    invoke-virtual {p1}, Ljava/util/regex/Matcher;->find()Z

    move-result p1

    if-eqz p1, :cond_d7

    new-array p1, v7, [B

    fill-array-data p1, :array_31e

    new-array v8, v2, [B

    fill-array-data v8, :array_326

    invoke-static {p1, v8}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v1, p1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result p1

    if-eqz p1, :cond_d5

    new-array p1, v3, [B

    fill-array-data p1, :array_32e

    new-array v8, v2, [B

    fill-array-data v8, :array_334

    invoke-static {p1, v8}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v1, p1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result p1

    if-nez p1, :cond_d7

    :cond_d5
    const/4 p1, 0x1

    goto :goto_d8

    :cond_d7
    const/4 p1, 0x0

    :goto_d8
    if-nez p1, :cond_db

    :cond_da
    return-object v4

    :cond_db
    const/16 p1, 0xa

    new-array v8, p1, [B

    .line 4
    fill-array-data v8, :array_33c

    new-array v9, v2, [B

    fill-array-data v9, :array_346

    invoke-static {v8, v9}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v1, v8}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v8

    if-nez v8, :cond_106

    const/4 v8, 0x5

    new-array v8, v8, [B

    fill-array-data v8, :array_34e

    new-array v9, v2, [B

    fill-array-data v9, :array_356

    invoke-static {v8, v9}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v1, v8}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v8

    if-eqz v8, :cond_107

    :cond_106
    const/4 v6, 0x1

    :cond_107
    if-eqz v6, :cond_10a

    return-object v4

    .line 5
    :cond_10a
    new-instance v4, Lorg/json/JSONObject;

    invoke-direct {v4}, Lorg/json/JSONObject;-><init>()V

    new-array v6, p1, [B

    fill-array-data v6, :array_35e

    new-array v8, v2, [B

    fill-array-data v8, :array_368

    invoke-static {v6, v8}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v6

    const-string v8, ""

    invoke-virtual {v0, v6, v8}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v9}, Ljava/lang/String;->length()I

    move-result v9

    const-string v10, "67"

    invoke-static {v10}, Lcom/github/catvod/spider/appysv2/KKB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    if-lez v9, :cond_153

    new-array v9, p1, [B

    fill-array-data v9, :array_370

    new-array v11, v2, [B

    fill-array-data v11, :array_37a

    invoke-static {v9, v11}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v9

    new-instance v11, Ljava/lang/StringBuilder;

    invoke-direct {v11}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v11, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v11, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v11}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v4, v9, v6}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    :cond_153
    new-array v6, v7, [B

    fill-array-data v6, :array_382

    new-array v9, v2, [B

    fill-array-data v9, :array_38a

    invoke-static {v6, v9}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v0, v6, v8}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/String;->length()I

    move-result v6

    if-lez v6, :cond_18f

    new-array v6, v7, [B

    fill-array-data v6, :array_392

    new-array v8, v2, [B

    fill-array-data v8, :array_39a

    invoke-static {v6, v8}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v6

    new-instance v8, Ljava/lang/StringBuilder;

    invoke-direct {v8}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v8, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v8, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v8}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v4, v6, v0}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    :cond_18f
    const/16 v0, 0xc

    new-array v6, v0, [B

    .line 6
    fill-array-data v6, :array_3a2

    new-array v8, v2, [B

    fill-array-data v8, :array_3ac

    invoke-static {v6, v8}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {p0, v6}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v6

    if-eqz v6, :cond_1d4

    new-array p0, v7, [B

    fill-array-data p0, :array_3b4

    new-array v6, v2, [B

    fill-array-data v6, :array_3bc

    invoke-static {p0, v6}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object p0

    invoke-virtual {v4, p0, v10}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    new-array p0, p1, [B

    fill-array-data p0, :array_3c4

    new-array p1, v2, [B

    fill-array-data p1, :array_3ce

    invoke-static {p0, p1}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object p0

    new-array p1, v0, [B

    fill-array-data p1, :array_3d6

    new-array v0, v2, [B

    fill-array-data v0, :array_3e0

    invoke-static {p1, v0}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object p1

    goto/16 :goto_28e

    :cond_1d4
    new-array v6, p1, [B

    fill-array-data v6, :array_3e8

    new-array v8, v2, [B

    fill-array-data v8, :array_3f2

    invoke-static {v6, v8}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v1, v6}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v6

    if-eqz v6, :cond_216

    new-array p0, v7, [B

    fill-array-data p0, :array_3fa

    new-array v6, v2, [B

    fill-array-data v6, :array_402

    invoke-static {p0, v6}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object p0

    invoke-virtual {v4, p0, v10}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    new-array p0, p1, [B

    fill-array-data p0, :array_40a

    new-array p1, v2, [B

    fill-array-data p1, :array_414

    invoke-static {p0, p1}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object p0

    new-array p1, v0, [B

    fill-array-data p1, :array_41c

    new-array v0, v2, [B

    fill-array-data v0, :array_426

    invoke-static {p1, v0}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object p1

    goto :goto_28e

    :cond_216
    new-array v0, v2, [B

    fill-array-data v0, :array_42e

    new-array v6, v2, [B

    fill-array-data v6, :array_436

    invoke-static {v0, v6}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p0, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    if-eqz v0, :cond_26a

    new-array p0, v7, [B

    fill-array-data p0, :array_43e

    new-array v0, v2, [B

    fill-array-data v0, :array_446

    invoke-static {p0, v0}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object p0

    const/16 v0, 0x1a

    new-array v0, v0, [B

    fill-array-data v0, :array_44e

    new-array v6, v2, [B

    fill-array-data v6, :array_460

    invoke-static {v0, v6}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v4, p0, v0}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    new-array p0, p1, [B

    fill-array-data p0, :array_468

    new-array p1, v2, [B

    fill-array-data p1, :array_472

    invoke-static {p0, p1}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object p0

    const/16 p1, 0x73

    new-array p1, p1, [B

    fill-array-data p1, :array_47a

    new-array v0, v2, [B

    fill-array-data v0, :array_4b8

    invoke-static {p1, v0}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object p1

    goto :goto_28e

    :cond_26a
    new-array v0, v7, [B

    fill-array-data v0, :array_4c0

    new-array v6, v2, [B

    fill-array-data v6, :array_4c8

    invoke-static {v0, v6}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p0, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result p0

    if-eqz p0, :cond_291

    new-array p0, p1, [B

    fill-array-data p0, :array_4d0

    new-array p1, v2, [B

    fill-array-data p1, :array_4da

    invoke-static {p0, p1}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object p0

    sget-object p1, Lcom/github/catvod/spider/appysv2/p/e;->b:Ljava/lang/String;

    :goto_28e
    invoke-virtual {v4, p0, p1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 7
    :cond_291
    new-instance p0, Lorg/json/JSONObject;

    invoke-direct {p0}, Lorg/json/JSONObject;-><init>()V

    new-array p1, v5, [B

    fill-array-data p1, :array_4e2

    new-array v0, v2, [B

    fill-array-data v0, :array_4ea

    invoke-static {p1, v0}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p0, p1, v4}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    new-array p1, v3, [B

    fill-array-data p1, :array_4f2

    new-array v0, v2, [B

    fill-array-data v0, :array_4f8

    invoke-static {p1, v0}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p0, p1, v1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    return-object p0

    nop

    :array_2ba
    .array-data 1
        -0x57t
        -0x7et
        -0x32t
        -0x1at
    .end array-data

    :array_2c0
    .array-data 1
        -0x33t
        -0x1dt
        -0x46t
        -0x79t
        0x52t
        0x4ct
        0x4bt
        0x6et
    .end array-data

    :array_2c8
    .array-data 1
        0x4at
        -0x7t
        0x48t
        -0x6ft
    .end array-data

    :array_2ce
    .array-data 1
        0x2et
        -0x68t
        0x3ct
        -0x10t
        -0x62t
        0x50t
        0x5ft
        -0x2et
    .end array-data

    :array_2d6
    .array-data 1
        -0xat
        -0x55t
        -0x3t
    .end array-data

    :array_2dc
    .array-data 1
        -0x7dt
        -0x27t
        -0x6ft
        -0x3at
        0x51t
        -0x5at
        0x2et
        -0x13t
    .end array-data

    :array_2e4
    .array-data 1
        0x14t
        -0x7ct
        0x2bt
    .end array-data

    :array_2ea
    .array-data 1
        0x61t
        -0xat
        0x47t
        -0x36t
        0x6et
        -0x20t
        -0x66t
        -0x58t
    .end array-data

    :array_2f2
    .array-data 1
        0x56t
        -0x3dt
    .end array-data

    nop

    :array_2f8
    .array-data 1
        0x79t
        -0x14t
        0x5dt
        -0x1at
        0x7et
        -0x2at
        -0x1bt
        0x73t
    .end array-data

    :array_300
    .array-data 1
        0x6ct
        0x7bt
        0x10t
        -0x6et
        -0x4ft
        0x46t
    .end array-data

    nop

    :array_308
    .array-data 1
        0x4t
        0xft
        0x64t
        -0x1et
        -0x3et
        0x7ct
        0x50t
        0x58t
    .end array-data

    :array_310
    .array-data 1
        -0x34t
        0x4t
        -0x37t
        0x1at
    .end array-data

    :array_316
    .array-data 1
        -0x5ct
        0x70t
        -0x43t
        0x6at
        -0xct
        0x9t
        -0x51t
        0x79t
    .end array-data

    :array_31e
    .array-data 1
        0x4ct
        0x75t
        0x0t
        -0x5ct
        0x50t
        0x7ct
        0x1et
    .end array-data

    :array_326
    .array-data 1
        0x2ft
        0x11t
        0x6et
        -0x77t
        0x24t
        0x13t
        0x6dt
        0xet
    .end array-data

    :array_32e
    .array-data 1
        0x1dt
        0x78t
        0x13t
    .end array-data

    :array_334
    .array-data 1
        0x33t
        0x12t
        0x60t
        -0x18t
        -0x51t
        0x3bt
        0x2at
        0x76t
    .end array-data

    :array_33c
    .array-data 1
        0x2at
        -0x46t
        0x6ct
        -0x6dt
        -0x55t
        -0x74t
        0x49t
        -0x27t
        0x6at
        -0x9t
    .end array-data

    nop

    :array_346
    .array-data 1
        0x13t
        -0x73t
        0x5ft
        -0x56t
        -0x64t
        -0x41t
        0x67t
        -0x5ft
    .end array-data

    :array_34e
    .array-data 1
        0x11t
        0x73t
        -0x6dt
        0x5at
        -0x4ct
    .end array-data

    nop

    :array_356
    .array-data 1
        0x3ft
        0x15t
        -0x6t
        0x2et
        -0x72t
        0x1at
        -0x48t
        0x65t
    .end array-data

    :array_35e
    .array-data 1
        0x45t
        0x1t
        -0x1ct
        0x26t
        -0x29t
        -0x2et
        -0xft
        0x65t
        0x5et
        0x6t
    .end array-data

    nop

    :array_368
    .array-data 1
        0x30t
        0x72t
        -0x7ft
        0x54t
        -0x6t
        -0x4dt
        -0x6at
        0x0t
    .end array-data

    :array_370
    .array-data 1
        -0x60t
        -0x56t
        -0x61t
        0x78t
        0xdt
        -0x68t
        -0x46t
        -0x7at
        -0x65t
        -0x53t
    .end array-data

    nop

    :array_37a
    .array-data 1
        -0xbt
        -0x27t
        -0x6t
        0xat
        0x20t
        -0x27t
        -0x23t
        -0x1dt
    .end array-data

    :array_382
    .array-data 1
        -0x3t
        -0x6t
        -0x27t
        0x35t
        0x22t
        0x3dt
        -0x27t
    .end array-data

    :array_38a
    .array-data 1
        -0x71t
        -0x61t
        -0x41t
        0x50t
        0x50t
        0x58t
        -0x55t
        0x4dt
    .end array-data

    :array_392
    .array-data 1
        -0x5at
        -0x63t
        -0x6ft
        0x2t
        -0x12t
        -0x14t
        0x72t
    .end array-data

    :array_39a
    .array-data 1
        -0xct
        -0x8t
        -0x9t
        0x67t
        -0x64t
        -0x77t
        0x0t
        -0x2ft
    .end array-data

    :array_3a2
    .array-data 1
        0x65t
        -0x74t
        -0x25t
        -0x3bt
        0x4et
        -0x36t
        -0x1t
        0x66t
        0x3ct
        -0x68t
        -0x3dt
        -0x7at
    .end array-data

    :array_3ac
    .array-data 1
        0x12t
        -0x5t
        -0x54t
        -0x15t
        0x23t
        -0x53t
        -0x75t
        0x10t
    .end array-data

    :array_3b4
    .array-data 1
        -0x3dt
        -0x22t
        0x1t
        -0x4dt
        0x5t
        -0x52t
        0x33t
    .end array-data

    :array_3bc
    .array-data 1
        -0x6ft
        -0x45t
        0x67t
        -0x2at
        0x77t
        -0x35t
        0x41t
        -0x1et
    .end array-data

    :array_3c4
    .array-data 1
        -0x3et
        -0x1et
        -0x6t
        -0x63t
        0x23t
        -0x5et
        0x49t
        0x6dt
        -0x7t
        -0x1bt
    .end array-data

    nop

    :array_3ce
    .array-data 1
        -0x69t
        -0x6ft
        -0x61t
        -0x11t
        0xet
        -0x1dt
        0x2et
        0x8t
    .end array-data

    :array_3d6
    .array-data 1
        0x54t
        -0x3et
        -0x22t
        0x35t
        -0x20t
        0x6dt
        0x43t
        -0x77t
        0x5bt
        -0x46t
        -0x61t
        0x7ft
    .end array-data

    :array_3e0
    .array-data 1
        0x74t
        -0x71t
        -0x4ft
        0x4ft
        -0x77t
        0x1t
        0x2ft
        -0x18t
    .end array-data

    :array_3e8
    .array-data 1
        0x77t
        0x3at
        0x1bt
        0x76t
        0x4t
        -0x5at
        0x5at
        -0x67t
        0x77t
        0x25t
    .end array-data

    nop

    :array_3f2
    .array-data 1
        0x3t
        0x53t
        0x6ft
        0x17t
        0x6at
        -0x78t
        0x37t
        -0x2t
    .end array-data

    :array_3fa
    .array-data 1
        0x4at
        -0x46t
        -0x24t
        -0x1bt
        -0x65t
        0x6at
        -0x21t
    .end array-data

    :array_402
    .array-data 1
        0x18t
        -0x21t
        -0x46t
        -0x80t
        -0x17t
        0xft
        -0x53t
        -0x2ct
    .end array-data

    :array_40a
    .array-data 1
        0x7ct
        0x4et
        0x61t
        -0xbt
        -0x61t
        -0x67t
        0x6dt
        -0x58t
        0x47t
        0x49t
    .end array-data

    nop

    :array_414
    .array-data 1
        0x29t
        0x3dt
        0x4t
        -0x79t
        -0x4et
        -0x28t
        0xat
        -0x33t
    .end array-data

    :array_41c
    .array-data 1
        -0x14t
        -0x43t
        0x61t
        -0x18t
        -0x37t
        -0x3ft
        0xat
        -0x58t
        -0x1dt
        -0x3bt
        0x20t
        -0x5et
    .end array-data

    :array_426
    .array-data 1
        -0x34t
        -0x10t
        0xet
        -0x6et
        -0x60t
        -0x53t
        0x66t
        -0x37t
    .end array-data

    :array_42e
    .array-data 1
        0x1ct
        -0x27t
        0x58t
        0x23t
        -0x34t
        -0x23t
        0x7at
        -0x7ft
    .end array-data

    :array_436
    .array-data 1
        0x7et
        -0x50t
        0x34t
        0x4at
        -0x52t
        -0x4ct
        0x16t
        -0x18t
    .end array-data

    :array_43e
    .array-data 1
        -0x4et
        -0x7dt
        0x54t
        0x5ct
        -0x29t
        0x74t
        -0x1ct
    .end array-data

    :array_446
    .array-data 1
        -0x20t
        -0x1at
        0x32t
        0x39t
        -0x5bt
        0x11t
        -0x6at
        -0x51t
    .end array-data

    :array_44e
    .array-data 1
        -0x2t
        -0x46t
        -0x1ft
        0x30t
        0x45t
        -0x68t
        0xat
        0x30t
        -0xft
        -0x5bt
        -0x1et
        0x33t
        0x1bt
        -0x77t
        0x59t
        0x73t
        -0x49t
        -0x50t
        -0x4t
        0x28t
        0x5ct
        -0x3bt
        0x53t
        0x70t
        -0x4dt
        -0x3t
    .end array-data

    nop

    :array_460
    .array-data 1
        -0x22t
        -0x2et
        -0x6bt
        0x44t
        0x35t
        -0x15t
        0x30t
        0x1ft
    .end array-data

    :array_468
    .array-data 1
        -0x1t
        -0x5t
        0x5dt
        -0x41t
        0x58t
        -0x11t
        -0x1ct
        0x4dt
        -0x3ct
        -0x4t
    .end array-data

    nop

    :array_472
    .array-data 1
        -0x56t
        -0x78t
        0x38t
        -0x33t
        0x75t
        -0x52t
        -0x7dt
        0x28t
    .end array-data

    :array_47a
    .array-data 1
        -0x20t
        -0x73t
        0x21t
        -0x24t
        -0x59t
        0x7ft
        0x71t
        -0x76t
        -0x11t
        -0xbt
        0x60t
        -0x6at
        -0x12t
        0x3bt
        0x4at
        -0x7et
        -0x52t
        -0x5ct
        0x21t
        -0x2ft
        -0x43t
        0x33t
        0x53t
        -0x41t
        -0x20t
        -0xft
        0x7et
        -0x78t
        -0x2t
        0x28t
        0x3dt
        -0x44t
        -0x57t
        -0x52t
        0x78t
        -0x6et
        -0xbt
        0x33t
        0x65t
        -0x23t
        -0xct
        -0x17t
        0x6et
        -0x19t
        -0x42t
        0x63t
        0x71t
        -0x72t
        -0x69t
        -0x5bt
        0x2ct
        -0x13t
        -0x59t
        0x67t
        0x32t
        -0x22t
        -0xdt
        -0x9t
        0x60t
        -0x6bt
        -0x8t
        0x33t
        0x35t
        -0x60t
        -0x78t
        -0x6ct
        0x3t
        -0x16t
        -0x1et
        0x33t
        0x71t
        -0x7et
        -0x55t
        -0x5bt
        0x6et
        -0x1ft
        -0x55t
        0x70t
        0x76t
        -0x7ct
        -0x17t
        -0x20t
        0xdt
        -0x32t
        -0x44t
        0x7ct
        0x70t
        -0x72t
        -0x11t
        -0x7t
        0x7at
        -0x78t
        -0x2t
        0x3dt
        0x29t
        -0x23t
        -0x10t
        -0xat
        0x60t
        -0x6dt
        -0x6t
        0x33t
        0x4et
        -0x76t
        -0x5at
        -0x5ft
        0x3ct
        -0x31t
        -0x1ft
        0x26t
        0x2et
        -0x24t
        -0x12t
        -0xdt
        0x78t
    .end array-data

    :array_4b8
    .array-data 1
        -0x40t
        -0x40t
        0x4et
        -0x5at
        -0x32t
        0x13t
        0x1dt
        -0x15t
    .end array-data

    :array_4c0
    .array-data 1
        0x3ct
        -0x6dt
        0x26t
        -0x26t
        0x20t
        -0x73t
        -0x21t
    .end array-data

    :array_4c8
    .array-data 1
        0x51t
        -0x4t
        0x47t
        -0x43t
        0x45t
        -0x1dt
        -0x55t
        0x11t
    .end array-data

    :array_4d0
    .array-data 1
        -0x3ct
        0x58t
        0x1t
        -0x37t
        0x6bt
        -0x3bt
        0x2et
        0x10t
        -0x1t
        0x5ft
    .end array-data

    nop

    :array_4da
    .array-data 1
        -0x6ft
        0x2bt
        0x64t
        -0x45t
        0x46t
        -0x7ct
        0x49t
        0x75t
    .end array-data

    :array_4e2
    .array-data 1
        0x6ct
        -0x58t
        -0x5t
        0x39t
        -0x75t
        0x2t
    .end array-data

    nop

    :array_4ea
    .array-data 1
        0x4t
        -0x33t
        -0x66t
        0x5dt
        -0x12t
        0x70t
        -0x6t
        -0xet
    .end array-data

    :array_4f2
    .array-data 1
        0xdt
        0x24t
        -0x1bt
    .end array-data

    :array_4f8
    .array-data 1
        0x78t
        0x56t
        -0x77t
        -0x6at
        -0x6ft
        -0x73t
        0x18t
        0x52t
    .end array-data
.end method
