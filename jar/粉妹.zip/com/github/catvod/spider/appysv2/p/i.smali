.class final Lcom/github/catvod/spider/appysv2/p/i;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field static volatile a:Lcom/github/catvod/spider/appysv2/p/j;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    new-instance v0, Lcom/github/catvod/spider/appysv2/p/j;

    invoke-direct {v0}, Lcom/github/catvod/spider/appysv2/p/j;-><init>()V

    sput-object v0, Lcom/github/catvod/spider/appysv2/p/i;->a:Lcom/github/catvod/spider/appysv2/p/j;

    return-void
.end method
