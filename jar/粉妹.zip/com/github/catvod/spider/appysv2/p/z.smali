.class public final synthetic Lcom/github/catvod/spider/appysv2/p/z;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Ljava/lang/Object;

.field public final synthetic c:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(Ljava/lang/Object;Ljava/lang/Object;I)V
    .registers 4

    iput p3, p0, Lcom/github/catvod/spider/appysv2/p/z;->a:I

    iput-object p1, p0, Lcom/github/catvod/spider/appysv2/p/z;->b:Ljava/lang/Object;

    iput-object p2, p0, Lcom/github/catvod/spider/appysv2/p/z;->c:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 3

    iget v0, p0, Lcom/github/catvod/spider/appysv2/p/z;->a:I

    packed-switch v0, :pswitch_data_36

    goto :goto_2a

    :pswitch_6  #0x2
    iget-object v0, p0, Lcom/github/catvod/spider/appysv2/p/z;->b:Ljava/lang/Object;

    check-cast v0, Lcom/github/catvod/spider/appysv2/p/B;

    iget-object v1, p0, Lcom/github/catvod/spider/appysv2/p/z;->c:Ljava/lang/Object;

    check-cast v1, Ljava/util/Map;

    .line 1
    invoke-virtual {v0, v1}, Lcom/github/catvod/spider/appysv2/p/B;->x(Ljava/util/Map;)V

    return-void

    .line 2
    :pswitch_12  #0x1
    iget-object v0, p0, Lcom/github/catvod/spider/appysv2/p/z;->b:Ljava/lang/Object;

    check-cast v0, Lcom/github/catvod/spider/appysv2/p/B;

    iget-object v1, p0, Lcom/github/catvod/spider/appysv2/p/z;->c:Ljava/lang/Object;

    check-cast v1, Ljava/util/Map;

    .line 3
    invoke-virtual {v0, v1}, Lcom/github/catvod/spider/appysv2/p/B;->x(Ljava/util/Map;)V

    return-void

    .line 4
    :pswitch_1e  #0x0
    iget-object v0, p0, Lcom/github/catvod/spider/appysv2/p/z;->b:Ljava/lang/Object;

    check-cast v0, Lcom/github/catvod/spider/appysv2/p/B;

    iget-object v1, p0, Lcom/github/catvod/spider/appysv2/p/z;->c:Ljava/lang/Object;

    check-cast v1, Ljava/util/Map;

    invoke-static {v0, v1}, Lcom/github/catvod/spider/appysv2/p/B;->j(Lcom/github/catvod/spider/appysv2/p/B;Ljava/util/Map;)V

    return-void

    :goto_2a
    iget-object v0, p0, Lcom/github/catvod/spider/appysv2/p/z;->b:Ljava/lang/Object;

    check-cast v0, Lcom/github/catvod/spider/appysv2/b/U;

    iget-object v1, p0, Lcom/github/catvod/spider/appysv2/p/z;->c:Ljava/lang/Object;

    check-cast v1, Ljava/lang/String;

    invoke-static {v0, v1}, Lcom/github/catvod/spider/appysv2/b/U;->d(Lcom/github/catvod/spider/appysv2/b/U;Ljava/lang/String;)V

    return-void

    :pswitch_data_36
    .packed-switch 0x0
        :pswitch_1e  #00000000
        :pswitch_12  #00000001
        :pswitch_6  #00000002
    .end packed-switch
.end method
