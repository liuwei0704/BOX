.class public final Lcom/github/catvod/spider/appysv2/p/k;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field private static final a:Ljava/lang/String;


# direct methods
.method static constructor <clinit>()V
    .registers 2

    const/16 v0, 0x1e

    new-array v0, v0, [B

    fill-array-data v0, :array_16

    const/16 v1, 0x8

    new-array v1, v1, [B

    fill-array-data v1, :array_2a

    invoke-static {v0, v1}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lcom/github/catvod/spider/appysv2/p/k;->a:Ljava/lang/String;

    return-void

    nop

    :array_16
    .array-data 1
        -0x72t
        0x7t
        0x5et
        -0x75t
        -0x23t
        0x64t
        0x56t
        -0x49t
        -0x79t
        0x3t
        0x43t
        -0x2bt
        -0x40t
        0x30t
        0x57t
        -0x5t
        -0x71t
        0x5ct
        0x45t
        -0x68t
        -0x24t
        0x71t
        0x1bt
        -0x52t
        -0x2et
        0x5ct
        0x5et
        -0x62t
        -0x2at
        0x2at
    .end array-data

    nop

    :array_2a
    .array-data 1
        -0x1at
        0x73t
        0x2at
        -0x5t
        -0x52t
        0x5et
        0x79t
        -0x68t
    .end array-data
.end method

.method public static a(Ljava/lang/String;Ljava/util/Map;)Ljava/lang/String;
    .registers 21
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;)",
            "Ljava/lang/String;"
        }
    .end annotation

    const/4 v0, 0x0

    const-string v1, ""

    move-object v2, v1

    const/4 v3, 0x0

    :goto_5
    :try_start_5
    invoke-virtual {v2, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_10b

    const/4 v4, 0x3

    if-ge v3, v4, :cond_10b

    new-instance v5, Ljava/net/URL;

    move-object/from16 v6, p0

    invoke-direct {v5, v6}, Ljava/net/URL;-><init>(Ljava/lang/String;)V

    invoke-virtual {v5}, Ljava/net/URL;->openConnection()Ljava/net/URLConnection;

    move-result-object v5

    check-cast v5, Ljava/net/HttpURLConnection;

    invoke-virtual {v5}, Ljava/net/URLConnection;->getHeaderFields()Ljava/util/Map;

    move-result-object v7

    const/16 v8, 0xa

    new-array v8, v8, [B

    const/16 v9, -0x70

    aput-byte v9, v8, v0

    const/16 v9, -0x25

    const/4 v10, 0x1

    aput-byte v9, v8, v10

    const/16 v11, -0x18

    const/4 v12, 0x2

    aput-byte v11, v8, v12

    const/16 v11, -0x49

    aput-byte v11, v8, v4

    const/16 v11, 0x30

    const/4 v13, 0x4

    aput-byte v11, v8, v13

    const/16 v11, -0x4e

    const/4 v14, 0x5

    aput-byte v11, v8, v14

    const/16 v11, -0x13

    const/4 v15, 0x6

    aput-byte v11, v8, v15

    const/16 v11, 0x7c

    const/16 v16, 0x7

    aput-byte v11, v8, v16

    const/16 v11, -0x56

    const/16 v15, 0x8

    aput-byte v11, v8, v15

    const/16 v11, 0x9

    aput-byte v9, v8, v11

    new-array v9, v15, [B

    const/16 v11, -0x3d

    aput-byte v11, v9, v0

    const/16 v11, -0x42

    aput-byte v11, v9, v10

    const/16 v11, -0x64

    aput-byte v11, v9, v12

    const/16 v11, -0x66

    aput-byte v11, v9, v4

    const/16 v18, 0x73

    aput-byte v18, v9, v13

    const/16 v18, -0x23

    aput-byte v18, v9, v14

    const/16 v18, -0x7e

    const/16 v17, 0x6

    aput-byte v18, v9, v17

    const/16 v18, 0x17

    aput-byte v18, v9, v16

    invoke-static {v8, v9}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v8

    invoke-interface {v7, v8}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Ljava/util/List;

    const/4 v8, 0x6

    new-array v9, v8, [B

    aput-byte v11, v9, v0

    const/16 v8, -0x68

    aput-byte v8, v9, v10

    const/16 v8, -0x48

    aput-byte v8, v9, v12

    const/16 v8, 0xd

    aput-byte v8, v9, v4

    const/16 v8, -0x1b

    aput-byte v8, v9, v13

    const/16 v8, 0x57

    aput-byte v8, v9, v14

    new-array v8, v15, [B

    const/16 v11, -0x27

    aput-byte v11, v8, v0

    const/16 v11, -0x9

    aput-byte v11, v8, v10

    const/16 v10, -0x29

    aput-byte v10, v8, v12

    const/16 v10, 0x66

    aput-byte v10, v8, v4

    const/16 v4, -0x74

    aput-byte v4, v8, v13

    const/16 v4, 0x32

    aput-byte v4, v8, v14

    const/16 v4, -0x7a

    const/4 v10, 0x6

    aput-byte v4, v8, v10

    const/16 v4, 0x40

    aput-byte v4, v8, v16

    invoke-static {v9, v8}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-interface {v7, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Ljava/lang/String;

    move-object/from16 v8, p1

    invoke-interface {v8, v4, v7}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    invoke-virtual {v5}, Ljava/net/URLConnection;->getInputStream()Ljava/io/InputStream;

    move-result-object v4

    new-instance v5, Ljava/io/ByteArrayOutputStream;

    invoke-direct {v5}, Ljava/io/ByteArrayOutputStream;-><init>()V

    const/16 v7, 0x400

    new-array v7, v7, [B

    :goto_da
    invoke-virtual {v4, v7}, Ljava/io/InputStream;->read([B)I

    move-result v9

    const/4 v10, -0x1

    if-eq v9, v10, :cond_e5

    invoke-virtual {v5, v7, v0, v9}, Ljava/io/ByteArrayOutputStream;->write([BII)V

    goto :goto_da

    :cond_e5
    invoke-virtual {v4}, Ljava/io/InputStream;->close()V

    invoke-virtual {v5}, Ljava/io/ByteArrayOutputStream;->toByteArray()[B

    move-result-object v4

    invoke-static {v4, v0}, Landroid/util/Base64;->encodeToString([BI)Ljava/lang/String;

    move-result-object v4

    sget-object v5, Lcom/github/catvod/spider/appysv2/p/k;->a:Ljava/lang/String;

    invoke-static {v5, v4}, Lcom/github/catvod/spider/appysv2/n/c;->j(Ljava/lang/String;Ljava/lang/String;)Lokhttp3/Response;

    move-result-object v4

    invoke-virtual {v4}, Lokhttp3/Response;->body()Lokhttp3/ResponseBody;

    move-result-object v4

    if-eqz v4, :cond_107

    invoke-virtual {v4}, Lokhttp3/ResponseBody;->string()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/String;->length()I

    move-result v5
    :try_end_104
    .catch Ljava/lang/Exception; {:try_start_5 .. :try_end_104} :catch_10b

    if-ne v5, v13, :cond_107

    move-object v2, v4

    :cond_107
    add-int/lit8 v3, v3, 0x1

    goto/16 :goto_5

    :catch_10b
    :cond_10b
    return-object v2
.end method
