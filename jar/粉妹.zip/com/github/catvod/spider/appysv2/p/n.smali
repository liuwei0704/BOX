.class public final Lcom/github/catvod/spider/appysv2/p/n;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final a:Ljava/lang/String;


# direct methods
.method static constructor <clinit>()V
    .registers 2

    const/4 v0, 0x3

    new-array v0, v0, [B

    fill-array-data v0, :array_14

    const/16 v1, 0x8

    new-array v1, v1, [B

    fill-array-data v1, :array_1a

    invoke-static {v0, v1}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lcom/github/catvod/spider/appysv2/p/n;->a:Ljava/lang/String;

    return-void

    :array_14
    .array-data 1
        -0x14t
        0x1t
        0x74t
    .end array-data

    :array_1a
    .array-data 1
        -0x42t
        0x52t
        0x35t
        -0x1ft
        -0x45t
        0x54t
        0x68t
        0x3bt
    .end array-data
.end method

.method public static a(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    .registers 5

    const-string v0, "0A0C383A22110E07303D073805221A082E1D2E02480E76340614343F073714063014070120223B1A07110204301601372273193234210B2C4003171B2D112548290C250045282230220F36373E03253D1D1D7031350336012F1B3F233C0A0B34710701332E0624111E0C07073E32303F36062E0E140D13340527290E1F051E10400E080471714921101B17283234050F7337284130122B2C3717243B122F4141703212732B5269191F07152E13456827403E76320976344031230B17220E253D1D11420E2C592406384830050428421E2C44157022082D377E1C413A0701020430280D3420043B316D42043D2749690C051312352F34040D072A07382A751D4E0E13333C132D2E592D7701491F473411290B29420609063827351310140822342D12183515197E293F0E023E013C00413C2E7E755A1E080E2672124C030724122740001B2B13290B7E202F233303252C28741F212338231D372D7102167708182E592821051D250E6C33233415310D21400D69432C70133D224F30040720223F03271D3407116C3218320D2C720E121D071D0204401A05172C003F4D08133F2E374C323E1717032B702E081C5E210E102C342901031E0A341C3724347E10424D3517130F1F35113F0F0649301E0F347320143C0C7475250D3C352D303E080D24153C5A3F0B3B7311150E0C34060F202300262D36363A6D243626364C130011081834161E29321456242E0220192A2E3D7F7308330D59206A24100D04087D461175170230441E253C3607081E12077407333B293E7528154A360468125A11133B1007023A1727042D1711123F35213510283D2E731D2B3E0423071F1776392F2F164B250132343A4C3C0C127C0156085D147C094E051D7F3224307345030E1C412C230D00492E073170123D136919040A263C2E5D2E2647370F011321301203372D752941281E3F7330213511041C23082A472C29130832202A0949527F430C1F3A4E16180B1236560F102D142400750617021E2A272C7023150833317F270041290F21705A1D3C1C026A1E2D1E15053C2252702E15143B3816597226180077140B763F11131E34243E2F3F437208392128262D21122D1E4601243D106D0F251D2B30203F1677214D3414767C1C2F374721203C1B052E2F3F5A357704007D1E1832432B1C3A1F36137F2E494A1C377A78"

    invoke-static {v0}, Lcom/github/catvod/spider/appysv2/KKB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v1, 0x2

    .line 1
    invoke-static {v0, v1}, Landroid/util/Base64;->decode(Ljava/lang/String;I)[B

    move-result-object v0

    .line 2
    new-instance v2, Ljava/security/spec/PKCS8EncodedKeySpec;

    invoke-direct {v2, v0}, Ljava/security/spec/PKCS8EncodedKeySpec;-><init>([B)V

    sget-object v0, Lcom/github/catvod/spider/appysv2/p/n;->a:Ljava/lang/String;

    invoke-static {v0}, Ljava/security/KeyFactory;->getInstance(Ljava/lang/String;)Ljava/security/KeyFactory;

    move-result-object v0

    invoke-virtual {v0, v2}, Ljava/security/KeyFactory;->generatePrivate(Ljava/security/spec/KeySpec;)Ljava/security/PrivateKey;

    move-result-object v0

    invoke-static {p1}, Ljavax/crypto/Cipher;->getInstance(Ljava/lang/String;)Ljavax/crypto/Cipher;

    move-result-object p1

    invoke-virtual {p1, v1, v0}, Ljavax/crypto/Cipher;->init(ILjava/security/Key;)V

    .line 3
    invoke-static {p0, v1}, Landroid/util/Base64;->decode(Ljava/lang/String;I)[B

    move-result-object p0

    .line 4
    invoke-virtual {p1, p0}, Ljavax/crypto/Cipher;->doFinal([B)[B

    move-result-object p0

    new-instance p1, Ljava/lang/String;

    sget-object v0, Ljava/nio/charset/StandardCharsets;->UTF_8:Ljava/nio/charset/Charset;

    invoke-direct {p1, p0, v0}, Ljava/lang/String;-><init>([BLjava/nio/charset/Charset;)V

    return-object p1
.end method
