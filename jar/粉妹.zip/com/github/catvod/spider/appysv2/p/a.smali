.class public final Lcom/github/catvod/spider/appysv2/p/a;
.super Ljava/lang/Object;
.source "SourceFile"


# direct methods
.method public static a(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    .registers 9

    const/4 v0, 0x0

    const/4 v1, 0x2

    if-eqz p0, :cond_2c

    .line 1
    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v2

    rem-int/2addr v2, v1

    if-eqz v2, :cond_c

    goto :goto_2c

    :cond_c
    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v2

    div-int/2addr v2, v1

    new-array v2, v2, [B

    :goto_13
    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v3

    if-ge v0, v3, :cond_2e

    add-int/lit8 v3, v0, 0x2

    invoke-virtual {p0, v0, v3}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v4

    div-int/lit8 v0, v0, 0x2

    const/16 v5, 0x10

    invoke-static {v4, v5}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;I)I

    move-result v4

    int-to-byte v4, v4

    aput-byte v4, v2, v0

    move v0, v3

    goto :goto_13

    :cond_2c
    :goto_2c
    new-array v2, v0, [B

    .line 2
    :cond_2e
    sget-object p0, Ljava/nio/charset/StandardCharsets;->UTF_8:Ljava/nio/charset/Charset;

    invoke-virtual {p1, p0}, Ljava/lang/String;->getBytes(Ljava/nio/charset/Charset;)[B

    move-result-object p0

    sget-object p1, Ljava/nio/charset/StandardCharsets;->UTF_8:Ljava/nio/charset/Charset;

    invoke-virtual {p2, p1}, Ljava/lang/String;->getBytes(Ljava/nio/charset/Charset;)[B

    move-result-object p1

    new-instance p2, Ljavax/crypto/spec/SecretKeySpec;

    const/4 v0, 0x3

    new-array v0, v0, [B

    fill-array-data v0, :array_78

    const/16 v3, 0x8

    new-array v4, v3, [B

    fill-array-data v4, :array_7e

    invoke-static {v0, v4}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-direct {p2, p0, v0}, Ljavax/crypto/spec/SecretKeySpec;-><init>([BLjava/lang/String;)V

    new-instance p0, Ljavax/crypto/spec/IvParameterSpec;

    invoke-direct {p0, p1}, Ljavax/crypto/spec/IvParameterSpec;-><init>([B)V

    const/16 p1, 0x14

    new-array p1, p1, [B

    fill-array-data p1, :array_86

    new-array v0, v3, [B

    fill-array-data v0, :array_94

    invoke-static {p1, v0}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object p1

    invoke-static {p1}, Ljavax/crypto/Cipher;->getInstance(Ljava/lang/String;)Ljavax/crypto/Cipher;

    move-result-object p1

    invoke-virtual {p1, v1, p2, p0}, Ljavax/crypto/Cipher;->init(ILjava/security/Key;Ljava/security/spec/AlgorithmParameterSpec;)V

    invoke-virtual {p1, v2}, Ljavax/crypto/Cipher;->doFinal([B)[B

    move-result-object p0

    new-instance p1, Ljava/lang/String;

    sget-object p2, Ljava/nio/charset/StandardCharsets;->UTF_8:Ljava/nio/charset/Charset;

    invoke-direct {p1, p0, p2}, Ljava/lang/String;-><init>([BLjava/nio/charset/Charset;)V

    return-object p1

    :array_78
    .array-data 1
        -0x4et
        0x9t
        -0xft
    .end array-data

    :array_7e
    .array-data 1
        -0xdt
        0x4ct
        -0x5et
        0x0t
        -0x37t
        -0x13t
        0x6at
        0x0t
    .end array-data

    :array_86
    .array-data 1
        0xat
        -0x57t
        0x3ft
        -0x60t
        0x27t
        -0x6at
        0x30t
        -0x1t
        0x1bt
        -0x59t
        0x2ft
        -0x24t
        0x51t
        -0x7ct
        0x12t
        -0x4ct
        0x2ft
        -0x7bt
        0x2t
        -0x18t
    .end array-data

    :array_94
    .array-data 1
        0x4bt
        -0x14t
        0x6ct
        -0x71t
        0x64t
        -0x2ct
        0x73t
        -0x30t
    .end array-data
.end method

.method public static b(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    .registers 19

    const/16 v0, 0x14

    :try_start_2
    new-array v0, v0, [B

    const/16 v1, 0x1f

    const/4 v2, 0x0

    aput-byte v1, v0, v2

    const/16 v1, 0x3e

    const/4 v3, 0x1

    aput-byte v1, v0, v3

    const/16 v1, -0xb

    const/4 v4, 0x2

    aput-byte v1, v0, v4

    const/16 v1, -0x13

    const/4 v5, 0x3

    aput-byte v1, v0, v5

    const/16 v1, 0x58

    const/4 v6, 0x4

    aput-byte v1, v0, v6

    const/16 v1, 0x11

    const/4 v7, 0x5

    aput-byte v1, v0, v7

    const/16 v8, -0x69

    const/4 v9, 0x6

    aput-byte v8, v0, v9

    const/16 v8, -0x27

    const/4 v10, 0x7

    aput-byte v8, v0, v10

    const/16 v8, 0xe

    const/16 v11, 0x8

    aput-byte v8, v0, v11

    const/16 v12, 0x9

    const/16 v13, 0x30

    aput-byte v13, v0, v12

    const/16 v12, 0xa

    const/16 v13, -0x1b

    aput-byte v13, v0, v12

    const/16 v12, 0xb

    const/16 v13, -0x6f

    aput-byte v13, v0, v12

    const/16 v12, 0xc

    const/16 v13, 0x2c

    aput-byte v13, v0, v12

    const/16 v12, 0xd

    aput-byte v5, v0, v12

    const/16 v12, -0x4b

    aput-byte v12, v0, v8

    const/16 v8, 0xf

    const/16 v12, -0x6e

    aput-byte v12, v0, v8

    const/16 v8, 0x10

    const/16 v13, 0x3a

    aput-byte v13, v0, v8

    const/16 v8, 0x12

    aput-byte v8, v0, v1

    const/16 v1, -0x38

    aput-byte v1, v0, v8

    const/16 v1, 0x13

    const/16 v8, -0x5b

    aput-byte v8, v0, v1

    new-array v1, v11, [B

    const/16 v8, 0x5e

    aput-byte v8, v1, v2

    const/16 v8, 0x7b

    aput-byte v8, v1, v3

    const/16 v8, -0x5a

    aput-byte v8, v1, v4

    const/16 v8, -0x3e

    aput-byte v8, v1, v5

    const/16 v13, 0x1b

    aput-byte v13, v1, v6

    const/16 v13, 0x53

    aput-byte v13, v1, v7

    const/16 v14, -0x2c

    aput-byte v14, v1, v9

    const/16 v14, -0xa

    aput-byte v14, v1, v10

    invoke-static {v0, v1}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Ljavax/crypto/Cipher;->getInstance(Ljava/lang/String;)Ljavax/crypto/Cipher;

    move-result-object v0

    new-instance v1, Ljavax/crypto/spec/SecretKeySpec;

    invoke-virtual/range {p1 .. p1}, Ljava/lang/String;->getBytes()[B

    move-result-object v14

    new-array v15, v5, [B

    aput-byte v8, v15, v2

    aput-byte v12, v15, v3

    const/16 v8, 0x6f

    aput-byte v8, v15, v4

    new-array v8, v11, [B

    const/16 v11, -0x7d

    aput-byte v11, v8, v2

    const/16 v11, -0x29

    aput-byte v11, v8, v3

    const/16 v3, 0x3c

    aput-byte v3, v8, v4

    const/16 v3, -0x18

    aput-byte v3, v8, v5

    aput-byte v13, v8, v6

    const/16 v3, 0x31

    aput-byte v3, v8, v7

    const/16 v3, 0x1d

    aput-byte v3, v8, v9

    const/16 v3, -0x41

    aput-byte v3, v8, v10

    invoke-static {v15, v8}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v3

    invoke-direct {v1, v14, v3}, Ljavax/crypto/spec/SecretKeySpec;-><init>([BLjava/lang/String;)V

    new-instance v3, Ljavax/crypto/spec/IvParameterSpec;

    invoke-virtual/range {p2 .. p2}, Ljava/lang/String;->getBytes()[B

    move-result-object v5

    invoke-direct {v3, v5}, Ljavax/crypto/spec/IvParameterSpec;-><init>([B)V

    invoke-virtual {v0, v4, v1, v3}, Ljavax/crypto/Cipher;->init(ILjava/security/Key;Ljava/security/spec/AlgorithmParameterSpec;)V

    new-instance v1, Ljava/lang/String;

    invoke-virtual/range {p0 .. p0}, Ljava/lang/String;->getBytes()[B

    move-result-object v3

    invoke-static {v3, v2}, Landroid/util/Base64;->decode([BI)[B

    move-result-object v2

    invoke-virtual {v0, v2}, Ljavax/crypto/Cipher;->doFinal([B)[B

    move-result-object v0

    invoke-direct {v1, v0}, Ljava/lang/String;-><init>([B)V
    :try_end_ea
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_ea} :catch_eb

    return-object v1

    :catch_eb
    move-exception v0

    invoke-static {v0}, Lcom/github/catvod/crawler/SpiderDebug;->log(Ljava/lang/Throwable;)V

    const/4 v0, 0x0

    return-object v0
.end method

.method public static c(Ljava/lang/String;[B[B)Ljava/lang/String;
    .registers 10

    const/16 v0, 0x14

    new-array v0, v0, [B

    fill-array-data v0, :array_70

    const/16 v1, 0x8

    new-array v2, v1, [B

    fill-array-data v2, :array_7e

    invoke-static {v0, v2}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Ljavax/crypto/Cipher;->getInstance(Ljava/lang/String;)Ljavax/crypto/Cipher;

    move-result-object v0

    new-instance v2, Ljavax/crypto/spec/SecretKeySpec;

    const/4 v3, 0x3

    new-array v3, v3, [B

    fill-array-data v3, :array_86

    new-array v4, v1, [B

    fill-array-data v4, :array_8c

    invoke-static {v3, v4}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v3

    invoke-direct {v2, p1, v3}, Ljavax/crypto/spec/SecretKeySpec;-><init>([BLjava/lang/String;)V

    new-instance p1, Ljavax/crypto/spec/IvParameterSpec;

    invoke-direct {p1, p2}, Ljavax/crypto/spec/IvParameterSpec;-><init>([B)V

    const/4 p2, 0x1

    invoke-virtual {v0, p2, v2, p1}, Ljavax/crypto/Cipher;->init(ILjava/security/Key;Ljava/security/spec/AlgorithmParameterSpec;)V

    sget-object p1, Ljava/nio/charset/StandardCharsets;->UTF_8:Ljava/nio/charset/Charset;

    invoke-virtual {p0, p1}, Ljava/lang/String;->getBytes(Ljava/nio/charset/Charset;)[B

    move-result-object p0

    invoke-virtual {v0, p0}, Ljavax/crypto/Cipher;->doFinal([B)[B

    move-result-object p0

    new-instance p1, Ljava/lang/StringBuilder;

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    array-length v0, p0

    const/4 v2, 0x0

    const/4 v3, 0x0

    :goto_45
    if-ge v3, v0, :cond_6a

    aget-byte v4, p0, v3

    const/4 v5, 0x4

    new-array v5, v5, [B

    fill-array-data v5, :array_94

    new-array v6, v1, [B

    fill-array-data v6, :array_9a

    invoke-static {v5, v6}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v5

    new-array v6, p2, [Ljava/lang/Object;

    invoke-static {v4}, Ljava/lang/Byte;->valueOf(B)Ljava/lang/Byte;

    move-result-object v4

    aput-object v4, v6, v2

    invoke-static {v5, v6}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {p1, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    add-int/lit8 v3, v3, 0x1

    goto :goto_45

    :cond_6a
    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0

    nop

    :array_70
    .array-data 1
        0x28t
        0x22t
        0x75t
        -0x65t
        0x6ft
        -0x74t
        -0x68t
        0x23t
        0x39t
        0x2ct
        0x65t
        -0x19t
        0x19t
        -0x62t
        -0x46t
        0x68t
        0xdt
        0xet
        0x48t
        -0x2dt
    .end array-data

    :array_7e
    .array-data 1
        0x69t
        0x67t
        0x26t
        -0x4ct
        0x2ct
        -0x32t
        -0x25t
        0xct
    .end array-data

    :array_86
    .array-data 1
        -0x5et
        -0x24t
        -0x11t
    .end array-data

    :array_8c
    .array-data 1
        -0x1dt
        -0x67t
        -0x44t
        0x9t
        -0x51t
        -0x72t
        -0x80t
        -0x36t
    .end array-data

    :array_94
    .array-data 1
        -0x9t
        0x24t
        0x2et
        0x18t
    .end array-data

    :array_9a
    .array-data 1
        -0x2et
        0x14t
        0x1ct
        0x60t
        -0x23t
        -0x6dt
        0x56t
        0x40t
    .end array-data
.end method

.method public static d(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    .registers 19

    const/4 v0, 0x0

    move-object/from16 v1, p0

    :try_start_3
    invoke-static {v1, v0}, Landroid/util/Base64;->decode(Ljava/lang/String;I)[B

    move-result-object v1

    sget-object v2, Ljava/nio/charset/StandardCharsets;->UTF_8:Ljava/nio/charset/Charset;

    move-object/from16 v3, p1

    invoke-virtual {v3, v2}, Ljava/lang/String;->getBytes(Ljava/nio/charset/Charset;)[B

    move-result-object v2

    new-instance v3, Ljavax/crypto/spec/SecretKeySpec;

    const/4 v4, 0x3

    new-array v5, v4, [B

    const/16 v6, -0x66

    aput-byte v6, v5, v0

    const/16 v6, -0x78

    const/4 v7, 0x1

    aput-byte v6, v5, v7

    const/16 v6, 0x1a

    const/4 v8, 0x2

    aput-byte v6, v5, v8

    const/16 v9, 0x8

    new-array v10, v9, [B

    const/16 v11, -0x25

    aput-byte v11, v10, v0

    const/16 v12, -0x33

    aput-byte v12, v10, v7

    const/16 v12, 0x49

    aput-byte v12, v10, v8

    const/16 v12, -0x3b

    aput-byte v12, v10, v4

    const/16 v12, 0x5d

    const/4 v13, 0x4

    aput-byte v12, v10, v13

    const/16 v12, 0x6e

    const/4 v14, 0x5

    aput-byte v12, v10, v14

    const/16 v12, 0x52

    const/4 v15, 0x6

    aput-byte v12, v10, v15

    const/16 v12, 0x4b

    const/16 v16, 0x7

    aput-byte v12, v10, v16

    invoke-static {v5, v10}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-direct {v3, v2, v5}, Ljavax/crypto/spec/SecretKeySpec;-><init>([BLjava/lang/String;)V

    const/16 v2, 0x14

    new-array v2, v2, [B

    const/16 v5, 0x4e

    aput-byte v5, v2, v0

    const/16 v5, 0x3c

    aput-byte v5, v2, v7

    const/16 v5, -0x13

    aput-byte v5, v2, v8

    const/16 v5, 0x17

    aput-byte v5, v2, v4

    const/16 v5, -0x7a

    aput-byte v5, v2, v13

    const/16 v5, 0x59

    aput-byte v5, v2, v14

    aput-byte v11, v2, v15

    aput-byte v9, v2, v16

    const/16 v5, 0x5f

    aput-byte v5, v2, v9

    const/16 v10, 0x9

    const/16 v11, 0x32

    aput-byte v11, v2, v10

    const/16 v10, 0xa

    const/4 v11, -0x3

    aput-byte v11, v2, v10

    const/16 v10, 0xb

    const/16 v11, 0x6b

    aput-byte v11, v2, v10

    const/16 v10, 0xc

    const/16 v12, -0xa

    aput-byte v12, v2, v10

    const/16 v10, 0xd

    const/16 v12, 0x4a

    aput-byte v12, v2, v10

    const/16 v10, 0xe

    const/4 v12, -0x8

    aput-byte v12, v2, v10

    const/16 v10, 0x43

    const/16 v12, 0xf

    aput-byte v10, v2, v12

    const/16 v10, 0x10

    aput-byte v11, v2, v10

    const/16 v11, 0x11

    aput-byte v10, v2, v11

    const/16 v10, 0x12

    const/16 v11, -0x30

    aput-byte v11, v2, v10

    const/16 v10, 0x13

    aput-byte v5, v2, v10

    new-array v5, v9, [B

    aput-byte v12, v5, v0

    const/16 v0, 0x79

    aput-byte v0, v5, v7

    const/16 v0, -0x42

    aput-byte v0, v5, v8

    const/16 v0, 0x38

    aput-byte v0, v5, v4

    const/16 v0, -0x3d

    aput-byte v0, v5, v13

    aput-byte v6, v5, v14

    const/16 v0, -0x67

    aput-byte v0, v5, v15

    const/16 v0, 0x27

    aput-byte v0, v5, v16

    invoke-static {v2, v5}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Ljavax/crypto/Cipher;->getInstance(Ljava/lang/String;)Ljavax/crypto/Cipher;

    move-result-object v0

    invoke-virtual {v0, v8, v3}, Ljavax/crypto/Cipher;->init(ILjava/security/Key;)V

    invoke-virtual {v0, v1}, Ljavax/crypto/Cipher;->doFinal([B)[B

    move-result-object v0

    new-instance v1, Ljava/lang/String;

    sget-object v2, Ljava/nio/charset/StandardCharsets;->UTF_8:Ljava/nio/charset/Charset;

    invoke-direct {v1, v0, v2}, Ljava/lang/String;-><init>([BLjava/nio/charset/Charset;)V
    :try_end_e4
    .catch Ljava/lang/Exception; {:try_start_3 .. :try_end_e4} :catch_e5

    return-object v1

    :catch_e5
    const-string v0, ""

    return-object v0
.end method

.method public static e(Ljava/io/File;)Ljava/io/File;
    .registers 14

    :try_start_0
    invoke-virtual {p0}, Ljava/io/File;->canWrite()Z

    move-result v0

    const/4 v1, 0x1

    if-nez v0, :cond_a

    invoke-virtual {p0, v1}, Ljava/io/File;->setWritable(Z)Z

    :cond_a
    invoke-virtual {p0}, Ljava/io/File;->exists()Z

    move-result v0

    if-nez v0, :cond_13

    invoke-virtual {p0}, Ljava/io/File;->createNewFile()Z

    :cond_13
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/16 v2, 0xa

    new-array v2, v2, [B

    const/16 v3, -0x11

    const/4 v4, 0x0

    aput-byte v3, v2, v4

    const/16 v3, 0x23

    aput-byte v3, v2, v1

    const/16 v3, 0x43

    const/4 v5, 0x2

    aput-byte v3, v2, v5

    const/16 v3, -0x31

    const/4 v6, 0x3

    aput-byte v3, v2, v6

    const/16 v3, 0x63

    const/4 v7, 0x4

    aput-byte v3, v2, v7

    const/16 v3, 0x5a

    const/4 v8, 0x5

    aput-byte v3, v2, v8

    const/16 v3, -0x75

    const/4 v9, 0x6

    aput-byte v3, v2, v9

    const/16 v3, 0xe

    const/4 v10, 0x7

    aput-byte v3, v2, v10

    const/16 v3, -0x45

    const/16 v11, 0x8

    aput-byte v3, v2, v11

    const/16 v3, 0x9

    const/16 v12, 0x6b

    aput-byte v12, v2, v3

    new-array v3, v11, [B

    const/16 v11, -0x74

    aput-byte v11, v3, v4

    const/16 v4, 0x4b

    aput-byte v4, v3, v1

    const/16 v1, 0x2e

    aput-byte v1, v3, v5

    const/16 v1, -0x60

    aput-byte v1, v3, v6

    aput-byte v10, v3, v7

    const/16 v1, 0x7a

    aput-byte v1, v3, v8

    const/16 v1, -0x44

    aput-byte v1, v3, v9

    const/16 v1, 0x39

    aput-byte v1, v3, v10

    invoke-static {v2, v3}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lcom/github/catvod/spider/appysv2/B/l;->b(Ljava/lang/String;)V
    :try_end_80
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_80} :catch_81

    return-object p0

    :catch_81
    move-exception v0

    invoke-virtual {v0}, Ljava/lang/Throwable;->printStackTrace()V

    return-object p0
.end method

.method public static f([B[B[BLjava/lang/String;)[B
    .registers 12

    :try_start_0
    new-instance v0, Ljavax/crypto/spec/SecretKeySpec;

    const/4 v1, 0x3

    new-array v2, v1, [B

    const/16 v3, -0x36

    const/4 v4, 0x0

    aput-byte v3, v2, v4

    const/4 v3, -0x5

    const/4 v5, 0x1

    aput-byte v3, v2, v5

    const/4 v3, 0x2

    aput-byte v5, v2, v3

    const/16 v6, 0x8

    new-array v6, v6, [B

    const/16 v7, -0x75

    aput-byte v7, v6, v4

    const/16 v4, -0x42

    aput-byte v4, v6, v5

    const/16 v4, 0x52

    aput-byte v4, v6, v3

    aput-byte v3, v6, v1

    const/4 v1, 0x4

    const/16 v4, -0x52

    aput-byte v4, v6, v1

    const/4 v1, 0x5

    const/16 v4, -0x7b

    aput-byte v4, v6, v1

    const/4 v1, 0x6

    const/16 v4, 0x33

    aput-byte v4, v6, v1

    const/4 v1, 0x7

    const/16 v4, -0x3f

    aput-byte v4, v6, v1

    invoke-static {v2, v6}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, p1, v1}, Ljavax/crypto/spec/SecretKeySpec;-><init>([BLjava/lang/String;)V

    invoke-static {p3}, Ljavax/crypto/Cipher;->getInstance(Ljava/lang/String;)Ljavax/crypto/Cipher;

    move-result-object p1

    if-eqz p2, :cond_4d

    new-instance p3, Ljavax/crypto/spec/IvParameterSpec;

    invoke-direct {p3, p2}, Ljavax/crypto/spec/IvParameterSpec;-><init>([B)V

    invoke-virtual {p1, v3, v0, p3}, Ljavax/crypto/Cipher;->init(ILjava/security/Key;Ljava/security/spec/AlgorithmParameterSpec;)V

    goto :goto_50

    :cond_4d
    invoke-virtual {p1, v3, v0}, Ljavax/crypto/Cipher;->init(ILjava/security/Key;)V

    :goto_50
    invoke-virtual {p1, p0}, Ljavax/crypto/Cipher;->doFinal([B)[B

    move-result-object p0
    :try_end_54
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_54} :catch_55

    return-object p0

    :catch_55
    move-exception p0

    invoke-static {p0}, Lcom/github/catvod/crawler/SpiderDebug;->log(Ljava/lang/Throwable;)V

    const/4 p0, 0x0

    return-object p0
.end method

.method public static g([B[B[BLjava/lang/String;)Ljava/lang/String;
    .registers 5

    new-instance v0, Ljava/lang/String;

    invoke-static {p0, p1, p2, p3}, Lcom/github/catvod/spider/appysv2/p/a;->f([B[B[BLjava/lang/String;)[B

    move-result-object p0

    invoke-direct {v0, p0}, Ljava/lang/String;-><init>([B)V

    return-object v0
.end method

.method public static h(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)[B
    .registers 16

    :try_start_0
    new-instance v0, Ljavax/crypto/spec/IvParameterSpec;

    sget-object v1, Ljava/nio/charset/StandardCharsets;->UTF_8:Ljava/nio/charset/Charset;

    invoke-virtual {p2, v1}, Ljava/lang/String;->getBytes(Ljava/nio/charset/Charset;)[B

    move-result-object p2

    invoke-direct {v0, p2}, Ljavax/crypto/spec/IvParameterSpec;-><init>([B)V

    new-instance p2, Ljavax/crypto/spec/SecretKeySpec;

    sget-object v1, Ljava/nio/charset/StandardCharsets;->UTF_8:Ljava/nio/charset/Charset;

    invoke-virtual {p1, v1}, Ljava/lang/String;->getBytes(Ljava/nio/charset/Charset;)[B

    move-result-object p1

    const/4 v1, 0x3

    new-array v2, v1, [B

    const/16 v3, -0x31

    const/4 v4, 0x0

    aput-byte v3, v2, v4

    const/16 v3, 0x1b

    const/4 v5, 0x1

    aput-byte v3, v2, v5

    const/16 v3, 0x4f

    const/4 v6, 0x2

    aput-byte v3, v2, v6

    const/16 v3, 0x8

    new-array v7, v3, [B

    const/16 v8, -0x72

    aput-byte v8, v7, v4

    const/16 v8, 0x5e

    aput-byte v8, v7, v5

    const/16 v8, 0x1c

    aput-byte v8, v7, v6

    const/16 v8, -0x55

    aput-byte v8, v7, v1

    const/16 v8, -0x5d

    const/4 v9, 0x4

    aput-byte v8, v7, v9

    const/16 v8, -0x5f

    const/4 v10, 0x5

    aput-byte v8, v7, v10

    const/16 v8, -0x11

    const/4 v11, 0x6

    aput-byte v8, v7, v11

    const/16 v8, -0x32

    const/4 v12, 0x7

    aput-byte v8, v7, v12

    invoke-static {v2, v7}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-direct {p2, p1, v2}, Ljavax/crypto/spec/SecretKeySpec;-><init>([BLjava/lang/String;)V

    const/16 p1, 0x14

    new-array p1, p1, [B

    const/16 v2, 0x6e

    aput-byte v2, p1, v4

    const/16 v2, -0x7c

    aput-byte v2, p1, v5

    const/16 v2, 0x63

    aput-byte v2, p1, v6

    const/16 v7, 0x1f

    aput-byte v7, p1, v1

    const/16 v7, 0x74

    aput-byte v7, p1, v9

    aput-byte v8, p1, v10

    const/16 v7, -0x6c

    aput-byte v7, p1, v11

    const/16 v7, -0x3e

    aput-byte v7, p1, v12

    const/16 v7, 0x7f

    aput-byte v7, p1, v3

    const/16 v7, 0x9

    const/16 v8, -0x76

    aput-byte v8, p1, v7

    const/16 v7, 0xa

    const/16 v8, 0x73

    aput-byte v8, p1, v7

    const/16 v7, 0xb

    aput-byte v2, p1, v7

    const/16 v2, 0xc

    aput-byte v6, p1, v2

    const/16 v2, 0xd

    const/16 v7, -0x24

    aput-byte v7, p1, v2

    const/16 v2, 0xe

    const/16 v7, -0x6a

    aput-byte v7, p1, v2

    const/16 v2, 0xf

    const/16 v7, -0x57

    aput-byte v7, p1, v2

    const/16 v2, 0x10

    const/16 v7, 0x6b

    aput-byte v7, p1, v2

    const/16 v2, 0x11

    const/16 v7, -0x78

    aput-byte v7, p1, v2

    const/16 v2, 0x12

    const/16 v7, 0x7e

    aput-byte v7, p1, v2

    const/16 v2, 0x13

    const/16 v7, 0x77

    aput-byte v7, p1, v2

    new-array v2, v3, [B

    const/16 v3, 0x2f

    aput-byte v3, v2, v4

    const/16 v3, -0x3f

    aput-byte v3, v2, v5

    const/16 v3, 0x30

    aput-byte v3, v2, v6

    aput-byte v3, v2, v1

    const/16 v1, 0x37

    aput-byte v1, v2, v9

    const/16 v1, -0x74

    aput-byte v1, v2, v10

    const/16 v1, -0x29

    aput-byte v1, v2, v11

    const/16 v1, -0x13

    aput-byte v1, v2, v12

    invoke-static {p1, v2}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object p1

    invoke-static {p1}, Ljavax/crypto/Cipher;->getInstance(Ljava/lang/String;)Ljavax/crypto/Cipher;

    move-result-object p1

    invoke-virtual {p1, v5, p2, v0}, Ljavax/crypto/Cipher;->init(ILjava/security/Key;Ljava/security/spec/AlgorithmParameterSpec;)V

    invoke-virtual {p0}, Ljava/lang/String;->getBytes()[B

    move-result-object p0

    invoke-virtual {p1, p0}, Ljavax/crypto/Cipher;->doFinal([B)[B

    move-result-object p0
    :try_end_eb
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_eb} :catch_ec

    return-object p0

    :catch_ec
    const-string p0, ""

    invoke-virtual {p0}, Ljava/lang/String;->getBytes()[B

    move-result-object p0

    return-object p0
.end method

.method public static i(Ljava/lang/String;)Ljava/lang/String;
    .registers 4

    const/4 v0, 0x2

    new-array v1, v0, [B

    fill-array-data v1, :array_2c

    const/16 v2, 0x8

    new-array v2, v2, [B

    fill-array-data v2, :array_32

    invoke-static {v1, v2}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {p0, v1}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_1b

    invoke-virtual {p0, v0}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object p0

    :cond_1b
    new-instance v0, Ljava/math/BigInteger;

    const/16 v1, 0x10

    invoke-direct {v0, p0, v1}, Ljava/math/BigInteger;-><init>(Ljava/lang/String;I)V

    invoke-virtual {v0}, Ljava/math/BigInteger;->toByteArray()[B

    move-result-object p0

    new-instance v0, Ljava/lang/String;

    invoke-direct {v0, p0}, Ljava/lang/String;-><init>([B)V

    return-object v0

    :array_2c
    .array-data 1
        -0x10t
        -0x35t
    .end array-data

    nop

    :array_32
    .array-data 1
        -0x40t
        -0x4dt
        -0x6ct
        0x41t
        0x7dt
        -0x70t
        -0x15t
        -0x29t
    .end array-data
.end method

.method public static j(Ljava/lang/String;)Ljava/io/File;
    .registers 6

    new-instance v0, Ljava/io/File;

    const/4 v1, 0x6

    new-array v2, v1, [B

    fill-array-data v2, :array_50

    const/16 v3, 0x8

    new-array v4, v3, [B

    fill-array-data v4, :array_58

    invoke-static {v2, v4}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v2

    const-string v4, ""

    invoke-virtual {p0, v2, v4}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object v2

    invoke-direct {v0, v2}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    new-instance v2, Ljava/io/File;

    new-array v1, v1, [B

    fill-array-data v1, :array_60

    new-array v3, v3, [B

    fill-array-data v3, :array_68

    invoke-static {v1, v3}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v1

    .line 1
    invoke-static {}, Landroid/os/Environment;->getExternalStorageDirectory()Ljava/io/File;

    move-result-object v3

    .line 2
    invoke-virtual {v3}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;

    move-result-object v3

    .line 3
    invoke-virtual {p0, v1, v3}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object v1

    invoke-direct {v2, v1}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    invoke-virtual {v2}, Ljava/io/File;->exists()Z

    move-result v1

    if-eqz v1, :cond_43

    move-object v0, v2

    goto :goto_4f

    :cond_43
    invoke-virtual {v0}, Ljava/io/File;->exists()Z

    move-result v1

    if-eqz v1, :cond_4a

    goto :goto_4f

    :cond_4a
    new-instance v0, Ljava/io/File;

    invoke-direct {v0, p0}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    :goto_4f
    return-object v0

    :array_50
    .array-data 1
        0x1t
        -0x1dt
        0x61t
        -0x4bt
        0x22t
        -0x13t
    .end array-data

    nop

    :array_58
    .array-data 1
        0x67t
        -0x76t
        0xdt
        -0x30t
        0x18t
        -0x3et
        -0x7t
        -0x33t
    .end array-data

    :array_60
    .array-data 1
        0x72t
        -0x58t
        0x37t
        -0x5at
        0x3t
        0xft
    .end array-data

    nop

    :array_68
    .array-data 1
        0x14t
        -0x3ft
        0x5bt
        -0x3dt
        0x39t
        0x20t
        0x74t
        0x20t
    .end array-data
.end method

.method public static k(Ljava/io/File;)Ljava/lang/String;
    .registers 2

    :try_start_0
    new-instance v0, Ljava/io/FileInputStream;

    invoke-direct {v0, p0}, Ljava/io/FileInputStream;-><init>(Ljava/io/File;)V

    invoke-static {v0}, Lcom/github/catvod/spider/appysv2/p/a;->l(Ljava/io/InputStream;)Ljava/lang/String;

    move-result-object p0
    :try_end_9
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_9} :catch_a

    return-object p0

    :catch_a
    const-string p0, ""

    return-object p0
.end method

.method public static l(Ljava/io/InputStream;)Ljava/lang/String;
    .registers 3

    :try_start_0
    invoke-virtual {p0}, Ljava/io/InputStream;->available()I

    move-result v0

    new-array v0, v0, [B

    invoke-virtual {p0, v0}, Ljava/io/InputStream;->read([B)I

    invoke-virtual {p0}, Ljava/io/InputStream;->close()V

    new-instance p0, Ljava/lang/String;

    sget-object v1, Ljava/nio/charset/StandardCharsets;->UTF_8:Ljava/nio/charset/Charset;

    invoke-direct {p0, v0, v1}, Ljava/lang/String;-><init>([BLjava/nio/charset/Charset;)V
    :try_end_13
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_13} :catch_14

    return-object p0

    :catch_14
    move-exception p0

    invoke-virtual {p0}, Ljava/lang/Throwable;->printStackTrace()V

    const-string p0, ""

    return-object p0
.end method

.method public static m(Ljava/lang/String;)Ljava/lang/String;
    .registers 2

    :try_start_0
    new-instance v0, Ljava/io/FileInputStream;

    invoke-static {p0}, Lcom/github/catvod/spider/appysv2/p/a;->j(Ljava/lang/String;)Ljava/io/File;

    move-result-object p0

    invoke-direct {v0, p0}, Ljava/io/FileInputStream;-><init>(Ljava/io/File;)V

    invoke-static {v0}, Lcom/github/catvod/spider/appysv2/p/a;->l(Ljava/io/InputStream;)Ljava/lang/String;

    move-result-object p0
    :try_end_d
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_d} :catch_e

    return-object p0

    :catch_e
    const-string p0, ""

    return-object p0
.end method

.method public static n(Ljava/lang/String;)Ljava/io/File;
    .registers 6

    const/4 v0, 0x1

    new-array v1, v0, [B

    const/4 v2, 0x0

    const/16 v3, -0x29

    aput-byte v3, v1, v2

    const/16 v3, 0x8

    new-array v4, v3, [B

    fill-array-data v4, :array_62

    invoke-static {v1, v4}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {p0, v1}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v1

    if-nez v1, :cond_2d

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    new-array v0, v0, [B

    const/16 v4, -0x20

    aput-byte v4, v0, v2

    new-array v2, v3, [B

    fill-array-data v2, :array_6a

    .line 1
    invoke-static {v0, v2, v1, p0}, Lcom/github/catvod/spider/appysv2/b/u;->a([B[BLjava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    .line 2
    :cond_2d
    new-instance v0, Ljava/io/File;

    .line 3
    new-instance v1, Ljava/io/File;

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    .line 4
    invoke-static {}, Landroid/os/Environment;->getExternalStorageDirectory()Ljava/io/File;

    move-result-object v4

    .line 5
    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    sget-object v4, Ljava/io/File;->separator:Ljava/lang/String;

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x2

    new-array v4, v4, [B

    fill-array-data v4, :array_72

    new-array v3, v3, [B

    fill-array-data v3, :array_78

    .line 6
    invoke-static {v4, v3, v2}, Lcom/github/catvod/spider/appysv2/b/t;->a([B[BLjava/lang/StringBuilder;)Ljava/lang/String;

    move-result-object v2

    .line 7
    invoke-direct {v1, v2}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    .line 8
    invoke-virtual {v1}, Ljava/io/File;->exists()Z

    move-result v2

    if-nez v2, :cond_5d

    invoke-virtual {v1}, Ljava/io/File;->mkdirs()Z

    .line 9
    :cond_5d
    invoke-direct {v0, v1, p0}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    return-object v0

    nop

    :array_62
    .array-data 1
        -0x7t
        -0x80t
        0xct
        0x47t
        -0x15t
        -0x51t
        -0x7et
        0x38t
    .end array-data

    :array_6a
    .array-data 1
        -0x32t
        0x0t
        0x33t
        -0x63t
        -0x6t
        0x6et
        0x69t
        -0x4ct
    .end array-data

    :array_72
    .array-data 1
        -0x30t
        0x28t
    .end array-data

    nop

    :array_78
    .array-data 1
        -0x7ct
        0x7et
        0x67t
        0x50t
        0xat
        0x34t
        0x2bt
        0x5ct
    .end array-data
.end method

.method public static o(Ljava/io/File;Ljava/lang/String;)Ljava/io/File;
    .registers 3

    invoke-virtual {p1}, Ljava/lang/String;->getBytes()[B

    move-result-object p1

    :try_start_4
    new-instance v0, Ljava/io/FileOutputStream;

    invoke-static {p0}, Lcom/github/catvod/spider/appysv2/p/a;->e(Ljava/io/File;)Ljava/io/File;

    invoke-direct {v0, p0}, Ljava/io/FileOutputStream;-><init>(Ljava/io/File;)V

    invoke-virtual {v0, p1}, Ljava/io/FileOutputStream;->write([B)V

    invoke-virtual {v0}, Ljava/io/OutputStream;->flush()V

    invoke-virtual {v0}, Ljava/io/FileOutputStream;->close()V
    :try_end_15
    .catch Ljava/lang/Exception; {:try_start_4 .. :try_end_15} :catch_15

    :catch_15
    return-object p0
.end method
