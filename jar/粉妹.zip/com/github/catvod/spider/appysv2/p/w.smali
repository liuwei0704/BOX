.class public final synthetic Lcom/github/catvod/spider/appysv2/p/w;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/content/DialogInterface$OnClickListener;


# instance fields
.field public final synthetic a:Lcom/github/catvod/spider/appysv2/p/B;

.field public final synthetic b:Ljava/util/Map;

.field public final synthetic c:Ljava/lang/String;


# direct methods
.method public synthetic constructor <init>(Lcom/github/catvod/spider/appysv2/p/B;Ljava/util/Map;Ljava/lang/String;)V
    .registers 4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/github/catvod/spider/appysv2/p/w;->a:Lcom/github/catvod/spider/appysv2/p/B;

    iput-object p2, p0, Lcom/github/catvod/spider/appysv2/p/w;->b:Ljava/util/Map;

    iput-object p3, p0, Lcom/github/catvod/spider/appysv2/p/w;->c:Ljava/lang/String;

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/content/DialogInterface;I)V
    .registers 4

    iget-object p1, p0, Lcom/github/catvod/spider/appysv2/p/w;->a:Lcom/github/catvod/spider/appysv2/p/B;

    iget-object p2, p0, Lcom/github/catvod/spider/appysv2/p/w;->b:Ljava/util/Map;

    iget-object v0, p0, Lcom/github/catvod/spider/appysv2/p/w;->c:Ljava/lang/String;

    invoke-static {p1, p2, v0}, Lcom/github/catvod/spider/appysv2/p/B;->m(Lcom/github/catvod/spider/appysv2/p/B;Ljava/util/Map;Ljava/lang/String;)V

    return-void
.end method
