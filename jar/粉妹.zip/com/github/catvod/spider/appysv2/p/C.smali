.class public final Lcom/github/catvod/spider/appysv2/p/C;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final a:Ljava/util/regex/Pattern;

.field public static final b:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field public static final c:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .registers 9

    const/16 v0, 0x6f

    new-array v0, v0, [B

    fill-array-data v0, :array_17c

    const/16 v1, 0x8

    new-array v2, v1, [B

    fill-array-data v2, :array_1b8

    invoke-static {v0, v2}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    const/16 v0, 0x87

    new-array v0, v0, [B

    fill-array-data v0, :array_1c0

    new-array v2, v1, [B

    fill-array-data v2, :array_208

    invoke-static {v0, v2}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    const/16 v0, 0x8a

    new-array v0, v0, [B

    fill-array-data v0, :array_210

    new-array v2, v1, [B

    fill-array-data v2, :array_25a

    invoke-static {v0, v2}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    move-result-object v0

    sput-object v0, Lcom/github/catvod/spider/appysv2/p/C;->a:Ljava/util/regex/Pattern;

    const/16 v0, 0xe

    new-array v0, v0, [Ljava/lang/String;

    const/4 v2, 0x3

    new-array v3, v2, [B

    fill-array-data v3, :array_262

    new-array v4, v1, [B

    fill-array-data v4, :array_268

    invoke-static {v3, v4}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v3

    const/4 v4, 0x0

    aput-object v3, v0, v4

    new-array v3, v2, [B

    fill-array-data v3, :array_270

    new-array v5, v1, [B

    fill-array-data v5, :array_276

    invoke-static {v3, v5}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v3

    const/4 v5, 0x1

    aput-object v3, v0, v5

    new-array v3, v2, [B

    fill-array-data v3, :array_27e

    new-array v6, v1, [B

    fill-array-data v6, :array_284

    invoke-static {v3, v6}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v3

    const/4 v6, 0x2

    aput-object v3, v0, v6

    new-array v3, v2, [B

    fill-array-data v3, :array_28c

    new-array v7, v1, [B

    fill-array-data v7, :array_292

    invoke-static {v3, v7}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v3

    aput-object v3, v0, v2

    new-array v3, v2, [B

    fill-array-data v3, :array_29a

    new-array v7, v1, [B

    fill-array-data v7, :array_2a0

    invoke-static {v3, v7}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v3

    const/4 v7, 0x4

    aput-object v3, v0, v7

    new-array v3, v2, [B

    fill-array-data v3, :array_2a8

    new-array v8, v1, [B

    fill-array-data v8, :array_2ae

    invoke-static {v3, v8}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v3

    const/4 v8, 0x5

    aput-object v3, v0, v8

    new-array v3, v2, [B

    fill-array-data v3, :array_2b6

    new-array v8, v1, [B

    fill-array-data v8, :array_2bc

    invoke-static {v3, v8}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v3

    const/4 v8, 0x6

    aput-object v3, v0, v8

    new-array v3, v6, [B

    fill-array-data v3, :array_2c4

    new-array v8, v1, [B

    fill-array-data v8, :array_2ca

    invoke-static {v3, v8}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v3

    const/4 v8, 0x7

    aput-object v3, v0, v8

    new-array v3, v2, [B

    fill-array-data v3, :array_2d2

    new-array v8, v1, [B

    fill-array-data v8, :array_2d8

    invoke-static {v3, v8}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v3

    aput-object v3, v0, v1

    new-array v3, v2, [B

    fill-array-data v3, :array_2e0

    new-array v8, v1, [B

    fill-array-data v8, :array_2e6

    invoke-static {v3, v8}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v3

    const/16 v8, 0x9

    aput-object v3, v0, v8

    new-array v3, v7, [B

    fill-array-data v3, :array_2ee

    new-array v8, v1, [B

    fill-array-data v8, :array_2f4

    invoke-static {v3, v8}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v3

    const/16 v8, 0xa

    aput-object v3, v0, v8

    new-array v3, v2, [B

    fill-array-data v3, :array_2fc

    new-array v8, v1, [B

    fill-array-data v8, :array_302

    invoke-static {v3, v8}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v3

    const/16 v8, 0xb

    aput-object v3, v0, v8

    new-array v3, v2, [B

    fill-array-data v3, :array_30a

    new-array v8, v1, [B

    fill-array-data v8, :array_310

    invoke-static {v3, v8}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v3

    const/16 v8, 0xc

    aput-object v3, v0, v8

    new-array v3, v2, [B

    fill-array-data v3, :array_318

    new-array v8, v1, [B

    fill-array-data v8, :array_31e

    invoke-static {v3, v8}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v3

    const/16 v8, 0xd

    aput-object v3, v0, v8

    invoke-static {v0}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v0

    sput-object v0, Lcom/github/catvod/spider/appysv2/p/C;->b:Ljava/util/List;

    new-array v0, v7, [Ljava/lang/String;

    new-array v3, v2, [B

    fill-array-data v3, :array_326

    new-array v7, v1, [B

    fill-array-data v7, :array_32c

    invoke-static {v3, v7}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v3

    aput-object v3, v0, v4

    new-array v3, v2, [B

    fill-array-data v3, :array_334

    new-array v4, v1, [B

    fill-array-data v4, :array_33a

    invoke-static {v3, v4}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v3

    aput-object v3, v0, v5

    new-array v3, v2, [B

    fill-array-data v3, :array_342

    new-array v4, v1, [B

    fill-array-data v4, :array_348

    invoke-static {v3, v4}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v3

    aput-object v3, v0, v6

    new-array v3, v2, [B

    fill-array-data v3, :array_350

    new-array v1, v1, [B

    fill-array-data v1, :array_356

    invoke-static {v3, v1}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v1

    aput-object v1, v0, v2

    invoke-static {v0}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v0

    sput-object v0, Lcom/github/catvod/spider/appysv2/p/C;->c:Ljava/util/List;

    return-void

    nop

    :array_17c
    .array-data 1
        -0x56t
        0x19t
        -0x2et
        0x60t
        0x60t
        -0x16t
        0x38t
        0x22t
        -0x2et
        0x58t
        -0x68t
        0x29t
        0x24t
        -0x2ft
        0x30t
        0x63t
        -0x7dt
        0x19t
        -0x21t
        0x7at
        0x2ct
        -0x38t
        0xdt
        0x2dt
        -0x2at
        0x46t
        -0x7at
        0x39t
        0x37t
        -0x5at
        0xet
        0x64t
        -0x77t
        0x40t
        -0x64t
        0x32t
        0x2ct
        -0x2t
        0x6ft
        0x39t
        -0x32t
        0x56t
        -0x17t
        0x79t
        0x7ct
        -0x16t
        0x3ct
        0x5at
        -0x7et
        0x14t
        -0x1dt
        0x60t
        0x78t
        -0x57t
        0x6ct
        0x3et
        -0x30t
        0x58t
        -0x65t
        0x3ft
        0x2ct
        -0x52t
        0x12t
        0x45t
        -0x4dt
        0x3bt
        -0x1ct
        0x25t
        0x2ct
        -0x16t
        0x30t
        0x66t
        -0x7et
        0x56t
        -0x11t
        0x6ct
        0x6ft
        -0x13t
        0x36t
        0x24t
        -0x39t
        0x35t
        -0x40t
        0x7bt
        0x63t
        -0x15t
        0x3ct
        0x22t
        -0x2at
        0x47t
        -0x61t
        0x27t
        0x3ct
        -0x58t
        0x69t
        0x23t
        -0x29t
        0x56t
        -0x5t
        0x68t
        0x6at
        -0x19t
        0x2bt
        0x64t
        -0x38t
        0x43t
        -0x65t
        0x3et
        0x22t
        -0x4bt
        0x6ft
    .end array-data

    :array_1b8
    .array-data 1
        -0x19t
        0x76t
        -0x58t
        0x9t
        0xct
        -0x7at
        0x59t
        0xdt
    .end array-data

    :array_1c0
    .array-data 1
        0x46t
        0x67t
        0x3et
        0x43t
        0x32t
        -0x58t
        0x7ft
        0x9t
        0x5et
        0x2et
        0x27t
        0x47t
        0x6dt
        -0x54t
        0x62t
        0x7t
        0x53t
        0x76t
        0x2ft
        0x58t
        0x73t
        -0x11t
        0x73t
        0xct
        0x46t
        0x6ft
        0x2at
        0x1ct
        0x65t
        -0x53t
        0x67t
        0x48t
        0x53t
        0x72t
        0x36t
        0x5bt
        0x74t
        -0x5dt
        0x6at
        0x10t
        0x5bt
        0x6dt
        0x28t
        0x18t
        0x65t
        -0x53t
        0x67t
        0x5ft
        0x43t
        0x3ft
        0x76t
        0x19t
        0x24t
        -0x14t
        0x62t
        0x9t
        0x53t
        0x65t
        0x23t
        0x18t
        0x7ct
        -0x4at
        0x62t
        0x2t
        0x1et
        0x6bt
        0x2bt
        0x56t
        0x7at
        -0x5bt
        0x24t
        0x13t
        0x57t
        0x60t
        0x36t
        0x1bt
        0x74t
        -0x53t
        0x6at
        0x3t
        0x57t
        0x2dt
        0x27t
        0x47t
        0x73t
        -0x59t
        0x27t
        0x4et
        0x1dt
        0x28t
        0x7dt
        0x46t
        0x20t
        -0x10t
        0x25t
        0x5ct
        0x1et
        0x63t
        0x36t
        0x47t
        0x71t
        -0x57t
        0x68t
        0x5t
        0x46t
        0x6bt
        0x29t
        0x59t
        0x32t
        -0x4dt
        0x62t
        0x3t
        0x5ct
        0x67t
        0x22t
        0x1at
        0x78t
        -0x48t
        0x68t
        0xct
        0x53t
        0x6ct
        0x21t
        0x52t
        0x26t
        -0x4at
        0x36t
        0x6t
        0x1t
        0x39t
        0x37t
        0xat
        0x2dt
        -0x12t
        0x3ct
    .end array-data

    :array_208
    .array-data 1
        0x32t
        0x2t
        0x46t
        0x37t
        0x1dt
        -0x40t
        0xbt
        0x64t
    .end array-data

    :array_210
    .array-data 1
        0x48t
        0x58t
        -0x6et
        0x27t
        0x2bt
        -0x57t
        -0x35t
        -0x15t
        0x48t
        0x58t
        -0x6et
        0x27t
        0x2at
        -0x51t
        -0x23t
        -0x4ft
        0x11t
        0x1et
        -0x36t
        0x2at
        0x3ct
        -0x23t
        -0x26t
        -0x1et
        0x4dt
        0x1ft
        -0x6dt
        0x6ft
        0x7ft
        -0x14t
        -0x7ct
        -0x2t
        0x5ct
        0x41t
        -0x73t
        0x21t
        0x7ft
        -0x19t
        -0x68t
        -0x44t
        0x5ct
        0x41t
        -0x6at
        0x64t
        0x7ft
        -0x14t
        -0x40t
        -0x55t
        0x5ct
        0x4dt
        -0x79t
        0x34t
        0x2at
        -0x23t
        -0x35t
        -0x1ct
        0xat
        0x50t
        -0x72t
        0x23t
        0x77t
        -0xft
        -0x24t
        -0x1et
        0x1ft
        0xdt
        -0x72t
        0x23t
        0x77t
        -0xft
        -0x23t
        -0x1ct
        0x9t
        0x57t
        -0x29t
        0x65t
        0x2ft
        -0x4t
        -0x58t
        -0x1ct
        0x8t
        0x41t
        -0x2bt
        0x22t
        0x3bt
        -0x3t
        -0x67t
        -0x46t
        0x14t
        0x50t
        -0x75t
        0x3ct
        0x75t
        -0x3t
        -0x6et
        -0x5at
        0x56t
        0x50t
        -0x75t
        0x27t
        0x30t
        -0x3t
        -0x67t
        -0x2t
        0x41t
        0x50t
        -0x79t
        0x36t
        0x60t
        -0x58t
        -0x78t
        -0x5et
        0x54t
        0x58t
        -0x6at
        0x7ft
        0x2bt
        -0x42t
        -0x2bt
        -0x5et
        0x54t
        0x58t
        -0x6at
        0x7et
        0x2dt
        -0x58t
        -0x22t
        -0xbt
        0x56t
        0x45t
        -0x7et
        0x32t
        0x6ct
        -0x52t
        -0x80t
        -0x5bt
        0x53t
        0x6t
    .end array-data

    nop

    :array_25a
    .array-data 1
        0x20t
        0x2ct
        -0x1at
        0x57t
        0x3t
        -0x7ft
        -0xct
        -0x36t
    .end array-data

    :array_262
    .array-data 1
        0x18t
        -0x67t
        0x6bt
    .end array-data

    :array_268
    .array-data 1
        0x75t
        -0x17t
        0x5ft
        0x50t
        0x7bt
        -0x3bt
        0x69t
        0x1et
    .end array-data

    :array_270
    .array-data 1
        0x20t
        -0x46t
        0x26t
    .end array-data

    :array_276
    .array-data 1
        0x4dt
        -0x2ft
        0x50t
        0xdt
        -0xat
        0x37t
        0x74t
        -0x2et
    .end array-data

    :array_27e
    .array-data 1
        -0x9t
        -0x6ft
        0x6t
    .end array-data

    :array_284
    .array-data 1
        -0x80t
        -0x4t
        0x70t
        0x16t
        0x2t
        0x2dt
        0x78t
        0x47t
    .end array-data

    :array_28c
    .array-data 1
        0x61t
        0x7t
        0x76t
    .end array-data

    :array_292
    .array-data 1
        0x7t
        0x6bt
        0x0t
        -0xdt
        0x17t
        0x46t
        -0x54t
        0x18t
    .end array-data

    :array_29a
    .array-data 1
        0x27t
        0x15t
        0x14t
    .end array-data

    :array_2a0
    .array-data 1
        0x46t
        0x63t
        0x7dt
        0x1t
        -0x10t
        -0x14t
        -0x60t
        0x62t
    .end array-data

    :array_2a8
    .array-data 1
        0x50t
        0x3at
        0x13t
    .end array-data

    :array_2ae
    .array-data 1
        0x39t
        0x49t
        0x7ct
        0x76t
        0x2at
        -0x2et
        -0x4t
        0x66t
    .end array-data

    :array_2b6
    .array-data 1
        -0x3at
        0x38t
        0x46t
    .end array-data

    :array_2bc
    .array-data 1
        -0x55t
        0x48t
        0x21t
        0x2ft
        0x7et
        0xdt
        -0x51t
        -0x1bt
    .end array-data

    :array_2c4
    .array-data 1
        0x47t
        0x59t
    .end array-data

    nop

    :array_2ca
    .array-data 1
        0x33t
        0x2at
        -0x2t
        0x33t
        0x38t
        -0x25t
        0x2ct
        -0x63t
    .end array-data

    :array_2d2
    .array-data 1
        -0x50t
        0x6t
        0x3ft
    .end array-data

    :array_2d8
    .array-data 1
        -0x23t
        0x76t
        0xct
        -0x17t
        0x20t
        -0x2dt
        0x25t
        -0x4et
    .end array-data

    :array_2e0
    .array-data 1
        0x70t
        0x2t
        -0x4at
    .end array-data

    :array_2e6
    .array-data 1
        0x11t
        0x63t
        -0x2bt
        -0x2et
        -0x4dt
        -0xet
        -0x24t
        0x15t
    .end array-data

    :array_2ee
    .array-data 1
        -0x21t
        0x62t
        0x32t
        0x57t
    .end array-data

    :array_2f4
    .array-data 1
        -0x47t
        0xet
        0x53t
        0x34t
        -0x4bt
        -0x15t
        -0x7t
        -0x77t
    .end array-data

    :array_2fc
    .array-data 1
        -0x1dt
        -0x50t
        -0x55t
    .end array-data

    :array_302
    .array-data 1
        -0x72t
        -0x7ct
        -0x36t
        -0x2et
        0x4et
        0x5bt
        -0x2et
        0x12t
    .end array-data

    :array_30a
    .array-data 1
        0x10t
        0x77t
        0x37t
    .end array-data

    :array_310
    .array-data 1
        0x71t
        0x7t
        0x52t
        -0x67t
        0x7et
        -0x49t
        0x49t
        -0x10t
    .end array-data

    :array_318
    .array-data 1
        0x72t
        0x73t
        -0x60t
    .end array-data

    :array_31e
    .array-data 1
        0x1dt
        0x14t
        -0x39t
        0x64t
        -0xat
        -0x5bt
        -0x23t
        0x78t
    .end array-data

    :array_326
    .array-data 1
        0x5at
        0xbt
        -0x7et
    .end array-data

    :array_32c
    .array-data 1
        0x29t
        0x79t
        -0xat
        0x7et
        -0xat
        0x33t
        0x2t
        0x2ft
    .end array-data

    :array_334
    .array-data 1
        -0x2ft
        0x39t
        -0x59t
    .end array-data

    :array_33a
    .array-data 1
        -0x50t
        0x4at
        -0x2ct
        -0xat
        -0x69t
        -0x2t
        -0x3ft
        -0x48t
    .end array-data

    :array_342
    .array-data 1
        0x72t
        -0x5t
        0x22t
    .end array-data

    :array_348
    .array-data 1
        0x1t
        -0x78t
        0x43t
        0x22t
        0x79t
        0xet
        0x43t
        0x10t
    .end array-data

    :array_350
    .array-data 1
        0x72t
        0x58t
        -0x6dt
    .end array-data

    :array_356
    .array-data 1
        0x4t
        0x2ct
        -0x19t
        0x3dt
        -0x80t
        0x60t
        0x5ct
        0x2bt
    .end array-data
.end method

.method public static a(Ljava/lang/String;)Ljava/lang/String;
    .registers 15

    const/4 v0, 0x5

    new-array v1, v0, [B

    fill-array-data v1, :array_aa

    const/16 v2, 0x8

    new-array v3, v2, [B

    fill-array-data v3, :array_b2

    invoke-static {v1, v3}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v1

    const/4 v3, 0x3

    :try_start_12
    new-array v4, v3, [B

    const/16 v5, -0x1c

    const/4 v6, 0x0

    aput-byte v5, v4, v6

    const/16 v5, 0xd

    const/4 v7, 0x1

    aput-byte v5, v4, v7

    const/16 v5, -0x15

    const/4 v8, 0x2

    aput-byte v5, v4, v8

    new-array v5, v2, [B

    const/16 v9, -0x57

    aput-byte v9, v5, v6

    const/16 v9, 0x49

    aput-byte v9, v5, v7

    const/16 v9, -0x22

    aput-byte v9, v5, v8

    const/16 v9, -0x54

    aput-byte v9, v5, v3

    const/16 v9, 0x11

    const/4 v10, 0x4

    aput-byte v9, v5, v10

    const/16 v9, 0x63

    aput-byte v9, v5, v0

    const/16 v9, 0x20

    const/4 v11, 0x6

    aput-byte v9, v5, v11

    const/16 v12, 0x22

    const/4 v13, 0x7

    aput-byte v12, v5, v13

    invoke-static {v4, v5}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-static {v4}, Ljava/security/MessageDigest;->getInstance(Ljava/lang/String;)Ljava/security/MessageDigest;

    move-result-object v4

    invoke-virtual {p0, v1}, Ljava/lang/String;->getBytes(Ljava/lang/String;)[B

    move-result-object p0

    invoke-virtual {v4, p0}, Ljava/security/MessageDigest;->digest([B)[B

    move-result-object p0

    new-instance v1, Ljava/math/BigInteger;

    invoke-direct {v1, v7, p0}, Ljava/math/BigInteger;-><init>(I[B)V

    new-instance p0, Ljava/lang/StringBuilder;

    const/16 v4, 0x10

    invoke-virtual {v1, v4}, Ljava/math/BigInteger;->toString(I)Ljava/lang/String;

    move-result-object v1

    invoke-direct {p0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    :goto_68
    invoke-virtual {p0}, Ljava/lang/StringBuilder;->length()I

    move-result v1

    if-ge v1, v9, :cond_9e

    new-array v1, v7, [B

    const/16 v4, -0xe

    aput-byte v4, v1, v6

    new-array v4, v2, [B

    const/16 v5, -0x3e

    aput-byte v5, v4, v6

    const/16 v5, 0x54

    aput-byte v5, v4, v7

    const/16 v5, -0x68

    aput-byte v5, v4, v8

    const/16 v5, -0x53

    aput-byte v5, v4, v3

    const/16 v5, -0x58

    aput-byte v5, v4, v10

    const/16 v5, 0x9

    aput-byte v5, v4, v0

    const/16 v5, 0x1d

    aput-byte v5, v4, v11

    const/16 v5, 0x3f

    aput-byte v5, v4, v13

    invoke-static {v1, v4}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {p0, v6, v1}, Ljava/lang/StringBuilder;->insert(ILjava/lang/String;)Ljava/lang/StringBuilder;

    goto :goto_68

    :cond_9e
    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-virtual {p0}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object p0
    :try_end_a6
    .catch Ljava/lang/Exception; {:try_start_12 .. :try_end_a6} :catch_a7

    goto :goto_a9

    :catch_a7
    const-string p0, ""

    :goto_a9
    return-object p0

    :array_aa
    .array-data 1
        0x64t
        0x19t
        -0x39t
        -0x2dt
        -0x1bt
    .end array-data

    nop

    :array_b2
    .array-data 1
        0x31t
        0x4dt
        -0x7ft
        -0x2t
        -0x23t
        0x1et
        0x14t
        -0x3at
    .end array-data
.end method

.method public static b(Ljava/lang/String;)Ljava/lang/String;
    .registers 12

    const/4 v0, 0x7

    :try_start_1
    new-array v1, v0, [B

    const/16 v2, -0x12

    const/4 v3, 0x0

    aput-byte v2, v1, v3

    const/16 v2, 0x6a

    const/4 v4, 0x1

    aput-byte v2, v1, v4

    const/16 v2, 0x33

    const/4 v5, 0x2

    aput-byte v2, v1, v5

    const/4 v2, 0x3

    const/4 v6, 0x5

    aput-byte v6, v1, v2

    const/16 v7, 0x73

    const/4 v8, 0x4

    aput-byte v7, v1, v8

    const/16 v7, 0x37

    aput-byte v7, v1, v6

    const/16 v7, -0x18

    const/4 v9, 0x6

    aput-byte v7, v1, v9

    const/16 v7, 0x8

    new-array v7, v7, [B

    const/16 v10, -0x43

    aput-byte v10, v7, v3

    const/16 v10, 0x22

    aput-byte v10, v7, v4

    const/16 v10, 0x72

    aput-byte v10, v7, v5

    const/16 v10, 0x28

    aput-byte v10, v7, v2

    const/16 v2, 0x41

    aput-byte v2, v7, v8

    aput-byte v5, v7, v6

    const/16 v2, -0x22

    aput-byte v2, v7, v9

    const/16 v2, -0x3e

    aput-byte v2, v7, v0

    invoke-static {v1, v7}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Ljava/security/MessageDigest;->getInstance(Ljava/lang/String;)Ljava/security/MessageDigest;

    move-result-object v0

    invoke-virtual {p0}, Ljava/lang/String;->getBytes()[B

    move-result-object p0

    invoke-virtual {v0, p0}, Ljava/security/MessageDigest;->digest([B)[B

    move-result-object p0

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    array-length v1, p0

    :goto_5c
    if-ge v3, v1, :cond_77

    aget-byte v2, p0, v3

    and-int/lit16 v2, v2, 0xff

    invoke-static {v2}, Ljava/lang/Integer;->toHexString(I)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/String;->length()I

    move-result v5

    if-ne v5, v4, :cond_71

    const/16 v5, 0x30

    invoke-virtual {v0, v5}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    :cond_71
    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    add-int/lit8 v3, v3, 0x1

    goto :goto_5c

    :cond_77
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0
    :try_end_7b
    .catch Ljava/security/NoSuchAlgorithmException; {:try_start_1 .. :try_end_7b} :catch_7c

    return-object p0

    :catch_7c
    const-string p0, ""

    return-object p0
.end method

.method public static c(Ljava/lang/String;)V
    .registers 3

    new-instance v0, Ljava/io/File;

    invoke-static {}, Lcom/github/catvod/spider/Init;->context()Landroid/app/Application;

    move-result-object v1

    invoke-virtual {v1}, Landroid/content/Context;->getFilesDir()Ljava/io/File;

    move-result-object v1

    invoke-direct {v0, v1, p0}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    :try_start_d
    invoke-virtual {v0}, Ljava/io/File;->exists()Z

    move-result p0

    if-eqz p0, :cond_16

    invoke-virtual {v0}, Ljava/io/File;->delete()Z
    :try_end_16
    .catch Ljava/lang/Exception; {:try_start_d .. :try_end_16} :catch_16

    :catch_16
    :cond_16
    return-void
.end method

.method public static d()Ljava/lang/String;
    .registers 9

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v0

    invoke-static {v0, v1}, Ljava/lang/Long;->toString(J)Ljava/lang/String;

    move-result-object v0

    const/4 v1, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x0

    :goto_b
    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v4

    const/4 v5, 0x1

    if-ge v2, v4, :cond_2d

    invoke-virtual {v0, v2}, Ljava/lang/String;->charAt(I)C

    move-result v4

    add-int/lit8 v4, v4, -0x30

    add-int/lit8 v2, v2, 0x1

    const/4 v6, 0x2

    if-gt v2, v6, :cond_1e

    goto :goto_29

    :cond_1e
    const/4 v6, 0x1

    const/4 v7, 0x3

    :goto_20
    if-gt v7, v2, :cond_29

    add-int/2addr v6, v5

    add-int/lit8 v7, v7, 0x1

    move v8, v6

    move v6, v5

    move v5, v8

    goto :goto_20

    :cond_29
    :goto_29
    mul-int v4, v4, v5

    add-int/2addr v3, v4

    goto :goto_b

    :cond_2d
    rem-int/lit16 v3, v3, 0x3e8

    const/4 v2, 0x4

    new-array v2, v2, [B

    fill-array-data v2, :array_52

    const/16 v4, 0x8

    new-array v4, v4, [B

    fill-array-data v4, :array_58

    invoke-static {v2, v4}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v2

    new-array v4, v5, [Ljava/lang/Object;

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    aput-object v3, v4, v1

    invoke-static {v2, v4}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    .line 1
    invoke-static {v0, v1}, Lcom/github/catvod/spider/appysv2/b/y;->a(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    return-object v0

    nop

    :array_52
    .array-data 1
        -0x45t
        0x47t
        0x31t
        -0x75t
    .end array-data

    :array_58
    .array-data 1
        -0x62t
        0x77t
        0x2t
        -0x11t
        0x3et
        -0x6t
        0x4bt
        0x23t
    .end array-data
.end method

.method public static e()Lcom/github/catvod/spider/appysv2/c/k;
    .registers 5

    new-instance v0, Lcom/github/catvod/spider/appysv2/c/k;

    invoke-direct {v0}, Lcom/github/catvod/spider/appysv2/c/k;-><init>()V

    const/4 v1, 0x5

    new-array v1, v1, [B

    fill-array-data v1, :array_88

    const/16 v2, 0x8

    new-array v3, v2, [B

    fill-array-data v3, :array_90

    invoke-static {v1, v3}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/github/catvod/spider/appysv2/c/k;->g(Ljava/lang/String;)V

    const/4 v1, 0x6

    new-array v3, v1, [B

    fill-array-data v3, :array_98

    new-array v4, v2, [B

    fill-array-data v4, :array_a0

    invoke-static {v3, v4}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v0, v3}, Lcom/github/catvod/spider/appysv2/c/k;->e(Ljava/lang/String;)V

    new-array v1, v1, [B

    fill-array-data v1, :array_a8

    new-array v3, v2, [B

    fill-array-data v3, :array_b0

    invoke-static {v1, v3}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/github/catvod/spider/appysv2/c/k;->i(Ljava/lang/String;)V

    const/16 v1, 0x9

    new-array v3, v1, [B

    fill-array-data v3, :array_b8

    new-array v4, v2, [B

    fill-array-data v4, :array_c2

    invoke-static {v3, v4}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v0, v3}, Lcom/github/catvod/spider/appysv2/c/k;->h(Ljava/lang/String;)V

    const/16 v3, 0x75

    new-array v3, v3, [B

    fill-array-data v3, :array_ca

    new-array v4, v2, [B

    fill-array-data v4, :array_10a

    invoke-static {v3, v4}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v0, v3}, Lcom/github/catvod/spider/appysv2/c/k;->k(Ljava/lang/String;)V

    const/16 v3, 0x12

    new-array v3, v3, [B

    fill-array-data v3, :array_112

    new-array v4, v2, [B

    fill-array-data v4, :array_120

    invoke-static {v3, v4}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v0, v3}, Lcom/github/catvod/spider/appysv2/c/k;->j(Ljava/lang/String;)V

    new-array v1, v1, [B

    fill-array-data v1, :array_128

    new-array v2, v2, [B

    fill-array-data v2, :array_132

    invoke-static {v1, v2}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/github/catvod/spider/appysv2/c/k;->b(Ljava/lang/String;)V

    return-object v0

    nop

    :array_88
    .array-data 1
        -0x77t
        -0x29t
        -0x4ct
        -0x75t
        0x69t
    .end array-data

    nop

    :array_90
    .array-data 1
        -0x48t
        -0x19t
        -0x7ct
        -0x4dt
        0x5ft
        0x6bt
        0x20t
        0x3at
    .end array-data

    :array_98
    .array-data 1
        0x43t
        0x44t
        0x34t
        0x5ct
        0x5bt
        -0x29t
    .end array-data

    nop

    :array_a0
    .array-data 1
        0x25t
        0x2dt
        0x58t
        0x39t
        0x12t
        -0x4dt
        -0x55t
        0x74t
    .end array-data

    :array_a8
    .array-data 1
        -0x61t
        0x69t
        -0x43t
        -0x76t
        -0x5et
        0x2et
    .end array-data

    nop

    :array_b0
    .array-data 1
        -0x7t
        0x0t
        -0x2ft
        -0x11t
        -0x15t
        0x4at
        0x74t
        -0x22t
    .end array-data

    :array_b8
    .array-data 1
        0x41t
        -0x49t
        0x46t
        0x33t
        0x2at
        -0x2bt
        -0x31t
        -0x15t
        0x2ct
    .end array-data

    nop

    :array_c2
    .array-data 1
        -0x5ct
        0x0t
        -0xct
        -0x2at
        -0x72t
        0x64t
        0x29t
        0x7et
    .end array-data

    :array_ca
    .array-data 1
        0x74t
        -0x4ft
        -0x37t
        -0xat
        0x24t
        -0x71t
        0x47t
        -0x58t
        0x23t
        -0x24t
        -0x15t
        -0x5dt
        0x78t
        -0x4ft
        0x2at
        -0x7t
        0x19t
        -0x51t
        -0x56t
        -0x69t
        0x28t
        -0x40t
        0x19t
        -0x77t
        0x74t
        -0x49t
        -0x30t
        -0x9t
        0x5t
        -0x7ct
        0x46t
        -0x59t
        0x1ct
        -0x24t
        -0x40t
        -0x43t
        0x79t
        -0x50t
        0xat
        0x3bt
        -0x7t
        0x4dt
        0x3bt
        0x62t
        -0x13t
        0x1et
        -0x73t
        0x30t
        -0xdt
        0x58t
        0x26t
        0x76t
        -0x15t
        0xat
        -0x3ft
        0x70t
        -0x4t
        0x1dt
        0x6bt
        0x36t
        0x7bt
        -0x54t
        0x24t
        -0x5t
        0x2bt
        -0x6et
        -0x56t
        -0x5bt
        0x2ct
        -0x3ft
        0x6t
        -0x52t
        0x77t
        -0x54t
        -0x39t
        -0xct
        0x16t
        -0x4et
        0x47t
        -0x66t
        0x27t
        -0x23t
        -0xct
        -0x7ct
        0x7bt
        -0x56t
        0x3dt
        -0x6t
        0xat
        -0x67t
        -0x55t
        -0x56t
        0x13t
        -0x3ft
        0x2dt
        -0x50t
        0x76t
        -0x53t
        -0x19t
        0x36t
        -0xat
        0x50t
        -0x2at
        0x6ft
        -0x1et
        0x3t
        0x60t
        0x3dt
        -0x4t
        0x45t
        -0x35t
        0x7bt
        -0x1ct
        0x17t
        0x2ct
        0x7dt
        -0xdt
    .end array-data

    nop

    :array_10a
    .array-data 1
        -0x6ft
        0x39t
        0x4ft
        0x12t
        -0x62t
        0x24t
        -0x5et
        0x1ft
    .end array-data

    :array_112
    .array-data 1
        -0x5ct
        -0x5dt
        -0x49t
        0x3at
        0x44t
        -0xct
        0x57t
        -0x2dt
        -0x2ct
        -0x26t
        -0x6bt
        0x62t
        0x22t
        -0xat
        0x36t
        -0x46t
        -0x8t
        -0x51t
    .end array-data

    nop

    :array_120
    .array-data 1
        0x42t
        0x3ft
        0x1dt
        -0x2et
        -0x36t
        0x43t
        -0x4et
        0x5ct
    .end array-data

    :array_128
    .array-data 1
        -0xet
        0x2bt
        0x1bt
        -0x40t
        0x55t
        0x3bt
        -0x3ct
        0x7et
        0x5bt
    .end array-data

    nop

    :array_132
    .array-data 1
        -0x3dt
        0x19t
        0x28t
        0x24t
        -0x11t
        -0x56t
        0x23t
        -0x1bt
    .end array-data
.end method

.method public static f(Ljava/lang/String;)Ljava/lang/String;
    .registers 6

    const/4 v0, 0x1

    new-array v1, v0, [B

    const/16 v2, -0x32

    const/4 v3, 0x0

    aput-byte v2, v1, v3

    const/16 v2, 0x8

    new-array v4, v2, [B

    fill-array-data v4, :array_32

    invoke-static {v1, v4}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {p0, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-eqz v1, :cond_31

    new-array v1, v0, [B

    const/16 v4, 0x58

    aput-byte v4, v1, v3

    new-array v2, v2, [B

    fill-array-data v2, :array_3a

    invoke-static {v1, v2}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {p0, v1}, Ljava/lang/String;->lastIndexOf(Ljava/lang/String;)I

    move-result v1

    add-int/2addr v1, v0

    invoke-virtual {p0, v1}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object p0

    :cond_31
    return-object p0

    :array_32
    .array-data 1
        -0x20t
        0x70t
        -0x63t
        -0x35t
        0x43t
        0x0t
        -0x7t
        0x7et
    .end array-data

    :array_3a
    .array-data 1
        0x76t
        -0x59t
        -0x3bt
        -0x66t
        -0x54t
        0x4dt
        0x7ft
        0x13t
    .end array-data
.end method

.method public static g(Landroid/content/Context;)Ljava/lang/String;
    .registers 16
    .annotation build Landroid/annotation/SuppressLint;
        value = {
            "DefaultLocale"
        }
    .end annotation

    const/4 v0, 0x4

    new-array v1, v0, [B

    fill-array-data v1, :array_124

    const/16 v2, 0x8

    new-array v3, v2, [B

    fill-array-data v3, :array_12a

    invoke-static {v1, v3}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {p0, v1}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Landroid/net/wifi/WifiManager;

    invoke-virtual {p0}, Landroid/net/wifi/WifiManager;->getConnectionInfo()Landroid/net/wifi/WifiInfo;

    move-result-object p0

    invoke-virtual {p0}, Landroid/net/wifi/WifiInfo;->getIpAddress()I

    move-result p0

    const/4 v1, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x0

    if-nez p0, :cond_e7

    const/4 p0, 0x7

    :try_start_26
    invoke-static {}, Ljava/net/NetworkInterface;->getNetworkInterfaces()Ljava/util/Enumeration;

    move-result-object v6

    :cond_2a
    invoke-interface {v6}, Ljava/util/Enumeration;->hasMoreElements()Z

    move-result v7

    if-eqz v7, :cond_d8

    invoke-interface {v6}, Ljava/util/Enumeration;->nextElement()Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Ljava/net/NetworkInterface;

    invoke-virtual {v7}, Ljava/net/NetworkInterface;->getDisplayName()Ljava/lang/String;

    move-result-object v8

    new-array v9, v0, [B

    const/16 v10, -0x21

    aput-byte v10, v9, v5

    const/16 v10, 0x47

    aput-byte v10, v9, v4

    const/16 v11, -0x5f

    aput-byte v11, v9, v3

    const/16 v12, 0x14

    aput-byte v12, v9, v1

    new-array v12, v2, [B

    const/16 v13, -0x46

    aput-byte v13, v12, v5

    const/16 v13, 0x33

    aput-byte v13, v12, v4

    const/16 v13, -0x37

    aput-byte v13, v12, v3

    const/16 v13, 0x24

    aput-byte v13, v12, v1

    aput-byte v11, v12, v0

    const/16 v11, 0x52

    const/4 v13, 0x5

    aput-byte v11, v12, v13

    const/16 v11, -0x62

    const/4 v14, 0x6

    aput-byte v11, v12, v14

    const/16 v11, 0x63

    aput-byte v11, v12, p0

    invoke-static {v9, v12}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v8, v9}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v9

    if-nez v9, :cond_b5

    new-array v9, v13, [B

    const/16 v12, 0x30

    aput-byte v12, v9, v5

    const/16 v12, -0x6e

    aput-byte v12, v9, v4

    const/16 v12, -0x1d

    aput-byte v12, v9, v3

    const/16 v12, -0x20

    aput-byte v12, v9, v1

    aput-byte v11, v9, v0

    new-array v11, v2, [B

    aput-byte v10, v11, v5

    const/4 v10, -0x2

    aput-byte v10, v11, v4

    const/16 v10, -0x7e

    aput-byte v10, v11, v3

    const/16 v10, -0x72

    aput-byte v10, v11, v1

    const/16 v10, 0x53

    aput-byte v10, v11, v0

    const/16 v10, 0x1a

    aput-byte v10, v11, v13

    const/16 v10, 0x2d

    aput-byte v10, v11, v14

    const/16 v10, 0x42

    aput-byte v10, v11, p0

    invoke-static {v9, v11}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v8, v9}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v8

    if-eqz v8, :cond_2a

    :cond_b5
    invoke-virtual {v7}, Ljava/net/NetworkInterface;->getInetAddresses()Ljava/util/Enumeration;

    move-result-object v7

    :cond_b9
    invoke-interface {v7}, Ljava/util/Enumeration;->hasMoreElements()Z

    move-result v8

    if-eqz v8, :cond_2a

    invoke-interface {v7}, Ljava/util/Enumeration;->nextElement()Ljava/lang/Object;

    move-result-object v8

    check-cast v8, Ljava/net/InetAddress;

    invoke-virtual {v8}, Ljava/net/InetAddress;->isLoopbackAddress()Z

    move-result v9

    if-nez v9, :cond_b9

    instance-of v9, v8, Ljava/net/Inet4Address;

    if-eqz v9, :cond_b9

    invoke-virtual {v8}, Ljava/net/InetAddress;->getHostAddress()Ljava/lang/String;

    move-result-object p0
    :try_end_d3
    .catch Ljava/net/SocketException; {:try_start_26 .. :try_end_d3} :catch_d4

    return-object p0

    :catch_d4
    move-exception v0

    invoke-virtual {v0}, Ljava/lang/Throwable;->printStackTrace()V

    :cond_d8
    new-array p0, p0, [B

    fill-array-data p0, :array_132

    new-array v0, v2, [B

    fill-array-data v0, :array_13a

    invoke-static {p0, v0}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object p0

    return-object p0

    :cond_e7
    const/16 v6, 0xb

    new-array v6, v6, [B

    fill-array-data v6, :array_142

    new-array v2, v2, [B

    fill-array-data v2, :array_14c

    invoke-static {v6, v2}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v2

    new-array v0, v0, [Ljava/lang/Object;

    and-int/lit16 v6, p0, 0xff

    invoke-static {v6}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v6

    aput-object v6, v0, v5

    shr-int/lit8 v5, p0, 0x8

    and-int/lit16 v5, v5, 0xff

    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    aput-object v5, v0, v4

    shr-int/lit8 v4, p0, 0x10

    and-int/lit16 v4, v4, 0xff

    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    aput-object v4, v0, v3

    shr-int/lit8 p0, p0, 0x18

    and-int/lit16 p0, p0, 0xff

    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p0

    aput-object p0, v0, v1

    invoke-static {v2, v0}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p0

    return-object p0

    :array_124
    .array-data 1
        0x40t
        -0x61t
        0x3at
        0x5ct
    .end array-data

    :array_12a
    .array-data 1
        0x37t
        -0xat
        0x5ct
        0x35t
        -0x74t
        -0x5dt
        -0x32t
        0x70t
    .end array-data

    :array_132
    .array-data 1
        -0x56t
        -0x48t
        0x69t
        -0x58t
        -0x6bt
        0x2bt
        -0x75t
    .end array-data

    :array_13a
    .array-data 1
        -0x66t
        -0x6at
        0x59t
        -0x7at
        -0x5bt
        0x5t
        -0x45t
        0x33t
    .end array-data

    :array_142
    .array-data 1
        -0x5et
        -0x5et
        0x9t
        -0x80t
        0x48t
        -0x17t
        -0x71t
        0x56t
        -0x57t
        -0x1dt
        0x43t
    .end array-data

    :array_14c
    .array-data 1
        -0x79t
        -0x3at
        0x27t
        -0x5bt
        0x2ct
        -0x39t
        -0x56t
        0x32t
    .end array-data
.end method

.method public static h(Ljava/lang/String;Ljava/util/Map;)Lorg/json/JSONObject;
    .registers 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;)",
            "Lorg/json/JSONObject;"
        }
    .end annotation

    invoke-static {}, Ljava/util/Calendar;->getInstance()Ljava/util/Calendar;

    move-result-object v0

    new-instance v1, Ljava/text/SimpleDateFormat;

    const/16 v2, 0x8

    new-array v3, v2, [B

    fill-array-data v3, :array_6c

    new-array v4, v2, [B

    fill-array-data v4, :array_74

    invoke-static {v3, v4}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v3

    invoke-direct {v1, v3}, Ljava/text/SimpleDateFormat;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0}, Ljava/util/Calendar;->getTime()Ljava/util/Date;

    move-result-object v0

    invoke-virtual {v1, v0}, Ljava/text/DateFormat;->format(Ljava/util/Date;)Ljava/lang/String;

    move-result-object v0

    const/16 v1, 0x21

    new-array v1, v1, [B

    fill-array-data v1, :array_7c

    new-array v3, v2, [B

    fill-array-data v3, :array_92

    invoke-static {v1, v3}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v1

    const/4 v3, 0x2

    new-array v3, v3, [Ljava/lang/Object;

    const/4 v4, 0x0

    aput-object p0, v3, v4

    const/4 p0, 0x1

    aput-object v0, v3, p0

    invoke-static {v1, v3}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p0

    invoke-static {p0, p1}, Lcom/github/catvod/spider/appysv2/n/c;->m(Ljava/lang/String;Ljava/util/Map;)Ljava/lang/String;

    move-result-object p0

    new-instance p1, Lorg/json/JSONObject;

    const/16 v0, 0x1c

    new-array v0, v0, [B

    fill-array-data v0, :array_9a

    new-array v1, v2, [B

    fill-array-data v1, :array_ac

    invoke-static {v0, v1}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v0

    const/16 v1, 0x10

    new-array v1, v1, [B

    fill-array-data v1, :array_b4

    new-array v2, v2, [B

    fill-array-data v2, :array_c0

    invoke-static {v1, v2}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-static {p0, v0, v1}, Lcom/github/catvod/spider/appysv2/D/h;->k(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    invoke-direct {p1, p0}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    return-object p1

    :array_6c
    .array-data 1
        0x3bt
        -0x66t
        -0x5ft
        -0x4bt
        0x35t
        0x45t
        -0x15t
        0x19t
    .end array-data

    :array_74
    .array-data 1
        0x42t
        -0x1dt
        -0x28t
        -0x34t
        0x78t
        0x8t
        -0x71t
        0x7dt
    .end array-data

    :array_7c
    .array-data 1
        -0x63t
        -0x4ft
        -0x73t
        -0x12t
        0x11t
        -0x13t
        0x5ct
        0x34t
        -0x25t
        -0x13t
        -0x38t
        -0x12t
        0x4at
        -0x4t
        0x44t
        0x3ct
        -0x3ft
        -0x59t
        -0x30t
        -0x2t
        0xat
        -0x1et
        0x4et
        0x34t
        -0x21t
        -0x14t
        -0x38t
        -0x12t
        0x5at
        -0x8t
        0x15t
        0x78t
        -0x35t
    .end array-data

    nop

    :array_92
    .array-data 1
        -0x48t
        -0x3et
        -0x5et
        -0x63t
        0x65t
        -0x74t
        0x28t
        0x5dt
    .end array-data

    :array_9a
    .array-data 1
        0x3bt
        0x1dt
        0x1t
        0x39t
        0x3at
        0x73t
        0xdt
        -0x62t
        0x4t
        0x3ft
        0xdt
        0x7t
        0x30t
        0x7bt
        0x13t
        -0x2bt
        0x6t
        0x10t
        0x3t
        0x10t
        0x33t
        0x60t
        0x2bt
        -0x69t
        0x1ft
        0xft
        0x16t
        0x54t
    .end array-data

    :array_ac
    .array-data 1
        0x76t
        0x7ct
        0x62t
        0x69t
        0x56t
        0x12t
        0x74t
        -0x5t
    .end array-data

    :array_b4
    .array-data 1
        -0x20t
        0x11t
        -0x1et
        -0x6t
        -0x65t
        0x48t
        0x16t
        0x17t
        -0x57t
        0x2et
        -0x40t
        -0xat
        -0x5bt
        0x42t
        0x1et
        0x9t
    .end array-data

    :array_c0
    .array-data 1
        -0x34t
        0x5ct
        -0x7dt
        -0x67t
        -0x35t
        0x24t
        0x77t
        0x6et
    .end array-data
.end method

.method public static i(D)Ljava/lang/String;
    .registers 10

    const-wide/16 v0, 0x0

    cmpg-double v2, p0, v0

    if-gtz v2, :cond_9

    const-string p0, ""

    return-object p0

    :cond_9
    const-wide/high16 v0, 0x4270000000000000L  # 1.099511627776E12

    const/4 v2, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x2

    const/16 v6, 0x8

    cmpl-double v7, p0, v0

    if-lez v7, :cond_45

    div-double/2addr p0, v0

    invoke-static {}, Ljava/util/Locale;->getDefault()Ljava/util/Locale;

    move-result-object v0

    new-array v1, v4, [B

    fill-array-data v1, :array_e4

    new-array v4, v6, [B

    fill-array-data v4, :array_ec

    invoke-static {v1, v4}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v1

    new-array v4, v5, [Ljava/lang/Object;

    invoke-static {p0, p1}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object p0

    aput-object p0, v4, v3

    new-array p0, v5, [B

    fill-array-data p0, :array_f4

    new-array p1, v6, [B

    fill-array-data p1, :array_fa

    invoke-static {p0, p1}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object p0

    aput-object p0, v4, v2

    invoke-static {v0, v1, v4}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p0

    return-object p0

    :cond_45
    const-wide/high16 v0, 0x41d0000000000000L  # 1.073741824E9

    cmpl-double v7, p0, v0

    if-lez v7, :cond_7b

    div-double/2addr p0, v0

    invoke-static {}, Ljava/util/Locale;->getDefault()Ljava/util/Locale;

    move-result-object v0

    new-array v1, v4, [B

    fill-array-data v1, :array_102

    new-array v4, v6, [B

    fill-array-data v4, :array_10a

    invoke-static {v1, v4}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v1

    new-array v4, v5, [Ljava/lang/Object;

    invoke-static {p0, p1}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object p0

    aput-object p0, v4, v3

    new-array p0, v5, [B

    fill-array-data p0, :array_112

    new-array p1, v6, [B

    fill-array-data p1, :array_118

    invoke-static {p0, p1}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object p0

    aput-object p0, v4, v2

    invoke-static {v0, v1, v4}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p0

    return-object p0

    :cond_7b
    const-wide/high16 v0, 0x4130000000000000L  # 1048576.0

    cmpl-double v7, p0, v0

    if-lez v7, :cond_b1

    div-double/2addr p0, v0

    invoke-static {}, Ljava/util/Locale;->getDefault()Ljava/util/Locale;

    move-result-object v0

    new-array v1, v4, [B

    fill-array-data v1, :array_120

    new-array v4, v6, [B

    fill-array-data v4, :array_128

    invoke-static {v1, v4}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v1

    new-array v4, v5, [Ljava/lang/Object;

    invoke-static {p0, p1}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object p0

    aput-object p0, v4, v3

    new-array p0, v5, [B

    fill-array-data p0, :array_130

    new-array p1, v6, [B

    fill-array-data p1, :array_136

    invoke-static {p0, p1}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object p0

    aput-object p0, v4, v2

    invoke-static {v0, v1, v4}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p0

    return-object p0

    :cond_b1
    const-wide/high16 v0, 0x4090000000000000L  # 1024.0

    div-double/2addr p0, v0

    invoke-static {}, Ljava/util/Locale;->getDefault()Ljava/util/Locale;

    move-result-object v0

    new-array v1, v4, [B

    fill-array-data v1, :array_13e

    new-array v4, v6, [B

    fill-array-data v4, :array_146

    invoke-static {v1, v4}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v1

    new-array v4, v5, [Ljava/lang/Object;

    invoke-static {p0, p1}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object p0

    aput-object p0, v4, v3

    new-array p0, v5, [B

    fill-array-data p0, :array_14e

    new-array p1, v6, [B

    fill-array-data p1, :array_154

    invoke-static {p0, p1}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object p0

    aput-object p0, v4, v2

    invoke-static {v0, v1, v4}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p0

    return-object p0

    nop

    :array_e4
    .array-data 1
        -0x3bt
        0x19t
        -0x3ft
        -0x48t
        -0x37t
        -0x77t
    .end array-data

    nop

    :array_ec
    .array-data 1
        -0x20t
        0x37t
        -0xdt
        -0x22t
        -0x14t
        -0x6t
        -0x61t
        -0x16t
    .end array-data

    :array_f4
    .array-data 1
        -0x2ft
        -0x4t
    .end array-data

    nop

    :array_fa
    .array-data 1
        -0x7bt
        -0x42t
        0x45t
        -0x6t
        0x6bt
        -0x2et
        0x78t
        0x45t
    .end array-data

    :array_102
    .array-data 1
        -0x12t
        0x7dt
        0x4dt
        -0x2bt
        0x62t
        0x1bt
    .end array-data

    nop

    :array_10a
    .array-data 1
        -0x35t
        0x53t
        0x7ft
        -0x4dt
        0x47t
        0x68t
        0x19t
        -0x1dt
    .end array-data

    :array_112
    .array-data 1
        0x4et
        0x37t
    .end array-data

    nop

    :array_118
    .array-data 1
        0x9t
        0x75t
        0x25t
        0x15t
        0x39t
        0x79t
        0x1at
        -0x6et
    .end array-data

    :array_120
    .array-data 1
        -0x1at
        -0x32t
        0x1et
        -0x1at
        -0x35t
        -0x5ct
    .end array-data

    nop

    :array_128
    .array-data 1
        -0x3dt
        -0x20t
        0x2ct
        -0x80t
        -0x12t
        -0x29t
        0x29t
        0x33t
    .end array-data

    :array_130
    .array-data 1
        0x2ft
        0x54t
    .end array-data

    nop

    :array_136
    .array-data 1
        0x62t
        0x16t
        -0x19t
        0x29t
        -0x23t
        0x4bt
        0x5dt
        -0x1dt
    .end array-data

    :array_13e
    .array-data 1
        -0x58t
        -0x17t
        -0x7at
        -0x31t
        -0x12t
        0x78t
    .end array-data

    nop

    :array_146
    .array-data 1
        -0x73t
        -0x39t
        -0x4ct
        -0x57t
        -0x35t
        0xbt
        0x66t
        0x11t
    .end array-data

    :array_14e
    .array-data 1
        -0x44t
        -0x65t
    .end array-data

    nop

    :array_154
    .array-data 1
        -0x9t
        -0x27t
        0x4t
        -0x55t
        -0x27t
        -0x7ct
        0x52t
        -0x35t
    .end array-data
.end method

.method public static j()J
    .registers 3

    invoke-static {}, Ljava/util/TimeZone;->getDefault()Ljava/util/TimeZone;

    move-result-object v0

    invoke-static {v0}, Ljava/util/Calendar;->getInstance(Ljava/util/TimeZone;)Ljava/util/Calendar;

    move-result-object v0

    const/16 v1, 0xb

    const/4 v2, 0x0

    invoke-virtual {v0, v1, v2}, Ljava/util/Calendar;->set(II)V

    const/16 v1, 0xc

    invoke-virtual {v0, v1, v2}, Ljava/util/Calendar;->set(II)V

    const/16 v1, 0xd

    invoke-virtual {v0, v1, v2}, Ljava/util/Calendar;->set(II)V

    const/16 v1, 0xe

    invoke-virtual {v0, v1, v2}, Ljava/util/Calendar;->set(II)V

    invoke-virtual {v0}, Ljava/util/Calendar;->getTimeInMillis()J

    move-result-wide v0

    return-wide v0
.end method

.method public static k()Ljava/util/ArrayList;
    .registers 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/ArrayList<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    const/16 v1, 0x9

    new-array v2, v1, [B

    fill-array-data v2, :array_180

    const/16 v3, 0x8

    new-array v4, v3, [B

    fill-array-data v4, :array_18a

    invoke-static {v2, v4}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    const/16 v2, 0xf

    new-array v4, v2, [B

    fill-array-data v4, :array_192

    new-array v5, v3, [B

    fill-array-data v5, :array_19e

    invoke-static {v4, v5}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v0, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    const/16 v4, 0x10

    new-array v4, v4, [B

    fill-array-data v4, :array_1a6

    new-array v5, v3, [B

    fill-array-data v5, :array_1b2

    invoke-static {v4, v5}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v0, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    new-array v2, v2, [B

    fill-array-data v2, :array_1ba

    new-array v4, v3, [B

    fill-array-data v4, :array_1c6

    invoke-static {v2, v4}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    const/16 v2, 0xe

    new-array v2, v2, [B

    fill-array-data v2, :array_1ce

    new-array v4, v3, [B

    fill-array-data v4, :array_1da

    invoke-static {v2, v4}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    const/16 v2, 0xb

    new-array v2, v2, [B

    fill-array-data v2, :array_1e2

    new-array v4, v3, [B

    fill-array-data v4, :array_1ec

    invoke-static {v2, v4}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    const/16 v2, 0xa

    new-array v4, v2, [B

    fill-array-data v4, :array_1f4

    new-array v5, v3, [B

    fill-array-data v5, :array_1fe

    invoke-static {v4, v5}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v0, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    new-array v4, v2, [B

    fill-array-data v4, :array_206

    new-array v5, v3, [B

    fill-array-data v5, :array_210

    invoke-static {v4, v5}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v0, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    new-array v4, v2, [B

    fill-array-data v4, :array_218

    new-array v5, v3, [B

    fill-array-data v5, :array_222

    invoke-static {v4, v5}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v0, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    new-array v4, v1, [B

    fill-array-data v4, :array_22a

    new-array v5, v3, [B

    fill-array-data v5, :array_234

    invoke-static {v4, v5}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v0, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    new-array v4, v2, [B

    fill-array-data v4, :array_23c

    new-array v5, v3, [B

    fill-array-data v5, :array_246

    invoke-static {v4, v5}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v0, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    const/16 v4, 0x1c

    new-array v4, v4, [B

    fill-array-data v4, :array_24e

    new-array v5, v3, [B

    fill-array-data v5, :array_260

    invoke-static {v4, v5}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v0, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    const/16 v4, 0x16

    new-array v4, v4, [B

    fill-array-data v4, :array_268

    new-array v5, v3, [B

    fill-array-data v5, :array_278

    invoke-static {v4, v5}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v0, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    const/16 v4, 0xd

    new-array v4, v4, [B

    fill-array-data v4, :array_280

    new-array v5, v3, [B

    fill-array-data v5, :array_28c

    invoke-static {v4, v5}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v0, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    new-array v4, v2, [B

    fill-array-data v4, :array_294

    new-array v5, v3, [B

    fill-array-data v5, :array_29e

    invoke-static {v4, v5}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v0, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    new-array v4, v2, [B

    fill-array-data v4, :array_2a6

    new-array v5, v3, [B

    fill-array-data v5, :array_2b0

    invoke-static {v4, v5}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v0, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    new-array v4, v1, [B

    fill-array-data v4, :array_2b8

    new-array v5, v3, [B

    fill-array-data v5, :array_2c2

    invoke-static {v4, v5}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v0, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    new-array v4, v1, [B

    fill-array-data v4, :array_2ca

    new-array v5, v3, [B

    fill-array-data v5, :array_2d4

    invoke-static {v4, v5}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v0, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    new-array v4, v2, [B

    fill-array-data v4, :array_2dc

    new-array v5, v3, [B

    fill-array-data v5, :array_2e6

    invoke-static {v4, v5}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v0, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    new-array v2, v2, [B

    fill-array-data v2, :array_2ee

    new-array v4, v3, [B

    fill-array-data v4, :array_2f8

    invoke-static {v2, v4}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    new-array v1, v1, [B

    fill-array-data v1, :array_300

    new-array v2, v3, [B

    fill-array-data v2, :array_30a

    invoke-static {v1, v2}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    return-object v0

    nop

    :array_180
    .array-data 1
        0xat
        -0x7et
        -0xat
        0x5ct
        -0x3et
        -0x50t
        0x53t
        -0x35t
        0x48t
    .end array-data

    nop

    :array_18a
    .array-data 1
        0x7ct
        -0x15t
        -0x6et
        0x39t
        -0x53t
        -0x61t
        0x3et
        -0x45t
    .end array-data

    :array_192
    .array-data 1
        -0x9t
        -0x6ft
        -0xbt
        -0x18t
        0x3at
        -0x37t
        -0x54t
        0x17t
        -0x14t
        -0x75t
        -0x19t
        -0x1ct
        0x31t
        -0x7dt
        -0x45t
    .end array-data

    :array_19e
    .array-data 1
        -0x7ft
        -0x8t
        -0x6ft
        -0x73t
        0x55t
        -0x1at
        -0x2ct
        0x3at
    .end array-data

    :array_1a6
    .array-data 1
        -0x3ct
        -0x70t
        -0x67t
        -0x41t
        -0x55t
        -0x19t
        0x6bt
        -0x70t
        -0x21t
        -0x68t
        -0x77t
        -0x58t
        -0x55t
        -0x45t
        0x78t
        -0x24t
    .end array-data

    :array_1b2
    .array-data 1
        -0x4et
        -0x7t
        -0x3t
        -0x26t
        -0x3ct
        -0x38t
        0x13t
        -0x43t
    .end array-data

    :array_1ba
    .array-data 1
        -0x6ct
        0x67t
        -0x6ct
        0x7et
        0x5et
        -0x13t
        0x1at
        -0x2at
        -0x75t
        0x6dt
        -0x65t
        0x6ft
        0x58t
        -0x51t
        0xet
    .end array-data

    :array_1c6
    .array-data 1
        -0x1et
        0xet
        -0x10t
        0x1bt
        0x31t
        -0x3et
        0x6bt
        -0x5dt
    .end array-data

    :array_1ce
    .array-data 1
        0x1t
        0x67t
        -0x25t
        -0x65t
        -0xdt
        -0x7at
        0x30t
        0x78t
        0x1at
        0x7dt
        -0x6et
        -0x77t
        -0xft
        -0x21t
    .end array-data

    nop

    :array_1da
    .array-data 1
        0x77t
        0xet
        -0x41t
        -0x2t
        -0x64t
        -0x57t
        0x48t
        0x55t
    .end array-data

    :array_1e2
    .array-data 1
        0x3et
        -0x78t
        0x6t
        0x7bt
        0x2ct
        0x54t
        0x1ft
        0x3ft
        0x2et
        -0x73t
        0x14t
    .end array-data

    :array_1ec
    .array-data 1
        0x48t
        -0x1ft
        0x62t
        0x1et
        0x43t
        0x7bt
        0x67t
        0x12t
    .end array-data

    :array_1f4
    .array-data 1
        -0x29t
        0x2at
        0x68t
        -0xft
        0x6t
        0x7et
        -0x6t
        -0x62t
        -0x3dt
        0x2et
    .end array-data

    nop

    :array_1fe
    .array-data 1
        -0x5ft
        0x43t
        0xct
        -0x6ct
        0x69t
        0x51t
        -0x73t
        -0x5t
    .end array-data

    :array_206
    .array-data 1
        -0x78t
        -0x67t
        -0x4dt
        -0x77t
        -0x17t
        -0x4et
        -0x17t
        -0x44t
        -0x65t
        -0x69t
    .end array-data

    nop

    :array_210
    .array-data 1
        -0x2t
        -0x10t
        -0x29t
        -0x14t
        -0x7at
        -0x63t
        -0x7ct
        -0x34t
    .end array-data

    :array_218
    .array-data 1
        0x65t
        -0x53t
        -0x11t
        -0x77t
        0x1at
        -0x57t
        0x3dt
        -0x65t
        0x63t
        -0x4ct
    .end array-data

    nop

    :array_222
    .array-data 1
        0x13t
        -0x3ct
        -0x75t
        -0x14t
        0x75t
        -0x7at
        0xet
        -0x4t
    .end array-data

    :array_22a
    .array-data 1
        -0x80t
        0x3dt
        0x56t
        -0x70t
        -0x56t
        -0x1et
        -0x4at
        0x46t
        -0x6ft
    .end array-data

    nop

    :array_234
    .array-data 1
        -0xat
        0x54t
        0x32t
        -0xbt
        -0x3bt
        -0x33t
        -0x27t
        0x21t
    .end array-data

    :array_23c
    .array-data 1
        0x5ft
        -0x32t
        0x30t
        0x70t
        -0x25t
        -0x39t
        -0x1bt
        0x18t
        0x1bt
        -0xdt
    .end array-data

    nop

    :array_246
    .array-data 1
        0x29t
        -0x59t
        0x54t
        0x15t
        -0x4ct
        -0x18t
        -0x58t
        0x48t
    .end array-data

    :array_24e
    .array-data 1
        -0x4bt
        -0x2dt
        -0x71t
        -0x44t
        -0x37t
        -0x8t
        0x63t
        -0x2t
        -0x43t
        -0x34t
        -0x6ft
        -0x1t
        -0x2at
        -0xbt
        0x66t
        -0x5ct
        -0x5at
        -0x33t
        -0x2et
        -0x5et
        -0x3bt
        -0x6t
        0x6et
        -0x19t
        -0x4ft
        -0x39t
        -0x6at
        -0x4ft
    .end array-data

    :array_260
    .array-data 1
        -0x2ct
        -0x5dt
        -0x1t
        -0x30t
        -0x60t
        -0x65t
        0x2t
        -0x76t
    .end array-data

    :array_268
    .array-data 1
        -0x60t
        -0x3et
        0x17t
        -0x55t
        -0x37t
        -0x21t
        0x64t
        -0x1at
        -0x58t
        -0x23t
        0x9t
        -0x18t
        -0x28t
        -0x6ft
        0x68t
        -0xdt
        -0x4bt
        -0x40t
        0x8t
        -0x4ct
        -0x35t
        -0x23t
    .end array-data

    nop

    :array_278
    .array-data 1
        -0x3ft
        -0x4et
        0x67t
        -0x39t
        -0x60t
        -0x44t
        0x5t
        -0x6et
    .end array-data

    :array_280
    .array-data 1
        -0x6ft
        0x75t
        0x61t
        -0x79t
        -0x57t
        -0x8t
        -0x1ct
        0x1ct
        -0x2dt
        0x6at
        0x28t
        -0x79t
        -0x4bt
    .end array-data

    nop

    :array_28c
    .array-data 1
        -0x19t
        0x1ct
        0x5t
        -0x1et
        -0x3at
        -0x29t
        -0x77t
        0x6ct
    .end array-data

    :array_294
    .array-data 1
        -0x3dt
        0x56t
        -0x47t
        0x3at
        0x27t
        0x44t
        0x17t
        0x73t
        -0x7dt
        0xbt
    .end array-data

    nop

    :array_29e
    .array-data 1
        -0x4bt
        0x3ft
        -0x23t
        0x5ft
        0x48t
        0x6bt
        0x5ft
        0x41t
    .end array-data

    :array_2a6
    .array-data 1
        -0x2at
        -0x25t
        0x4at
        -0x45t
        -0x11t
        -0x4ct
        -0x12t
        -0x63t
        -0x6at
        -0x79t
    .end array-data

    nop

    :array_2b0
    .array-data 1
        -0x60t
        -0x4et
        0x2et
        -0x22t
        -0x80t
        -0x65t
        -0x5at
        -0x51t
    .end array-data

    :array_2b8
    .array-data 1
        -0x7at
        0x40t
        -0x66t
        0x66t
        -0x1ft
        0x15t
        0x26t
        -0x26t
        -0x38t
    .end array-data

    nop

    :array_2c2
    .array-data 1
        -0x10t
        0x29t
        -0x2t
        0x3t
        -0x72t
        0x3at
        0x70t
        -0x76t
    .end array-data

    :array_2ca
    .array-data 1
        0x1bt
        -0x10t
        0xat
        -0x63t
        -0x5ct
        -0x64t
        -0xat
        0x7ct
        0x54t
    .end array-data

    nop

    :array_2d4
    .array-data 1
        0x6dt
        -0x67t
        0x6et
        -0x8t
        -0x35t
        -0x4dt
        -0x60t
        0x2ct
    .end array-data

    :array_2dc
    .array-data 1
        0x1bt
        -0x76t
        -0x79t
        -0x4t
        -0x41t
        -0x6at
        0x65t
        0x31t
        0x1bt
        -0x65t
    .end array-data

    nop

    :array_2e6
    .array-data 1
        0x6dt
        -0x1dt
        -0x1dt
        -0x67t
        -0x30t
        -0x47t
        0x1t
        0x58t
    .end array-data

    :array_2ee
    .array-data 1
        0x10t
        0x38t
        0x48t
        0x53t
        -0x8t
        -0xet
        -0x6dt
        0x44t
        0xft
        0x35t
    .end array-data

    nop

    :array_2f8
    .array-data 1
        0x66t
        0x51t
        0x2ct
        0x36t
        -0x69t
        -0x23t
        -0x15t
        0x32t
    .end array-data

    :array_300
    .array-data 1
        -0x5et
        0x25t
        -0x3dt
        0x3t
        -0x59t
        -0xft
        0xdt
        -0x18t
        -0x1bt
    .end array-data

    nop

    :array_30a
    .array-data 1
        -0x2ct
        0x4ct
        -0x59t
        0x66t
        -0x38t
        -0x22t
        0x4ct
        -0x42t
    .end array-data
.end method

.method public static l(Ljava/lang/String;)Z
    .registers 5

    const/4 v0, 0x2

    new-array v0, v0, [Ljava/lang/String;

    const/16 v1, 0xa

    new-array v1, v1, [B

    fill-array-data v1, :array_46

    const/16 v2, 0x8

    new-array v3, v2, [B

    fill-array-data v3, :array_50

    invoke-static {v1, v3}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v1

    const/4 v3, 0x0

    aput-object v1, v0, v3

    const/4 v1, 0x5

    new-array v1, v1, [B

    fill-array-data v1, :array_58

    new-array v2, v2, [B

    fill-array-data v2, :array_60

    invoke-static {v1, v2}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v1

    const/4 v2, 0x1

    aput-object v1, v0, v2

    invoke-static {v0}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :cond_32
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_45

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    invoke-virtual {p0, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-eqz v1, :cond_32

    return v2

    :cond_45
    return v3

    :array_46
    .array-data 1
        -0x78t
        -0x42t
        0x4dt
        0xet
        -0x45t
        0x74t
        0x11t
        0x7et
        -0x38t
        -0xdt
    .end array-data

    nop

    :array_50
    .array-data 1
        -0x4ft
        -0x77t
        0x7et
        0x37t
        -0x74t
        0x47t
        0x3ft
        0x6t
    .end array-data

    :array_58
    .array-data 1
        0x19t
        0x22t
        0x7dt
        0x5et
        0x20t
    .end array-data

    nop

    :array_60
    .array-data 1
        0x37t
        0x44t
        0x14t
        0x2at
        0x1at
        -0x48t
        -0x36t
        0x45t
    .end array-data
.end method

.method public static m(Ljava/lang/String;)Z
    .registers 6

    const/4 v0, 0x1

    new-array v1, v0, [B

    const/16 v2, 0x1a

    const/4 v3, 0x0

    aput-byte v2, v1, v3

    const/16 v2, 0x8

    new-array v4, v2, [B

    fill-array-data v4, :array_32

    invoke-static {v1, v4}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {p0, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-eqz v1, :cond_2f

    new-array v1, v0, [B

    const/16 v4, -0x24

    aput-byte v4, v1, v3

    new-array v2, v2, [B

    fill-array-data v2, :array_3a

    invoke-static {v1, v2}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {p0, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result p0

    if-eqz p0, :cond_2f

    goto :goto_30

    :cond_2f
    const/4 v0, 0x0

    :goto_30
    return v0

    nop

    :array_32
    .array-data 1
        0x5at
        0x25t
        -0x74t
        0x2et
        0x65t
        -0x78t
        -0x22t
        0x11t
    .end array-data

    :array_3a
    .array-data 1
        -0xet
        0x5et
        -0x51t
        0x28t
        -0x2et
        -0x22t
        0x4bt
        -0x9t
    .end array-data
.end method

.method public static n(Ljava/lang/String;)Z
    .registers 2

    sget-object v0, Lcom/github/catvod/spider/appysv2/p/C;->c:Ljava/util/List;

    invoke-interface {v0, p0}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    move-result p0

    return p0
.end method

.method public static o(Ljava/lang/String;)Z
    .registers 4

    const/16 v0, 0x8

    new-array v1, v0, [B

    fill-array-data v1, :array_64

    new-array v2, v0, [B

    fill-array-data v2, :array_6c

    invoke-static {v1, v2}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {p0, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_61

    const/4 v1, 0x3

    new-array v1, v1, [B

    fill-array-data v1, :array_74

    new-array v2, v0, [B

    fill-array-data v2, :array_7a

    invoke-static {v1, v2}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {p0, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_61

    const/4 v1, 0x4

    new-array v1, v1, [B

    fill-array-data v1, :array_82

    new-array v2, v0, [B

    fill-array-data v2, :array_88

    invoke-static {v1, v2}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {p0, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_61

    const/4 v1, 0x5

    new-array v1, v1, [B

    fill-array-data v1, :array_90

    new-array v0, v0, [B

    fill-array-data v0, :array_98

    invoke-static {v1, v0}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p0, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    if-eqz v0, :cond_56

    goto :goto_61

    :cond_56
    sget-object v0, Lcom/github/catvod/spider/appysv2/p/C;->a:Ljava/util/regex/Pattern;

    invoke-virtual {v0, p0}, Ljava/util/regex/Pattern;->matcher(Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;

    move-result-object p0

    invoke-virtual {p0}, Ljava/util/regex/Matcher;->find()Z

    move-result p0

    return p0

    :cond_61
    :goto_61
    const/4 p0, 0x0

    return p0

    nop

    :array_64
    .array-data 1
        -0x53t
        0x4ct
        -0x16t
        0x73t
        0x6ft
        0x11t
        -0x55t
        0x52t
    .end array-data

    :array_6c
    .array-data 1
        -0x28t
        0x3et
        -0x7at
        0x4et
        0x7t
        0x65t
        -0x21t
        0x22t
    .end array-data

    :array_74
    .array-data 1
        0x34t
        0x7ft
        0x15t
    .end array-data

    :array_7a
    .array-data 1
        0x1at
        0x15t
        0x66t
        -0x51t
        -0x24t
        -0x6t
        -0x3at
        0x55t
    .end array-data

    :array_82
    .array-data 1
        -0x80t
        0x55t
        0x5t
        0x8t
    .end array-data

    :array_88
    .array-data 1
        -0x52t
        0x36t
        0x76t
        0x7bt
        -0x30t
        0x45t
        -0x13t
        -0x46t
    .end array-data

    :array_90
    .array-data 1
        0x5dt
        0x1ct
        -0x4ft
        0x7at
        -0x7ct
    .end array-data

    nop

    :array_98
    .array-data 1
        0x73t
        0x74t
        -0x3bt
        0x17t
        -0x18t
        0x7et
        -0xct
        -0x16t
    .end array-data
.end method

.method public static p(Ljava/lang/String;)Z
    .registers 10

    const/16 v0, 0xb

    new-array v1, v0, [Ljava/lang/String;

    const/16 v2, 0x9

    new-array v3, v2, [B

    fill-array-data v3, :array_e0

    const/16 v4, 0x8

    new-array v5, v4, [B

    fill-array-data v5, :array_ea

    invoke-static {v3, v5}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v3

    const/4 v5, 0x0

    aput-object v3, v1, v5

    new-array v3, v4, [B

    fill-array-data v3, :array_f2

    new-array v6, v4, [B

    fill-array-data v6, :array_fa

    invoke-static {v3, v6}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v3

    const/4 v6, 0x1

    aput-object v3, v1, v6

    new-array v3, v2, [B

    fill-array-data v3, :array_102

    new-array v7, v4, [B

    fill-array-data v7, :array_10c

    invoke-static {v3, v7}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v3

    const/4 v7, 0x2

    aput-object v3, v1, v7

    const/4 v3, 0x6

    new-array v7, v3, [B

    fill-array-data v7, :array_114

    new-array v8, v4, [B

    fill-array-data v8, :array_11c

    invoke-static {v7, v8}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v7

    const/4 v8, 0x3

    aput-object v7, v1, v8

    new-array v7, v2, [B

    fill-array-data v7, :array_124

    new-array v8, v4, [B

    fill-array-data v8, :array_12e

    invoke-static {v7, v8}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v7

    const/4 v8, 0x4

    aput-object v7, v1, v8

    new-array v7, v4, [B

    fill-array-data v7, :array_136

    new-array v8, v4, [B

    fill-array-data v8, :array_13e

    invoke-static {v7, v8}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v7

    const/4 v8, 0x5

    aput-object v7, v1, v8

    new-array v7, v4, [B

    fill-array-data v7, :array_146

    new-array v8, v4, [B

    fill-array-data v8, :array_14e

    invoke-static {v7, v8}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v7

    aput-object v7, v1, v3

    new-array v3, v4, [B

    fill-array-data v3, :array_156

    new-array v7, v4, [B

    fill-array-data v7, :array_15e

    invoke-static {v3, v7}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v3

    const/4 v7, 0x7

    aput-object v3, v1, v7

    const/16 v3, 0xc

    new-array v3, v3, [B

    fill-array-data v3, :array_166

    new-array v7, v4, [B

    fill-array-data v7, :array_170

    invoke-static {v3, v7}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v3

    aput-object v3, v1, v4

    new-array v0, v0, [B

    fill-array-data v0, :array_178

    new-array v3, v4, [B

    fill-array-data v3, :array_182

    invoke-static {v0, v3}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v0

    aput-object v0, v1, v2

    new-array v0, v4, [B

    fill-array-data v0, :array_18a

    new-array v2, v4, [B

    fill-array-data v2, :array_192

    invoke-static {v0, v2}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v0

    const/16 v2, 0xa

    aput-object v0, v1, v2

    invoke-static {v1}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :cond_cc
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_df

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    invoke-virtual {p0, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-eqz v1, :cond_cc

    return v6

    :cond_df
    return v5

    :array_e0
    .array-data 1
        -0x3et
        0x6at
        -0x22t
        0x3bt
        0x76t
        -0x45t
        0x64t
        0xft
        -0x3at
    .end array-data

    nop

    :array_ea
    .array-data 1
        -0x55t
        0x1bt
        -0x49t
        0x42t
        0x1ft
        -0x6bt
        0x7t
        0x60t
    .end array-data

    :array_f2
    .array-data 1
        -0x3at
        -0x3bt
        -0x35t
        -0x2ct
        0x5et
        -0x5at
        -0x1t
        -0x6at
    .end array-data

    :array_fa
    .array-data 1
        -0x50t
        -0x15t
        -0x46t
        -0x5bt
        0x70t
        -0x3bt
        -0x70t
        -0x5t
    .end array-data

    :array_102
    .array-data 1
        -0x12t
        0xct
        0x2bt
        0x42t
        -0x63t
        0x5at
        0x2ft
        0x55t
        -0x6t
    .end array-data

    nop

    :array_10c
    .array-data 1
        -0x69t
        0x63t
        0x5et
        0x29t
        -0x18t
        0x74t
        0x4ct
        0x3at
    .end array-data

    :array_114
    .array-data 1
        0x9t
        0x16t
        0x1ct
        -0x40t
        -0x42t
        -0x6bt
    .end array-data

    nop

    :array_11c
    .array-data 1
        0x65t
        0x73t
        0x32t
        -0x5dt
        -0x2ft
        -0x8t
        -0x31t
        0x1ct
    .end array-data

    :array_124
    .array-data 1
        0x51t
        0x1bt
        0x63t
        0x5at
        0x5dt
        -0x39t
        0x77t
        -0x4at
        0x48t
    .end array-data

    nop

    :array_12e
    .array-data 1
        0x25t
        0x6et
        0x7t
        0x35t
        0x28t
        -0x17t
        0x14t
        -0x27t
    .end array-data

    :array_136
    .array-data 1
        -0x6dt
        -0x20t
        -0x68t
        -0x75t
        0x78t
        -0x64t
        -0x1t
        0x2ct
    .end array-data

    :array_13e
    .array-data 1
        -0x2t
        -0x79t
        -0x14t
        -0x3t
        0x56t
        -0x1t
        -0x70t
        0x41t
    .end array-data

    :array_146
    .array-data 1
        -0x5t
        0x4ct
        0x1dt
        0x15t
        -0x37t
        -0x7ct
        0x4ft
        -0x58t
    .end array-data

    :array_14e
    .array-data 1
        -0x78t
        0x23t
        0x75t
        0x60t
        -0x19t
        -0x19t
        0x20t
        -0x3bt
    .end array-data

    :array_156
    .array-data 1
        -0x25t
        0x2et
        0xbt
        0x52t
        0x48t
        -0x57t
        -0x60t
        0x7at
    .end array-data

    :array_15e
    .array-data 1
        -0x46t
        0x4dt
        0x6dt
        0x27t
        0x26t
        -0x79t
        -0x3dt
        0x14t
    .end array-data

    :array_166
    .array-data 1
        0x3et
        0x52t
        -0x35t
        -0x1et
        -0x63t
        -0x7et
        -0x1at
        -0x3t
        0x72t
        0x58t
        -0x38t
        -0x1at
    .end array-data

    :array_170
    .array-data 1
        0x5ct
        0x3bt
        -0x59t
        -0x75t
        -0x1t
        -0x15t
        -0x76t
        -0x6ct
    .end array-data

    :array_178
    .array-data 1
        0x25t
        -0x6t
        0x1et
        -0xet
        0x33t
        -0x75t
        0x17t
        -0x61t
        0x24t
        -0xct
        0x1ct
    .end array-data

    :array_182
    .array-data 1
        0x47t
        -0x65t
        0x71t
        -0x6ct
        0x56t
        -0x1bt
        0x70t
        -0x4ft
    .end array-data

    :array_18a
    .array-data 1
        0x68t
        0xat
        0x61t
        0x3dt
        0x6ct
        -0x4at
        -0x75t
        0x4t
    .end array-data

    :array_192
    .array-data 1
        0x18t
        0x7at
        0x15t
        0x4bt
        0x42t
        -0x2bt
        -0x1ct
        0x69t
    .end array-data
.end method

.method public static q(Ljava/lang/String;)Ljava/lang/String;
    .registers 3

    new-instance v0, Ljava/io/File;

    invoke-static {}, Lcom/github/catvod/spider/Init;->context()Landroid/app/Application;

    move-result-object v1

    invoke-virtual {v1}, Landroid/content/Context;->getFilesDir()Ljava/io/File;

    move-result-object v1

    invoke-direct {v0, v1, p0}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    invoke-static {v0}, Lcom/github/catvod/spider/appysv2/p/a;->k(Ljava/io/File;)Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method public static r(Ljava/lang/String;)Ljava/lang/String;
    .registers 6

    const/4 v0, 0x1

    new-array v1, v0, [B

    const/16 v2, -0x43

    const/4 v3, 0x0

    aput-byte v2, v1, v3

    const/16 v2, 0x8

    new-array v4, v2, [B

    fill-array-data v4, :array_32

    invoke-static {v1, v4}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {p0, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-eqz v1, :cond_30

    new-array v0, v0, [B

    const/16 v1, -0x34

    aput-byte v1, v0, v3

    new-array v1, v2, [B

    fill-array-data v1, :array_3a

    invoke-static {v0, v1}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p0, v0}, Ljava/lang/String;->lastIndexOf(Ljava/lang/String;)I

    move-result v0

    invoke-virtual {p0, v3, v0}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object p0

    :cond_30
    return-object p0

    nop

    :array_32
    .array-data 1
        -0x6dt
        -0x74t
        -0x55t
        0x36t
        -0x78t
        0x2ft
        0x75t
        -0x64t
    .end array-data

    :array_3a
    .array-data 1
        -0x1et
        -0x2dt
        0x8t
        0x6ft
        -0x69t
        0x50t
        -0x11t
        0x74t
    .end array-data
.end method

.method public static s(Ljava/lang/String;)Ljava/lang/String;
    .registers 4

    if-eqz p0, :cond_13

    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v0

    const/4 v1, 0x1

    if-le v0, v1, :cond_13

    const/4 v0, 0x0

    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v2

    sub-int/2addr v2, v1

    invoke-virtual {p0, v0, v2}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object p0

    :cond_13
    return-object p0
.end method

.method public static t([B)[B
    .registers 3

    :try_start_0
    new-instance v0, Lcom/github/catvod/spider/appysv2/O/b;

    invoke-direct {v0}, Lcom/github/catvod/spider/appysv2/O/b;-><init>()V

    array-length v1, p0

    invoke-virtual {v0, p0, v1}, Lcom/github/catvod/spider/appysv2/O/b;->c([BI)V

    invoke-virtual {v0}, Lcom/github/catvod/spider/appysv2/O/b;->a()V

    new-instance v1, Ljava/lang/String;

    invoke-virtual {v0}, Lcom/github/catvod/spider/appysv2/O/b;->b()Ljava/lang/String;

    move-result-object v0

    invoke-direct {v1, p0, v0}, Ljava/lang/String;-><init>([BLjava/lang/String;)V

    sget-object v0, Ljava/nio/charset/StandardCharsets;->UTF_8:Ljava/nio/charset/Charset;

    invoke-virtual {v1, v0}, Ljava/lang/String;->getBytes(Ljava/nio/charset/Charset;)[B

    move-result-object p0
    :try_end_1b
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_1b} :catch_1b

    :catch_1b
    return-object p0
.end method

.method public static u(Ljava/lang/String;Ljava/lang/String;)V
    .registers 4

    new-instance v0, Ljava/io/File;

    invoke-static {}, Lcom/github/catvod/spider/Init;->context()Landroid/app/Application;

    move-result-object v1

    invoke-virtual {v1}, Landroid/content/Context;->getFilesDir()Ljava/io/File;

    move-result-object v1

    invoke-direct {v0, v1, p0}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    invoke-static {v0, p1}, Lcom/github/catvod/spider/appysv2/p/a;->o(Ljava/io/File;Ljava/lang/String;)Ljava/io/File;

    return-void
.end method

.method public static v(Ljava/lang/String;Ljava/lang/String;)V
    .registers 3

    invoke-virtual {p1}, Ljava/lang/String;->isEmpty()Z

    move-result v0

    if-eqz v0, :cond_7

    return-void

    :cond_7
    invoke-static {p0}, Lcom/github/catvod/spider/appysv2/p/a;->n(Ljava/lang/String;)Ljava/io/File;

    move-result-object p0

    invoke-static {p0, p1}, Lcom/github/catvod/spider/appysv2/p/a;->o(Ljava/io/File;Ljava/lang/String;)Ljava/io/File;

    return-void
.end method

.method public static w(Ljava/lang/String;)Lorg/json/JSONObject;
    .registers 39

    move-object/from16 v0, p0

    new-instance v1, Lorg/json/JSONObject;

    invoke-direct {v1}, Lorg/json/JSONObject;-><init>()V

    const/4 v2, 0x4

    :try_start_8
    new-array v3, v2, [B

    const/4 v4, 0x0

    const/16 v5, 0x55

    aput-byte v5, v3, v4

    const/4 v6, 0x1

    const/16 v7, -0x48

    aput-byte v7, v3, v6

    const/16 v8, 0x30

    const/4 v9, 0x2

    aput-byte v8, v3, v9

    const/4 v8, 0x3

    const/16 v10, -0xe

    aput-byte v10, v3, v8

    const/16 v11, 0x8

    new-array v12, v11, [B

    const/16 v13, 0x3d

    aput-byte v13, v12, v4

    const/16 v14, -0x34

    aput-byte v14, v12, v6

    const/16 v14, 0x44

    aput-byte v14, v12, v9

    const/16 v14, -0x7e

    aput-byte v14, v12, v8

    const/16 v14, -0x11

    aput-byte v14, v12, v2

    const/16 v15, 0x51

    const/4 v7, 0x5

    aput-byte v15, v12, v7

    const/16 v15, -0x40

    const/4 v5, 0x6

    aput-byte v15, v12, v5

    const/4 v15, 0x7

    const/16 v16, -0x63

    aput-byte v16, v12, v15

    invoke-static {v3, v12}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v0, v3}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v3

    const/4 v12, 0x0

    if-eqz v3, :cond_59

    new-instance v1, Lorg/json/JSONObject;

    .line 1
    invoke-static {v0, v12}, Lcom/github/catvod/spider/appysv2/n/c;->m(Ljava/lang/String;Ljava/util/Map;)Ljava/lang/String;

    move-result-object v3

    .line 2
    invoke-direct {v1, v3}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    :cond_59
    new-array v3, v2, [B

    const/16 v17, -0x54

    aput-byte v17, v3, v4

    const/16 v17, -0x74

    aput-byte v17, v3, v6

    const/16 v17, 0xf

    aput-byte v17, v3, v9

    const/16 v17, -0x3f

    aput-byte v17, v3, v8

    new-array v12, v11, [B

    const/16 v18, -0x36

    aput-byte v18, v12, v4

    const/16 v18, -0x1b

    aput-byte v18, v12, v6

    const/16 v19, 0x63

    aput-byte v19, v12, v9

    const/16 v20, -0x5c

    aput-byte v20, v12, v8

    const/16 v20, 0x6d

    aput-byte v20, v12, v2

    const/16 v14, 0xb

    aput-byte v14, v12, v7

    const/16 v22, -0x2d

    aput-byte v22, v12, v5

    const/16 v22, -0x7d

    aput-byte v22, v12, v15

    invoke-static {v3, v12}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v0, v3}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v3

    if-eqz v3, :cond_a0

    new-instance v1, Lorg/json/JSONObject;

    invoke-static/range {p0 .. p0}, Lcom/github/catvod/spider/appysv2/p/a;->m(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-direct {v1, v3}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    :cond_a0
    new-array v3, v6, [B

    const/16 v12, -0x18

    aput-byte v12, v3, v4

    new-array v12, v11, [B

    const/16 v23, -0x6d

    aput-byte v23, v12, v4

    const/16 v23, 0x18

    aput-byte v23, v12, v6

    const/16 v24, -0x3

    aput-byte v24, v12, v9

    const/16 v25, 0x4b

    aput-byte v25, v12, v8

    aput-byte v4, v12, v2

    const/16 v26, -0x37

    aput-byte v26, v12, v7

    const/16 v26, -0x6f

    aput-byte v26, v12, v5

    const/16 v27, 0x2d

    aput-byte v27, v12, v15

    invoke-static {v3, v12}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v0, v3}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v3

    if-eqz v3, :cond_d5

    new-instance v1, Lorg/json/JSONObject;

    invoke-direct {v1, v0}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    :cond_d5
    const/16 v0, 0xa

    new-array v3, v0, [B

    const/16 v12, 0x2f

    aput-byte v12, v3, v4

    const/16 v28, 0x72

    aput-byte v28, v3, v6

    const/16 v29, 0x25

    aput-byte v29, v3, v9

    const/16 v29, 0x3e

    aput-byte v29, v3, v8

    const/16 v29, 0x5d

    aput-byte v29, v3, v2

    aput-byte v12, v3, v7

    const/16 v29, 0x1d

    aput-byte v29, v3, v5

    const/16 v29, 0x21

    aput-byte v29, v3, v15

    aput-byte v13, v3, v11

    const/16 v29, 0x9

    const/16 v30, 0x75

    aput-byte v30, v3, v29

    new-array v12, v11, [B

    const/16 v31, 0x5b

    aput-byte v31, v12, v4

    const/16 v31, 0x1a

    aput-byte v31, v12, v6

    const/16 v31, 0x57

    aput-byte v31, v12, v9

    const/16 v31, 0x5b

    aput-byte v31, v12, v8

    const/16 v31, 0x3c

    aput-byte v31, v12, v2

    aput-byte v25, v12, v7

    const/16 v32, 0x74

    aput-byte v32, v12, v5

    const/16 v32, 0x4f

    aput-byte v32, v12, v15

    invoke-static {v3, v12}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v1, v3}, Lorg/json/JSONObject;->has(Ljava/lang/String;)Z

    move-result v3

    const/16 v12, 0x17

    const/16 v32, 0x7e

    const/16 v33, 0x19

    if-eqz v3, :cond_1b8

    new-array v3, v0, [B

    const/16 v34, -0x20

    aput-byte v34, v3, v4

    aput-byte v28, v3, v6

    const/16 v34, -0x5a

    aput-byte v34, v3, v9

    const/16 v34, 0x6e

    aput-byte v34, v3, v8

    aput-byte v6, v3, v2

    const/16 v34, -0x1e

    aput-byte v34, v3, v7

    const/16 v34, 0x36

    aput-byte v34, v3, v5

    const/16 v34, -0x7f

    aput-byte v34, v3, v15

    aput-byte v10, v3, v11

    aput-byte v30, v3, v29

    new-array v10, v11, [B

    const/16 v35, -0x6c

    aput-byte v35, v10, v4

    const/16 v35, 0x1a

    aput-byte v35, v10, v6

    const/16 v35, -0x2c

    aput-byte v35, v10, v9

    aput-byte v14, v10, v8

    const/16 v35, 0x60

    aput-byte v35, v10, v2

    const/16 v35, -0x7a

    aput-byte v35, v10, v7

    const/16 v35, 0x5f

    aput-byte v35, v10, v5

    const/16 v21, -0x11

    aput-byte v21, v10, v15

    invoke-static {v3, v10}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v1, v3}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    new-array v10, v11, [B

    aput-byte v12, v10, v4

    aput-byte v8, v10, v6

    aput-byte v18, v10, v9

    const/16 v35, 0x46

    aput-byte v35, v10, v8

    aput-byte v32, v10, v2

    const/16 v35, 0x10

    aput-byte v35, v10, v7

    const/16 v35, -0x16

    aput-byte v35, v10, v5

    const/16 v35, 0x7d

    aput-byte v35, v10, v15

    new-array v0, v11, [B

    const/16 v36, 0x38

    aput-byte v36, v0, v4

    aput-byte v27, v0, v6

    aput-byte v26, v0, v9

    const/16 v36, 0x2e

    aput-byte v36, v0, v8

    const/16 v36, 0xc

    aput-byte v36, v0, v2

    aput-byte v30, v0, v7

    const/16 v30, -0x75

    aput-byte v30, v0, v5

    aput-byte v33, v0, v15

    invoke-static {v10, v0}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lcom/github/catvod/spider/appysv2/p/a;->n(Ljava/lang/String;)Ljava/io/File;

    move-result-object v0

    invoke-static {v0, v3}, Lcom/github/catvod/spider/appysv2/p/a;->o(Ljava/io/File;Ljava/lang/String;)Ljava/io/File;

    :cond_1b8
    new-array v0, v7, [B

    const/16 v3, -0x5a

    aput-byte v3, v0, v4

    const/16 v3, -0x22

    aput-byte v3, v0, v6

    aput-byte v9, v0, v9

    const/16 v3, -0x2c

    aput-byte v3, v0, v8

    const/16 v3, -0x44

    aput-byte v3, v0, v2

    new-array v3, v11, [B

    const/16 v10, -0x2e

    aput-byte v10, v3, v4

    const/16 v30, -0x4f

    aput-byte v30, v3, v6

    const/16 v36, 0x69

    aput-byte v36, v3, v9

    aput-byte v30, v3, v8

    aput-byte v10, v3, v2

    aput-byte v32, v3, v7

    const/16 v36, 0x32

    aput-byte v36, v3, v5

    const/16 v36, 0x71

    aput-byte v36, v3, v15

    invoke-static {v0, v3}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v1, v0}, Lorg/json/JSONObject;->has(Ljava/lang/String;)Z

    move-result v0

    const/4 v3, -0x4

    if-eqz v0, :cond_26d

    new-array v0, v7, [B

    const/16 v36, -0x51

    aput-byte v36, v0, v4

    const/16 v36, -0xc

    aput-byte v36, v0, v6

    const/16 v36, 0x74

    aput-byte v36, v0, v9

    aput-byte v3, v0, v8

    aput-byte v11, v0, v2

    new-array v3, v11, [B

    const/16 v37, -0x25

    aput-byte v37, v3, v4

    const/16 v37, -0x65

    aput-byte v37, v3, v6

    const/16 v37, 0x1f

    aput-byte v37, v3, v9

    const/16 v37, -0x67

    aput-byte v37, v3, v8

    const/16 v37, 0x66

    aput-byte v37, v3, v2

    const/16 v37, -0x58

    aput-byte v37, v3, v7

    aput-byte v26, v3, v5

    aput-byte v7, v3, v15

    invoke-static {v0, v3}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v1, v0}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    new-array v3, v2, [B

    aput-byte v32, v3, v4

    const/16 v21, -0x11

    aput-byte v21, v3, v6

    aput-byte v19, v3, v9

    const/16 v19, -0x69

    aput-byte v19, v3, v8

    new-array v10, v11, [B

    const/16 v37, 0x16

    aput-byte v37, v10, v4

    const/16 v37, -0x65

    aput-byte v37, v10, v6

    aput-byte v12, v10, v9

    const/16 v37, -0x19

    aput-byte v37, v10, v8

    aput-byte v6, v10, v2

    const/16 v37, -0x33

    aput-byte v37, v10, v7

    const/16 v37, 0x61

    aput-byte v37, v10, v5

    const/16 v37, -0x51

    aput-byte v37, v10, v15

    invoke-static {v3, v10}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v0, v3}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v3

    if-eqz v3, :cond_266

    const/4 v3, 0x0

    .line 3
    invoke-static {v0, v3}, Lcom/github/catvod/spider/appysv2/n/c;->m(Ljava/lang/String;Ljava/util/Map;)Ljava/lang/String;

    move-result-object v0

    .line 4
    :cond_266
    invoke-static {}, Lcom/github/catvod/spider/appysv2/b/x;->p()Lcom/github/catvod/spider/appysv2/b/x;

    move-result-object v3

    invoke-virtual {v3, v0}, Lcom/github/catvod/spider/appysv2/b/x;->L(Ljava/lang/String;)V

    :cond_26d
    new-array v0, v14, [B

    const/16 v3, -0xb

    aput-byte v3, v0, v4

    aput-byte v14, v0, v6

    const/16 v3, -0x1c

    aput-byte v3, v0, v9

    const/16 v10, 0x2b

    aput-byte v10, v0, v8

    aput-byte v13, v0, v2

    aput-byte v14, v0, v7

    aput-byte v24, v0, v5

    const/16 v10, -0x4a

    aput-byte v10, v0, v15

    const/16 v10, -0x11

    aput-byte v10, v0, v11

    aput-byte v12, v0, v29

    const/16 v10, -0x20

    const/16 v21, 0xa

    aput-byte v10, v0, v21

    new-array v10, v11, [B

    const/16 v21, -0x7c

    aput-byte v21, v10, v4

    aput-byte v32, v10, v6

    const/16 v21, -0x7b

    aput-byte v21, v10, v9

    const/16 v21, 0x59

    aput-byte v21, v10, v8

    const/16 v21, 0x56

    aput-byte v21, v10, v2

    const/16 v21, 0x48

    aput-byte v21, v10, v7

    const/16 v21, -0x6e

    aput-byte v21, v10, v5

    const/16 v21, -0x27

    aput-byte v21, v10, v15

    invoke-static {v0, v10}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v1, v0}, Lorg/json/JSONObject;->has(Ljava/lang/String;)Z

    move-result v0

    const/16 v10, -0x55

    if-eqz v0, :cond_38d

    new-array v0, v14, [B

    const/16 v21, -0x79

    aput-byte v21, v0, v4

    const/16 v21, -0x25

    aput-byte v21, v0, v6

    const/16 v21, 0x13

    aput-byte v21, v0, v9

    const/16 v21, 0x40

    aput-byte v21, v0, v8

    const/16 v21, 0x43

    aput-byte v21, v0, v2

    const/16 v21, 0x38

    aput-byte v21, v0, v7

    const/16 v21, -0x2a

    aput-byte v21, v0, v5

    const/16 v21, -0x66

    aput-byte v21, v0, v15

    aput-byte v16, v0, v11

    const/16 v16, -0x39

    aput-byte v16, v0, v29

    const/16 v16, 0xa

    aput-byte v12, v0, v16

    new-array v12, v11, [B

    const/16 v16, -0xa

    aput-byte v16, v12, v4

    const/16 v16, -0x52

    aput-byte v16, v12, v6

    aput-byte v28, v12, v9

    const/16 v16, 0x32

    aput-byte v16, v12, v8

    const/16 v16, 0x28

    aput-byte v16, v12, v2

    const/16 v16, 0x7b

    aput-byte v16, v12, v7

    const/16 v16, -0x47

    aput-byte v16, v12, v5

    const/16 v16, -0xb

    aput-byte v16, v12, v15

    invoke-static {v0, v12}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v1, v0}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v12

    if-nez v12, :cond_38d

    new-array v12, v2, [B

    const/16 v16, 0x45

    aput-byte v16, v12, v4

    aput-byte v23, v12, v6

    aput-byte v3, v12, v9

    const/16 v16, 0x29

    aput-byte v16, v12, v8

    new-array v14, v11, [B

    aput-byte v27, v14, v4

    const/16 v21, 0x6c

    aput-byte v21, v14, v6

    const/16 v21, -0x70

    aput-byte v21, v14, v9

    const/16 v21, 0x59

    aput-byte v21, v14, v8

    const/16 v21, 0x20

    aput-byte v21, v14, v2

    aput-byte v10, v14, v7

    const/16 v19, -0x2e

    aput-byte v19, v14, v5

    aput-byte v10, v14, v15

    invoke-static {v12, v14}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v12

    invoke-virtual {v0, v12}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v12

    if-eqz v12, :cond_352

    const/4 v12, 0x0

    .line 5
    invoke-static {v0, v12}, Lcom/github/catvod/spider/appysv2/n/c;->m(Ljava/lang/String;Ljava/util/Map;)Ljava/lang/String;

    move-result-object v0

    :cond_352
    new-array v12, v5, [B

    const/16 v14, 0x31

    aput-byte v14, v12, v4

    aput-byte v18, v12, v6

    aput-byte v2, v12, v9

    const/16 v14, 0x2a

    aput-byte v14, v12, v8

    const/16 v14, 0x67

    aput-byte v14, v12, v2

    const/16 v14, -0xe

    aput-byte v14, v12, v7

    new-array v14, v11, [B

    const/16 v18, 0x1f

    aput-byte v18, v14, v4

    const/16 v18, -0x6c

    aput-byte v18, v14, v6

    const/16 v18, 0x71

    aput-byte v18, v14, v9

    aput-byte v25, v14, v8

    const/16 v18, 0x15

    aput-byte v18, v14, v2

    const/16 v18, -0x67

    aput-byte v18, v14, v7

    const/16 v18, -0x4

    aput-byte v18, v14, v5

    aput-byte v26, v14, v15

    .line 6
    invoke-static {v12, v14}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v12

    invoke-static {v12, v0}, Lcom/github/catvod/spider/appysv2/p/C;->u(Ljava/lang/String;Ljava/lang/String;)V

    :cond_38d
    new-array v0, v11, [B

    const/16 v12, -0x17

    aput-byte v12, v0, v4

    const/16 v12, 0x5e

    aput-byte v12, v0, v6

    const/16 v12, 0x33

    aput-byte v12, v0, v9

    const/16 v12, 0x2e

    aput-byte v12, v0, v8

    aput-byte v13, v0, v2

    const/16 v12, -0x23

    aput-byte v12, v0, v7

    aput-byte v31, v0, v5

    const/16 v12, -0x7f

    aput-byte v12, v0, v15

    new-array v12, v11, [B

    const/16 v14, -0x64

    aput-byte v14, v12, v4

    aput-byte v13, v12, v6

    const/16 v14, 0x70

    aput-byte v14, v12, v9

    const/16 v14, 0x41

    aput-byte v14, v12, v8

    const/16 v14, 0x52

    aput-byte v14, v12, v2

    const/16 v14, -0x4a

    aput-byte v14, v12, v7

    const/16 v14, 0x55

    aput-byte v14, v12, v5

    aput-byte v3, v12, v15

    invoke-static {v0, v12}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v1, v0}, Lorg/json/JSONObject;->has(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_48c

    new-array v0, v11, [B

    const/16 v3, -0x7a

    aput-byte v3, v0, v4

    aput-byte v31, v0, v6

    const/16 v3, -0x48

    aput-byte v3, v0, v9

    const/16 v3, 0x2f

    aput-byte v3, v0, v8

    const/16 v3, -0xd

    aput-byte v3, v0, v2

    const/16 v3, -0x4e

    aput-byte v3, v0, v7

    const/16 v3, 0x70

    aput-byte v3, v0, v5

    aput-byte v33, v0, v15

    new-array v3, v11, [B

    const/16 v12, -0xd

    aput-byte v12, v3, v4

    const/16 v12, 0x5f

    aput-byte v12, v3, v6

    const/4 v12, -0x5

    aput-byte v12, v3, v9

    const/16 v12, 0x40

    aput-byte v12, v3, v8

    const/16 v12, -0x64

    aput-byte v12, v3, v2

    const/16 v12, -0x27

    aput-byte v12, v3, v7

    aput-byte v33, v3, v5

    const/16 v12, 0x7c

    aput-byte v12, v3, v15

    invoke-static {v0, v3}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v1, v0}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v3

    if-nez v3, :cond_48c

    new-array v3, v2, [B

    const/16 v12, 0x42

    aput-byte v12, v3, v4

    aput-byte v30, v3, v6

    const/16 v12, -0x78

    aput-byte v12, v3, v9

    const/16 v12, -0x18

    aput-byte v12, v3, v8

    new-array v12, v11, [B

    const/16 v14, 0x2a

    aput-byte v14, v12, v4

    const/16 v14, -0x3b

    aput-byte v14, v12, v6

    const/4 v14, -0x4

    aput-byte v14, v12, v9

    const/16 v14, -0x68

    aput-byte v14, v12, v8

    const/16 v14, 0xb

    aput-byte v14, v12, v2

    const/16 v14, 0x21

    aput-byte v14, v12, v7

    const/16 v14, 0x4f

    aput-byte v14, v12, v5

    const/16 v14, 0x25

    aput-byte v14, v12, v15

    invoke-static {v3, v12}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v0, v3}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v3

    if-eqz v3, :cond_45e

    const/4 v3, 0x0

    .line 7
    invoke-static {v0, v3}, Lcom/github/catvod/spider/appysv2/n/c;->m(Ljava/lang/String;Ljava/util/Map;)Ljava/lang/String;

    move-result-object v0

    :cond_45e
    new-array v3, v8, [B

    const/16 v12, 0x42

    aput-byte v12, v3, v4

    const/16 v12, -0x76

    aput-byte v12, v3, v6

    aput-byte v13, v3, v9

    new-array v11, v11, [B

    const/16 v12, 0x6c

    aput-byte v12, v11, v4

    const/4 v4, -0x1

    aput-byte v4, v11, v6

    const/16 v4, 0x5e

    aput-byte v4, v11, v9

    aput-byte v10, v11, v8

    aput-byte v20, v11, v2

    const/16 v2, 0x7b

    aput-byte v2, v11, v7

    aput-byte v15, v11, v5

    const/16 v2, -0x73

    aput-byte v2, v11, v15

    .line 8
    invoke-static {v3, v11}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-static {v2, v0}, Lcom/github/catvod/spider/appysv2/p/C;->u(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_48c
    .catch Ljava/lang/Exception; {:try_start_8 .. :try_end_48c} :catch_48d

    :cond_48c
    return-object v1

    :catch_48d
    move-exception v0

    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Lcom/github/catvod/crawler/SpiderDebug;->log(Ljava/lang/String;)V

    new-instance v1, Ljava/lang/Exception;

    invoke-direct {v1, v0}, Ljava/lang/Exception;-><init>(Ljava/lang/Throwable;)V

    throw v1
.end method
