.class public final Lcom/github/catvod/spider/appysv2/p/m;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field private static final a:Ljava/lang/String;

.field private static final b:Ljava/lang/String;


# direct methods
.method static constructor <clinit>()V
    .registers 3

    const/16 v0, 0x16

    new-array v0, v0, [B

    fill-array-data v0, :array_28

    const/16 v1, 0x8

    new-array v2, v1, [B

    fill-array-data v2, :array_38

    invoke-static {v0, v2}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lcom/github/catvod/spider/appysv2/p/m;->a:Ljava/lang/String;

    const/16 v0, 0x15

    new-array v0, v0, [B

    fill-array-data v0, :array_40

    new-array v1, v1, [B

    fill-array-data v1, :array_50

    invoke-static {v0, v1}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lcom/github/catvod/spider/appysv2/p/m;->b:Ljava/lang/String;

    return-void

    nop

    :array_28
    .array-data 1
        0x35t
        0x2t
        -0x32t
        -0x3at
        0x5ft
        -0x72t
        0x27t
        -0x5dt
        0x6ft
        0x41t
        -0x6ct
        -0x7at
        0x4bt
        -0x6ft
        0x26t
        -0x5dt
        0x67t
        0x41t
        -0x73t
        -0x7ft
        0x52t
        -0x72t
    .end array-data

    nop

    :array_38
    .array-data 1
        0x5dt
        0x76t
        -0x46t
        -0x4at
        0x65t
        -0x5ft
        0x8t
        -0x6et
    .end array-data

    :array_40
    .array-data 1
        0x38t
        0x71t
        0x49t
        -0x4at
        -0x43t
        0x7t
        -0x24t
        -0x8t
        0x62t
        0x32t
        0x13t
        -0xat
        -0x57t
        0x18t
        -0x23t
        -0x8t
        0x6at
        0x32t
        0x4t
        -0x2t
        -0x42t
    .end array-data

    nop

    :array_50
    .array-data 1
        0x50t
        0x5t
        0x3dt
        -0x3at
        -0x79t
        0x28t
        -0xdt
        -0x37t
    .end array-data
.end method

.method public static a(Ljava/lang/String;)Ljava/lang/String;
    .registers 24

    const/16 v1, 0x17

    const/16 v2, 0x8

    :try_start_4
    invoke-static {}, Lcom/github/catvod/spider/appysv2/p/C;->d()Ljava/lang/String;

    move-result-object v0

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const/16 v4, 0x2b

    new-array v4, v4, [B

    const/4 v5, -0x1

    const/4 v6, 0x0

    aput-byte v5, v4, v6

    const/16 v5, 0x69

    const/4 v7, 0x1

    aput-byte v5, v4, v7

    const/16 v8, 0x3d

    const/4 v9, 0x2

    aput-byte v8, v4, v9

    const/16 v10, 0x10

    const/4 v11, 0x3

    aput-byte v10, v4, v11

    const/16 v12, 0x4c

    const/4 v13, 0x4

    aput-byte v12, v4, v13

    const/16 v12, -0x6d

    const/4 v14, 0x5

    aput-byte v12, v4, v14

    const/16 v15, 0x55

    const/16 v16, 0x6

    aput-byte v15, v4, v16

    const/16 v15, 0x7c

    const/16 v17, 0x7

    aput-byte v15, v4, v17

    const/16 v18, -0x5b

    aput-byte v18, v4, v2

    const/16 v18, 0x9

    const/16 v19, 0x2a

    aput-byte v19, v4, v18

    const/16 v18, 0xa

    const/16 v20, 0x67

    aput-byte v20, v4, v18

    const/16 v18, 0xb

    const/16 v20, 0x50

    aput-byte v20, v4, v18

    const/16 v18, 0xc

    const/16 v20, 0x58

    aput-byte v20, v4, v18

    const/16 v18, -0x74

    const/16 v21, 0xd

    aput-byte v18, v4, v21

    const/16 v18, 0x54

    const/16 v22, 0xe

    aput-byte v18, v4, v22

    const/16 v18, 0xf

    aput-byte v15, v4, v18

    const/16 v15, -0x53

    aput-byte v15, v4, v10

    const/16 v10, 0x11

    aput-byte v19, v4, v10

    const/16 v10, 0x12

    const/16 v15, 0x70

    aput-byte v15, v4, v10

    const/16 v10, 0x13

    aput-byte v20, v4, v10

    const/16 v15, 0x14

    const/16 v18, 0x4f

    aput-byte v18, v4, v15

    const/16 v15, 0x15

    aput-byte v12, v4, v15

    const/16 v12, 0x16

    const/16 v18, 0x1b

    aput-byte v18, v4, v12

    aput-byte v8, v4, v1

    const/16 v8, 0x18

    const/4 v12, -0x2

    aput-byte v12, v4, v8

    const/16 v8, 0x19

    const/16 v12, 0x32

    aput-byte v12, v4, v8

    const/16 v8, 0x1a

    const/16 v12, 0x2d

    aput-byte v12, v4, v8

    aput-byte v14, v4, v18

    const/16 v8, 0x1c

    aput-byte v15, v4, v8

    const/16 v8, 0x1d

    const/16 v12, -0x2d

    aput-byte v12, v4, v8

    const/16 v8, 0x1e

    const/16 v12, 0x1e

    aput-byte v12, v4, v8

    const/16 v8, 0x1f

    const/16 v12, 0x28

    aput-byte v12, v4, v8

    const/16 v8, 0x20

    const/16 v12, -0x58

    aput-byte v12, v4, v8

    const/16 v8, 0x21

    aput-byte v5, v4, v8

    const/16 v5, 0x22

    const/16 v8, 0x20

    aput-byte v8, v4, v5

    const/16 v5, 0x23

    aput-byte v21, v4, v5

    const/16 v5, 0x24

    aput-byte v10, v4, v5

    const/16 v5, 0x25

    const/16 v8, -0x31

    aput-byte v8, v4, v5

    const/16 v5, 0x26

    aput-byte v22, v4, v5

    const/16 v5, 0x27

    const/16 v8, 0x2c

    aput-byte v8, v4, v5

    const/16 v5, 0x28

    const/4 v8, -0x6

    aput-byte v8, v4, v5

    const/16 v5, 0x29

    const/16 v8, 0x6d

    aput-byte v8, v4, v5

    const/16 v5, 0x74

    aput-byte v5, v4, v19

    new-array v5, v2, [B

    const/16 v8, -0x69

    aput-byte v8, v5, v6

    const/16 v8, 0x1d

    aput-byte v8, v5, v7

    const/16 v8, 0x49

    aput-byte v8, v5, v9

    const/16 v8, 0x60

    aput-byte v8, v5, v11

    const/16 v8, 0x76

    aput-byte v8, v5, v13

    const/16 v8, -0x44

    aput-byte v8, v5, v14

    const/16 v8, 0x7a

    aput-byte v8, v5, v16

    const/16 v8, 0x4d

    aput-byte v8, v5, v17

    invoke-static {v4, v5}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    new-instance v3, Lorg/json/JSONObject;

    invoke-direct {v3}, Lorg/json/JSONObject;-><init>()V

    new-array v4, v13, [B

    const/16 v5, -0x30

    aput-byte v5, v4, v6

    const/16 v5, -0x2f

    aput-byte v5, v4, v7

    const/16 v5, -0x4d

    aput-byte v5, v4, v9

    const/16 v5, 0x19

    aput-byte v5, v4, v11

    new-array v5, v2, [B

    const/16 v8, -0x4c

    aput-byte v8, v5, v6

    const/16 v6, -0x50

    aput-byte v6, v5, v7

    const/16 v6, -0x39

    aput-byte v6, v5, v9

    const/16 v6, 0x78

    aput-byte v6, v5, v11

    const/4 v6, -0x3

    aput-byte v6, v5, v13

    const/16 v6, 0x5b

    aput-byte v6, v5, v14

    aput-byte v9, v5, v16

    const/16 v6, -0x10

    aput-byte v6, v5, v17

    invoke-static {v4, v5}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v4

    move-object/from16 v5, p0

    invoke-virtual {v3, v4, v5}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    invoke-virtual {v3}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object v3

    const/4 v4, 0x0

    .line 1
    invoke-static {v0, v3, v4}, Lcom/github/catvod/spider/appysv2/n/c;->g(Ljava/lang/String;Ljava/lang/String;Ljava/util/Map;)Lcom/github/catvod/spider/appysv2/n/e;

    move-result-object v0

    invoke-virtual {v0}, Lcom/github/catvod/spider/appysv2/n/e;->a()Ljava/lang/String;

    move-result-object v0
    :try_end_166
    .catch Ljava/lang/Exception; {:try_start_4 .. :try_end_166} :catch_167

    return-object v0

    :catch_167
    move-exception v0

    .line 2
    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    new-array v1, v1, [B

    fill-array-data v1, :array_190

    new-array v2, v2, [B

    fill-array-data v2, :array_1a0

    invoke-static {v1, v2}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lcom/github/catvod/crawler/SpiderDebug;->log(Ljava/lang/String;)V

    const-string v0, ""

    return-object v0

    nop

    :array_190
    .array-data 1
        0x75t
        -0x68t
        -0x43t
        -0x45t
        -0x39t
        0x9t
        -0x25t
        -0x62t
        0x76t
        -0x6et
        -0x2t
        -0x6ft
        -0x25t
        0xft
        -0x4t
        -0x69t
        0x45t
        -0x6ct
        -0x4ft
        -0x46t
        -0x67t
        0x4ct
        -0x47t
    .end array-data

    :array_1a0
    .array-data 1
        0x31t
        -0x3t
        -0x22t
        -0x2ct
        -0x5dt
        0x6ct
        -0x67t
        -0x19t
    .end array-data
.end method

.method public static b()Ljava/lang/Boolean;
    .registers 24

    invoke-static {}, Lcom/github/catvod/spider/appysv2/p/C;->d()Ljava/lang/String;

    move-result-object v1

    const/4 v2, 0x0

    const/4 v3, 0x0

    :cond_6
    :goto_6
    const/4 v4, 0x5

    if-ge v3, v4, :cond_198

    const/16 v5, 0x13

    const/16 v6, 0x11

    const/16 v7, 0x8

    :try_start_f
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/16 v8, 0x29

    new-array v8, v8, [B

    const/16 v9, -0x4f

    aput-byte v9, v8, v2

    const/16 v9, 0x4f

    const/4 v10, 0x1

    aput-byte v9, v8, v10

    const/16 v9, 0x27

    const/4 v11, 0x2

    aput-byte v9, v8, v11

    const/16 v12, 0x12

    const/4 v13, 0x3

    aput-byte v12, v8, v13

    const/4 v14, 0x4

    aput-byte v11, v8, v14

    const/16 v15, -0x25

    aput-byte v15, v8, v4

    const/16 v16, 0x7

    const/16 v17, 0x6

    aput-byte v16, v8, v17

    const/16 v18, -0x30

    aput-byte v18, v8, v16

    const/16 v19, -0x15

    aput-byte v19, v8, v7

    const/16 v19, 0x9

    const/16 v20, 0xc

    aput-byte v20, v8, v19

    const/16 v19, 0xa

    const/16 v21, 0x7d

    aput-byte v21, v8, v19

    const/16 v19, 0x52

    const/16 v21, 0xb

    aput-byte v19, v8, v21

    const/16 v19, 0x16

    aput-byte v19, v8, v20

    const/16 v22, 0xd

    const/16 v23, -0x3c

    aput-byte v23, v8, v22

    const/16 v22, 0xe

    aput-byte v17, v8, v22

    const/16 v22, 0xf

    aput-byte v18, v8, v22

    const/16 v18, 0x10

    const/16 v22, -0x1d

    aput-byte v22, v8, v18

    aput-byte v20, v8, v6

    const/16 v18, 0x6a

    aput-byte v18, v8, v12

    const/16 v12, 0x5a

    aput-byte v12, v8, v5

    const/16 v12, 0x14

    aput-byte v10, v8, v12

    const/16 v18, 0x15

    aput-byte v15, v8, v18

    const/16 v15, 0x49

    aput-byte v15, v8, v19

    const/16 v15, -0x6f

    const/16 v18, 0x17

    aput-byte v15, v8, v18

    const/16 v19, 0x18

    const/16 v20, -0x50

    aput-byte v20, v8, v19

    const/16 v19, 0x19

    aput-byte v12, v8, v19

    const/16 v12, 0x1a

    const/16 v19, 0x23

    aput-byte v19, v8, v12

    const/16 v12, 0x1b

    aput-byte v21, v8, v12

    const/16 v12, 0x1c

    const/16 v21, 0x56

    aput-byte v21, v8, v12

    const/16 v12, 0x1d

    const/16 v22, -0x6d

    aput-byte v22, v8, v12

    const/16 v12, 0x1e

    aput-byte v18, v8, v12

    const/16 v12, 0x1f

    const/16 v18, -0x6b

    aput-byte v18, v8, v12

    const/16 v12, 0x20

    aput-byte v20, v8, v12

    const/16 v12, 0x21

    aput-byte v21, v8, v12

    const/16 v12, 0x22

    const/16 v20, 0x36

    aput-byte v20, v8, v12

    aput-byte v6, v8, v19

    const/16 v12, 0x24

    const/16 v19, 0x4c

    aput-byte v19, v8, v12

    const/16 v12, 0x25

    aput-byte v18, v8, v12

    const/16 v12, 0x26

    const/16 v18, 0x45

    aput-byte v18, v8, v12

    aput-byte v15, v8, v9

    const/16 v9, -0x1c

    const/16 v12, 0x28

    aput-byte v9, v8, v12

    new-array v9, v7, [B

    const/16 v15, -0x27

    aput-byte v15, v9, v2

    const/16 v15, 0x3b

    aput-byte v15, v9, v10

    const/16 v15, 0x53

    aput-byte v15, v9, v11

    const/16 v15, 0x62

    aput-byte v15, v9, v13

    const/16 v15, 0x38

    aput-byte v15, v9, v14

    const/16 v15, -0xc

    aput-byte v15, v9, v4

    aput-byte v12, v9, v17

    const/16 v12, -0x1f

    aput-byte v12, v9, v16

    invoke-static {v8, v9}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v0, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v8, 0x0

    .line 1
    invoke-static {v0, v8}, Lcom/github/catvod/spider/appysv2/n/c;->m(Ljava/lang/String;Ljava/util/Map;)Ljava/lang/String;

    move-result-object v0

    new-array v8, v11, [B

    const/16 v9, -0x1a

    aput-byte v9, v8, v2

    const/4 v9, -0x4

    aput-byte v9, v8, v10

    new-array v9, v7, [B

    const/16 v12, -0x77

    aput-byte v12, v9, v2

    const/16 v12, -0x69

    aput-byte v12, v9, v10

    const/16 v10, 0x57

    aput-byte v10, v9, v11

    const/4 v10, -0x1

    aput-byte v10, v9, v13

    const/16 v10, 0x5e

    aput-byte v10, v9, v14

    const/16 v10, -0x21

    aput-byte v10, v9, v4

    const/16 v10, -0x28

    aput-byte v10, v9, v17

    aput-byte v12, v9, v16

    .line 2
    invoke-static {v8, v9}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v8, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_165

    sget-object v0, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;
    :try_end_13f
    .catch Ljava/lang/Exception; {:try_start_f .. :try_end_13f} :catch_140

    return-object v0

    :catch_140
    move-exception v0

    new-instance v8, Ljava/lang/StringBuilder;

    invoke-direct {v8}, Ljava/lang/StringBuilder;-><init>()V

    new-array v6, v6, [B

    fill-array-data v6, :array_19c

    new-array v9, v7, [B

    fill-array-data v9, :array_1aa

    invoke-static {v6, v9}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v8, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v8, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v8}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lcom/github/catvod/crawler/SpiderDebug;->log(Ljava/lang/String;)V

    :cond_165
    add-int/lit8 v3, v3, 0x1

    if-ge v3, v4, :cond_6

    const-wide/16 v8, 0x3e8

    :try_start_16b
    invoke-static {v8, v9}, Ljava/lang/Thread;->sleep(J)V
    :try_end_16e
    .catch Ljava/lang/InterruptedException; {:try_start_16b .. :try_end_16e} :catch_170

    goto/16 :goto_6

    :catch_170
    move-exception v0

    move-object v4, v0

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    new-array v5, v5, [B

    fill-array-data v5, :array_1b2

    new-array v6, v7, [B

    fill-array-data v6, :array_1c0

    invoke-static {v5, v6}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v0, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lcom/github/catvod/crawler/SpiderDebug;->log(Ljava/lang/String;)V

    goto/16 :goto_6

    :cond_198
    sget-object v0, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    return-object v0

    nop

    :array_19c
    .array-data 1
        -0xat
        -0x4et
        -0x11t
        -0x3et
        -0xft
        -0x2at
        0x33t
        -0x3et
        -0xet
        -0x48t
        -0x37t
        -0x2dt
        -0x16t
        -0x67t
        0x18t
        -0x80t
        -0x4ft
    .end array-data

    nop

    :array_1aa
    .array-data 1
        -0x6ft
        -0x23t
        -0x47t
        -0x59t
        -0x7dt
        -0xat
        0x76t
        -0x46t
    .end array-data

    :array_1b2
    .array-data 1
        0x2ft
        0x55t
        -0x6t
        -0x34t
        0x4bt
        -0x5bt
        -0x7t
        -0x2et
        0x8t
        0x5ct
        -0x13t
        -0x25t
        0x4et
        -0xbt
        -0x1ct
        -0x27t
        0x18t
        0x3t
        -0x41t
    .end array-data

    :array_1c0
    .array-data 1
        0x7ct
        0x39t
        -0x61t
        -0x57t
        0x3bt
        -0x7bt
        -0x70t
        -0x44t
    .end array-data
.end method

.method public static c()Ljava/lang/String;
    .registers 1

    sget-object v0, Lcom/github/catvod/spider/appysv2/p/m;->b:Ljava/lang/String;

    return-object v0
.end method

.method public static d(Ljava/lang/String;II)Ljava/lang/String;
    .registers 9

    invoke-static {}, Lcom/github/catvod/spider/appysv2/p/C;->d()Ljava/lang/String;

    move-result-object v0

    invoke-static {}, Ljava/util/Locale;->getDefault()Ljava/util/Locale;

    move-result-object v1

    const/16 v2, 0x3e

    new-array v2, v2, [B

    fill-array-data v2, :array_40

    const/16 v3, 0x8

    new-array v3, v3, [B

    fill-array-data v3, :array_64

    invoke-static {v2, v3}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v2

    const/4 v3, 0x5

    new-array v3, v3, [Ljava/lang/Object;

    sget-object v4, Lcom/github/catvod/spider/appysv2/p/m;->b:Ljava/lang/String;

    const/4 v5, 0x0

    aput-object v4, v3, v5

    invoke-static {p0}, Ljava/net/URLEncoder;->encode(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    const/4 v4, 0x1

    aput-object p0, v3, v4

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p0

    const/4 p1, 0x2

    aput-object p0, v3, p1

    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p0

    const/4 p1, 0x3

    aput-object p0, v3, p1

    const/4 p0, 0x4

    aput-object v0, v3, p0

    invoke-static {v1, v2, v3}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p0

    return-object p0

    nop

    :array_40
    .array-data 1
        0x5ct
        -0x70t
        -0x66t
        0x35t
        -0x8t
        0x57t
        0x22t
        0x34t
        0xat
        -0x3bt
        -0x2ft
        0x28t
        -0x8t
        0x5et
        0x7et
        0x75t
        0x44t
        -0x3at
        -0x3ft
        0x66t
        -0x17t
        0x53t
        0x6at
        0x7ft
        0x12t
        -0x22t
        -0x80t
        0x24t
        -0x54t
        0x50t
        0x7at
        0x68t
        0x44t
        -0x6et
        -0x30t
        0x21t
        -0x8t
        0x50t
        0x39t
        0x65t
        0x0t
        -0x6dt
        -0x40t
        0x7dt
        -0x5t
        0x4et
        0x7et
        0x63t
        0x12t
        -0x3bt
        -0x2ft
        0x29t
        -0x19t
        0x5et
        0x6ct
        0x65t
        0x18t
        -0x72t
        -0x2bt
        0x7dt
        -0x51t
        0x48t
    .end array-data

    nop

    :array_64
    .array-data 1
        0x79t
        -0x1dt
        -0x5bt
        0x40t
        -0x76t
        0x3bt
        0x1ft
        0x11t
    .end array-data
.end method

.method public static e(Ljava/lang/String;)Ljava/lang/String;
    .registers 6

    invoke-static {}, Ljava/util/Locale;->getDefault()Ljava/util/Locale;

    move-result-object v0

    const/16 v1, 0x13

    new-array v1, v1, [B

    fill-array-data v1, :array_34

    const/16 v2, 0x8

    new-array v2, v2, [B

    fill-array-data v2, :array_42

    invoke-static {v1, v2}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v1

    const/4 v2, 0x3

    new-array v2, v2, [Ljava/lang/Object;

    sget-object v3, Lcom/github/catvod/spider/appysv2/p/m;->a:Ljava/lang/String;

    const/4 v4, 0x0

    aput-object v3, v2, v4

    invoke-static {p0}, Ljava/net/URLEncoder;->encode(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    const/4 v3, 0x1

    aput-object p0, v2, v3

    const/16 p0, 0xa

    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p0

    const/4 v3, 0x2

    aput-object p0, v2, v3

    invoke-static {v0, v1, v2}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p0

    return-object p0

    nop

    :array_34
    .array-data 1
        -0x56t
        0x40t
        0x6at
        0x47t
        -0x2at
        -0x72t
        0x64t
        0x4t
        -0x4t
        0x15t
        0x21t
        0x5at
        -0x2at
        -0x79t
        0x38t
        0x45t
        -0x4et
        0x16t
        0x31t
    .end array-data

    :array_42
    .array-data 1
        -0x71t
        0x33t
        0x55t
        0x32t
        -0x5ct
        -0x1et
        0x59t
        0x21t
    .end array-data
.end method

.method public static f()V
    .registers 7

    sget-object v0, Lcom/github/catvod/spider/appysv2/p/m;->a:Ljava/lang/String;

    const/4 v1, 0x0

    .line 1
    invoke-static {v0, v1}, Lcom/github/catvod/spider/appysv2/n/c;->m(Ljava/lang/String;Ljava/util/Map;)Ljava/lang/String;

    move-result-object v0

    .line 2
    invoke-virtual {v0}, Ljava/lang/String;->isEmpty()Z

    move-result v0

    const/4 v2, 0x3

    if-eqz v0, :cond_47

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const/16 v4, 0x11

    new-array v4, v4, [B

    fill-array-data v4, :array_62

    const/16 v5, 0x8

    new-array v6, v5, [B

    fill-array-data v6, :array_70

    invoke-static {v4, v6}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static {}, Lcom/github/catvod/spider/Proxy;->getPort()I

    move-result v4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    new-array v4, v2, [B

    fill-array-data v4, :array_78

    new-array v5, v5, [B

    fill-array-data v5, :array_7e

    invoke-static {v4, v5}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-static {v3}, Lcom/github/catvod/spider/appysv2/n/c;->l(Ljava/lang/String;)Ljava/lang/String;

    :cond_47
    if-eqz v0, :cond_60

    const/4 v0, 0x0

    :goto_4a
    sget-object v3, Lcom/github/catvod/spider/appysv2/p/m;->a:Ljava/lang/String;

    .line 3
    invoke-static {v3, v1}, Lcom/github/catvod/spider/appysv2/n/c;->m(Ljava/lang/String;Ljava/util/Map;)Ljava/lang/String;

    move-result-object v3

    .line 4
    invoke-virtual {v3}, Ljava/lang/String;->isEmpty()Z

    move-result v3

    if-eqz v3, :cond_60

    if-ge v0, v2, :cond_60

    const-wide/16 v3, 0x14

    invoke-static {v3, v4}, Landroid/os/SystemClock;->sleep(J)V

    add-int/lit8 v0, v0, 0x1

    goto :goto_4a

    :cond_60
    return-void

    nop

    :array_62
    .array-data 1
        0x6et
        0x69t
        -0x73t
        -0x3ft
        -0x23t
        -0x2bt
        -0x19t
        -0x71t
        0x34t
        0x2at
        -0x29t
        -0x7ft
        -0x37t
        -0x36t
        -0x1at
        -0x71t
        0x3ct
    .end array-data

    nop

    :array_70
    .array-data 1
        0x6t
        0x1dt
        -0x7t
        -0x4ft
        -0x19t
        -0x6t
        -0x38t
        -0x42t
    .end array-data

    :array_78
    .array-data 1
        -0x2dt
        0x68t
        0x6t
    .end array-data

    :array_7e
    .array-data 1
        -0x4t
        0xft
        0x69t
        -0x45t
        0x66t
        0x79t
        -0x2at
        0x2at
    .end array-data
.end method

.method public static g()Ljava/lang/String;
    .registers 17

    const/16 v1, 0x12

    const/16 v2, 0x8

    :try_start_4
    invoke-static {}, Lcom/github/catvod/spider/appysv2/p/m;->f()V

    const/16 v0, 0x1d

    new-array v0, v0, [B

    const/16 v3, 0x4e

    const/4 v4, 0x0

    aput-byte v3, v0, v4

    const/16 v5, -0x6b

    const/4 v6, 0x1

    aput-byte v5, v0, v6

    const/16 v5, 0x36

    const/4 v7, 0x2

    aput-byte v5, v0, v7

    const/16 v5, 0x32

    const/4 v8, 0x3

    aput-byte v5, v0, v8

    const/16 v5, 0x4a

    const/4 v9, 0x4

    aput-byte v5, v0, v9

    const/16 v5, -0x3b

    const/4 v10, 0x5

    aput-byte v5, v0, v10

    const/4 v11, 0x6

    aput-byte v3, v0, v11

    const/16 v3, 0xb

    const/4 v12, 0x7

    aput-byte v3, v0, v12

    const/16 v13, 0x14

    aput-byte v13, v0, v2

    const/16 v14, 0x9

    const/16 v15, -0x2a

    aput-byte v15, v0, v14

    const/16 v14, 0xa

    const/16 v16, 0x6c

    aput-byte v16, v0, v14

    const/16 v14, 0x72

    aput-byte v14, v0, v3

    const/16 v14, 0xc

    const/16 v16, 0x5e

    aput-byte v16, v0, v14

    const/16 v14, 0xd

    const/16 v16, -0x26

    aput-byte v16, v0, v14

    const/16 v14, 0xe

    const/16 v16, 0x4f

    aput-byte v16, v0, v14

    const/16 v14, 0xf

    aput-byte v3, v0, v14

    const/16 v3, 0x10

    const/16 v14, 0x1c

    aput-byte v14, v0, v3

    const/16 v3, 0x11

    aput-byte v15, v0, v3

    const/16 v3, 0x75

    aput-byte v3, v0, v1

    const/16 v15, 0x13

    aput-byte v3, v0, v15

    const/16 v3, 0x47

    aput-byte v3, v0, v13

    const/16 v3, 0x15

    aput-byte v5, v0, v3

    const/16 v3, 0x16

    const/16 v5, 0x17

    aput-byte v5, v0, v3

    const/16 v3, 0x5f

    aput-byte v3, v0, v5

    const/16 v3, 0x18

    const/16 v5, 0x54

    aput-byte v5, v0, v3

    const/16 v3, 0x19

    const/16 v5, -0x6e

    aput-byte v5, v0, v3

    const/16 v3, 0x1a

    const/16 v5, 0x2b

    aput-byte v5, v0, v3

    const/16 v3, 0x1b

    const/16 v5, 0x2d

    aput-byte v5, v0, v3

    const/16 v3, 0x1e

    aput-byte v3, v0, v14

    new-array v3, v2, [B

    const/16 v5, 0x26

    aput-byte v5, v3, v4

    const/16 v5, -0x1f

    aput-byte v5, v3, v6

    const/16 v5, 0x42

    aput-byte v5, v3, v7

    aput-byte v5, v3, v8

    const/16 v5, 0x70

    aput-byte v5, v3, v9

    const/16 v5, -0x16

    aput-byte v5, v3, v10

    const/16 v5, 0x61

    aput-byte v5, v3, v11

    const/16 v5, 0x3a

    aput-byte v5, v3, v12

    invoke-static {v0, v3}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x0

    .line 1
    invoke-static {v0, v3}, Lcom/github/catvod/spider/appysv2/n/c;->m(Ljava/lang/String;Ljava/util/Map;)Ljava/lang/String;

    move-result-object v0

    .line 2
    new-instance v3, Lorg/json/JSONObject;

    invoke-direct {v3, v0}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    new-array v0, v12, [B

    const/16 v5, -0x38

    aput-byte v5, v0, v4

    const/16 v5, -0x43

    aput-byte v5, v0, v6

    const/16 v5, -0x1c

    aput-byte v5, v0, v7

    const/16 v5, -0x58

    aput-byte v5, v0, v8

    const/16 v5, -0x23

    aput-byte v5, v0, v9

    const/16 v5, -0x15

    aput-byte v5, v0, v10

    const/16 v5, -0x9

    aput-byte v5, v0, v11

    new-array v5, v2, [B

    const/16 v13, -0x42

    aput-byte v13, v5, v4

    const/16 v4, -0x28

    aput-byte v4, v5, v6

    const/16 v4, -0x6a

    aput-byte v4, v5, v7

    const/16 v4, -0x25

    aput-byte v4, v5, v8

    const/16 v4, -0x4c

    aput-byte v4, v5, v9

    const/16 v4, -0x7c

    aput-byte v4, v5, v10

    const/16 v4, -0x67

    aput-byte v4, v5, v11

    const/16 v4, -0x37

    aput-byte v4, v5, v12

    invoke-static {v0, v5}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v3, v0}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0
    :try_end_111
    .catch Ljava/lang/Exception; {:try_start_4 .. :try_end_111} :catch_112

    return-object v0

    :catch_112
    move-exception v0

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    new-array v1, v1, [B

    fill-array-data v1, :array_13a

    new-array v2, v2, [B

    fill-array-data v2, :array_148

    invoke-static {v1, v2}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lcom/github/catvod/crawler/SpiderDebug;->log(Ljava/lang/String;)V

    const-string v0, ""

    return-object v0

    :array_13a
    .array-data 1
        0x79t
        -0x7t
        -0x65t
        0x53t
        0x1ft
        -0x65t
        0x4at
        -0x1dt
        0x7dt
        -0xdt
        -0x43t
        0x42t
        0x4t
        -0x2ct
        0x61t
        -0x5ft
        0x3et
        -0x4at
    .end array-data

    nop

    :array_148
    .array-data 1
        0x1et
        -0x6at
        -0x33t
        0x36t
        0x6dt
        -0x45t
        0xft
        -0x65t
    .end array-data
.end method

.method public static h(Ljava/lang/String;Ljava/util/Map;)[Ljava/lang/Object;
    .registers 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;)[",
            "Ljava/lang/Object;"
        }
    .end annotation

    invoke-static {p0, p1}, Lcom/github/catvod/spider/appysv2/n/c;->e(Ljava/lang/String;Ljava/util/Map;)Lokhttp3/Response;

    move-result-object p0

    const/16 p1, 0x16

    new-array p1, p1, [B

    fill-array-data p1, :array_5e

    const/16 v0, 0x8

    new-array v0, v0, [B

    fill-array-data v0, :array_6e

    invoke-static {p1, v0}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object p1

    new-instance v0, Ljava/util/HashMap;

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    invoke-virtual {p0}, Lokhttp3/Response;->headers()Lokhttp3/Headers;

    move-result-object v1

    invoke-virtual {v1}, Lokhttp3/Headers;->names()Ljava/util/Set;

    move-result-object v1

    invoke-interface {v1}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_27
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_3f

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/String;

    invoke-virtual {p0}, Lokhttp3/Response;->headers()Lokhttp3/Headers;

    move-result-object v3

    invoke-virtual {v3, v2}, Lokhttp3/Headers;->get(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v0, v2, v3}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_27

    :cond_3f
    const/4 v1, 0x4

    new-array v1, v1, [Ljava/lang/Object;

    const/4 v2, 0x0

    const/16 v3, 0xce

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    aput-object v3, v1, v2

    const/4 v2, 0x1

    aput-object p1, v1, v2

    const/4 p1, 0x2

    invoke-virtual {p0}, Lokhttp3/Response;->body()Lokhttp3/ResponseBody;

    move-result-object p0

    invoke-virtual {p0}, Lokhttp3/ResponseBody;->byteStream()Ljava/io/InputStream;

    move-result-object p0

    aput-object p0, v1, p1

    const/4 p0, 0x3

    aput-object v0, v1, p0

    return-object v1

    nop

    :array_5e
    .array-data 1
        0x21t
        0x15t
        0x40t
        -0x49t
        -0x60t
        0x25t
        0x35t
        -0x1et
        0x29t
        0xat
        0x5et
        -0xct
        -0x5at
        0x25t
        0x20t
        -0x45t
        0x33t
        0x11t
        0x42t
        -0x42t
        -0x58t
        0x2bt
    .end array-data

    nop

    :array_6e
    .array-data 1
        0x40t
        0x65t
        0x30t
        -0x25t
        -0x37t
        0x46t
        0x54t
        -0x6at
    .end array-data
.end method
