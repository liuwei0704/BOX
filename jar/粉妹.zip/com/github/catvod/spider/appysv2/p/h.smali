.class public final Lcom/github/catvod/spider/appysv2/p/h;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field private final a:Ljava/util/concurrent/LinkedBlockingQueue;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/concurrent/BlockingQueue<",
            "Lcom/github/catvod/spider/appysv2/p/g;",
            ">;"
        }
    .end annotation
.end field

.field private final b:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field private final c:Ljava/util/concurrent/ExecutorService;

.field private final d:Ljava/lang/String;

.field private final e:Ljava/util/concurrent/locks/ReentrantLock;

.field private final f:I

.field private final g:I

.field private final h:I

.field private i:J

.field private j:J

.field private k:J

.field private l:J

.field private m:Z


# direct methods
.method public constructor <init>(Ljava/lang/String;Ljava/util/Map;II)V
    .registers 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;II)V"
        }
    .end annotation

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const-wide/16 v0, -0x1

    iput-wide v0, p0, Lcom/github/catvod/spider/appysv2/p/h;->i:J

    iput-wide v0, p0, Lcom/github/catvod/spider/appysv2/p/h;->j:J

    iput-wide v0, p0, Lcom/github/catvod/spider/appysv2/p/h;->k:J

    iput-wide v0, p0, Lcom/github/catvod/spider/appysv2/p/h;->l:J

    iput-object p1, p0, Lcom/github/catvod/spider/appysv2/p/h;->d:Ljava/lang/String;

    iput-object p2, p0, Lcom/github/catvod/spider/appysv2/p/h;->b:Ljava/util/Map;

    iput p3, p0, Lcom/github/catvod/spider/appysv2/p/h;->g:I

    new-instance p1, Ljava/util/concurrent/locks/ReentrantLock;

    invoke-direct {p1}, Ljava/util/concurrent/locks/ReentrantLock;-><init>()V

    iput-object p1, p0, Lcom/github/catvod/spider/appysv2/p/h;->e:Ljava/util/concurrent/locks/ReentrantLock;

    new-instance p1, Ljava/util/concurrent/LinkedBlockingQueue;

    invoke-direct {p1}, Ljava/util/concurrent/LinkedBlockingQueue;-><init>()V

    iput-object p1, p0, Lcom/github/catvod/spider/appysv2/p/h;->a:Ljava/util/concurrent/LinkedBlockingQueue;

    invoke-static {p3}, Ljava/util/concurrent/Executors;->newFixedThreadPool(I)Ljava/util/concurrent/ExecutorService;

    move-result-object p1

    iput-object p1, p0, Lcom/github/catvod/spider/appysv2/p/h;->c:Ljava/util/concurrent/ExecutorService;

    iput p4, p0, Lcom/github/catvod/spider/appysv2/p/h;->h:I

    const/high16 p1, 0x4600000

    div-int/2addr p1, p4

    int-to-double p1, p1

    invoke-static {p1, p2}, Ljava/lang/Math;->ceil(D)D

    move-result-wide p1

    double-to-int p1, p1

    iput p1, p0, Lcom/github/catvod/spider/appysv2/p/h;->f:I

    return-void
.end method

.method public static a(Lcom/github/catvod/spider/appysv2/p/h;Ljava/io/PipedOutputStream;)V
    .registers 5

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    :goto_3
    const/4 v0, 0x0

    .line 1
    :try_start_4
    invoke-direct {p0}, Lcom/github/catvod/spider/appysv2/p/h;->e()[B

    move-result-object v1

    if-eqz v1, :cond_12

    array-length v2, v1

    if-nez v2, :cond_e

    goto :goto_12

    :cond_e
    invoke-virtual {p1, v1}, Ljava/io/OutputStream;->write([B)V
    :try_end_11
    .catch Ljava/lang/Exception; {:try_start_4 .. :try_end_11} :catch_1c
    .catchall {:try_start_4 .. :try_end_11} :catchall_1a

    goto :goto_3

    .line 2
    :cond_12
    :goto_12
    :try_start_12
    iput-boolean v0, p0, Lcom/github/catvod/spider/appysv2/p/h;->m:Z

    .line 3
    :goto_14
    invoke-virtual {p1}, Ljava/io/PipedOutputStream;->close()V
    :try_end_17
    .catch Ljava/lang/Exception; {:try_start_12 .. :try_end_17} :catch_18

    goto :goto_26

    :catch_18
    move-exception p0

    goto :goto_23

    :catchall_1a
    move-exception v1

    goto :goto_27

    :catch_1c
    move-exception v1

    :try_start_1d
    invoke-virtual {v1}, Ljava/lang/Throwable;->printStackTrace()V
    :try_end_20
    .catchall {:try_start_1d .. :try_end_20} :catchall_1a

    .line 4
    :try_start_20
    iput-boolean v0, p0, Lcom/github/catvod/spider/appysv2/p/h;->m:Z
    :try_end_22
    .catch Ljava/lang/Exception; {:try_start_20 .. :try_end_22} :catch_18

    goto :goto_14

    .line 5
    :goto_23
    invoke-virtual {p0}, Ljava/lang/Throwable;->printStackTrace()V

    :goto_26
    return-void

    .line 6
    :goto_27
    :try_start_27
    iput-boolean v0, p0, Lcom/github/catvod/spider/appysv2/p/h;->m:Z

    .line 7
    invoke-virtual {p1}, Ljava/io/PipedOutputStream;->close()V
    :try_end_2c
    .catch Ljava/lang/Exception; {:try_start_27 .. :try_end_2c} :catch_2d

    goto :goto_31

    :catch_2d
    move-exception p0

    invoke-virtual {p0}, Ljava/lang/Throwable;->printStackTrace()V

    :goto_31
    goto :goto_33

    :goto_32
    throw v1

    :goto_33
    goto :goto_32
.end method

.method public static b(Lcom/github/catvod/spider/appysv2/p/h;I)V
    .registers 27

    move-object/from16 v1, p0

    :cond_2
    :goto_2
    iget-boolean v0, v1, Lcom/github/catvod/spider/appysv2/p/h;->m:Z

    if-eqz v0, :cond_23b

    invoke-static {}, Ljava/lang/Thread;->interrupted()Z

    move-result v0

    if-eqz v0, :cond_e

    goto/16 :goto_23b

    :cond_e
    const/4 v0, 0x0

    iget-object v2, v1, Lcom/github/catvod/spider/appysv2/p/h;->e:Ljava/util/concurrent/locks/ReentrantLock;

    invoke-virtual {v2}, Ljava/util/concurrent/locks/ReentrantLock;->lock()V

    iget-wide v2, v1, Lcom/github/catvod/spider/appysv2/p/h;->l:J

    move/from16 v4, p1

    int-to-long v5, v4

    add-long/2addr v5, v2

    iput-wide v5, v1, Lcom/github/catvod/spider/appysv2/p/h;->l:J

    iget-wide v7, v1, Lcom/github/catvod/spider/appysv2/p/h;->j:J

    cmp-long v9, v2, v7

    if-gtz v9, :cond_35

    const-wide/16 v9, 0x1

    sub-long/2addr v5, v9

    cmp-long v0, v5, v7

    if-lez v0, :cond_2a

    goto :goto_2b

    :cond_2a
    move-wide v7, v5

    :goto_2b
    new-instance v0, Lcom/github/catvod/spider/appysv2/p/g;

    invoke-direct {v0, v2, v3, v7, v8}, Lcom/github/catvod/spider/appysv2/p/g;-><init>(JJ)V

    iget-object v2, v1, Lcom/github/catvod/spider/appysv2/p/h;->a:Ljava/util/concurrent/LinkedBlockingQueue;

    invoke-interface {v2, v0}, Ljava/util/concurrent/BlockingQueue;->add(Ljava/lang/Object;)Z

    :cond_35
    move-object v2, v0

    const/4 v3, 0x1

    iget-object v0, v1, Lcom/github/catvod/spider/appysv2/p/h;->e:Ljava/util/concurrent/locks/ReentrantLock;

    invoke-virtual {v0}, Ljava/util/concurrent/locks/ReentrantLock;->unlock()V

    if-nez v2, :cond_40

    goto/16 :goto_23b

    :cond_40
    :goto_40
    iget-boolean v0, v1, Lcom/github/catvod/spider/appysv2/p/h;->m:Z

    const-wide/16 v5, 0x3e8

    if-eqz v0, :cond_5d

    invoke-static {v2}, Lcom/github/catvod/spider/appysv2/p/g;->a(Lcom/github/catvod/spider/appysv2/p/g;)J

    move-result-wide v7

    iget-wide v9, v1, Lcom/github/catvod/spider/appysv2/p/h;->k:J

    sub-long/2addr v7, v9

    iget v0, v1, Lcom/github/catvod/spider/appysv2/p/h;->h:I

    int-to-long v9, v0

    iget v0, v1, Lcom/github/catvod/spider/appysv2/p/h;->f:I

    int-to-long v11, v0

    mul-long v9, v9, v11

    cmp-long v0, v7, v9

    if-ltz v0, :cond_5d

    invoke-static {v5, v6}, Landroid/os/SystemClock;->sleep(J)V

    goto :goto_40

    :cond_5d
    :goto_5d
    iget-boolean v0, v1, Lcom/github/catvod/spider/appysv2/p/h;->m:Z

    if-eqz v0, :cond_2

    :try_start_61
    new-instance v0, Ljava/util/HashMap;

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    iget-object v7, v1, Lcom/github/catvod/spider/appysv2/p/h;->b:Ljava/util/Map;

    invoke-interface {v7}, Ljava/util/Map;->entrySet()Ljava/util/Set;

    move-result-object v7

    invoke-interface {v7}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v7

    :goto_70
    invoke-interface {v7}, Ljava/util/Iterator;->hasNext()Z

    move-result v8

    const/16 v9, 0x61

    const/16 v10, 0x8

    const/4 v11, 0x6

    const/4 v12, 0x4

    const/4 v13, 0x5

    const/4 v14, 0x3

    const/4 v15, 0x2

    const/16 v16, 0x0

    const/16 v17, 0x4a

    const/16 v18, 0xd

    const/16 v19, 0x9

    const/16 v20, 0xa

    if-eqz v8, :cond_192

    invoke-interface {v7}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v8

    check-cast v8, Ljava/util/Map$Entry;

    invoke-interface {v8}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v21

    move-object/from16 v5, v21

    check-cast v5, Ljava/lang/String;

    new-array v6, v13, [B

    const/16 v22, 0x3b

    aput-byte v22, v6, v16

    const/16 v22, 0x36

    aput-byte v22, v6, v3

    const/16 v23, 0x2a

    aput-byte v23, v6, v15

    aput-byte v9, v6, v14

    const/16 v9, -0x1b

    aput-byte v9, v6, v12

    new-array v9, v10, [B

    const/16 v23, 0x69

    aput-byte v23, v9, v16

    const/16 v23, 0x57

    aput-byte v23, v9, v3

    const/16 v23, 0x44

    aput-byte v23, v9, v15

    aput-byte v11, v9, v14

    const/16 v23, -0x80

    aput-byte v23, v9, v12

    const/16 v23, -0x50

    aput-byte v23, v9, v13

    const/16 v24, -0x4b

    aput-byte v24, v9, v11

    const/16 v24, -0x51

    const/16 v21, 0x7

    aput-byte v24, v9, v21

    invoke-static {v6, v9}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v5, v6}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v5

    if-eqz v5, :cond_17f

    new-array v5, v13, [B

    const/16 v6, -0x27

    aput-byte v6, v5, v16

    aput-byte v3, v5, v3

    const/16 v6, 0xb

    aput-byte v6, v5, v15

    aput-byte v18, v5, v14

    const/16 v6, -0x42

    aput-byte v6, v5, v12

    new-array v6, v10, [B

    const/16 v8, -0x75

    aput-byte v8, v6, v16

    const/16 v8, 0x60

    aput-byte v8, v6, v3

    const/16 v8, 0x65

    aput-byte v8, v6, v15

    const/16 v8, 0x6a

    aput-byte v8, v6, v14

    const/16 v8, -0x25

    aput-byte v8, v6, v12

    const/16 v8, -0x7c

    aput-byte v8, v6, v13

    aput-byte v17, v6, v11

    const/4 v8, -0x3

    const/4 v9, 0x7

    aput-byte v8, v6, v9

    invoke-static {v5, v6}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-static {}, Ljava/util/Locale;->getDefault()Ljava/util/Locale;

    move-result-object v6

    const/16 v8, 0xb

    new-array v8, v8, [B

    const/16 v9, -0x5e

    aput-byte v9, v8, v16

    const/16 v9, -0x37

    aput-byte v9, v8, v3

    const/16 v9, -0x4d

    aput-byte v9, v8, v15

    const/16 v9, 0x53

    aput-byte v9, v8, v14

    const/16 v9, 0x58

    aput-byte v9, v8, v12

    const/16 v9, 0x78

    aput-byte v9, v8, v13

    const/16 v9, 0x25

    aput-byte v9, v8, v11

    const/16 v9, -0x12

    const/16 v17, 0x7

    aput-byte v9, v8, v17

    const/16 v9, -0x13

    aput-byte v9, v8, v10

    const/16 v9, -0x6b

    aput-byte v9, v8, v19

    const/16 v9, -0x5d

    aput-byte v9, v8, v20

    new-array v9, v10, [B

    const/16 v10, -0x40

    aput-byte v10, v9, v16

    aput-byte v23, v9, v3

    const/16 v10, -0x39

    aput-byte v10, v9, v15

    aput-byte v22, v9, v14

    const/16 v10, 0x2b

    aput-byte v10, v9, v12

    const/16 v10, 0x45

    aput-byte v10, v9, v13

    aput-byte v16, v9, v11

    const/16 v10, -0x76

    const/4 v11, 0x7

    aput-byte v10, v9, v11

    invoke-static {v8, v9}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v8

    new-array v9, v15, [Ljava/lang/Object;

    invoke-static {v2}, Lcom/github/catvod/spider/appysv2/p/g;->a(Lcom/github/catvod/spider/appysv2/p/g;)J

    move-result-wide v10

    invoke-static {v10, v11}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v10

    aput-object v10, v9, v16

    invoke-static {v2}, Lcom/github/catvod/spider/appysv2/p/g;->b(Lcom/github/catvod/spider/appysv2/p/g;)J

    move-result-wide v10

    invoke-static {v10, v11}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v10

    aput-object v10, v9, v3

    invoke-static {v6, v8, v9}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v6

    goto :goto_18b

    :cond_17f
    invoke-interface {v8}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/lang/String;

    invoke-interface {v8}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Ljava/lang/String;

    :goto_18b
    invoke-virtual {v0, v5, v6}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-wide/16 v5, 0x3e8

    goto/16 :goto_70

    :cond_192
    invoke-direct/range {p0 .. p0}, Lcom/github/catvod/spider/appysv2/p/h;->d()Ljava/lang/String;

    move-result-object v5

    invoke-static {v5, v0}, Lcom/github/catvod/spider/appysv2/n/c;->e(Ljava/lang/String;Ljava/util/Map;)Lokhttp3/Response;

    move-result-object v0

    invoke-virtual {v0}, Lokhttp3/Response;->code()I

    move-result v5

    const/16 v6, 0xc8

    if-lt v5, v6, :cond_1b9

    const/16 v6, 0x12c

    if-ge v5, v6, :cond_1b9

    invoke-virtual {v0}, Lokhttp3/Response;->body()Lokhttp3/ResponseBody;

    move-result-object v5

    if-eqz v5, :cond_2

    invoke-virtual {v0}, Lokhttp3/Response;->body()Lokhttp3/ResponseBody;

    move-result-object v0

    invoke-virtual {v0}, Lokhttp3/ResponseBody;->bytes()[B

    move-result-object v0

    invoke-virtual {v2, v0}, Lcom/github/catvod/spider/appysv2/p/g;->d([B)V

    goto/16 :goto_2

    :cond_1b9
    new-instance v0, Ljava/lang/Exception;

    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    const/16 v7, 0xf

    new-array v7, v7, [B

    const/16 v8, 0x46

    aput-byte v8, v7, v16

    const/16 v8, 0x2f

    aput-byte v8, v7, v3

    aput-byte v9, v7, v15

    const/16 v8, 0x24

    aput-byte v8, v7, v14

    const/16 v8, 0x6c

    aput-byte v8, v7, v12

    aput-byte v11, v7, v13

    aput-byte v20, v7, v11

    const/16 v8, 0xe

    const/4 v9, 0x7

    aput-byte v8, v7, v9

    const/16 v9, 0x14

    aput-byte v9, v7, v10

    const/16 v9, 0x29

    aput-byte v9, v7, v19

    const/16 v9, 0x7d

    aput-byte v9, v7, v20

    const/16 v9, 0x30

    const/16 v19, 0xb

    aput-byte v9, v7, v19

    const/16 v9, 0xc

    const/16 v19, 0x66

    aput-byte v19, v7, v9

    const/16 v9, 0x52

    aput-byte v9, v7, v18

    const/16 v9, 0x59

    aput-byte v9, v7, v8

    new-array v8, v10, [B

    const/16 v9, 0x34

    aput-byte v9, v8, v16

    aput-byte v17, v8, v3

    const/16 v9, 0x12

    aput-byte v9, v8, v15

    const/16 v9, 0x54

    aput-byte v9, v8, v14

    aput-byte v14, v8, v12

    const/16 v9, 0x68

    aput-byte v9, v8, v13

    const/16 v9, 0x79

    aput-byte v9, v8, v11

    const/16 v9, 0x6b

    const/4 v10, 0x7

    aput-byte v9, v8, v10

    invoke-static {v7, v8}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v6, v5}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-direct {v0, v5}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V

    throw v0
    :try_end_230
    .catch Ljava/lang/Exception; {:try_start_61 .. :try_end_230} :catch_230

    :catch_230
    move-exception v0

    invoke-virtual {v0}, Ljava/lang/Throwable;->printStackTrace()V

    const-wide/16 v5, 0x3e8

    invoke-static {v5, v6}, Landroid/os/SystemClock;->sleep(J)V

    goto/16 :goto_5d

    :cond_23b
    :goto_23b
    return-void
.end method

.method private d()Ljava/lang/String;
    .registers 4

    iget-object v0, p0, Lcom/github/catvod/spider/appysv2/p/h;->d:Ljava/lang/String;

    const/4 v1, 0x7

    new-array v1, v1, [B

    fill-array-data v1, :array_24

    const/16 v2, 0x8

    new-array v2, v2, [B

    fill-array-data v2, :array_2c

    invoke-static {v1, v2}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    if-eqz v0, :cond_21

    iget-object v0, p0, Lcom/github/catvod/spider/appysv2/p/h;->d:Ljava/lang/String;

    const/4 v1, 0x0

    .line 1
    invoke-static {v0, v1}, Lcom/github/catvod/spider/appysv2/n/c;->m(Ljava/lang/String;Ljava/util/Map;)Ljava/lang/String;

    move-result-object v0

    return-object v0

    .line 2
    :cond_21
    iget-object v0, p0, Lcom/github/catvod/spider/appysv2/p/h;->d:Ljava/lang/String;

    return-object v0

    :array_24
    .array-data 1
        0x2bt
        -0x7at
        0x27t
        0x6ct
        -0x25t
        0x56t
        0x5bt
    .end array-data

    :array_2c
    .array-data 1
        0x4t
        -0xat
        0x55t
        0x3t
        -0x5dt
        0x2ft
        0x64t
        -0x5ct
    .end array-data
.end method

.method private e()[B
    .registers 8

    iget-wide v0, p0, Lcom/github/catvod/spider/appysv2/p/h;->k:J

    iget-wide v2, p0, Lcom/github/catvod/spider/appysv2/p/h;->j:J

    const/4 v4, 0x0

    const/4 v5, 0x0

    cmp-long v6, v0, v2

    if-lez v6, :cond_d

    .line 1
    iput-boolean v5, p0, Lcom/github/catvod/spider/appysv2/p/h;->m:Z

    return-object v4

    .line 2
    :cond_d
    iget-object v0, p0, Lcom/github/catvod/spider/appysv2/p/h;->a:Ljava/util/concurrent/LinkedBlockingQueue;

    const-wide/16 v1, 0xa

    sget-object v3, Ljava/util/concurrent/TimeUnit;->SECONDS:Ljava/util/concurrent/TimeUnit;

    invoke-virtual {v0, v1, v2, v3}, Ljava/util/concurrent/LinkedBlockingQueue;->poll(JLjava/util/concurrent/TimeUnit;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/github/catvod/spider/appysv2/p/g;

    if-eqz v0, :cond_34

    :goto_1b
    iget-boolean v1, p0, Lcom/github/catvod/spider/appysv2/p/h;->m:Z

    if-eqz v1, :cond_33

    invoke-virtual {v0}, Lcom/github/catvod/spider/appysv2/p/g;->c()[B

    move-result-object v1

    if-eqz v1, :cond_2d

    iget-wide v2, p0, Lcom/github/catvod/spider/appysv2/p/h;->k:J

    array-length v0, v1

    int-to-long v4, v0

    add-long/2addr v2, v4

    iput-wide v2, p0, Lcom/github/catvod/spider/appysv2/p/h;->k:J

    return-object v1

    :cond_2d
    const-wide/16 v1, 0x64

    invoke-static {v1, v2}, Landroid/os/SystemClock;->sleep(J)V

    goto :goto_1b

    :cond_33
    return-object v4

    .line 3
    :cond_34
    iput-boolean v5, p0, Lcom/github/catvod/spider/appysv2/p/h;->m:Z

    .line 4
    new-instance v0, Ljava/lang/Exception;

    const/16 v1, 0xc

    new-array v1, v1, [B

    fill-array-data v1, :array_50

    const/16 v2, 0x8

    new-array v2, v2, [B

    fill-array-data v2, :array_5a

    invoke-static {v1, v2}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V

    goto :goto_4f

    :goto_4e
    throw v0

    :goto_4f
    goto :goto_4e

    :array_50
    .array-data 1
        -0x2et
        0x5ft
        -0x28t
        0x3ct
        -0xet
        -0x64t
        -0x30t
        0x1t
        -0x3bt
        0x55t
        -0x34t
        0x2ct
    .end array-data

    :array_5a
    .array-data 1
        -0x60t
        0x3at
        -0x47t
        0x58t
        -0x2et
        -0x18t
        -0x47t
        0x6ct
    .end array-data
.end method


# virtual methods
.method public final c()V
    .registers 2

    const/4 v0, 0x0

    iput-boolean v0, p0, Lcom/github/catvod/spider/appysv2/p/h;->m:Z

    iget-object v0, p0, Lcom/github/catvod/spider/appysv2/p/h;->c:Ljava/util/concurrent/ExecutorService;

    invoke-interface {v0}, Ljava/util/concurrent/ExecutorService;->shutdownNow()Ljava/util/List;

    return-void
.end method

.method public final f()[Ljava/lang/Object;
    .registers 16

    iget-object v0, p0, Lcom/github/catvod/spider/appysv2/p/h;->b:Ljava/util/Map;

    const/4 v1, 0x5

    new-array v2, v1, [B

    fill-array-data v2, :array_274

    const/16 v3, 0x8

    new-array v4, v3, [B

    fill-array-data v4, :array_27c

    invoke-static {v2, v4}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-interface {v0, v2}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_3a

    iget-object v0, p0, Lcom/github/catvod/spider/appysv2/p/h;->b:Ljava/util/Map;

    new-array v2, v1, [B

    fill-array-data v2, :array_284

    new-array v4, v3, [B

    fill-array-data v4, :array_28c

    invoke-static {v2, v4}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v2

    new-array v4, v3, [B

    fill-array-data v4, :array_294

    new-array v5, v3, [B

    fill-array-data v5, :array_29c

    invoke-static {v4, v5}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-interface {v0, v2, v4}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_3a
    const/16 v0, 0x12

    new-array v0, v0, [B

    fill-array-data v0, :array_2a4

    new-array v2, v3, [B

    fill-array-data v2, :array_2b2

    invoke-static {v0, v2}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    move-result-object v0

    iget-object v2, p0, Lcom/github/catvod/spider/appysv2/p/h;->b:Ljava/util/Map;

    new-array v4, v1, [B

    fill-array-data v4, :array_2ba

    new-array v5, v3, [B

    fill-array-data v5, :array_2c2

    invoke-static {v4, v5}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-interface {v2, v4}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/CharSequence;

    invoke-virtual {v0, v2}, Ljava/util/regex/Pattern;->matcher(Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;

    move-result-object v0

    invoke-virtual {v0}, Ljava/util/regex/Matcher;->find()Z

    move-result v2

    const/16 v4, 0xf

    if-eqz v2, :cond_238

    const/4 v1, 0x1

    invoke-virtual {v0, v1}, Ljava/util/regex/Matcher;->group(I)Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Ljava/lang/Long;->parseLong(Ljava/lang/String;)J

    move-result-wide v5

    iput-wide v5, p0, Lcom/github/catvod/spider/appysv2/p/h;->i:J

    const/4 v2, 0x2

    invoke-virtual {v0, v2}, Ljava/util/regex/Matcher;->group(I)Ljava/lang/String;

    move-result-object v5

    if-eqz v5, :cond_8c

    invoke-virtual {v0, v2}, Ljava/util/regex/Matcher;->group(I)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Ljava/lang/Long;->parseLong(Ljava/lang/String;)J

    move-result-wide v5

    iput-wide v5, p0, Lcom/github/catvod/spider/appysv2/p/h;->j:J

    :cond_8c
    iget-wide v5, p0, Lcom/github/catvod/spider/appysv2/p/h;->i:J

    iput-wide v5, p0, Lcom/github/catvod/spider/appysv2/p/h;->l:J

    iput-wide v5, p0, Lcom/github/catvod/spider/appysv2/p/h;->k:J

    invoke-direct {p0}, Lcom/github/catvod/spider/appysv2/p/h;->d()Ljava/lang/String;

    move-result-object v0

    iget-object v5, p0, Lcom/github/catvod/spider/appysv2/p/h;->b:Ljava/util/Map;

    invoke-static {v0, v5}, Lcom/github/catvod/spider/appysv2/n/c;->e(Ljava/lang/String;Ljava/util/Map;)Lokhttp3/Response;

    move-result-object v0

    invoke-virtual {v0}, Lokhttp3/Response;->body()Lokhttp3/ResponseBody;

    move-result-object v5

    if-eqz v5, :cond_a9

    invoke-virtual {v0}, Lokhttp3/Response;->body()Lokhttp3/ResponseBody;

    move-result-object v5

    invoke-virtual {v5}, Lokhttp3/ResponseBody;->close()V

    :cond_a9
    invoke-virtual {v0}, Lokhttp3/Response;->code()I

    move-result v5

    const/16 v6, 0xc8

    if-lt v5, v6, :cond_215

    const/16 v6, 0x12c

    if-ge v5, v6, :cond_215

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const/16 v6, 0x1b

    new-array v6, v6, [B

    fill-array-data v6, :array_2ca

    new-array v7, v3, [B

    fill-array-data v7, :array_2dc

    invoke-static {v6, v7}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v4, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-static {v4}, Lcom/github/catvod/crawler/SpiderDebug;->log(Ljava/lang/String;)V

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const/16 v5, 0x16

    new-array v6, v5, [B

    fill-array-data v6, :array_2e4

    new-array v7, v3, [B

    fill-array-data v7, :array_2f4

    invoke-static {v6, v7}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v4, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Lokhttp3/Response;->headers()Lokhttp3/Headers;

    move-result-object v6

    invoke-virtual {v4, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-static {v4}, Lcom/github/catvod/crawler/SpiderDebug;->log(Ljava/lang/String;)V

    new-array v4, v5, [B

    fill-array-data v4, :array_2fc

    new-array v5, v3, [B

    fill-array-data v5, :array_30c

    invoke-static {v4, v5}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v0}, Lokhttp3/Response;->headers()Lokhttp3/Headers;

    move-result-object v5

    const/16 v6, 0xe

    new-array v6, v6, [B

    fill-array-data v6, :array_314

    new-array v7, v3, [B

    fill-array-data v7, :array_320

    invoke-static {v6, v7}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v5, v6}, Lokhttp3/Headers;->get(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    if-eqz v5, :cond_1ff

    invoke-static {v5}, Ljava/lang/Long;->parseLong(Ljava/lang/String;)J

    iget-wide v5, p0, Lcom/github/catvod/spider/appysv2/p/h;->j:J

    const-wide/16 v7, 0x0

    const-wide/16 v9, 0x1

    cmp-long v11, v5, v7

    if-gtz v11, :cond_19d

    invoke-virtual {v0}, Lokhttp3/Response;->headers()Lokhttp3/Headers;

    move-result-object v0

    const/16 v5, 0xd

    new-array v5, v5, [B

    fill-array-data v5, :array_328

    new-array v6, v3, [B

    fill-array-data v6, :array_334

    invoke-static {v5, v6}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v0, v5}, Lokhttp3/Headers;->get(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    if-eqz v0, :cond_187

    new-array v5, v3, [B

    fill-array-data v5, :array_33c

    new-array v6, v3, [B

    fill-array-data v6, :array_344

    .line 1
    invoke-static {v5, v6, v0}, Lcom/github/catvod/spider/appysv2/b/u;->b([B[BLjava/lang/String;)Ljava/util/regex/Matcher;

    move-result-object v5

    .line 2
    invoke-virtual {v5}, Ljava/util/regex/Matcher;->find()Z

    move-result v6

    if-eqz v6, :cond_16c

    invoke-virtual {v5, v1}, Ljava/util/regex/Matcher;->group(I)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Ljava/lang/Long;->parseLong(Ljava/lang/String;)J

    move-result-wide v5

    sub-long/2addr v5, v9

    iput-wide v5, p0, Lcom/github/catvod/spider/appysv2/p/h;->j:J

    goto :goto_19d

    :cond_16c
    new-instance v1, Ljava/lang/Exception;

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/16 v4, 0x19

    new-array v4, v4, [B

    fill-array-data v4, :array_34c

    new-array v3, v3, [B

    fill-array-data v3, :array_35e

    .line 3
    invoke-static {v4, v3, v2, v0}, Lcom/github/catvod/spider/appysv2/b/u;->a([B[BLjava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 4
    invoke-direct {v1, v0}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V

    throw v1

    :cond_187
    new-instance v0, Ljava/lang/Exception;

    const/16 v1, 0x26

    new-array v1, v1, [B

    fill-array-data v1, :array_366

    new-array v2, v3, [B

    fill-array-data v2, :array_37e

    invoke-static {v1, v2}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_19d
    :goto_19d
    iget v0, p0, Lcom/github/catvod/spider/appysv2/p/h;->h:I

    iget v3, p0, Lcom/github/catvod/spider/appysv2/p/h;->g:I

    iget-wide v5, p0, Lcom/github/catvod/spider/appysv2/p/h;->i:J

    const/4 v11, 0x3

    cmp-long v12, v5, v7

    if-eqz v12, :cond_1b5

    iget-wide v7, p0, Lcom/github/catvod/spider/appysv2/p/h;->j:J

    sub-long/2addr v7, v5

    const-wide/32 v12, 0x100000

    cmp-long v14, v7, v12

    if-gtz v14, :cond_1b3

    goto :goto_1b5

    :cond_1b3
    move v7, v0

    goto :goto_1b9

    :cond_1b5
    :goto_1b5
    const/4 v3, 0x3

    const v7, 0x10400

    :goto_1b9
    iget-wide v12, p0, Lcom/github/catvod/spider/appysv2/p/h;->j:J

    sub-long/2addr v12, v5

    add-long/2addr v12, v9

    int-to-long v5, v3

    div-long/2addr v12, v5

    add-long/2addr v12, v9

    int-to-long v5, v7

    cmp-long v7, v5, v12

    if-lez v7, :cond_1c6

    long-to-int v0, v12

    :cond_1c6
    iput-boolean v1, p0, Lcom/github/catvod/spider/appysv2/p/h;->m:Z

    const/4 v5, 0x0

    const/4 v6, 0x0

    :goto_1ca
    if-ge v6, v3, :cond_1d9

    iget-object v7, p0, Lcom/github/catvod/spider/appysv2/p/h;->c:Ljava/util/concurrent/ExecutorService;

    new-instance v8, Lcom/github/catvod/spider/appysv2/p/f;

    invoke-direct {v8, p0, v0}, Lcom/github/catvod/spider/appysv2/p/f;-><init>(Lcom/github/catvod/spider/appysv2/p/h;I)V

    invoke-interface {v7, v8}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V

    add-int/lit8 v6, v6, 0x1

    goto :goto_1ca

    :cond_1d9
    new-instance v0, Ljava/io/PipedInputStream;

    invoke-direct {v0}, Ljava/io/PipedInputStream;-><init>()V

    new-instance v3, Ljava/io/PipedOutputStream;

    invoke-direct {v3, v0}, Ljava/io/PipedOutputStream;-><init>(Ljava/io/PipedInputStream;)V

    new-instance v6, Lcom/github/catvod/spider/appysv2/b/K;

    invoke-direct {v6, p0, v3, v2}, Lcom/github/catvod/spider/appysv2/b/K;-><init>(Ljava/lang/Object;Ljava/lang/Object;I)V

    invoke-static {v6}, Lcom/github/catvod/spider/Init;->execute(Ljava/lang/Runnable;)V

    const/4 v3, 0x4

    new-array v3, v3, [Ljava/lang/Object;

    const/16 v6, 0xce

    invoke-static {v6}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v6

    aput-object v6, v3, v5

    aput-object v4, v3, v1

    aput-object v0, v3, v2

    iget-object v0, p0, Lcom/github/catvod/spider/appysv2/p/h;->b:Ljava/util/Map;

    aput-object v0, v3, v11

    return-object v3

    :cond_1ff
    new-instance v0, Ljava/lang/Exception;

    const/16 v1, 0x27

    new-array v1, v1, [B

    fill-array-data v1, :array_386

    new-array v2, v3, [B

    fill-array-data v2, :array_39e

    invoke-static {v1, v2}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_215
    new-instance v0, Ljava/lang/Exception;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    new-array v2, v4, [B

    fill-array-data v2, :array_3a6

    new-array v3, v3, [B

    fill-array-data v3, :array_3b2

    invoke-static {v2, v3}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v5}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_238
    new-instance v0, Ljava/lang/Exception;

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    new-array v4, v4, [B

    fill-array-data v4, :array_3ba

    new-array v5, v3, [B

    fill-array-data v5, :array_3c6

    invoke-static {v4, v5}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v4, p0, Lcom/github/catvod/spider/appysv2/p/h;->b:Ljava/util/Map;

    new-array v1, v1, [B

    fill-array-data v1, :array_3ce

    new-array v3, v3, [B

    fill-array-data v3, :array_3d6

    invoke-static {v1, v3}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-interface {v4, v1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V

    goto :goto_272

    :goto_271
    throw v0

    :goto_272
    goto :goto_271

    nop

    :array_274
    .array-data 1
        -0x6dt
        0x39t
        0x6et
        -0x4ct
        0x38t
    .end array-data

    nop

    :array_27c
    .array-data 1
        -0x3ft
        0x58t
        0x0t
        -0x2dt
        0x5dt
        0x2ct
        -0x79t
        -0x6dt
    .end array-data

    :array_284
    .array-data 1
        0xat
        0x5bt
        0xbt
        -0x27t
        0x75t
    .end array-data

    nop

    :array_28c
    .array-data 1
        0x58t
        0x3at
        0x65t
        -0x42t
        0x10t
        0x7at
        0x9t
        -0x21t
    .end array-data

    :array_294
    .array-data 1
        0x10t
        0x4et
        -0x3t
        -0x7ft
        -0x48t
        -0x10t
        0x5bt
        -0x1dt
    .end array-data

    :array_29c
    .array-data 1
        0x72t
        0x37t
        -0x77t
        -0x1ct
        -0x35t
        -0x33t
        0x6bt
        -0x32t
    .end array-data

    :array_2a4
    .array-data 1
        0x11t
        0x11t
        -0x20t
        0x68t
        -0x33t
        -0x27t
        0x34t
        -0x17t
        0x17t
        0x43t
        -0x43t
        0x20t
        -0x6at
        -0x48t
        0x78t
        -0x62t
        0x5at
        0x57t
    .end array-data

    nop

    :array_2b2
    .array-data 1
        0x73t
        0x68t
        -0x6ct
        0xdt
        -0x42t
        -0x1ct
        0x1ct
        -0x4bt
    .end array-data

    :array_2ba
    .array-data 1
        -0x4ft
        -0x12t
        -0x47t
        0x32t
        0x39t
    .end array-data

    nop

    :array_2c2
    .array-data 1
        -0x1dt
        -0x71t
        -0x29t
        0x55t
        0x5ct
        0x1ct
        -0x35t
        -0x17t
    .end array-data

    :array_2ca
    .array-data 1
        0x5et
        0x58t
        -0x12t
        0x6t
        -0x25t
        -0x19t
        -0x48t
        -0x33t
        0x49t
        0x43t
        -0x2t
        0x59t
        -0x6ct
        -0x10t
        -0x15t
        -0x35t
        0x4dt
        0x42t
        -0x6t
        0xct
        -0x26t
        -0x47t
        -0x52t
        -0x6t
        0x47t
        0x55t
        -0x11t
    .end array-data

    :array_2dc
    .array-data 1
        0x28t
        0x31t
        -0x76t
        0x63t
        -0x4ct
        -0x36t
        -0x35t
        -0x47t
    .end array-data

    :array_2e4
    .array-data 1
        -0x3at
        -0x39t
        -0x65t
        -0x5t
        -0x63t
        0x7et
        -0x15t
        -0x57t
        -0x2ft
        -0x24t
        -0x75t
        -0x5ct
        -0x2et
        0x3bt
        -0x3t
        -0x44t
        -0x2ct
        -0x35t
        -0x73t
        -0x13t
        -0x38t
        0x73t
    .end array-data

    nop

    :array_2f4
    .array-data 1
        -0x50t
        -0x52t
        -0x1t
        -0x62t
        -0xet
        0x53t
        -0x68t
        -0x23t
    .end array-data

    :array_2fc
    .array-data 1
        0x4et
        -0x4ct
        0x67t
        0x7ct
        0x29t
        0x72t
        -0x3et
        0x69t
        0x46t
        -0x55t
        0x79t
        0x3ft
        0x2ft
        0x72t
        -0x29t
        0x30t
        0x5ct
        -0x50t
        0x65t
        0x75t
        0x21t
        0x7ct
    .end array-data

    nop

    :array_30c
    .array-data 1
        0x2ft
        -0x3ct
        0x17t
        0x10t
        0x40t
        0x11t
        -0x5dt
        0x1dt
    .end array-data

    :array_314
    .array-data 1
        -0x2bt
        0x51t
        -0x31t
        0x6at
        0x36t
        -0xet
        0x2t
        0x4t
        -0x26t
        0x5bt
        -0x31t
        0x79t
        0x27t
        -0xct
    .end array-data

    nop

    :array_320
    .array-data 1
        -0x6at
        0x3et
        -0x5ft
        0x1et
        0x53t
        -0x64t
        0x76t
        0x29t
    .end array-data

    :array_328
    .array-data 1
        0x5dt
        -0x70t
        0x2ct
        -0x70t
        0x52t
        -0x25t
        0xbt
        0x22t
        0x4ct
        -0x62t
        0x2ct
        -0x7dt
        0x52t
    .end array-data

    nop

    :array_334
    .array-data 1
        0x1et
        -0x1t
        0x42t
        -0x1ct
        0x37t
        -0x4bt
        0x7ft
        0xft
    .end array-data

    :array_33c
    .array-data 1
        0x45t
        0x62t
        0x14t
        0x63t
        -0x4at
        0x7at
        -0x35t
        0x38t
    .end array-data

    :array_344
    .array-data 1
        0x6bt
        0x48t
        0x3bt
        0x4bt
        -0x16t
        0x1et
        -0x20t
        0x11t
    .end array-data

    :array_34c
    .array-data 1
        -0x4et
        -0x65t
        -0x68t
        0x26t
        0x59t
        0x49t
        0x44t
        -0x35t
        -0x45t
        -0x4at
        -0x7ft
        0x29t
        0x41t
        0x45t
        0x4et
        -0x61t
        -0xat
        -0x59t
        -0x71t
        0x29t
        0x52t
        0x45t
        0x40t
        -0x2ft
        -0x5t
    .end array-data

    nop

    :array_35e
    .array-data 1
        -0x25t
        -0xbt
        -0x12t
        0x47t
        0x35t
        0x20t
        0x20t
        -0x15t
    .end array-data

    :array_366
    .array-data 1
        0x34t
        -0x74t
        0x4ct
        -0x36t
        -0x4ct
        0x36t
        -0x2t
        0x60t
        0x2bt
        -0x80t
        0x4ct
        -0x37t
        -0x4et
        0x36t
        -0x16t
        0x25t
        0x79t
        -0x73t
        0x5at
        -0x28t
        -0x47t
        0x3dt
        -0x15t
        0x7at
        0x79t
        -0x5at
        0x50t
        -0x29t
        -0x57t
        0x3dt
        -0x9t
        0x34t
        0x74t
        -0x49t
        0x5et
        -0x29t
        -0x46t
        0x3dt
    .end array-data

    nop

    :array_37e
    .array-data 1
        0x59t
        -0x1bt
        0x3ft
        -0x47t
        -0x23t
        0x58t
        -0x67t
        0x40t
    .end array-data

    :array_386
    .array-data 1
        -0x5ct
        0x33t
        -0x7ft
        -0x3at
        -0x20t
        0x46t
        -0x6t
        0x21t
        -0x45t
        0x3ft
        -0x7ft
        -0x3bt
        -0x1at
        0x46t
        -0x12t
        0x64t
        -0x17t
        0x32t
        -0x69t
        -0x2ct
        -0x13t
        0x4dt
        -0x11t
        0x3bt
        -0x17t
        0x19t
        -0x63t
        -0x25t
        -0x3t
        0x4dt
        -0xdt
        0x75t
        -0x1ct
        0x16t
        -0x69t
        -0x25t
        -0x12t
        0x5ct
        -0xbt
    .end array-data

    :array_39e
    .array-data 1
        -0x37t
        0x5at
        -0xet
        -0x4bt
        -0x77t
        0x28t
        -0x63t
        0x1t
    .end array-data

    :array_3a6
    .array-data 1
        -0x23t
        -0x75t
        -0x17t
        0x5bt
        0x2bt
        -0x31t
        -0x75t
        -0x2t
        -0x71t
        -0x73t
        -0xbt
        0x4ft
        0x21t
        -0x65t
        -0x28t
    .end array-data

    :array_3b2
    .array-data 1
        -0x51t
        -0x12t
        -0x66t
        0x2bt
        0x44t
        -0x5ft
        -0x8t
        -0x65t
    .end array-data

    :array_3ba
    .array-data 1
        0x14t
        0x1dt
        0x5ft
        -0x6bt
        -0x68t
        -0x3dt
        0x71t
        0x7at
        0x2ft
        0x12t
        0x47t
        -0x6dt
        -0x6ft
        -0x70t
        0x35t
    .end array-data

    :array_3c6
    .array-data 1
        0x7dt
        0x73t
        0x29t
        -0xct
        -0xct
        -0x56t
        0x15t
        0x5at
    .end array-data

    :array_3ce
    .array-data 1
        -0x24t
        -0x7dt
        -0x32t
        -0x1ft
        0x71t
    .end array-data

    nop

    :array_3d6
    .array-data 1
        -0x72t
        -0x1et
        -0x60t
        -0x7at
        0x14t
        0x7t
        -0x50t
        -0x6ct
    .end array-data
.end method
