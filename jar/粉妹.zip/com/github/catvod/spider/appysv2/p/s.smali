.class public final synthetic Lcom/github/catvod/spider/appysv2/p/s;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/content/DialogInterface$OnClickListener;


# instance fields
.field public final synthetic a:Lcom/github/catvod/spider/appysv2/p/B;

.field public final synthetic b:Landroid/widget/EditText;

.field public final synthetic c:Ljava/lang/String;

.field public final synthetic d:Landroid/widget/EditText;


# direct methods
.method public synthetic constructor <init>(Lcom/github/catvod/spider/appysv2/p/B;Landroid/widget/EditText;Ljava/lang/String;Landroid/widget/EditText;)V
    .registers 5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/github/catvod/spider/appysv2/p/s;->a:Lcom/github/catvod/spider/appysv2/p/B;

    iput-object p2, p0, Lcom/github/catvod/spider/appysv2/p/s;->b:Landroid/widget/EditText;

    iput-object p3, p0, Lcom/github/catvod/spider/appysv2/p/s;->c:Ljava/lang/String;

    iput-object p4, p0, Lcom/github/catvod/spider/appysv2/p/s;->d:Landroid/widget/EditText;

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/content/DialogInterface;I)V
    .registers 6

    iget-object p1, p0, Lcom/github/catvod/spider/appysv2/p/s;->a:Lcom/github/catvod/spider/appysv2/p/B;

    iget-object p2, p0, Lcom/github/catvod/spider/appysv2/p/s;->b:Landroid/widget/EditText;

    iget-object v0, p0, Lcom/github/catvod/spider/appysv2/p/s;->c:Ljava/lang/String;

    iget-object v1, p0, Lcom/github/catvod/spider/appysv2/p/s;->d:Landroid/widget/EditText;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p2}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v2

    if-nez v2, :cond_21

    new-instance v2, Lcom/github/catvod/spider/appysv2/p/q;

    invoke-direct {v2, p1, v0, p2}, Lcom/github/catvod/spider/appysv2/p/q;-><init>(Lcom/github/catvod/spider/appysv2/p/B;Ljava/lang/String;Landroid/widget/EditText;)V

    invoke-static {v2}, Lcom/github/catvod/spider/Init;->execute(Ljava/lang/Runnable;)V

    :cond_21
    invoke-virtual {v1}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object p2

    invoke-virtual {p2}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p2

    invoke-static {p2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result p2

    if-nez p2, :cond_38

    new-instance p2, Lcom/github/catvod/spider/appysv2/b/j;

    const/4 v0, 0x5

    invoke-direct {p2, p1, v1, v0}, Lcom/github/catvod/spider/appysv2/b/j;-><init>(Ljava/lang/Object;Ljava/lang/Object;I)V

    invoke-static {p2}, Lcom/github/catvod/spider/Init;->execute(Ljava/lang/Runnable;)V

    :cond_38
    return-void
.end method
