.class final Lcom/github/catvod/spider/appysv2/p/c;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lcom/github/catvod/spider/appysv2/p/b;


# instance fields
.field private final a:Ljava/lang/String;

.field private final b:Ljava/util/HashMap;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/HashMap<",
            "Ljava/lang/String;",
            "Ljava/io/File;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method constructor <init>(Ljava/lang/String;)V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Ljava/util/HashMap;

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    iput-object v0, p0, Lcom/github/catvod/spider/appysv2/p/c;->b:Ljava/util/HashMap;

    iput-object p1, p0, Lcom/github/catvod/spider/appysv2/p/c;->a:Ljava/lang/String;

    return-void
.end method


# virtual methods
.method public final a(Ljava/io/File;)Landroid/net/Uri;
    .registers 9

    const/16 v0, 0x8

    :try_start_2
    invoke-virtual {p1}, Ljava/io/File;->getCanonicalPath()Ljava/lang/String;

    move-result-object p1
    :try_end_6
    .catch Ljava/io/IOException; {:try_start_2 .. :try_end_6} :catch_e6

    const/4 v1, 0x0

    iget-object v2, p0, Lcom/github/catvod/spider/appysv2/p/c;->b:Ljava/util/HashMap;

    invoke-virtual {v2}, Ljava/util/HashMap;->entrySet()Ljava/util/Set;

    move-result-object v2

    invoke-interface {v2}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :cond_11
    :goto_11
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_45

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/util/Map$Entry;

    invoke-interface {v3}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/io/File;

    invoke-virtual {v4}, Ljava/io/File;->getPath()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {p1, v4}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v5

    if-eqz v5, :cond_11

    if-eqz v1, :cond_43

    invoke-virtual {v4}, Ljava/lang/String;->length()I

    move-result v4

    invoke-interface {v1}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/io/File;

    invoke-virtual {v5}, Ljava/io/File;->getPath()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/String;->length()I

    move-result v5

    if-le v4, v5, :cond_11

    :cond_43
    move-object v1, v3

    goto :goto_11

    :cond_45
    if-eqz v1, :cond_cb

    invoke-interface {v1}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/io/File;

    invoke-virtual {v2}, Ljava/io/File;->getPath()Ljava/lang/String;

    move-result-object v2

    const/4 v3, 0x1

    new-array v4, v3, [B

    const/16 v5, 0x13

    const/4 v6, 0x0

    aput-byte v5, v4, v6

    new-array v5, v0, [B

    fill-array-data v5, :array_10e

    invoke-static {v4, v5}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v2, v4}, Ljava/lang/String;->endsWith(Ljava/lang/String;)Z

    move-result v4

    invoke-virtual {v2}, Ljava/lang/String;->length()I

    move-result v2

    if-eqz v4, :cond_6d

    goto :goto_6f

    :cond_6d
    add-int/lit8 v2, v2, 0x1

    :goto_6f
    invoke-virtual {p1, v2}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object p1

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-interface {v1}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    invoke-static {v1}, Landroid/net/Uri;->encode(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v1, 0x2f

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    new-array v1, v3, [B

    const/16 v3, -0x27

    aput-byte v3, v1, v6

    new-array v3, v0, [B

    fill-array-data v3, :array_116

    invoke-static {v1, v3}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-static {p1, v1}, Landroid/net/Uri;->encode(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    new-instance v1, Landroid/net/Uri$Builder;

    invoke-direct {v1}, Landroid/net/Uri$Builder;-><init>()V

    const/4 v2, 0x7

    new-array v2, v2, [B

    fill-array-data v2, :array_11e

    new-array v0, v0, [B

    fill-array-data v0, :array_126

    invoke-static {v2, v0}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v1, v0}, Landroid/net/Uri$Builder;->scheme(Ljava/lang/String;)Landroid/net/Uri$Builder;

    move-result-object v0

    iget-object v1, p0, Lcom/github/catvod/spider/appysv2/p/c;->a:Ljava/lang/String;

    invoke-virtual {v0, v1}, Landroid/net/Uri$Builder;->authority(Ljava/lang/String;)Landroid/net/Uri$Builder;

    move-result-object v0

    invoke-virtual {v0, p1}, Landroid/net/Uri$Builder;->encodedPath(Ljava/lang/String;)Landroid/net/Uri$Builder;

    move-result-object p1

    invoke-virtual {p1}, Landroid/net/Uri$Builder;->build()Landroid/net/Uri;

    move-result-object p1

    return-object p1

    :cond_cb
    new-instance v1, Ljava/lang/IllegalArgumentException;

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/16 v3, 0x2d

    new-array v3, v3, [B

    fill-array-data v3, :array_12e

    new-array v0, v0, [B

    fill-array-data v0, :array_14a

    .line 1
    invoke-static {v3, v0, v2, p1}, Lcom/github/catvod/spider/appysv2/b/u;->a([B[BLjava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    .line 2
    invoke-direct {v1, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v1

    :catch_e6
    new-instance v1, Ljava/lang/IllegalArgumentException;

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/16 v3, 0x25

    new-array v3, v3, [B

    fill-array-data v3, :array_152

    new-array v0, v0, [B

    fill-array-data v0, :array_16a

    invoke-static {v3, v0}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {v1, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    goto :goto_10c

    :goto_10b
    throw v1

    :goto_10c
    goto :goto_10b

    nop

    :array_10e
    .array-data 1
        0x3ct
        0x1et
        0x4at
        0x7bt
        0x64t
        0x62t
        0x7et
        0x28t
    .end array-data

    :array_116
    .array-data 1
        -0xat
        0x3bt
        -0x63t
        -0x2bt
        -0x7t
        0x1t
        -0x39t
        0x3bt
    .end array-data

    :array_11e
    .array-data 1
        -0x5at
        -0x33t
        0x2ft
        -0x4et
        -0x60t
        0x8t
        0x47t
    .end array-data

    :array_126
    .array-data 1
        -0x3bt
        -0x5et
        0x41t
        -0x3at
        -0x3bt
        0x66t
        0x33t
        0x48t
    .end array-data

    :array_12e
    .array-data 1
        0x20t
        -0x34t
        0x34t
        0x7at
        0x6ct
        0x62t
        -0x6t
        -0x6at
        0x9t
        -0x73t
        0x3bt
        0x7ft
        0x67t
        0x62t
        -0x6t
        -0x7ft
        0x9t
        -0x3dt
        0x3bt
        0x7ft
        0x6et
        0x73t
        -0x58t
        -0x79t
        0x2t
        -0x73t
        0x2ft
        0x79t
        0x66t
        0x72t
        -0x6t
        -0x6at
        0xet
        -0x34t
        0x29t
        0x36t
        0x6at
        0x69t
        -0x4ct
        -0x6at
        0x7t
        -0x3ct
        0x33t
        0x65t
        0x29t
    .end array-data

    nop

    :array_14a
    .array-data 1
        0x66t
        -0x53t
        0x5dt
        0x16t
        0x9t
        0x6t
        -0x26t
        -0x1et
    .end array-data

    :array_152
    .array-data 1
        -0x6ct
        0x65t
        0x28t
        -0x15t
        0x37t
        0x7bt
        -0x63t
        0x43t
        -0x43t
        0x24t
        0x33t
        -0x1et
        0x21t
        0x70t
        -0x2ft
        0x41t
        -0x49t
        0x24t
        0x22t
        -0x1at
        0x3ct
        0x70t
        -0x2dt
        0x5et
        -0x4ft
        0x65t
        0x2dt
        -0x59t
        0x22t
        0x7et
        -0x37t
        0x5ft
        -0xet
        0x62t
        0x2et
        -0xbt
        0x72t
    .end array-data

    nop

    :array_16a
    .array-data 1
        -0x2et
        0x4t
        0x41t
        -0x79t
        0x52t
        0x1ft
        -0x43t
        0x37t
    .end array-data
.end method

.method final b(Ljava/lang/String;Ljava/io/File;)V
    .registers 7

    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    const/16 v1, 0x8

    if-nez v0, :cond_38

    :try_start_8
    invoke-virtual {p2}, Ljava/io/File;->getCanonicalFile()Ljava/io/File;

    move-result-object p2
    :try_end_c
    .catch Ljava/io/IOException; {:try_start_8 .. :try_end_c} :catch_12

    iget-object v0, p0, Lcom/github/catvod/spider/appysv2/p/c;->b:Ljava/util/HashMap;

    invoke-virtual {v0, p1, p2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    :catch_12
    move-exception p1

    new-instance v0, Ljava/lang/IllegalArgumentException;

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/16 v3, 0x25

    new-array v3, v3, [B

    fill-array-data v3, :array_4e

    new-array v1, v1, [B

    fill-array-data v1, :array_66

    invoke-static {v3, v1}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    invoke-direct {v0, p2, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    throw v0

    :cond_38
    new-instance p1, Ljava/lang/IllegalArgumentException;

    const/16 p2, 0x16

    new-array p2, p2, [B

    fill-array-data p2, :array_6e

    new-array v0, v1, [B

    fill-array-data v0, :array_7e

    invoke-static {p2, v0}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object p2

    invoke-direct {p1, p2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p1

    :array_4e
    .array-data 1
        0xdt
        -0x39t
        0x2t
        -0x4dt
        0xat
        -0x71t
        0x71t
        -0x70t
        0x24t
        -0x7at
        0x19t
        -0x46t
        0x1ct
        -0x7ct
        0x3dt
        -0x6et
        0x2et
        -0x7at
        0x8t
        -0x42t
        0x1t
        -0x7ct
        0x3ft
        -0x73t
        0x28t
        -0x39t
        0x7t
        -0x1t
        0x1ft
        -0x76t
        0x25t
        -0x74t
        0x6bt
        -0x40t
        0x4t
        -0x53t
        0x4ft
    .end array-data

    nop

    :array_66
    .array-data 1
        0x4bt
        -0x5at
        0x6bt
        -0x21t
        0x6ft
        -0x15t
        0x51t
        -0x1ct
    .end array-data

    :array_6e
    .array-data 1
        -0x59t
        -0x4et
        0x51t
        0xat
        -0x14t
        0x59t
        -0xdt
        -0x72t
        -0x63t
        -0xdt
        0x52t
        0x0t
        -0x48t
        0x14t
        -0x1ct
        -0x68t
        -0x37t
        -0x4at
        0x51t
        0x1ft
        -0x48t
        0x4dt
    .end array-data

    nop

    :array_7e
    .array-data 1
        -0x17t
        -0x2dt
        0x3ct
        0x6ft
        -0x34t
        0x34t
        -0x7at
        -0x3t
    .end array-data
.end method
