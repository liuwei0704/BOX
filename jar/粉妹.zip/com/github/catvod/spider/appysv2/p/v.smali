.class public final synthetic Lcom/github/catvod/spider/appysv2/p/v;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/content/DialogInterface$OnClickListener;


# instance fields
.field public final synthetic a:Lcom/github/catvod/spider/appysv2/p/B;

.field public final synthetic b:Ljava/util/Map;


# direct methods
.method public synthetic constructor <init>(Lcom/github/catvod/spider/appysv2/p/B;Ljava/util/Map;)V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/github/catvod/spider/appysv2/p/v;->a:Lcom/github/catvod/spider/appysv2/p/B;

    iput-object p2, p0, Lcom/github/catvod/spider/appysv2/p/v;->b:Ljava/util/Map;

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/content/DialogInterface;I)V
    .registers 8

    iget-object p1, p0, Lcom/github/catvod/spider/appysv2/p/v;->a:Lcom/github/catvod/spider/appysv2/p/B;

    iget-object p2, p0, Lcom/github/catvod/spider/appysv2/p/v;->b:Ljava/util/Map;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v0, 0x5

    new-array v0, v0, [B

    fill-array-data v0, :array_58

    const/16 v1, 0x8

    new-array v2, v1, [B

    fill-array-data v2, :array_60

    invoke-static {v0, v2}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x1

    new-array v2, v2, [B

    const/4 v3, 0x0

    const/16 v4, -0x68

    aput-byte v4, v2, v3

    new-array v3, v1, [B

    fill-array-data v3, :array_68

    invoke-static {v2, v3}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-interface {p2, v0, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v0, 0x4

    new-array v0, v0, [B

    fill-array-data v0, :array_70

    new-array v2, v1, [B

    fill-array-data v2, :array_76

    invoke-static {v0, v2}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v0

    const/16 v2, 0x3f

    new-array v2, v2, [B

    fill-array-data v2, :array_7e

    new-array v1, v1, [B

    fill-array-data v1, :array_a2

    invoke-static {v2, v1}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-interface {p2, v0, v1}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    new-instance v0, Lcom/github/catvod/spider/appysv2/b/k;

    const/4 v1, 0x2

    invoke-direct {v0, p1, p2, v1}, Lcom/github/catvod/spider/appysv2/b/k;-><init>(Ljava/lang/Object;Ljava/lang/Object;I)V

    invoke-static {v0}, Lcom/github/catvod/spider/Init;->execute(Ljava/lang/Runnable;)V

    return-void

    :array_58
    .array-data 1
        0xet
        0x67t
        0x41t
        0x18t
        0x3ct
    .end array-data

    nop

    :array_60
    .array-data 1
        0x63t
        0x8t
        0x25t
        0x7dt
        0x50t
        0x35t
        0x78t
        0x49t
    .end array-data

    :array_68
    .array-data 1
        -0x57t
        0x68t
        -0x59t
        0x49t
        0x18t
        0x1t
        0x6t
        0x72t
    .end array-data

    :array_70
    .array-data 1
        0x3bt
        0x2dt
        -0x29t
        -0x57t
    .end array-data

    :array_76
    .array-data 1
        0x5dt
        0x41t
        -0x4at
        -0x32t
        -0x4et
        0x3ft
        -0x3ft
        -0x6bt
    .end array-data

    :array_7e
    .array-data 1
        -0x28t
        -0x52t
        0x19t
        -0x56t
        0x1ft
        -0x3bt
        -0x62t
        0x5t
        -0x68t
        -0x1ct
        0x10t
        -0x20t
        0x46t
        -0x3bt
        -0x28t
        0x77t
        -0x48t
        -0x69t
        0x46t
        -0x32t
        0x27t
        -0x64t
        -0x34t
        0x1et
        -0x28t
        -0x5at
        0x26t
        -0x55t
        0x3bt
        -0x2et
        -0x61t
        0x18t
        -0x65t
        -0x1at
        0xet
        -0x31t
        0x46t
        -0x3et
        -0xet
        0x77t
        -0x5at
        -0x48t
        0x4at
        -0xct
        0x2et
        -0x63t
        -0x3et
        0x25t
        -0x29t
        -0x5ft
        0x2ft
        -0x5at
        0x1dt
        -0x1at
        -0x62t
        0x39t
        -0x45t
        -0x17t
        0x10t
        -0x23t
        0x47t
        -0x1t
        -0x24t
    .end array-data

    :array_a2
    .array-data 1
        0x30t
        0x1t
        -0x52t
        0x4et
        -0x5et
        0x7at
        0x79t
        -0x6ft
    .end array-data
.end method
