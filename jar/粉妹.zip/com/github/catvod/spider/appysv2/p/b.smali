.class interface abstract Lcom/github/catvod/spider/appysv2/p/b;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract a(Ljava/io/File;)Landroid/net/Uri;
.end method
