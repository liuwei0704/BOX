.class public final synthetic Lcom/github/catvod/spider/appysv2/p/r;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/content/DialogInterface$OnClickListener;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lcom/github/catvod/spider/appysv2/p/B;

.field public final synthetic c:Ljava/util/Map;


# direct methods
.method public synthetic constructor <init>(Lcom/github/catvod/spider/appysv2/p/B;Ljava/util/Map;I)V
    .registers 4

    iput p3, p0, Lcom/github/catvod/spider/appysv2/p/r;->a:I

    iput-object p1, p0, Lcom/github/catvod/spider/appysv2/p/r;->b:Lcom/github/catvod/spider/appysv2/p/B;

    iput-object p2, p0, Lcom/github/catvod/spider/appysv2/p/r;->c:Ljava/util/Map;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/content/DialogInterface;I)V
    .registers 8

    iget p1, p0, Lcom/github/catvod/spider/appysv2/p/r;->a:I

    packed-switch p1, :pswitch_data_66

    goto :goto_e

    :pswitch_6  #0x0
    iget-object p1, p0, Lcom/github/catvod/spider/appysv2/p/r;->b:Lcom/github/catvod/spider/appysv2/p/B;

    iget-object p2, p0, Lcom/github/catvod/spider/appysv2/p/r;->c:Ljava/util/Map;

    invoke-static {p1, p2}, Lcom/github/catvod/spider/appysv2/p/B;->b(Lcom/github/catvod/spider/appysv2/p/B;Ljava/util/Map;)V

    return-void

    :goto_e
    iget-object p1, p0, Lcom/github/catvod/spider/appysv2/p/r;->b:Lcom/github/catvod/spider/appysv2/p/B;

    iget-object p2, p0, Lcom/github/catvod/spider/appysv2/p/r;->c:Ljava/util/Map;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v0, 0x5

    new-array v0, v0, [B

    fill-array-data v0, :array_6c

    const/16 v1, 0x8

    new-array v2, v1, [B

    fill-array-data v2, :array_74

    invoke-static {v0, v2}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x1

    new-array v2, v2, [B

    const/4 v3, 0x0

    const/16 v4, 0x49

    aput-byte v4, v2, v3

    new-array v3, v1, [B

    fill-array-data v3, :array_7c

    invoke-static {v2, v3}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-interface {p2, v0, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v0, 0x4

    new-array v0, v0, [B

    fill-array-data v0, :array_84

    new-array v2, v1, [B

    fill-array-data v2, :array_8a

    invoke-static {v0, v2}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v0

    const/16 v2, 0x3f

    new-array v2, v2, [B

    fill-array-data v2, :array_92

    new-array v1, v1, [B

    fill-array-data v1, :array_b6

    invoke-static {v2, v1}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-interface {p2, v0, v1}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    new-instance v0, Lcom/github/catvod/spider/appysv2/b/K;

    const/4 v1, 0x3

    invoke-direct {v0, p1, p2, v1}, Lcom/github/catvod/spider/appysv2/b/K;-><init>(Ljava/lang/Object;Ljava/lang/Object;I)V

    invoke-static {v0}, Lcom/github/catvod/spider/Init;->execute(Ljava/lang/Runnable;)V

    return-void

    :pswitch_data_66
    .packed-switch 0x0
        :pswitch_6  #00000000
    .end packed-switch

    :array_6c
    .array-data 1
        -0x38t
        0xft
        -0x6et
        0x3ft
        -0x16t
    .end array-data

    nop

    :array_74
    .array-data 1
        -0x5bt
        0x60t
        -0xat
        0x5at
        -0x7at
        0x2t
        -0x36t
        -0x2at
    .end array-data

    :array_7c
    .array-data 1
        0x78t
        -0x53t
        -0x50t
        -0x70t
        -0x18t
        0x22t
        0x10t
        -0x29t
    .end array-data

    :array_84
    .array-data 1
        -0x31t
        -0x5t
        0x51t
        0x6et
    .end array-data

    :array_8a
    .array-data 1
        -0x57t
        -0x69t
        0x30t
        0x9t
        -0xct
        0x6bt
        0x35t
        -0x5ct
    .end array-data

    :array_92
    .array-data 1
        0x5ct
        0xat
        0x43t
        -0x49t
        0x6et
        -0x5et
        -0x46t
        0x3et
        0x1ct
        0x40t
        0x4at
        -0x3t
        0x37t
        -0x5et
        -0x4t
        0x4ct
        0x3ct
        0x33t
        0x1ct
        -0x2dt
        0x56t
        -0x5t
        -0x18t
        0x25t
        0x5ct
        0x2t
        0x7ct
        -0x4at
        0x4at
        -0x4bt
        -0x45t
        0x23t
        0x1ft
        0x42t
        0x54t
        -0x2et
        0x37t
        -0x5bt
        -0x2at
        0x4ct
        0x22t
        0x1ct
        0x10t
        -0x17t
        0x5ft
        -0x6t
        -0x1at
        0x1et
        0x53t
        0x5t
        0x75t
        -0x45t
        0x6ct
        -0x7ft
        -0x46t
        0x2t
        0x3ft
        0x4dt
        0x4at
        -0x40t
        0x36t
        -0x68t
        -0x8t
    .end array-data

    :array_b6
    .array-data 1
        -0x4ct
        -0x5bt
        -0xct
        0x53t
        -0x2dt
        0x1dt
        0x5dt
        -0x56t
    .end array-data
.end method
