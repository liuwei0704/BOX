.class public final Lcom/github/catvod/spider/appysv2/p/d;
.super Landroid/content/ContentProvider;
.source "SourceFile"


# static fields
.field private static final a:Ljava/lang/String;

.field private static final b:Ljava/lang/String;

.field private static final c:Ljava/lang/String;

.field private static final d:Ljava/lang/String;

.field private static final e:Ljava/lang/String;

.field private static final f:Ljava/util/HashMap;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/HashMap<",
            "Ljava/lang/String;",
            "Lcom/github/catvod/spider/appysv2/p/b;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .registers 5

    const/16 v0, 0x23

    new-array v0, v0, [B

    fill-array-data v0, :array_8c

    const/16 v1, 0x8

    new-array v2, v1, [B

    fill-array-data v2, :array_a2

    invoke-static {v0, v2}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lcom/github/catvod/spider/appysv2/p/d;->a:Ljava/lang/String;

    const/16 v0, 0xa

    new-array v0, v0, [B

    fill-array-data v0, :array_aa

    new-array v2, v1, [B

    fill-array-data v2, :array_b4

    invoke-static {v0, v2}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lcom/github/catvod/spider/appysv2/p/d;->b:Ljava/lang/String;

    const/16 v0, 0xd

    new-array v2, v0, [B

    fill-array-data v2, :array_bc

    new-array v3, v1, [B

    fill-array-data v3, :array_c8

    invoke-static {v2, v3}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v2

    sput-object v2, Lcom/github/catvod/spider/appysv2/p/d;->c:Ljava/lang/String;

    const/4 v2, 0x4

    new-array v3, v2, [B

    fill-array-data v3, :array_d0

    new-array v4, v1, [B

    fill-array-data v4, :array_d6

    invoke-static {v3, v4}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v3

    sput-object v3, Lcom/github/catvod/spider/appysv2/p/d;->d:Ljava/lang/String;

    new-array v2, v2, [B

    fill-array-data v2, :array_de

    new-array v3, v1, [B

    fill-array-data v3, :array_e4

    invoke-static {v2, v3}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v2

    sput-object v2, Lcom/github/catvod/spider/appysv2/p/d;->e:Ljava/lang/String;

    const/16 v2, 0xb

    new-array v2, v2, [B

    fill-array-data v2, :array_ec

    new-array v3, v1, [B

    fill-array-data v3, :array_f6

    invoke-static {v2, v3}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    new-array v0, v0, [B

    fill-array-data v0, :array_fe

    new-array v2, v1, [B

    fill-array-data v2, :array_10a

    invoke-static {v0, v2}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    const/4 v0, 0x5

    new-array v0, v0, [B

    fill-array-data v0, :array_112

    new-array v1, v1, [B

    fill-array-data v1, :array_11a

    invoke-static {v0, v1}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    new-instance v0, Ljava/util/HashMap;

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    sput-object v0, Lcom/github/catvod/spider/appysv2/p/d;->f:Ljava/util/HashMap;

    return-void

    nop

    :array_8c
    .array-data 1
        0x27t
        -0x34t
        0x12t
        0x64t
        0x15t
        0x2t
        -0x53t
        -0x6bt
        0x35t
        -0x29t
        0x6t
        0x66t
        0x15t
        0x19t
        -0x43t
        -0x6bt
        0x0t
        -0x15t
        0x3at
        0x53t
        0x25t
        0x3bt
        -0x65t
        -0xct
        0x10t
        -0x15t
        0x32t
        0x53t
        0x28t
        0x34t
        -0x67t
        -0x6t
        0x12t
        -0x16t
        0x25t
    .end array-data

    :array_a2
    .array-data 1
        0x46t
        -0x5et
        0x76t
        0x16t
        0x7at
        0x6bt
        -0x37t
        -0x45t
    .end array-data

    :array_aa
    .array-data 1
        0x71t
        0x3dt
        -0x5ft
        0x45t
        0x3ct
        0x33t
        0x31t
        -0x5dt
        0x66t
        0x34t
    .end array-data

    nop

    :array_b4
    .array-data 1
        0x12t
        0x5ct
        -0x3et
        0x2dt
        0x59t
        0x1et
        0x41t
        -0x3et
    .end array-data

    :array_bc
    .array-data 1
        -0x25t
        -0x5bt
        0x2ft
        0x26t
        0x3et
        -0x5dt
        0x63t
        -0x79t
        -0x6dt
        -0x53t
        0x3at
        0x37t
        0x24t
    .end array-data

    nop

    :array_c8
    .array-data 1
        -0x42t
        -0x23t
        0x5bt
        0x43t
        0x4ct
        -0x33t
        0x2t
        -0x15t
    .end array-data

    :array_d0
    .array-data 1
        -0x6at
        -0x4t
        0x4t
        -0x2at
    .end array-data

    :array_d6
    .array-data 1
        -0x8t
        -0x63t
        0x69t
        -0x4dt
        0x20t
        -0x3at
        0x4bt
        0x61t
    .end array-data

    :array_de
    .array-data 1
        0x24t
        0x48t
        0x66t
        -0xct
    .end array-data

    :array_e4
    .array-data 1
        0x54t
        0x29t
        0x12t
        -0x64t
        0x31t
        -0x7at
        0x41t
        -0x62t
    .end array-data

    :array_ec
    .array-data 1
        0x43t
        0x2at
        -0x41t
        0x21t
        -0x27t
        -0x31t
        -0x19t
        0x44t
        0x46t
        0x2et
        -0x57t
    .end array-data

    :array_f6
    .array-data 1
        0x27t
        0x43t
        -0x34t
        0x51t
        -0x4bt
        -0x52t
        -0x62t
        0xat
    .end array-data

    :array_fe
    .array-data 1
        0x6ft
        0x1at
        0x5at
        0x14t
        -0x43t
        -0x62t
        0x58t
        0x2ct
        0x6ft
        0x10t
        0x52t
        0xat
        -0x58t
    .end array-data

    nop

    :array_10a
    .array-data 1
        0x30t
        0x7et
        0x33t
        0x67t
        -0x33t
        -0xet
        0x39t
        0x55t
    .end array-data

    :array_112
    .array-data 1
        -0x3bt
        0x13t
        -0x6at
        -0x69t
        0x46t
    .end array-data

    nop

    :array_11a
    .array-data 1
        -0x66t
        0x60t
        -0x1t
        -0x13t
        0x23t
        0x70t
        0x25t
        0x1ft
    .end array-data
.end method

.method public static a(Landroid/content/Context;Ljava/lang/String;Ljava/io/File;)Landroid/net/Uri;
    .registers 61

    move-object/from16 v0, p1

    .line 1
    sget-object v1, Lcom/github/catvod/spider/appysv2/p/d;->f:Ljava/util/HashMap;

    monitor-enter v1

    :try_start_5
    invoke-virtual {v1, v0}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcom/github/catvod/spider/appysv2/p/b;
    :try_end_b
    .catchall {:try_start_5 .. :try_end_b} :catchall_28b

    if-nez v2, :cond_283

    const/16 v2, 0x1c

    const/16 v3, 0x12

    const/16 v4, 0x1a

    const/16 v5, 0xb

    const/16 v6, 0xe

    const/16 v7, 0x9

    const/16 v8, 0x8

    const/4 v9, 0x6

    const/4 v10, 0x5

    const/4 v11, 0x4

    const/4 v12, 0x3

    const/4 v13, 0x2

    const/4 v14, 0x1

    const/16 v16, 0x7

    const/16 v17, 0x3c

    const/16 v15, 0x3d

    const/16 v19, -0x4c

    const/16 v20, 0x0

    const/16 v21, 0x38

    const/16 v22, 0x35

    const/16 v23, 0x2f

    const/16 v24, 0x2e

    const/16 v25, 0x3a

    const/16 v26, 0x22

    const/16 v27, 0x1f

    const/16 v28, 0x1d

    const/16 v29, 0x1b

    const/16 v30, 0x24

    const/16 v31, 0x4c

    const/16 v32, 0x11

    const/16 v33, 0x31

    const/16 v34, 0x58

    const/16 v35, 0x18

    const/16 v36, 0x29

    const/16 v37, 0x26

    const/16 v38, 0x20

    const/16 v39, 0x17

    const/16 v40, 0x19

    const/16 v41, 0x16

    const/16 v42, 0x15

    const/16 v43, 0x14

    const/16 v44, 0x13

    const/16 v45, 0x10

    const/16 v46, 0xf

    const/16 v47, 0x3e

    const/16 v48, -0x78

    const/16 v49, 0xd

    const/16 v50, 0xc

    const/16 v51, 0xa

    const/16 v52, 0x32

    const/16 v53, 0x28

    const/16 v54, 0x2c

    :try_start_6f
    invoke-static/range {p0 .. p1}, Lcom/github/catvod/spider/appysv2/p/d;->b(Landroid/content/Context;Ljava/lang/String;)Lcom/github/catvod/spider/appysv2/p/b;

    move-result-object v2
    :try_end_73
    .catch Ljava/io/IOException; {:try_start_6f .. :try_end_73} :catch_17e
    .catch Lcom/github/catvod/spider/appysv2/f0/a; {:try_start_6f .. :try_end_73} :catch_78
    .catchall {:try_start_6f .. :try_end_73} :catchall_28b

    :try_start_73
    invoke-virtual {v1, v0, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    goto/16 :goto_283

    :catch_78
    move-exception v0

    move-object/from16 v55, v0

    new-instance v0, Ljava/lang/IllegalArgumentException;

    new-array v15, v15, [B

    aput-byte v19, v15, v20

    const/16 v56, 0x59

    aput-byte v56, v15, v14

    aput-byte v39, v15, v13

    const/16 v56, -0x1c

    aput-byte v56, v15, v12

    const/16 v56, 0x50

    aput-byte v56, v15, v11

    aput-byte v36, v15, v10

    aput-byte v17, v15, v9

    aput-byte v16, v15, v16

    const/16 v56, -0x63

    aput-byte v56, v15, v8

    aput-byte v35, v15, v7

    aput-byte v6, v15, v51

    const/16 v7, -0x17

    aput-byte v7, v15, v5

    const/16 v5, 0x47

    aput-byte v5, v15, v50

    aput-byte v47, v15, v49

    const/16 v5, 0x79

    aput-byte v5, v15, v6

    const/16 v5, 0x53

    aput-byte v5, v15, v46

    const/16 v5, -0x6d

    aput-byte v5, v15, v45

    const/16 v5, 0x56

    aput-byte v5, v15, v32

    aput-byte v4, v15, v3

    const/4 v5, -0x6

    aput-byte v5, v15, v44

    const/16 v5, 0x5a

    aput-byte v5, v15, v43

    aput-byte v30, v15, v42

    const/16 v7, 0x78

    aput-byte v7, v15, v41

    const/16 v7, 0x5d

    aput-byte v7, v15, v39

    const/16 v32, -0x7f

    aput-byte v32, v15, v35

    const/16 v32, 0x4d

    aput-byte v32, v15, v40

    aput-byte v6, v15, v4

    const/4 v4, -0x8

    aput-byte v4, v15, v29

    aput-byte v5, v15, v2

    const/16 v4, 0x3f

    aput-byte v4, v15, v28

    const/16 v4, 0x1e

    const/16 v5, 0x68

    aput-byte v5, v15, v4

    aput-byte v7, v15, v27

    aput-byte v19, v15, v38

    const/16 v4, 0x21

    const/16 v5, 0x71

    aput-byte v5, v15, v4

    aput-byte v52, v15, v26

    const/16 v4, 0x23

    const/16 v5, -0x33

    aput-byte v5, v15, v4

    const/16 v4, 0x6a

    aput-byte v4, v15, v30

    const/16 v4, 0x25

    aput-byte v28, v15, v4

    const/16 v4, 0x4e

    aput-byte v4, v15, v37

    const/16 v4, 0x27

    aput-byte v17, v15, v4

    const/16 v4, -0x5c

    aput-byte v4, v15, v53

    const/16 v4, 0x71

    aput-byte v4, v15, v36

    const/16 v4, 0x2a

    aput-byte v25, v15, v4

    const/16 v4, 0x2b

    const/16 v5, -0x33

    aput-byte v5, v15, v4

    const/16 v4, 0x67

    aput-byte v4, v15, v54

    const/16 v4, 0x2d

    aput-byte v3, v15, v4

    aput-byte v31, v15, v24

    aput-byte v52, v15, v23

    const/16 v4, 0x30

    const/16 v5, -0x5a

    aput-byte v5, v15, v4

    const/16 v4, 0x70

    aput-byte v4, v15, v33

    const/16 v4, 0x2d

    aput-byte v4, v15, v52

    const/16 v4, 0x33

    const/16 v5, -0x58

    aput-byte v5, v15, v4

    const/16 v4, 0x34

    aput-byte v34, v15, v4

    aput-byte v53, v15, v22

    const/16 v4, 0x36

    const/16 v5, 0x68

    aput-byte v5, v15, v4

    const/16 v4, 0x37

    aput-byte v3, v15, v4

    const/16 v3, -0x21

    aput-byte v3, v15, v21

    const/16 v3, 0x39

    const/16 v4, 0x5c

    aput-byte v4, v15, v3

    aput-byte v27, v15, v25

    const/16 v3, 0x3b

    const/4 v4, -0x4

    aput-byte v4, v15, v3

    const/16 v3, 0x54

    aput-byte v3, v15, v17

    new-array v3, v8, [B

    const/16 v4, -0xe

    aput-byte v4, v3, v20

    aput-byte v21, v3, v14

    const/16 v4, 0x7e

    aput-byte v4, v3, v13

    aput-byte v48, v3, v12

    aput-byte v22, v3, v11

    aput-byte v32, v3, v10

    aput-byte v2, v3, v9

    const/16 v2, 0x73

    aput-byte v2, v3, v16

    invoke-static {v15, v3}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v2

    move-object/from16 v3, v55

    invoke-direct {v0, v2, v3}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    throw v0

    :catch_17e
    move-exception v0

    move-object/from16 v57, v0

    new-instance v0, Ljava/lang/IllegalArgumentException;

    new-array v15, v15, [B

    const/16 v55, -0x9

    aput-byte v55, v15, v20

    const/16 v56, -0x2b

    aput-byte v56, v15, v14

    const/16 v56, 0x41

    aput-byte v56, v15, v13

    aput-byte v38, v15, v12

    aput-byte v37, v15, v11

    const/16 v56, -0x61

    aput-byte v56, v15, v10

    const/16 v56, 0x5f

    aput-byte v56, v15, v9

    const/16 v56, -0x6b

    aput-byte v56, v15, v16

    const/16 v56, -0x22

    aput-byte v56, v15, v8

    const/16 v56, -0x6c

    aput-byte v56, v15, v7

    aput-byte v34, v15, v51

    const/16 v18, 0x2d

    aput-byte v18, v15, v5

    aput-byte v33, v15, v50

    aput-byte v48, v15, v49

    aput-byte v4, v15, v6

    const/16 v6, -0x3f

    aput-byte v6, v15, v46

    const/16 v46, -0x30

    aput-byte v46, v15, v45

    const/16 v45, -0x26

    aput-byte v45, v15, v32

    aput-byte v31, v15, v3

    aput-byte v47, v15, v44

    aput-byte v54, v15, v43

    const/16 v3, -0x6e

    aput-byte v3, v15, v42

    aput-byte v29, v15, v41

    const/16 v3, -0x31

    aput-byte v3, v15, v39

    const/16 v39, -0x3e

    aput-byte v39, v15, v35

    aput-byte v6, v15, v40

    aput-byte v34, v15, v4

    aput-byte v17, v15, v29

    aput-byte v54, v15, v2

    const/16 v4, -0x77

    aput-byte v4, v15, v28

    const/16 v4, 0x1e

    aput-byte v5, v15, v4

    aput-byte v3, v15, v27

    aput-byte v55, v15, v38

    const/16 v3, 0x21

    const/4 v4, -0x3

    aput-byte v4, v15, v3

    const/16 v3, 0x64

    aput-byte v3, v15, v26

    const/16 v3, 0x23

    aput-byte v7, v15, v3

    aput-byte v2, v15, v30

    const/16 v2, 0x25

    const/16 v3, -0x55

    aput-byte v3, v15, v2

    const/16 v2, 0x2d

    aput-byte v2, v15, v37

    const/16 v2, 0x27

    const/16 v3, -0x52

    aput-byte v3, v15, v2

    const/16 v2, -0x19

    aput-byte v2, v15, v53

    const/4 v2, -0x3

    aput-byte v2, v15, v36

    const/16 v2, 0x2a

    const/16 v3, 0x6c

    aput-byte v3, v15, v2

    const/16 v2, 0x2b

    aput-byte v7, v15, v2

    aput-byte v32, v15, v54

    const/16 v2, -0x5c

    const/16 v3, 0x2d

    aput-byte v2, v15, v3

    aput-byte v23, v15, v24

    const/16 v2, -0x60

    aput-byte v2, v15, v23

    const/16 v2, 0x30

    const/16 v3, -0x1b

    aput-byte v3, v15, v2

    const/4 v2, -0x4

    aput-byte v2, v15, v33

    const/16 v2, 0x7b

    aput-byte v2, v15, v52

    const/16 v2, 0x33

    const/16 v3, 0x6c

    aput-byte v3, v15, v2

    const/16 v2, 0x34

    aput-byte v24, v15, v2

    const/16 v2, -0x62

    aput-byte v2, v15, v22

    const/16 v2, 0x36

    aput-byte v5, v15, v2

    const/16 v2, 0x37

    const/16 v3, -0x80

    aput-byte v3, v15, v2

    const/16 v2, -0x64

    aput-byte v2, v15, v21

    const/16 v2, 0x39

    aput-byte v46, v15, v2

    const/16 v2, 0x49

    aput-byte v2, v15, v25

    const/16 v2, 0x3b

    aput-byte v21, v15, v2

    aput-byte v26, v15, v17

    new-array v2, v8, [B

    const/16 v3, -0x4f

    aput-byte v3, v2, v20

    aput-byte v19, v2, v14

    aput-byte v53, v2, v13

    aput-byte v31, v2, v12

    const/16 v3, 0x43

    aput-byte v3, v2, v11

    const/4 v3, -0x5

    aput-byte v3, v2, v10

    const/16 v3, 0x7f

    aput-byte v3, v2, v9

    const/16 v3, -0x1f

    aput-byte v3, v2, v16

    invoke-static {v15, v2}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v2

    move-object/from16 v3, v57

    invoke-direct {v0, v2, v3}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    throw v0

    :cond_283
    :goto_283
    monitor-exit v1
    :try_end_284
    .catchall {:try_start_73 .. :try_end_284} :catchall_28b

    move-object/from16 v0, p2

    .line 2
    invoke-interface {v2, v0}, Lcom/github/catvod/spider/appysv2/p/b;->a(Ljava/io/File;)Landroid/net/Uri;

    move-result-object v0

    return-object v0

    :catchall_28b
    move-exception v0

    .line 3
    :try_start_28c
    monitor-exit v1
    :try_end_28d
    .catchall {:try_start_28c .. :try_end_28d} :catchall_28b

    throw v0
.end method

.method private static b(Landroid/content/Context;Ljava/lang/String;)Lcom/github/catvod/spider/appysv2/p/b;
    .registers 10

    new-instance v0, Lcom/github/catvod/spider/appysv2/p/c;

    invoke-direct {v0, p1}, Lcom/github/catvod/spider/appysv2/p/c;-><init>(Ljava/lang/String;)V

    invoke-virtual {p0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v1

    const/16 v2, 0x80

    invoke-virtual {v1, p1, v2}, Landroid/content/pm/PackageManager;->resolveContentProvider(Ljava/lang/String;I)Landroid/content/pm/ProviderInfo;

    move-result-object v1

    const/16 v2, 0x8

    if-eqz v1, :cond_86

    .line 1
    iget-object p1, v1, Landroid/content/pm/ProviderInfo;->metaData:Landroid/os/Bundle;

    invoke-virtual {p0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object p1

    sget-object v3, Lcom/github/catvod/spider/appysv2/p/d;->a:Ljava/lang/String;

    invoke-virtual {v1, p1, v3}, Landroid/content/pm/PackageItemInfo;->loadXmlMetaData(Landroid/content/pm/PackageManager;Ljava/lang/String;)Landroid/content/res/XmlResourceParser;

    move-result-object p1

    if-eqz p1, :cond_70

    .line 2
    :cond_21
    :goto_21
    invoke-interface {p1}, Lorg/xmlpull/v1/XmlPullParser;->next()I

    move-result v1

    const/4 v2, 0x1

    if-eq v1, v2, :cond_6f

    const/4 v3, 0x2

    if-ne v1, v3, :cond_21

    invoke-interface {p1}, Lorg/xmlpull/v1/XmlPullParser;->getName()Ljava/lang/String;

    move-result-object v1

    sget-object v3, Lcom/github/catvod/spider/appysv2/p/d;->d:Ljava/lang/String;

    const/4 v4, 0x0

    invoke-interface {p1, v4, v3}, Lorg/xmlpull/v1/XmlPullParser;->getAttributeValue(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    sget-object v5, Lcom/github/catvod/spider/appysv2/p/d;->e:Ljava/lang/String;

    invoke-interface {p1, v4, v5}, Lorg/xmlpull/v1/XmlPullParser;->getAttributeValue(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    sget-object v6, Lcom/github/catvod/spider/appysv2/p/d;->b:Ljava/lang/String;

    invoke-virtual {v6, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_49

    invoke-virtual {p0}, Landroid/content/Context;->getCacheDir()Ljava/io/File;

    move-result-object v4

    goto :goto_55

    :cond_49
    sget-object v6, Lcom/github/catvod/spider/appysv2/p/d;->c:Ljava/lang/String;

    invoke-virtual {v6, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_55

    invoke-static {}, Landroid/os/Environment;->getExternalStorageDirectory()Ljava/io/File;

    move-result-object v4

    :cond_55
    :goto_55
    if-eqz v4, :cond_21

    new-array v1, v2, [Ljava/lang/String;

    const/4 v6, 0x0

    aput-object v5, v1, v6

    :goto_5c
    if-ge v6, v2, :cond_6b

    .line 3
    aget-object v5, v1, v6

    if-eqz v5, :cond_68

    new-instance v7, Ljava/io/File;

    invoke-direct {v7, v4, v5}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    move-object v4, v7

    :cond_68
    add-int/lit8 v6, v6, 0x1

    goto :goto_5c

    .line 4
    :cond_6b
    invoke-virtual {v0, v3, v4}, Lcom/github/catvod/spider/appysv2/p/c;->b(Ljava/lang/String;Ljava/io/File;)V

    goto :goto_21

    :cond_6f
    return-object v0

    .line 5
    :cond_70
    new-instance p0, Ljava/lang/IllegalArgumentException;

    const/16 p1, 0x35

    new-array p1, p1, [B

    fill-array-data p1, :array_a4

    new-array v0, v2, [B

    fill-array-data v0, :array_c4

    invoke-static {p1, v0}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object p1

    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_86
    new-instance p0, Ljava/lang/IllegalArgumentException;

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/16 v1, 0x34

    new-array v1, v1, [B

    fill-array-data v1, :array_cc

    new-array v2, v2, [B

    fill-array-data v2, :array_ea

    .line 6
    invoke-static {v1, v2, v0, p1}, Lcom/github/catvod/spider/appysv2/b/u;->a([B[BLjava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    .line 7
    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    goto :goto_a2

    :goto_a1
    throw p0

    :goto_a2
    goto :goto_a1

    nop

    :array_a4
    .array-data 1
        0x0t
        -0x7ft
        -0x1dt
        -0x1bt
        0x26t
        -0x40t
        -0x50t
        -0x1bt
        0x2ct
        -0x7at
        -0xct
        -0x1ct
        0x20t
        -0x39t
        -0x4dt
        -0x15t
        0x3et
        -0x63t
        -0x20t
        -0x1at
        0x20t
        -0x24t
        -0x5dt
        -0x15t
        0xbt
        -0x5ft
        -0x24t
        -0x2dt
        0x10t
        -0x2t
        -0x7bt
        -0x76t
        0x1bt
        -0x5ft
        -0x2ct
        -0x2dt
        0x1dt
        -0xft
        -0x79t
        -0x7ct
        0x19t
        -0x60t
        -0x3dt
        -0x4at
        0x22t
        -0x35t
        -0x5dt
        -0x5ct
        0x60t
        -0x74t
        -0xft
        -0x1et
        0x2et
    .end array-data

    nop

    :array_c4
    .array-data 1
        0x4dt
        -0x18t
        -0x70t
        -0x6at
        0x4ft
        -0x52t
        -0x29t
        -0x3bt
    .end array-data

    :array_cc
    .array-data 1
        0x11t
        0x2ft
        -0x3et
        -0x26t
        -0x7t
        -0x11t
        0x72t
        -0x3bt
        0x72t
        0x26t
        -0x22t
        -0x28t
        -0x7t
        -0x5ft
        0x38t
        -0x2ct
        0x26t
        0x21t
        -0x66t
        -0x2et
        -0x4t
        -0xbt
        0x34t
        -0x6ft
        0x34t
        0x2ft
        -0x3bt
        -0x6at
        -0x13t
        -0xdt
        0x3at
        -0x39t
        0x3bt
        0x24t
        -0x2et
        -0x3ct
        -0x43t
        -0xat
        0x3ct
        -0x3bt
        0x3at
        0x60t
        -0x2at
        -0x3dt
        -0x17t
        -0x17t
        0x3at
        -0x3dt
        0x3bt
        0x34t
        -0x32t
        -0x6at
    .end array-data

    :array_ea
    .array-data 1
        0x52t
        0x40t
        -0x49t
        -0x4at
        -0x63t
        -0x7ft
        0x55t
        -0x4ft
    .end array-data
.end method
