.class public final synthetic Lcom/github/catvod/spider/appysv2/p/t;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/content/DialogInterface$OnClickListener;


# instance fields
.field public final synthetic a:Lcom/github/catvod/spider/appysv2/p/B;

.field public final synthetic b:Ljava/util/Map;


# direct methods
.method public synthetic constructor <init>(Lcom/github/catvod/spider/appysv2/p/B;Ljava/util/Map;)V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/github/catvod/spider/appysv2/p/t;->a:Lcom/github/catvod/spider/appysv2/p/B;

    iput-object p2, p0, Lcom/github/catvod/spider/appysv2/p/t;->b:Ljava/util/Map;

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/content/DialogInterface;I)V
    .registers 3

    iget-object p1, p0, Lcom/github/catvod/spider/appysv2/p/t;->a:Lcom/github/catvod/spider/appysv2/p/B;

    iget-object p2, p0, Lcom/github/catvod/spider/appysv2/p/t;->b:Ljava/util/Map;

    invoke-static {p1, p2}, Lcom/github/catvod/spider/appysv2/p/B;->f(Lcom/github/catvod/spider/appysv2/p/B;Ljava/util/Map;)V

    return-void
.end method
