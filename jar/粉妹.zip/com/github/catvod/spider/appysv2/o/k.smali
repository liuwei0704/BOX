.class public final synthetic Lcom/github/catvod/spider/appysv2/o/k;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:Lcom/github/catvod/spider/Duopan;

.field public final synthetic b:Ljava/lang/String;

.field public final synthetic c:Ljava/util/concurrent/atomic/AtomicReference;

.field public final synthetic d:Ljava/util/concurrent/CountDownLatch;


# direct methods
.method public synthetic constructor <init>(Lcom/github/catvod/spider/Duopan;Ljava/lang/String;Ljava/util/concurrent/atomic/AtomicReference;Ljava/util/concurrent/CountDownLatch;)V
    .registers 5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/github/catvod/spider/appysv2/o/k;->a:Lcom/github/catvod/spider/Duopan;

    iput-object p2, p0, Lcom/github/catvod/spider/appysv2/o/k;->b:Ljava/lang/String;

    iput-object p3, p0, Lcom/github/catvod/spider/appysv2/o/k;->c:Ljava/util/concurrent/atomic/AtomicReference;

    iput-object p4, p0, Lcom/github/catvod/spider/appysv2/o/k;->d:Ljava/util/concurrent/CountDownLatch;

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 5

    iget-object v0, p0, Lcom/github/catvod/spider/appysv2/o/k;->a:Lcom/github/catvod/spider/Duopan;

    iget-object v1, p0, Lcom/github/catvod/spider/appysv2/o/k;->b:Ljava/lang/String;

    iget-object v2, p0, Lcom/github/catvod/spider/appysv2/o/k;->c:Ljava/util/concurrent/atomic/AtomicReference;

    iget-object v3, p0, Lcom/github/catvod/spider/appysv2/o/k;->d:Ljava/util/concurrent/CountDownLatch;

    invoke-static {v0, v1, v2, v3}, Lcom/github/catvod/spider/Duopan;->d(Lcom/github/catvod/spider/Duopan;Ljava/lang/String;Ljava/util/concurrent/atomic/AtomicReference;Ljava/util/concurrent/CountDownLatch;)V

    return-void
.end method
