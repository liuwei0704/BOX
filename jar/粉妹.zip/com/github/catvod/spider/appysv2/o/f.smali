.class public final synthetic Lcom/github/catvod/spider/appysv2/o/f;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# static fields
.field public static final synthetic b:Lcom/github/catvod/spider/appysv2/o/f;

.field public static final synthetic c:Lcom/github/catvod/spider/appysv2/o/f;

.field public static final synthetic d:Lcom/github/catvod/spider/appysv2/o/f;


# instance fields
.field public final synthetic a:I


# direct methods
.method static synthetic constructor <clinit>()V
    .registers 2

    new-instance v0, Lcom/github/catvod/spider/appysv2/o/f;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, Lcom/github/catvod/spider/appysv2/o/f;-><init>(I)V

    sput-object v0, Lcom/github/catvod/spider/appysv2/o/f;->b:Lcom/github/catvod/spider/appysv2/o/f;

    new-instance v0, Lcom/github/catvod/spider/appysv2/o/f;

    const/4 v1, 0x1

    invoke-direct {v0, v1}, Lcom/github/catvod/spider/appysv2/o/f;-><init>(I)V

    sput-object v0, Lcom/github/catvod/spider/appysv2/o/f;->c:Lcom/github/catvod/spider/appysv2/o/f;

    new-instance v0, Lcom/github/catvod/spider/appysv2/o/f;

    const/4 v1, 0x2

    invoke-direct {v0, v1}, Lcom/github/catvod/spider/appysv2/o/f;-><init>(I)V

    sput-object v0, Lcom/github/catvod/spider/appysv2/o/f;->d:Lcom/github/catvod/spider/appysv2/o/f;

    return-void
.end method

.method public synthetic constructor <init>(I)V
    .registers 2

    iput p1, p0, Lcom/github/catvod/spider/appysv2/o/f;->a:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 3

    iget v0, p0, Lcom/github/catvod/spider/appysv2/o/f;->a:I

    packed-switch v0, :pswitch_data_1e

    goto :goto_19

    .line 1
    :pswitch_6  #0x1
    new-instance v0, Ljava/lang/Thread;

    sget-object v1, Lcom/github/catvod/spider/appysv2/o/h;->c:Lcom/github/catvod/spider/appysv2/o/h;

    invoke-direct {v0, v1}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;)V

    invoke-virtual {v0}, Ljava/lang/Thread;->start()V

    return-void

    .line 2
    :pswitch_11  #0x0
    invoke-static {}, Lcom/github/catvod/spider/appysv2/b/M;->p()Lcom/github/catvod/spider/appysv2/b/M;

    move-result-object v0

    invoke-virtual {v0}, Lcom/github/catvod/spider/appysv2/b/M;->k()V

    return-void

    .line 3
    :goto_19
    invoke-static {}, Lcom/github/catvod/spider/Init;->a()V

    return-void

    nop

    :pswitch_data_1e
    .packed-switch 0x0
        :pswitch_11  #00000000
        :pswitch_6  #00000001
    .end packed-switch
.end method
