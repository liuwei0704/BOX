.class public final synthetic Lcom/github/catvod/spider/appysv2/o/b;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# static fields
.field public static final synthetic b:Lcom/github/catvod/spider/appysv2/o/b;

.field public static final synthetic c:Lcom/github/catvod/spider/appysv2/o/b;


# instance fields
.field public final synthetic a:I


# direct methods
.method static synthetic constructor <clinit>()V
    .registers 2

    new-instance v0, Lcom/github/catvod/spider/appysv2/o/b;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, Lcom/github/catvod/spider/appysv2/o/b;-><init>(I)V

    sput-object v0, Lcom/github/catvod/spider/appysv2/o/b;->b:Lcom/github/catvod/spider/appysv2/o/b;

    new-instance v0, Lcom/github/catvod/spider/appysv2/o/b;

    const/4 v1, 0x1

    invoke-direct {v0, v1}, Lcom/github/catvod/spider/appysv2/o/b;-><init>(I)V

    sput-object v0, Lcom/github/catvod/spider/appysv2/o/b;->c:Lcom/github/catvod/spider/appysv2/o/b;

    return-void
.end method

.method public synthetic constructor <init>(I)V
    .registers 2

    iput p1, p0, Lcom/github/catvod/spider/appysv2/o/b;->a:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 2

    iget v0, p0, Lcom/github/catvod/spider/appysv2/o/b;->a:I

    packed-switch v0, :pswitch_data_20

    goto :goto_c

    .line 1
    :pswitch_6  #0x0
    sget-object v0, Lcom/github/catvod/spider/appysv2/o/g;->c:Lcom/github/catvod/spider/appysv2/o/g;

    invoke-static {v0}, Lcom/github/catvod/spider/Init;->run(Ljava/lang/Runnable;)V

    return-void

    .line 2
    :goto_c
    :try_start_c
    invoke-static {}, Lcom/github/catvod/spider/appysv2/b/U;->t()Lcom/github/catvod/spider/appysv2/b/U;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 3
    invoke-static {}, Lcom/github/catvod/spider/Init;->checkPermission()V

    invoke-virtual {v0}, Lcom/github/catvod/spider/appysv2/b/U;->o()V
    :try_end_19
    .catch Ljava/lang/Exception; {:try_start_c .. :try_end_19} :catch_1a

    goto :goto_1e

    :catch_1a
    move-exception v0

    .line 4
    invoke-virtual {v0}, Ljava/lang/Throwable;->printStackTrace()V

    :goto_1e
    return-void

    nop

    :pswitch_data_20
    .packed-switch 0x0
        :pswitch_6  #00000000
    .end packed-switch
.end method
