.class public final synthetic Lcom/github/catvod/spider/appysv2/o/c;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# static fields
.field public static final synthetic b:Lcom/github/catvod/spider/appysv2/o/c;

.field public static final synthetic c:Lcom/github/catvod/spider/appysv2/o/c;


# instance fields
.field public final synthetic a:I


# direct methods
.method static synthetic constructor <clinit>()V
    .registers 2

    new-instance v0, Lcom/github/catvod/spider/appysv2/o/c;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, Lcom/github/catvod/spider/appysv2/o/c;-><init>(I)V

    sput-object v0, Lcom/github/catvod/spider/appysv2/o/c;->b:Lcom/github/catvod/spider/appysv2/o/c;

    new-instance v0, Lcom/github/catvod/spider/appysv2/o/c;

    const/4 v1, 0x1

    invoke-direct {v0, v1}, Lcom/github/catvod/spider/appysv2/o/c;-><init>(I)V

    sput-object v0, Lcom/github/catvod/spider/appysv2/o/c;->c:Lcom/github/catvod/spider/appysv2/o/c;

    return-void
.end method

.method public synthetic constructor <init>(I)V
    .registers 2

    iput p1, p0, Lcom/github/catvod/spider/appysv2/o/c;->a:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 2

    iget v0, p0, Lcom/github/catvod/spider/appysv2/o/c;->a:I

    packed-switch v0, :pswitch_data_1c

    goto :goto_e

    .line 1
    :pswitch_6  #0x0
    invoke-static {}, Lcom/github/catvod/spider/appysv2/b/U;->t()Lcom/github/catvod/spider/appysv2/b/U;

    move-result-object v0

    invoke-virtual {v0}, Lcom/github/catvod/spider/appysv2/b/U;->p()V

    return-void

    .line 2
    :goto_e
    :try_start_e
    invoke-static {}, Lcom/github/catvod/spider/appysv2/b/x;->p()Lcom/github/catvod/spider/appysv2/b/x;

    move-result-object v0

    invoke-virtual {v0}, Lcom/github/catvod/spider/appysv2/b/x;->K()V
    :try_end_15
    .catch Ljava/lang/Exception; {:try_start_e .. :try_end_15} :catch_16

    goto :goto_1a

    :catch_16
    move-exception v0

    invoke-virtual {v0}, Ljava/lang/Throwable;->printStackTrace()V

    :goto_1a
    return-void

    nop

    :pswitch_data_1c
    .packed-switch 0x0
        :pswitch_6  #00000000
    .end packed-switch
.end method
