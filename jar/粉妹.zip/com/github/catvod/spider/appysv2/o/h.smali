.class public final synthetic Lcom/github/catvod/spider/appysv2/o/h;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# static fields
.field public static final synthetic b:Lcom/github/catvod/spider/appysv2/o/h;

.field public static final synthetic c:Lcom/github/catvod/spider/appysv2/o/h;

.field public static final synthetic d:Lcom/github/catvod/spider/appysv2/o/h;


# instance fields
.field public final synthetic a:I


# direct methods
.method static synthetic constructor <clinit>()V
    .registers 2

    new-instance v0, Lcom/github/catvod/spider/appysv2/o/h;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, Lcom/github/catvod/spider/appysv2/o/h;-><init>(I)V

    sput-object v0, Lcom/github/catvod/spider/appysv2/o/h;->b:Lcom/github/catvod/spider/appysv2/o/h;

    new-instance v0, Lcom/github/catvod/spider/appysv2/o/h;

    const/4 v1, 0x1

    invoke-direct {v0, v1}, Lcom/github/catvod/spider/appysv2/o/h;-><init>(I)V

    sput-object v0, Lcom/github/catvod/spider/appysv2/o/h;->c:Lcom/github/catvod/spider/appysv2/o/h;

    new-instance v0, Lcom/github/catvod/spider/appysv2/o/h;

    const/4 v1, 0x2

    invoke-direct {v0, v1}, Lcom/github/catvod/spider/appysv2/o/h;-><init>(I)V

    sput-object v0, Lcom/github/catvod/spider/appysv2/o/h;->d:Lcom/github/catvod/spider/appysv2/o/h;

    return-void
.end method

.method public synthetic constructor <init>(I)V
    .registers 2

    iput p1, p0, Lcom/github/catvod/spider/appysv2/o/h;->a:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 3

    iget v0, p0, Lcom/github/catvod/spider/appysv2/o/h;->a:I

    packed-switch v0, :pswitch_data_42

    goto :goto_2f

    .line 1
    :pswitch_6  #0x1
    :try_start_6
    invoke-static {}, Lcom/github/catvod/spider/Bili;->get()Lcom/github/catvod/spider/Bili;

    move-result-object v0

    invoke-virtual {v0}, Lcom/github/catvod/spider/Bili;->getQRCode()V
    :try_end_d
    .catch Ljava/lang/Exception; {:try_start_6 .. :try_end_d} :catch_e

    goto :goto_12

    :catch_e
    move-exception v0

    invoke-virtual {v0}, Ljava/lang/Throwable;->printStackTrace()V

    :goto_12
    return-void

    .line 2
    :pswitch_13  #0x0
    invoke-static {}, Lcom/github/catvod/spider/appysv2/b/A;->e()Lcom/github/catvod/spider/appysv2/b/A;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v0, 0x6

    new-array v0, v0, [B

    .line 3
    fill-array-data v0, :array_4a

    const/16 v1, 0x8

    new-array v1, v1, [B

    fill-array-data v1, :array_52

    invoke-static {v0, v1}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lcom/github/catvod/spider/appysv2/p/C;->c(Ljava/lang/String;)V

    return-void

    .line 4
    :goto_2f
    :try_start_2f
    invoke-static {}, Lcom/github/catvod/spider/appysv2/b/M;->p()Lcom/github/catvod/spider/appysv2/b/M;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 5
    invoke-static {}, Lcom/github/catvod/spider/Init;->checkPermission()V

    invoke-virtual {v0}, Lcom/github/catvod/spider/appysv2/b/M;->j()V
    :try_end_3c
    .catch Ljava/lang/Exception; {:try_start_2f .. :try_end_3c} :catch_3d

    goto :goto_41

    :catch_3d
    move-exception v0

    .line 6
    invoke-virtual {v0}, Ljava/lang/Throwable;->printStackTrace()V

    :goto_41
    return-void

    :pswitch_data_42
    .packed-switch 0x0
        :pswitch_13  #00000000
        :pswitch_6  #00000001
    .end packed-switch

    :array_4a
    .array-data 1
        0x4bt
        -0x34t
        0x68t
        0x1ft
        -0x3dt
        -0x7at
    .end array-data

    nop

    :array_52
    .array-data 1
        0x65t
        -0x52t
        0x9t
        0x76t
        -0x59t
        -0xdt
        -0x7dt
        -0x43t
    .end array-data
.end method
