.class public final synthetic Lcom/github/catvod/spider/appysv2/o/i;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# static fields
.field public static final synthetic b:Lcom/github/catvod/spider/appysv2/o/i;

.field public static final synthetic c:Lcom/github/catvod/spider/appysv2/o/i;

.field public static final synthetic d:Lcom/github/catvod/spider/appysv2/o/i;


# instance fields
.field public final synthetic a:I


# direct methods
.method static synthetic constructor <clinit>()V
    .registers 2

    new-instance v0, Lcom/github/catvod/spider/appysv2/o/i;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, Lcom/github/catvod/spider/appysv2/o/i;-><init>(I)V

    sput-object v0, Lcom/github/catvod/spider/appysv2/o/i;->b:Lcom/github/catvod/spider/appysv2/o/i;

    new-instance v0, Lcom/github/catvod/spider/appysv2/o/i;

    const/4 v1, 0x1

    invoke-direct {v0, v1}, Lcom/github/catvod/spider/appysv2/o/i;-><init>(I)V

    sput-object v0, Lcom/github/catvod/spider/appysv2/o/i;->c:Lcom/github/catvod/spider/appysv2/o/i;

    new-instance v0, Lcom/github/catvod/spider/appysv2/o/i;

    const/4 v1, 0x2

    invoke-direct {v0, v1}, Lcom/github/catvod/spider/appysv2/o/i;-><init>(I)V

    sput-object v0, Lcom/github/catvod/spider/appysv2/o/i;->d:Lcom/github/catvod/spider/appysv2/o/i;

    return-void
.end method

.method public synthetic constructor <init>(I)V
    .registers 2

    iput p1, p0, Lcom/github/catvod/spider/appysv2/o/i;->a:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 3

    iget v0, p0, Lcom/github/catvod/spider/appysv2/o/i;->a:I

    packed-switch v0, :pswitch_data_38

    goto :goto_2b

    .line 1
    :pswitch_6  #0x1
    new-instance v0, Ljava/lang/Thread;

    sget-object v1, Lcom/github/catvod/spider/appysv2/o/e;->c:Lcom/github/catvod/spider/appysv2/o/e;

    invoke-direct {v0, v1}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;)V

    invoke-virtual {v0}, Ljava/lang/Thread;->start()V

    return-void

    :pswitch_11  #0x0
    const/16 v0, 0x8

    new-array v1, v0, [B

    .line 2
    fill-array-data v1, :array_40

    new-array v0, v0, [B

    fill-array-data v0, :array_48

    invoke-static {v1, v0}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lcom/github/catvod/spider/appysv2/p/a;->n(Ljava/lang/String;)Ljava/io/File;

    move-result-object v0

    const-string v1, ""

    invoke-static {v0, v1}, Lcom/github/catvod/spider/appysv2/p/a;->o(Ljava/io/File;Ljava/lang/String;)Ljava/io/File;

    return-void

    .line 3
    :goto_2b
    :try_start_2b
    invoke-static {}, Lcom/github/catvod/spider/appysv2/b/U;->t()Lcom/github/catvod/spider/appysv2/b/U;

    move-result-object v0

    invoke-virtual {v0}, Lcom/github/catvod/spider/appysv2/b/U;->D()V
    :try_end_32
    .catch Ljava/lang/Exception; {:try_start_2b .. :try_end_32} :catch_33

    goto :goto_37

    :catch_33
    move-exception v0

    invoke-virtual {v0}, Ljava/lang/Throwable;->printStackTrace()V

    :goto_37
    return-void

    :pswitch_data_38
    .packed-switch 0x0
        :pswitch_11  #00000000
        :pswitch_6  #00000001
    .end packed-switch

    :array_40
    .array-data 1
        0xbt
        0x6dt
        0x25t
        -0x45t
        0x75t
        -0x56t
        0x54t
        0x3dt
    .end array-data

    :array_48
    .array-data 1
        0x24t
        0x43t
        0x44t
        -0x29t
        0x1ct
        -0x2dt
        0x21t
        0x53t
    .end array-data
.end method
