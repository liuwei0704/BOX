.class public final synthetic Lcom/github/catvod/spider/appysv2/o/g;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# static fields
.field public static final synthetic b:Lcom/github/catvod/spider/appysv2/o/g;

.field public static final synthetic c:Lcom/github/catvod/spider/appysv2/o/g;

.field public static final synthetic d:Lcom/github/catvod/spider/appysv2/o/g;


# instance fields
.field public final synthetic a:I


# direct methods
.method static synthetic constructor <clinit>()V
    .registers 2

    new-instance v0, Lcom/github/catvod/spider/appysv2/o/g;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, Lcom/github/catvod/spider/appysv2/o/g;-><init>(I)V

    sput-object v0, Lcom/github/catvod/spider/appysv2/o/g;->b:Lcom/github/catvod/spider/appysv2/o/g;

    new-instance v0, Lcom/github/catvod/spider/appysv2/o/g;

    const/4 v1, 0x1

    invoke-direct {v0, v1}, Lcom/github/catvod/spider/appysv2/o/g;-><init>(I)V

    sput-object v0, Lcom/github/catvod/spider/appysv2/o/g;->c:Lcom/github/catvod/spider/appysv2/o/g;

    new-instance v0, Lcom/github/catvod/spider/appysv2/o/g;

    const/4 v1, 0x2

    invoke-direct {v0, v1}, Lcom/github/catvod/spider/appysv2/o/g;-><init>(I)V

    sput-object v0, Lcom/github/catvod/spider/appysv2/o/g;->d:Lcom/github/catvod/spider/appysv2/o/g;

    return-void
.end method

.method public synthetic constructor <init>(I)V
    .registers 2

    iput p1, p0, Lcom/github/catvod/spider/appysv2/o/g;->a:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 3

    iget v0, p0, Lcom/github/catvod/spider/appysv2/o/g;->a:I

    packed-switch v0, :pswitch_data_1c

    goto :goto_17

    .line 1
    :pswitch_6  #0x1
    new-instance v0, Ljava/lang/Thread;

    sget-object v1, Lcom/github/catvod/spider/appysv2/o/h;->d:Lcom/github/catvod/spider/appysv2/o/h;

    invoke-direct {v0, v1}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;)V

    invoke-virtual {v0}, Ljava/lang/Thread;->start()V

    return-void

    .line 2
    :pswitch_11  #0x0
    sget-object v0, Lcom/github/catvod/spider/appysv2/o/d;->c:Lcom/github/catvod/spider/appysv2/o/d;

    invoke-static {v0}, Lcom/github/catvod/spider/Init;->run(Ljava/lang/Runnable;)V

    return-void

    .line 3
    :goto_17
    invoke-static {}, Lcom/github/catvod/spider/Init;->b()V

    return-void

    nop

    :pswitch_data_1c
    .packed-switch 0x0
        :pswitch_11  #00000000
        :pswitch_6  #00000001
    .end packed-switch
.end method
