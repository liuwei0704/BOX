.class public final synthetic Lcom/github/catvod/spider/appysv2/o/j;
.super Ljava/lang/Object;
.source "SourceFile"


# direct methods
.method public static a([B[BLcom/github/catvod/spider/appysv2/L/h;)Ljava/lang/String;
    .registers 3

    .line 1
    invoke-static {p0, p1}, Lcom/github/catvod/spider/appysv2/a/a;->a([B[B)Ljava/lang/String;

    move-result-object p0

    .line 2
    invoke-virtual {p2, p0}, Lcom/github/catvod/spider/appysv2/L/m;->o0(Ljava/lang/String;)Lcom/github/catvod/spider/appysv2/N/g;

    move-result-object p0

    .line 3
    invoke-virtual {p0}, Lcom/github/catvod/spider/appysv2/N/g;->h()Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method
