.class public final synthetic Lcom/github/catvod/spider/appysv2/o/d;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# static fields
.field public static final synthetic b:Lcom/github/catvod/spider/appysv2/o/d;

.field public static final synthetic c:Lcom/github/catvod/spider/appysv2/o/d;


# instance fields
.field public final synthetic a:I


# direct methods
.method static synthetic constructor <clinit>()V
    .registers 2

    new-instance v0, Lcom/github/catvod/spider/appysv2/o/d;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, Lcom/github/catvod/spider/appysv2/o/d;-><init>(I)V

    sput-object v0, Lcom/github/catvod/spider/appysv2/o/d;->b:Lcom/github/catvod/spider/appysv2/o/d;

    new-instance v0, Lcom/github/catvod/spider/appysv2/o/d;

    const/4 v1, 0x1

    invoke-direct {v0, v1}, Lcom/github/catvod/spider/appysv2/o/d;-><init>(I)V

    sput-object v0, Lcom/github/catvod/spider/appysv2/o/d;->c:Lcom/github/catvod/spider/appysv2/o/d;

    return-void
.end method

.method public synthetic constructor <init>(I)V
    .registers 2

    iput p1, p0, Lcom/github/catvod/spider/appysv2/o/d;->a:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 3

    iget v0, p0, Lcom/github/catvod/spider/appysv2/o/d;->a:I

    packed-switch v0, :pswitch_data_1c

    goto :goto_11

    .line 1
    :pswitch_6  #0x0
    new-instance v0, Ljava/lang/Thread;

    sget-object v1, Lcom/github/catvod/spider/appysv2/o/i;->d:Lcom/github/catvod/spider/appysv2/o/i;

    invoke-direct {v0, v1}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;)V

    invoke-virtual {v0}, Ljava/lang/Thread;->start()V

    return-void

    .line 2
    :goto_11
    new-instance v0, Ljava/lang/Thread;

    sget-object v1, Lcom/github/catvod/spider/appysv2/o/c;->c:Lcom/github/catvod/spider/appysv2/o/c;

    invoke-direct {v0, v1}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;)V

    invoke-virtual {v0}, Ljava/lang/Thread;->start()V

    return-void

    :pswitch_data_1c
    .packed-switch 0x0
        :pswitch_6  #00000000
    .end packed-switch
.end method
