.class public Lcom/github/catvod/spider/XYQHiker;
.super Lcom/github/catvod/crawler/Spider;
.source "SourceFile"


# static fields
.field private static Ϳ:Landroid/content/SharedPreferences;

.field private static Ԩ:Z

.field public static ԩ:Ljava/util/regex/Pattern;

.field public static Ԫ:Ljava/lang/String;

.field public static ԫ:Ljava/lang/String;

.field public static Ԭ:Ljava/lang/String;

.field public static ԭ:Ljava/lang/String;

.field private static Ԯ:[Ljava/lang/String;

.field private static ԯ:[Ljava/lang/String;


# instance fields
.field public ֏:Lcom/github/catvod/spider/XYQPushAgent;

.field private ؠ:Ljava/lang/String;

.field private ހ:Ljava/lang/String;

.field private ށ:Ljava/lang/String;

.field private ނ:Ljava/lang/String;

.field private ރ:Lorg/json/JSONObject;

.field private ބ:Ljava/lang/String;

.field protected ޅ:Ljava/lang/String;

.field protected ކ:Lorg/json/JSONObject;

.field protected އ:Ljava/lang/String;

.field protected ވ:Z


# direct methods
.method static constructor <clinit>()V
    .registers 7

    const-string v0, "5A2A27252A37486D7C262D335C6A323D3334132C2F30362D0B373D35282D04277A7F392B1F6D207E011A501F7878"

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 1
    invoke-static {v0}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    move-result-object v0

    sput-object v0, Lcom/github/catvod/spider/XYQHiker;->ԩ:Ljava/util/regex/Pattern;

    const-string v0, "3F2D29383628136D667F6A645A153A3F3E2B0531731F0E6443727D616164252B3D676E7F523A656573643332233D3F13172018382E6B4771647F6972526A18190E093E6E733D332F17621434392F1D6B731232361D2F367E6B75426C637F6A6A426200303C25002B7C6469735C7165711F20156D62606A6A426C626462735C7764"

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 2
    sput-object v0, Lcom/github/catvod/spider/XYQHiker;->Ԫ:Ljava/lang/String;

    const-string v0, "3F2D29383628136D667F6A645A0E3A3F2F3C4962123F3E361D2B37716B7749620B383B2B1F2B7360696422303C787A0502323F340D2110093A25757141757D626C645A091B0517085E623F38312152053632312B5B621039282B1F277C606B775C727D646C73406C62626B643F2D31383621521132373B361B6D66626D6A4174"

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 3
    sput-object v0, Lcom/github/catvod/spider/XYQHiker;->ԫ:Ljava/lang/String;

    const-string v0, "3F2D29383628136D667F6A645A2B0339352A177973120A11522B0339352A17621C027A75441D6371362D1927731C3B27520D0071026D5203232136212527311A33305D74636474755C736671720F3A161E1D76641E2B38347A031721383E736424272122332B1C6D62677474520F3C333328176D62641F75467A73023B2213303A7E6C74466C62"

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 4
    sput-object v0, Lcom/github/catvod/spider/XYQHiker;->Ԭ:Ljava/lang/String;

    const-string v0, "3F2D29383628136D667F6A645A0F3232332A062D203961643B2C273436643F2330711517521A73636A1B4672687128324873636174745B6212212A2817153633112D066D66626D6A45777D606E645A091B0517085E623F38312152053632312B5B62053428371B2D3D7E6B715C727D617A1713243223336B43776361"

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 5
    sput-object v0, Lcom/github/catvod/spider/XYQHiker;->ԭ:Ljava/lang/String;

    const/4 v0, 0x4

    new-array v1, v0, [Ljava/lang/String;

    const-string v2, "13283229753217303A37231B112A363231"

    invoke-static {v2}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    const/4 v3, 0x0

    aput-object v2, v1, v3

    const-string v2, "1328322974341A326C303979112D373405271A27303A"

    invoke-static {v2}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    const/4 v4, 0x1

    aput-object v2, v1, v4

    const-string v2, "5D34362333220B6D3A3F3E210A6C3B253728"

    invoke-static {v2}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    const/4 v5, 0x2

    aput-object v2, v1, v5

    const-string v2, "4D3130393F271903106C392C172138"

    invoke-static {v2}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    const/4 v6, 0x3

    aput-object v2, v1, v6

    .line 6
    sput-object v1, Lcom/github/catvod/spider/XYQHiker;->Ԯ:[Ljava/lang/String;

    const/4 v1, 0x5

    new-array v1, v1, [Ljava/lang/String;

    const-string v2, "1A303637"

    invoke-static {v2}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    aput-object v2, v1, v3

    const-string v2, "013030"

    invoke-static {v2}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    aput-object v2, v1, v4

    const-string v2, "112E322229"

    invoke-static {v2}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    aput-object v2, v1, v5

    const-string v2, "062B273D3F"

    invoke-static {v2}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    aput-object v2, v1, v6

    const-string v2, "132E27"

    invoke-static {v2}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    aput-object v2, v1, v0

    .line 7
    sput-object v1, Lcom/github/catvod/spider/XYQHiker;->ԯ:[Ljava/lang/String;

    return-void
.end method

.method public constructor <init>()V
    .registers 2

    .line 1
    invoke-direct {p0}, Lcom/github/catvod/crawler/Spider;-><init>()V

    const-string v0, ""

    .line 2
    iput-object v0, p0, Lcom/github/catvod/spider/XYQHiker;->ؠ:Ljava/lang/String;

    .line 3
    iput-object v0, p0, Lcom/github/catvod/spider/XYQHiker;->ހ:Ljava/lang/String;

    .line 4
    iput-object v0, p0, Lcom/github/catvod/spider/XYQHiker;->ށ:Ljava/lang/String;

    .line 5
    iput-object v0, p0, Lcom/github/catvod/spider/XYQHiker;->ނ:Ljava/lang/String;

    .line 6
    new-instance v0, Lorg/json/JSONObject;

    invoke-direct {v0}, Lorg/json/JSONObject;-><init>()V

    iput-object v0, p0, Lcom/github/catvod/spider/XYQHiker;->ރ:Lorg/json/JSONObject;

    const-string v0, "291E042D06170E6C0E7B65091321033D3B3D1730103E34221B257D2136250B27210E362D0136080D0D382E112F7F076E4D7F7B0A06130E1E002D7419587D7A7D172511123F30232100013C3F3C2D156C373E2D2A17300C3D333706"

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 7
    iput-object v0, p0, Lcom/github/catvod/spider/XYQHiker;->ބ:Ljava/lang/String;

    const/4 v0, 0x0

    .line 8
    iput-object v0, p0, Lcom/github/catvod/spider/XYQHiker;->ޅ:Ljava/lang/String;

    .line 9
    iput-object v0, p0, Lcom/github/catvod/spider/XYQHiker;->ކ:Lorg/json/JSONObject;

    .line 10
    iput-object v0, p0, Lcom/github/catvod/spider/XYQHiker;->އ:Ljava/lang/String;

    return-void
.end method

.method public static checkstring(Ljava/lang/String;)Z
    .registers 7

    const/4 v0, 0x3

    new-array v1, v0, [Ljava/lang/String;

    const-string v2, "1F7126697434056D1030392C17"

    invoke-static {v2}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    const/4 v3, 0x0

    aput-object v2, v1, v3

    const-string v2, "14303C3C672C06362322606B5D20323F23311C257D212D"

    invoke-static {v2}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    const/4 v4, 0x1

    aput-object v2, v1, v4

    const/4 v2, 0x2

    const-string v5, "1527273C69314A7D262336791A362721"

    invoke-static {v5}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    aput-object v5, v1, v2

    const/4 v2, 0x0

    :goto_1f
    if-ge v2, v0, :cond_2d

    .line 1
    aget-object v5, v1, v2

    .line 2
    invoke-virtual {p0, v5}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v5

    if-eqz v5, :cond_2a

    return v4

    :cond_2a
    add-int/lit8 v2, v2, 0x1

    goto :goto_1f

    :cond_2d
    return v3
.end method

.method public static checkveriry(Ljava/lang/String;)Z
    .registers 6

    .line 1
    sget-object v0, Lcom/github/catvod/spider/XYQHiker;->Ԯ:[Ljava/lang/String;

    array-length v1, v0

    const/4 v2, 0x0

    const/4 v3, 0x0

    :goto_5
    if-ge v3, v1, :cond_14

    aget-object v4, v0, v3

    .line 2
    invoke-virtual {p0, v4}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v4

    if-eqz v4, :cond_11

    const/4 p0, 0x1

    return p0

    :cond_11
    add-int/lit8 v3, v3, 0x1

    goto :goto_5

    :cond_14
    return v2
.end method

.method public static getText(Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;Ljava/lang/String;)Ljava/lang/String;
    .registers 6

    const-string v0, "58"

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 1
    invoke-virtual {v0, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_13

    const-string p0, "1C373F3D"

    invoke-static {p0}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    return-object p0

    :cond_13
    const-string v0, "2E3E0F2D"

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 2
    invoke-virtual {p1, v0}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v0

    .line 3
    array-length v1, v0

    const/4 v2, 0x1

    if-le v1, v2, :cond_3b

    const/4 v1, 0x0

    .line 4
    :goto_22
    array-length v2, v0

    if-ge v1, v2, :cond_3b

    const/4 v2, 0x0

    .line 5
    :try_start_26
    aget-object v3, v0, v1

    invoke-static {p0, v3}, Lcom/github/catvod/spider/XYQHiker;->ޅ(Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2
    :try_end_2c
    .catch Ljava/lang/Exception; {:try_start_26 .. :try_end_2c} :catch_2d

    goto :goto_31

    :catch_2d
    move-exception v3

    .line 6
    invoke-virtual {v3}, Ljava/lang/Exception;->printStackTrace()V

    .line 7
    :goto_31
    invoke-static {v2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v3

    if-nez v3, :cond_38

    return-object v2

    :cond_38
    add-int/lit8 v1, v1, 0x1

    goto :goto_22

    .line 8
    :cond_3b
    invoke-static {p0, p1}, Lcom/github/catvod/spider/XYQHiker;->ޅ(Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method public static getTextByRule(Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;Ljava/lang/String;)Ljava/lang/String;
    .registers 4

    if-eqz p1, :cond_42

    .line 1
    invoke-virtual {p1}, Ljava/lang/String;->length()I

    move-result v0

    if-eqz v0, :cond_42

    const-string v0, "58"

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_15

    goto :goto_42

    :cond_15
    const-string v0, "5C28206B"

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 2
    invoke-virtual {p1, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    const-string v1, "9DFED8"

    invoke-static {v1}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    if-eqz v0, :cond_2c

    .line 3
    invoke-static {p0, p1, v1}, Lcom/github/catvod/spider/XYQHiker;->֏(Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    return-object p0

    .line 4
    :cond_2c
    invoke-virtual {p1, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    if-eqz v0, :cond_37

    .line 5
    invoke-static {p0, p1, v1}, Lcom/github/catvod/spider/XYQHiker;->֏(Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    return-object p0

    :cond_37
    const-string v0, "2E69"

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 6
    invoke-static {p0, p1, v0}, Lcom/github/catvod/spider/XYQHiker;->֏(Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    return-object p0

    :cond_42
    :goto_42
    const-string p0, ""

    return-object p0
.end method

.method public static getTrueElement(Ljava/lang/String;Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;)Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;
    .registers 8

    const-string v0, "26272B25"

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 1
    invoke-virtual {p0, v0}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v0

    if-nez v0, :cond_c0

    const-string v0, "33362723"

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p0, v0}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_1a

    goto/16 :goto_c0

    .line 2
    :cond_1a
    sget-object v0, Lcom/github/catvod/spider/XYQHiker;->ԯ:[Ljava/lang/String;

    array-length v1, v0

    const/4 v2, 0x0

    const/4 v3, 0x0

    :goto_1f
    if-ge v3, v1, :cond_2d

    aget-object v4, v0, v3

    .line 3
    invoke-virtual {v4, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_2a

    return-object p1

    :cond_2a
    add-int/lit8 v3, v3, 0x1

    goto :goto_1f

    :cond_2d
    const-string v0, "5F6F"

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 4
    invoke-virtual {p0, v0}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v0

    .line 5
    array-length v1, v0

    const/4 v3, 0x1

    if-le v1, v3, :cond_60

    .line 6
    aget-object p0, v0, v2

    invoke-static {p0, p1}, Lcom/github/catvod/spider/XYQHiker;->getTrueElement(Ljava/lang/String;Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;)Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;

    move-result-object p0

    .line 7
    invoke-virtual {p0}, Lcom/github/catvod/spider/xbpqxyq/xyq/ւ;->ދ()Ljava/lang/String;

    move-result-object p1

    .line 8
    :goto_45
    array-length v1, v0

    if-ge v3, v1, :cond_5f

    .line 9
    aget-object v1, v0, v3

    invoke-static {v1, p0}, Lcom/github/catvod/spider/XYQHiker;->getTrueElement(Ljava/lang/String;Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;)Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;

    move-result-object p0

    invoke-virtual {p0}, Lcom/github/catvod/spider/xbpqxyq/xyq/ւ;->ދ()Ljava/lang/String;

    move-result-object p0

    const-string v1, ""

    .line 10
    invoke-virtual {p1, p0, v1}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object p1

    .line 11
    invoke-static {p1}, Lcom/github/catvod/spider/xbpqxyq/xyq/ٱ;->Ϳ(Ljava/lang/String;)Lcom/github/catvod/spider/xbpqxyq/xyq/ǐ;

    move-result-object p0

    add-int/lit8 v3, v3, 0x1

    goto :goto_45

    :cond_5f
    return-object p0

    :cond_60
    const-string v0, "2E3E0F2D"

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 12
    invoke-virtual {p0, v0}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v0

    .line 13
    array-length v1, v0

    if-le v1, v3, :cond_83

    const/4 v1, 0x0

    .line 14
    :goto_6e
    array-length v4, v0

    if-ge v1, v4, :cond_83

    const/4 v4, 0x0

    .line 15
    :try_start_72
    aget-object v5, v0, v1

    invoke-static {v5, p1}, Lcom/github/catvod/spider/XYQHiker;->getTrueElement(Ljava/lang/String;Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;)Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;

    move-result-object v4
    :try_end_78
    .catch Ljava/lang/Exception; {:try_start_72 .. :try_end_78} :catch_79

    goto :goto_7d

    :catch_79
    move-exception v5

    .line 16
    invoke-virtual {v5}, Ljava/lang/Exception;->printStackTrace()V

    :goto_7d
    if-eqz v4, :cond_80

    return-object v4

    :cond_80
    add-int/lit8 v1, v1, 0x1

    goto :goto_6e

    :cond_83
    const-string v0, "5E"

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 17
    invoke-virtual {p0, v0}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v0

    .line 18
    array-length v1, v0

    if-le v1, v3, :cond_b7

    .line 19
    aget-object p0, v0, v3

    invoke-static {p0}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result p0

    .line 20
    aget-object v1, v0, v2

    invoke-virtual {p1, v1}, Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;->ࢳ(Ljava/lang/String;)Lcom/github/catvod/spider/xbpqxyq/xyq/ำ;

    move-result-object v1

    if-gez p0, :cond_aa

    .line 21
    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result p1

    add-int/2addr p1, p0

    invoke-virtual {v1, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;

    return-object p0

    .line 22
    :cond_aa
    aget-object v0, v0, v2

    invoke-virtual {p1, v0}, Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;->ࢳ(Ljava/lang/String;)Lcom/github/catvod/spider/xbpqxyq/xyq/ำ;

    move-result-object p1

    invoke-virtual {p1, p0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;

    return-object p0

    .line 23
    :cond_b7
    invoke-virtual {p1, p0}, Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;->ࢳ(Ljava/lang/String;)Lcom/github/catvod/spider/xbpqxyq/xyq/ำ;

    move-result-object p0

    invoke-virtual {p0}, Lcom/github/catvod/spider/xbpqxyq/xyq/ำ;->ԩ()Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;

    move-result-object p0

    return-object p0

    :cond_c0
    :goto_c0
    return-object p1
.end method

.method public static listToString(Ljava/util/List;Ljava/lang/String;)Ljava/lang/String;
    .registers 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;",
            "Ljava/lang/String;",
            ")",
            "Ljava/lang/String;"
        }
    .end annotation

    .line 1
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    if-eqz p0, :cond_40

    .line 2
    invoke-interface {p0}, Ljava/util/List;->size()I

    move-result v1

    if-gtz v1, :cond_e

    goto :goto_40

    .line 3
    :cond_e
    invoke-interface {p0}, Ljava/util/List;->size()I

    move-result v1

    const/4 v2, 0x0

    const/4 v3, 0x1

    if-gt v1, v3, :cond_1d

    .line 4
    invoke-interface {p0, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/String;

    return-object p0

    .line 5
    :cond_1d
    invoke-interface {p0, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 6
    :goto_26
    invoke-interface {p0}, Ljava/util/List;->size()I

    move-result v1

    if-ge v3, v1, :cond_3b

    .line 7
    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-interface {p0, v3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    add-int/lit8 v3, v3, 0x1

    goto :goto_26

    .line 8
    :cond_3b
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0

    :cond_40
    :goto_40
    const-string p0, ""

    return-object p0
.end method

.method public static selectElements(Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;Ljava/lang/String;)Lcom/github/catvod/spider/xbpqxyq/xyq/ำ;
    .registers 5

    const-string v0, "2E3E0F2D"

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 1
    invoke-virtual {p1, v0}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object p1

    .line 2
    new-instance v0, Lcom/github/catvod/spider/xbpqxyq/xyq/ำ;

    invoke-direct {v0}, Lcom/github/catvod/spider/xbpqxyq/xyq/ำ;-><init>()V

    const/4 v1, 0x0

    .line 3
    :goto_10
    array-length v2, p1

    if-ge v1, v2, :cond_24

    .line 4
    :try_start_13
    aget-object v2, p1, v1

    invoke-static {p0, v2}, Lcom/github/catvod/spider/XYQHiker;->ދ(Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;Ljava/lang/String;)Lcom/github/catvod/spider/xbpqxyq/xyq/ำ;

    move-result-object v2

    invoke-virtual {v0, v2}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z
    :try_end_1c
    .catch Ljava/lang/Exception; {:try_start_13 .. :try_end_1c} :catch_1d

    goto :goto_21

    :catch_1d
    move-exception v2

    .line 5
    invoke-virtual {v2}, Ljava/lang/Exception;->printStackTrace()V

    :goto_21
    add-int/lit8 v1, v1, 0x1

    goto :goto_10

    :cond_24
    return-object v0
.end method

.method public static string2Hex(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    .registers 6

    .line 1
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v1, 0x0

    .line 2
    :goto_6
    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v2

    add-int/lit8 v2, v2, -0x1

    if-gt v1, v2, :cond_32

    .line 3
    invoke-virtual {p0, v1}, Ljava/lang/String;->charAt(I)C

    move-result v2

    .line 4
    invoke-static {v2}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v2

    const-string v3, "162820"

    invoke-static {v3}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    .line 5
    invoke-virtual {p1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_26

    .line 6
    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    goto :goto_2f

    .line 7
    :cond_26
    invoke-static {v2}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v2

    add-int/lit8 v2, v2, 0x1

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    :goto_2f
    add-int/lit8 v1, v1, 0x1

    goto :goto_6

    .line 8
    :cond_32
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method public static vertype(Ljava/lang/String;)Ljava/lang/String;
    .registers 6

    .line 1
    sget-object v0, Lcom/github/catvod/spider/XYQHiker;->Ԯ:[Ljava/lang/String;

    array-length v1, v0

    const/4 v2, 0x0

    :goto_4
    if-ge v2, v1, :cond_12

    aget-object v3, v0, v2

    .line 2
    invoke-virtual {p0, v3}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v4

    if-eqz v4, :cond_f

    return-object v3

    :cond_f
    add-int/lit8 v2, v2, 0x1

    goto :goto_4

    :cond_12
    const-string p0, ""

    return-object p0
.end method

.method private Ԩ(Ljava/lang/String;Ljava/lang/String;ZLjava/util/HashMap;)Lorg/json/JSONObject;
    .registers 39
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Z",
            "Ljava/util/HashMap<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;)",
            "Lorg/json/JSONObject;"
        }
    .end annotation

    move-object/from16 v1, p0

    move-object/from16 v2, p4

    const-string v3, "97CAD5B6EBFF9AF7E4B4FDCF9BE3E6B6FAC5"

    invoke-static {v3}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    const-string v4, "95FFC2B8FBF195FEC5B6FAC594E2EFB4E6CB"

    invoke-static {v4}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    const-string v5, "1F266679"

    invoke-static {v5}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    const-string v6, "092132253F14153F"

    invoke-static {v6}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    const-string v7, "42"

    invoke-static {v7}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    const-string v8, "43"

    invoke-static {v8}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    .line 1
    :try_start_28
    invoke-virtual/range {p0 .. p0}, Lcom/github/catvod/spider/XYQHiker;->Ԯ()V

    .line 2
    invoke-direct {v1, v4}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v10}, Ljava/lang/String;->isEmpty()Z

    move-result v10

    if-nez v10, :cond_36

    goto :goto_3c

    :cond_36
    const-string v4, "312D373834232D243C23372506"

    invoke-static {v4}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    .line 3
    :goto_3c
    invoke-direct {v1, v3}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v10}, Ljava/lang/String;->isEmpty()Z

    move-result v10

    if-nez v10, :cond_47

    goto :goto_4d

    :cond_47
    const-string v3, "142B21222E34132536"

    invoke-static {v3}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    :goto_4d
    const-string v10, "2716157C62"

    invoke-static {v10}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    .line 4
    invoke-direct {v1, v4, v10}, Lcom/github/catvod/spider/XYQHiker;->ރ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    iput-object v4, v1, Lcom/github/catvod/spider/XYQHiker;->ހ:Ljava/lang/String;

    .line 5
    invoke-direct {v1, v3, v8}, Lcom/github/catvod/spider/XYQHiker;->ރ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-static {v4}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v4

    invoke-static {v4}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v4

    .line 6
    invoke-virtual {v4, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v10

    const/4 v11, 0x1

    if-eqz v10, :cond_76

    .line 7
    invoke-static/range {p2 .. p2}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v3

    sub-int/2addr v3, v11

    invoke-static {v3}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v3

    goto :goto_88

    .line 8
    :cond_76
    invoke-static/range {p2 .. p2}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v10

    sub-int/2addr v10, v11

    invoke-direct {v1, v3, v8}, Lcom/github/catvod/spider/XYQHiker;->ރ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-static {v3}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v3

    add-int/2addr v10, v3

    invoke-static {v10}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v3

    :goto_88
    const-string v10, "97CAD5B6EBFF9BD1EDB7D4E1"

    invoke-static {v10}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    .line 9
    invoke-direct {v1, v10}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v10}, Ljava/lang/String;->isEmpty()Z

    move-result v10

    if-nez v10, :cond_9f

    const-string v10, "97CAD5B6EBFF9BD1EDB7D4E1"

    invoke-static {v10}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    goto :goto_a5

    :cond_9f
    const-string v10, "112E3222291B07303F"

    invoke-static {v10}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    .line 10
    :goto_a5
    invoke-direct {v1, v10}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v12

    .line 11
    invoke-virtual {v12, v6}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v13

    if-eqz v13, :cond_b1

    move-object v13, v7

    goto :goto_b2

    :cond_b1
    move-object v13, v8

    :goto_b2
    const-string v14, "142B21222E141325366C"

    invoke-static {v14}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v14

    .line 12
    invoke-virtual {v12, v14}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v14

    const/4 v15, 0x0

    if-eqz v14, :cond_109

    .line 13
    invoke-virtual {v3, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v14
    :try_end_c3
    .catch Ljava/lang/Exception; {:try_start_28 .. :try_end_c3} :catch_cbc

    const-string v9, "2E1935382837061232363F79"

    invoke-static {v9}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    if-eqz v14, :cond_e4

    :try_start_cb
    invoke-virtual {v4, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v14

    if-eqz v14, :cond_e4

    .line 14
    invoke-virtual {v12, v9}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v4

    aget-object v4, v4, v11

    const-string v9, "2E1F"

    invoke-static {v9}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v4, v9}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v4

    aget-object v12, v4, v15

    goto :goto_109

    .line 15
    :cond_e4
    invoke-virtual {v3, v8}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v14

    if-eqz v14, :cond_103

    invoke-virtual {v4, v8}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_103

    .line 16
    invoke-virtual {v12, v9}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v4

    aget-object v4, v4, v11

    const-string v9, "2E1F"

    invoke-static {v9}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v4, v9}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v4

    aget-object v12, v4, v15

    goto :goto_109

    .line 17
    :cond_103
    invoke-virtual {v12, v9}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v4

    aget-object v12, v4, v15
    :try_end_109
    .catch Ljava/lang/Exception; {:try_start_cb .. :try_end_109} :catch_cbc

    :cond_109
    :goto_109
    const-string v4, "0F"

    invoke-static {v4}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    const-string v9, "09"

    invoke-static {v9}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    if-eqz p3, :cond_15e

    if-eqz v2, :cond_15e

    .line 18
    :try_start_119
    invoke-virtual/range {p4 .. p4}, Ljava/util/HashMap;->size()I

    move-result v14

    if-lez v14, :cond_15e

    .line 19
    invoke-virtual/range {p4 .. p4}, Ljava/util/HashMap;->keySet()Ljava/util/Set;

    move-result-object v14

    invoke-interface {v14}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v14

    :goto_127
    invoke-interface {v14}, Ljava/util/Iterator;->hasNext()Z

    move-result v16

    if-eqz v16, :cond_15e

    .line 20
    invoke-interface {v14}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v16

    move-object/from16 v11, v16

    check-cast v11, Ljava/lang/String;

    .line 21
    invoke-virtual {v2, v11}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v16

    move-object/from16 v15, v16

    check-cast v15, Ljava/lang/String;

    .line 22
    invoke-virtual {v15}, Ljava/lang/String;->length()I

    move-result v16

    if-lez v16, :cond_159

    .line 23
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v2, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v12, v2, v15}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object v12

    :cond_159
    move-object/from16 v2, p4

    const/4 v11, 0x1

    const/4 v15, 0x0

    goto :goto_127

    :cond_15e
    const-string v2, "2E3930302E213B260F2C"

    invoke-static {v2}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    move-object/from16 v11, p1

    .line 24
    invoke-virtual {v12, v2, v11}, Ljava/lang/String;->replaceAll(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    .line 25
    invoke-virtual {v2, v6}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v11

    if-nez v11, :cond_19e

    invoke-direct {v1, v10}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v10, v6}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v6

    if-nez v6, :cond_19e

    .line 26
    invoke-virtual {v3, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_18c

    invoke-static {v3}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v6

    invoke-static {v13}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v10

    if-lt v6, v10, :cond_18c

    const/4 v6, 0x0

    return-object v6

    .line 27
    :cond_18c
    invoke-virtual {v3, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v6

    if-nez v6, :cond_19e

    invoke-static {v3}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v6

    invoke-static {v13}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v10

    if-le v6, v10, :cond_19e

    const/4 v6, 0x0

    return-object v6

    :cond_19e
    const-string v6, "2E3930302E2122250F2C"

    invoke-static {v6}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    .line 28
    invoke-virtual {v2, v6, v3}, Ljava/lang/String;->replaceAll(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    const-string v6, "2E397B7F707B5B1E2E"

    invoke-static {v6}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    .line 29
    invoke-static {v6}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    move-result-object v6

    invoke-virtual {v6, v2}, Ljava/util/regex/Pattern;->matcher(Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;

    move-result-object v6

    .line 30
    :goto_1b6
    invoke-virtual {v6}, Ljava/util/regex/Matcher;->find()Z

    move-result v10
    :try_end_1ba
    .catch Ljava/lang/Exception; {:try_start_119 .. :try_end_1ba} :catch_cbc

    const-string v11, ""

    if-eqz v10, :cond_1f6

    const/4 v10, 0x0

    .line 31
    :try_start_1bf
    invoke-virtual {v6, v10}, Ljava/util/regex/Matcher;->group(I)Ljava/lang/String;

    move-result-object v12

    invoke-virtual {v12, v9, v11}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object v12

    invoke-virtual {v12, v4, v11}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object v12

    .line 32
    invoke-virtual {v6, v10}, Ljava/util/regex/Matcher;->group(I)Ljava/lang/String;

    move-result-object v13

    invoke-virtual {v2, v13, v11}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object v2

    new-instance v10, Ljava/lang/StringBuilder;

    invoke-direct {v10}, Ljava/lang/StringBuilder;-><init>()V

    const-string v13, "5D"

    invoke-static {v13}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v13

    invoke-virtual {v10, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v10, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v12, "5D"

    invoke-static {v12}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v12

    invoke-virtual {v10, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v10}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v2, v10, v11}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object v2

    goto :goto_1b6

    .line 33
    :cond_1f6
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v12

    const-wide/16 v14, 0x3e8

    div-long/2addr v12, v14

    invoke-static {v12, v13}, Ljava/lang/String;->valueOf(J)Ljava/lang/String;

    move-result-object v6

    .line 34
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v12

    invoke-static {v12, v13}, Ljava/lang/String;->valueOf(J)Ljava/lang/String;

    move-result-object v10

    const-string v12, "94D5E5B8CDF094CAE0"

    invoke-static {v12}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v12

    .line 35
    invoke-virtual {v2, v12, v6}, Ljava/lang/String;->replaceAll(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    const-string v6, "94D5E5B8CDF094E2D4"

    invoke-static {v6}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    .line 36
    invoke-virtual {v2, v6, v10}, Ljava/lang/String;->replaceAll(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    .line 37
    invoke-virtual {v2, v5}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v6
    :try_end_221
    .catch Ljava/lang/Exception; {:try_start_1bf .. :try_end_221} :catch_cbc

    const-string v10, "5B"

    invoke-static {v10}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    if-eqz v6, :cond_250

    .line 38
    :try_start_229
    invoke-static {v2, v5, v10}, Lcom/github/catvod/spider/xbpqxyq/xyq/ވ;->އ(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/util/ArrayList;

    move-result-object v6

    const/4 v12, 0x0

    invoke-virtual {v6, v12}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Ljava/lang/String;

    .line 39
    new-instance v12, Ljava/lang/StringBuilder;

    invoke-direct {v12}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v12, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v12, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v12, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v12}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    sget-object v12, Lcom/github/catvod/spider/xbpqxyq/xyq/ކ;->ԩ:Ljava/nio/charset/Charset;

    invoke-static {v6, v12}, Lcom/github/catvod/spider/xbpqxyq/xyq/ކ;->Ϳ(Ljava/lang/String;Ljava/nio/charset/Charset;)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v2, v5, v6}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object v2

    :cond_250
    const-string v5, "9DFFC8"

    invoke-static {v5}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    .line 40
    invoke-virtual {v2, v5, v9}, Ljava/lang/String;->replaceAll(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    const-string v5, "9DFFCE"

    invoke-static {v5}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v2, v5, v4}, Ljava/lang/String;->replaceAll(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    const-string v5, "49323C222E"

    invoke-static {v5}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    .line 41
    invoke-virtual {v2, v5}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v5
    :try_end_26e
    .catch Ljava/lang/Exception; {:try_start_229 .. :try_end_26e} :catch_cbc

    const-string v6, "012A3C26"

    invoke-static {v6}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    if-eqz v5, :cond_357

    :try_start_276
    const-string v5, "2E7D"

    invoke-static {v5}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    .line 42
    invoke-virtual {v2, v5}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v5

    const/4 v12, 0x0

    aget-object v5, v5, v12

    const-string v12, "9DFECCBEE6DB"

    invoke-static {v12}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v12

    const-string v13, "4D"

    invoke-static {v13}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v13

    invoke-virtual {v5, v12, v13}, Ljava/lang/String;->replaceAll(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v5

    const-string v12, "2E7D"

    invoke-static {v12}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v12

    .line 43
    invoke-virtual {v2, v12}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v12

    const/4 v13, 0x1

    aget-object v12, v12, v13

    const-string v13, "49"

    invoke-static {v13}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v13

    invoke-virtual {v12, v13}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v12

    const/4 v13, 0x0

    aget-object v12, v12, v13

    const-string v13, "9DFECCBEE6DB"

    invoke-static {v13}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v13

    const-string v14, "4D"

    invoke-static {v14}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v14

    invoke-virtual {v12, v13, v14}, Ljava/lang/String;->replaceAll(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v12

    invoke-virtual {v12}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v12

    .line 44
    invoke-virtual {v12}, Ljava/lang/String;->isEmpty()Z

    move-result v13

    if-nez v13, :cond_34b

    .line 45
    invoke-virtual {v12, v9}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v9

    if-eqz v9, :cond_2ec

    invoke-virtual {v12, v4}, Ljava/lang/String;->endsWith(Ljava/lang/String;)Z

    move-result v4

    if-eqz v4, :cond_2ec

    .line 46
    new-instance v4, Lorg/json/JSONObject;

    invoke-direct {v4, v12}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    .line 47
    invoke-virtual {v4}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object v4

    iget-object v6, v1, Lcom/github/catvod/spider/XYQHiker;->ހ:Ljava/lang/String;

    invoke-virtual {v1, v5}, Lcom/github/catvod/spider/XYQHiker;->ހ(Ljava/lang/String;)Ljava/util/HashMap;

    move-result-object v9

    invoke-virtual {v1, v5, v4, v6, v9}, Lcom/github/catvod/spider/XYQHiker;->Ϳ(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/util/Map;)Ljava/lang/String;

    move-result-object v4

    goto/16 :goto_3b4

    .line 48
    :cond_2ec
    new-instance v4, Ljava/util/LinkedHashMap;

    invoke-direct {v4}, Ljava/util/LinkedHashMap;-><init>()V

    const-string v9, "54"

    invoke-static {v9}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    .line 49
    invoke-virtual {v12, v9}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v9

    .line 50
    array-length v12, v9

    const/4 v13, 0x0

    :goto_2fd
    if-ge v13, v12, :cond_324

    aget-object v14, v9, v13

    const-string v15, "4F"

    invoke-static {v15}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v15

    .line 51
    invoke-virtual {v14, v15}, Ljava/lang/String;->indexOf(Ljava/lang/String;)I

    move-result v15

    move-object/from16 p1, v9

    move/from16 v16, v12

    const/4 v9, 0x0

    .line 52
    invoke-virtual {v14, v9, v15}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v12

    add-int/lit8 v15, v15, 0x1

    invoke-virtual {v14, v15}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v4, v12, v9}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    add-int/lit8 v13, v13, 0x1

    move-object/from16 v9, p1

    move/from16 v12, v16

    goto :goto_2fd

    .line 53
    :cond_324
    iget-object v9, v1, Lcom/github/catvod/spider/XYQHiker;->ހ:Ljava/lang/String;

    invoke-virtual {v1, v5}, Lcom/github/catvod/spider/XYQHiker;->ހ(Ljava/lang/String;)Ljava/util/HashMap;

    move-result-object v12

    invoke-virtual {v1, v5, v4, v9, v12}, Lcom/github/catvod/spider/XYQHiker;->ԭ(Ljava/lang/String;Ljava/util/Map;Ljava/lang/String;Ljava/util/Map;)Ljava/lang/String;

    move-result-object v9

    const-string v12, "9AFCC0B4DFE19BE8DFB9F5C595E2D2"

    invoke-static {v12}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v12

    .line 54
    invoke-virtual {v9, v12}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v12

    if-eqz v12, :cond_349

    invoke-static {v9}, Lcom/github/catvod/spider/XYQHiker;->checkveriry(Ljava/lang/String;)Z

    move-result v12

    if-eqz v12, :cond_349

    .line 55
    invoke-static {v9}, Lcom/github/catvod/spider/XYQHiker;->vertype(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    invoke-direct {v1, v5, v4, v6, v9}, Lcom/github/catvod/spider/XYQHiker;->ވ(Ljava/lang/String;Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    goto :goto_3b4

    :cond_349
    move-object v4, v9

    goto :goto_3b4

    .line 56
    :cond_34b
    iget-object v4, v1, Lcom/github/catvod/spider/XYQHiker;->ހ:Ljava/lang/String;

    invoke-virtual {v1, v5}, Lcom/github/catvod/spider/XYQHiker;->ހ(Ljava/lang/String;)Ljava/util/HashMap;

    move-result-object v6

    const/4 v9, 0x0

    invoke-virtual {v1, v5, v9, v4, v6}, Lcom/github/catvod/spider/XYQHiker;->ԭ(Ljava/lang/String;Ljava/util/Map;Ljava/lang/String;Ljava/util/Map;)Ljava/lang/String;

    move-result-object v4

    goto :goto_3b4

    .line 57
    :cond_357
    iget-object v4, v1, Lcom/github/catvod/spider/XYQHiker;->ހ:Ljava/lang/String;

    invoke-virtual {v1, v2}, Lcom/github/catvod/spider/XYQHiker;->ހ(Ljava/lang/String;)Ljava/util/HashMap;

    move-result-object v5

    invoke-virtual {v1, v2, v4, v5}, Lcom/github/catvod/spider/XYQHiker;->Ԭ(Ljava/lang/String;Ljava/lang/String;Ljava/util/Map;)Ljava/lang/String;

    move-result-object v4

    const-string v5, "94E1D3B7EFCF96FAFE"

    invoke-static {v5}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    .line 58
    invoke-virtual {v4, v5}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v5

    if-eqz v5, :cond_37d

    const-string v5, "103624303C"

    invoke-static {v5}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v5

    if-eqz v5, :cond_37d

    .line 59
    invoke-direct {v1, v2, v4, v6}, Lcom/github/catvod/spider/XYQHiker;->އ(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    :cond_37d
    const-string v5, "5D2A26303E2B1C250C"

    invoke-static {v5}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    .line 60
    invoke-virtual {v4, v5}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v5

    if-nez v5, :cond_395

    const-string v5, "5D30363F302D2D"

    invoke-static {v5}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v5

    if-eqz v5, :cond_399

    .line 61
    :cond_395
    invoke-direct {v1, v2, v4, v6}, Lcom/github/catvod/spider/XYQHiker;->ކ(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    :cond_399
    const-string v5, "9AFCC0B4DFE19BE8DFB9F5C595E2D2"

    invoke-static {v5}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    .line 62
    invoke-virtual {v4, v5}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v5

    if-eqz v5, :cond_3b4

    invoke-static {v4}, Lcom/github/catvod/spider/XYQHiker;->checkveriry(Ljava/lang/String;)Z

    move-result v5

    if-eqz v5, :cond_3b4

    .line 63
    invoke-static {v4}, Lcom/github/catvod/spider/XYQHiker;->vertype(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    const/4 v5, 0x0

    invoke-direct {v1, v2, v5, v6, v4}, Lcom/github/catvod/spider/XYQHiker;->ވ(Ljava/lang/String;Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    .line 64
    :cond_3b4
    :goto_3b4
    invoke-static {v4}, Lcom/github/catvod/spider/XYQHiker;->ԩ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    const-string v5, "97CAD5B6EBFF94CAF9B4D5D294EAF2B4E6CB"

    invoke-static {v5}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    .line 65
    invoke-direct {v1, v5}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/String;->isEmpty()Z

    move-result v5

    if-nez v5, :cond_3cf

    const-string v5, "97CAD5B6EBFF94CAF9B4D5D294EAF2B4E6CB"

    invoke-static {v5}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    goto :goto_3d5

    :cond_3cf
    const-string v5, "1123270E372B1627"

    invoke-static {v5}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    :goto_3d5
    const-string v6, "97CAD5B6EBFF95CBD4B4D7D194DAFCB4CAE238313C242AA1F4DBB5E2CF"

    invoke-static {v6}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    .line 66
    invoke-direct {v1, v6}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/String;->isEmpty()Z

    move-result v6

    if-nez v6, :cond_3ec

    const-string v6, "97CAD5B6EBFF95CBD4B4D7D194DAFCB4CAE238313C242AA1F4DBB5E2CF"

    invoke-static {v6}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    goto :goto_3f2

    :cond_3ec
    const-string v6, "1123270E33372D28203E2F34"

    invoke-static {v6}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    :goto_3f2
    const-string v9, "97CAD5B6EBFF38313C3FBCD1C2A4DEFFBEFEFEA4FFF0BCCCD8A7DCC7"

    invoke-static {v9}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    .line 67
    invoke-direct {v1, v9}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v9}, Ljava/lang/String;->isEmpty()Z

    move-result v9

    if-nez v9, :cond_409

    const-string v9, "97CAD5B6EBFF38313C3FBCD1C2A4DEFFBEFEFEA4FFF0BCCCD8A7DCC7"

    invoke-static {v9}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    goto :goto_40f

    :cond_409
    const-string v9, "1123273B292B1C1D2726332717"

    invoke-static {v9}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    :goto_40f
    const-string v12, "97D9EDB6D3C394DAFCB4CAE29BDED3B9FCC596F9F0B6CAC2"

    invoke-static {v12}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v12

    .line 68
    invoke-direct {v1, v12}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v12

    invoke-virtual {v12}, Ljava/lang/String;->isEmpty()Z

    move-result v12

    if-nez v12, :cond_426

    const-string v12, "97D9EDB6D3C394DAFCB4CAE29BDED3B9FCC596F9F0B6CAC2"

    invoke-static {v12}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v12

    goto :goto_42c

    :cond_426
    const-string v12, "222B301F3F211612213E223D"

    invoke-static {v12}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v12

    .line 69
    :goto_42c
    invoke-direct {v1, v5}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v13

    invoke-virtual {v13, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v7

    if-nez v7, :cond_449

    invoke-direct {v1, v5}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    const-string v7, "97D2F5"

    invoke-static {v7}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v5, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_447

    goto :goto_449

    :cond_447
    const/4 v5, 0x0

    goto :goto_44a

    :cond_449
    :goto_449
    const/4 v5, 0x1

    .line 70
    :goto_44a
    invoke-direct {v1, v6, v8}, Lcom/github/catvod/spider/XYQHiker;->ރ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v7, v8}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v7
    :try_end_452
    .catch Ljava/lang/Exception; {:try_start_276 .. :try_end_452} :catch_cbc

    const-string v13, "94DAFC"

    invoke-static {v13}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v13

    if-nez v7, :cond_467

    :try_start_45a
    invoke-direct {v1, v6, v13}, Lcom/github/catvod/spider/XYQHiker;->ރ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v6, v13}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_465

    goto :goto_467

    :cond_465
    const/4 v6, 0x0

    goto :goto_468

    :cond_467
    :goto_467
    const/4 v6, 0x1

    .line 71
    :goto_468
    invoke-direct {v1, v12}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v7, v8}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v7

    if-nez v7, :cond_47f

    invoke-direct {v1, v12}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v7, v13}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v7

    if-eqz v7, :cond_47d

    goto :goto_47f

    :cond_47d
    const/4 v7, 0x0

    goto :goto_480

    :cond_47f
    :goto_47f
    const/4 v7, 0x1

    :goto_480
    const-string v12, "97CAD5B6EBFF97CAC4B9FBEC94D7E3B6E1C09AE5D7B4D2DD"

    invoke-static {v12}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v12

    .line 72
    invoke-direct {v1, v12}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v12

    invoke-virtual {v12}, Ljava/lang/String;->isEmpty()Z

    move-result v12

    if-nez v12, :cond_497

    const-string v12, "97CAD5B6EBFF97CAC4B9FBEC94D7E3B6E1C09AE5D7B4D2DD"

    invoke-static {v12}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v12

    goto :goto_49d

    :cond_497
    const-string v12, "1123270E3B36001D21243621"

    invoke-static {v12}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v12

    :goto_49d
    const-string v14, "97CAD5B6EBFF95CBD4B4D7D194E2D4B8F8DC"

    invoke-static {v14}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v14

    .line 73
    invoke-direct {v1, v14}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v14

    invoke-virtual {v14}, Ljava/lang/String;->isEmpty()Z

    move-result v14

    if-nez v14, :cond_4b4

    const-string v14, "97CAD5B6EBFF95CBD4B4D7D194E2D4B8F8DC"

    invoke-static {v14}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v14

    goto :goto_4ba

    :cond_4b4
    const-string v14, "1123270E2E2D062E36"

    invoke-static {v14}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v14

    :goto_4ba
    const-string v15, "97CAD5B6EBFF95CBD4B4D7D19BD1EDB7D4E1"

    invoke-static {v15}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v15

    .line 74
    invoke-direct {v1, v15}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v15

    invoke-virtual {v15}, Ljava/lang/String;->isEmpty()Z

    move-result v15

    if-nez v15, :cond_4d1

    const-string v15, "97CAD5B6EBFF95CBD4B4D7D19BD1EDB7D4E1"

    invoke-static {v15}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v15

    goto :goto_4d7

    :cond_4d1
    const-string v15, "1123270E2F361E"

    invoke-static {v15}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v15

    :goto_4d7
    move-object/from16 v16, v3

    const-string v3, "97CAD5B6EBFF95CBD4B4D7D197D9EDB6D3C3"

    invoke-static {v3}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    .line 75
    invoke-direct {v1, v3}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/String;->isEmpty()Z

    move-result v3

    if-nez v3, :cond_4f0

    const-string v3, "97CAD5B6EBFF95CBD4B4D7D197D9EDB6D3C3"

    invoke-static {v3}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    goto :goto_4f6

    :cond_4f0
    const-string v3, "1123270E2A2D11"

    invoke-static {v3}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    :goto_4f6
    move-object/from16 p1, v10

    const-string v10, "97CAD5B6EBFF95CBD4B4D7D197CBFCB7FAC39BE0CB"

    invoke-static {v10}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    .line 76
    invoke-direct {v1, v10}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v10}, Ljava/lang/String;->isEmpty()Z

    move-result v10

    if-nez v10, :cond_50f

    const-string v10, "97CAD5B6EBFF95CBD4B4D7D197CBFCB7FAC39BE0CB"

    invoke-static {v10}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    goto :goto_515

    :cond_50f
    const-string v10, "1123270E293110363A253621"

    invoke-static {v10}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    :goto_515
    move/from16 p3, v6

    const-string v6, "97CAD5B6EBFF95CBD4B4D7D19BD1EDB7D4E197C8F3B4D3C995FED3"

    invoke-static {v6}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    .line 77
    invoke-direct {v1, v6}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/String;->isEmpty()Z

    move-result v6

    if-nez v6, :cond_52e

    const-string v6, "97CAD5B6EBFF95CBD4B4D7D19BD1EDB7D4E197C8F3B4D3C995FED3"

    invoke-static {v6}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    goto :goto_534

    :cond_52e
    const-string v6, "1123270E2A3617243A29"

    invoke-static {v6}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    :goto_534
    move-object/from16 p4, v13

    const-string v13, "97CAD5B6EBFF95CBD4B4D7D19BD1EDB7D4E197C8F3B4CACA95FED3"

    invoke-static {v13}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v13

    .line 78
    invoke-direct {v1, v13}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v13

    invoke-virtual {v13}, Ljava/lang/String;->isEmpty()Z

    move-result v13

    if-nez v13, :cond_54d

    const-string v13, "97CAD5B6EBFF95CBD4B4D7D19BD1EDB7D4E197C8F3B4CACA95FED3"

    invoke-static {v13}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v13

    goto :goto_553

    :cond_54d
    const-string v13, "1123270E293114243A29"

    invoke-static {v13}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v13

    :goto_553
    move-object/from16 v18, v8

    .line 79
    new-instance v8, Lorg/json/JSONArray;

    invoke-direct {v8}, Lorg/json/JSONArray;-><init>()V

    move-object/from16 v19, v8

    .line 80
    new-instance v8, Lorg/json/JSONObject;

    invoke-direct {v8}, Lorg/json/JSONObject;-><init>()V
    :try_end_561
    .catch Ljava/lang/Exception; {:try_start_45a .. :try_end_561} :catch_cbc

    move-object/from16 v20, v8

    const-string v8, "566677"

    invoke-static {v8}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    move-object/from16 v21, v8

    const-string v8, "552B3D212F3055"

    invoke-static {v8}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    move-object/from16 v22, v10

    const-string v10, "5464"

    invoke-static {v10}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    if-eqz v5, :cond_7ef

    .line 81
    :try_start_57b
    invoke-direct {v1, v9}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    .line 82
    invoke-virtual {v5}, Ljava/lang/String;->isEmpty()Z

    move-result v9

    if-nez v9, :cond_5a6

    invoke-virtual {v5, v10}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v9

    if-eqz v9, :cond_5a6

    .line 83
    invoke-virtual {v5, v10}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v9

    move/from16 v23, v7

    const/4 v7, 0x0

    aget-object v9, v9, v7

    invoke-virtual {v5, v10}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v5

    const/4 v10, 0x1

    aget-object v5, v5, v10

    invoke-static {v4, v9, v5}, Lcom/github/catvod/spider/xbpqxyq/xyq/ވ;->އ(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/util/ArrayList;

    move-result-object v4

    invoke-virtual {v4, v7}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/lang/String;

    goto :goto_5a8

    :cond_5a6
    move/from16 v23, v7

    .line 84
    :goto_5a8
    new-instance v5, Lorg/json/JSONObject;

    invoke-direct {v5, v4}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    const-string v4, "16232730"

    invoke-static {v4}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    .line 85
    invoke-direct {v1, v12, v4}, Lcom/github/catvod/spider/XYQHiker;->ރ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    const-string v7, "2E6C"

    invoke-static {v7}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v4, v7}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v4

    .line 86
    array-length v7, v4

    const/4 v9, 0x1

    if-ne v7, v9, :cond_5cd

    const/4 v7, 0x0

    .line 87
    aget-object v4, v4, v7

    invoke-virtual {v5, v4}, Lorg/json/JSONObject;->getJSONArray(Ljava/lang/String;)Lorg/json/JSONArray;

    move-result-object v4

    goto :goto_61a

    .line 88
    :cond_5cd
    array-length v7, v4

    const/4 v9, 0x2

    if-ne v7, v9, :cond_5e0

    const/4 v7, 0x0

    .line 89
    aget-object v9, v4, v7

    invoke-virtual {v5, v9}, Lorg/json/JSONObject;->getJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v5

    const/4 v7, 0x1

    aget-object v4, v4, v7

    invoke-virtual {v5, v4}, Lorg/json/JSONObject;->getJSONArray(Ljava/lang/String;)Lorg/json/JSONArray;

    move-result-object v4

    goto :goto_61a

    .line 90
    :cond_5e0
    array-length v7, v4

    const/4 v10, 0x3

    if-ne v7, v10, :cond_5f9

    const/4 v7, 0x0

    .line 91
    aget-object v10, v4, v7

    invoke-virtual {v5, v10}, Lorg/json/JSONObject;->getJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v5

    const/4 v7, 0x1

    aget-object v10, v4, v7

    invoke-virtual {v5, v10}, Lorg/json/JSONObject;->getJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v5

    aget-object v4, v4, v9

    invoke-virtual {v5, v4}, Lorg/json/JSONObject;->getJSONArray(Ljava/lang/String;)Lorg/json/JSONArray;

    move-result-object v4

    goto :goto_61a

    .line 92
    :cond_5f9
    array-length v7, v4

    const/4 v10, 0x4

    if-ne v7, v10, :cond_619

    const/4 v7, 0x0

    .line 93
    aget-object v10, v4, v7

    invoke-virtual {v5, v10}, Lorg/json/JSONObject;->getJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v5

    const/4 v7, 0x1

    aget-object v10, v4, v7

    invoke-virtual {v5, v10}, Lorg/json/JSONObject;->getJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v5

    aget-object v7, v4, v9

    invoke-virtual {v5, v7}, Lorg/json/JSONObject;->getJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v5

    const/4 v7, 0x3

    aget-object v4, v4, v7

    invoke-virtual {v5, v4}, Lorg/json/JSONObject;->getJSONArray(Ljava/lang/String;)Lorg/json/JSONArray;

    move-result-object v4

    goto :goto_61a

    :cond_619
    const/4 v4, 0x0

    :goto_61a
    move-object v7, v11

    move-object v9, v7

    const/4 v5, 0x0

    .line 94
    :goto_61d
    invoke-virtual {v4}, Lorg/json/JSONArray;->length()I

    move-result v10
    :try_end_621
    .catch Ljava/lang/Exception; {:try_start_57b .. :try_end_621} :catch_cbc

    if-ge v5, v10, :cond_7eb

    .line 95
    :try_start_623
    invoke-virtual {v4, v5}, Lorg/json/JSONArray;->getJSONObject(I)Lorg/json/JSONObject;

    move-result-object v10

    .line 96
    invoke-direct {v1, v14}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v12

    invoke-virtual {v10, v12}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v12

    invoke-virtual {v12}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v12
    :try_end_633
    .catch Ljava/lang/Exception; {:try_start_623 .. :try_end_633} :catch_79b

    move-object/from16 p1, v4

    .line 97
    :try_start_635
    invoke-direct {v1, v15}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v10, v4}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v4
    :try_end_641
    .catch Ljava/lang/Exception; {:try_start_635 .. :try_end_641} :catch_797

    move-object/from16 p2, v7

    .line 98
    :try_start_643
    new-instance v7, Ljava/lang/StringBuilder;

    invoke-direct {v7}, Ljava/lang/StringBuilder;-><init>()V
    :try_end_648
    .catch Ljava/lang/Exception; {:try_start_643 .. :try_end_648} :catch_793

    move-object/from16 p3, v9

    :try_start_64a
    invoke-direct {v1, v6, v11}, Lcom/github/catvod/spider/XYQHiker;->ރ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v7, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v7, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-direct {v1, v13, v11}, Lcom/github/catvod/spider/XYQHiker;->ރ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v7, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v7

    .line 99
    invoke-virtual {v7, v8}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v9
    :try_end_663
    .catch Ljava/lang/Exception; {:try_start_64a .. :try_end_663} :catch_77f

    if-eqz v9, :cond_67f

    .line 100
    :try_start_665
    invoke-virtual {v7, v8, v4}, Ljava/lang/String;->replaceAll(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7
    :try_end_669
    .catch Ljava/lang/Exception; {:try_start_665 .. :try_end_669} :catch_66a

    goto :goto_67f

    :catch_66a
    move-exception v0

    move-object/from16 v4, p2

    move-object/from16 v9, p3

    move-object/from16 v26, v3

    move-object/from16 v7, v19

    move-object/from16 v3, v21

    move-object/from16 v24, v22

    move/from16 v25, v23

    move-object/from16 v22, v8

    move-object/from16 v23, v15

    goto/16 :goto_7b2

    .line 101
    :cond_67f
    :goto_67f
    :try_start_67f
    invoke-direct {v1, v3}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/String;->isEmpty()Z

    move-result v4
    :try_end_687
    .catch Ljava/lang/Exception; {:try_start_67f .. :try_end_687} :catch_77f

    if-nez v4, :cond_6e6

    .line 102
    :try_start_689
    invoke-direct {v1, v3}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    const-string v9, "1A362721"

    invoke-static {v9}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v4, v9}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v4
    :try_end_697
    .catch Ljava/lang/Exception; {:try_start_689 .. :try_end_697} :catch_6c8

    if-eqz v4, :cond_6a6

    .line 103
    :try_start_699
    invoke-direct {v1, v3}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4
    :try_end_69d
    .catch Ljava/lang/Exception; {:try_start_699 .. :try_end_69d} :catch_69e

    goto :goto_6b6

    :catch_69e
    move-exception v0

    move-object/from16 v4, p2

    move-object/from16 v18, v0

    move/from16 v9, v23

    goto :goto_6cf

    .line 104
    :cond_6a6
    :try_start_6a6
    invoke-direct {v1, v3}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v10, v4}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v4
    :try_end_6b2
    .catch Ljava/lang/Exception; {:try_start_6a6 .. :try_end_6b2} :catch_6c8

    .line 105
    :try_start_6b2
    invoke-static {v2, v4}, Lcom/github/catvod/spider/xbpqxyq/xyq/ވ;->Ԫ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4
    :try_end_6b6
    .catch Ljava/lang/Exception; {:try_start_6b2 .. :try_end_6b6} :catch_6c4

    :goto_6b6
    if-eqz v23, :cond_6c1

    move/from16 v9, v23

    .line 106
    :try_start_6ba
    invoke-virtual {v1, v4, v2, v9}, Lcom/github/catvod/spider/XYQHiker;->ԯ(Ljava/lang/String;Ljava/lang/String;Z)Ljava/lang/String;

    move-result-object v4
    :try_end_6be
    .catch Ljava/lang/Exception; {:try_start_6ba .. :try_end_6be} :catch_6bf

    goto :goto_6ea

    :catch_6bf
    move-exception v0

    goto :goto_6cd

    :cond_6c1
    move/from16 v9, v23

    goto :goto_6ea

    :catch_6c4
    move-exception v0

    move/from16 v9, v23

    goto :goto_6cd

    :catch_6c8
    move-exception v0

    move/from16 v9, v23

    move-object/from16 v4, p2

    :goto_6cd
    move-object/from16 v18, v0

    .line 107
    :goto_6cf
    :try_start_6cf
    invoke-static/range {v18 .. v18}, Lcom/github/catvod/crawler/SpiderDebug;->log(Ljava/lang/Throwable;)V
    :try_end_6d2
    .catch Ljava/lang/Exception; {:try_start_6cf .. :try_end_6d2} :catch_6d3

    goto :goto_6ea

    :catch_6d3
    move-exception v0

    move-object/from16 v26, v3

    move/from16 v25, v9

    move-object/from16 v23, v15

    move-object/from16 v7, v19

    move-object/from16 v3, v21

    move-object/from16 v24, v22

    move-object/from16 v9, p3

    move-object/from16 v22, v8

    goto/16 :goto_7b2

    :cond_6e6
    move/from16 v9, v23

    move-object/from16 v4, p2

    :goto_6ea
    move-object/from16 v23, v15

    move-object/from16 v33, v22

    move-object/from16 v22, v8

    move-object/from16 v8, v33

    .line 108
    :try_start_6f2
    invoke-direct {v1, v8}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v15

    invoke-virtual {v10, v15}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v10}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v10
    :try_end_6fe
    .catch Ljava/lang/Exception; {:try_start_6f2 .. :try_end_6fe} :catch_6ff

    goto :goto_706

    :catch_6ff
    move-exception v0

    move-object v10, v0

    .line 109
    :try_start_701
    invoke-static {v10}, Lcom/github/catvod/crawler/SpiderDebug;->log(Ljava/lang/Throwable;)V
    :try_end_704
    .catch Ljava/lang/Exception; {:try_start_701 .. :try_end_704} :catch_773

    move-object/from16 v10, p3

    .line 110
    :goto_706
    :try_start_706
    new-instance v15, Lorg/json/JSONObject;

    invoke-direct {v15}, Lorg/json/JSONObject;-><init>()V
    :try_end_70b
    .catch Ljava/lang/Exception; {:try_start_706 .. :try_end_70b} :catch_765

    move-object/from16 v24, v8

    :try_start_70d
    const-string v8, "042D370E3320"

    invoke-static {v8}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8
    :try_end_713
    .catch Ljava/lang/Exception; {:try_start_70d .. :try_end_713} :catch_761

    move/from16 v25, v9

    .line 111
    :try_start_715
    new-instance v9, Ljava/lang/StringBuilder;

    invoke-direct {v9}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v9, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    :try_end_71d
    .catch Ljava/lang/Exception; {:try_start_715 .. :try_end_71d} :catch_75d

    move-object/from16 v26, v3

    move-object/from16 v3, v21

    :try_start_721
    invoke-virtual {v9, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v9, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v9, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v9, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v9}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v15, v8, v7}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const-string v7, "042D370E34251F27"

    invoke-static {v7}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    .line 112
    invoke-virtual {v15, v7, v12}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const-string v7, "042D370E2A2D11"

    invoke-static {v7}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    .line 113
    invoke-virtual {v15, v7, v4}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const-string v7, "042D370E28211F23213A29"

    invoke-static {v7}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    .line 114
    invoke-virtual {v15, v7, v10}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    :try_end_74f
    .catch Ljava/lang/Exception; {:try_start_721 .. :try_end_74f} :catch_759

    move-object/from16 v7, v19

    .line 115
    :try_start_751
    invoke-virtual {v7, v15}, Lorg/json/JSONArray;->put(Ljava/lang/Object;)Lorg/json/JSONArray;
    :try_end_754
    .catch Ljava/lang/Exception; {:try_start_751 .. :try_end_754} :catch_757

    move-object v9, v10

    goto/16 :goto_7d6

    :catch_757
    move-exception v0

    goto :goto_770

    :catch_759
    move-exception v0

    move-object/from16 v7, v19

    goto :goto_770

    :catch_75d
    move-exception v0

    move-object/from16 v26, v3

    goto :goto_76c

    :catch_761
    move-exception v0

    move-object/from16 v26, v3

    goto :goto_76a

    :catch_765
    move-exception v0

    move-object/from16 v26, v3

    move-object/from16 v24, v8

    :goto_76a
    move/from16 v25, v9

    :goto_76c
    move-object/from16 v7, v19

    move-object/from16 v3, v21

    :goto_770
    move-object v8, v0

    move-object v9, v10

    goto :goto_7b3

    :catch_773
    move-exception v0

    move-object/from16 v26, v3

    move-object/from16 v24, v8

    move/from16 v25, v9

    move-object/from16 v7, v19

    move-object/from16 v3, v21

    goto :goto_790

    :catch_77f
    move-exception v0

    move-object/from16 v26, v3

    move-object/from16 v7, v19

    move-object/from16 v3, v21

    move-object/from16 v24, v22

    move/from16 v25, v23

    move-object/from16 v22, v8

    move-object/from16 v23, v15

    move-object/from16 v4, p2

    :goto_790
    move-object/from16 v9, p3

    goto :goto_7b2

    :catch_793
    move-exception v0

    move-object/from16 v26, v3

    goto :goto_7a2

    :catch_797
    move-exception v0

    move-object/from16 v26, v3

    goto :goto_7a0

    :catch_79b
    move-exception v0

    move-object/from16 v26, v3

    move-object/from16 p1, v4

    :goto_7a0
    move-object/from16 p2, v7

    :goto_7a2
    move-object/from16 p3, v9

    move-object/from16 v7, v19

    move-object/from16 v3, v21

    move-object/from16 v24, v22

    move/from16 v25, v23

    move-object/from16 v22, v8

    move-object/from16 v23, v15

    move-object/from16 v4, p2

    :goto_7b2
    move-object v8, v0

    .line 116
    :goto_7b3
    :try_start_7b3
    invoke-static {v8}, Lcom/github/catvod/crawler/SpiderDebug;->log(Ljava/lang/Throwable;)V

    .line 117
    iget-boolean v10, v1, Lcom/github/catvod/spider/XYQHiker;->ވ:Z

    if-eqz v10, :cond_7d6

    .line 118
    new-instance v10, Ljava/lang/StringBuilder;

    invoke-direct {v10}, Ljava/lang/StringBuilder;-><init>()V

    const-string v12, "97CAD5B6EBFF9AE5F0B7C4D418313C3FBFC3C8ABC7C8B5F8E8"

    invoke-static {v12}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v12

    invoke-virtual {v10, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v8}, Ljava/lang/Exception;->toString()Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v10, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v10}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v8

    invoke-static {v8}, Lcom/github/catvod/spider/Init;->show(Ljava/lang/String;)V

    :cond_7d6
    :goto_7d6
    add-int/lit8 v5, v5, 0x1

    move-object/from16 v21, v3

    move-object/from16 v19, v7

    move-object/from16 v8, v22

    move-object/from16 v15, v23

    move-object/from16 v22, v24

    move/from16 v23, v25

    move-object/from16 v3, v26

    move-object v7, v4

    move-object/from16 v4, p1

    goto/16 :goto_61d

    :cond_7eb
    move-object/from16 v4, v19

    goto/16 :goto_c77

    :cond_7ef
    move-object/from16 v26, v3

    move/from16 v25, v7

    move-object/from16 v23, v15

    move-object/from16 v7, v19

    move-object/from16 v3, v21

    move-object/from16 v24, v22

    move-object/from16 v22, v8

    const-string v5, "9BE4C5B8FBF195CBD4B4D7D194DAFCB4CAE238313C242AA1F4DBB5E2CF"

    invoke-static {v5}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    .line 119
    invoke-direct {v1, v5}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/String;->isEmpty()Z

    move-result v5

    if-nez v5, :cond_814

    const-string v5, "9BE4C5B8FBF195CBD4B4D7D194DAFCB4CAE238313C242AA1F4DBB5E2CF"

    invoke-static {v5}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    goto :goto_81a

    :cond_814
    const-string v5, "1A2D3E34052D011D3922353102"

    invoke-static {v5}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    :goto_81a
    const-string v8, "9BE4C5B8FBF195CBD4B4D7D194E2D4B8F8DC"

    invoke-static {v8}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    .line 120
    invoke-direct {v1, v8}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v8}, Ljava/lang/String;->isEmpty()Z

    move-result v8

    if-nez v8, :cond_831

    const-string v8, "9BE4C5B8FBF195CBD4B4D7D194E2D4B8F8DC"

    invoke-static {v8}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    goto :goto_837

    :cond_831
    const-string v8, "1A2D3E3405301B363F34"

    invoke-static {v8}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    :goto_837
    const-string v9, "9BE4C5B8FBF195CBD4B4D7D19BD1EDB7D4E1"

    invoke-static {v9}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    .line 121
    invoke-direct {v1, v9}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v9}, Ljava/lang/String;->isEmpty()Z

    move-result v9

    if-nez v9, :cond_84e

    const-string v9, "9BE4C5B8FBF195CBD4B4D7D19BD1EDB7D4E1"

    invoke-static {v9}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    goto :goto_854

    :cond_84e
    const-string v9, "1A2D3E340531002E"

    invoke-static {v9}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    :goto_854
    const-string v15, "9BE4C5B8FBF195CBD4B4D7D197D9EDB6D3C3"

    invoke-static {v15}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v15

    .line 122
    invoke-direct {v1, v15}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v15

    invoke-virtual {v15}, Ljava/lang/String;->isEmpty()Z

    move-result v15

    if-nez v15, :cond_86b

    const-string v15, "9BE4C5B8FBF195CBD4B4D7D197D9EDB6D3C3"

    invoke-static {v15}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v15

    goto :goto_871

    :cond_86b
    const-string v15, "1A2D3E3405341B21"

    invoke-static {v15}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v15

    :goto_871
    move-object/from16 v19, v7

    const-string v7, "9BE4C5B8FBF195CBD4B4D7D197CBFCB7FAC39BE0CB"

    invoke-static {v7}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    .line 123
    invoke-direct {v1, v7}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v7}, Ljava/lang/String;->isEmpty()Z

    move-result v7

    if-nez v7, :cond_88a

    const-string v7, "9BE4C5B8FBF195CBD4B4D7D197CBFCB7FAC39BE0CB"

    invoke-static {v7}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    goto :goto_890

    :cond_88a
    const-string v7, "1A2D3E340537072027382E2817"

    invoke-static {v7}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    :goto_890
    move-object/from16 v21, v3

    const-string v3, "9BE4C5B8FBF195CBD4B4D7D19BD1EDB7D4E197C8F3B4D3C995FED3"

    invoke-static {v3}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    .line 124
    invoke-direct {v1, v3}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/String;->isEmpty()Z

    move-result v3

    if-nez v3, :cond_8a9

    const-string v3, "9BE4C5B8FBF195CBD4B4D7D19BD1EDB7D4E197C8F3B4D3C995FED3"

    invoke-static {v3}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    goto :goto_8af

    :cond_8a9
    const-string v3, "1A2D3E3405340027353822"

    invoke-static {v3}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    :goto_8af
    move-object/from16 v27, v9

    const-string v9, "9BE4C5B8FBF195CBD4B4D7D19BD1EDB7D4E197C8F3B4CACA95FED3"

    invoke-static {v9}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    .line 125
    invoke-direct {v1, v9}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v9}, Ljava/lang/String;->isEmpty()Z

    move-result v9

    if-nez v9, :cond_8c8

    const-string v9, "9BE4C5B8FBF195CBD4B4D7D19BD1EDB7D4E197C8F3B4CACA95FED3"

    invoke-static {v9}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    goto :goto_8ce

    :cond_8c8
    const-string v9, "1A2D3E3405370724353822"

    invoke-static {v9}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    :goto_8ce
    move-object/from16 v28, v7

    move-object/from16 v7, v18

    move-object/from16 v18, v15

    .line 126
    invoke-direct {v1, v5, v7}, Lcom/github/catvod/spider/XYQHiker;->ރ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v15

    invoke-virtual {v15, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v7

    if-nez v7, :cond_8ed

    move-object/from16 v7, p4

    invoke-direct {v1, v5, v7}, Lcom/github/catvod/spider/XYQHiker;->ރ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v5, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_8eb

    goto :goto_8ed

    :cond_8eb
    const/4 v5, 0x0

    goto :goto_8ee

    :cond_8ed
    :goto_8ed
    const/4 v5, 0x1

    .line 127
    :goto_8ee
    invoke-static {v4}, Lcom/github/catvod/spider/xbpqxyq/xyq/ٱ;->Ϳ(Ljava/lang/String;)Lcom/github/catvod/spider/xbpqxyq/xyq/ǐ;

    move-result-object v4

    .line 128
    invoke-direct {v1, v6}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    .line 129
    invoke-virtual {v6}, Ljava/lang/String;->isEmpty()Z

    move-result v7

    if-eqz v7, :cond_905

    move/from16 v7, p3

    if-ne v7, v5, :cond_907

    .line 130
    invoke-direct {v1, v3}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    goto :goto_907

    :cond_905
    move/from16 v7, p3

    .line 131
    :cond_907
    :goto_907
    invoke-virtual {v6, v10}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v3
    :try_end_90b
    .catch Ljava/lang/Exception; {:try_start_7b3 .. :try_end_90b} :catch_cbc

    const-string v15, "22050C040808"

    invoke-static {v15}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v15

    if-eqz v3, :cond_91b

    .line 132
    :try_start_913
    invoke-static {v4, v6}, Lcom/github/catvod/spider/XYQHiker;->getTextByRule(Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v3, v15, v2}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object v6

    .line 133
    :cond_91b
    invoke-virtual {v6, v15}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v3

    if-eqz v3, :cond_92f

    .line 134
    invoke-virtual {v6, v15, v2}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object v3

    const-string v6, "55"

    invoke-static {v6}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v3, v6, v11}, Ljava/lang/String;->replaceAll(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    .line 135
    :cond_92f
    invoke-direct {v1, v13}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    .line 136
    invoke-virtual {v3}, Ljava/lang/String;->isEmpty()Z

    move-result v13

    if-eqz v13, :cond_93f

    if-ne v7, v5, :cond_93f

    .line 137
    invoke-direct {v1, v9}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    .line 138
    :cond_93f
    invoke-virtual {v3, v10}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v9

    if-eqz v9, :cond_949

    .line 139
    invoke-static {v4, v3}, Lcom/github/catvod/spider/XYQHiker;->getTextByRule(Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    .line 140
    :cond_949
    invoke-direct {v1, v12}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v9, v10}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v9

    const/4 v12, 0x0

    .line 141
    aget-object v13, v9, v12

    invoke-static {v13, v4}, Lcom/github/catvod/spider/XYQHiker;->getTrueElement(Ljava/lang/String;Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;)Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;

    move-result-object v4

    const/4 v12, 0x1

    .line 142
    :goto_959
    array-length v13, v9

    const/4 v15, 0x1

    sub-int/2addr v13, v15

    if-ge v12, v13, :cond_967

    .line 143
    aget-object v13, v9, v12

    invoke-static {v13, v4}, Lcom/github/catvod/spider/XYQHiker;->getTrueElement(Ljava/lang/String;Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;)Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;

    move-result-object v4

    add-int/lit8 v12, v12, 0x1

    goto :goto_959

    .line 144
    :cond_967
    array-length v12, v9

    const/4 v13, 0x1

    sub-int/2addr v12, v13

    aget-object v9, v9, v12

    invoke-static {v4, v9}, Lcom/github/catvod/spider/XYQHiker;->selectElements(Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;Ljava/lang/String;)Lcom/github/catvod/spider/xbpqxyq/xyq/ำ;

    move-result-object v4

    move-object v12, v11

    move-object v13, v12

    const/4 v9, 0x0

    .line 145
    :goto_973
    invoke-virtual {v4}, Ljava/util/ArrayList;->size()I

    move-result v15
    :try_end_977
    .catch Ljava/lang/Exception; {:try_start_913 .. :try_end_977} :catch_cbc

    if-ge v9, v15, :cond_7eb

    .line 146
    :try_start_979
    invoke-virtual {v4, v9}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v15

    check-cast v15, Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;

    .line 147
    invoke-direct {v1, v14}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v29

    .line 148
    invoke-virtual/range {v29 .. v29}, Ljava/lang/String;->isEmpty()Z

    move-result v30
    :try_end_987
    .catch Ljava/lang/Exception; {:try_start_979 .. :try_end_987} :catch_c50

    if-eqz v30, :cond_98f

    if-ne v7, v5, :cond_98f

    .line 149
    :try_start_98b
    invoke-direct {v1, v8}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v29

    :cond_98f
    move-object/from16 p3, v4

    move-object/from16 v4, v29

    if-eqz v7, :cond_9a8

    .line 150
    invoke-static {v15, v4}, Lcom/github/catvod/spider/XYQHiker;->getTextByRule(Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4
    :try_end_999
    .catch Ljava/lang/Exception; {:try_start_98b .. :try_end_999} :catch_9a2

    move-object/from16 v29, v8

    move-object/from16 p4, v12

    move-object/from16 v31, v13

    :goto_99f
    move-object/from16 v8, v26

    goto :goto_9d0

    :catch_9a2
    move-exception v0

    move-object v2, v0

    move-object/from16 v4, v19

    goto/16 :goto_c54

    :cond_9a8
    move-object/from16 v29, v8

    .line 151
    :try_start_9aa
    invoke-virtual {v15}, Lcom/github/catvod/spider/xbpqxyq/xyq/ւ;->ދ()Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v4, v10}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v30

    move-object/from16 p4, v12

    move-object/from16 v31, v13

    const/4 v12, 0x0

    aget-object v13, v30, v12

    invoke-virtual {v4, v10}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v4

    const/16 v17, 0x1

    aget-object v4, v4, v17

    invoke-static {v8, v13, v4}, Lcom/github/catvod/spider/xbpqxyq/xyq/ވ;->އ(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/util/ArrayList;

    move-result-object v4

    invoke-virtual {v4, v12}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/lang/String;

    invoke-virtual {v1, v4}, Lcom/github/catvod/spider/XYQHiker;->މ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    goto :goto_99f

    .line 152
    :goto_9d0
    invoke-direct {v1, v8}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v12

    .line 153
    invoke-virtual {v12}, Ljava/lang/String;->isEmpty()Z

    move-result v13
    :try_end_9d8
    .catch Ljava/lang/Exception; {:try_start_9aa .. :try_end_9d8} :catch_c50

    if-eqz v13, :cond_9e3

    if-ne v7, v5, :cond_9e3

    move-object/from16 v13, v18

    .line 154
    :try_start_9de
    invoke-direct {v1, v13}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v12
    :try_end_9e2
    .catch Ljava/lang/Exception; {:try_start_9de .. :try_end_9e2} :catch_9a2

    goto :goto_9e5

    :cond_9e3
    move-object/from16 v13, v18

    .line 155
    :goto_9e5
    :try_start_9e5
    invoke-virtual {v12}, Ljava/lang/String;->isEmpty()Z

    move-result v18
    :try_end_9e9
    .catch Ljava/lang/Exception; {:try_start_9e5 .. :try_end_9e9} :catch_c50

    if-nez v18, :cond_ac7

    move-object/from16 v18, v13

    .line 156
    :try_start_9ed
    invoke-direct {v1, v8}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v13
    :try_end_9f1
    .catch Ljava/lang/Exception; {:try_start_9ed .. :try_end_9f1} :catch_ab7

    move-object/from16 v26, v8

    :try_start_9f3
    const-string v8, "1A362721"

    invoke-static {v8}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v13, v8}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v8
    :try_end_9fd
    .catch Ljava/lang/Exception; {:try_start_9f3 .. :try_end_9fd} :catch_ab5

    if-eqz v8, :cond_a05

    move-object/from16 v30, v14

    move-object/from16 v14, p1

    goto/16 :goto_a99

    :cond_a05
    if-eqz v7, :cond_a1f

    .line 157
    :try_start_a07
    invoke-static {v15, v12}, Lcom/github/catvod/spider/XYQHiker;->getTextByRule(Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v8}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v8
    :try_end_a0f
    .catch Ljava/lang/Exception; {:try_start_a07 .. :try_end_a0f} :catch_a13

    move-object v12, v8

    move-object/from16 v30, v14

    goto :goto_a3f

    :catch_a13
    move-exception v0

    move-object/from16 v12, p4

    move-object v13, v0

    move-object/from16 v30, v14

    move/from16 v8, v25

    move-object/from16 v14, p1

    goto/16 :goto_ac3

    .line 158
    :cond_a1f
    :try_start_a1f
    invoke-virtual {v15}, Lcom/github/catvod/spider/xbpqxyq/xyq/ւ;->ދ()Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v12, v10}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v13
    :try_end_a27
    .catch Ljava/lang/Exception; {:try_start_a1f .. :try_end_a27} :catch_ab5

    move-object/from16 v30, v14

    const/4 v14, 0x0

    :try_start_a2a
    aget-object v13, v13, v14

    invoke-virtual {v12, v10}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v12

    const/16 v17, 0x1

    aget-object v12, v12, v17

    invoke-static {v8, v13, v12}, Lcom/github/catvod/spider/xbpqxyq/xyq/ވ;->އ(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/util/ArrayList;

    move-result-object v8

    invoke-virtual {v8, v14}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v8

    check-cast v8, Ljava/lang/String;
    :try_end_a3e
    .catch Ljava/lang/Exception; {:try_start_a2a .. :try_end_a3e} :catch_aaf

    move-object v12, v8

    :goto_a3f
    :try_start_a3f
    const-string v8, "07303F79"

    invoke-static {v8}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    .line 159
    invoke-virtual {v12, v8}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v8
    :try_end_a49
    .catch Ljava/lang/Exception; {:try_start_a3f .. :try_end_a49} :catch_aa9

    if-eqz v8, :cond_a92

    :try_start_a4b
    const-string v8, "2E642224353049"

    invoke-static {v8}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    .line 160
    invoke-virtual {v12, v8, v11}, Ljava/lang/String;->replaceAll(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    const-string v13, "07303F0D72"

    invoke-static {v13}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v13

    invoke-virtual {v8, v13}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v8

    .line 161
    array-length v13, v8

    const/4 v14, 0x1

    if-le v13, v14, :cond_a92

    aget-object v13, v8, v14
    :try_end_a65
    .catch Ljava/lang/Exception; {:try_start_a4b .. :try_end_a65} :catch_a8b

    move-object/from16 v14, p1

    :try_start_a67
    invoke-virtual {v13, v14}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v13

    if-eqz v13, :cond_a94

    const/4 v13, 0x1

    .line 162
    aget-object v8, v8, v13

    const-string v13, "2E6B"

    invoke-static {v13}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v13

    invoke-virtual {v8, v13}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v8

    const/4 v13, 0x0

    aget-object v8, v8, v13

    const-string v13, "2965710C"

    invoke-static {v13}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v13

    invoke-virtual {v8, v13, v11}, Ljava/lang/String;->replaceAll(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8
    :try_end_a87
    .catch Ljava/lang/Exception; {:try_start_a67 .. :try_end_a87} :catch_a89

    move-object v12, v8

    goto :goto_a94

    :catch_a89
    move-exception v0

    goto :goto_a8e

    :catch_a8b
    move-exception v0

    move-object/from16 v14, p1

    :goto_a8e
    move-object v13, v0

    move/from16 v8, v25

    goto :goto_ac3

    :cond_a92
    move-object/from16 v14, p1

    .line 163
    :cond_a94
    :goto_a94
    :try_start_a94
    invoke-static {v2, v12}, Lcom/github/catvod/spider/xbpqxyq/xyq/ވ;->Ԫ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8
    :try_end_a98
    .catch Ljava/lang/Exception; {:try_start_a94 .. :try_end_a98} :catch_aa7

    move-object v12, v8

    :goto_a99
    if-eqz v25, :cond_aa4

    move/from16 v8, v25

    .line 164
    :try_start_a9d
    invoke-virtual {v1, v12, v2, v8}, Lcom/github/catvod/spider/XYQHiker;->ԯ(Ljava/lang/String;Ljava/lang/String;Z)Ljava/lang/String;

    move-result-object v12
    :try_end_aa1
    .catch Ljava/lang/Exception; {:try_start_a9d .. :try_end_aa1} :catch_aa2

    goto :goto_ad3

    :catch_aa2
    move-exception v0

    goto :goto_ac2

    :cond_aa4
    move/from16 v8, v25

    goto :goto_ad3

    :catch_aa7
    move-exception v0

    goto :goto_aac

    :catch_aa9
    move-exception v0

    move-object/from16 v14, p1

    :goto_aac
    move/from16 v8, v25

    goto :goto_ac2

    :catch_aaf
    move-exception v0

    move-object/from16 v14, p1

    move/from16 v8, v25

    goto :goto_ac0

    :catch_ab5
    move-exception v0

    goto :goto_aba

    :catch_ab7
    move-exception v0

    move-object/from16 v26, v8

    :goto_aba
    move-object/from16 v30, v14

    move/from16 v8, v25

    move-object/from16 v14, p1

    :goto_ac0
    move-object/from16 v12, p4

    :goto_ac2
    move-object v13, v0

    .line 165
    :goto_ac3
    :try_start_ac3
    invoke-static {v13}, Lcom/github/catvod/crawler/SpiderDebug;->log(Ljava/lang/Throwable;)V
    :try_end_ac6
    .catch Ljava/lang/Exception; {:try_start_ac3 .. :try_end_ac6} :catch_9a2

    goto :goto_ad3

    :cond_ac7
    move-object/from16 v26, v8

    move-object/from16 v18, v13

    move-object/from16 v30, v14

    move/from16 v8, v25

    move-object/from16 v14, p1

    move-object/from16 v12, p4

    :goto_ad3
    move-object/from16 v13, v24

    .line 166
    :try_start_ad5
    invoke-direct {v1, v13}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v24

    .line 167
    invoke-virtual/range {v24 .. v24}, Ljava/lang/String;->isEmpty()Z

    move-result v25
    :try_end_add
    .catch Ljava/lang/Exception; {:try_start_ad5 .. :try_end_add} :catch_c50

    if-eqz v25, :cond_aea

    if-ne v7, v5, :cond_aea

    move-object/from16 p1, v2

    move-object/from16 v2, v28

    .line 168
    :try_start_ae5
    invoke-direct {v1, v2}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v24
    :try_end_ae9
    .catch Ljava/lang/Exception; {:try_start_ae5 .. :try_end_ae9} :catch_9a2

    goto :goto_aee

    :cond_aea
    move-object/from16 p1, v2

    move-object/from16 v2, v28

    :goto_aee
    move-object/from16 p4, v24

    .line 169
    :try_start_af0
    invoke-virtual/range {p4 .. p4}, Ljava/lang/String;->isEmpty()Z

    move-result v24
    :try_end_af4
    .catch Ljava/lang/Exception; {:try_start_af0 .. :try_end_af4} :catch_c50

    if-nez v24, :cond_b4c

    if-eqz v7, :cond_b11

    move-object/from16 v28, v2

    move-object/from16 v2, p4

    .line 170
    :try_start_afc
    invoke-static {v15, v2}, Lcom/github/catvod/spider/XYQHiker;->getTextByRule(Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2
    :try_end_b00
    .catch Ljava/lang/Exception; {:try_start_afc .. :try_end_b00} :catch_b08

    move/from16 v25, v8

    move-object/from16 p4, v11

    move-object/from16 v32, v13

    :goto_b06
    move-object v13, v2

    goto :goto_b3d

    :catch_b08
    move-exception v0

    move-object v2, v0

    move/from16 v25, v8

    move-object/from16 p4, v11

    move-object/from16 v32, v13

    goto :goto_b48

    :cond_b11
    move-object/from16 v28, v2

    move/from16 v25, v8

    move-object/from16 v2, p4

    .line 171
    :try_start_b17
    invoke-virtual {v15}, Lcom/github/catvod/spider/xbpqxyq/xyq/ւ;->ދ()Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v2, v10}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v24
    :try_end_b1f
    .catch Ljava/lang/Exception; {:try_start_b17 .. :try_end_b1f} :catch_b42

    move-object/from16 p4, v11

    move-object/from16 v32, v13

    const/4 v11, 0x0

    :try_start_b24
    aget-object v13, v24, v11

    invoke-virtual {v2, v10}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v2

    const/16 v17, 0x1

    aget-object v2, v2, v17

    invoke-static {v8, v13, v2}, Lcom/github/catvod/spider/xbpqxyq/xyq/ވ;->އ(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2, v11}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/String;

    invoke-virtual {v1, v2}, Lcom/github/catvod/spider/XYQHiker;->މ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2
    :try_end_b3c
    .catch Ljava/lang/Exception; {:try_start_b24 .. :try_end_b3c} :catch_b40

    goto :goto_b06

    :goto_b3d
    move-object/from16 v2, v23

    goto :goto_b58

    :catch_b40
    move-exception v0

    goto :goto_b47

    :catch_b42
    move-exception v0

    move-object/from16 p4, v11

    move-object/from16 v32, v13

    :goto_b47
    move-object v2, v0

    .line 172
    :goto_b48
    :try_start_b48
    invoke-static {v2}, Lcom/github/catvod/crawler/SpiderDebug;->log(Ljava/lang/Throwable;)V
    :try_end_b4b
    .catch Ljava/lang/Exception; {:try_start_b48 .. :try_end_b4b} :catch_9a2

    goto :goto_b54

    :cond_b4c
    move-object/from16 v28, v2

    move/from16 v25, v8

    move-object/from16 p4, v11

    move-object/from16 v32, v13

    :goto_b54
    move-object/from16 v2, v23

    move-object/from16 v13, v31

    .line 173
    :goto_b58
    :try_start_b58
    invoke-direct {v1, v2}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    .line 174
    invoke-virtual {v8}, Ljava/lang/String;->isEmpty()Z

    move-result v11
    :try_end_b60
    .catch Ljava/lang/Exception; {:try_start_b58 .. :try_end_b60} :catch_c50

    if-eqz v11, :cond_b6b

    if-ne v7, v5, :cond_b6b

    move-object/from16 v11, v27

    .line 175
    :try_start_b66
    invoke-direct {v1, v11}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8
    :try_end_b6a
    .catch Ljava/lang/Exception; {:try_start_b66 .. :try_end_b6a} :catch_9a2

    goto :goto_b6d

    :cond_b6b
    move-object/from16 v11, v27

    :goto_b6d
    move-object/from16 v23, v2

    const-string v2, "2E19B5CAE5A2FFE069"

    invoke-static {v2}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    if-eqz v7, :cond_b89

    .line 176
    :try_start_b77
    invoke-virtual {v8, v2}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v2

    const/16 v24, 0x0

    aget-object v2, v2, v24

    invoke-static {v15, v2}, Lcom/github/catvod/spider/XYQHiker;->getTextByRule(Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2
    :try_end_b83
    .catch Ljava/lang/Exception; {:try_start_b77 .. :try_end_b83} :catch_9a2

    move/from16 v27, v5

    move/from16 v31, v7

    const/4 v5, 0x0

    goto :goto_bb6

    .line 177
    :cond_b89
    :try_start_b89
    invoke-virtual {v15}, Lcom/github/catvod/spider/xbpqxyq/xyq/ւ;->ދ()Ljava/lang/String;

    move-result-object v15

    invoke-virtual {v8, v2}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v24

    move/from16 v27, v5

    move/from16 v31, v7

    const/4 v5, 0x0

    aget-object v7, v24, v5

    invoke-virtual {v7, v10}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v7

    aget-object v7, v7, v5

    invoke-virtual {v8, v2}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v2

    aget-object v2, v2, v5

    invoke-virtual {v2, v10}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v2

    const/16 v17, 0x1

    aget-object v2, v2, v17

    invoke-static {v15, v7, v2}, Lcom/github/catvod/spider/xbpqxyq/xyq/ވ;->އ(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2, v5}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/String;

    :goto_bb6
    const-string v7, "29A4C8EEBCC9D0"

    invoke-static {v7}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    .line 178
    invoke-virtual {v8, v7}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v7
    :try_end_bc0
    .catch Ljava/lang/Exception; {:try_start_b89 .. :try_end_bc0} :catch_c50

    if-eqz v7, :cond_bc6

    .line 179
    :try_start_bc2
    invoke-static {v2, v8}, Lcom/github/catvod/spider/xbpqxyq/xyq/ވ;->ރ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2
    :try_end_bc6
    .catch Ljava/lang/Exception; {:try_start_bc2 .. :try_end_bc6} :catch_9a2

    .line 180
    :cond_bc6
    :try_start_bc6
    new-instance v7, Ljava/lang/StringBuilder;

    invoke-direct {v7}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v7, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v7, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v7, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v7

    move-object/from16 v8, v22

    .line 181
    invoke-virtual {v7, v8}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v15
    :try_end_bde
    .catch Ljava/lang/Exception; {:try_start_bc6 .. :try_end_bde} :catch_c50

    if-eqz v15, :cond_be4

    .line 182
    :try_start_be0
    invoke-virtual {v7, v8, v2}, Ljava/lang/String;->replaceAll(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7
    :try_end_be4
    .catch Ljava/lang/Exception; {:try_start_be0 .. :try_end_be4} :catch_9a2

    .line 183
    :cond_be4
    :try_start_be4
    new-instance v2, Lorg/json/JSONObject;

    invoke-direct {v2}, Lorg/json/JSONObject;-><init>()V

    const-string v15, "042D370E3320"

    invoke-static {v15}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v15

    .line 184
    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v5, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-object/from16 v22, v3

    move-object/from16 v3, v21

    invoke-virtual {v5, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v2, v15, v5}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const-string v5, "042D370E34251F27"

    invoke-static {v5}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    .line 185
    invoke-virtual {v2, v5, v4}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const-string v4, "042D370E2A2D11"

    invoke-static {v4}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    .line 186
    invoke-virtual {v2, v4, v12}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const-string v4, "042D370E28211F23213A29"

    invoke-static {v4}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    .line 187
    invoke-virtual {v2, v4, v13}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    :try_end_c29
    .catch Ljava/lang/Exception; {:try_start_be4 .. :try_end_c29} :catch_c50

    move-object/from16 v4, v19

    .line 188
    :try_start_c2b
    invoke-virtual {v4, v2}, Lorg/json/JSONArray;->put(Ljava/lang/Object;)Lorg/json/JSONArray;
    :try_end_c2e
    .catch Ljava/lang/Exception; {:try_start_c2b .. :try_end_c2e} :catch_c4e

    add-int/lit8 v9, v9, 0x1

    move-object/from16 v2, p1

    move-object/from16 v21, v3

    move-object/from16 v19, v4

    move-object/from16 p1, v14

    move-object/from16 v3, v22

    move/from16 v5, v27

    move-object/from16 v14, v30

    move/from16 v7, v31

    move-object/from16 v24, v32

    move-object/from16 v4, p3

    move-object/from16 v22, v8

    move-object/from16 v27, v11

    move-object/from16 v8, v29

    move-object/from16 v11, p4

    goto/16 :goto_973

    :catch_c4e
    move-exception v0

    goto :goto_c53

    :catch_c50
    move-exception v0

    move-object/from16 v4, v19

    :goto_c53
    move-object v2, v0

    .line 189
    :goto_c54
    :try_start_c54
    invoke-static {v2}, Lcom/github/catvod/crawler/SpiderDebug;->log(Ljava/lang/Throwable;)V

    .line 190
    iget-boolean v3, v1, Lcom/github/catvod/spider/XYQHiker;->ވ:Z

    if-eqz v3, :cond_c77

    .line 191
    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v5, "97CAD5B6EBFF9AE5F0B7C4D41A363E3DBFC3C8ABC7C8B5F8E8"

    invoke-static {v5}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/Exception;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Lcom/github/catvod/spider/Init;->show(Ljava/lang/String;)V

    :cond_c77
    :goto_c77
    const-string v2, "02233434"

    invoke-static {v2}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    move-object/from16 v3, v16

    move-object/from16 v5, v20

    .line 192
    invoke-virtual {v5, v2, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const-string v2, "02233434392B072C27"

    invoke-static {v2}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    const v3, 0x7fffffff

    .line 193
    invoke-virtual {v5, v2, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    const-string v2, "1E2B3E382E"

    invoke-static {v2}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    .line 194
    invoke-virtual {v4}, Lorg/json/JSONArray;->length()I

    move-result v3

    invoke-virtual {v5, v2, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    const-string v2, "062D273036"

    invoke-static {v2}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    const v3, 0x7fffffff

    .line 195
    invoke-virtual {v5, v2, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    const-string v2, "1E2B2025"

    invoke-static {v2}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    .line 196
    invoke-virtual {v5, v2, v4}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 197
    invoke-virtual {v4}, Lorg/json/JSONArray;->length()I

    move-result v2
    :try_end_cb6
    .catch Ljava/lang/Exception; {:try_start_c54 .. :try_end_cb6} :catch_cbc

    const/4 v3, 0x1

    if-ge v2, v3, :cond_cbb

    const/4 v2, 0x0

    return-object v2

    :cond_cbb
    return-object v5

    :catch_cbc
    move-exception v0

    move-object v2, v0

    .line 198
    invoke-static {v2}, Lcom/github/catvod/crawler/SpiderDebug;->log(Ljava/lang/Throwable;)V

    .line 199
    iget-boolean v3, v1, Lcom/github/catvod/spider/XYQHiker;->ވ:Z

    if-eqz v3, :cond_ce1

    .line 200
    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, "97CAD5B6EBFF95FFC2B8FBF197C7FBB4EBC497C5E9B8CEDD9DFEC9"

    invoke-static {v4}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/Exception;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Lcom/github/catvod/spider/Init;->show(Ljava/lang/String;)V

    :cond_ce1
    const/4 v2, 0x0

    return-object v2
.end method

.method private static ԩ(Ljava/lang/String;)Ljava/lang/String;
    .registers 5

    const-string v0, "5A1E0F2472180539672C736D"

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 1
    invoke-static {v0}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    move-result-object v0

    .line 2
    invoke-virtual {v0, p0}, Ljava/util/regex/Pattern;->matcher(Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;

    move-result-object v0

    .line 3
    :goto_e
    invoke-virtual {v0}, Ljava/util/regex/Matcher;->find()Z

    move-result v1

    if-eqz v1, :cond_3b

    const/4 v1, 0x1

    .line 4
    invoke-virtual {v0, v1}, Ljava/util/regex/Matcher;->group(I)Ljava/lang/String;

    move-result-object v1

    const/4 v2, 0x2

    .line 5
    invoke-virtual {v0, v2}, Ljava/util/regex/Matcher;->group(I)Ljava/lang/String;

    move-result-object v2

    const/16 v3, 0x10

    .line 6
    invoke-static {v2, v3}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;I)I

    move-result v2

    int-to-char v2, v2

    .line 7
    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const-string v2, ""

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {p0, v1, v2}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object p0

    goto :goto_e

    :cond_3b
    return-object p0
.end method

.method private Ԫ(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lorg/json/JSONObject;
    .registers 34

    move-object/from16 v1, p0

    move-object/from16 v2, p2

    move-object/from16 v3, p3

    move-object/from16 v4, p5

    move-object/from16 v5, p7

    move-object/from16 v6, p9

    move-object/from16 v7, p11

    move-object/from16 v8, p13

    const-string v0, "54"

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 1
    :try_start_16
    new-instance v9, Lorg/json/JSONArray;

    invoke-direct {v9}, Lorg/json/JSONArray;-><init>()V

    .line 2
    new-instance v10, Lorg/json/JSONObject;

    invoke-direct {v10}, Lorg/json/JSONObject;-><init>()V

    move-object/from16 v11, p1

    .line 3
    invoke-virtual {v11, v0}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v11

    .line 4
    new-instance v12, Ljava/util/ArrayList;

    invoke-direct {v12}, Ljava/util/ArrayList;-><init>()V

    .line 5
    array-length v13, v11

    const/4 v15, 0x0

    :goto_2d
    if-ge v15, v13, :cond_45

    aget-object v14, v11, v15

    move-object/from16 v16, v9

    const-string v9, "9DFED5BEE6C2"

    invoke-static {v9}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    .line 6
    invoke-virtual {v14, v9, v0}, Ljava/lang/String;->replaceAll(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v12, v9}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/lit8 v15, v15, 0x1

    move-object/from16 v9, v16

    goto :goto_2d

    :cond_45
    move-object/from16 v16, v9

    move-object/from16 v9, p4

    move-object/from16 v11, p6

    move-object/from16 v13, p8

    move-object/from16 v14, p10

    move-object/from16 v15, p12

    move-object/from16 p1, p14

    const/4 v8, 0x0

    move-object/from16 v18, v16

    move-object/from16 v16, v10

    move-object/from16 v10, v18

    .line 7
    :goto_5a
    invoke-virtual {v12}, Ljava/util/ArrayList;->size()I

    move-result v0
    :try_end_5e
    .catch Ljava/lang/Exception; {:try_start_16 .. :try_end_5e} :catch_4a8

    if-ge v8, v0, :cond_4a5

    .line 8
    :try_start_60
    invoke-virtual/range {p3 .. p3}, Ljava/lang/String;->isEmpty()Z

    move-result v0
    :try_end_64
    .catch Ljava/lang/Exception; {:try_start_60 .. :try_end_64} :catch_454

    move-object/from16 v17, v12

    const-string v12, "95EBE9"

    invoke-static {v12}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v12

    const-string v7, "58"

    invoke-static {v7}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    move-object/from16 p4, v15

    const-string v15, "2E3E0F2D"

    invoke-static {v15}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v15

    const-string v6, "0E3E"

    invoke-static {v6}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    if-nez v0, :cond_fc

    :try_start_82
    invoke-virtual {v9}, Ljava/lang/String;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_fc

    const-string v0, "092132253F0D163F"

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v2, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    if-eqz v0, :cond_fc

    .line 9
    invoke-virtual {v9, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_9b

    move-object v9, v3

    .line 10
    :cond_9b
    invoke-virtual {v9, v6}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0
    :try_end_9f
    .catch Ljava/lang/Exception; {:try_start_82 .. :try_end_9f} :catch_e8

    move-object/from16 p6, v14

    const-string v14, "97CAD5B6EBFF"

    invoke-static {v14}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v14

    const-string v5, "112327341320"

    invoke-static {v5}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    if-eqz v0, :cond_dc

    :try_start_af
    invoke-virtual {v3, v6}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    if-eqz v0, :cond_dc

    .line 11
    invoke-virtual {v3, v15}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v0
    :try_end_b9
    .catch Ljava/lang/Exception; {:try_start_af .. :try_end_b9} :catch_d8

    move-object/from16 p8, v13

    .line 12
    :try_start_bb
    invoke-virtual {v9, v15}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v13

    move-object/from16 p10, v15

    .line 13
    array-length v15, v13

    if-ge v8, v15, :cond_102

    aget-object v15, v13, v8

    invoke-virtual {v15, v12}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v15

    if-nez v15, :cond_102

    .line 14
    aget-object v0, v0, v8

    aget-object v13, v13, v8

    invoke-direct {v1, v5, v14, v0, v13}, Lcom/github/catvod/spider/XYQHiker;->ށ(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v0

    invoke-virtual {v10, v0}, Lorg/json/JSONArray;->put(Ljava/lang/Object;)Lorg/json/JSONArray;

    goto :goto_102

    :catch_d8
    move-exception v0

    move-object/from16 p8, v13

    goto :goto_ed

    :cond_dc
    move-object/from16 p8, v13

    move-object/from16 p10, v15

    .line 15
    invoke-direct {v1, v5, v14, v3, v9}, Lcom/github/catvod/spider/XYQHiker;->ށ(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v0

    invoke-virtual {v10, v0}, Lorg/json/JSONArray;->put(Ljava/lang/Object;)Lorg/json/JSONArray;
    :try_end_e7
    .catch Ljava/lang/Exception; {:try_start_bb .. :try_end_e7} :catch_164

    goto :goto_102

    :catch_e8
    move-exception v0

    move-object/from16 p8, v13

    move-object/from16 p6, v14

    :goto_ed
    move-object/from16 v6, p1

    move-object/from16 v5, p4

    move-object/from16 v4, p6

    move-object/from16 v15, p7

    move-object/from16 v3, p8

    :goto_f7
    move-object/from16 v7, p11

    :goto_f9
    move v13, v8

    goto/16 :goto_44d

    :cond_fc
    move-object/from16 p8, v13

    move-object/from16 p6, v14

    move-object/from16 p10, v15

    .line 16
    :cond_102
    :goto_102
    :try_start_102
    invoke-virtual/range {p5 .. p5}, Ljava/lang/String;->isEmpty()Z

    move-result v0
    :try_end_106
    .catch Ljava/lang/Exception; {:try_start_102 .. :try_end_106} :catch_43d

    if-nez v0, :cond_166

    :try_start_108
    invoke-virtual {v11}, Ljava/lang/String;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_166

    const-string v0, "09213F3029370F"

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v2, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    if-eqz v0, :cond_166

    .line 17
    invoke-virtual {v11, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_121

    move-object v11, v4

    .line 18
    :cond_121
    invoke-virtual {v11, v6}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0
    :try_end_125
    .catch Ljava/lang/Exception; {:try_start_108 .. :try_end_125} :catch_164

    const-string v5, "95F3E8B4C4CF"

    invoke-static {v5}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    const-string v13, "112E322229"

    invoke-static {v13}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v13

    if-eqz v0, :cond_15a

    :try_start_133
    invoke-virtual {v4, v6}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    if-eqz v0, :cond_15a

    move-object/from16 v0, p10

    .line 19
    invoke-virtual {v4, v0}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v14

    .line 20
    invoke-virtual {v11, v0}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v15

    .line 21
    array-length v3, v15

    if-ge v8, v3, :cond_168

    aget-object v3, v15, v8

    invoke-virtual {v3, v12}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_168

    .line 22
    aget-object v3, v14, v8

    aget-object v14, v15, v8

    invoke-direct {v1, v13, v5, v3, v14}, Lcom/github/catvod/spider/XYQHiker;->ށ(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v3

    invoke-virtual {v10, v3}, Lorg/json/JSONArray;->put(Ljava/lang/Object;)Lorg/json/JSONArray;

    goto :goto_168

    :cond_15a
    move-object/from16 v0, p10

    .line 23
    invoke-direct {v1, v13, v5, v4, v11}, Lcom/github/catvod/spider/XYQHiker;->ށ(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v3

    invoke-virtual {v10, v3}, Lorg/json/JSONArray;->put(Ljava/lang/Object;)Lorg/json/JSONArray;
    :try_end_163
    .catch Ljava/lang/Exception; {:try_start_133 .. :try_end_163} :catch_164

    goto :goto_168

    :catch_164
    move-exception v0

    goto :goto_ed

    :cond_166
    move-object/from16 v0, p10

    .line 24
    :cond_168
    :goto_168
    :try_start_168
    invoke-virtual/range {p7 .. p7}, Ljava/lang/String;->isEmpty()Z

    move-result v3
    :try_end_16c
    .catch Ljava/lang/Exception; {:try_start_168 .. :try_end_16c} :catch_42a

    if-nez v3, :cond_205

    :try_start_16e
    invoke-virtual/range {p8 .. p8}, Ljava/lang/String;->isEmpty()Z

    move-result v3

    if-nez v3, :cond_205

    const-string v3, "092321343B39"

    invoke-static {v3}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v3
    :try_end_17e
    .catch Ljava/lang/Exception; {:try_start_16e .. :try_end_17e} :catch_1f6

    if-eqz v3, :cond_205

    move-object/from16 v3, p8

    .line 25
    :try_start_182
    invoke-virtual {v3, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5
    :try_end_186
    .catch Ljava/lang/Exception; {:try_start_182 .. :try_end_186} :catch_1f2

    if-eqz v5, :cond_18b

    move-object/from16 v13, p7

    goto :goto_18c

    :cond_18b
    move-object v13, v3

    .line 26
    :goto_18c
    :try_start_18c
    invoke-virtual {v13, v6}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v3
    :try_end_190
    .catch Ljava/lang/Exception; {:try_start_18c .. :try_end_190} :catch_1dd

    const-string v5, "97DEE3B4D6FE"

    invoke-static {v5}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    const-string v14, "13303630"

    invoke-static {v14}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v14

    move-object/from16 v15, p7

    if-eqz v3, :cond_1c9

    :try_start_1a0
    invoke-virtual {v15, v6}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v3

    if-eqz v3, :cond_1c9

    .line 27
    invoke-virtual {v15, v0}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v3

    .line 28
    invoke-virtual {v13, v0}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v4
    :try_end_1ae
    .catch Ljava/lang/Exception; {:try_start_1a0 .. :try_end_1ae} :catch_1c7

    move-object/from16 p8, v9

    .line 29
    :try_start_1b0
    array-length v9, v4

    if-ge v8, v9, :cond_20c

    aget-object v9, v4, v8

    invoke-virtual {v9, v12}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v9

    if-nez v9, :cond_20c

    .line 30
    aget-object v3, v3, v8

    aget-object v4, v4, v8

    invoke-direct {v1, v14, v5, v3, v4}, Lcom/github/catvod/spider/XYQHiker;->ށ(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v3

    invoke-virtual {v10, v3}, Lorg/json/JSONArray;->put(Ljava/lang/Object;)Lorg/json/JSONArray;

    goto :goto_20c

    :catch_1c7
    move-exception v0

    goto :goto_1e0

    :cond_1c9
    move-object/from16 p8, v9

    .line 31
    invoke-direct {v1, v14, v5, v15, v13}, Lcom/github/catvod/spider/XYQHiker;->ށ(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v3

    invoke-virtual {v10, v3}, Lorg/json/JSONArray;->put(Ljava/lang/Object;)Lorg/json/JSONArray;
    :try_end_1d2
    .catch Ljava/lang/Exception; {:try_start_1b0 .. :try_end_1d2} :catch_1d3

    goto :goto_20c

    :catch_1d3
    move-exception v0

    move-object/from16 v6, p1

    move-object/from16 v5, p4

    move-object/from16 v4, p6

    move-object/from16 v9, p8

    goto :goto_1e8

    :catch_1dd
    move-exception v0

    move-object/from16 v15, p7

    :goto_1e0
    move-object/from16 p8, v9

    move-object/from16 v6, p1

    move-object/from16 v5, p4

    move-object/from16 v4, p6

    :goto_1e8
    move-object/from16 v7, p11

    move-object v3, v13

    move-object/from16 v14, v16

    move-object/from16 v12, v17

    move v13, v8

    goto/16 :goto_451

    :catch_1f2
    move-exception v0

    move-object/from16 v15, p7

    goto :goto_1fb

    :catch_1f6
    move-exception v0

    move-object/from16 v15, p7

    move-object/from16 v3, p8

    :goto_1fb
    move-object/from16 p8, v9

    move-object/from16 v6, p1

    move-object/from16 v5, p4

    move-object/from16 v4, p6

    goto/16 :goto_f7

    :cond_205
    move-object/from16 v15, p7

    move-object/from16 v3, p8

    move-object/from16 p8, v9

    move-object v13, v3

    .line 32
    :cond_20c
    :goto_20c
    :try_start_20c
    invoke-virtual/range {p9 .. p9}, Ljava/lang/String;->isEmpty()Z

    move-result v3
    :try_end_210
    .catch Ljava/lang/Exception; {:try_start_20c .. :try_end_210} :catch_411

    if-nez v3, :cond_2bb

    :try_start_212
    invoke-virtual/range {p6 .. p6}, Ljava/lang/String;->isEmpty()Z

    move-result v3

    if-nez v3, :cond_2bb

    const-string v3, "093B36302839"

    invoke-static {v3}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v3
    :try_end_222
    .catch Ljava/lang/Exception; {:try_start_212 .. :try_end_222} :catch_2a8

    if-eqz v3, :cond_2bb

    move-object/from16 v4, p6

    .line 33
    :try_start_226
    invoke-virtual {v4, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3
    :try_end_22a
    .catch Ljava/lang/Exception; {:try_start_226 .. :try_end_22a} :catch_2a6

    if-eqz v3, :cond_22f

    move-object/from16 v14, p9

    goto :goto_230

    :cond_22f
    move-object v14, v4

    .line 34
    :goto_230
    :try_start_230
    invoke-virtual {v14, v6}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v3
    :try_end_234
    .catch Ljava/lang/Exception; {:try_start_230 .. :try_end_234} :catch_291

    const-string v4, "97FBE7B5E1F9"

    invoke-static {v4}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    const-string v5, "0B273223"

    invoke-static {v5}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    if-eqz v3, :cond_27a

    move-object v3, v6

    move-object/from16 v6, p9

    :try_start_245
    invoke-virtual {v6, v3}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v9

    if-eqz v9, :cond_273

    .line 35
    invoke-virtual {v6, v0}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v9
    :try_end_24f
    .catch Ljava/lang/Exception; {:try_start_245 .. :try_end_24f} :catch_278

    move-object/from16 p6, v11

    .line 36
    :try_start_251
    invoke-virtual {v14, v0}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v11
    :try_end_255
    .catch Ljava/lang/Exception; {:try_start_251 .. :try_end_255} :catch_26f

    move-object/from16 p10, v13

    .line 37
    :try_start_257
    array-length v13, v11

    if-ge v8, v13, :cond_2c5

    aget-object v13, v11, v8

    invoke-virtual {v13, v12}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v13

    if-nez v13, :cond_2c5

    .line 38
    aget-object v9, v9, v8

    aget-object v11, v11, v8

    invoke-direct {v1, v5, v4, v9, v11}, Lcom/github/catvod/spider/XYQHiker;->ށ(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v4

    invoke-virtual {v10, v4}, Lorg/json/JSONArray;->put(Ljava/lang/Object;)Lorg/json/JSONArray;

    goto/16 :goto_2c5

    :catch_26f
    move-exception v0

    move-object/from16 p10, v13

    goto :goto_28a

    :cond_273
    move-object/from16 p6, v11

    move-object/from16 p10, v13

    goto :goto_281

    :catch_278
    move-exception v0

    goto :goto_294

    :cond_27a
    move-object v3, v6

    move-object/from16 p6, v11

    move-object/from16 p10, v13

    move-object/from16 v6, p9

    .line 39
    :goto_281
    invoke-direct {v1, v5, v4, v6, v14}, Lcom/github/catvod/spider/XYQHiker;->ށ(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v4

    invoke-virtual {v10, v4}, Lorg/json/JSONArray;->put(Ljava/lang/Object;)Lorg/json/JSONArray;
    :try_end_288
    .catch Ljava/lang/Exception; {:try_start_257 .. :try_end_288} :catch_289

    goto :goto_2c5

    :catch_289
    move-exception v0

    :goto_28a
    move-object/from16 v6, p1

    move-object/from16 v5, p4

    move-object/from16 v11, p6

    goto :goto_29c

    :catch_291
    move-exception v0

    move-object/from16 v6, p9

    :goto_294
    move-object/from16 p6, v11

    move-object/from16 p10, v13

    move-object/from16 v6, p1

    move-object/from16 v5, p4

    :goto_29c
    move-object/from16 v9, p8

    move-object/from16 v3, p10

    move-object/from16 v7, p11

    move v13, v8

    move-object v4, v14

    goto/16 :goto_44d

    :catch_2a6
    move-exception v0

    goto :goto_2ab

    :catch_2a8
    move-exception v0

    move-object/from16 v4, p6

    :goto_2ab
    move-object/from16 v6, p9

    move-object/from16 p6, v11

    move-object/from16 p10, v13

    move-object/from16 v6, p1

    move-object/from16 v5, p4

    move-object/from16 v9, p8

    move-object/from16 v3, p10

    goto/16 :goto_f7

    :cond_2bb
    move-object/from16 v4, p6

    move-object v3, v6

    move-object/from16 p6, v11

    move-object/from16 p10, v13

    move-object/from16 v6, p9

    move-object v14, v4

    .line 40
    :cond_2c5
    :goto_2c5
    :try_start_2c5
    invoke-virtual/range {p11 .. p11}, Ljava/lang/String;->isEmpty()Z

    move-result v4
    :try_end_2c9
    .catch Ljava/lang/Exception; {:try_start_2c5 .. :try_end_2c9} :catch_3fc

    if-nez v4, :cond_34c

    :try_start_2cb
    invoke-virtual/range {p4 .. p4}, Ljava/lang/String;->isEmpty()Z

    move-result v4

    if-nez v4, :cond_34c

    const-string v4, "092E323F3D39"

    invoke-static {v4}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v2, v4}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v4
    :try_end_2db
    .catch Ljava/lang/Exception; {:try_start_2cb .. :try_end_2db} :catch_339

    if-eqz v4, :cond_34c

    move-object/from16 v5, p4

    .line 41
    :try_start_2df
    invoke-virtual {v5, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_2e7

    move-object/from16 v5, p11

    .line 42
    :cond_2e7
    invoke-virtual {v5, v3}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v4
    :try_end_2eb
    .catch Ljava/lang/Exception; {:try_start_2df .. :try_end_2eb} :catch_337

    const-string v9, "9AEDFEB9F2C4"

    invoke-static {v9}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    const-string v11, "1E233D36"

    invoke-static {v11}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v11

    if-eqz v4, :cond_328

    move-object v4, v7

    move-object/from16 v7, p11

    :try_start_2fc
    invoke-virtual {v7, v3}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v13

    if-eqz v13, :cond_323

    .line 43
    invoke-virtual {v7, v0}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v13

    .line 44
    invoke-virtual {v5, v0}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v6
    :try_end_30a
    .catch Ljava/lang/Exception; {:try_start_2fc .. :try_end_30a} :catch_326

    move-object/from16 p4, v14

    .line 45
    :try_start_30c
    array-length v14, v6

    if-ge v8, v14, :cond_353

    aget-object v14, v6, v8

    invoke-virtual {v14, v12}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v14

    if-nez v14, :cond_353

    .line 46
    aget-object v13, v13, v8

    aget-object v6, v6, v8

    invoke-direct {v1, v11, v9, v13, v6}, Lcom/github/catvod/spider/XYQHiker;->ށ(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v6

    invoke-virtual {v10, v6}, Lorg/json/JSONArray;->put(Ljava/lang/Object;)Lorg/json/JSONArray;

    goto :goto_353

    :cond_323
    move-object/from16 p4, v14

    goto :goto_32d

    :catch_326
    move-exception v0

    goto :goto_33e

    :cond_328
    move-object v4, v7

    move-object/from16 p4, v14

    move-object/from16 v7, p11

    .line 47
    :goto_32d
    invoke-direct {v1, v11, v9, v7, v5}, Lcom/github/catvod/spider/XYQHiker;->ށ(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v6

    invoke-virtual {v10, v6}, Lorg/json/JSONArray;->put(Ljava/lang/Object;)Lorg/json/JSONArray;
    :try_end_334
    .catch Ljava/lang/Exception; {:try_start_30c .. :try_end_334} :catch_335

    goto :goto_353

    :catch_335
    move-exception v0

    goto :goto_340

    :catch_337
    move-exception v0

    goto :goto_33c

    :catch_339
    move-exception v0

    move-object/from16 v5, p4

    :goto_33c
    move-object/from16 v7, p11

    :goto_33e
    move-object/from16 p4, v14

    :goto_340
    move-object/from16 v6, p1

    move-object/from16 v4, p4

    move-object/from16 v11, p6

    move-object/from16 v9, p8

    move-object/from16 v3, p10

    goto/16 :goto_f9

    :cond_34c
    move-object/from16 v5, p4

    move-object v4, v7

    move-object/from16 p4, v14

    move-object/from16 v7, p11

    .line 48
    :cond_353
    :goto_353
    :try_start_353
    invoke-virtual/range {p13 .. p13}, Ljava/lang/String;->isEmpty()Z

    move-result v6
    :try_end_357
    .catch Ljava/lang/Exception; {:try_start_353 .. :try_end_357} :catch_3f7

    if-nez v6, :cond_3cf

    :try_start_359
    invoke-virtual/range {p1 .. p1}, Ljava/lang/String;->isEmpty()Z

    move-result v6

    if-nez v6, :cond_3cf

    const-string v6, "09202A2C"

    invoke-static {v6}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v2, v6}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v6
    :try_end_369
    .catch Ljava/lang/Exception; {:try_start_359 .. :try_end_369} :catch_3bb

    if-eqz v6, :cond_3cf

    move-object/from16 v6, p1

    .line 49
    :try_start_36d
    invoke-virtual {v6, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_375

    move-object/from16 v6, p13

    .line 50
    :cond_375
    invoke-virtual {v6, v3}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v4
    :try_end_379
    .catch Ljava/lang/Exception; {:try_start_36d .. :try_end_379} :catch_3b9

    const-string v9, "94CCC1B4E0CB"

    invoke-static {v9}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    const-string v11, "103B"

    invoke-static {v11}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v11

    move v13, v8

    move-object/from16 v8, p13

    if-eqz v4, :cond_3b1

    :try_start_38a
    invoke-virtual {v8, v3}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v3

    if-eqz v3, :cond_3b1

    .line 51
    invoke-virtual {v8, v0}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v3

    .line 52
    invoke-virtual {v6, v0}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v0

    .line 53
    array-length v4, v0

    if-ge v13, v4, :cond_3d4

    aget-object v4, v0, v13

    invoke-virtual {v4, v12}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-nez v4, :cond_3d4

    .line 54
    aget-object v3, v3, v13

    aget-object v0, v0, v13

    invoke-direct {v1, v11, v9, v3, v0}, Lcom/github/catvod/spider/XYQHiker;->ށ(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v0

    invoke-virtual {v10, v0}, Lorg/json/JSONArray;->put(Ljava/lang/Object;)Lorg/json/JSONArray;

    goto :goto_3d4

    :catch_3af
    move-exception v0

    goto :goto_3c1

    .line 55
    :cond_3b1
    invoke-direct {v1, v11, v9, v8, v6}, Lcom/github/catvod/spider/XYQHiker;->ށ(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v0

    invoke-virtual {v10, v0}, Lorg/json/JSONArray;->put(Ljava/lang/Object;)Lorg/json/JSONArray;
    :try_end_3b8
    .catch Ljava/lang/Exception; {:try_start_38a .. :try_end_3b8} :catch_3af

    goto :goto_3d4

    :catch_3b9
    move-exception v0

    goto :goto_3be

    :catch_3bb
    move-exception v0

    move-object/from16 v6, p1

    :goto_3be
    move v13, v8

    move-object/from16 v8, p13

    :goto_3c1
    move-object/from16 v4, p4

    move-object/from16 v11, p6

    move-object/from16 v9, p8

    move-object/from16 v3, p10

    move-object/from16 v14, v16

    move-object/from16 v12, v17

    goto/16 :goto_463

    :cond_3cf
    move-object/from16 v6, p1

    move v13, v8

    move-object/from16 v8, p13

    :cond_3d4
    :goto_3d4
    move-object/from16 v12, v17

    .line 56
    :try_start_3d6
    invoke-virtual {v12, v13}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;
    :try_end_3dc
    .catch Ljava/lang/Exception; {:try_start_3d6 .. :try_end_3dc} :catch_3f3

    move-object/from16 v14, v16

    :try_start_3de
    invoke-virtual {v14, v0, v10}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 57
    new-instance v0, Lorg/json/JSONArray;

    invoke-direct {v0}, Lorg/json/JSONArray;-><init>()V
    :try_end_3e6
    .catch Ljava/lang/Exception; {:try_start_3de .. :try_end_3e6} :catch_3f1

    move-object/from16 v4, p4

    move-object/from16 v11, p6

    move-object/from16 v9, p8

    move-object v10, v0

    move-object/from16 v0, p10

    goto/16 :goto_48d

    :catch_3f1
    move-exception v0

    goto :goto_40c

    :catch_3f3
    move-exception v0

    move-object/from16 v14, v16

    goto :goto_40c

    :catch_3f7
    move-exception v0

    move-object/from16 v6, p1

    move v13, v8

    goto :goto_406

    :catch_3fc
    move-exception v0

    move-object/from16 v6, p1

    move-object/from16 v5, p4

    move-object/from16 v7, p11

    move v13, v8

    move-object/from16 p4, v14

    :goto_406
    move-object/from16 v14, v16

    move-object/from16 v12, v17

    move-object/from16 v8, p13

    :goto_40c
    move-object/from16 v4, p4

    move-object/from16 v11, p6

    goto :goto_425

    :catch_411
    move-exception v0

    move-object/from16 v6, p1

    move-object/from16 v5, p4

    move-object/from16 v4, p6

    move-object/from16 v7, p11

    move-object/from16 p6, v11

    move-object/from16 p10, v13

    move-object/from16 v14, v16

    move-object/from16 v12, v17

    move v13, v8

    move-object/from16 v8, p13

    :goto_425
    move-object/from16 v9, p8

    move-object/from16 v3, p10

    goto :goto_463

    :catch_42a
    move-exception v0

    move-object/from16 v6, p1

    move-object/from16 v5, p4

    move-object/from16 v4, p6

    move-object/from16 v15, p7

    move-object/from16 v3, p8

    move-object/from16 v7, p11

    move v13, v8

    move-object/from16 p8, v9

    move-object/from16 p6, v11

    goto :goto_44d

    :catch_43d
    move-exception v0

    move-object/from16 v6, p1

    move-object/from16 v5, p4

    move-object/from16 v4, p6

    move-object/from16 v15, p7

    move-object/from16 v3, p8

    move-object/from16 v7, p11

    move v13, v8

    move-object/from16 p8, v9

    :goto_44d
    move-object/from16 v14, v16

    move-object/from16 v12, v17

    :goto_451
    move-object/from16 v8, p13

    goto :goto_463

    :catch_454
    move-exception v0

    move-object/from16 v6, p1

    move-object v3, v13

    move-object v4, v14

    move-object/from16 v14, v16

    move v13, v8

    move-object/from16 v8, p13

    move-object/from16 v18, v15

    move-object v15, v5

    move-object/from16 v5, v18

    .line 58
    :goto_463
    :try_start_463
    invoke-static {v0}, Lcom/github/catvod/crawler/SpiderDebug;->log(Ljava/lang/Throwable;)V

    .line 59
    iget-boolean v2, v1, Lcom/github/catvod/spider/XYQHiker;->ވ:Z

    if-eqz v2, :cond_489

    .line 60
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    move-object/from16 p1, v3

    const-string v3, "113036302E021B2E273428ACDDE4B4EADCA3DFD9BAD1D3A3E6DDB5D9CAA1F5F8BAC5C3ABCED8"

    invoke-static {v3}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/Exception;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lcom/github/catvod/spider/Init;->show(Ljava/lang/String;)V
    :try_end_488
    .catch Ljava/lang/Exception; {:try_start_463 .. :try_end_488} :catch_4a8

    goto :goto_48b

    :cond_489
    move-object/from16 p1, v3

    :goto_48b
    move-object/from16 v0, p1

    :goto_48d
    add-int/lit8 v2, v13, 0x1

    move-object/from16 v3, p3

    move-object v13, v0

    move v8, v2

    move-object/from16 p1, v6

    move-object/from16 v16, v14

    move-object/from16 v2, p2

    move-object/from16 v6, p9

    move-object v14, v4

    move-object/from16 v4, p5

    move-object/from16 v18, v15

    move-object v15, v5

    move-object/from16 v5, v18

    goto/16 :goto_5a

    :cond_4a5
    move-object/from16 v14, v16

    return-object v14

    :catch_4a8
    move-exception v0

    .line 61
    invoke-static {v0}, Lcom/github/catvod/crawler/SpiderDebug;->log(Ljava/lang/Throwable;)V

    .line 62
    iget-boolean v2, v1, Lcom/github/catvod/spider/XYQHiker;->ވ:Z

    if-eqz v2, :cond_4cc

    .line 63
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "113036302E021B2E273428A1F7EAB6E0DAA1F5F8BAC5C3ABCED8"

    invoke-static {v3}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/Exception;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lcom/github/catvod/spider/Init;->show(Ljava/lang/String;)V

    :cond_4cc
    const/4 v0, 0x0

    return-object v0
.end method

.method private static ԫ()Ljava/lang/String;
    .registers 5

    .line 1
    new-instance v0, Ljava/text/SimpleDateFormat;

    const-string v1, "0B3B2A28"

    invoke-static {v1}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Ljava/text/SimpleDateFormat;-><init>(Ljava/lang/String;)V

    new-instance v1, Ljava/util/Date;

    invoke-direct {v1}, Ljava/util/Date;-><init>()V

    invoke-virtual {v0, v1}, Ljava/text/SimpleDateFormat;->format(Ljava/util/Date;)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v0

    add-int/lit8 v1, v0, -0x14

    if-le v0, v1, :cond_1f

    move v4, v1

    move v1, v0

    move v0, v4

    :cond_1f
    const-string v2, ""

    :goto_21
    if-lt v1, v0, :cond_58

    if-ne v1, v0, :cond_39

    .line 2
    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static {v1}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    goto :goto_55

    .line 3
    :cond_39
    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static {v1}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v2, "54"

    invoke-static {v2}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    :goto_55
    add-int/lit8 v1, v1, -0x1

    goto :goto_21

    :cond_58
    return-object v2
.end method

.method private static ֏(Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    .registers 8

    .line 1
    invoke-virtual {p1, p2}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object p1

    .line 2
    new-instance p2, Ljava/util/ArrayList;

    invoke-direct {p2}, Ljava/util/ArrayList;-><init>()V

    .line 3
    array-length v0, p1

    const/4 v1, 0x0

    :goto_b
    if-ge v1, v0, :cond_5f

    aget-object v2, p1, v1

    .line 4
    invoke-virtual {v2}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v2

    const-string v3, "55"

    invoke-static {v3}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    .line 5
    invoke-virtual {v2, v3}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v4

    if-eqz v4, :cond_25

    invoke-virtual {v2, v3}, Ljava/lang/String;->endsWith(Ljava/lang/String;)Z

    move-result v3

    if-nez v3, :cond_37

    :cond_25
    const-string v3, "50"

    invoke-static {v3}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    .line 6
    invoke-virtual {v2, v3}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v4

    if-eqz v4, :cond_55

    invoke-virtual {v2, v3}, Ljava/lang/String;->endsWith(Ljava/lang/String;)Z

    move-result v3

    if-eqz v3, :cond_55

    .line 7
    :cond_37
    invoke-virtual {v2}, Ljava/lang/String;->length()I

    move-result v3

    const/4 v4, 0x1

    sub-int/2addr v3, v4

    invoke-virtual {v2, v4, v3}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v2

    const-string v3, "2E2C"

    invoke-static {v3}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    const-string v4, "78"

    invoke-static {v4}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v2, v3, v4}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object v2

    invoke-interface {p2, v2}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    goto :goto_5c

    .line 8
    :cond_55
    invoke-static {p0, v2}, Lcom/github/catvod/spider/XYQHiker;->ؠ(Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-interface {p2, v2}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    :goto_5c
    add-int/lit8 v1, v1, 0x1

    goto :goto_b

    :cond_5f
    const-string p0, ""

    .line 9
    invoke-static {p2, p0}, Lcom/github/catvod/spider/XYQHiker;->listToString(Ljava/util/List;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method private static ؠ(Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;Ljava/lang/String;)Ljava/lang/String;
    .registers 5

    const-string v0, "5464"

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 1
    invoke-virtual {p1, v0}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object p1

    .line 2
    array-length v0, p1

    const/4 v1, 0x1

    if-ne v0, v1, :cond_f

    goto :goto_16

    :cond_f
    const/4 v0, 0x0

    .line 3
    aget-object v0, p1, v0

    invoke-static {v0, p0}, Lcom/github/catvod/spider/XYQHiker;->getTrueElement(Ljava/lang/String;Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;)Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;

    move-result-object p0

    :goto_16
    const/4 v0, 0x1

    .line 4
    :goto_17
    array-length v2, p1

    sub-int/2addr v2, v1

    if-ge v0, v2, :cond_24

    .line 5
    aget-object v2, p1, v0

    invoke-static {v2, p0}, Lcom/github/catvod/spider/XYQHiker;->getTrueElement(Ljava/lang/String;Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;)Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;

    move-result-object p0

    add-int/lit8 v0, v0, 0x1

    goto :goto_17

    .line 6
    :cond_24
    array-length v0, p1

    sub-int/2addr v0, v1

    aget-object p1, p1, v0

    invoke-static {p0, p1}, Lcom/github/catvod/spider/XYQHiker;->getText(Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method private ށ(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lorg/json/JSONObject;
    .registers 14

    const-string v0, "103B"

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const-string v1, "54"

    invoke-static {v1}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    .line 1
    :try_start_c
    new-instance v2, Lorg/json/JSONObject;

    invoke-direct {v2}, Lorg/json/JSONObject;-><init>()V

    .line 2
    new-instance v3, Lorg/json/JSONArray;

    invoke-direct {v3}, Lorg/json/JSONArray;-><init>()V

    .line 3
    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4
    :try_end_1a
    .catch Ljava/lang/Exception; {:try_start_c .. :try_end_1a} :catch_d2

    const-string v5, ""

    const-string v6, "04"

    invoke-static {v6}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    const-string v7, "1C"

    invoke-static {v7}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    const-string v8, "95EBE9"

    invoke-static {v8}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    if-nez v4, :cond_4b

    :try_start_30
    invoke-virtual {p4, v8}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-nez v4, :cond_4b

    const-string v0, "97C7FBB8D9EC"

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 4
    invoke-virtual {v2, v7, v0}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 5
    invoke-virtual {v2, v6, v5}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 6
    invoke-virtual {v3, v2}, Lorg/json/JSONArray;->put(Ljava/lang/Object;)Lorg/json/JSONArray;

    .line 7
    new-instance v2, Lorg/json/JSONObject;

    invoke-direct {v2}, Lorg/json/JSONObject;-><init>()V

    goto :goto_6b

    .line 8
    :cond_4b
    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_6b

    invoke-virtual {p4, v8}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_6b

    const-string v0, "9BF9CBB9F4E0"

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 9
    invoke-virtual {v2, v7, v0}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 10
    invoke-virtual {v2, v6, v5}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 11
    invoke-virtual {v3, v2}, Lorg/json/JSONArray;->put(Ljava/lang/Object;)Lorg/json/JSONArray;

    .line 12
    new-instance v2, Lorg/json/JSONObject;

    invoke-direct {v2}, Lorg/json/JSONObject;-><init>()V

    .line 13
    :cond_6b
    :goto_6b
    invoke-virtual {p4, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    if-eqz v0, :cond_a2

    invoke-virtual {p4, v8}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_a2

    .line 14
    invoke-virtual {p3, v1}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object p3

    .line 15
    invoke-virtual {p4, v1}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object p4

    const/4 v0, 0x0

    .line 16
    :goto_80
    array-length v4, p3

    if-ge v0, v4, :cond_b1

    .line 17
    aget-object v4, p3, v0

    invoke-virtual {v2, v7, v4}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 18
    aget-object v4, p4, v0

    const-string v5, "9DFED5BEE6C2"

    invoke-static {v5}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5, v1}, Ljava/lang/String;->replaceAll(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v2, v6, v4}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 19
    invoke-virtual {v3, v2}, Lorg/json/JSONArray;->put(Ljava/lang/Object;)Lorg/json/JSONArray;

    .line 20
    new-instance v2, Lorg/json/JSONObject;

    invoke-direct {v2}, Lorg/json/JSONObject;-><init>()V

    add-int/lit8 v0, v0, 0x1

    goto :goto_80

    .line 21
    :cond_a2
    invoke-virtual {p4, v8}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_b1

    .line 22
    invoke-virtual {v2, v7, p3}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 23
    invoke-virtual {v2, v6, p4}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 24
    invoke-virtual {v3, v2}, Lorg/json/JSONArray;->put(Ljava/lang/Object;)Lorg/json/JSONArray;

    .line 25
    :cond_b1
    new-instance p3, Lorg/json/JSONObject;

    invoke-direct {p3}, Lorg/json/JSONObject;-><init>()V

    const-string p4, "19272A"

    invoke-static {p4}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p4

    .line 26
    invoke-virtual {p3, p4, p1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const-string p1, "1C233E34"

    invoke-static {p1}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    .line 27
    invoke-virtual {p3, p1, p2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const-string p1, "04233F243F"

    invoke-static {p1}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    .line 28
    invoke-virtual {p3, p1, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    :try_end_d1
    .catch Ljava/lang/Exception; {:try_start_30 .. :try_end_d1} :catch_d2

    return-object p3

    :catch_d2
    move-exception p1

    .line 29
    invoke-static {p1}, Lcom/github/catvod/crawler/SpiderDebug;->log(Ljava/lang/Throwable;)V

    .line 30
    iget-boolean p2, p0, Lcom/github/catvod/spider/XYQHiker;->ވ:Z

    if-eqz p2, :cond_f6

    .line 31
    new-instance p2, Ljava/lang/StringBuilder;

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    const-string p3, "95EFC8B8DACD152727030E3D0227BAD2F2A1FAC4B6D6E0ADE6DBBCEDC0"

    invoke-static {p3}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p3

    invoke-virtual {p2, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/Exception;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-static {p1}, Lcom/github/catvod/spider/Init;->show(Ljava/lang/String;)V

    :cond_f6
    const/4 p1, 0x0

    return-object p1
.end method

.method private ނ(Ljava/lang/String;)Ljava/lang/String;
    .registers 3

    const-string v0, ""

    .line 1
    invoke-direct {p0, p1, v0}, Lcom/github/catvod/spider/XYQHiker;->ރ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    return-object p1
.end method

.method private ރ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    .registers 4

    .line 1
    iget-object v0, p0, Lcom/github/catvod/spider/XYQHiker;->ކ:Lorg/json/JSONObject;

    invoke-virtual {v0, p1}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    .line 2
    invoke-virtual {p1}, Ljava/lang/String;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_26

    const-string v0, "95EBE9"

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_26

    const-string v0, "5464"

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_25

    goto :goto_26

    :cond_25
    return-object p1

    :cond_26
    :goto_26
    return-object p2
.end method

.method private static ޅ(Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;Ljava/lang/String;)Ljava/lang/String;
    .registers 13

    :try_start_0
    const-string v0, "2E6C392260"

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 1
    invoke-virtual {p1, v0}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v0

    .line 2
    array-length v1, v0

    const/4 v2, 0x1

    const/4 v3, 0x0

    if-le v1, v2, :cond_11

    .line 3
    aget-object p1, v0, v3

    :cond_11
    const-string v0, "53"

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 4
    invoke-virtual {p1, v0}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v0

    .line 5
    array-length v1, v0
    :try_end_1c
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_1c} :catch_ed

    const-string v4, "52"

    invoke-static {v4}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    const-string v5, "78"

    invoke-static {v5}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    const-string v6, "307467153F27"

    invoke-static {v6}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    const-string v7, "26272B25"

    invoke-static {v7}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    const-string v8, ""

    const-string v9, "33362723"

    invoke-static {v9}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    const-string v10, "3A363E3D"

    invoke-static {v10}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    if-le v1, v2, :cond_a4

    .line 6
    :try_start_44
    aget-object v1, v0, v3

    invoke-virtual {v1, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_51

    .line 7
    invoke-virtual {p0}, Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;->ࢹ()Ljava/lang/String;

    move-result-object p0

    goto :goto_8e

    .line 8
    :cond_51
    aget-object v1, v0, v3

    invoke-virtual {v6, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_68

    .line 9
    new-instance v1, Ljava/lang/String;

    invoke-virtual {p0}, Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;->ࢹ()Ljava/lang/String;

    move-result-object p0

    invoke-static {p0, v3}, Landroid/util/Base64;->decode(Ljava/lang/String;I)[B

    move-result-object p0

    invoke-direct {v1, p0}, Ljava/lang/String;-><init>([B)V

    move-object p0, v1

    goto :goto_8e

    .line 10
    :cond_68
    aget-object v1, v0, v3

    invoke-virtual {v10, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_75

    .line 11
    invoke-virtual {p0}, Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;->ࢣ()Ljava/lang/String;

    move-result-object p0

    goto :goto_8e

    .line 12
    :cond_75
    aget-object v1, v0, v3

    invoke-virtual {v1, v9}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-eqz v1, :cond_88

    .line 13
    aget-object v1, v0, v3

    invoke-virtual {v1, v9, v8}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {p0, v1}, Lcom/github/catvod/spider/xbpqxyq/xyq/ւ;->ԩ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    goto :goto_8e

    .line 14
    :cond_88
    aget-object v1, v0, v3

    invoke-virtual {p0, v1}, Lcom/github/catvod/spider/xbpqxyq/xyq/ւ;->ԩ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    .line 15
    :goto_8e
    invoke-virtual {v10, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-nez p1, :cond_98

    .line 16
    invoke-virtual {p0, v5, v4}, Ljava/lang/String;->replaceAll(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    .line 17
    :cond_98
    :goto_98
    array-length p1, v0

    if-ge v2, p1, :cond_ec

    .line 18
    aget-object p1, v0, v2

    invoke-virtual {p0, p1, v8}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object p0

    add-int/lit8 v2, v2, 0x1

    goto :goto_98

    .line 19
    :cond_a4
    invoke-virtual {p1, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_af

    .line 20
    invoke-virtual {p0}, Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;->ࢹ()Ljava/lang/String;

    move-result-object p0

    goto :goto_e2

    .line 21
    :cond_af
    invoke-virtual {v6, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_c4

    .line 22
    new-instance v0, Ljava/lang/String;

    invoke-virtual {p0}, Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;->ࢹ()Ljava/lang/String;

    move-result-object p0

    invoke-static {p0, v3}, Landroid/util/Base64;->decode(Ljava/lang/String;I)[B

    move-result-object p0

    invoke-direct {v0, p0}, Ljava/lang/String;-><init>([B)V

    move-object p0, v0

    goto :goto_e2

    .line 23
    :cond_c4
    invoke-virtual {v10, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_cf

    .line 24
    invoke-virtual {p0}, Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;->ࢣ()Ljava/lang/String;

    move-result-object p0

    goto :goto_e2

    .line 25
    :cond_cf
    invoke-virtual {p1, v9}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    if-eqz v0, :cond_de

    .line 26
    invoke-virtual {p1, v9, v8}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p0, v0}, Lcom/github/catvod/spider/xbpqxyq/xyq/ւ;->ԩ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    goto :goto_e2

    .line 27
    :cond_de
    invoke-virtual {p0, p1}, Lcom/github/catvod/spider/xbpqxyq/xyq/ւ;->ԩ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    .line 28
    :goto_e2
    invoke-virtual {v10, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-nez p1, :cond_ec

    .line 29
    invoke-virtual {p0, v5, v4}, Ljava/lang/String;->replaceAll(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0
    :try_end_ec
    .catch Ljava/lang/Exception; {:try_start_44 .. :try_end_ec} :catch_ed

    :cond_ec
    return-object p0

    :catch_ed
    move-exception p0

    .line 30
    invoke-static {p0}, Lcom/github/catvod/crawler/SpiderDebug;->log(Ljava/lang/Throwable;)V

    const/4 p0, 0x0

    return-object p0
.end method

.method private ކ(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    .registers 15

    const-string v0, "012A3C26"

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 1
    invoke-virtual {p3, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p3

    if-eqz p3, :cond_11

    invoke-virtual {p0, p1}, Lcom/github/catvod/spider/XYQHiker;->ހ(Ljava/lang/String;)Ljava/util/HashMap;

    move-result-object p3

    goto :goto_15

    :cond_11
    invoke-virtual {p0, p1}, Lcom/github/catvod/spider/XYQHiker;->ބ(Ljava/lang/String;)Ljava/util/HashMap;

    move-result-object p3

    :goto_15
    const/4 v0, 0x0

    const/4 v1, 0x0

    :goto_17
    const/4 v2, 0x3

    if-ge v1, v2, :cond_133

    const-string v2, "5D2A26303E2B1C250C"

    invoke-static {v2}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    .line 2
    invoke-virtual {p2, v2}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v2

    const-string v3, ""

    const-string v4, "7F3E59"

    invoke-static {v4}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    const-string v5, "9BE8DFB9F5C54E6D27382E28177C"

    invoke-static {v5}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    const-string v6, "5D30363F302D2D"

    invoke-static {v6}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    if-nez v2, :cond_40

    invoke-virtual {p2, v6}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v2

    if-eqz v2, :cond_124

    .line 3
    :cond_40
    invoke-static {p2}, Lcom/github/catvod/spider/xbpqxyq/xyq/ٱ;->Ϳ(Ljava/lang/String;)Lcom/github/catvod/spider/xbpqxyq/xyq/ǐ;

    move-result-object v2

    const-string v7, "102D37287C62012121382A305464202339"

    invoke-static {v7}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    invoke-static {v2, v7}, Lcom/github/catvod/spider/XYQHiker;->getTextByRule(Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-static {p1, v2}, Lcom/github/catvod/spider/xbpqxyq/xyq/ވ;->Ԫ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    .line 4
    iget-object v7, p0, Lcom/github/catvod/spider/XYQHiker;->ހ:Ljava/lang/String;

    invoke-virtual {p0, v2, v7, p3}, Lcom/github/catvod/spider/XYQHiker;->Ԭ(Ljava/lang/String;Ljava/lang/String;Ljava/util/Map;)Ljava/lang/String;

    move-result-object v2

    const-string v7, "19272A6C78"

    invoke-static {v7}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    const-string v8, "50"

    invoke-static {v8}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    .line 5
    invoke-static {v2, v7, v8}, Lcom/github/catvod/spider/xbpqxyq/xyq/ވ;->އ(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/util/ArrayList;

    move-result-object v7

    invoke-virtual {v7, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Ljava/lang/String;

    const-string v9, "04233F243F7950"

    invoke-static {v9}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    .line 6
    invoke-static {v2, v9, v8}, Lcom/github/catvod/spider/xbpqxyq/xyq/ވ;->އ(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/util/ArrayList;

    move-result-object v9

    invoke-virtual {v9, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v9

    check-cast v9, Ljava/lang/String;

    const-string v10, "116C34342E6C506D32636A26177A6A68"

    invoke-static {v10}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    .line 7
    invoke-static {v2, v10, v8}, Lcom/github/catvod/spider/xbpqxyq/xyq/ވ;->އ(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/String;

    .line 8
    new-instance v8, Ljava/lang/StringBuilder;

    invoke-direct {v8}, Ljava/lang/StringBuilder;-><init>()V

    const-string v10, "5D23616138214A7B6A"

    invoke-static {v10}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v8, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v8, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v8, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v2, "5434323D2F214F"

    invoke-static {v2}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v8, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p2, v6}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result p2

    if-eqz p2, :cond_b8

    const-string p2, "162820"

    invoke-static {p2}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p2

    goto :goto_be

    :cond_b8
    const-string p2, "1A26"

    invoke-static {p2}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p2

    :goto_be
    invoke-static {v9, p2}, Lcom/github/catvod/spider/XYQHiker;->string2Hex(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p2

    sget-object v2, Lcom/github/catvod/spider/xbpqxyq/xyq/ކ;->ԩ:Ljava/nio/charset/Charset;

    invoke-static {p2, v2}, Lcom/github/catvod/spider/xbpqxyq/xyq/ކ;->Ϳ(Ljava/lang/String;Ljava/nio/charset/Charset;)Ljava/lang/String;

    move-result-object p2

    invoke-virtual {v8, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v8}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    invoke-static {p1, p2}, Lcom/github/catvod/spider/xbpqxyq/xyq/ވ;->Ԫ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p2

    .line 9
    new-instance v2, Ljava/util/HashMap;

    invoke-direct {v2}, Ljava/util/HashMap;-><init>()V

    .line 10
    invoke-static {p2, p3, v2}, Lcom/github/catvod/spider/xbpqxyq/xyq/ތ;->ؠ(Ljava/lang/String;Ljava/util/Map;Ljava/util/Map;)Ljava/lang/String;

    .line 11
    invoke-interface {v2}, Ljava/util/Map;->entrySet()Ljava/util/Set;

    move-result-object p2

    invoke-interface {p2}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object p2

    :cond_e3
    invoke-interface {p2}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_113

    invoke-interface {p2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/util/Map$Entry;

    .line 12
    invoke-interface {v2}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Ljava/lang/String;

    const-string v7, "0127277C392B1D293A34"

    invoke-static {v7}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v6, v7}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v6

    if-eqz v6, :cond_e3

    .line 13
    invoke-interface {v2}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object p2

    check-cast p2, Ljava/lang/Iterable;

    const-string v2, "49"

    invoke-static {v2}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-static {v2, p2}, Landroid/text/TextUtils;->join(Ljava/lang/CharSequence;Ljava/lang/Iterable;)Ljava/lang/String;

    move-result-object p2

    iput-object p2, p0, Lcom/github/catvod/spider/XYQHiker;->ؠ:Ljava/lang/String;

    .line 14
    :cond_113
    iget-object p2, p0, Lcom/github/catvod/spider/XYQHiker;->ހ:Ljava/lang/String;

    invoke-virtual {p0, p1, p2, p3}, Lcom/github/catvod/spider/XYQHiker;->Ԭ(Ljava/lang/String;Ljava/lang/String;Ljava/util/Map;)Ljava/lang/String;

    move-result-object p2

    .line 15
    invoke-virtual {p2, v5}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v2

    if-nez v2, :cond_124

    .line 16
    invoke-virtual {p2, v4, v3}, Ljava/lang/String;->replaceAll(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    return-object p1

    .line 17
    :cond_124
    invoke-virtual {p2, v5}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v2

    if-nez v2, :cond_12f

    .line 18
    invoke-virtual {p2, v4, v3}, Ljava/lang/String;->replaceAll(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    return-object p1

    :cond_12f
    add-int/lit8 v1, v1, 0x1

    goto/16 :goto_17

    :cond_133
    const/4 p1, 0x0

    return-object p1
.end method

.method private އ(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    .registers 13

    const-string v0, "012A3C26"

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 1
    invoke-virtual {p3, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p3

    if-eqz p3, :cond_11

    invoke-virtual {p0, p1}, Lcom/github/catvod/spider/XYQHiker;->ހ(Ljava/lang/String;)Ljava/util/HashMap;

    move-result-object p3

    goto :goto_15

    :cond_11
    invoke-virtual {p0, p1}, Lcom/github/catvod/spider/XYQHiker;->ބ(Ljava/lang/String;)Ljava/util/HashMap;

    move-result-object p3

    :goto_15
    const/4 v0, 0x0

    const/4 v1, 0x0

    :goto_17
    const/4 v2, 0x3

    if-ge v1, v2, :cond_ea

    const-string v2, "94E1D3B7EFCF96FAFE"

    invoke-static {v2}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    .line 2
    invoke-virtual {p2, v2}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v2

    const-string v3, ""

    const-string v4, "7F3E59"

    invoke-static {v4}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    const-string v5, "4E363A2536214CA4F0D1BCF1F9A6EBFC666B062B273D3F7A"

    invoke-static {v5}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    if-eqz v2, :cond_db

    const-string v2, "103624303C"

    invoke-static {v2}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {p2, v2}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v2

    if-eqz v2, :cond_db

    const-string v2, "103624303C79"

    invoke-static {v2}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    const-string v6, "50"

    invoke-static {v6}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    .line 3
    invoke-static {p2, v2, v6}, Lcom/github/catvod/spider/xbpqxyq/xyq/ވ;->އ(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/util/ArrayList;

    move-result-object p2

    invoke-virtual {p2, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p2

    check-cast p2, Ljava/lang/String;

    const-string v2, "4D"

    invoke-static {v2}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    .line 4
    invoke-virtual {p1, v2}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v2

    if-eqz v2, :cond_71

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v6, "542027263B224F"

    invoke-static {v6}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    goto :goto_7f

    :cond_71
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v6, "4D2027263B224F"

    invoke-static {v6}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    :goto_7f
    invoke-virtual {v2, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    .line 5
    new-instance v2, Ljava/util/HashMap;

    invoke-direct {v2}, Ljava/util/HashMap;-><init>()V

    .line 6
    invoke-static {p2, p3, v2}, Lcom/github/catvod/spider/xbpqxyq/xyq/ތ;->ؠ(Ljava/lang/String;Ljava/util/Map;Ljava/util/Map;)Ljava/lang/String;

    move-result-object p2

    .line 7
    invoke-interface {v2}, Ljava/util/Map;->entrySet()Ljava/util/Set;

    move-result-object v2

    invoke-interface {v2}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :cond_9a
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v6

    if-eqz v6, :cond_ca

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Ljava/util/Map$Entry;

    .line 8
    invoke-interface {v6}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Ljava/lang/String;

    const-string v8, "0127277C392B1D293A34"

    invoke-static {v8}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v7, v8}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v7

    if-eqz v7, :cond_9a

    .line 9
    invoke-interface {v6}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/Iterable;

    const-string v6, "49"

    invoke-static {v6}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    invoke-static {v6, v2}, Landroid/text/TextUtils;->join(Ljava/lang/CharSequence;Ljava/lang/Iterable;)Ljava/lang/String;

    move-result-object v2

    iput-object v2, p0, Lcom/github/catvod/spider/XYQHiker;->ؠ:Ljava/lang/String;

    .line 10
    :cond_ca
    invoke-virtual {p2, v5}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v2

    if-nez v2, :cond_d5

    .line 11
    invoke-virtual {p2, v4, v3}, Ljava/lang/String;->replaceAll(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    return-object p1

    .line 12
    :cond_d5
    iget-object p2, p0, Lcom/github/catvod/spider/XYQHiker;->ހ:Ljava/lang/String;

    invoke-virtual {p0, p1, p2, p3}, Lcom/github/catvod/spider/XYQHiker;->Ԭ(Ljava/lang/String;Ljava/lang/String;Ljava/util/Map;)Ljava/lang/String;

    move-result-object p2

    .line 13
    :cond_db
    invoke-virtual {p2, v5}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v2

    if-nez v2, :cond_e6

    .line 14
    invoke-virtual {p2, v4, v3}, Ljava/lang/String;->replaceAll(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    return-object p1

    :cond_e6
    add-int/lit8 v1, v1, 0x1

    goto/16 :goto_17

    :cond_ea
    const/4 p1, 0x0

    return-object p1
.end method

.method private ވ(Ljava/lang/String;Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    .registers 23
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ")",
            "Ljava/lang/String;"
        }
    .end annotation

    move-object/from16 v1, p0

    move-object/from16 v2, p1

    move-object/from16 v3, p2

    move-object/from16 v4, p3

    move-object/from16 v5, p4

    const-string v6, "5D34362333220B"

    invoke-static {v6}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    const-string v7, "012A3C26"

    invoke-static {v7}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    .line 1
    invoke-virtual {v4, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_21

    invoke-virtual/range {p0 .. p1}, Lcom/github/catvod/spider/XYQHiker;->ހ(Ljava/lang/String;)Ljava/util/HashMap;

    move-result-object v0

    goto :goto_25

    :cond_21
    invoke-virtual/range {p0 .. p1}, Lcom/github/catvod/spider/XYQHiker;->ބ(Ljava/lang/String;)Ljava/util/HashMap;

    move-result-object v0

    :goto_25
    move-object v8, v0

    const-string v9, "2A6F01342B31173127343E69252B2739"

    invoke-static {v9}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    const-string v0, "2A0F1F192E30021036202F210136"

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 2
    invoke-virtual {v8, v9, v0}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v0, 0x0

    const-string v10, ""

    move-object v12, v10

    const/4 v11, 0x0

    .line 3
    :goto_3a
    :try_start_3a
    new-instance v0, Lcom/github/catvod/spider/XYQHiker$4;

    invoke-direct {v0, v1}, Lcom/github/catvod/spider/XYQHiker$4;-><init>(Lcom/github/catvod/spider/XYQHiker;)V

    .line 4
    invoke-virtual {v5, v6}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v13
    :try_end_43
    .catch Ljava/lang/Exception; {:try_start_3a .. :try_end_43} :catch_2ad

    const-string v14, "01213B34392F3301"

    invoke-static {v14}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v14

    if-eqz v13, :cond_95

    .line 5
    :try_start_4b
    invoke-static {}, Lcom/github/catvod/spider/xbpqxyq/xyq/ތ;->ԩ()Lokhttp3/OkHttpClient;

    move-result-object v13

    new-instance v15, Ljava/lang/StringBuilder;

    invoke-direct {v15}, Ljava/lang/StringBuilder;-><init>()V
    :try_end_54
    .catch Ljava/lang/Exception; {:try_start_4b .. :try_end_54} :catch_2ad

    move-object/from16 v16, v12

    :try_start_56
    const-string v12, "5D2B3D353F3C5C323B21753217303A37236B1B2C3734226A1A363E3D"

    invoke-static {v12}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v12

    invoke-static {v2, v12}, Lcom/github/catvod/spider/xbpqxyq/xyq/ވ;->Ԫ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v12

    invoke-virtual {v15, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v12, "4D"

    invoke-static {v12}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v12

    invoke-virtual {v15, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    :try_end_6c
    .catch Ljava/lang/Exception; {:try_start_56 .. :try_end_6c} :catch_90

    move/from16 v17, v11

    :try_start_6e
    invoke-static {}, Ljava/lang/Math;->random()D

    move-result-wide v11

    invoke-virtual {v15, v11, v12}, Ljava/lang/StringBuilder;->append(D)Ljava/lang/StringBuilder;

    invoke-virtual {v15}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v11

    invoke-virtual {v4, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v12

    if-eqz v12, :cond_84

    invoke-virtual/range {p0 .. p1}, Lcom/github/catvod/spider/XYQHiker;->ހ(Ljava/lang/String;)Ljava/util/HashMap;

    move-result-object v12

    goto :goto_88

    :cond_84
    invoke-virtual/range {p0 .. p1}, Lcom/github/catvod/spider/XYQHiker;->ބ(Ljava/lang/String;)Ljava/util/HashMap;

    move-result-object v12

    :goto_88
    const/4 v15, 0x0

    invoke-static {v13, v11, v15, v12, v0}, Lcom/github/catvod/spider/xbpqxyq/xyq/ތ;->Ԫ(Lokhttp3/OkHttpClient;Ljava/lang/String;Ljava/util/Map;Ljava/util/Map;Lcom/github/catvod/spider/xbpqxyq/xyq/ފ;)V

    :goto_8c
    move-object v13, v9

    move-object v15, v10

    goto/16 :goto_12c

    :catch_90
    move-exception v0

    move/from16 v17, v11

    goto/16 :goto_2b2

    :cond_95
    move/from16 v17, v11

    move-object/from16 v16, v12

    .line 6
    invoke-virtual {v5, v14}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v11

    if-eqz v11, :cond_de

    .line 7
    invoke-static {}, Lcom/github/catvod/spider/xbpqxyq/xyq/ތ;->ԩ()Lokhttp3/OkHttpClient;

    move-result-object v11

    new-instance v12, Ljava/lang/StringBuilder;

    invoke-direct {v12}, Ljava/lang/StringBuilder;-><init>()V

    const-string v13, "5D2B3D32363116277C273E2D1F25303A74341A32"

    invoke-static {v13}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v13

    invoke-static {v2, v13}, Lcom/github/catvod/spider/xbpqxyq/xyq/ވ;->Ԫ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v13

    invoke-virtual {v12, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v13, "4D25362567"

    invoke-static {v13}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v13

    invoke-virtual {v12, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    new-instance v13, Ljava/util/Date;

    invoke-direct {v13}, Ljava/util/Date;-><init>()V

    invoke-virtual {v12, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v12}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v12

    invoke-virtual {v4, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v13

    if-eqz v13, :cond_d5

    invoke-virtual/range {p0 .. p1}, Lcom/github/catvod/spider/XYQHiker;->ހ(Ljava/lang/String;)Ljava/util/HashMap;

    move-result-object v13

    goto :goto_d9

    :cond_d5
    invoke-virtual/range {p0 .. p1}, Lcom/github/catvod/spider/XYQHiker;->ބ(Ljava/lang/String;)Ljava/util/HashMap;

    move-result-object v13

    :goto_d9
    const/4 v15, 0x0

    invoke-static {v11, v12, v15, v13, v0}, Lcom/github/catvod/spider/xbpqxyq/xyq/ތ;->Ԫ(Lokhttp3/OkHttpClient;Ljava/lang/String;Ljava/util/Map;Ljava/util/Map;Lcom/github/catvod/spider/xbpqxyq/xyq/ފ;)V

    goto :goto_8c

    .line 8
    :cond_de
    invoke-static {}, Lcom/github/catvod/spider/xbpqxyq/xyq/ތ;->ԩ()Lokhttp3/OkHttpClient;

    move-result-object v11

    new-instance v12, Ljava/lang/StringBuilder;

    invoke-direct {v12}, Ljava/lang/StringBuilder;-><init>()V

    new-instance v13, Ljava/lang/StringBuilder;

    invoke-direct {v13}, Ljava/lang/StringBuilder;-><init>()V

    const-string v15, "5D2B3D3275271D2F3E3E346B112D373474341A326C3067"

    invoke-static {v15}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v15

    invoke-virtual {v13, v15}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v13, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v15, "54316E"

    invoke-static {v15}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v15

    invoke-virtual {v13, v15}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v13}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v13

    invoke-static {v2, v13}, Lcom/github/catvod/spider/xbpqxyq/xyq/ވ;->Ԫ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v13

    invoke-virtual {v12, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    :try_end_10c
    .catch Ljava/lang/Exception; {:try_start_6e .. :try_end_10c} :catch_2ab

    move-object v13, v9

    move-object v15, v10

    :try_start_10e
    invoke-static {}, Ljava/lang/Math;->random()D

    move-result-wide v9

    invoke-virtual {v12, v9, v10}, Ljava/lang/StringBuilder;->append(D)Ljava/lang/StringBuilder;

    invoke-virtual {v12}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v4, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v10

    if-eqz v10, :cond_124

    invoke-virtual/range {p0 .. p1}, Lcom/github/catvod/spider/XYQHiker;->ހ(Ljava/lang/String;)Ljava/util/HashMap;

    move-result-object v10

    goto :goto_128

    :cond_124
    invoke-virtual/range {p0 .. p1}, Lcom/github/catvod/spider/XYQHiker;->ބ(Ljava/lang/String;)Ljava/util/HashMap;

    move-result-object v10

    :goto_128
    const/4 v12, 0x0

    invoke-static {v11, v9, v12, v10, v0}, Lcom/github/catvod/spider/xbpqxyq/xyq/ތ;->Ԫ(Lokhttp3/OkHttpClient;Ljava/lang/String;Ljava/util/Map;Ljava/util/Map;Lcom/github/catvod/spider/xbpqxyq/xyq/ފ;)V

    .line 9
    :goto_12c
    invoke-virtual {v0}, Lcom/github/catvod/spider/xbpqxyq/xyq/ފ;->getResult()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lokhttp3/Response;

    .line 10
    invoke-virtual {v0}, Lokhttp3/Response;->body()Lokhttp3/ResponseBody;

    move-result-object v0

    invoke-virtual {v0}, Lokhttp3/ResponseBody;->bytes()[B

    move-result-object v0

    const/4 v9, 0x2

    .line 11
    invoke-static {v0, v9}, Landroid/util/Base64;->encodeToString([BI)Ljava/lang/String;

    move-result-object v0

    .line 12
    new-instance v9, Ljava/util/HashMap;

    invoke-direct {v9}, Ljava/util/HashMap;-><init>()V

    const-string v10, "27313623770515273D25"

    invoke-static {v10}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    const-string v11, "3F2D29383628136D667F6A645A153A3F3E2B0531731F0E6443727D616164252B3D676E7F523A656573643332233D3F13172018382E6B4771647F6972526A18190E093E6E733D332F17621434392F1D6B731232361D2F367E6B74476C637F6A6A426200303C25002B7C6469735C7165"

    invoke-static {v11}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v11

    .line 13
    invoke-virtual {v9, v10, v11}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string v10, "312D3D253F2A066F07282A21"

    invoke-static {v10}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    const-string v11, "06272B2575341E233A3F6164112A32232921067F26253C694A"

    invoke-static {v11}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v11

    .line 14
    invoke-virtual {v9, v10, v11}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 15
    iget-object v10, v1, Lcom/github/catvod/spider/XYQHiker;->އ:Ljava/lang/String;

    iget-object v11, v1, Lcom/github/catvod/spider/XYQHiker;->ހ:Ljava/lang/String;

    invoke-virtual {v1, v10, v0, v11, v9}, Lcom/github/catvod/spider/XYQHiker;->Ϳ(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/util/Map;)Ljava/lang/String;

    move-result-object v0

    .line 16
    invoke-virtual {v5, v6}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v9

    if-eqz v9, :cond_19f

    .line 17
    new-instance v9, Ljava/lang/StringBuilder;

    invoke-direct {v9}, Ljava/lang/StringBuilder;-><init>()V

    const-string v10, "5D2B3D353F3C5C323B21752518232B7E2C21002B352805271A27303A65300B32366C"

    invoke-static {v10}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v9, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v9, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v10, "5434362333220B7F"

    invoke-static {v10}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v9, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v9, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v9}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    .line 18
    invoke-static {v2, v0}, Lcom/github/catvod/spider/xbpqxyq/xyq/ވ;->Ԫ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    iget-object v9, v1, Lcom/github/catvod/spider/XYQHiker;->ހ:Ljava/lang/String;

    const/4 v10, 0x0

    invoke-virtual {v1, v0, v10, v9, v8}, Lcom/github/catvod/spider/XYQHiker;->ԭ(Ljava/lang/String;Ljava/util/Map;Ljava/lang/String;Ljava/util/Map;)Ljava/lang/String;

    move-result-object v0

    move-object v9, v13

    move-object v12, v15

    goto :goto_202

    .line 19
    :cond_19f
    invoke-virtual {v5, v14}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v9
    :try_end_1a3
    .catch Ljava/lang/Exception; {:try_start_10e .. :try_end_1a3} :catch_2a7

    if-eqz v9, :cond_1d5

    move-object v9, v13

    .line 20
    :try_start_1a6
    invoke-virtual {v8, v9}, Ljava/util/HashMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    const-string v10, "5D31363028271A6C23392A7B01213B34392F33016E323221112975213B23177F75223F2500213B252334177F753E282017306E772E2D167F75302821137F75283F25007F753D3F300627216C7C3D073B323F6762013632253F79542F3C3F3F3D4F64253428795428226C"

    invoke-static {v10}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    .line 21
    new-instance v11, Ljava/util/HashMap;

    invoke-direct {v11}, Ljava/util/HashMap;-><init>()V

    const-string v12, "04233F383E250627"

    invoke-static {v12}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v12

    .line 22
    invoke-virtual {v11, v12, v0}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string v0, "01273223392C052D2135"

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0
    :try_end_1c3
    .catch Ljava/lang/Exception; {:try_start_1a6 .. :try_end_1c3} :catch_1d2

    move-object v12, v15

    .line 23
    :try_start_1c4
    invoke-virtual {v11, v0, v12}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 24
    invoke-static {v2, v10}, Lcom/github/catvod/spider/xbpqxyq/xyq/ވ;->Ԫ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    iget-object v10, v1, Lcom/github/catvod/spider/XYQHiker;->ހ:Ljava/lang/String;

    invoke-virtual {v1, v0, v11, v10, v8}, Lcom/github/catvod/spider/XYQHiker;->ԭ(Ljava/lang/String;Ljava/util/Map;Ljava/lang/String;Ljava/util/Map;)Ljava/lang/String;

    move-result-object v0

    goto :goto_202

    :catch_1d2
    move-exception v0

    goto/16 :goto_2a9

    :cond_1d5
    move-object v9, v13

    move-object v12, v15

    .line 25
    new-instance v10, Ljava/lang/StringBuilder;

    invoke-direct {v10}, Ljava/lang/StringBuilder;-><init>()V

    const-string v11, "5D2B3D32752518232B7F2A2C027D323267271D26360E392C172138772E3D02276E"

    invoke-static {v11}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v11

    invoke-virtual {v10, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v10, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v11, "54213C353F79"

    invoke-static {v11}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v11

    invoke-virtual {v10, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v10, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v10}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    .line 26
    invoke-static {v2, v0}, Lcom/github/catvod/spider/xbpqxyq/xyq/ވ;->Ԫ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    iget-object v10, v1, Lcom/github/catvod/spider/XYQHiker;->ހ:Ljava/lang/String;

    invoke-virtual {v1, v0, v10, v8}, Lcom/github/catvod/spider/XYQHiker;->Ԭ(Ljava/lang/String;Ljava/lang/String;Ljava/util/Map;)Ljava/lang/String;

    move-result-object v0

    .line 27
    :goto_202
    invoke-virtual {v5, v14}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v10

    if-eqz v10, :cond_23c

    const-string v10, "9BE8DFB9F5C595E2D2B5E2C994EFF0B6FBEA"

    invoke-static {v10}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    .line 28
    invoke-virtual {v0, v10}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    if-nez v0, :cond_2a0

    if-nez v3, :cond_21d

    .line 29
    iget-object v0, v1, Lcom/github/catvod/spider/XYQHiker;->ހ:Ljava/lang/String;

    invoke-virtual {v1, v2, v0, v8}, Lcom/github/catvod/spider/XYQHiker;->Ԭ(Ljava/lang/String;Ljava/lang/String;Ljava/util/Map;)Ljava/lang/String;

    move-result-object v0

    goto :goto_223

    .line 30
    :cond_21d
    iget-object v0, v1, Lcom/github/catvod/spider/XYQHiker;->ހ:Ljava/lang/String;

    invoke-virtual {v1, v2, v3, v0, v8}, Lcom/github/catvod/spider/XYQHiker;->ԭ(Ljava/lang/String;Ljava/util/Map;Ljava/lang/String;Ljava/util/Map;)Ljava/lang/String;

    move-result-object v0
    :try_end_223
    .catch Ljava/lang/Exception; {:try_start_1c4 .. :try_end_223} :catch_2a5

    :goto_223
    move-object v10, v0

    :try_start_224
    const-string v0, "9AFCC0B4DFE194EFF0B6FBEA95D8D7B8F0C89AEDD2B6FAC5"

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 31
    invoke-virtual {v10, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    if-nez v0, :cond_2a2

    invoke-static {v10}, Lcom/github/catvod/spider/XYQHiker;->checkveriry(Ljava/lang/String;)Z

    move-result v0
    :try_end_234
    .catch Ljava/lang/Exception; {:try_start_224 .. :try_end_234} :catch_237

    if-nez v0, :cond_2a2

    return-object v10

    :catch_237
    move-exception v0

    move-object/from16 v16, v10

    goto/16 :goto_2b3

    .line 32
    :cond_23c
    :try_start_23c
    new-instance v10, Lorg/json/JSONObject;

    invoke-direct {v10, v0}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    const-string v0, "1F3134"

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 33
    invoke-virtual {v10, v0}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const-string v10, "1D29"

    invoke-static {v10}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v0, v10}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_2a0

    .line 34
    invoke-virtual {v8, v9}, Ljava/util/HashMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    if-nez v3, :cond_263

    .line 35
    iget-object v0, v1, Lcom/github/catvod/spider/XYQHiker;->ހ:Ljava/lang/String;

    invoke-virtual {v1, v2, v0, v8}, Lcom/github/catvod/spider/XYQHiker;->Ԭ(Ljava/lang/String;Ljava/lang/String;Ljava/util/Map;)Ljava/lang/String;

    move-result-object v0

    goto :goto_269

    .line 36
    :cond_263
    iget-object v0, v1, Lcom/github/catvod/spider/XYQHiker;->ހ:Ljava/lang/String;

    invoke-virtual {v1, v2, v3, v0, v8}, Lcom/github/catvod/spider/XYQHiker;->ԭ(Ljava/lang/String;Ljava/util/Map;Ljava/lang/String;Ljava/util/Map;)Ljava/lang/String;

    move-result-object v0
    :try_end_269
    .catch Ljava/lang/Exception; {:try_start_23c .. :try_end_269} :catch_2a5

    :goto_269
    move-object v10, v0

    :try_start_26a
    const-string v0, "96FADEB9FCC59BE0C2B6E3C594D1DEB5E7D89DFEDFB7CAD895F6F1B7CDF29BD5E7B8CDF09BD8C7B5E2FE"

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 37
    invoke-virtual {v10, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    if-eqz v0, :cond_28d

    .line 38
    sget-object v0, Ljava/util/concurrent/TimeUnit;->SECONDS:Ljava/util/concurrent/TimeUnit;

    const-wide/16 v13, 0x6

    invoke-virtual {v0, v13, v14}, Ljava/util/concurrent/TimeUnit;->sleep(J)V

    if-nez v3, :cond_286

    .line 39
    iget-object v0, v1, Lcom/github/catvod/spider/XYQHiker;->ހ:Ljava/lang/String;

    invoke-virtual {v1, v2, v0, v8}, Lcom/github/catvod/spider/XYQHiker;->Ԭ(Ljava/lang/String;Ljava/lang/String;Ljava/util/Map;)Ljava/lang/String;

    move-result-object v0

    goto :goto_28c

    .line 40
    :cond_286
    iget-object v0, v1, Lcom/github/catvod/spider/XYQHiker;->ހ:Ljava/lang/String;

    invoke-virtual {v1, v2, v3, v0, v8}, Lcom/github/catvod/spider/XYQHiker;->ԭ(Ljava/lang/String;Ljava/util/Map;Ljava/lang/String;Ljava/util/Map;)Ljava/lang/String;

    move-result-object v0

    :goto_28c
    move-object v10, v0

    :cond_28d
    const-string v0, "9AFCC0B4DFE19BE8DFB9F5C595E2D2"

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 41
    invoke-virtual {v10, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    if-nez v0, :cond_2a2

    invoke-static {v10}, Lcom/github/catvod/spider/XYQHiker;->checkveriry(Ljava/lang/String;)Z

    move-result v0
    :try_end_29d
    .catch Ljava/lang/Exception; {:try_start_26a .. :try_end_29d} :catch_237

    if-nez v0, :cond_2a2

    return-object v10

    :cond_2a0
    move-object/from16 v10, v16

    :cond_2a2
    move-object/from16 v16, v10

    goto :goto_2d6

    :catch_2a5
    move-exception v0

    goto :goto_2b3

    :catch_2a7
    move-exception v0

    move-object v9, v13

    :goto_2a9
    move-object v12, v15

    goto :goto_2b3

    :catch_2ab
    move-exception v0

    goto :goto_2b2

    :catch_2ad
    move-exception v0

    move/from16 v17, v11

    move-object/from16 v16, v12

    :goto_2b2
    move-object v12, v10

    .line 42
    :goto_2b3
    invoke-static {v0}, Lcom/github/catvod/crawler/SpiderDebug;->log(Ljava/lang/Throwable;)V

    .line 43
    iget-boolean v10, v1, Lcom/github/catvod/spider/XYQHiker;->ވ:Z

    if-eqz v10, :cond_2d6

    .line 44
    new-instance v10, Ljava/lang/StringBuilder;

    invoke-direct {v10}, Ljava/lang/StringBuilder;-><init>()V

    const-string v11, "1D2121B8F0C89AEDD2B4DDFE9BD6CABEE6DE"

    invoke-static {v11}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v11

    invoke-virtual {v10, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/Exception;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v10, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v10}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lcom/github/catvod/spider/Init;->show(Ljava/lang/String;)V

    :cond_2d6
    :goto_2d6
    add-int/lit8 v11, v17, 0x1

    const/4 v0, 0x4

    if-lt v11, v0, :cond_2dc

    return-object v16

    :cond_2dc
    move-object v10, v12

    move-object/from16 v12, v16

    goto/16 :goto_3a
.end method

.method private ފ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    .registers 34

    move-object/from16 v1, p0

    move-object/from16 v2, p1

    const-string v0, "2E3924350639"

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const-string v3, "0911363028271A12342C"

    invoke-static {v3}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    const-string v4, "94D2CFB6EEE69AF7E4B4FDCF9BE3E6B6FAC5"

    invoke-static {v4}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    const-string v5, "220D0005B2EBC5A4E2D3BCD1C2A4DEFF"

    invoke-static {v5}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    const-string v6, "94D2CFB6EEE69BD1EDB7D4E1"

    invoke-static {v6}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    const-string v7, "95FFC2B8FBF195FEC5B6FAC594E2EFB4E6CB"

    invoke-static {v7}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    const-string v8, "1F266679"

    invoke-static {v8}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    const-string v9, "42"

    invoke-static {v9}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    const-string v10, "43"

    invoke-static {v10}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    const-string v11, ""

    .line 1
    :try_start_3c
    invoke-virtual/range {p0 .. p0}, Lcom/github/catvod/spider/XYQHiker;->Ԯ()V

    .line 2
    invoke-direct {v1, v7}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v12

    invoke-virtual {v12}, Ljava/lang/String;->isEmpty()Z

    move-result v12

    if-nez v12, :cond_4a

    goto :goto_50

    :cond_4a
    const-string v7, "312D373834232D243C23372506"

    invoke-static {v7}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    .line 3
    :goto_50
    invoke-direct {v1, v6}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v12

    invoke-virtual {v12}, Ljava/lang/String;->isEmpty()Z

    move-result v12

    if-nez v12, :cond_5b

    goto :goto_61

    :cond_5b
    const-string v6, "01273223392C2D37213D"

    invoke-static {v6}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    .line 4
    :goto_61
    invoke-direct {v1, v5}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v12

    invoke-virtual {v12}, Ljava/lang/String;->isEmpty()Z

    move-result v12

    if-nez v12, :cond_6c

    goto :goto_72

    :cond_6c
    const-string v5, "0127320E0A30302D3728"

    invoke-static {v5}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    .line 5
    :goto_72
    invoke-direct {v1, v4}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v12

    invoke-virtual {v12}, Ljava/lang/String;->isEmpty()Z

    move-result v12

    if-nez v12, :cond_7d

    goto :goto_83

    :cond_7d
    const-string v4, "0127320E3C2D003127213B2317"

    invoke-static {v4}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    :goto_83
    const-string v12, "2716157C62"

    invoke-static {v12}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v12

    .line 6
    invoke-direct {v1, v7, v12}, Lcom/github/catvod/spider/XYQHiker;->ރ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    iput-object v7, v1, Lcom/github/catvod/spider/XYQHiker;->ހ:Ljava/lang/String;

    .line 7
    invoke-direct {v1, v4, v10}, Lcom/github/catvod/spider/XYQHiker;->ރ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    invoke-static {v7}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v7

    invoke-static {v7}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v7

    .line 8
    invoke-virtual {v7, v9}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v12

    const/4 v13, 0x1

    if-eqz v12, :cond_ac

    .line 9
    invoke-static/range {p2 .. p2}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v4

    sub-int/2addr v4, v13

    invoke-static {v4}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v4

    goto :goto_be

    .line 10
    :cond_ac
    invoke-static/range {p2 .. p2}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v12

    sub-int/2addr v12, v13

    invoke-direct {v1, v4, v10}, Lcom/github/catvod/spider/XYQHiker;->ރ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-static {v4}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v4

    add-int/2addr v12, v4

    invoke-static {v12}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v4

    .line 11
    :goto_be
    invoke-direct {v1, v6}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    .line 12
    invoke-virtual {v6, v3}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v12

    if-eqz v12, :cond_ca

    move-object v12, v9

    goto :goto_cb

    :cond_ca
    move-object v12, v10

    .line 13
    :goto_cb
    invoke-virtual {v6, v3}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v3

    const/4 v14, 0x0

    if-nez v3, :cond_f4

    .line 14
    invoke-virtual {v4, v9}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_e3

    invoke-static {v4}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v3

    invoke-static {v12}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v15

    if-lt v3, v15, :cond_e3

    return-object v14

    .line 15
    :cond_e3
    invoke-virtual {v4, v9}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_f4

    invoke-static {v4}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v3

    invoke-static {v12}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v12

    if-le v3, v12, :cond_f4

    return-object v14

    :cond_f4
    const-string v3, "142B21222E141325366C"

    invoke-static {v3}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    .line 16
    invoke-virtual {v6, v3}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v3

    const/4 v12, 0x0

    if-eqz v3, :cond_14b

    .line 17
    invoke-virtual {v4, v9}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3
    :try_end_105
    .catch Ljava/lang/Exception; {:try_start_3c .. :try_end_105} :catch_b10

    const-string v15, "2E1935382837061232363F79"

    invoke-static {v15}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v15

    if-eqz v3, :cond_126

    :try_start_10d
    invoke-virtual {v7, v9}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_126

    .line 18
    invoke-virtual {v6, v15}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v3

    aget-object v3, v3, v13

    const-string v6, "2E1F"

    invoke-static {v6}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v3, v6}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v3

    aget-object v6, v3, v12

    goto :goto_14b

    .line 19
    :cond_126
    invoke-virtual {v4, v10}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_145

    invoke-virtual {v7, v10}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_145

    .line 20
    invoke-virtual {v6, v15}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v3

    aget-object v3, v3, v13

    const-string v6, "2E1F"

    invoke-static {v6}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v3, v6}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v3

    aget-object v6, v3, v12

    goto :goto_14b

    .line 21
    :cond_145
    invoke-virtual {v6, v15}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v3

    aget-object v6, v3, v12

    .line 22
    :cond_14b
    :goto_14b
    iget-object v3, v1, Lcom/github/catvod/spider/XYQHiker;->ހ:Ljava/lang/String;

    invoke-static {v2, v3}, Ljava/net/URLEncoder;->encode(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    .line 23
    invoke-virtual {v6, v0, v3}, Ljava/lang/String;->replaceAll(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    const-string v6, "2E3900343B36112A03360639"

    invoke-static {v6}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v3, v6, v4}, Ljava/lang/String;->replaceAll(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    const-string v6, "49"

    invoke-static {v6}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    .line 24
    invoke-virtual {v3, v6}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v6

    aget-object v6, v6, v12

    .line 25
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v15

    const-wide/16 v17, 0x3e8

    div-long v15, v15, v17

    invoke-static/range {v15 .. v16}, Ljava/lang/String;->valueOf(J)Ljava/lang/String;

    move-result-object v7

    .line 26
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v15

    invoke-static/range {v15 .. v16}, Ljava/lang/String;->valueOf(J)Ljava/lang/String;

    move-result-object v15

    const-string v13, "94D5E5B8CDF094CAE0"

    invoke-static {v13}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v13

    .line 27
    invoke-virtual {v6, v13, v7}, Ljava/lang/String;->replaceAll(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    const-string v7, "94D5E5B8CDF094E2D4"

    invoke-static {v7}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    .line 28
    invoke-virtual {v6, v7, v15}, Ljava/lang/String;->replaceAll(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    .line 29
    invoke-virtual {v6, v8}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v7
    :try_end_197
    .catch Ljava/lang/Exception; {:try_start_10d .. :try_end_197} :catch_b10

    const-string v13, "5B"

    invoke-static {v13}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v13

    if-eqz v7, :cond_1c5

    .line 30
    :try_start_19f
    invoke-static {v6, v8, v13}, Lcom/github/catvod/spider/xbpqxyq/xyq/ވ;->އ(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/util/ArrayList;

    move-result-object v7

    invoke-virtual {v7, v12}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Ljava/lang/String;

    .line 31
    new-instance v15, Ljava/lang/StringBuilder;

    invoke-direct {v15}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v15, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v15, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v15, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v15}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v8

    sget-object v15, Lcom/github/catvod/spider/xbpqxyq/xyq/ކ;->ԩ:Ljava/nio/charset/Charset;

    invoke-static {v7, v15}, Lcom/github/catvod/spider/xbpqxyq/xyq/ކ;->Ϳ(Ljava/lang/String;Ljava/nio/charset/Charset;)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v6, v8, v7}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object v6

    :cond_1c5
    const-string v7, "49323C222E"

    invoke-static {v7}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    .line 32
    invoke-virtual {v3, v7}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v3
    :try_end_1cf
    .catch Ljava/lang/Exception; {:try_start_19f .. :try_end_1cf} :catch_b10

    const-string v7, "01273223392C"

    invoke-static {v7}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    if-eqz v3, :cond_2cc

    .line 33
    :try_start_1d7
    invoke-direct {v1, v5}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v3, v0, v2}, Ljava/lang/String;->replaceAll(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const-string v3, "2E3900343B36112A03360639"

    invoke-static {v3}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v0, v3, v4}, Ljava/lang/String;->replaceAll(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v0

    const-string v3, "9DFFC8"

    invoke-static {v3}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    const-string v4, "09"

    invoke-static {v4}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    .line 34
    invoke-virtual {v0, v3, v4}, Ljava/lang/String;->replaceAll(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const-string v3, "9DFFCE"

    invoke-static {v3}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    const-string v4, "0F"

    invoke-static {v4}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v0, v3, v4}, Ljava/lang/String;->replaceAll(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 35
    invoke-virtual {v0}, Ljava/lang/String;->isEmpty()Z

    move-result v3

    if-nez v3, :cond_2be

    const-string v3, "09"

    invoke-static {v3}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    .line 36
    invoke-virtual {v0, v3}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v3

    if-eqz v3, :cond_240

    const-string v3, "0F"

    invoke-static {v3}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v0, v3}, Ljava/lang/String;->endsWith(Ljava/lang/String;)Z

    move-result v3

    if-eqz v3, :cond_240

    .line 37
    new-instance v3, Lorg/json/JSONObject;

    invoke-direct {v3, v0}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    .line 38
    invoke-virtual {v3}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object v0

    iget-object v3, v1, Lcom/github/catvod/spider/XYQHiker;->ހ:Ljava/lang/String;

    invoke-virtual {v1, v6}, Lcom/github/catvod/spider/XYQHiker;->ބ(Ljava/lang/String;)Ljava/util/HashMap;

    move-result-object v4

    invoke-virtual {v1, v6, v0, v3, v4}, Lcom/github/catvod/spider/XYQHiker;->Ϳ(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/util/Map;)Ljava/lang/String;

    move-result-object v0

    goto/16 :goto_2c9

    .line 39
    :cond_240
    new-instance v3, Ljava/util/LinkedHashMap;

    invoke-direct {v3}, Ljava/util/LinkedHashMap;-><init>()V

    const-string v4, "54"

    invoke-static {v4}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    .line 40
    invoke-virtual {v0, v4}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v0

    .line 41
    array-length v4, v0

    const/4 v5, 0x0

    :goto_251
    if-ge v5, v4, :cond_270

    aget-object v8, v0, v5

    const-string v15, "4F"

    invoke-static {v15}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v15

    .line 42
    invoke-virtual {v8, v15}, Ljava/lang/String;->indexOf(Ljava/lang/String;)I

    move-result v15

    .line 43
    invoke-virtual {v8, v12, v15}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v14

    add-int/lit8 v15, v15, 0x1

    .line 44
    invoke-virtual {v8, v15}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v8

    .line 45
    invoke-virtual {v3, v14, v8}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    add-int/lit8 v5, v5, 0x1

    const/4 v14, 0x0

    goto :goto_251

    .line 46
    :cond_270
    iget-object v0, v1, Lcom/github/catvod/spider/XYQHiker;->ހ:Ljava/lang/String;

    invoke-virtual {v1, v6}, Lcom/github/catvod/spider/XYQHiker;->ބ(Ljava/lang/String;)Ljava/util/HashMap;

    move-result-object v4

    invoke-virtual {v1, v6, v3, v0, v4}, Lcom/github/catvod/spider/XYQHiker;->ԭ(Ljava/lang/String;Ljava/util/Map;Ljava/lang/String;Ljava/util/Map;)Ljava/lang/String;

    move-result-object v0

    const-string v4, "9AFCC0B4DFE19BE8DFB9F5C595E2D2"

    invoke-static {v4}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    .line 47
    invoke-virtual {v0, v4}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v4

    if-nez v4, :cond_292

    const-string v4, "9AFCC0B4DFE194EFF0B6FBEA95D8D7B8F0C89AEDD2B6FAC5"

    invoke-static {v4}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v0, v4}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v4

    if-eqz v4, :cond_2a0

    :cond_292
    invoke-static {v0}, Lcom/github/catvod/spider/XYQHiker;->checkveriry(Ljava/lang/String;)Z

    move-result v4

    if-eqz v4, :cond_2a0

    .line 48
    invoke-static {v0}, Lcom/github/catvod/spider/XYQHiker;->vertype(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-direct {v1, v6, v3, v7, v0}, Lcom/github/catvod/spider/XYQHiker;->ވ(Ljava/lang/String;Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    :cond_2a0
    const-string v4, "96FADEB9FCC59BE0C2B6E3C594D1DEB5E7D89DFEDFB7CAD895F6F1B7CDF29BD5E7B8CDF09BD8C7B5E2FE"

    invoke-static {v4}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    .line 49
    invoke-virtual {v0, v4}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v4

    if-eqz v4, :cond_2c9

    .line 50
    sget-object v0, Ljava/util/concurrent/TimeUnit;->SECONDS:Ljava/util/concurrent/TimeUnit;

    const-wide/16 v4, 0x6

    invoke-virtual {v0, v4, v5}, Ljava/util/concurrent/TimeUnit;->sleep(J)V

    .line 51
    iget-object v0, v1, Lcom/github/catvod/spider/XYQHiker;->ހ:Ljava/lang/String;

    invoke-virtual {v1, v6}, Lcom/github/catvod/spider/XYQHiker;->ބ(Ljava/lang/String;)Ljava/util/HashMap;

    move-result-object v4

    invoke-virtual {v1, v6, v3, v0, v4}, Lcom/github/catvod/spider/XYQHiker;->ԭ(Ljava/lang/String;Ljava/util/Map;Ljava/lang/String;Ljava/util/Map;)Ljava/lang/String;

    move-result-object v0

    goto :goto_2c9

    .line 52
    :cond_2be
    iget-object v0, v1, Lcom/github/catvod/spider/XYQHiker;->ހ:Ljava/lang/String;

    invoke-virtual {v1, v6}, Lcom/github/catvod/spider/XYQHiker;->ބ(Ljava/lang/String;)Ljava/util/HashMap;

    move-result-object v3

    const/4 v4, 0x0

    invoke-virtual {v1, v6, v4, v0, v3}, Lcom/github/catvod/spider/XYQHiker;->ԭ(Ljava/lang/String;Ljava/util/Map;Ljava/lang/String;Ljava/util/Map;)Ljava/lang/String;

    move-result-object v0

    :cond_2c9
    :goto_2c9
    const/4 v3, 0x0

    goto/16 :goto_354

    .line 53
    :cond_2cc
    iget-object v0, v1, Lcom/github/catvod/spider/XYQHiker;->ހ:Ljava/lang/String;

    invoke-virtual {v1, v6}, Lcom/github/catvod/spider/XYQHiker;->ބ(Ljava/lang/String;)Ljava/util/HashMap;

    move-result-object v3

    invoke-virtual {v1, v6, v0, v3}, Lcom/github/catvod/spider/XYQHiker;->Ԭ(Ljava/lang/String;Ljava/lang/String;Ljava/util/Map;)Ljava/lang/String;

    move-result-object v0

    const-string v3, "94E1D3B7EFCF96FAFE"

    invoke-static {v3}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    .line 54
    invoke-virtual {v0, v3}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v3

    if-eqz v3, :cond_2f2

    const-string v3, "103624303C"

    invoke-static {v3}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v0, v3}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v3

    if-eqz v3, :cond_2f2

    .line 55
    invoke-direct {v1, v6, v0, v7}, Lcom/github/catvod/spider/XYQHiker;->އ(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    :cond_2f2
    const-string v3, "5D2A26303E2B1C250C"

    invoke-static {v3}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    .line 56
    invoke-virtual {v0, v3}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v3

    if-nez v3, :cond_30a

    const-string v3, "5D30363F302D2D"

    invoke-static {v3}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v0, v3}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v3

    if-eqz v3, :cond_30e

    .line 57
    :cond_30a
    invoke-direct {v1, v6, v0, v7}, Lcom/github/catvod/spider/XYQHiker;->ކ(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    :cond_30e
    const-string v3, "9AFCC0B4DFE19BE8DFB9F5C595E2D2"

    invoke-static {v3}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    .line 58
    invoke-virtual {v0, v3}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v3

    if-nez v3, :cond_326

    const-string v3, "9AFCC0B4DFE194EFF0B6FBEA95D8D7B8F0C89AEDD2B6FAC5"

    invoke-static {v3}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v0, v3}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v3

    if-eqz v3, :cond_336

    :cond_326
    invoke-static {v0}, Lcom/github/catvod/spider/XYQHiker;->checkveriry(Ljava/lang/String;)Z

    move-result v3

    if-eqz v3, :cond_336

    .line 59
    invoke-static {v0}, Lcom/github/catvod/spider/XYQHiker;->vertype(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x0

    invoke-direct {v1, v6, v3, v7, v0}, Lcom/github/catvod/spider/XYQHiker;->ވ(Ljava/lang/String;Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    goto :goto_337

    :cond_336
    const/4 v3, 0x0

    :goto_337
    const-string v4, "96FADEB9FCC59BE0C2B6E3C594D1DEB5E7D89DFEDFB7CAD895F6F1B7CDF29BD5E7B8CDF09BD8C7B5E2FE"

    invoke-static {v4}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    .line 60
    invoke-virtual {v0, v4}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v4

    if-eqz v4, :cond_354

    .line 61
    sget-object v0, Ljava/util/concurrent/TimeUnit;->SECONDS:Ljava/util/concurrent/TimeUnit;

    const-wide/16 v4, 0x6

    invoke-virtual {v0, v4, v5}, Ljava/util/concurrent/TimeUnit;->sleep(J)V

    .line 62
    iget-object v0, v1, Lcom/github/catvod/spider/XYQHiker;->ހ:Ljava/lang/String;

    invoke-virtual {v1, v6}, Lcom/github/catvod/spider/XYQHiker;->ބ(Ljava/lang/String;)Ljava/util/HashMap;

    move-result-object v4

    invoke-virtual {v1, v6, v0, v4}, Lcom/github/catvod/spider/XYQHiker;->Ԭ(Ljava/lang/String;Ljava/lang/String;Ljava/util/Map;)Ljava/lang/String;

    move-result-object v0

    .line 63
    :cond_354
    :goto_354
    invoke-static {v0}, Lcom/github/catvod/spider/XYQHiker;->ԩ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const-string v4, "94D2CFB6EEE694CAF9B4D5D294EAF2B4E6CB"

    invoke-static {v4}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    .line 64
    invoke-direct {v1, v4}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/String;->isEmpty()Z

    move-result v4

    if-nez v4, :cond_36f

    const-string v4, "94D2CFB6EEE694CAF9B4D5D294EAF2B4E6CB"

    invoke-static {v4}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    goto :goto_375

    :cond_36f
    const-string v4, "01273223392C2D2F3C353F"

    invoke-static {v4}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    :goto_375
    const-string v5, "94D2CFB6EEE695CBD4B4D7D194DAFCB4CAE238313C242AA1F4DBB5E2CF"

    invoke-static {v5}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    .line 65
    invoke-direct {v1, v5}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/String;->isEmpty()Z

    move-result v5

    if-nez v5, :cond_38c

    const-string v5, "94D2CFB6EEE695CBD4B4D7D194DAFCB4CAE238313C242AA1F4DBB5E2CF"

    invoke-static {v5}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    goto :goto_392

    :cond_38c
    const-string v5, "0127320E33372D28203E2F34"

    invoke-static {v5}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    :goto_392
    const-string v7, "97D9EDB6D3C394DAFCB4CAE29BDED3B9FCC596F9F0B6CAC2"

    invoke-static {v7}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    .line 66
    invoke-direct {v1, v7}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v7}, Ljava/lang/String;->isEmpty()Z

    move-result v7

    if-nez v7, :cond_3a9

    const-string v7, "97D9EDB6D3C394DAFCB4CAE29BDED3B9FCC596F9F0B6CAC2"

    invoke-static {v7}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    goto :goto_3af

    :cond_3a9
    const-string v7, "222B301F3F211612213E223D"

    invoke-static {v7}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    :goto_3af
    const-string v8, "94D2CFB6EEE638313C3FBCD1C2A4DEFFBEFEFEA4FFF0BCCCD8A7DCC7"

    invoke-static {v8}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    .line 67
    invoke-direct {v1, v8}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v8}, Ljava/lang/String;->isEmpty()Z

    move-result v8

    if-nez v8, :cond_3c6

    const-string v8, "94D2CFB6EEE638313C3FBCD1C2A4DEFFBEFEFEA4FFF0BCCCD8A7DCC7"

    invoke-static {v8}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    goto :goto_3cc

    :cond_3c6
    const-string v8, "0127323B292B1C1D2726332717"

    invoke-static {v8}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    .line 68
    :goto_3cc
    invoke-direct {v1, v4}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v14

    invoke-virtual {v14, v9}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v9

    if-nez v9, :cond_3e9

    invoke-direct {v1, v4}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    const-string v9, "97D2F5"

    invoke-static {v9}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v4, v9}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_3e7

    goto :goto_3e9

    :cond_3e7
    const/4 v4, 0x0

    goto :goto_3ea

    :cond_3e9
    :goto_3e9
    const/4 v4, 0x1

    .line 69
    :goto_3ea
    invoke-direct {v1, v5, v10}, Lcom/github/catvod/spider/XYQHiker;->ރ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v9, v10}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v9
    :try_end_3f2
    .catch Ljava/lang/Exception; {:try_start_1d7 .. :try_end_3f2} :catch_b10

    const-string v14, "94DAFC"

    invoke-static {v14}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v14

    if-nez v9, :cond_407

    :try_start_3fa
    invoke-direct {v1, v5, v14}, Lcom/github/catvod/spider/XYQHiker;->ރ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v5, v14}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_405

    goto :goto_407

    :cond_405
    const/4 v5, 0x0

    goto :goto_408

    :cond_407
    :goto_407
    const/4 v5, 0x1

    .line 70
    :goto_408
    invoke-direct {v1, v7}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v9, v10}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v9

    if-nez v9, :cond_41f

    invoke-direct {v1, v7}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v7, v14}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v7

    if-eqz v7, :cond_41d

    goto :goto_41f

    :cond_41d
    const/4 v7, 0x0

    goto :goto_420

    :cond_41f
    :goto_41f
    const/4 v7, 0x1

    :goto_420
    const-string v9, "94D2CFB6EEE697CAC4B9FBEC94D7E3B6E1C09AE5D7B4D2DD"

    invoke-static {v9}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    .line 71
    invoke-direct {v1, v9}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v9}, Ljava/lang/String;->isEmpty()Z

    move-result v9

    if-nez v9, :cond_437

    const-string v9, "94D2CFB6EEE697CAC4B9FBEC94D7E3B6E1C09AE5D7B4D2DD"

    invoke-static {v9}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    goto :goto_43d

    :cond_437
    const-string v9, "0127320E3B36001D21243621"

    invoke-static {v9}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    :goto_43d
    const-string v10, "94D2CFB6EEE695CBD4B4D7D197D9EDB6D3C3"

    invoke-static {v10}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    .line 72
    invoke-direct {v1, v10}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v10}, Ljava/lang/String;->isEmpty()Z

    move-result v10

    if-nez v10, :cond_454

    const-string v10, "94D2CFB6EEE695CBD4B4D7D197D9EDB6D3C3"

    invoke-static {v10}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    goto :goto_45a

    :cond_454
    const-string v10, "0127320E2A2D11"

    invoke-static {v10}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    :goto_45a
    const-string v14, "94D2CFB6EEE695CBD4B4D7D194E2D4B8F8DC"

    invoke-static {v14}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v14

    .line 73
    invoke-direct {v1, v14}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v14

    invoke-virtual {v14}, Ljava/lang/String;->isEmpty()Z

    move-result v14

    if-nez v14, :cond_471

    const-string v14, "94D2CFB6EEE695CBD4B4D7D194E2D4B8F8DC"

    invoke-static {v14}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v14

    goto :goto_477

    :cond_471
    const-string v14, "0127320E2E2D062E36"

    invoke-static {v14}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v14

    :goto_477
    const-string v15, "94D2CFB6EEE695CBD4B4D7D19BD1EDB7D4E1"

    invoke-static {v15}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v15

    .line 74
    invoke-direct {v1, v15}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v15

    invoke-virtual {v15}, Ljava/lang/String;->isEmpty()Z

    move-result v15

    if-nez v15, :cond_48e

    const-string v15, "94D2CFB6EEE695CBD4B4D7D19BD1EDB7D4E1"

    invoke-static {v15}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v15

    goto :goto_494

    :cond_48e
    const-string v15, "0127320E2F361E"

    invoke-static {v15}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v15

    :goto_494
    const-string v3, "94D2CFB6EEE695CBD4B4D7D197CBFCB7FAC39BE0CB"

    invoke-static {v3}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    .line 75
    invoke-direct {v1, v3}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/String;->isEmpty()Z

    move-result v3

    if-nez v3, :cond_4ab

    const-string v3, "94D2CFB6EEE695CBD4B4D7D197CBFCB7FAC39BE0CB"

    invoke-static {v3}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    goto :goto_4b1

    :cond_4ab
    const-string v3, "0127320E293110363A253621"

    invoke-static {v3}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    :goto_4b1
    const-string v12, "94D2CFB6EEE695CBD4B4D7D19BD1EDB7D4E197C8F3B4D3C995FED3"

    invoke-static {v12}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v12

    .line 76
    invoke-direct {v1, v12}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v12

    invoke-virtual {v12}, Ljava/lang/String;->isEmpty()Z

    move-result v12

    if-nez v12, :cond_4c8

    const-string v12, "94D2CFB6EEE695CBD4B4D7D19BD1EDB7D4E197C8F3B4D3C995FED3"

    invoke-static {v12}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v12

    goto :goto_4ce

    :cond_4c8
    const-string v12, "01273223392C2D3221343C2D0A"

    invoke-static {v12}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v12

    :goto_4ce
    move-object/from16 v18, v13

    const-string v13, "94D2CFB6EEE695CBD4B4D7D19BD1EDB7D4E197C8F3B4CACA95FED3"

    invoke-static {v13}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v13

    .line 77
    invoke-direct {v1, v13}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v13

    invoke-virtual {v13}, Ljava/lang/String;->isEmpty()Z

    move-result v13

    if-nez v13, :cond_4e7

    const-string v13, "94D2CFB6EEE695CBD4B4D7D19BD1EDB7D4E197C8F3B4CACA95FED3"

    invoke-static {v13}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v13

    goto :goto_4ed

    :cond_4e7
    const-string v13, "01273223392C2D3126373C2D0A"

    invoke-static {v13}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v13

    :goto_4ed
    move/from16 v19, v5

    .line 78
    new-instance v5, Lorg/json/JSONObject;

    invoke-direct {v5}, Lorg/json/JSONObject;-><init>()V

    move-object/from16 v20, v5

    .line 79
    new-instance v5, Lorg/json/JSONArray;

    invoke-direct {v5}, Lorg/json/JSONArray;-><init>()V

    .line 80
    invoke-direct {v1, v8}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    .line 81
    invoke-virtual {v8}, Ljava/lang/String;->isEmpty()Z

    move-result v21
    :try_end_503
    .catch Ljava/lang/Exception; {:try_start_3fa .. :try_end_503} :catch_b10

    move-object/from16 v22, v5

    const-string v5, "5464"

    invoke-static {v5}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    if-nez v21, :cond_52f

    :try_start_50d
    invoke-virtual {v8, v5}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v21

    if-eqz v21, :cond_52f

    .line 82
    invoke-virtual {v8, v5}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v21

    move-object/from16 v23, v3

    const/4 v2, 0x0

    aget-object v3, v21, v2

    invoke-virtual {v8, v5}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v8

    const/16 v16, 0x1

    aget-object v8, v8, v16

    invoke-static {v0, v3, v8}, Lcom/github/catvod/spider/xbpqxyq/xyq/ވ;->އ(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/util/ArrayList;

    move-result-object v0

    invoke-virtual {v0, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;
    :try_end_52e
    .catch Ljava/lang/Exception; {:try_start_50d .. :try_end_52e} :catch_b10

    goto :goto_531

    :cond_52f
    move-object/from16 v23, v3

    :goto_531
    const-string v2, "566677"

    invoke-static {v2}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    const-string v3, "552B3D212F3055"

    invoke-static {v3}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    if-eqz v4, :cond_758

    .line 83
    :try_start_53f
    new-instance v4, Lorg/json/JSONObject;

    invoke-direct {v4, v0}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    const-string v0, "1E2B2025"

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 84
    invoke-direct {v1, v9, v0}, Lcom/github/catvod/spider/XYQHiker;->ރ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const-string v5, "2E6C"

    invoke-static {v5}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v0, v5}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v0

    .line 85
    array-length v5, v0

    const/4 v8, 0x1

    if-ne v5, v8, :cond_565

    const/4 v5, 0x0

    .line 86
    aget-object v0, v0, v5

    invoke-virtual {v4, v0}, Lorg/json/JSONObject;->getJSONArray(Ljava/lang/String;)Lorg/json/JSONArray;

    move-result-object v0

    :goto_563
    move-object v4, v0

    goto :goto_5b2

    .line 87
    :cond_565
    array-length v5, v0

    const/4 v8, 0x2

    if-ne v5, v8, :cond_578

    const/4 v5, 0x0

    .line 88
    aget-object v8, v0, v5

    invoke-virtual {v4, v8}, Lorg/json/JSONObject;->getJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v4

    const/4 v5, 0x1

    aget-object v0, v0, v5

    invoke-virtual {v4, v0}, Lorg/json/JSONObject;->getJSONArray(Ljava/lang/String;)Lorg/json/JSONArray;

    move-result-object v0

    goto :goto_563

    .line 89
    :cond_578
    array-length v5, v0

    const/4 v9, 0x3

    if-ne v5, v9, :cond_591

    const/4 v5, 0x0

    .line 90
    aget-object v9, v0, v5

    invoke-virtual {v4, v9}, Lorg/json/JSONObject;->getJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v4

    const/4 v5, 0x1

    aget-object v5, v0, v5

    invoke-virtual {v4, v5}, Lorg/json/JSONObject;->getJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v4

    aget-object v0, v0, v8

    invoke-virtual {v4, v0}, Lorg/json/JSONObject;->getJSONArray(Ljava/lang/String;)Lorg/json/JSONArray;

    move-result-object v0

    goto :goto_563

    .line 91
    :cond_591
    array-length v5, v0

    const/4 v9, 0x4

    if-ne v5, v9, :cond_5b1

    const/4 v5, 0x0

    .line 92
    aget-object v9, v0, v5

    invoke-virtual {v4, v9}, Lorg/json/JSONObject;->getJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v4

    const/4 v5, 0x1

    aget-object v5, v0, v5

    invoke-virtual {v4, v5}, Lorg/json/JSONObject;->getJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v4

    aget-object v5, v0, v8

    invoke-virtual {v4, v5}, Lorg/json/JSONObject;->getJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v4

    const/4 v5, 0x3

    aget-object v0, v0, v5

    invoke-virtual {v4, v0}, Lorg/json/JSONObject;->getJSONArray(Ljava/lang/String;)Lorg/json/JSONArray;

    move-result-object v0

    goto :goto_563

    :cond_5b1
    const/4 v4, 0x0

    :goto_5b2
    move-object v8, v11

    move-object v9, v8

    const/4 v5, 0x0

    .line 93
    :goto_5b5
    invoke-virtual {v4}, Lorg/json/JSONArray;->length()I

    move-result v0
    :try_end_5b9
    .catch Ljava/lang/Exception; {:try_start_53f .. :try_end_5b9} :catch_b10

    if-ge v5, v0, :cond_754

    move-object/from16 p2, v8

    .line 94
    :try_start_5bd
    invoke-virtual {v4, v5}, Lorg/json/JSONArray;->getJSONObject(I)Lorg/json/JSONObject;

    move-result-object v8

    const-string v0, "1C233E34"

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 95
    invoke-direct {v1, v14, v0}, Lcom/github/catvod/spider/XYQHiker;->ރ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v8, v0}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0
    :try_end_5cf
    .catch Ljava/lang/Exception; {:try_start_5bd .. :try_end_5cf} :catch_710

    move-object/from16 v16, v4

    :try_start_5d1
    invoke-virtual {v0}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v4

    const-string v0, "1B26"

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 96
    invoke-direct {v1, v15, v0}, Lcom/github/catvod/spider/XYQHiker;->ރ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v8, v0}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v0
    :try_end_5e7
    .catch Ljava/lang/Exception; {:try_start_5d1 .. :try_end_5e7} :catch_70e

    move-object/from16 v17, v9

    .line 97
    :try_start_5e9
    new-instance v9, Ljava/lang/StringBuilder;

    invoke-direct {v9}, Ljava/lang/StringBuilder;-><init>()V
    :try_end_5ee
    .catch Ljava/lang/Exception; {:try_start_5e9 .. :try_end_5ee} :catch_6fe

    move-object/from16 v21, v15

    :try_start_5f0
    invoke-direct {v1, v12, v11}, Lcom/github/catvod/spider/XYQHiker;->ރ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v15

    invoke-virtual {v9, v15}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v9, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-direct {v1, v13, v11}, Lcom/github/catvod/spider/XYQHiker;->ރ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v15

    invoke-virtual {v9, v15}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v9}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v9

    .line 98
    invoke-virtual {v9, v3}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v15
    :try_end_609
    .catch Ljava/lang/Exception; {:try_start_5f0 .. :try_end_609} :catch_6fa

    if-eqz v15, :cond_61f

    .line 99
    :try_start_60b
    invoke-virtual {v9, v3, v0}, Ljava/lang/String;->replaceAll(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9
    :try_end_60f
    .catch Ljava/lang/Exception; {:try_start_60b .. :try_end_60f} :catch_610

    goto :goto_61f

    :catch_610
    move-exception v0

    move-object/from16 v8, p2

    move/from16 v25, v7

    :goto_615
    move-object/from16 v9, v17

    move-object/from16 v24, v23

    move-object/from16 v23, v3

    move-object/from16 v3, v22

    goto/16 :goto_721

    .line 100
    :cond_61f
    :goto_61f
    :try_start_61f
    invoke-direct {v1, v10}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/String;->isEmpty()Z

    move-result v0
    :try_end_627
    .catch Ljava/lang/Exception; {:try_start_61f .. :try_end_627} :catch_6fa

    if-nez v0, :cond_66c

    .line 101
    :try_start_629
    invoke-direct {v1, v10}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const-string v15, "1A362721"

    invoke-static {v15}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v15

    invoke-virtual {v0, v15}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_63f

    .line 102
    invoke-direct {v1, v10}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    :goto_63d
    move-object v15, v0

    goto :goto_656

    :cond_63f
    const-string v0, "022B30"

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 103
    invoke-direct {v1, v10, v0}, Lcom/github/catvod/spider/XYQHiker;->ރ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v8, v0}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v15
    :try_end_651
    .catch Ljava/lang/Exception; {:try_start_629 .. :try_end_651} :catch_660

    .line 104
    :try_start_651
    invoke-static {v6, v15}, Lcom/github/catvod/spider/xbpqxyq/xyq/ވ;->Ԫ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    goto :goto_63d

    :goto_656
    if-eqz v7, :cond_66e

    .line 105
    invoke-virtual {v1, v15, v6, v7}, Lcom/github/catvod/spider/XYQHiker;->ԯ(Ljava/lang/String;Ljava/lang/String;Z)Ljava/lang/String;

    move-result-object v0
    :try_end_65c
    .catch Ljava/lang/Exception; {:try_start_651 .. :try_end_65c} :catch_65e

    move-object v15, v0

    goto :goto_66e

    :catch_65e
    move-exception v0

    goto :goto_663

    :catch_660
    move-exception v0

    move-object/from16 v15, p2

    .line 106
    :goto_663
    :try_start_663
    invoke-static {v0}, Lcom/github/catvod/crawler/SpiderDebug;->log(Ljava/lang/Throwable;)V
    :try_end_666
    .catch Ljava/lang/Exception; {:try_start_663 .. :try_end_666} :catch_667

    goto :goto_66e

    :catch_667
    move-exception v0

    move/from16 v25, v7

    move-object v8, v15

    goto :goto_615

    :cond_66c
    move-object/from16 v15, p2

    :cond_66e
    :goto_66e
    move-object/from16 v30, v23

    move-object/from16 v23, v3

    move-object/from16 v3, v30

    .line 107
    :try_start_674
    invoke-direct {v1, v3}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v8, v0}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v0
    :try_end_680
    .catch Ljava/lang/Exception; {:try_start_674 .. :try_end_680} :catch_684

    move-object v8, v0

    move-object/from16 v24, v3

    goto :goto_68c

    :catch_684
    move-exception v0

    .line 108
    :try_start_685
    invoke-static {v0}, Lcom/github/catvod/crawler/SpiderDebug;->log(Ljava/lang/Throwable;)V
    :try_end_688
    .catch Ljava/lang/Exception; {:try_start_685 .. :try_end_688} :catch_6f1

    move-object/from16 v24, v3

    move-object/from16 v8, v17

    :goto_68c
    move-object/from16 v3, p1

    .line 109
    :try_start_68e
    invoke-virtual {v4, v3}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    if-eqz v0, :cond_6e1

    .line 110
    new-instance v0, Lorg/json/JSONObject;

    invoke-direct {v0}, Lorg/json/JSONObject;-><init>()V

    const-string v3, "042D370E3320"

    invoke-static {v3}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3
    :try_end_69f
    .catch Ljava/lang/Exception; {:try_start_68e .. :try_end_69f} :catch_6e9

    move/from16 v25, v7

    .line 111
    :try_start_6a1
    new-instance v7, Ljava/lang/StringBuilder;

    invoke-direct {v7}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v7, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v7, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v7, v15}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v7, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v7, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v0, v3, v7}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const-string v3, "042D370E34251F27"

    invoke-static {v3}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    .line 112
    invoke-virtual {v0, v3, v4}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const-string v3, "042D370E2A2D11"

    invoke-static {v3}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    .line 113
    invoke-virtual {v0, v3, v15}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const-string v3, "042D370E28211F23213A29"

    invoke-static {v3}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    .line 114
    invoke-virtual {v0, v3, v8}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    :try_end_6d7
    .catch Ljava/lang/Exception; {:try_start_6a1 .. :try_end_6d7} :catch_6df

    move-object/from16 v3, v22

    .line 115
    :try_start_6d9
    invoke-virtual {v3, v0}, Lorg/json/JSONArray;->put(Ljava/lang/Object;)Lorg/json/JSONArray;
    :try_end_6dc
    .catch Ljava/lang/Exception; {:try_start_6d9 .. :try_end_6dc} :catch_6dd

    goto :goto_6e5

    :catch_6dd
    move-exception v0

    goto :goto_6ee

    :catch_6df
    move-exception v0

    goto :goto_6ec

    :cond_6e1
    move/from16 v25, v7

    move-object/from16 v3, v22

    :goto_6e5
    move-object v9, v8

    move-object v8, v15

    goto/16 :goto_744

    :catch_6e9
    move-exception v0

    move/from16 v25, v7

    :goto_6ec
    move-object/from16 v3, v22

    :goto_6ee
    move-object v9, v8

    move-object v8, v15

    goto :goto_721

    :catch_6f1
    move-exception v0

    move-object/from16 v24, v3

    move/from16 v25, v7

    move-object/from16 v3, v22

    move-object v8, v15

    goto :goto_70b

    :catch_6fa
    move-exception v0

    move/from16 v25, v7

    goto :goto_703

    :catch_6fe
    move-exception v0

    move/from16 v25, v7

    move-object/from16 v21, v15

    :goto_703
    move-object/from16 v24, v23

    move-object/from16 v23, v3

    move-object/from16 v3, v22

    move-object/from16 v8, p2

    :goto_70b
    move-object/from16 v9, v17

    goto :goto_721

    :catch_70e
    move-exception v0

    goto :goto_713

    :catch_710
    move-exception v0

    move-object/from16 v16, v4

    :goto_713
    move/from16 v25, v7

    move-object/from16 v17, v9

    move-object/from16 v21, v15

    move-object/from16 v24, v23

    move-object/from16 v23, v3

    move-object/from16 v3, v22

    move-object/from16 v8, p2

    .line 116
    :goto_721
    :try_start_721
    invoke-static {v0}, Lcom/github/catvod/crawler/SpiderDebug;->log(Ljava/lang/Throwable;)V

    .line 117
    iget-boolean v4, v1, Lcom/github/catvod/spider/XYQHiker;->ވ:Z

    if-eqz v4, :cond_744

    .line 118
    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const-string v7, "94D2CFB6EEE69AE5F0B7C4D418313C3FBFC8C8A7CCCEBFC3C8ABC7C8B5F8E8"

    invoke-static {v7}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v4, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/Exception;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lcom/github/catvod/spider/Init;->show(Ljava/lang/String;)V

    :cond_744
    :goto_744
    add-int/lit8 v5, v5, 0x1

    move-object/from16 v22, v3

    move-object/from16 v4, v16

    move-object/from16 v15, v21

    move-object/from16 v3, v23

    move-object/from16 v23, v24

    move/from16 v7, v25

    goto/16 :goto_5b5

    :cond_754
    move-object/from16 v3, v22

    goto/16 :goto_b00

    :cond_758
    move/from16 v25, v7

    move-object/from16 v21, v15

    move-object/from16 v24, v23

    move-object/from16 v23, v3

    move-object/from16 v3, v22

    .line 119
    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xyq/ٱ;->Ϳ(Ljava/lang/String;)Lcom/github/catvod/spider/xbpqxyq/xyq/ǐ;

    move-result-object v0

    .line 120
    invoke-direct {v1, v12}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    .line 121
    invoke-virtual {v4, v5}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v7
    :try_end_76e
    .catch Ljava/lang/Exception; {:try_start_721 .. :try_end_76e} :catch_b10

    const-string v8, "22050C040808"

    invoke-static {v8}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    if-eqz v7, :cond_77e

    .line 122
    :try_start_776
    invoke-static {v0, v4}, Lcom/github/catvod/spider/XYQHiker;->getTextByRule(Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v4, v8, v6}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object v4

    .line 123
    :cond_77e
    invoke-virtual {v4, v8}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v7

    if-eqz v7, :cond_792

    .line 124
    invoke-virtual {v4, v8, v6}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object v4

    const-string v7, "55"

    invoke-static {v7}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v4, v7, v11}, Ljava/lang/String;->replaceAll(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    .line 125
    :cond_792
    invoke-direct {v1, v13}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    .line 126
    invoke-virtual {v7, v5}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v8

    if-eqz v8, :cond_7a0

    .line 127
    invoke-static {v0, v7}, Lcom/github/catvod/spider/XYQHiker;->getTextByRule(Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    .line 128
    :cond_7a0
    invoke-direct {v1, v9}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v8, v5}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v8

    const/4 v9, 0x0

    .line 129
    aget-object v12, v8, v9

    invoke-static {v12, v0}, Lcom/github/catvod/spider/XYQHiker;->getTrueElement(Ljava/lang/String;Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;)Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;

    move-result-object v0

    const/4 v9, 0x1

    .line 130
    :goto_7b0
    array-length v12, v8

    const/4 v13, 0x1

    sub-int/2addr v12, v13

    if-ge v9, v12, :cond_7be

    .line 131
    aget-object v12, v8, v9

    invoke-static {v12, v0}, Lcom/github/catvod/spider/XYQHiker;->getTrueElement(Ljava/lang/String;Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;)Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;

    move-result-object v0

    add-int/lit8 v9, v9, 0x1

    goto :goto_7b0

    .line 132
    :cond_7be
    array-length v9, v8

    const/4 v12, 0x1

    sub-int/2addr v9, v12

    aget-object v8, v8, v9

    invoke-static {v0, v8}, Lcom/github/catvod/spider/XYQHiker;->selectElements(Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;Ljava/lang/String;)Lcom/github/catvod/spider/xbpqxyq/xyq/ำ;

    move-result-object v8

    move-object v12, v11

    move-object v13, v12

    const/4 v9, 0x0

    .line 133
    :goto_7ca
    invoke-virtual {v8}, Ljava/util/ArrayList;->size()I

    move-result v0
    :try_end_7ce
    .catch Ljava/lang/Exception; {:try_start_776 .. :try_end_7ce} :catch_b10

    if-ge v9, v0, :cond_b00

    .line 134
    :try_start_7d0
    invoke-virtual {v8, v9}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    move-object v15, v0

    check-cast v15, Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;

    .line 135
    invoke-direct {v1, v14}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0
    :try_end_7db
    .catch Ljava/lang/Exception; {:try_start_7d0 .. :try_end_7db} :catch_aa8

    if-eqz v19, :cond_7f0

    .line 136
    :try_start_7dd
    invoke-static {v15, v0}, Lcom/github/catvod/spider/XYQHiker;->getTextByRule(Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0
    :try_end_7e1
    .catch Ljava/lang/Exception; {:try_start_7dd .. :try_end_7e1} :catch_7e9

    move-object/from16 p2, v8

    move-object/from16 v26, v12

    move-object/from16 v27, v13

    :goto_7e7
    move-object v8, v0

    goto :goto_818

    :catch_7e9
    move-exception v0

    move-object/from16 p2, v8

    move-object/from16 v22, v10

    goto/16 :goto_ab1

    :cond_7f0
    move-object/from16 p2, v8

    .line 137
    :try_start_7f2
    invoke-virtual {v15}, Lcom/github/catvod/spider/xbpqxyq/xyq/ւ;->ދ()Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v0, v5}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v22
    :try_end_7fa
    .catch Ljava/lang/Exception; {:try_start_7f2 .. :try_end_7fa} :catch_aa6

    move-object/from16 v26, v12

    move-object/from16 v27, v13

    const/4 v12, 0x0

    :try_start_7ff
    aget-object v13, v22, v12

    invoke-virtual {v0, v5}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v0
    :try_end_805
    .catch Ljava/lang/Exception; {:try_start_7ff .. :try_end_805} :catch_a80

    const/16 v16, 0x1

    :try_start_807
    aget-object v0, v0, v16
    :try_end_809
    .catch Ljava/lang/Exception; {:try_start_807 .. :try_end_809} :catch_a9c

    :try_start_809
    invoke-static {v8, v13, v0}, Lcom/github/catvod/spider/xbpqxyq/xyq/ވ;->އ(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/util/ArrayList;

    move-result-object v0

    invoke-virtual {v0, v12}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    invoke-virtual {v1, v0}, Lcom/github/catvod/spider/XYQHiker;->މ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    goto :goto_7e7

    .line 138
    :goto_818
    invoke-direct {v1, v10}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/String;->isEmpty()Z

    move-result v0
    :try_end_820
    .catch Ljava/lang/Exception; {:try_start_809 .. :try_end_820} :catch_a80

    if-nez v0, :cond_8ff

    .line 139
    :try_start_822
    invoke-direct {v1, v10}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const-string v12, "1A362721"

    invoke-static {v12}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v12

    invoke-virtual {v0, v12}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_83d

    .line 140
    invoke-direct {v1, v10}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    move-object v12, v0

    move-object/from16 v22, v10

    move-object/from16 v13, v18

    goto/16 :goto_8c0

    .line 141
    :cond_83d
    invoke-direct {v1, v10}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    if-eqz v19, :cond_84f

    .line 142
    invoke-static {v15, v0}, Lcom/github/catvod/spider/XYQHiker;->getTextByRule(Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v0

    move-object v12, v0

    move-object/from16 v22, v10

    goto :goto_86f

    .line 143
    :cond_84f
    invoke-virtual {v15}, Lcom/github/catvod/spider/xbpqxyq/xyq/ւ;->ދ()Ljava/lang/String;

    move-result-object v12

    invoke-virtual {v0, v5}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v13
    :try_end_857
    .catch Ljava/lang/Exception; {:try_start_822 .. :try_end_857} :catch_8d9

    move-object/from16 v22, v10

    const/4 v10, 0x0

    :try_start_85a
    aget-object v13, v13, v10

    invoke-virtual {v0, v5}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v0

    const/16 v16, 0x1

    aget-object v0, v0, v16

    invoke-static {v12, v13, v0}, Lcom/github/catvod/spider/xbpqxyq/xyq/ވ;->އ(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/util/ArrayList;

    move-result-object v0

    invoke-virtual {v0, v10}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;
    :try_end_86e
    .catch Ljava/lang/Exception; {:try_start_85a .. :try_end_86e} :catch_8d7

    move-object v12, v0

    :goto_86f
    :try_start_86f
    const-string v0, "07303F79"

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 144
    invoke-virtual {v12, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    if-eqz v0, :cond_8b9

    const-string v0, "2E642224353049"

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 145
    invoke-virtual {v12, v0, v11}, Ljava/lang/String;->replaceAll(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const-string v10, "07303F0D72"

    invoke-static {v10}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v0, v10}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v0

    .line 146
    array-length v10, v0

    const/4 v13, 0x1

    if-le v10, v13, :cond_8b9

    aget-object v10, v0, v13
    :try_end_895
    .catch Ljava/lang/Exception; {:try_start_86f .. :try_end_895} :catch_8d1

    move-object/from16 v13, v18

    :try_start_897
    invoke-virtual {v10, v13}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v10

    if-eqz v10, :cond_8bb

    const/4 v10, 0x1

    .line 147
    aget-object v0, v0, v10

    const-string v10, "2E6B"

    invoke-static {v10}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v0, v10}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v0

    const/4 v10, 0x0

    aget-object v0, v0, v10

    const-string v10, "2965710C"

    invoke-static {v10}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v0, v10, v11}, Ljava/lang/String;->replaceAll(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    move-object v12, v0

    goto :goto_8bb

    :cond_8b9
    move-object/from16 v13, v18

    .line 148
    :cond_8bb
    :goto_8bb
    invoke-static {v6, v12}, Lcom/github/catvod/spider/xbpqxyq/xyq/ވ;->Ԫ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0
    :try_end_8bf
    .catch Ljava/lang/Exception; {:try_start_897 .. :try_end_8bf} :catch_8cf

    move-object v12, v0

    :goto_8c0
    if-eqz v25, :cond_8cc

    move/from16 v10, v25

    .line 149
    :try_start_8c4
    invoke-virtual {v1, v12, v6, v10}, Lcom/github/catvod/spider/XYQHiker;->ԯ(Ljava/lang/String;Ljava/lang/String;Z)Ljava/lang/String;

    move-result-object v0
    :try_end_8c8
    .catch Ljava/lang/Exception; {:try_start_8c4 .. :try_end_8c8} :catch_8ca

    move-object v12, v0

    goto :goto_8e5

    :catch_8ca
    move-exception v0

    goto :goto_8e2

    :cond_8cc
    move/from16 v10, v25

    goto :goto_8e5

    :catch_8cf
    move-exception v0

    goto :goto_8d4

    :catch_8d1
    move-exception v0

    move-object/from16 v13, v18

    :goto_8d4
    move/from16 v10, v25

    goto :goto_8e2

    :catch_8d7
    move-exception v0

    goto :goto_8dc

    :catch_8d9
    move-exception v0

    move-object/from16 v22, v10

    :goto_8dc
    move-object/from16 v13, v18

    move/from16 v10, v25

    move-object/from16 v12, v26

    .line 150
    :goto_8e2
    :try_start_8e2
    invoke-static {v0}, Lcom/github/catvod/crawler/SpiderDebug;->log(Ljava/lang/Throwable;)V
    :try_end_8e5
    .catch Ljava/lang/Exception; {:try_start_8e2 .. :try_end_8e5} :catch_8ea

    :goto_8e5
    move-object/from16 v18, v6

    move-object/from16 v6, v24

    goto :goto_90b

    :catch_8ea
    move-exception v0

    move-object/from16 v25, v5

    move-object/from16 v18, v6

    move/from16 v28, v10

    move-object/from16 v29, v13

    :goto_8f3
    move-object/from16 v6, v21

    move-object/from16 v15, v23

    move-object/from16 v13, v27

    const/16 v16, 0x1

    move-object/from16 v23, v4

    goto/16 :goto_ac1

    :cond_8ff
    move-object/from16 v22, v10

    move-object/from16 v13, v18

    move/from16 v10, v25

    move-object/from16 v18, v6

    move-object/from16 v6, v24

    move-object/from16 v12, v26

    .line 151
    :goto_90b
    :try_start_90b
    invoke-direct {v1, v6}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/String;->isEmpty()Z

    move-result v0
    :try_end_913
    .catch Ljava/lang/Exception; {:try_start_90b .. :try_end_913} :catch_a6a

    if-nez v0, :cond_965

    .line 152
    :try_start_915
    invoke-direct {v1, v6}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    if-eqz v19, :cond_927

    .line 153
    invoke-static {v15, v0}, Lcom/github/catvod/spider/XYQHiker;->getTextByRule(Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0
    :try_end_91f
    .catch Ljava/lang/Exception; {:try_start_915 .. :try_end_91f} :catch_956

    move-object/from16 v24, v6

    move/from16 v28, v10

    move-object/from16 v29, v13

    :goto_925
    move-object v13, v0

    goto :goto_94f

    :cond_927
    move-object/from16 v24, v6

    .line 154
    :try_start_929
    invoke-virtual {v15}, Lcom/github/catvod/spider/xbpqxyq/xyq/ւ;->ދ()Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v0, v5}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v25
    :try_end_931
    .catch Ljava/lang/Exception; {:try_start_929 .. :try_end_931} :catch_954

    move/from16 v28, v10

    move-object/from16 v29, v13

    const/4 v10, 0x0

    :try_start_936
    aget-object v13, v25, v10

    invoke-virtual {v0, v5}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v0

    const/16 v16, 0x1

    aget-object v0, v0, v16

    invoke-static {v6, v13, v0}, Lcom/github/catvod/spider/xbpqxyq/xyq/ވ;->އ(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/util/ArrayList;

    move-result-object v0

    invoke-virtual {v0, v10}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    invoke-virtual {v1, v0}, Lcom/github/catvod/spider/XYQHiker;->މ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0
    :try_end_94e
    .catch Ljava/lang/Exception; {:try_start_936 .. :try_end_94e} :catch_952

    goto :goto_925

    :goto_94f
    move-object/from16 v6, v21

    goto :goto_96f

    :catch_952
    move-exception v0

    goto :goto_95d

    :catch_954
    move-exception v0

    goto :goto_959

    :catch_956
    move-exception v0

    move-object/from16 v24, v6

    :goto_959
    move/from16 v28, v10

    move-object/from16 v29, v13

    .line 155
    :goto_95d
    :try_start_95d
    invoke-static {v0}, Lcom/github/catvod/crawler/SpiderDebug;->log(Ljava/lang/Throwable;)V
    :try_end_960
    .catch Ljava/lang/Exception; {:try_start_95d .. :try_end_960} :catch_961

    goto :goto_96b

    :catch_961
    move-exception v0

    move-object/from16 v25, v5

    goto :goto_8f3

    :cond_965
    move-object/from16 v24, v6

    move/from16 v28, v10

    move-object/from16 v29, v13

    :goto_96b
    move-object/from16 v6, v21

    move-object/from16 v13, v27

    .line 156
    :goto_96f
    :try_start_96f
    invoke-direct {v1, v6}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const-string v10, "2E19B5CAE5A2FFE069"

    invoke-static {v10}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v0, v10}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v0

    const/4 v10, 0x0

    aget-object v0, v0, v10

    if-eqz v19, :cond_98c

    .line 157
    invoke-static {v15, v0}, Lcom/github/catvod/spider/XYQHiker;->getTextByRule(Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    move-object/from16 v21, v14

    const/4 v14, 0x0

    const/16 v16, 0x1

    goto :goto_9ab

    .line 158
    :cond_98c
    invoke-virtual {v15}, Lcom/github/catvod/spider/xbpqxyq/xyq/ւ;->ދ()Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v0, v5}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v15
    :try_end_994
    .catch Ljava/lang/Exception; {:try_start_96f .. :try_end_994} :catch_a5b

    move-object/from16 v21, v14

    const/4 v14, 0x0

    :try_start_997
    aget-object v15, v15, v14

    invoke-virtual {v0, v5}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v0
    :try_end_99d
    .catch Ljava/lang/Exception; {:try_start_997 .. :try_end_99d} :catch_a51

    const/16 v16, 0x1

    :try_start_99f
    aget-object v0, v0, v16

    invoke-static {v10, v15, v0}, Lcom/github/catvod/spider/xbpqxyq/xyq/ވ;->އ(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/util/ArrayList;

    move-result-object v0

    invoke-virtual {v0, v14}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    .line 159
    :goto_9ab
    invoke-direct {v1, v6}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    const-string v15, "29A4C8EEBCC9D0"

    invoke-static {v15}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v15

    invoke-virtual {v10, v15}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v10

    if-eqz v10, :cond_9c3

    .line 160
    invoke-direct {v1, v6}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    invoke-static {v0, v10}, Lcom/github/catvod/spider/xbpqxyq/xyq/ވ;->ރ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 161
    :cond_9c3
    new-instance v10, Ljava/lang/StringBuilder;

    invoke-direct {v10}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v10, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v10, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v10, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v10}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v10
    :try_end_9d5
    .catch Ljava/lang/Exception; {:try_start_99f .. :try_end_9d5} :catch_a49

    move-object/from16 v15, v23

    .line 162
    :try_start_9d7
    invoke-virtual {v10, v15}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v17

    if-eqz v17, :cond_9e1

    .line 163
    invoke-virtual {v10, v15, v0}, Ljava/lang/String;->replaceAll(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10
    :try_end_9e1
    .catch Ljava/lang/Exception; {:try_start_9d7 .. :try_end_9e1} :catch_a40

    :cond_9e1
    move-object/from16 v14, p1

    .line 164
    :try_start_9e3
    invoke-virtual {v8, v14}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    if-eqz v0, :cond_a38

    .line 165
    new-instance v0, Lorg/json/JSONObject;

    invoke-direct {v0}, Lorg/json/JSONObject;-><init>()V
    :try_end_9ee
    .catch Ljava/lang/Exception; {:try_start_9e3 .. :try_end_9ee} :catch_a3e

    move-object/from16 v23, v4

    :try_start_9f0
    const-string v4, "042D370E3320"

    invoke-static {v4}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4
    :try_end_9f6
    .catch Ljava/lang/Exception; {:try_start_9f0 .. :try_end_9f6} :catch_a36

    move-object/from16 v25, v5

    .line 166
    :try_start_9f8
    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v5, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v0, v4, v5}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const-string v4, "042D370E34251F27"

    invoke-static {v4}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    .line 167
    invoke-virtual {v0, v4, v8}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const-string v4, "042D370E2A2D11"

    invoke-static {v4}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    .line 168
    invoke-virtual {v0, v4, v12}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const-string v4, "042D370E28211F23213A29"

    invoke-static {v4}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    .line 169
    invoke-virtual {v0, v4, v13}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 170
    invoke-virtual {v3, v0}, Lorg/json/JSONArray;->put(Ljava/lang/Object;)Lorg/json/JSONArray;
    :try_end_a31
    .catch Ljava/lang/Exception; {:try_start_9f8 .. :try_end_a31} :catch_a33

    goto/16 :goto_ae8

    :catch_a33
    move-exception v0

    goto/16 :goto_ac5

    :catch_a36
    move-exception v0

    goto :goto_a45

    :cond_a38
    move-object/from16 v23, v4

    move-object/from16 v25, v5

    goto/16 :goto_ae8

    :catch_a3e
    move-exception v0

    goto :goto_a43

    :catch_a40
    move-exception v0

    move-object/from16 v14, p1

    :goto_a43
    move-object/from16 v23, v4

    :goto_a45
    move-object/from16 v25, v5

    goto/16 :goto_ac5

    :catch_a49
    move-exception v0

    move-object/from16 v14, p1

    move-object/from16 v25, v5

    move-object/from16 v15, v23

    goto :goto_a66

    :catch_a51
    move-exception v0

    move-object/from16 v14, p1

    move-object/from16 v25, v5

    move-object/from16 v15, v23

    const/16 v16, 0x1

    goto :goto_a66

    :catch_a5b
    move-exception v0

    move-object/from16 v25, v5

    move-object/from16 v21, v14

    move-object/from16 v15, v23

    const/16 v16, 0x1

    move-object/from16 v14, p1

    :goto_a66
    move-object/from16 v23, v4

    goto/16 :goto_ac5

    :catch_a6a
    move-exception v0

    move-object/from16 v25, v5

    move-object/from16 v24, v6

    move/from16 v28, v10

    move-object/from16 v29, v13

    move-object/from16 v6, v21

    move-object/from16 v15, v23

    const/16 v16, 0x1

    move-object/from16 v23, v4

    move-object/from16 v21, v14

    move-object/from16 v14, p1

    goto :goto_a99

    :catch_a80
    move-exception v0

    move-object/from16 v22, v10

    move-object/from16 v29, v18

    move-object/from16 v15, v23

    move/from16 v28, v25

    const/16 v16, 0x1

    :goto_a8b
    move-object/from16 v23, v4

    move-object/from16 v25, v5

    move-object/from16 v18, v6

    move-object/from16 v6, v21

    move-object/from16 v21, v14

    move-object/from16 v14, p1

    move-object/from16 v12, v26

    :goto_a99
    move-object/from16 v13, v27

    goto :goto_ac5

    :catch_a9c
    move-exception v0

    move-object/from16 v22, v10

    move-object/from16 v29, v18

    move-object/from16 v15, v23

    move/from16 v28, v25

    goto :goto_a8b

    :catch_aa6
    move-exception v0

    goto :goto_aab

    :catch_aa8
    move-exception v0

    move-object/from16 p2, v8

    :goto_aab
    move-object/from16 v22, v10

    move-object/from16 v26, v12

    move-object/from16 v27, v13

    :goto_ab1
    move-object/from16 v29, v18

    move-object/from16 v15, v23

    move/from16 v28, v25

    const/16 v16, 0x1

    move-object/from16 v23, v4

    move-object/from16 v25, v5

    move-object/from16 v18, v6

    move-object/from16 v6, v21

    :goto_ac1
    move-object/from16 v21, v14

    move-object/from16 v14, p1

    .line 171
    :goto_ac5
    :try_start_ac5
    invoke-static {v0}, Lcom/github/catvod/crawler/SpiderDebug;->log(Ljava/lang/Throwable;)V

    .line 172
    iget-boolean v4, v1, Lcom/github/catvod/spider/XYQHiker;->ވ:Z

    if-eqz v4, :cond_ae8

    .line 173
    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const-string v5, "94D2CFB6EEE69AE5F0B7C4D41A363E3DBFC8C8A7CCCEBFC3C8ABC7C8B5F8E8"

    invoke-static {v5}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/Exception;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lcom/github/catvod/spider/Init;->show(Ljava/lang/String;)V

    :cond_ae8
    :goto_ae8
    add-int/lit8 v9, v9, 0x1

    move-object/from16 v8, p2

    move-object/from16 v14, v21

    move-object/from16 v10, v22

    move-object/from16 v4, v23

    move-object/from16 v5, v25

    move/from16 v25, v28

    move-object/from16 v21, v6

    move-object/from16 v23, v15

    move-object/from16 v6, v18

    move-object/from16 v18, v29

    goto/16 :goto_7ca

    :cond_b00
    :goto_b00
    const-string v0, "1E2B2025"

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    move-object/from16 v2, v20

    .line 174
    invoke-virtual {v2, v0, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 175
    invoke-virtual {v2}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object v0
    :try_end_b0f
    .catch Ljava/lang/Exception; {:try_start_ac5 .. :try_end_b0f} :catch_b10

    return-object v0

    :catch_b10
    move-exception v0

    .line 176
    invoke-static {v0}, Lcom/github/catvod/crawler/SpiderDebug;->log(Ljava/lang/Throwable;)V

    .line 177
    iget-boolean v2, v1, Lcom/github/catvod/spider/XYQHiker;->ވ:Z

    if-eqz v2, :cond_b34

    .line 178
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "94D2CFB6EEE697C7FBB4EBC497C5E9B8CEDD9DFEC9"

    invoke-static {v3}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/Exception;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lcom/github/catvod/spider/Init;->show(Ljava/lang/String;)V

    :cond_b34
    return-object v11
.end method

.method private static ދ(Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;Ljava/lang/String;)Lcom/github/catvod/spider/xbpqxyq/xyq/ำ;
    .registers 7

    const-string v0, "5E"

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 1
    invoke-virtual {p1, v0}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v0

    .line 2
    array-length v1, v0

    const/4 v2, 0x1

    if-le v1, v2, :cond_6f

    .line 3
    aget-object p1, v0, v2

    const/4 v1, -0x1

    const-string v3, "48"

    invoke-static {v3}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {p1, v3, v1}, Ljava/lang/String;->split(Ljava/lang/String;I)[Ljava/lang/String;

    move-result-object p1

    const/4 v1, 0x0

    .line 4
    aget-object v3, p1, v1

    invoke-static {v3}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v3

    if-nez v3, :cond_2f

    .line 5
    :try_start_24
    aget-object v3, p1, v1

    invoke-static {v3}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v3
    :try_end_2a
    .catch Ljava/lang/NumberFormatException; {:try_start_24 .. :try_end_2a} :catch_2b

    goto :goto_30

    :catch_2b
    move-exception v3

    .line 6
    invoke-virtual {v3}, Ljava/lang/NumberFormatException;->printStackTrace()V

    :cond_2f
    const/4 v3, 0x0

    .line 7
    :goto_30
    aget-object v4, p1, v2

    invoke-static {v4}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v4

    if-nez v4, :cond_43

    .line 8
    :try_start_38
    aget-object p1, p1, v2

    invoke-static {p1}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result p1
    :try_end_3e
    .catch Ljava/lang/NumberFormatException; {:try_start_38 .. :try_end_3e} :catch_3f

    goto :goto_44

    :catch_3f
    move-exception p1

    .line 9
    invoke-virtual {p1}, Ljava/lang/NumberFormatException;->printStackTrace()V

    :cond_43
    const/4 p1, 0x0

    .line 10
    :goto_44
    aget-object v0, v0, v1

    invoke-virtual {p0, v0}, Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;->ࢳ(Ljava/lang/String;)Lcom/github/catvod/spider/xbpqxyq/xyq/ำ;

    move-result-object p0

    .line 11
    invoke-virtual {p0}, Ljava/util/ArrayList;->size()I

    move-result v0

    if-le p1, v0, :cond_54

    .line 12
    invoke-virtual {p0}, Ljava/util/ArrayList;->size()I

    move-result p1

    :cond_54
    if-gtz p1, :cond_5b

    .line 13
    invoke-virtual {p0}, Ljava/util/ArrayList;->size()I

    move-result v0

    add-int/2addr p1, v0

    .line 14
    :cond_5b
    new-instance v0, Lcom/github/catvod/spider/xbpqxyq/xyq/ำ;

    invoke-direct {v0}, Lcom/github/catvod/spider/xbpqxyq/xyq/ำ;-><init>()V

    :goto_60
    if-ge v3, p1, :cond_6e

    .line 15
    invoke-virtual {p0, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/lit8 v3, v3, 0x1

    goto :goto_60

    :cond_6e
    return-object v0

    .line 16
    :cond_6f
    invoke-virtual {p0, p1}, Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;->ࢳ(Ljava/lang/String;)Lcom/github/catvod/spider/xbpqxyq/xyq/ำ;

    move-result-object p0

    return-object p0
.end method


# virtual methods
.method public categoryContent(Ljava/lang/String;Ljava/lang/String;ZLjava/util/HashMap;)Ljava/lang/String;
    .registers 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Z",
            "Ljava/util/HashMap<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;)",
            "Ljava/lang/String;"
        }
    .end annotation

    .line 1
    invoke-direct {p0, p1, p2, p3, p4}, Lcom/github/catvod/spider/XYQHiker;->Ԩ(Ljava/lang/String;Ljava/lang/String;ZLjava/util/HashMap;)Lorg/json/JSONObject;

    move-result-object p1

    if-eqz p1, :cond_b

    .line 2
    invoke-virtual {p1}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object p1

    goto :goto_d

    :cond_b
    const-string p1, ""

    :goto_d
    return-object p1
.end method

.method public detailContent(Ljava/util/List;)Ljava/lang/String;
    .registers 44
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;)",
            "Ljava/lang/String;"
        }
    .end annotation

    move-object/from16 v1, p0

    move-object/from16 v2, p1

    const-string v3, "2E7D"

    invoke-static {v3}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    const-string v4, "94DAFCB4CAE297CDDEB9E7E89BC2DAB8C1C297F8DCB4D2D3"

    invoke-static {v4}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    const-string v5, "9BC2DAB8C1C297CAC4B9FBEC94D7E3B6E1C09AE5D7B4D2DD"

    invoke-static {v5}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    const-string v6, "94D0FEB7CEFA97CAC4B9FBEC94D7E3B6E1C09AE5D7B4D2DD"

    invoke-static {v6}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    const-string v7, "9BD1EDB7D4E194DAFCB4CAE295D9E7B7D4E194D0FEB7CEFA"

    invoke-static {v7}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    const-string v8, "95FFC2B8FBF195FEC5B6FAC594E2EFB4E6CB"

    invoke-static {v8}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    const-string v9, "29A4C8EEBCC9D078"

    invoke-static {v9}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    const-string v10, "29A4DDC3BFFEFD78"

    invoke-static {v10}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    const-string v11, "29A6EBDCBFC8F7A7C3FA60"

    invoke-static {v11}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v11

    const-string v12, "43"

    invoke-static {v12}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v12

    const-string v13, ""

    const-string v14, "5464"

    invoke-static {v14}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v14

    .line 1
    :try_start_48
    invoke-virtual/range {p0 .. p0}, Lcom/github/catvod/spider/XYQHiker;->Ԯ()V

    .line 2
    invoke-direct {v1, v8}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v15

    invoke-virtual {v15}, Ljava/lang/String;->isEmpty()Z

    move-result v15

    if-nez v15, :cond_56

    goto :goto_5c

    :cond_56
    const-string v8, "312D373834232D243C23372506"

    invoke-static {v8}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    :goto_5c
    const-string v15, "2716157C62"

    invoke-static {v15}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v15

    .line 3
    invoke-direct {v1, v8, v15}, Lcom/github/catvod/spider/XYQHiker;->ރ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    iput-object v8, v1, Lcom/github/catvod/spider/XYQHiker;->ހ:Ljava/lang/String;

    const/4 v8, 0x0

    .line 4
    invoke-interface {v2, v8}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v15

    check-cast v15, Ljava/lang/String;

    const-string v8, "2E660F750660"

    invoke-static {v8}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v15, v8}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v8

    const/4 v15, 0x2

    move-object/from16 v17, v9

    .line 5
    aget-object v9, v8, v15

    .line 6
    sget-object v15, Lcom/github/catvod/spider/XYQHiker;->ԩ:Ljava/util/regex/Pattern;

    move-object/from16 v18, v10

    invoke-virtual {v9}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v15, v10}, Ljava/util/regex/Pattern;->matcher(Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;

    move-result-object v10

    invoke-virtual {v10}, Ljava/util/regex/Matcher;->find()Z

    move-result v10
    :try_end_8e
    .catch Ljava/lang/Exception; {:try_start_48 .. :try_end_8e} :catch_d61

    const-string v15, "042D370E3320"

    invoke-static {v15}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v15

    move-object/from16 v19, v11

    const-string v11, "1E2B2025"

    invoke-static {v11}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v11

    move-object/from16 v20, v13

    const/4 v13, 0x1

    if-eqz v10, :cond_db

    .line 7
    :try_start_a1
    sput-boolean v13, Lcom/github/catvod/spider/XYQHiker;->Ԩ:Z

    .line 8
    new-instance v3, Ljava/util/ArrayList;

    invoke-direct {v3}, Ljava/util/ArrayList;-><init>()V

    .line 9
    invoke-virtual {v9}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v4

    invoke-interface {v3, v4}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 10
    iget-object v4, v1, Lcom/github/catvod/spider/XYQHiker;->֏:Lcom/github/catvod/spider/XYQPushAgent;

    invoke-virtual {v4, v3}, Lcom/github/catvod/spider/XYQPushAgent;->detailContent(Ljava/util/List;)Ljava/lang/String;

    move-result-object v3

    .line 11
    invoke-virtual {v3}, Ljava/lang/String;->length()I

    move-result v4

    if-lez v4, :cond_d4

    .line 12
    new-instance v4, Lorg/json/JSONObject;

    invoke-direct {v4, v3}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    .line 13
    invoke-virtual {v4, v11}, Lorg/json/JSONObject;->optJSONArray(Ljava/lang/String;)Lorg/json/JSONArray;

    move-result-object v3

    const/4 v5, 0x0

    invoke-virtual {v3, v5}, Lorg/json/JSONArray;->getJSONObject(I)Lorg/json/JSONObject;

    move-result-object v3

    invoke-interface {v2, v5}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v2

    invoke-virtual {v3, v15, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 14
    invoke-virtual {v4}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object v3
    :try_end_d4
    .catch Ljava/lang/Exception; {:try_start_a1 .. :try_end_d4} :catch_d5

    :cond_d4
    return-object v3

    :catch_d5
    move-exception v0

    move-object v2, v0

    move-object/from16 v14, v20

    goto/16 :goto_d64

    .line 15
    :cond_db
    :try_start_db
    aget-object v10, v8, v13

    const/16 v16, 0x0

    aget-object v13, v8, v16

    .line 16
    invoke-direct {v1, v7}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v22

    invoke-virtual/range {v22 .. v22}, Ljava/lang/String;->isEmpty()Z

    move-result v22

    if-nez v22, :cond_ec

    goto :goto_f2

    :cond_ec
    const-string v7, "142D21323F1B022E3228"

    invoke-static {v7}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    .line 17
    :goto_f2
    invoke-direct {v1, v6}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v22

    invoke-virtual/range {v22 .. v22}, Ljava/lang/String;->isEmpty()Z

    move-result v22

    if-nez v22, :cond_fd

    goto :goto_103

    :cond_fd
    const-string v6, "1E2B2025052500300C232F2817"

    invoke-static {v6}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    .line 18
    :goto_103
    invoke-direct {v1, v5}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v22

    invoke-virtual/range {v22 .. v22}, Ljava/lang/String;->isEmpty()Z

    move-result v22

    if-nez v22, :cond_10e

    goto :goto_114

    :cond_10e
    const-string v5, "17323A0E3B36001D21243621"

    invoke-static {v5}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    .line 19
    :goto_114
    invoke-direct {v1, v4}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v22

    invoke-virtual/range {v22 .. v22}, Ljava/lang/String;->isEmpty()Z

    move-result v22

    if-nez v22, :cond_11f

    goto :goto_125

    :cond_11f
    const-string v4, "17323A0E2821042721223F"

    invoke-static {v4}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    :goto_125
    move-object/from16 v22, v11

    .line 20
    new-instance v11, Ljava/util/ArrayList;

    invoke-direct {v11}, Ljava/util/ArrayList;-><init>()V

    move-object/from16 v23, v13

    .line 21
    new-instance v13, Ljava/util/ArrayList;

    invoke-direct {v13}, Ljava/util/ArrayList;-><init>()V

    move-object/from16 v24, v15

    .line 22
    invoke-direct {v1, v7}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v15

    invoke-virtual {v15, v12}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v15
    :try_end_13d
    .catch Ljava/lang/Exception; {:try_start_db .. :try_end_13d} :catch_d5d

    const-string v2, "94DAFC"

    invoke-static {v2}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    if-nez v15, :cond_152

    :try_start_145
    invoke-direct {v1, v7}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v7, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v7
    :try_end_14d
    .catch Ljava/lang/Exception; {:try_start_145 .. :try_end_14d} :catch_d5

    if-eqz v7, :cond_150

    goto :goto_152

    :cond_150
    const/4 v7, 0x0

    goto :goto_153

    :cond_152
    :goto_152
    const/4 v7, 0x1

    :goto_153
    const-string v15, "56"

    invoke-static {v15}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v15

    if-eqz v7, :cond_187

    const/4 v7, 0x0

    .line 23
    :try_start_15c
    aget-object v2, v8, v7

    invoke-virtual {v13, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 24
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    aget-object v3, v8, v7

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v15}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x2

    aget-object v3, v8, v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v11, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    :try_end_17b
    .catch Ljava/lang/Exception; {:try_start_15c .. :try_end_17b} :catch_d5

    move-object/from16 v30, v11

    move-object v12, v13

    move-object/from16 v2, v20

    move-object v3, v2

    move-object v4, v3

    move-object v5, v4

    move-object v6, v5

    move-object v14, v6

    goto/16 :goto_cae

    :cond_187
    :try_start_187
    const-string v7, "49323C222E"

    invoke-static {v7}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    .line 25
    invoke-virtual {v9, v7}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v7
    :try_end_191
    .catch Ljava/lang/Exception; {:try_start_187 .. :try_end_191} :catch_d5d

    if-eqz v7, :cond_278

    .line 26
    :try_start_193
    invoke-virtual {v9, v3}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v7

    const/16 v16, 0x0

    aget-object v7, v7, v16

    move-object/from16 v25, v10

    const-string v10, "9DFECCBEE6DB"

    invoke-static {v10}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    move-object/from16 v26, v13

    const-string v13, "4D"

    invoke-static {v13}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v13

    invoke-virtual {v7, v10, v13}, Ljava/lang/String;->replaceAll(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v7}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v7

    .line 27
    invoke-virtual {v9, v3}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v3

    const/4 v10, 0x1

    aget-object v3, v3, v10

    const-string v10, "49"

    invoke-static {v10}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v3, v10}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v3

    const/4 v10, 0x0

    aget-object v3, v3, v10

    const-string v10, "9DFECCBEE6DB"

    invoke-static {v10}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    const-string v13, "4D"

    invoke-static {v13}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v13

    invoke-virtual {v3, v10, v13}, Ljava/lang/String;->replaceAll(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v3

    .line 28
    invoke-virtual {v3}, Ljava/lang/String;->isEmpty()Z

    move-result v10

    if-nez v10, :cond_266

    const-string v10, "09"

    invoke-static {v10}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    .line 29
    invoke-virtual {v3, v10}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v10

    if-eqz v10, :cond_214

    const-string v10, "0F"

    invoke-static {v10}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v3, v10}, Ljava/lang/String;->endsWith(Ljava/lang/String;)Z

    move-result v10

    if-eqz v10, :cond_214

    .line 30
    new-instance v10, Lorg/json/JSONObject;

    invoke-direct {v10, v3}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    .line 31
    invoke-virtual {v10}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object v3

    iget-object v10, v1, Lcom/github/catvod/spider/XYQHiker;->ހ:Ljava/lang/String;

    invoke-virtual {v1, v7}, Lcom/github/catvod/spider/XYQHiker;->ހ(Ljava/lang/String;)Ljava/util/HashMap;

    move-result-object v13

    invoke-virtual {v1, v7, v3, v10, v13}, Lcom/github/catvod/spider/XYQHiker;->Ϳ(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/util/Map;)Ljava/lang/String;

    move-result-object v3

    move-object/from16 v31, v4

    move-object/from16 v27, v8

    move-object/from16 v30, v11

    goto/16 :goto_2e5

    .line 32
    :cond_214
    new-instance v10, Ljava/util/LinkedHashMap;

    invoke-direct {v10}, Ljava/util/LinkedHashMap;-><init>()V

    const-string v13, "54"

    invoke-static {v13}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v13

    .line 33
    invoke-virtual {v3, v13}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v3

    .line 34
    array-length v13, v3

    move-object/from16 v27, v8

    const/4 v8, 0x0

    :goto_227
    if-ge v8, v13, :cond_256

    move/from16 v28, v13

    aget-object v13, v3, v8

    move-object/from16 v29, v3

    const-string v3, "4F"

    invoke-static {v3}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    .line 35
    invoke-virtual {v13, v3}, Ljava/lang/String;->indexOf(Ljava/lang/String;)I

    move-result v3

    move-object/from16 v31, v4

    move-object/from16 v30, v11

    const/4 v11, 0x0

    .line 36
    invoke-virtual {v13, v11, v3}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v4

    add-int/lit8 v3, v3, 0x1

    invoke-virtual {v13, v3}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v10, v4, v3}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    add-int/lit8 v8, v8, 0x1

    move/from16 v13, v28

    move-object/from16 v3, v29

    move-object/from16 v11, v30

    move-object/from16 v4, v31

    goto :goto_227

    :cond_256
    move-object/from16 v31, v4

    move-object/from16 v30, v11

    .line 37
    iget-object v3, v1, Lcom/github/catvod/spider/XYQHiker;->ހ:Ljava/lang/String;

    invoke-virtual {v1, v7}, Lcom/github/catvod/spider/XYQHiker;->ހ(Ljava/lang/String;)Ljava/util/HashMap;

    move-result-object v4

    invoke-virtual {v1, v7, v10, v3, v4}, Lcom/github/catvod/spider/XYQHiker;->ԭ(Ljava/lang/String;Ljava/util/Map;Ljava/lang/String;Ljava/util/Map;)Ljava/lang/String;

    move-result-object v3

    goto/16 :goto_2e5

    :cond_266
    move-object/from16 v31, v4

    move-object/from16 v27, v8

    move-object/from16 v30, v11

    const/4 v3, 0x0

    .line 38
    iget-object v4, v1, Lcom/github/catvod/spider/XYQHiker;->ހ:Ljava/lang/String;

    invoke-virtual {v1, v7}, Lcom/github/catvod/spider/XYQHiker;->ހ(Ljava/lang/String;)Ljava/util/HashMap;

    move-result-object v8

    invoke-virtual {v1, v7, v3, v4, v8}, Lcom/github/catvod/spider/XYQHiker;->ԭ(Ljava/lang/String;Ljava/util/Map;Ljava/lang/String;Ljava/util/Map;)Ljava/lang/String;

    move-result-object v3
    :try_end_277
    .catch Ljava/lang/Exception; {:try_start_193 .. :try_end_277} :catch_d5

    goto :goto_2e5

    :cond_278
    move-object/from16 v31, v4

    move-object/from16 v27, v8

    move-object/from16 v25, v10

    move-object/from16 v30, v11

    move-object/from16 v26, v13

    .line 39
    :try_start_282
    iget-object v3, v1, Lcom/github/catvod/spider/XYQHiker;->ހ:Ljava/lang/String;

    invoke-virtual {v1, v9}, Lcom/github/catvod/spider/XYQHiker;->ހ(Ljava/lang/String;)Ljava/util/HashMap;

    move-result-object v4

    invoke-virtual {v1, v9, v3, v4}, Lcom/github/catvod/spider/XYQHiker;->Ԭ(Ljava/lang/String;Ljava/lang/String;Ljava/util/Map;)Ljava/lang/String;

    move-result-object v3

    const-string v4, "94E1D3B7EFCF96FAFE"

    invoke-static {v4}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    .line 40
    invoke-virtual {v3, v4}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v4
    :try_end_296
    .catch Ljava/lang/Exception; {:try_start_282 .. :try_end_296} :catch_d5d

    const-string v7, "012A3C26"

    invoke-static {v7}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    if-eqz v4, :cond_2ae

    :try_start_29e
    const-string v4, "103624303C"

    invoke-static {v4}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v4

    if-eqz v4, :cond_2ae

    .line 41
    invoke-direct {v1, v9, v3, v7}, Lcom/github/catvod/spider/XYQHiker;->އ(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3
    :try_end_2ae
    .catch Ljava/lang/Exception; {:try_start_29e .. :try_end_2ae} :catch_d5

    :cond_2ae
    :try_start_2ae
    const-string v4, "5D2A26303E2B1C250C"

    invoke-static {v4}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    .line 42
    invoke-virtual {v3, v4}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v4
    :try_end_2b8
    .catch Ljava/lang/Exception; {:try_start_2ae .. :try_end_2b8} :catch_d5d

    if-nez v4, :cond_2c6

    :try_start_2ba
    const-string v4, "5D30363F302D2D"

    invoke-static {v4}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v4
    :try_end_2c4
    .catch Ljava/lang/Exception; {:try_start_2ba .. :try_end_2c4} :catch_d5

    if-eqz v4, :cond_2ca

    .line 43
    :cond_2c6
    :try_start_2c6
    invoke-direct {v1, v9, v3, v7}, Lcom/github/catvod/spider/XYQHiker;->ކ(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    :cond_2ca
    const-string v4, "9AFCC0B4DFE19BE8DFB9F5C595E2D2"

    invoke-static {v4}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    .line 44
    invoke-virtual {v3, v4}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v4
    :try_end_2d4
    .catch Ljava/lang/Exception; {:try_start_2c6 .. :try_end_2d4} :catch_d5d

    if-eqz v4, :cond_2e5

    :try_start_2d6
    invoke-static {v3}, Lcom/github/catvod/spider/XYQHiker;->checkveriry(Ljava/lang/String;)Z

    move-result v4

    if-eqz v4, :cond_2e5

    const/4 v4, 0x0

    .line 45
    invoke-static {v3}, Lcom/github/catvod/spider/XYQHiker;->vertype(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-direct {v1, v9, v4, v7, v3}, Lcom/github/catvod/spider/XYQHiker;->ވ(Ljava/lang/String;Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3
    :try_end_2e5
    .catch Ljava/lang/Exception; {:try_start_2d6 .. :try_end_2e5} :catch_d5

    .line 46
    :cond_2e5
    :goto_2e5
    :try_start_2e5
    invoke-static {v3}, Lcom/github/catvod/spider/XYQHiker;->ԩ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    .line 47
    invoke-static {v3}, Lcom/github/catvod/spider/xbpqxyq/xyq/ٱ;->Ϳ(Ljava/lang/String;)Lcom/github/catvod/spider/xbpqxyq/xyq/ǐ;

    move-result-object v4

    const-string v7, "9BC2DAB8C1C29BD1EDB7D4E197C8F3B4D3C995FED3"

    invoke-static {v7}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    .line 48
    invoke-direct {v1, v7}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v7}, Ljava/lang/String;->isEmpty()Z

    move-result v7
    :try_end_2fb
    .catch Ljava/lang/Exception; {:try_start_2e5 .. :try_end_2fb} :catch_d5d

    if-nez v7, :cond_304

    :try_start_2fd
    const-string v7, "9BC2DAB8C1C29BD1EDB7D4E197C8F3B4D3C995FED3"

    invoke-static {v7}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7
    :try_end_303
    .catch Ljava/lang/Exception; {:try_start_2fd .. :try_end_303} :catch_d5

    goto :goto_30a

    :cond_304
    :try_start_304
    const-string v7, "17323A2428282D3221343C2D0A"

    invoke-static {v7}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    :goto_30a
    const-string v8, "9BC2DAB8C1C29BD1EDB7D4E197C8F3B4CACA95FED3"

    invoke-static {v8}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    .line 49
    invoke-direct {v1, v8}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v8}, Ljava/lang/String;->isEmpty()Z

    move-result v8
    :try_end_318
    .catch Ljava/lang/Exception; {:try_start_304 .. :try_end_318} :catch_d5d

    if-nez v8, :cond_321

    :try_start_31a
    const-string v8, "9BC2DAB8C1C29BD1EDB7D4E197C8F3B4CACA95FED3"

    invoke-static {v8}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8
    :try_end_320
    .catch Ljava/lang/Exception; {:try_start_31a .. :try_end_320} :catch_d5

    goto :goto_327

    :cond_321
    :try_start_321
    const-string v8, "17323A2428282D3126373C2D0A"

    invoke-static {v8}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    :goto_327
    const-string v10, "9BC2DAB8C1C294E2D4B8F8DC9BD1EDB7D4E194DAFCB4CAE238313C242AA1F4DBB5E2CF"

    invoke-static {v10}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    .line 50
    invoke-direct {v1, v10}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v10}, Ljava/lang/String;->isEmpty()Z

    move-result v10
    :try_end_335
    .catch Ljava/lang/Exception; {:try_start_321 .. :try_end_335} :catch_d5d

    if-nez v10, :cond_33e

    :try_start_337
    const-string v10, "9BC2DAB8C1C294E2D4B8F8DC9BD1EDB7D4E194DAFCB4CAE238313C242AA1F4DBB5E2CF"

    invoke-static {v10}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10
    :try_end_33d
    .catch Ljava/lang/Exception; {:try_start_337 .. :try_end_33d} :catch_d5

    goto :goto_344

    :cond_33e
    :try_start_33e
    const-string v10, "17323A0E33372D28203E2F34"

    invoke-static {v10}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    :goto_344
    const-string v11, "9BC2DAB8C1C294E2D4B8F8DC"

    invoke-static {v11}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v11

    .line 51
    invoke-direct {v1, v11}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v11

    invoke-virtual {v11}, Ljava/lang/String;->isEmpty()Z

    move-result v11
    :try_end_352
    .catch Ljava/lang/Exception; {:try_start_33e .. :try_end_352} :catch_d5d

    if-nez v11, :cond_35b

    :try_start_354
    const-string v11, "9BC2DAB8C1C294E2D4B8F8DC"

    invoke-static {v11}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v11
    :try_end_35a
    .catch Ljava/lang/Exception; {:try_start_354 .. :try_end_35a} :catch_d5

    goto :goto_361

    :cond_35b
    :try_start_35b
    const-string v11, "17323A0E2E2D062E36"

    invoke-static {v11}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v11

    :goto_361
    const-string v13, "9BC2DAB8C1C29BD1EDB7D4E1"

    invoke-static {v13}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v13

    .line 52
    invoke-direct {v1, v13}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v13

    invoke-virtual {v13}, Ljava/lang/String;->isEmpty()Z

    move-result v13
    :try_end_36f
    .catch Ljava/lang/Exception; {:try_start_35b .. :try_end_36f} :catch_d5d

    if-nez v13, :cond_378

    :try_start_371
    const-string v13, "9BC2DAB8C1C29BD1EDB7D4E1"

    invoke-static {v13}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v13
    :try_end_377
    .catch Ljava/lang/Exception; {:try_start_371 .. :try_end_377} :catch_d5

    goto :goto_37e

    :cond_378
    :try_start_378
    const-string v13, "17323A0E2F361E"

    invoke-static {v13}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v13

    .line 53
    :goto_37e
    invoke-direct {v1, v7}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    .line 54
    invoke-virtual {v7, v14}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v28
    :try_end_386
    .catch Ljava/lang/Exception; {:try_start_378 .. :try_end_386} :catch_d5d

    move-object/from16 v29, v3

    const-string v3, "22050C040808"

    invoke-static {v3}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    if-eqz v28, :cond_398

    .line 55
    :try_start_390
    invoke-static {v4, v7}, Lcom/github/catvod/spider/XYQHiker;->getTextByRule(Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v7, v3, v9}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object v7
    :try_end_398
    .catch Ljava/lang/Exception; {:try_start_390 .. :try_end_398} :catch_d5

    .line 56
    :cond_398
    :try_start_398
    invoke-virtual {v7, v3}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v28
    :try_end_39c
    .catch Ljava/lang/Exception; {:try_start_398 .. :try_end_39c} :catch_d5d

    if-eqz v28, :cond_3b1

    .line 57
    :try_start_39e
    invoke-virtual {v7, v3, v9}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object v3

    const-string v7, "55"

    invoke-static {v7}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7
    :try_end_3a8
    .catch Ljava/lang/Exception; {:try_start_39e .. :try_end_3a8} :catch_d5

    move-object/from16 v28, v9

    move-object/from16 v9, v20

    :try_start_3ac
    invoke-virtual {v3, v7, v9}, Ljava/lang/String;->replaceAll(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7
    :try_end_3b0
    .catch Ljava/lang/Exception; {:try_start_3ac .. :try_end_3b0} :catch_3c4

    goto :goto_3b5

    :cond_3b1
    move-object/from16 v28, v9

    move-object/from16 v9, v20

    .line 58
    :goto_3b5
    :try_start_3b5
    invoke-direct {v1, v8}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    .line 59
    invoke-virtual {v3, v14}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v8
    :try_end_3bd
    .catch Ljava/lang/Exception; {:try_start_3b5 .. :try_end_3bd} :catch_d5a

    if-eqz v8, :cond_3c9

    .line 60
    :try_start_3bf
    invoke-static {v4, v3}, Lcom/github/catvod/spider/XYQHiker;->getTextByRule(Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3
    :try_end_3c3
    .catch Ljava/lang/Exception; {:try_start_3bf .. :try_end_3c3} :catch_3c4

    goto :goto_3c9

    :catch_3c4
    move-exception v0

    move-object v2, v0

    move-object v14, v9

    goto/16 :goto_d64

    .line 61
    :cond_3c9
    :goto_3c9
    :try_start_3c9
    invoke-direct {v1, v6}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v6, v14}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v6
    :try_end_3d1
    .catch Ljava/lang/Exception; {:try_start_3c9 .. :try_end_3d1} :catch_d5a

    move-object/from16 v20, v9

    const/4 v8, 0x0

    .line 62
    :try_start_3d4
    aget-object v9, v6, v8

    invoke-static {v9, v4}, Lcom/github/catvod/spider/XYQHiker;->getTrueElement(Ljava/lang/String;Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;)Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;

    move-result-object v8

    move-object/from16 v32, v4

    const/4 v9, 0x1

    .line 63
    :goto_3dd
    array-length v4, v6
    :try_end_3de
    .catch Ljava/lang/Exception; {:try_start_3d4 .. :try_end_3de} :catch_d5d

    const/16 v21, 0x1

    add-int/lit8 v4, v4, -0x1

    if-ge v9, v4, :cond_3ed

    .line 64
    :try_start_3e4
    aget-object v4, v6, v9

    invoke-static {v4, v8}, Lcom/github/catvod/spider/XYQHiker;->getTrueElement(Ljava/lang/String;Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;)Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;

    move-result-object v8
    :try_end_3ea
    .catch Ljava/lang/Exception; {:try_start_3e4 .. :try_end_3ea} :catch_d5

    add-int/lit8 v9, v9, 0x1

    goto :goto_3dd

    .line 65
    :cond_3ed
    :try_start_3ed
    array-length v4, v6

    const/4 v9, 0x1

    sub-int/2addr v4, v9

    aget-object v4, v6, v4

    invoke-static {v8, v4}, Lcom/github/catvod/spider/XYQHiker;->selectElements(Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;Ljava/lang/String;)Lcom/github/catvod/spider/xbpqxyq/xyq/ำ;

    move-result-object v4

    const/4 v6, 0x0

    .line 66
    :goto_3f7
    invoke-virtual {v4}, Ljava/util/ArrayList;->size()I

    move-result v8
    :try_end_3fb
    .catch Ljava/lang/Exception; {:try_start_3ed .. :try_end_3fb} :catch_d5d

    const-string v9, "1A362721"

    invoke-static {v9}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    if-ge v6, v8, :cond_68e

    .line 67
    :try_start_403
    invoke-virtual {v4, v6}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v8

    check-cast v8, Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;

    move-object/from16 v33, v4

    .line 68
    invoke-direct {v1, v5}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    .line 69
    invoke-virtual {v4, v14}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v34

    if-eqz v34, :cond_440

    .line 70
    invoke-virtual {v4, v14}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v4

    move-object/from16 v34, v5

    const/16 v16, 0x0

    .line 71
    aget-object v5, v4, v16

    invoke-static {v5, v8}, Lcom/github/catvod/spider/XYQHiker;->getTrueElement(Ljava/lang/String;Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;)Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;

    move-result-object v5

    move/from16 v35, v6

    const/4 v8, 0x1

    .line 72
    :goto_426
    array-length v6, v4

    const/16 v21, 0x1

    add-int/lit8 v6, v6, -0x1

    if-ge v8, v6, :cond_436

    .line 73
    aget-object v6, v4, v8

    invoke-static {v6, v5}, Lcom/github/catvod/spider/XYQHiker;->getTrueElement(Ljava/lang/String;Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;)Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;

    move-result-object v5

    add-int/lit8 v8, v8, 0x1

    goto :goto_426

    .line 74
    :cond_436
    array-length v6, v4

    const/4 v8, 0x1

    sub-int/2addr v6, v8

    aget-object v4, v4, v6

    invoke-static {v5, v4}, Lcom/github/catvod/spider/XYQHiker;->selectElements(Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;Ljava/lang/String;)Lcom/github/catvod/spider/xbpqxyq/xyq/ำ;

    move-result-object v4

    goto :goto_448

    :cond_440
    move-object/from16 v34, v5

    move/from16 v35, v6

    .line 75
    invoke-static {v8, v4}, Lcom/github/catvod/spider/XYQHiker;->selectElements(Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;Ljava/lang/String;)Lcom/github/catvod/spider/xbpqxyq/xyq/ำ;

    move-result-object v4

    .line 76
    :goto_448
    new-instance v5, Ljava/util/ArrayList;

    invoke-direct {v5}, Ljava/util/ArrayList;-><init>()V

    const/4 v6, 0x0

    .line 77
    :goto_44e
    invoke-virtual {v4}, Ljava/util/ArrayList;->size()I

    move-result v8

    if-ge v6, v8, :cond_5ff

    .line 78
    invoke-virtual {v4, v6}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v8

    check-cast v8, Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;

    move-object/from16 v36, v4

    .line 79
    invoke-direct {v1, v10, v12}, Lcom/github/catvod/spider/XYQHiker;->ރ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v4, v12}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-nez v4, :cond_473

    invoke-direct {v1, v10, v2}, Lcom/github/catvod/spider/XYQHiker;->ރ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v4, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_471

    goto :goto_473

    :cond_471
    const/4 v4, 0x0

    goto :goto_474

    :cond_473
    :goto_473
    const/4 v4, 0x1

    :goto_474
    move-object/from16 v37, v10

    .line 80
    invoke-direct {v1, v11}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    if-eqz v4, :cond_487

    .line 81
    invoke-static {v8, v10}, Lcom/github/catvod/spider/XYQHiker;->getTextByRule(Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    move-object/from16 v40, v2

    move-object/from16 v38, v11

    move-object/from16 v41, v12

    goto :goto_4ae

    :cond_487
    move-object/from16 v38, v11

    .line 82
    invoke-virtual {v8}, Lcom/github/catvod/spider/xbpqxyq/xyq/ւ;->ދ()Ljava/lang/String;

    move-result-object v11

    invoke-virtual {v10, v14}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v39
    :try_end_491
    .catch Ljava/lang/Exception; {:try_start_403 .. :try_end_491} :catch_664

    move-object/from16 v40, v2

    move-object/from16 v41, v12

    const/4 v2, 0x0

    :try_start_496
    aget-object v12, v39, v2

    invoke-virtual {v10, v14}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v10

    const/16 v16, 0x1

    aget-object v10, v10, v16

    invoke-static {v11, v12, v10}, Lcom/github/catvod/spider/xbpqxyq/xyq/ވ;->އ(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/util/ArrayList;

    move-result-object v10

    invoke-virtual {v10, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v10

    check-cast v10, Ljava/lang/String;

    invoke-virtual {v1, v10}, Lcom/github/catvod/spider/XYQHiker;->މ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    :goto_4ae
    const-string v2, "1726613A60"

    invoke-static {v2}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    .line 83
    invoke-virtual {v10, v2}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_4d8

    const-string v2, "2E3E353836212E3E7B7F707B5B1E2F"

    invoke-static {v2}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    .line 84
    invoke-static {v2}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    move-result-object v2

    invoke-static {v10}, Ljava/net/URLDecoder;->decode(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v11

    invoke-virtual {v2, v11}, Ljava/util/regex/Pattern;->matcher(Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;

    move-result-object v2

    .line 85
    invoke-virtual {v2}, Ljava/util/regex/Matcher;->find()Z

    move-result v11

    if-eqz v11, :cond_501

    const/4 v11, 0x1

    .line 86
    invoke-virtual {v2, v11}, Ljava/util/regex/Matcher;->group(I)Ljava/lang/String;

    move-result-object v10

    goto :goto_501

    :cond_4d8
    const-string v2, "1F23343F3F3048"

    invoke-static {v2}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    .line 87
    invoke-virtual {v10, v2}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_501

    const-string v2, "5A1C2F7773201C7F7B0A04622F687A797C38566B"

    invoke-static {v2}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    .line 88
    invoke-static {v2}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    move-result-object v2

    invoke-static {v10}, Ljava/net/URLDecoder;->decode(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v11

    invoke-virtual {v2, v11}, Ljava/util/regex/Pattern;->matcher(Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;

    move-result-object v2

    .line 89
    invoke-virtual {v2}, Ljava/util/regex/Matcher;->find()Z

    move-result v11

    if-eqz v11, :cond_501

    const/4 v11, 0x2

    .line 90
    invoke-virtual {v2, v11}, Ljava/util/regex/Matcher;->group(I)Ljava/lang/String;

    move-result-object v10

    :cond_501
    :goto_501
    const-string v2, "562A27252A"

    invoke-static {v2}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    .line 91
    invoke-virtual {v10, v2}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v2

    if-eqz v2, :cond_526

    const-string v2, "2E66"

    invoke-static {v2}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    .line 92
    invoke-virtual {v10, v2}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v2

    .line 93
    array-length v11, v2

    const/4 v12, 0x1

    if-le v11, v12, :cond_526

    aget-object v11, v2, v12

    invoke-virtual {v11, v9}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v11

    if-eqz v11, :cond_526

    const/4 v11, 0x0

    .line 94
    aget-object v10, v2, v11

    .line 95
    :cond_526
    invoke-direct {v1, v13}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    const-string v11, "2E19B7EEC7A3E7DBBAF0EFADE1FC0F0C"

    invoke-static {v11}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v11

    invoke-virtual {v2, v11}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v2

    const/4 v11, 0x0

    aget-object v2, v2, v11

    const-string v12, "2E19B5CAE5A2FFE069"

    invoke-static {v12}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v12

    invoke-virtual {v2, v12}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v2

    aget-object v2, v2, v11

    if-eqz v4, :cond_54a

    .line 96
    invoke-static {v8, v2}, Lcom/github/catvod/spider/XYQHiker;->getTextByRule(Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    goto :goto_566

    .line 97
    :cond_54a
    invoke-virtual {v8}, Lcom/github/catvod/spider/xbpqxyq/xyq/ւ;->ދ()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v2, v14}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v8

    const/4 v11, 0x0

    aget-object v8, v8, v11

    invoke-virtual {v2, v14}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v2

    const/4 v12, 0x1

    aget-object v2, v2, v12

    invoke-static {v4, v8, v2}, Lcom/github/catvod/spider/xbpqxyq/xyq/ވ;->އ(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2, v11}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/String;

    .line 98
    :goto_566
    invoke-direct {v1, v13}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    const-string v8, "29A4C8EEBCC9D0"

    invoke-static {v8}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v4, v8}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v4

    if-eqz v4, :cond_57e

    .line 99
    invoke-direct {v1, v13}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-static {v2, v4}, Lcom/github/catvod/spider/xbpqxyq/xyq/ވ;->ރ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    :cond_57e
    const-string v4, "562A27252A"

    invoke-static {v4}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    .line 100
    invoke-virtual {v2, v4}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v4

    if-eqz v4, :cond_5a2

    const-string v4, "2E66"

    invoke-static {v4}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    .line 101
    invoke-virtual {v2, v4}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v4

    .line 102
    array-length v8, v4

    const/4 v11, 0x1

    if-le v8, v11, :cond_5a2

    aget-object v8, v4, v11

    invoke-virtual {v8, v9}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v8

    if-eqz v8, :cond_5a2

    .line 103
    aget-object v2, v4, v11

    .line 104
    :cond_5a2
    invoke-static {v2}, Lcom/github/catvod/spider/xbpqxyq/xyq/ވ;->ހ(Ljava/lang/String;)Z

    move-result v4

    if-eqz v4, :cond_5aa

    move-object v4, v2

    goto :goto_5bc

    .line 105
    :cond_5aa
    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v4, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    :goto_5bc
    const-string v8, "552B3D212F3055"

    invoke-static {v8}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    .line 106
    invoke-virtual {v4, v8}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v8

    if-eqz v8, :cond_5d2

    const-string v8, "552B3D212F3055"

    invoke-static {v8}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    .line 107
    invoke-virtual {v4, v8, v2}, Ljava/lang/String;->replaceAll(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    .line 108
    :cond_5d2
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v2, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v15}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-interface {v5, v2}, Ljava/util/List;->add(Ljava/lang/Object;)Z
    :try_end_5e7
    .catch Ljava/lang/Exception; {:try_start_496 .. :try_end_5e7} :catch_5f5

    add-int/lit8 v6, v6, 0x1

    move-object/from16 v4, v36

    move-object/from16 v10, v37

    move-object/from16 v11, v38

    move-object/from16 v2, v40

    move-object/from16 v12, v41

    goto/16 :goto_44e

    :catch_5f5
    move-exception v0

    move-object v2, v0

    move-object/from16 v5, v30

    move-object/from16 v8, v40

    move-object/from16 v6, v41

    goto/16 :goto_66a

    :cond_5ff
    move-object/from16 v40, v2

    move-object/from16 v37, v10

    move-object/from16 v38, v11

    move-object/from16 v41, v12

    move-object/from16 v4, v31

    .line 109
    :try_start_609
    invoke-direct {v1, v4}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2
    :try_end_60d
    .catch Ljava/lang/Exception; {:try_start_609 .. :try_end_60d} :catch_65c

    move-object/from16 v6, v41

    :try_start_60f
    invoke-virtual {v2, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2
    :try_end_613
    .catch Ljava/lang/Exception; {:try_start_60f .. :try_end_613} :catch_656

    if-nez v2, :cond_62b

    :try_start_615
    invoke-direct {v1, v4}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2
    :try_end_619
    .catch Ljava/lang/Exception; {:try_start_615 .. :try_end_619} :catch_624

    move-object/from16 v8, v40

    :try_start_61b
    invoke-virtual {v2, v8}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2
    :try_end_61f
    .catch Ljava/lang/Exception; {:try_start_61b .. :try_end_61f} :catch_622

    if-eqz v2, :cond_630

    goto :goto_62d

    :catch_622
    move-exception v0

    goto :goto_627

    :catch_624
    move-exception v0

    move-object/from16 v8, v40

    :goto_627
    move-object v2, v0

    move-object/from16 v5, v30

    goto :goto_66a

    :cond_62b
    move-object/from16 v8, v40

    .line 110
    :goto_62d
    :try_start_62d
    invoke-static {v5}, Ljava/util/Collections;->reverse(Ljava/util/List;)V

    :cond_630
    const-string v2, "51"

    invoke-static {v2}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    .line 111
    invoke-static {v2, v5}, Landroid/text/TextUtils;->join(Ljava/lang/CharSequence;Ljava/lang/Iterable;)Ljava/lang/String;

    move-result-object v2
    :try_end_63a
    .catch Ljava/lang/Exception; {:try_start_62d .. :try_end_63a} :catch_654

    move-object/from16 v5, v30

    :try_start_63c
    invoke-virtual {v5, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    :try_end_63f
    .catch Ljava/lang/Exception; {:try_start_63c .. :try_end_63f} :catch_652

    add-int/lit8 v2, v35, 0x1

    move-object/from16 v31, v4

    move-object/from16 v30, v5

    move-object v12, v6

    move-object/from16 v4, v33

    move-object/from16 v5, v34

    move-object/from16 v10, v37

    move-object/from16 v11, v38

    move v6, v2

    move-object v2, v8

    goto/16 :goto_3f7

    :catch_652
    move-exception v0

    goto :goto_669

    :catch_654
    move-exception v0

    goto :goto_667

    :catch_656
    move-exception v0

    move-object/from16 v5, v30

    move-object/from16 v8, v40

    goto :goto_669

    :catch_65c
    move-exception v0

    move-object/from16 v5, v30

    move-object/from16 v8, v40

    move-object/from16 v6, v41

    goto :goto_669

    :catch_664
    move-exception v0

    move-object v8, v2

    move-object v6, v12

    :goto_667
    move-object/from16 v5, v30

    :goto_669
    move-object v2, v0

    .line 112
    :goto_66a
    :try_start_66a
    invoke-static {v2}, Lcom/github/catvod/crawler/SpiderDebug;->log(Ljava/lang/Throwable;)V

    .line 113
    iget-boolean v3, v1, Lcom/github/catvod/spider/XYQHiker;->ވ:Z

    if-eqz v3, :cond_692

    .line 114
    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, "9AEDF5B7D9C19ACCE4B4D5D297CAC4B9FBEC97C5E9B8CEDD9DFEC9"

    invoke-static {v4}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/Exception;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Lcom/github/catvod/spider/Init;->show(Ljava/lang/String;)V
    :try_end_68d
    .catch Ljava/lang/Exception; {:try_start_66a .. :try_end_68d} :catch_d5

    goto :goto_692

    :cond_68e
    move-object v8, v2

    move-object v6, v12

    move-object/from16 v5, v30

    .line 115
    :cond_692
    :goto_692
    :try_start_692
    invoke-virtual {v5}, Ljava/util/ArrayList;->size()I

    move-result v2
    :try_end_696
    .catch Ljava/lang/Exception; {:try_start_692 .. :try_end_696} :catch_d5d

    const/4 v3, 0x1

    if-lt v2, v3, :cond_6c0

    :try_start_699
    invoke-virtual {v5}, Ljava/util/ArrayList;->size()I

    move-result v2

    if-ne v2, v3, :cond_6de

    const/4 v2, 0x0

    invoke-virtual {v5, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/lang/String;

    invoke-virtual {v3}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v2, v15}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_6de

    invoke-direct {v1, v13}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    const-string v3, "29A6ECCCBDD1EBABF2E4B3D7CC1F"

    invoke-static {v3}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v2
    :try_end_6be
    .catch Ljava/lang/Exception; {:try_start_699 .. :try_end_6be} :catch_d5

    if-eqz v2, :cond_6de

    .line 116
    :cond_6c0
    :try_start_6c0
    invoke-virtual {v5}, Ljava/util/ArrayList;->clear()V

    .line 117
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x0

    aget-object v4, v27, v3

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v15}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x2

    aget-object v4, v27, v3

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v5, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_6de
    const-string v2, "95F8ECB9EDEB97CAC4B9FBEC94D7E3B6E1C09AE5D7B4D2DD"

    invoke-static {v2}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    .line 118
    invoke-direct {v1, v2}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/String;->isEmpty()Z

    move-result v2
    :try_end_6ec
    .catch Ljava/lang/Exception; {:try_start_6c0 .. :try_end_6ec} :catch_d5d

    if-nez v2, :cond_6f5

    :try_start_6ee
    const-string v2, "95F8ECB9EDEB97CAC4B9FBEC94D7E3B6E1C09AE5D7B4D2DD"

    invoke-static {v2}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2
    :try_end_6f4
    .catch Ljava/lang/Exception; {:try_start_6ee .. :try_end_6f4} :catch_d5

    goto :goto_6fb

    :cond_6f5
    :try_start_6f5
    const-string v2, "0623310E3B36001D21243621"

    invoke-static {v2}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    :goto_6fb
    const-string v3, "95F8ECB9EDEB94E2D4B8F8DC"

    invoke-static {v3}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    .line 119
    invoke-direct {v1, v3}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/String;->isEmpty()Z

    move-result v3
    :try_end_709
    .catch Ljava/lang/Exception; {:try_start_6f5 .. :try_end_709} :catch_d5d

    if-nez v3, :cond_712

    :try_start_70b
    const-string v3, "95F8ECB9EDEB94E2D4B8F8DC"

    invoke-static {v3}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3
    :try_end_711
    .catch Ljava/lang/Exception; {:try_start_70b .. :try_end_711} :catch_d5

    goto :goto_718

    :cond_712
    :try_start_712
    const-string v3, "0623310E2E2D062E36"

    invoke-static {v3}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    .line 120
    :goto_718
    invoke-direct {v1, v3}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/String;->isEmpty()Z

    move-result v4
    :try_end_720
    .catch Ljava/lang/Exception; {:try_start_712 .. :try_end_720} :catch_d5d

    if-nez v4, :cond_7e5

    :try_start_722
    invoke-direct {v1, v2}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/String;->isEmpty()Z

    move-result v4

    if-nez v4, :cond_7e5

    .line 121
    invoke-direct {v1, v2}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v2, v14}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v2

    const/4 v4, 0x0

    .line 122
    aget-object v7, v2, v4

    move-object/from16 v4, v32

    invoke-static {v7, v4}, Lcom/github/catvod/spider/XYQHiker;->getTrueElement(Ljava/lang/String;Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;)Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;

    move-result-object v7

    const/4 v10, 0x1

    .line 123
    :goto_73e
    array-length v11, v2

    const/4 v12, 0x1

    sub-int/2addr v11, v12

    if-ge v10, v11, :cond_74c

    .line 124
    aget-object v11, v2, v10

    invoke-static {v11, v7}, Lcom/github/catvod/spider/XYQHiker;->getTrueElement(Ljava/lang/String;Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;)Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;

    move-result-object v7

    add-int/lit8 v10, v10, 0x1

    goto :goto_73e

    .line 125
    :cond_74c
    array-length v10, v2

    const/4 v11, 0x1

    sub-int/2addr v10, v11

    aget-object v2, v2, v10

    invoke-static {v7, v2}, Lcom/github/catvod/spider/XYQHiker;->selectElements(Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;Ljava/lang/String;)Lcom/github/catvod/spider/xbpqxyq/xyq/ำ;

    move-result-object v2

    const/4 v7, 0x0

    .line 126
    :goto_756
    invoke-virtual {v5}, Ljava/util/ArrayList;->size()I

    move-result v10
    :try_end_75a
    .catch Ljava/lang/Exception; {:try_start_722 .. :try_end_75a} :catch_d5

    if-ge v7, v10, :cond_7e0

    .line 127
    :try_start_75c
    invoke-virtual {v2, v7}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v10

    check-cast v10, Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;

    .line 128
    invoke-direct {v1, v3}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v11

    invoke-static {v11}, Lcom/github/catvod/spider/xbpqxyq/xyq/ވ;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v11

    .line 129
    invoke-static {v10, v11}, Lcom/github/catvod/spider/XYQHiker;->getTextByRule(Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    const/4 v11, 0x0

    .line 130
    :goto_76f
    invoke-virtual/range {v26 .. v26}, Ljava/util/ArrayList;->size()I

    move-result v12
    :try_end_773
    .catch Ljava/lang/Exception; {:try_start_75c .. :try_end_773} :catch_7af

    if-ge v11, v12, :cond_7a5

    move-object/from16 v12, v26

    .line 131
    :try_start_777
    invoke-virtual {v12, v11}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v13

    invoke-virtual {v10, v13}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v13

    if-eqz v13, :cond_798

    .line 132
    new-instance v13, Ljava/lang/StringBuilder;

    invoke-direct {v13}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v13, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    :try_end_789
    .catch Ljava/lang/Exception; {:try_start_777 .. :try_end_789} :catch_7a1

    move-object/from16 v15, v20

    :try_start_78b
    invoke-virtual {v13, v15}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    add-int/lit8 v10, v7, 0x1

    invoke-virtual {v13, v10}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v13}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v10

    goto :goto_79a

    :cond_798
    move-object/from16 v15, v20

    :goto_79a
    add-int/lit8 v11, v11, 0x1

    move-object/from16 v26, v12

    move-object/from16 v20, v15

    goto :goto_76f

    :catch_7a1
    move-exception v0

    move-object/from16 v15, v20

    goto :goto_7b4

    :cond_7a5
    move-object/from16 v15, v20

    move-object/from16 v12, v26

    .line 133
    invoke-virtual {v12, v10}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    :try_end_7ac
    .catch Ljava/lang/Exception; {:try_start_78b .. :try_end_7ac} :catch_7ad

    goto :goto_7d8

    :catch_7ad
    move-exception v0

    goto :goto_7b4

    :catch_7af
    move-exception v0

    move-object/from16 v15, v20

    move-object/from16 v12, v26

    :goto_7b4
    move-object v10, v0

    .line 134
    :try_start_7b5
    invoke-static {v10}, Lcom/github/catvod/crawler/SpiderDebug;->log(Ljava/lang/Throwable;)V

    .line 135
    iget-boolean v11, v1, Lcom/github/catvod/spider/XYQHiker;->ވ:Z

    if-eqz v11, :cond_7d8

    .line 136
    new-instance v11, Ljava/lang/StringBuilder;

    invoke-direct {v11}, Ljava/lang/StringBuilder;-><init>()V

    const-string v13, "9AEDF5B7D9C19ACCE4B4D5D295F8ECB9EDEB97C5E9B8CEDD9DFEC9"

    invoke-static {v13}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v13

    invoke-virtual {v11, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v10}, Ljava/lang/Exception;->toString()Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v11, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v11}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v10

    invoke-static {v10}, Lcom/github/catvod/spider/Init;->show(Ljava/lang/String;)V
    :try_end_7d8
    .catch Ljava/lang/Exception; {:try_start_7b5 .. :try_end_7d8} :catch_80d

    :cond_7d8
    :goto_7d8
    add-int/lit8 v7, v7, 0x1

    move-object/from16 v26, v12

    move-object/from16 v20, v15

    goto/16 :goto_756

    :cond_7e0
    move-object/from16 v15, v20

    move-object/from16 v12, v26

    goto :goto_812

    :cond_7e5
    move-object/from16 v15, v20

    move-object/from16 v12, v26

    move-object/from16 v4, v32

    const/4 v2, 0x0

    .line 137
    :goto_7ec
    :try_start_7ec
    invoke-virtual {v5}, Ljava/util/ArrayList;->size()I

    move-result v7
    :try_end_7f0
    .catch Ljava/lang/Exception; {:try_start_7ec .. :try_end_7f0} :catch_d57

    if-ge v2, v7, :cond_812

    .line 138
    :try_start_7f2
    new-instance v7, Ljava/lang/StringBuilder;

    invoke-direct {v7}, Ljava/lang/StringBuilder;-><init>()V

    const-string v10, "95F8ECB9EDEB97CAC4B9FBEC"

    invoke-static {v10}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v7, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    add-int/lit8 v2, v2, 0x1

    invoke-virtual {v7, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v12, v7}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    :try_end_80c
    .catch Ljava/lang/Exception; {:try_start_7f2 .. :try_end_80c} :catch_80d

    goto :goto_7ec

    :catch_80d
    move-exception v0

    move-object v2, v0

    move-object v14, v15

    goto/16 :goto_d64

    :cond_812
    :goto_812
    const/4 v2, 0x3

    :try_start_813
    new-array v7, v2, [Ljava/lang/String;

    const/4 v10, 0x0

    aput-object v19, v7, v10

    const/4 v10, 0x1

    aput-object v18, v7, v10

    const/4 v10, 0x2

    aput-object v17, v7, v10
    :try_end_81e
    .catch Ljava/lang/Exception; {:try_start_813 .. :try_end_81e} :catch_d57

    const/4 v10, 0x0

    :goto_81f
    if-ge v10, v2, :cond_976

    .line 139
    :try_start_821
    aget-object v11, v7, v10

    .line 140
    invoke-direct {v1, v3}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v13

    move-object/from16 v2, v19

    invoke-virtual {v13, v2}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v13

    if-eqz v13, :cond_897

    invoke-virtual {v11, v2}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v13

    if-eqz v13, :cond_897

    .line 141
    invoke-direct {v1, v3}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v13

    move-object/from16 v19, v2

    const-string v2, "2E19B7E9D7A1FEC7B6C1F17E"

    invoke-static {v2}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v13, v2}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v2

    const/4 v13, 0x1

    aget-object v2, v2, v13

    const-string v13, "2E1F"

    invoke-static {v13}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v13

    invoke-virtual {v2, v13}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v2

    const/4 v13, 0x0

    aget-object v2, v2, v13

    const-string v13, "5E"

    invoke-static {v13}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v13

    .line 142
    invoke-virtual {v2, v13}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v2

    move-object/from16 v20, v7

    const/4 v13, 0x0

    .line 143
    :goto_862
    array-length v7, v2
    :try_end_863
    .catch Ljava/lang/Exception; {:try_start_821 .. :try_end_863} :catch_80d

    if-ge v13, v7, :cond_89b

    move-object/from16 v26, v15

    const/4 v7, 0x0

    .line 144
    :goto_868
    :try_start_868
    invoke-virtual {v5}, Ljava/util/ArrayList;->size()I

    move-result v15

    if-ge v7, v15, :cond_890

    .line 145
    invoke-virtual {v12, v7}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v15

    check-cast v15, Ljava/lang/String;

    move-object/from16 v27, v14

    aget-object v14, v2, v13

    invoke-virtual {v15, v14}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v14

    if-eqz v14, :cond_88b

    .line 146
    invoke-virtual {v5}, Ljava/util/ArrayList;->size()I

    move-result v14

    const/4 v15, 0x1

    if-le v14, v15, :cond_88b

    .line 147
    invoke-virtual {v12, v7}, Ljava/util/ArrayList;->remove(I)Ljava/lang/Object;

    .line 148
    invoke-virtual {v5, v7}, Ljava/util/ArrayList;->remove(I)Ljava/lang/Object;

    :cond_88b
    add-int/lit8 v7, v7, 0x1

    move-object/from16 v14, v27

    goto :goto_868

    :cond_890
    move-object/from16 v27, v14

    add-int/lit8 v13, v13, 0x1

    move-object/from16 v15, v26

    goto :goto_862

    :cond_897
    move-object/from16 v19, v2

    move-object/from16 v20, v7

    :cond_89b
    move-object/from16 v27, v14

    move-object/from16 v26, v15

    .line 149
    invoke-direct {v1, v3}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    move-object/from16 v7, v18

    invoke-virtual {v2, v7}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v2

    if-eqz v2, :cond_932

    invoke-virtual {v11, v7}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v2

    if-eqz v2, :cond_932

    .line 150
    new-instance v2, Ljava/util/ArrayList;

    invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V

    .line 151
    new-instance v13, Ljava/util/ArrayList;

    invoke-direct {v13}, Ljava/util/ArrayList;-><init>()V

    .line 152
    invoke-direct {v1, v3}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v14

    const-string v15, "2E19B5DFC8A1C8CD69"

    invoke-static {v15}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v15

    invoke-virtual {v14, v15}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v14

    const/4 v15, 0x1

    aget-object v14, v14, v15

    const-string v15, "2E1F"

    invoke-static {v15}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v15

    invoke-virtual {v14, v15}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v14

    const/4 v15, 0x0

    aget-object v14, v14, v15

    const-string v15, "5E"

    invoke-static {v15}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v15

    .line 153
    invoke-virtual {v14, v15}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v14

    move-object/from16 v18, v7

    const/4 v15, 0x0

    .line 154
    :goto_8e6
    array-length v7, v14

    if-ge v15, v7, :cond_926

    move-object/from16 v32, v4

    const/4 v7, 0x0

    .line 155
    :goto_8ec
    invoke-virtual {v5}, Ljava/util/ArrayList;->size()I

    move-result v4

    if-ge v7, v4, :cond_91f

    .line 156
    invoke-virtual {v12, v7}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/lang/String;

    move-object/from16 v30, v9

    aget-object v9, v14, v15

    invoke-virtual {v4, v9}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v4

    if-eqz v4, :cond_91a

    .line 157
    invoke-virtual {v12, v7}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/lang/String;

    invoke-virtual {v13, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 158
    invoke-virtual {v5, v7}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/lang/String;

    invoke-virtual {v2, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 159
    invoke-virtual {v12, v7}, Ljava/util/ArrayList;->remove(I)Ljava/lang/Object;

    .line 160
    invoke-virtual {v5, v7}, Ljava/util/ArrayList;->remove(I)Ljava/lang/Object;

    :cond_91a
    add-int/lit8 v7, v7, 0x1

    move-object/from16 v9, v30

    goto :goto_8ec

    :cond_91f
    move-object/from16 v30, v9

    add-int/lit8 v15, v15, 0x1

    move-object/from16 v4, v32

    goto :goto_8e6

    :cond_926
    move-object/from16 v32, v4

    move-object/from16 v30, v9

    const/4 v4, 0x0

    .line 161
    invoke-virtual {v5, v4, v2}, Ljava/util/ArrayList;->addAll(ILjava/util/Collection;)Z

    .line 162
    invoke-virtual {v12, v4, v13}, Ljava/util/ArrayList;->addAll(ILjava/util/Collection;)Z

    goto :goto_938

    :cond_932
    move-object/from16 v32, v4

    move-object/from16 v18, v7

    move-object/from16 v30, v9

    .line 163
    :goto_938
    invoke-direct {v1, v3}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    move-object/from16 v4, v17

    invoke-virtual {v2, v4}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v2

    if-eqz v2, :cond_965

    invoke-virtual {v11, v4}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v2

    if-eqz v2, :cond_965

    const/4 v2, 0x0

    .line 164
    :goto_94b
    invoke-virtual {v12}, Ljava/util/ArrayList;->size()I

    move-result v7

    if-ge v2, v7, :cond_965

    .line 165
    invoke-virtual {v12, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Ljava/lang/String;

    invoke-direct {v1, v3}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    invoke-static {v7, v9}, Lcom/github/catvod/spider/xbpqxyq/xyq/ވ;->ރ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v12, v2, v7}, Ljava/util/ArrayList;->set(ILjava/lang/Object;)Ljava/lang/Object;
    :try_end_962
    .catch Ljava/lang/Exception; {:try_start_868 .. :try_end_962} :catch_995

    add-int/lit8 v2, v2, 0x1

    goto :goto_94b

    :cond_965
    add-int/lit8 v10, v10, 0x1

    move-object/from16 v17, v4

    move-object/from16 v7, v20

    move-object/from16 v15, v26

    move-object/from16 v14, v27

    move-object/from16 v9, v30

    move-object/from16 v4, v32

    const/4 v2, 0x3

    goto/16 :goto_81f

    :cond_976
    move-object/from16 v32, v4

    move-object/from16 v30, v9

    move-object/from16 v27, v14

    move-object/from16 v26, v15

    :try_start_97e
    const-string v2, "97F2D2B8C7E69AEDF5B7D9C1"

    invoke-static {v2}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    .line 166
    invoke-direct {v1, v2}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/String;->isEmpty()Z

    move-result v2
    :try_end_98c
    .catch Ljava/lang/Exception; {:try_start_97e .. :try_end_98c} :catch_d53

    if-nez v2, :cond_99b

    :try_start_98e
    const-string v2, "97F2D2B8C7E69AEDF5B7D9C1"

    invoke-static {v2}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2
    :try_end_994
    .catch Ljava/lang/Exception; {:try_start_98e .. :try_end_994} :catch_995

    goto :goto_9a1

    :catch_995
    move-exception v0

    move-object v2, v0

    move-object/from16 v14, v26

    goto/16 :goto_d64

    :cond_99b
    :try_start_99b
    const-string v2, "02303C3B05271D343623"

    invoke-static {v2}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    :goto_9a1
    const-string v3, "95F3E8B4C4CF9AEDF5B7D9C1"

    invoke-static {v3}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    .line 167
    invoke-direct {v1, v3}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/String;->isEmpty()Z

    move-result v3
    :try_end_9af
    .catch Ljava/lang/Exception; {:try_start_99b .. :try_end_9af} :catch_d53

    if-nez v3, :cond_9b8

    :try_start_9b1
    const-string v3, "95F3E8B4C4CF9AEDF5B7D9C1"

    invoke-static {v3}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3
    :try_end_9b7
    .catch Ljava/lang/Exception; {:try_start_9b1 .. :try_end_9b7} :catch_995

    goto :goto_9be

    :cond_9b8
    :try_start_9b8
    const-string v3, "02303C3B0527133636"

    invoke-static {v3}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    :goto_9be
    const-string v4, "97FBE7B5E1E79AEDF5B7D9C1"

    invoke-static {v4}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    .line 168
    invoke-direct {v1, v4}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/String;->isEmpty()Z

    move-result v4
    :try_end_9cc
    .catch Ljava/lang/Exception; {:try_start_9b8 .. :try_end_9cc} :catch_d53

    if-nez v4, :cond_9d5

    :try_start_9ce
    const-string v4, "97FBE7B5E1E79AEDF5B7D9C1"

    invoke-static {v4}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4
    :try_end_9d4
    .catch Ljava/lang/Exception; {:try_start_9ce .. :try_end_9d4} :catch_995

    goto :goto_9db

    :cond_9d5
    :try_start_9d5
    const-string v4, "02303C3B053D172321"

    invoke-static {v4}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    :goto_9db
    const-string v7, "97DEE3B4D6FE9AEDF5B7D9C1"

    invoke-static {v7}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    .line 169
    invoke-direct {v1, v7}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v7}, Ljava/lang/String;->isEmpty()Z

    move-result v7
    :try_end_9e9
    .catch Ljava/lang/Exception; {:try_start_9d5 .. :try_end_9e9} :catch_d53

    if-nez v7, :cond_9f2

    :try_start_9eb
    const-string v7, "97DEE3B4D6FE9AEDF5B7D9C1"

    invoke-static {v7}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7
    :try_end_9f1
    .catch Ljava/lang/Exception; {:try_start_9eb .. :try_end_9f1} :catch_995

    goto :goto_9f8

    :cond_9f2
    :try_start_9f2
    const-string v7, "02303C3B0525002732"

    invoke-static {v7}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    :goto_9f8
    const-string v9, "94FEC7B4CBDC9AEDF5B7D9C1"

    invoke-static {v9}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    .line 170
    invoke-direct {v1, v9}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v9}, Ljava/lang/String;->isEmpty()Z

    move-result v9
    :try_end_a06
    .catch Ljava/lang/Exception; {:try_start_9f2 .. :try_end_a06} :catch_d53

    if-nez v9, :cond_a0f

    :try_start_a08
    const-string v9, "94FEC7B4CBDC9AEDF5B7D9C1"

    invoke-static {v9}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9
    :try_end_a0e
    .catch Ljava/lang/Exception; {:try_start_a08 .. :try_end_a0e} :catch_995

    goto :goto_a15

    :cond_a0f
    :try_start_a0f
    const-string v9, "02303C3B052511363C23"

    invoke-static {v9}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    :goto_a15
    const-string v10, "95ECD3B5E1CF9AEDF5B7D9C1"

    invoke-static {v10}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    .line 171
    invoke-direct {v1, v10}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v10}, Ljava/lang/String;->isEmpty()Z

    move-result v10
    :try_end_a23
    .catch Ljava/lang/Exception; {:try_start_a0f .. :try_end_a23} :catch_d53

    if-nez v10, :cond_a2c

    :try_start_a25
    const-string v10, "95ECD3B5E1CF9AEDF5B7D9C1"

    invoke-static {v10}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10
    :try_end_a2b
    .catch Ljava/lang/Exception; {:try_start_a25 .. :try_end_a2b} :catch_995

    goto :goto_a32

    :cond_a2c
    :try_start_a2c
    const-string v10, "02303C3B05341E2D27"

    invoke-static {v10}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    :goto_a32
    const-string v11, "9AEDF5B7D9C194DAFCB4CAE238313C242AA1F4DBB5E2CF"

    invoke-static {v11}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v11

    .line 172
    invoke-direct {v1, v11}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v11

    invoke-virtual {v11}, Ljava/lang/String;->isEmpty()Z

    move-result v11
    :try_end_a40
    .catch Ljava/lang/Exception; {:try_start_a2c .. :try_end_a40} :catch_d53

    if-nez v11, :cond_a49

    :try_start_a42
    const-string v11, "9AEDF5B7D9C194DAFCB4CAE238313C242AA1F4DBB5E2CF"

    invoke-static {v11}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v11
    :try_end_a48
    .catch Ljava/lang/Exception; {:try_start_a42 .. :try_end_a48} :catch_995

    goto :goto_a4f

    :cond_a49
    :try_start_a49
    const-string v11, "02303C3B052D011D3922353102"

    invoke-static {v11}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v11

    .line 173
    :goto_a4f
    invoke-direct {v1, v11, v6}, Lcom/github/catvod/spider/XYQHiker;->ރ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v13

    invoke-virtual {v13, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v6
    :try_end_a57
    .catch Ljava/lang/Exception; {:try_start_a49 .. :try_end_a57} :catch_d53

    if-nez v6, :cond_a66

    :try_start_a59
    invoke-direct {v1, v11, v8}, Lcom/github/catvod/spider/XYQHiker;->ރ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v6, v8}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v6
    :try_end_a61
    .catch Ljava/lang/Exception; {:try_start_a59 .. :try_end_a61} :catch_995

    if-eqz v6, :cond_a64

    goto :goto_a66

    :cond_a64
    const/4 v6, 0x0

    goto :goto_a67

    :cond_a66
    :goto_a66
    const/4 v6, 0x1

    .line 174
    :goto_a67
    :try_start_a67
    invoke-direct {v1, v2}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v8}, Ljava/lang/String;->isEmpty()Z

    move-result v8

    if-nez v8, :cond_b5c

    move-object/from16 v8, v25

    move-object/from16 v11, v30

    invoke-virtual {v8, v11}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v11
    :try_end_a79
    .catch Ljava/lang/Exception; {:try_start_a67 .. :try_end_a79} :catch_d53

    if-nez v11, :cond_b59

    .line 175
    :try_start_a7b
    invoke-direct {v1, v2}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2
    :try_end_a7f
    .catch Ljava/lang/Exception; {:try_start_a7b .. :try_end_a7f} :catch_b47

    if-eqz v6, :cond_a9a

    move-object/from16 v11, v32

    .line 176
    :try_start_a83
    invoke-static {v11, v2}, Lcom/github/catvod/spider/XYQHiker;->getTextByRule(Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2
    :try_end_a87
    .catch Ljava/lang/Exception; {:try_start_a83 .. :try_end_a87} :catch_a8c

    move-object/from16 v13, v27

    move-object/from16 v15, v29

    goto :goto_abe

    :catch_a8c
    move-exception v0

    move-object v2, v0

    move-object/from16 v30, v5

    move-object/from16 v17, v8

    move-object/from16 v14, v26

    move-object/from16 v13, v27

    move-object/from16 v15, v29

    goto/16 :goto_b55

    :cond_a9a
    move-object/from16 v11, v32

    move-object/from16 v13, v27

    .line 177
    :try_start_a9e
    invoke-virtual {v2, v13}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v14

    const/4 v15, 0x0

    aget-object v14, v14, v15

    invoke-virtual {v2, v13}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v2

    const/16 v16, 0x1

    aget-object v2, v2, v16
    :try_end_aad
    .catch Ljava/lang/Exception; {:try_start_a9e .. :try_end_aad} :catch_b3f

    move-object/from16 v15, v29

    :try_start_aaf
    invoke-static {v15, v14, v2}, Lcom/github/catvod/spider/xbpqxyq/xyq/ވ;->އ(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/util/ArrayList;

    move-result-object v2

    const/4 v14, 0x0

    invoke-virtual {v2, v14}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/String;

    invoke-virtual {v1, v2}, Lcom/github/catvod/spider/XYQHiker;->މ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2
    :try_end_abe
    .catch Ljava/lang/Exception; {:try_start_aaf .. :try_end_abe} :catch_b39

    :goto_abe
    :try_start_abe
    const-string v8, "07303F79"

    invoke-static {v8}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    .line 178
    invoke-virtual {v2, v8}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v8

    if-eqz v8, :cond_b1b

    const-string v8, "2E642224353049"

    invoke-static {v8}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8
    :try_end_ad0
    .catch Ljava/lang/Exception; {:try_start_abe .. :try_end_ad0} :catch_b30

    move-object/from16 v14, v26

    .line 179
    :try_start_ad2
    invoke-virtual {v2, v8, v14}, Ljava/lang/String;->replaceAll(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8
    :try_end_ad6
    .catch Ljava/lang/Exception; {:try_start_ad2 .. :try_end_ad6} :catch_b15

    move-object/from16 v17, v2

    :try_start_ad8
    const-string v2, "07303F0D72"

    invoke-static {v2}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v8, v2}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v2

    .line 180
    array-length v8, v2
    :try_end_ae3
    .catch Ljava/lang/Exception; {:try_start_ad8 .. :try_end_ae3} :catch_b13

    move-object/from16 v30, v5

    const/4 v5, 0x1

    if-le v8, v5, :cond_b21

    :try_start_ae8
    aget-object v8, v2, v5

    const-string v5, "5B"

    invoke-static {v5}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v8, v5}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v5

    if-eqz v5, :cond_b21

    const/4 v5, 0x1

    .line 181
    aget-object v2, v2, v5

    const-string v5, "2E6B"

    invoke-static {v5}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v2, v5}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v2

    const/4 v5, 0x0

    aget-object v2, v2, v5

    const-string v5, "2965710C"

    invoke-static {v5}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v2, v5, v14}, Ljava/lang/String;->replaceAll(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2
    :try_end_b10
    .catch Ljava/lang/Exception; {:try_start_ae8 .. :try_end_b10} :catch_b11

    goto :goto_b23

    :catch_b11
    move-exception v0

    goto :goto_b37

    :catch_b13
    move-exception v0

    goto :goto_b18

    :catch_b15
    move-exception v0

    move-object/from16 v17, v2

    :goto_b18
    move-object/from16 v30, v5

    goto :goto_b37

    :cond_b1b
    move-object/from16 v17, v2

    move-object/from16 v30, v5

    move-object/from16 v14, v26

    :cond_b21
    move-object/from16 v2, v17

    :goto_b23
    move-object/from16 v5, v28

    .line 182
    :try_start_b25
    invoke-static {v5, v2}, Lcom/github/catvod/spider/xbpqxyq/xyq/ވ;->Ԫ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2
    :try_end_b29
    .catch Ljava/lang/Exception; {:try_start_b25 .. :try_end_b29} :catch_b2c

    move-object/from16 v17, v2

    goto :goto_b6a

    :catch_b2c
    move-exception v0

    move-object/from16 v17, v2

    goto :goto_b37

    :catch_b30
    move-exception v0

    move-object/from16 v17, v2

    move-object/from16 v30, v5

    move-object/from16 v14, v26

    :goto_b37
    move-object v2, v0

    goto :goto_b55

    :catch_b39
    move-exception v0

    move-object/from16 v30, v5

    move-object/from16 v14, v26

    goto :goto_b52

    :catch_b3f
    move-exception v0

    move-object/from16 v30, v5

    move-object/from16 v14, v26

    move-object/from16 v15, v29

    goto :goto_b52

    :catch_b47
    move-exception v0

    move-object/from16 v30, v5

    move-object/from16 v14, v26

    move-object/from16 v13, v27

    move-object/from16 v15, v29

    move-object/from16 v11, v32

    :goto_b52
    move-object v2, v0

    move-object/from16 v17, v8

    .line 183
    :goto_b55
    :try_start_b55
    invoke-static {v2}, Lcom/github/catvod/crawler/SpiderDebug;->log(Ljava/lang/Throwable;)V

    goto :goto_b6a

    :cond_b59
    move-object/from16 v30, v5

    goto :goto_b60

    :cond_b5c
    move-object/from16 v30, v5

    move-object/from16 v8, v25

    :goto_b60
    move-object/from16 v14, v26

    move-object/from16 v13, v27

    move-object/from16 v15, v29

    move-object/from16 v11, v32

    move-object/from16 v17, v8

    .line 184
    :goto_b6a
    invoke-direct {v1, v3}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/String;->isEmpty()Z

    move-result v2
    :try_end_b72
    .catch Ljava/lang/Exception; {:try_start_b55 .. :try_end_b72} :catch_d51

    if-nez v2, :cond_ba1

    .line 185
    :try_start_b74
    invoke-direct {v1, v3}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    if-eqz v6, :cond_b7f

    .line 186
    invoke-static {v11, v2}, Lcom/github/catvod/spider/XYQHiker;->getTextByRule(Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    goto :goto_ba2

    .line 187
    :cond_b7f
    invoke-virtual {v2, v13}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v3

    const/4 v5, 0x0

    aget-object v3, v3, v5

    invoke-virtual {v2, v13}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v2

    const/4 v8, 0x1

    aget-object v2, v2, v8

    invoke-static {v15, v3, v2}, Lcom/github/catvod/spider/xbpqxyq/xyq/ވ;->އ(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2, v5}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/String;

    invoke-virtual {v1, v2}, Lcom/github/catvod/spider/XYQHiker;->މ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2
    :try_end_b9b
    .catch Ljava/lang/Exception; {:try_start_b74 .. :try_end_b9b} :catch_b9c

    goto :goto_ba2

    :catch_b9c
    move-exception v0

    move-object v2, v0

    .line 188
    :try_start_b9e
    invoke-static {v2}, Lcom/github/catvod/crawler/SpiderDebug;->log(Ljava/lang/Throwable;)V

    :cond_ba1
    move-object v2, v14

    .line 189
    :goto_ba2
    invoke-direct {v1, v4}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/String;->isEmpty()Z

    move-result v3
    :try_end_baa
    .catch Ljava/lang/Exception; {:try_start_b9e .. :try_end_baa} :catch_d51

    if-nez v3, :cond_bd9

    .line 190
    :try_start_bac
    invoke-direct {v1, v4}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    if-eqz v6, :cond_bb7

    .line 191
    invoke-static {v11, v3}, Lcom/github/catvod/spider/XYQHiker;->getTextByRule(Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    goto :goto_bda

    .line 192
    :cond_bb7
    invoke-virtual {v3, v13}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v4

    const/4 v5, 0x0

    aget-object v4, v4, v5

    invoke-virtual {v3, v13}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v3

    const/4 v8, 0x1

    aget-object v3, v3, v8

    invoke-static {v15, v4, v3}, Lcom/github/catvod/spider/xbpqxyq/xyq/ވ;->އ(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/util/ArrayList;

    move-result-object v3

    invoke-virtual {v3, v5}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/lang/String;

    invoke-virtual {v1, v3}, Lcom/github/catvod/spider/XYQHiker;->މ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3
    :try_end_bd3
    .catch Ljava/lang/Exception; {:try_start_bac .. :try_end_bd3} :catch_bd4

    goto :goto_bda

    :catch_bd4
    move-exception v0

    move-object v3, v0

    .line 193
    :try_start_bd6
    invoke-static {v3}, Lcom/github/catvod/crawler/SpiderDebug;->log(Ljava/lang/Throwable;)V

    :cond_bd9
    move-object v3, v14

    .line 194
    :goto_bda
    invoke-direct {v1, v7}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/String;->isEmpty()Z

    move-result v4
    :try_end_be2
    .catch Ljava/lang/Exception; {:try_start_bd6 .. :try_end_be2} :catch_d51

    if-nez v4, :cond_c11

    .line 195
    :try_start_be4
    invoke-direct {v1, v7}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    if-eqz v6, :cond_bef

    .line 196
    invoke-static {v11, v4}, Lcom/github/catvod/spider/XYQHiker;->getTextByRule(Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    goto :goto_c12

    .line 197
    :cond_bef
    invoke-virtual {v4, v13}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v5

    const/4 v7, 0x0

    aget-object v5, v5, v7

    invoke-virtual {v4, v13}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v4

    const/4 v8, 0x1

    aget-object v4, v4, v8

    invoke-static {v15, v5, v4}, Lcom/github/catvod/spider/xbpqxyq/xyq/ވ;->އ(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/util/ArrayList;

    move-result-object v4

    invoke-virtual {v4, v7}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/lang/String;

    invoke-virtual {v1, v4}, Lcom/github/catvod/spider/XYQHiker;->މ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4
    :try_end_c0b
    .catch Ljava/lang/Exception; {:try_start_be4 .. :try_end_c0b} :catch_c0c

    goto :goto_c12

    :catch_c0c
    move-exception v0

    move-object v4, v0

    .line 198
    :try_start_c0e
    invoke-static {v4}, Lcom/github/catvod/crawler/SpiderDebug;->log(Ljava/lang/Throwable;)V

    :cond_c11
    move-object v4, v14

    .line 199
    :goto_c12
    invoke-direct {v1, v9}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/String;->isEmpty()Z

    move-result v5
    :try_end_c1a
    .catch Ljava/lang/Exception; {:try_start_c0e .. :try_end_c1a} :catch_d51

    if-nez v5, :cond_c73

    .line 200
    :try_start_c1c
    invoke-direct {v1, v9}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    if-eqz v6, :cond_c27

    .line 201
    invoke-static {v11, v5}, Lcom/github/catvod/spider/XYQHiker;->getTextByRule(Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    goto :goto_c74

    .line 202
    :cond_c27
    invoke-virtual {v5, v13}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v7

    const/4 v8, 0x0

    aget-object v7, v7, v8

    invoke-virtual {v5, v13}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v5

    const/4 v9, 0x1

    aget-object v5, v5, v9

    invoke-static {v15, v7, v5}, Lcom/github/catvod/spider/xbpqxyq/xyq/ވ;->އ(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/util/ArrayList;

    move-result-object v5

    invoke-virtual {v5, v8}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/lang/String;

    const-string v7, "2E643D33293449"

    invoke-static {v7}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    const-string v8, "52"

    invoke-static {v8}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v5, v7, v8}, Ljava/lang/String;->replaceAll(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    const-string v7, "2E640830773E336F090C21755E73632C61"

    invoke-static {v7}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v5, v7, v14}, Ljava/lang/String;->replaceAll(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    const-string v7, "4E190D6F076E4C"

    invoke-static {v7}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v5, v7, v14}, Ljava/lang/String;->replaceAll(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    const-string v7, "2E3128637639"

    invoke-static {v7}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v5, v7, v14}, Ljava/lang/String;->replaceAll(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5
    :try_end_c6d
    .catch Ljava/lang/Exception; {:try_start_c1c .. :try_end_c6d} :catch_c6e

    goto :goto_c74

    :catch_c6e
    move-exception v0

    move-object v5, v0

    .line 203
    :try_start_c70
    invoke-static {v5}, Lcom/github/catvod/crawler/SpiderDebug;->log(Ljava/lang/Throwable;)V

    :cond_c73
    move-object v5, v14

    .line 204
    :goto_c74
    invoke-direct {v1, v10}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v7}, Ljava/lang/String;->isEmpty()Z

    move-result v7
    :try_end_c7c
    .catch Ljava/lang/Exception; {:try_start_c70 .. :try_end_c7c} :catch_d51

    if-nez v7, :cond_cab

    .line 205
    :try_start_c7e
    invoke-direct {v1, v10}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    if-eqz v6, :cond_c89

    .line 206
    invoke-static {v11, v7}, Lcom/github/catvod/spider/XYQHiker;->getTextByRule(Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    goto :goto_cac

    .line 207
    :cond_c89
    invoke-virtual {v7, v13}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v6

    const/4 v8, 0x0

    aget-object v6, v6, v8

    invoke-virtual {v7, v13}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v7

    const/4 v9, 0x1

    aget-object v7, v7, v9

    invoke-static {v15, v6, v7}, Lcom/github/catvod/spider/xbpqxyq/xyq/ވ;->އ(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/util/ArrayList;

    move-result-object v6

    invoke-virtual {v6, v8}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Ljava/lang/String;

    invoke-virtual {v1, v6}, Lcom/github/catvod/spider/XYQHiker;->މ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6
    :try_end_ca5
    .catch Ljava/lang/Exception; {:try_start_c7e .. :try_end_ca5} :catch_ca6

    goto :goto_cac

    :catch_ca6
    move-exception v0

    move-object v6, v0

    .line 208
    :try_start_ca8
    invoke-static {v6}, Lcom/github/catvod/crawler/SpiderDebug;->log(Ljava/lang/Throwable;)V

    :cond_cab
    move-object v6, v14

    :goto_cac
    move-object/from16 v10, v17

    .line 209
    :goto_cae
    new-instance v7, Lorg/json/JSONObject;

    invoke-direct {v7}, Lorg/json/JSONObject;-><init>()V

    move-object/from16 v8, p1

    const/4 v9, 0x0

    .line 210
    invoke-interface {v8, v9}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v8

    move-object/from16 v9, v24

    invoke-virtual {v7, v9, v8}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const-string v8, "042D370E34251F27"

    invoke-static {v8}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    move-object/from16 v9, v23

    .line 211
    invoke-virtual {v7, v8, v9}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const-string v8, "042D370E2A2D11"

    invoke-static {v8}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    .line 212
    invoke-virtual {v7, v8, v10}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const-string v8, "063B2334052A132F36"

    invoke-static {v8}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    .line 213
    invoke-virtual {v7, v8, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const-string v2, "042D370E23211330"

    invoke-static {v2}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    .line 214
    invoke-virtual {v7, v2, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const-string v2, "042D370E3B361723"

    invoke-static {v2}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    .line 215
    invoke-virtual {v7, v2, v4}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const-string v2, "042D370E28211F23213A29"

    invoke-static {v2}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    .line 216
    invoke-virtual {v7, v2, v14}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const-string v2, "042D370E3B27062D21"

    invoke-static {v2}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    .line 217
    invoke-virtual {v7, v2, v5}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const-string v2, "042D370E3E2D002730253536"

    invoke-static {v2}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    .line 218
    invoke-virtual {v7, v2, v14}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const-string v2, "042D370E392B1C36363F2E"

    invoke-static {v2}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    .line 219
    invoke-virtual {v7, v2, v6}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const-string v2, "566677"

    invoke-static {v2}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    .line 220
    invoke-static {v2, v12}, Landroid/text/TextUtils;->join(Ljava/lang/CharSequence;Ljava/lang/Iterable;)Ljava/lang/String;

    move-result-object v2

    const-string v3, "566677"

    invoke-static {v3}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    move-object/from16 v4, v30

    .line 221
    invoke-static {v3, v4}, Landroid/text/TextUtils;->join(Ljava/lang/CharSequence;Ljava/lang/Iterable;)Ljava/lang/String;

    move-result-object v3

    const-string v4, "042D370E2A28133B0C37282B1F"

    invoke-static {v4}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    .line 222
    invoke-virtual {v7, v4, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const-string v2, "042D370E2A28133B0C242828"

    invoke-static {v2}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    .line 223
    invoke-virtual {v7, v2, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 224
    new-instance v2, Lorg/json/JSONObject;

    invoke-direct {v2}, Lorg/json/JSONObject;-><init>()V

    .line 225
    new-instance v3, Lorg/json/JSONArray;

    invoke-direct {v3}, Lorg/json/JSONArray;-><init>()V

    .line 226
    invoke-virtual {v3, v7}, Lorg/json/JSONArray;->put(Ljava/lang/Object;)Lorg/json/JSONArray;

    move-object/from16 v4, v22

    .line 227
    invoke-virtual {v2, v4, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 228
    invoke-virtual {v2}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object v2
    :try_end_d50
    .catch Ljava/lang/Exception; {:try_start_ca8 .. :try_end_d50} :catch_d51

    return-object v2

    :catch_d51
    move-exception v0

    goto :goto_d63

    :catch_d53
    move-exception v0

    move-object/from16 v14, v26

    goto :goto_d63

    :catch_d57
    move-exception v0

    move-object v14, v15

    goto :goto_d63

    :catch_d5a
    move-exception v0

    move-object v14, v9

    goto :goto_d63

    :catch_d5d
    move-exception v0

    move-object/from16 v14, v20

    goto :goto_d63

    :catch_d61
    move-exception v0

    move-object v14, v13

    :goto_d63
    move-object v2, v0

    .line 229
    :goto_d64
    invoke-static {v2}, Lcom/github/catvod/crawler/SpiderDebug;->log(Ljava/lang/Throwable;)V

    .line 230
    iget-boolean v3, v1, Lcom/github/catvod/spider/XYQHiker;->ވ:Z

    if-eqz v3, :cond_d87

    .line 231
    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, "9AEDF5B7D9C197C7FBB4EBC497C5E9B8CEDD9DFEC9"

    invoke-static {v4}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/Exception;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Lcom/github/catvod/spider/Init;->show(Ljava/lang/String;)V

    :cond_d87
    return-object v14
.end method

.method public homeContent(Z)Ljava/lang/String;
    .registers 31

    move-object/from16 v15, p0

    const-string v0, "95EFC8B8DACD94D7E3B7D7EA"

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const-string v1, "95EFC8B8DACD94CCC1B4E0CB94D9ECB7D7E69AEDDE"

    invoke-static {v1}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const-string v2, "95EFC8B8DACD94CCC1B4E0CB97D2DEB6FDF4"

    invoke-static {v2}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    const-string v3, "95EFC8B8DACD9AEDFEB9F2C494D9ECB7D7E69AEDDE"

    invoke-static {v3}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    const-string v4, "95EFC8B8DACD9AEDFEB9F2C497D2DEB6FDF4"

    invoke-static {v4}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    const-string v5, "95EFC8B8DACD97FBE7B5E1F994D9ECB7D7E69AEDDE"

    invoke-static {v5}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    const-string v6, "95EFC8B8DACD97FBE7B5E1F997D2DEB6FDF4"

    invoke-static {v6}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    const-string v7, "95EFC8B8DACD97DEE3B4D6FE94D9ECB7D7E69AEDDE"

    invoke-static {v7}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    const-string v8, "95EFC8B8DACD97DEE3B4D6FE97D2DEB6FDF4"

    invoke-static {v8}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    const-string v9, "95EFC8B8DACD95F3E8B4C4CF94D9ECB7D7E69AEDDE"

    invoke-static {v9}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    const-string v10, "95EFC8B8DACD95F3E8B4C4CF97D2DEB6FDF4"

    invoke-static {v10}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    const-string v11, "95EFC8B8DACD97EFC3B4D2C295F3E8B7C1FB94CFF1B9F5C9"

    invoke-static {v11}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v11

    const-string v12, "95EFC8B8DACD97EFC3B4D2C295F3E8B4CAC995E5E3"

    invoke-static {v12}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v12

    const-string v13, "97CAD5B6EBFF9BD1EDB7D4E1"

    invoke-static {v13}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v13

    const-string v14, "97CAD5B6EBFF97D2DEB6FDF494D9ECB7D7E69AEDDE"

    invoke-static {v14}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v14

    move-object/from16 v16, v0

    const-string v0, "97CAD5B6EBFF97D2DEB6FDF4"

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    move-object/from16 v17, v1

    const-string v1, "54"

    invoke-static {v1}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    move-object/from16 v18, v1

    const-string v1, ""

    .line 1
    :try_start_70
    invoke-virtual/range {p0 .. p0}, Lcom/github/catvod/spider/XYQHiker;->Ԯ()V
    :try_end_73
    .catch Ljava/lang/Exception; {:try_start_70 .. :try_end_73} :catch_31b

    move-object/from16 v19, v1

    .line 2
    :try_start_75
    new-instance v1, Lorg/json/JSONObject;

    invoke-direct {v1}, Lorg/json/JSONObject;-><init>()V

    move-object/from16 v20, v1

    .line 3
    new-instance v1, Lorg/json/JSONArray;

    invoke-direct {v1}, Lorg/json/JSONArray;-><init>()V

    .line 4
    invoke-direct {v15, v0}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v21

    invoke-virtual/range {v21 .. v21}, Ljava/lang/String;->isEmpty()Z

    move-result v21

    if-nez v21, :cond_8c

    goto :goto_92

    :cond_8c
    const-string v0, "112E3222291B1C233E34"

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 5
    :goto_92
    invoke-direct {v15, v14}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v21

    invoke-virtual/range {v21 .. v21}, Ljava/lang/String;->isEmpty()Z

    move-result v21

    if-nez v21, :cond_9d

    goto :goto_a3

    :cond_9d
    const-string v14, "112E3222291B04233F243F"

    invoke-static {v14}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v14

    .line 6
    :goto_a3
    invoke-direct {v15, v13}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v21

    invoke-virtual/range {v21 .. v21}, Ljava/lang/String;->isEmpty()Z

    move-result v21

    if-nez v21, :cond_ae

    goto :goto_b4

    :cond_ae
    const-string v13, "112E3222291B07303F"

    invoke-static {v13}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v13

    .line 7
    :goto_b4
    invoke-direct {v15, v12}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v21

    invoke-virtual/range {v21 .. v21}, Ljava/lang/String;->isEmpty()Z

    move-result v21

    if-nez v21, :cond_bf

    goto :goto_c5

    :cond_bf
    const-string v12, "14213F3029372D2C323C3F"

    invoke-static {v12}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v12

    .line 8
    :goto_c5
    invoke-direct {v15, v11}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v21

    invoke-virtual/range {v21 .. v21}, Ljava/lang/String;->isEmpty()Z

    move-result v21

    if-nez v21, :cond_d0

    goto :goto_d6

    :cond_d0
    const-string v11, "14213F3029372D34323D2F21"

    invoke-static {v11}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v11

    .line 9
    :goto_d6
    invoke-direct {v15, v10}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v21

    invoke-virtual/range {v21 .. v21}, Ljava/lang/String;->isEmpty()Z

    move-result v21

    if-nez v21, :cond_e1

    goto :goto_e7

    :cond_e1
    const-string v10, "142132253F281D250C3F3B2917"

    invoke-static {v10}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    .line 10
    :goto_e7
    invoke-direct {v15, v9}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v21

    invoke-virtual/range {v21 .. v21}, Ljava/lang/String;->isEmpty()Z

    move-result v21

    if-nez v21, :cond_f2

    goto :goto_f8

    :cond_f2
    const-string v9, "142132253F281D250C273B280727"

    invoke-static {v9}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    .line 11
    :goto_f8
    invoke-direct {v15, v8}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v21

    invoke-virtual/range {v21 .. v21}, Ljava/lang/String;->isEmpty()Z

    move-result v21

    if-nez v21, :cond_103

    goto :goto_109

    :cond_103
    const-string v8, "142321343B1B1C233E34"

    invoke-static {v8}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    .line 12
    :goto_109
    invoke-direct {v15, v7}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v21

    invoke-virtual/range {v21 .. v21}, Ljava/lang/String;->isEmpty()Z

    move-result v21

    if-nez v21, :cond_114

    goto :goto_11a

    :cond_114
    const-string v7, "142321343B1B04233F243F"

    invoke-static {v7}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    .line 13
    :goto_11a
    invoke-direct {v15, v6}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v21

    invoke-virtual/range {v21 .. v21}, Ljava/lang/String;->isEmpty()Z

    move-result v21

    if-nez v21, :cond_125

    goto :goto_12b

    :cond_125
    const-string v6, "143B3630281B1C233E34"

    invoke-static {v6}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    .line 14
    :goto_12b
    invoke-direct {v15, v5}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v21

    invoke-virtual/range {v21 .. v21}, Ljava/lang/String;->isEmpty()Z

    move-result v21

    if-nez v21, :cond_136

    goto :goto_13c

    :cond_136
    const-string v5, "143B3630281B04233F243F"

    invoke-static {v5}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    .line 15
    :goto_13c
    invoke-direct {v15, v4}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v21

    invoke-virtual/range {v21 .. v21}, Ljava/lang/String;->isEmpty()Z

    move-result v21

    if-nez v21, :cond_147

    goto :goto_14d

    :cond_147
    const-string v4, "142E323F3D1B1C233E34"

    invoke-static {v4}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    .line 16
    :goto_14d
    invoke-direct {v15, v3}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v21

    invoke-virtual/range {v21 .. v21}, Ljava/lang/String;->isEmpty()Z

    move-result v21

    if-nez v21, :cond_158

    goto :goto_15e

    :cond_158
    const-string v3, "142E323F3D1B04233F243F"

    invoke-static {v3}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    .line 17
    :goto_15e
    invoke-direct {v15, v2}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v21

    invoke-virtual/range {v21 .. v21}, Ljava/lang/String;->isEmpty()Z

    move-result v21

    if-nez v21, :cond_169

    goto :goto_16f

    :cond_169
    const-string v2, "14313C232E1B1C233E34"

    invoke-static {v2}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    :goto_16f
    move-object/from16 v21, v1

    move-object/from16 v1, v17

    .line 18
    invoke-direct {v15, v1}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v17

    invoke-virtual/range {v17 .. v17}, Ljava/lang/String;->isEmpty()Z

    move-result v17

    if-nez v17, :cond_17e

    goto :goto_184

    :cond_17e
    const-string v1, "14313C232E1B04233F243F"

    invoke-static {v1}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    .line 19
    :goto_184
    invoke-direct {v15, v14}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v14

    .line 20
    invoke-direct {v15, v13}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v13

    .line 21
    invoke-direct {v15, v12}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v12

    .line 22
    invoke-direct {v15, v11}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v11

    .line 23
    invoke-direct {v15, v10}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    .line 24
    invoke-direct {v15, v9}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    .line 25
    invoke-direct {v15, v8}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    .line 26
    invoke-direct {v15, v7}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v17

    .line 27
    invoke-static {}, Lcom/github/catvod/spider/XYQHiker;->ԫ()Ljava/lang/String;

    move-result-object v7

    invoke-direct {v15, v6, v7}, Lcom/github/catvod/spider/XYQHiker;->ރ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v22

    const-string v6, "58"

    invoke-static {v6}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    .line 28
    invoke-direct {v15, v5, v6}, Lcom/github/catvod/spider/XYQHiker;->ރ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v23

    .line 29
    invoke-direct {v15, v4}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v24

    .line 30
    invoke-direct {v15, v3}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v25

    const-string v3, "94D5E5B8CDF054A6E9EBBCF4E664BBFEDEA1FAC4"

    invoke-static {v3}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    .line 31
    invoke-direct {v15, v2, v3}, Lcom/github/catvod/spider/XYQHiker;->ރ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v26

    const-string v2, "062B3E347C2C1B36207729271D3036"

    invoke-static {v2}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    .line 32
    invoke-direct {v15, v1, v2}, Lcom/github/catvod/spider/XYQHiker;->ރ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v27
    :try_end_1d2
    .catch Ljava/lang/Exception; {:try_start_75 .. :try_end_1d2} :catch_316

    move-object/from16 v1, v19

    .line 33
    :try_start_1d4
    invoke-direct {v15, v0, v1}, Lcom/github/catvod/spider/XYQHiker;->ރ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    move-object/from16 v2, v18

    invoke-virtual {v0, v2}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v0

    .line 34
    invoke-virtual {v14, v2}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v3

    const/4 v4, 0x0

    .line 35
    :goto_1e3
    array-length v5, v0

    if-ge v4, v5, :cond_219

    .line 36
    new-instance v5, Lorg/json/JSONObject;

    invoke-direct {v5}, Lorg/json/JSONObject;-><init>()V

    const-string v6, "063B2334052D16"

    invoke-static {v6}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    .line 37
    aget-object v7, v3, v4

    move-object/from16 v18, v3

    const-string v3, "9DFED5BEE6C2"

    invoke-static {v3}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v7, v3, v2}, Ljava/lang/String;->replaceAll(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v5, v6, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const-string v3, "063B2334052A132F36"

    invoke-static {v3}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    .line 38
    aget-object v6, v0, v4

    invoke-virtual {v5, v3, v6}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    move-object/from16 v3, v21

    .line 39
    invoke-virtual {v3, v5}, Lorg/json/JSONArray;->put(Ljava/lang/Object;)Lorg/json/JSONArray;

    add-int/lit8 v4, v4, 0x1

    move-object/from16 v21, v3

    move-object/from16 v3, v18

    goto :goto_1e3

    :cond_219
    move-object/from16 v3, v21

    const-string v0, "112E322229"

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    move-object/from16 v2, v20

    .line 40
    invoke-virtual {v2, v0, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    :try_end_226
    .catch Ljava/lang/Exception; {:try_start_1d4 .. :try_end_226} :catch_31b

    move-object/from16 v0, v16

    .line 41
    :try_start_228
    invoke-direct {v15, v0}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/String;->isEmpty()Z

    move-result v3

    if-nez v3, :cond_233

    goto :goto_239

    :cond_233
    const-string v0, "142B3F253F3616232730"

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 42
    :goto_239
    invoke-direct {v15, v0, v1}, Lcom/github/catvod/spider/XYQHiker;->ރ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    .line 43
    invoke-static {}, Ljava/net/InetAddress;->getLocalHost()Ljava/net/InetAddress;

    const-string v4, "112E323F606B5D"

    invoke-static {v4}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    .line 44
    invoke-virtual {v3, v4}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v4

    const/4 v5, 0x0

    if-nez v4, :cond_2a5

    const-string v4, "1A362721"

    invoke-static {v4}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v4

    if-nez v4, :cond_2a5

    const-string v4, "5C6D"

    invoke-static {v4}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v4

    if-eqz v4, :cond_266

    goto :goto_2a5

    :cond_266
    const-string v4, "371A07"

    invoke-static {v4}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    .line 45
    invoke-virtual {v3, v4}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v3
    :try_end_270
    .catch Ljava/lang/Exception; {:try_start_228 .. :try_end_270} :catch_2e8

    if-eqz v3, :cond_299

    move-object/from16 v16, v1

    move-object v7, v2

    move-object/from16 v1, p0

    move-object v2, v14

    move-object v3, v13

    move-object v4, v12

    move-object v5, v11

    move-object v6, v10

    move-object v14, v7

    move-object v7, v9

    move-object/from16 v9, v17

    move-object/from16 v10, v22

    move-object/from16 v11, v23

    move-object/from16 v12, v24

    move-object/from16 v13, v25

    move-object/from16 v28, v14

    move-object/from16 v14, v26

    move-object/from16 v15, v27

    .line 46
    :try_start_28e
    invoke-direct/range {v1 .. v15}, Lcom/github/catvod/spider/XYQHiker;->Ԫ(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v5
    :try_end_292
    .catch Ljava/lang/Exception; {:try_start_28e .. :try_end_292} :catch_295

    move-object/from16 v1, p0

    goto :goto_2cf

    :catch_295
    move-exception v0

    move-object/from16 v1, p0

    goto :goto_2e5

    :cond_299
    move-object/from16 v16, v1

    move-object/from16 v28, v2

    move-object v1, v15

    .line 47
    :try_start_29e
    iget-object v2, v1, Lcom/github/catvod/spider/XYQHiker;->ކ:Lorg/json/JSONObject;

    invoke-virtual {v2, v0}, Lorg/json/JSONObject;->optJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v5

    goto :goto_2cf

    :cond_2a5
    :goto_2a5
    move-object/from16 v16, v1

    move-object/from16 v28, v2

    move-object v1, v15

    .line 48
    invoke-static {v3, v5}, Lcom/github/catvod/spider/xbpqxyq/xyq/ތ;->֏(Ljava/lang/String;Ljava/util/Map;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v0

    const-string v2, "09"

    invoke-static {v2}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    .line 49
    invoke-virtual {v0, v2}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_2cf

    const-string v2, "0F"

    invoke-static {v2}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Ljava/lang/String;->endsWith(Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_2cf

    .line 50
    new-instance v5, Lorg/json/JSONObject;

    invoke-direct {v5, v0}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    :cond_2cf
    :goto_2cf
    if-eqz p1, :cond_2e1

    if-eqz v5, :cond_2e1

    const-string v0, "142B3F253F3601"

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0
    :try_end_2d9
    .catch Ljava/lang/Exception; {:try_start_29e .. :try_end_2d9} :catch_2e4

    move-object/from16 v2, v28

    .line 51
    :try_start_2db
    invoke-virtual {v2, v0, v5}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    :try_end_2de
    .catch Ljava/lang/Exception; {:try_start_2db .. :try_end_2de} :catch_2df

    goto :goto_30f

    :catch_2df
    move-exception v0

    goto :goto_2ec

    :cond_2e1
    move-object/from16 v2, v28

    goto :goto_30f

    :catch_2e4
    move-exception v0

    :goto_2e5
    move-object/from16 v2, v28

    goto :goto_2ec

    :catch_2e8
    move-exception v0

    move-object/from16 v16, v1

    move-object v1, v15

    .line 52
    :goto_2ec
    :try_start_2ec
    invoke-static {v0}, Lcom/github/catvod/crawler/SpiderDebug;->log(Ljava/lang/Throwable;)V

    .line 53
    iget-boolean v3, v1, Lcom/github/catvod/spider/XYQHiker;->ވ:Z

    if-eqz v3, :cond_30f

    .line 54
    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, "1A2D3E34192B1C36363F2EA3DFD9BAD1D3ADF1EAB6D9DCA1F5F8BAC5C3ABCED8"

    invoke-static {v4}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/Exception;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lcom/github/catvod/spider/Init;->show(Ljava/lang/String;)V

    .line 55
    :cond_30f
    :goto_30f
    invoke-virtual {v2}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object v0
    :try_end_313
    .catch Ljava/lang/Exception; {:try_start_2ec .. :try_end_313} :catch_314

    return-object v0

    :catch_314
    move-exception v0

    goto :goto_31f

    :catch_316
    move-exception v0

    move-object v1, v15

    move-object/from16 v16, v19

    goto :goto_31f

    :catch_31b
    move-exception v0

    move-object/from16 v16, v1

    move-object v1, v15

    .line 56
    :goto_31f
    invoke-static {v0}, Lcom/github/catvod/crawler/SpiderDebug;->log(Ljava/lang/Throwable;)V

    .line 57
    iget-boolean v2, v1, Lcom/github/catvod/spider/XYQHiker;->ވ:Z

    if-eqz v2, :cond_342

    .line 58
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "1A2D3E34192B1C36363F2EA1F7EAB6E0DAA1F5F8BAC5C3ABCED8"

    invoke-static {v3}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/Exception;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lcom/github/catvod/spider/Init;->show(Ljava/lang/String;)V

    :cond_342
    return-object v16
.end method

.method public homeVideoContent()Ljava/lang/String;
    .registers 39

    move-object/from16 v1, p0

    const-string v0, "9BE4C5B8FBF195CBD4B4D7D197CBFCB7FAC39BE0CB"

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const-string v2, "9BE4C5B8FBF195CBD4B4D7D197D9EDB6D3C3"

    invoke-static {v2}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    const-string v3, "9BE4C5B8FBF195CBD4B4D7D19BD1EDB7D4E1"

    invoke-static {v3}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    const-string v4, "9BE4C5B8FBF195CBD4B4D7D194E2D4B8F8DC"

    invoke-static {v4}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    const-string v5, "9BE4C5B8FBF195CBD4B4D7D194DAFCB4CAE238313C242AA1F4DBB5E2CF"

    invoke-static {v5}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    const-string v6, "9BE4C5B8FBF195CBD4B4D7D197CAC4B9FBEC94D7E3B6E1C09AE5D7B4D2DD"

    invoke-static {v6}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    const-string v7, "9BE4C5B8FBF197CAC4B9FBEC94D7E3B6E1C09AE5D7B4D2DD"

    invoke-static {v7}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    const-string v8, "9BE4C5B8FBF194CCFBB9D7D49BD1EDB7D4E1"

    invoke-static {v8}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    const-string v9, "97D9EDB6D3C394DAFCB4CAE29BDED3B9FCC596F9F0B6CAC2"

    invoke-static {v9}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    const-string v10, "94DAFCB4CAE297FED3B4CAEB9ACCE4B4D5D29BE4C5B8FBF194D7E3B7D7EA"

    invoke-static {v10}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    const-string v11, "1F266679"

    invoke-static {v11}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v11

    const-string v12, ""

    const-string v13, "5464"

    invoke-static {v13}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v13

    .line 1
    :try_start_4c
    invoke-virtual/range {p0 .. p0}, Lcom/github/catvod/spider/XYQHiker;->Ԯ()V

    .line 2
    invoke-direct {v1, v10}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v14

    invoke-virtual {v14}, Ljava/lang/String;->isEmpty()Z

    move-result v14

    if-nez v14, :cond_5a

    goto :goto_60

    :cond_5a
    const-string v10, "1A2D3E34192B1C36363F2E"

    invoke-static {v10}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    .line 3
    :goto_60
    invoke-direct {v1, v9}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v14

    invoke-virtual {v14}, Ljava/lang/String;->isEmpty()Z

    move-result v14

    if-nez v14, :cond_6b

    goto :goto_71

    :cond_6b
    const-string v9, "222B301F3F211612213E223D"

    invoke-static {v9}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    .line 4
    :goto_71
    invoke-direct {v1, v8}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v14

    invoke-virtual {v14}, Ljava/lang/String;->isEmpty()Z

    move-result v14

    if-nez v14, :cond_7c

    goto :goto_82

    :cond_7c
    const-string v8, "00213E343E1B07303F"

    invoke-static {v8}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    .line 5
    :goto_82
    invoke-direct {v1, v7}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v14

    invoke-virtual {v14}, Ljava/lang/String;->isEmpty()Z

    move-result v14

    if-nez v14, :cond_8d

    goto :goto_93

    :cond_8d
    const-string v7, "1A2D3E34052500300C232F2817"

    invoke-static {v7}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    .line 6
    :goto_93
    invoke-direct {v1, v6}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v14

    invoke-virtual {v14}, Ljava/lang/String;->isEmpty()Z

    move-result v14

    if-nez v14, :cond_9e

    goto :goto_a4

    :cond_9e
    const-string v6, "1A2F3621331B1330210E28311E27"

    invoke-static {v6}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    .line 7
    :goto_a4
    invoke-direct {v1, v5}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v14

    invoke-virtual {v14}, Ljava/lang/String;->isEmpty()Z

    move-result v14

    if-nez v14, :cond_af

    goto :goto_b5

    :cond_af
    const-string v5, "1A2D3E34052D011D3922353102"

    invoke-static {v5}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    .line 8
    :goto_b5
    invoke-direct {v1, v4}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v14

    invoke-virtual {v14}, Ljava/lang/String;->isEmpty()Z

    move-result v14

    if-nez v14, :cond_c0

    goto :goto_c6

    :cond_c0
    const-string v4, "1A2D3E3405301B363F34"

    invoke-static {v4}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    .line 9
    :goto_c6
    invoke-direct {v1, v3}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v14

    invoke-virtual {v14}, Ljava/lang/String;->isEmpty()Z

    move-result v14

    if-nez v14, :cond_d1

    goto :goto_d7

    :cond_d1
    const-string v3, "1A2D3E340531002E"

    invoke-static {v3}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    .line 10
    :goto_d7
    invoke-direct {v1, v2}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v14

    invoke-virtual {v14}, Ljava/lang/String;->isEmpty()Z

    move-result v14

    if-nez v14, :cond_e2

    goto :goto_e8

    :cond_e2
    const-string v2, "1A2D3E3405341B21"

    invoke-static {v2}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    .line 11
    :goto_e8
    invoke-direct {v1, v0}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v14

    invoke-virtual {v14}, Ljava/lang/String;->isEmpty()Z

    move-result v14

    if-nez v14, :cond_f3

    goto :goto_f9

    :cond_f3
    const-string v0, "1A2D3E340537072027382E2817"

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    :goto_f9
    move-object v14, v0

    const-string v0, "9BE4C5B8FBF195CBD4B4D7D19BD1EDB7D4E197C8F3B4D3C995FED3"

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 12
    invoke-direct {v1, v0}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/String;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_111

    const-string v0, "9BE4C5B8FBF195CBD4B4D7D19BD1EDB7D4E197C8F3B4D3C995FED3"

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    goto :goto_117

    :cond_111
    const-string v0, "1A2D3E3405340027353822"

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    :goto_117
    const-string v15, "9BE4C5B8FBF195CBD4B4D7D19BD1EDB7D4E197C8F3B4CACA95FED3"

    invoke-static {v15}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v15

    .line 13
    invoke-direct {v1, v15}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v15

    invoke-virtual {v15}, Ljava/lang/String;->isEmpty()Z

    move-result v15

    if-nez v15, :cond_12e

    const-string v15, "9BE4C5B8FBF195CBD4B4D7D19BD1EDB7D4E197C8F3B4CACA95FED3"

    invoke-static {v15}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v15

    goto :goto_134

    :cond_12e
    const-string v15, "1A2D3E3405370724353822"

    invoke-static {v15}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v15

    :goto_134
    move-object/from16 v16, v3

    const-string v3, "97CAD5B6EBFF97D2DEB6FDF494D9ECB7D7E69AEDDE"

    invoke-static {v3}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    .line 14
    invoke-direct {v1, v3}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/String;->isEmpty()Z

    move-result v3

    if-nez v3, :cond_14d

    const-string v3, "97CAD5B6EBFF97D2DEB6FDF494D9ECB7D7E69AEDDE"

    invoke-static {v3}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    goto :goto_153

    :cond_14d
    const-string v3, "112E3222291B04233F243F"

    invoke-static {v3}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    :goto_153
    move-object/from16 v17, v14

    .line 15
    new-instance v14, Lorg/json/JSONArray;

    invoke-direct {v14}, Lorg/json/JSONArray;-><init>()V

    move-object/from16 v18, v2

    .line 16
    new-instance v2, Lorg/json/JSONObject;

    invoke-direct {v2}, Lorg/json/JSONObject;-><init>()V

    .line 17
    invoke-direct {v1, v8}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v19

    invoke-virtual/range {v19 .. v19}, Ljava/lang/String;->isEmpty()Z

    move-result v19
    :try_end_169
    .catch Ljava/lang/Exception; {:try_start_4c .. :try_end_169} :catch_942

    move-object/from16 v20, v4

    const-string v4, "1E2B2025"

    invoke-static {v4}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    move-object/from16 v21, v7

    const-string v7, "54"

    invoke-static {v7}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    move-object/from16 v22, v15

    const-string v15, "94DAFC"

    invoke-static {v15}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v15

    move-object/from16 v23, v13

    const-string v13, "43"

    invoke-static {v13}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v13

    move-object/from16 v24, v11

    if-nez v19, :cond_19e

    :try_start_18d
    invoke-direct {v1, v6}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v19

    invoke-virtual/range {v19 .. v19}, Ljava/lang/String;->isEmpty()Z

    move-result v19

    if-eqz v19, :cond_198

    goto :goto_19e

    :cond_198
    move-object/from16 v28, v7

    move-object/from16 v25, v12

    goto/16 :goto_20f

    .line 18
    :cond_19e
    :goto_19e
    invoke-direct {v1, v10}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v11

    invoke-virtual {v11, v13}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v11

    if-nez v11, :cond_1b2

    invoke-direct {v1, v10}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v11

    invoke-virtual {v11, v15}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v11

    if-eqz v11, :cond_198

    .line 19
    :cond_1b2
    invoke-direct {v1, v3, v12}, Lcom/github/catvod/spider/XYQHiker;->ރ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v3, v7}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v3

    .line 20
    array-length v11, v3
    :try_end_1bb
    .catch Ljava/lang/Exception; {:try_start_18d .. :try_end_1bb} :catch_942

    move-object/from16 v25, v12

    const/4 v12, 0x0

    :goto_1be
    if-ge v12, v11, :cond_20a

    move/from16 v26, v11

    :try_start_1c2
    aget-object v11, v3, v12

    move-object/from16 v27, v3

    const-string v3, "9DFED5BEE6C2"

    invoke-static {v3}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    .line 21
    invoke-virtual {v11, v3, v7}, Ljava/lang/String;->replaceAll(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    new-instance v11, Ljava/util/HashMap;

    invoke-direct {v11}, Ljava/util/HashMap;-><init>()V

    move-object/from16 v28, v7

    const/4 v7, 0x0

    invoke-direct {v1, v3, v13, v7, v11}, Lcom/github/catvod/spider/XYQHiker;->Ԩ(Ljava/lang/String;Ljava/lang/String;ZLjava/util/HashMap;)Lorg/json/JSONObject;

    move-result-object v3

    if-eqz v3, :cond_1f8

    .line 22
    invoke-virtual {v3, v4}, Lorg/json/JSONObject;->optJSONArray(Ljava/lang/String;)Lorg/json/JSONArray;

    move-result-object v3

    if-eqz v3, :cond_1f8

    const/4 v7, 0x0

    .line 23
    :goto_1e5
    invoke-virtual {v3}, Lorg/json/JSONArray;->length()I

    move-result v11

    if-ge v7, v11, :cond_1f8

    const/4 v11, 0x5

    if-ge v7, v11, :cond_1f8

    .line 24
    invoke-virtual {v3, v7}, Lorg/json/JSONArray;->getJSONObject(I)Lorg/json/JSONObject;

    move-result-object v11

    invoke-virtual {v14, v11}, Lorg/json/JSONArray;->put(Ljava/lang/Object;)Lorg/json/JSONArray;

    add-int/lit8 v7, v7, 0x1

    goto :goto_1e5

    .line 25
    :cond_1f8
    invoke-virtual {v14}, Lorg/json/JSONArray;->length()I

    move-result v3

    const/16 v7, 0x14

    if-lt v3, v7, :cond_201

    goto :goto_20c

    :cond_201
    add-int/lit8 v12, v12, 0x1

    move/from16 v11, v26

    move-object/from16 v3, v27

    move-object/from16 v7, v28

    goto :goto_1be

    :cond_20a
    move-object/from16 v28, v7

    .line 26
    :goto_20c
    invoke-virtual {v2, v4, v14}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 27
    :goto_20f
    invoke-direct {v1, v8}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/String;->isEmpty()Z

    move-result v3

    if-eqz v3, :cond_228

    invoke-direct {v1, v6}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/String;->isEmpty()Z

    move-result v3

    if-nez v3, :cond_224

    goto :goto_228

    :cond_224
    move-object/from16 v11, v25

    goto/16 :goto_937

    .line 28
    :cond_228
    :goto_228
    invoke-direct {v1, v10}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v3, v13}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_23c

    invoke-direct {v1, v10}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v3, v15}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_224

    :cond_23c
    const-string v3, "95FFC2B8FBF195FEC5B6FAC594E2EFB4E6CB"

    invoke-static {v3}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    .line 29
    invoke-direct {v1, v3}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/String;->isEmpty()Z

    move-result v3

    if-nez v3, :cond_253

    const-string v3, "95FFC2B8FBF195FEC5B6FAC594E2EFB4E6CB"

    invoke-static {v3}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    goto :goto_259

    :cond_253
    const-string v3, "312D373834232D243C23372506"

    invoke-static {v3}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    :goto_259
    const-string v7, "2716157C62"

    invoke-static {v7}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    .line 30
    invoke-direct {v1, v3, v7}, Lcom/github/catvod/spider/XYQHiker;->ރ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    iput-object v3, v1, Lcom/github/catvod/spider/XYQHiker;->ހ:Ljava/lang/String;

    const-string v3, "97CAD5B6EBFF95CBD4B4D7D194DAFCB4CAE238313C242AA1F4DBB5E2CF"

    invoke-static {v3}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    .line 31
    invoke-direct {v1, v3}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/String;->isEmpty()Z

    move-result v3

    if-nez v3, :cond_27c

    const-string v3, "97CAD5B6EBFF95CBD4B4D7D194DAFCB4CAE238313C242AA1F4DBB5E2CF"

    invoke-static {v3}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    goto :goto_282

    :cond_27c
    const-string v3, "1123270E33372D28203E2F34"

    invoke-static {v3}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    :goto_282
    const-string v7, "97CAD5B6EBFF95CBD4B4D7D194E2D4B8F8DC"

    invoke-static {v7}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    .line 32
    invoke-direct {v1, v7}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v7}, Ljava/lang/String;->isEmpty()Z

    move-result v7

    if-nez v7, :cond_299

    const-string v7, "97CAD5B6EBFF95CBD4B4D7D194E2D4B8F8DC"

    invoke-static {v7}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    goto :goto_29f

    :cond_299
    const-string v7, "1123270E2E2D062E36"

    invoke-static {v7}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    :goto_29f
    const-string v10, "97CAD5B6EBFF95CBD4B4D7D19BD1EDB7D4E1"

    invoke-static {v10}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    .line 33
    invoke-direct {v1, v10}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v10}, Ljava/lang/String;->isEmpty()Z

    move-result v10

    if-nez v10, :cond_2b6

    const-string v10, "97CAD5B6EBFF95CBD4B4D7D19BD1EDB7D4E1"

    invoke-static {v10}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    goto :goto_2bc

    :cond_2b6
    const-string v10, "1123270E2F361E"

    invoke-static {v10}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    :goto_2bc
    const-string v11, "97CAD5B6EBFF95CBD4B4D7D197D9EDB6D3C3"

    invoke-static {v11}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v11

    .line 34
    invoke-direct {v1, v11}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v11

    invoke-virtual {v11}, Ljava/lang/String;->isEmpty()Z

    move-result v11

    if-nez v11, :cond_2d3

    const-string v11, "97CAD5B6EBFF95CBD4B4D7D197D9EDB6D3C3"

    invoke-static {v11}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v11

    goto :goto_2d9

    :cond_2d3
    const-string v11, "1123270E2A2D11"

    invoke-static {v11}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v11

    :goto_2d9
    const-string v12, "97CAD5B6EBFF95CBD4B4D7D197CBFCB7FAC39BE0CB"

    invoke-static {v12}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v12

    .line 35
    invoke-direct {v1, v12}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v12

    invoke-virtual {v12}, Ljava/lang/String;->isEmpty()Z

    move-result v12

    if-nez v12, :cond_2f0

    const-string v12, "97CAD5B6EBFF95CBD4B4D7D197CBFCB7FAC39BE0CB"

    invoke-static {v12}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v12

    goto :goto_2f6

    :cond_2f0
    const-string v12, "1123270E293110363A253621"

    invoke-static {v12}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v12

    :goto_2f6
    move-object/from16 v26, v2

    const-string v2, "97CAD5B6EBFF95CBD4B4D7D19BD1EDB7D4E197C8F3B4D3C995FED3"

    invoke-static {v2}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    .line 36
    invoke-direct {v1, v2}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/String;->isEmpty()Z

    move-result v2

    if-nez v2, :cond_30f

    const-string v2, "97CAD5B6EBFF95CBD4B4D7D19BD1EDB7D4E197C8F3B4D3C995FED3"

    invoke-static {v2}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    goto :goto_315

    :cond_30f
    const-string v2, "1123270E2A3617243A29"

    invoke-static {v2}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    :goto_315
    move-object/from16 v27, v4

    const-string v4, "97CAD5B6EBFF95CBD4B4D7D19BD1EDB7D4E197C8F3B4CACA95FED3"

    invoke-static {v4}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    .line 37
    invoke-direct {v1, v4}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/String;->isEmpty()Z

    move-result v4

    if-nez v4, :cond_32e

    const-string v4, "97CAD5B6EBFF95CBD4B4D7D19BD1EDB7D4E197C8F3B4CACA95FED3"

    invoke-static {v4}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    goto :goto_334

    :cond_32e
    const-string v4, "1123270E293114243A29"

    invoke-static {v4}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    :goto_334
    move-object/from16 v29, v14

    .line 38
    invoke-direct {v1, v5, v13}, Lcom/github/catvod/spider/XYQHiker;->ރ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v14

    invoke-virtual {v14, v13}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v14

    move-object/from16 v30, v10

    if-nez v14, :cond_34f

    invoke-direct {v1, v5, v15}, Lcom/github/catvod/spider/XYQHiker;->ރ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v5, v15}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_34d

    goto :goto_34f

    :cond_34d
    const/4 v5, 0x0

    goto :goto_350

    :cond_34f
    :goto_34f
    const/4 v5, 0x1

    .line 39
    :goto_350
    invoke-direct {v1, v9}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v14

    invoke-virtual {v14, v13}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v14

    if-nez v14, :cond_367

    invoke-direct {v1, v9}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v9, v15}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v9

    if-eqz v9, :cond_365

    goto :goto_367

    :cond_365
    const/4 v9, 0x0

    goto :goto_368

    :cond_367
    :goto_367
    const/4 v9, 0x1

    .line 40
    :goto_368
    invoke-direct {v1, v3, v13}, Lcom/github/catvod/spider/XYQHiker;->ރ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v14

    invoke-virtual {v14, v13}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v13

    if-nez v13, :cond_37f

    invoke-direct {v1, v3, v15}, Lcom/github/catvod/spider/XYQHiker;->ރ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v3, v15}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_37d

    goto :goto_37f

    :cond_37d
    const/4 v3, 0x0

    goto :goto_380

    :cond_37f
    :goto_37f
    const/4 v3, 0x1

    .line 41
    :goto_380
    invoke-direct {v1, v8}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    .line 42
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v13

    const-wide/16 v31, 0x3e8

    div-long v13, v13, v31

    invoke-static {v13, v14}, Ljava/lang/String;->valueOf(J)Ljava/lang/String;

    move-result-object v13

    .line 43
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v14

    invoke-static {v14, v15}, Ljava/lang/String;->valueOf(J)Ljava/lang/String;

    move-result-object v14

    const-string v15, "94D5E5B8CDF094CAE0"

    invoke-static {v15}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v15

    .line 44
    invoke-virtual {v8, v15, v13}, Ljava/lang/String;->replaceAll(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    const-string v13, "94D5E5B8CDF094E2D4"

    invoke-static {v13}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v13

    .line 45
    invoke-virtual {v8, v13, v14}, Ljava/lang/String;->replaceAll(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    move-object/from16 v13, v24

    .line 46
    invoke-virtual {v8, v13}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v14
    :try_end_3b2
    .catch Ljava/lang/Exception; {:try_start_1c2 .. :try_end_3b2} :catch_93e

    const-string v15, "5B"

    invoke-static {v15}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v15

    if-eqz v14, :cond_3e1

    .line 47
    :try_start_3ba
    invoke-static {v8, v13, v15}, Lcom/github/catvod/spider/xbpqxyq/xyq/ވ;->އ(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/util/ArrayList;

    move-result-object v14

    const/4 v10, 0x0

    invoke-virtual {v14, v10}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v14

    check-cast v14, Ljava/lang/String;

    .line 48
    new-instance v10, Ljava/lang/StringBuilder;

    invoke-direct {v10}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v10, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v10, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v10, v15}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v10}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v10

    sget-object v13, Lcom/github/catvod/spider/xbpqxyq/xyq/ކ;->ԩ:Ljava/nio/charset/Charset;

    invoke-static {v14, v13}, Lcom/github/catvod/spider/xbpqxyq/xyq/ކ;->Ϳ(Ljava/lang/String;Ljava/nio/charset/Charset;)Ljava/lang/String;

    move-result-object v13

    invoke-virtual {v8, v10, v13}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object v8

    :cond_3e1
    const-string v10, "49323C222E"

    invoke-static {v10}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    .line 49
    invoke-virtual {v8, v10}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v10

    if-eqz v10, :cond_4d6

    const-string v10, "2E7D"

    invoke-static {v10}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    .line 50
    invoke-virtual {v8, v10}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v10

    const/4 v13, 0x0

    aget-object v10, v10, v13

    const-string v13, "9DFECCBEE6DB"

    invoke-static {v13}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v13

    const-string v14, "4D"

    invoke-static {v14}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v14

    invoke-virtual {v10, v13, v14}, Ljava/lang/String;->replaceAll(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v10}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v10

    const-string v13, "2E7D"

    invoke-static {v13}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v13

    .line 51
    invoke-virtual {v8, v13}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v13

    const/4 v14, 0x1

    aget-object v13, v13, v14

    const-string v14, "49"

    invoke-static {v14}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v14

    invoke-virtual {v13, v14}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v13

    const/4 v14, 0x0

    aget-object v13, v13, v14

    const-string v14, "9DFECCBEE6DB"

    invoke-static {v14}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v14

    move-object/from16 v31, v12

    const-string v12, "4D"

    invoke-static {v12}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v12

    invoke-virtual {v13, v14, v12}, Ljava/lang/String;->replaceAll(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v12

    invoke-virtual {v12}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v12

    .line 52
    invoke-virtual {v12}, Ljava/lang/String;->isEmpty()Z

    move-result v13

    if-nez v13, :cond_4c4

    const-string v13, "09"

    invoke-static {v13}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v13

    .line 53
    invoke-virtual {v12, v13}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v13

    if-eqz v13, :cond_477

    const-string v13, "0F"

    invoke-static {v13}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v13

    invoke-virtual {v12, v13}, Ljava/lang/String;->endsWith(Ljava/lang/String;)Z

    move-result v13

    if-eqz v13, :cond_477

    .line 54
    new-instance v13, Lorg/json/JSONObject;

    invoke-direct {v13, v12}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    .line 55
    invoke-virtual {v13}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object v12

    iget-object v13, v1, Lcom/github/catvod/spider/XYQHiker;->ހ:Ljava/lang/String;

    invoke-virtual {v1, v10}, Lcom/github/catvod/spider/XYQHiker;->ހ(Ljava/lang/String;)Ljava/util/HashMap;

    move-result-object v14

    invoke-virtual {v1, v10, v12, v13, v14}, Lcom/github/catvod/spider/XYQHiker;->Ϳ(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/util/Map;)Ljava/lang/String;

    move-result-object v10

    move/from16 v28, v9

    move-object/from16 v35, v11

    move-object/from16 v34, v15

    goto/16 :goto_52d

    .line 56
    :cond_477
    new-instance v13, Ljava/util/LinkedHashMap;

    invoke-direct {v13}, Ljava/util/LinkedHashMap;-><init>()V

    move-object/from16 v14, v28

    .line 57
    invoke-virtual {v12, v14}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v12

    .line 58
    array-length v14, v12

    move/from16 v28, v9

    const/4 v9, 0x0

    :goto_486
    if-ge v9, v14, :cond_4b5

    move/from16 v32, v14

    aget-object v14, v12, v9

    move-object/from16 v33, v12

    const-string v12, "4F"

    invoke-static {v12}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v12

    .line 59
    invoke-virtual {v14, v12}, Ljava/lang/String;->indexOf(Ljava/lang/String;)I

    move-result v12

    move-object/from16 v35, v11

    move-object/from16 v34, v15

    const/4 v15, 0x0

    .line 60
    invoke-virtual {v14, v15, v12}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v11

    add-int/lit8 v12, v12, 0x1

    invoke-virtual {v14, v12}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v12

    invoke-virtual {v13, v11, v12}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    add-int/lit8 v9, v9, 0x1

    move/from16 v14, v32

    move-object/from16 v12, v33

    move-object/from16 v15, v34

    move-object/from16 v11, v35

    goto :goto_486

    :cond_4b5
    move-object/from16 v35, v11

    move-object/from16 v34, v15

    .line 61
    iget-object v9, v1, Lcom/github/catvod/spider/XYQHiker;->ހ:Ljava/lang/String;

    invoke-virtual {v1, v10}, Lcom/github/catvod/spider/XYQHiker;->ހ(Ljava/lang/String;)Ljava/util/HashMap;

    move-result-object v11

    invoke-virtual {v1, v10, v13, v9, v11}, Lcom/github/catvod/spider/XYQHiker;->ԭ(Ljava/lang/String;Ljava/util/Map;Ljava/lang/String;Ljava/util/Map;)Ljava/lang/String;

    move-result-object v10

    goto :goto_52d

    :cond_4c4
    move/from16 v28, v9

    move-object/from16 v35, v11

    move-object/from16 v34, v15

    const/4 v9, 0x0

    .line 62
    iget-object v11, v1, Lcom/github/catvod/spider/XYQHiker;->ހ:Ljava/lang/String;

    invoke-virtual {v1, v10}, Lcom/github/catvod/spider/XYQHiker;->ހ(Ljava/lang/String;)Ljava/util/HashMap;

    move-result-object v12

    invoke-virtual {v1, v10, v9, v11, v12}, Lcom/github/catvod/spider/XYQHiker;->ԭ(Ljava/lang/String;Ljava/util/Map;Ljava/lang/String;Ljava/util/Map;)Ljava/lang/String;

    move-result-object v10

    goto :goto_52d

    :cond_4d6
    move/from16 v28, v9

    move-object/from16 v35, v11

    move-object/from16 v31, v12

    move-object/from16 v34, v15

    .line 63
    iget-object v9, v1, Lcom/github/catvod/spider/XYQHiker;->ހ:Ljava/lang/String;

    invoke-virtual {v1, v8}, Lcom/github/catvod/spider/XYQHiker;->ހ(Ljava/lang/String;)Ljava/util/HashMap;

    move-result-object v10

    invoke-virtual {v1, v8, v9, v10}, Lcom/github/catvod/spider/XYQHiker;->Ԭ(Ljava/lang/String;Ljava/lang/String;Ljava/util/Map;)Ljava/lang/String;

    move-result-object v9

    const-string v10, "94E1D3B7EFCF96FAFE"

    invoke-static {v10}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    .line 64
    invoke-virtual {v9, v10}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v10

    if-eqz v10, :cond_50a

    const-string v10, "103624303C"

    invoke-static {v10}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v9, v10}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v10

    if-eqz v10, :cond_50a

    const-string v10, "012A3C26"

    invoke-static {v10}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    .line 65
    invoke-direct {v1, v8, v9, v10}, Lcom/github/catvod/spider/XYQHiker;->އ(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    :cond_50a
    move-object v10, v9

    const-string v9, "5D2A26303E2B1C250C"

    invoke-static {v9}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    .line 66
    invoke-virtual {v10, v9}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v9

    if-nez v9, :cond_523

    const-string v9, "5D30363F302D2D"

    invoke-static {v9}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v10, v9}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v9

    if-eqz v9, :cond_52d

    :cond_523
    const-string v9, "012A3C26"

    invoke-static {v9}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    .line 67
    invoke-direct {v1, v8, v10, v9}, Lcom/github/catvod/spider/XYQHiker;->ކ(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    .line 68
    :cond_52d
    :goto_52d
    invoke-static {v10}, Lcom/github/catvod/spider/XYQHiker;->ԩ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    .line 69
    invoke-static {v9}, Lcom/github/catvod/spider/xbpqxyq/xyq/ٱ;->Ϳ(Ljava/lang/String;)Lcom/github/catvod/spider/xbpqxyq/xyq/ǐ;

    move-result-object v9

    .line 70
    invoke-direct {v1, v0}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 71
    invoke-virtual {v0}, Ljava/lang/String;->isEmpty()Z

    move-result v10

    if-eqz v10, :cond_545

    if-ne v5, v3, :cond_545

    .line 72
    invoke-direct {v1, v2}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    :cond_545
    move-object/from16 v2, v23

    .line 73
    invoke-virtual {v0, v2}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v10
    :try_end_54b
    .catch Ljava/lang/Exception; {:try_start_3ba .. :try_end_54b} :catch_93e

    const-string v11, "22050C040808"

    invoke-static {v11}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v11

    if-eqz v10, :cond_55b

    .line 74
    :try_start_553
    invoke-static {v9, v0}, Lcom/github/catvod/spider/XYQHiker;->getTextByRule(Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0, v11, v8}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object v0

    .line 75
    :cond_55b
    invoke-virtual {v0, v11}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v10

    if-eqz v10, :cond_572

    .line 76
    invoke-virtual {v0, v11, v8}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object v0

    const-string v10, "55"

    invoke-static {v10}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10
    :try_end_56b
    .catch Ljava/lang/Exception; {:try_start_553 .. :try_end_56b} :catch_93e

    move-object/from16 v11, v25

    :try_start_56d
    invoke-virtual {v0, v10, v11}, Ljava/lang/String;->replaceAll(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    goto :goto_574

    :cond_572
    move-object/from16 v11, v25

    :goto_574
    move-object v10, v0

    move-object/from16 v15, v22

    .line 77
    invoke-direct {v1, v15}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 78
    invoke-virtual {v0}, Ljava/lang/String;->isEmpty()Z

    move-result v12

    if-eqz v12, :cond_587

    if-ne v5, v3, :cond_587

    .line 79
    invoke-direct {v1, v4}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 80
    :cond_587
    invoke-virtual {v0, v2}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v4

    if-eqz v4, :cond_591

    .line 81
    invoke-static {v9, v0}, Lcom/github/catvod/spider/XYQHiker;->getTextByRule(Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    :cond_591
    move-object v4, v0

    move-object/from16 v0, v21

    .line 82
    invoke-direct {v1, v0}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0, v2}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v0

    const/4 v12, 0x0

    .line 83
    aget-object v13, v0, v12

    invoke-static {v13, v9}, Lcom/github/catvod/spider/XYQHiker;->getTrueElement(Ljava/lang/String;Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;)Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;

    move-result-object v9

    const/4 v12, 0x1

    .line 84
    :goto_5a4
    array-length v13, v0

    const/4 v14, 0x1

    sub-int/2addr v13, v14

    if-ge v12, v13, :cond_5b2

    .line 85
    aget-object v13, v0, v12

    invoke-static {v13, v9}, Lcom/github/catvod/spider/XYQHiker;->getTrueElement(Ljava/lang/String;Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;)Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;

    move-result-object v9

    add-int/lit8 v12, v12, 0x1

    goto :goto_5a4

    .line 86
    :cond_5b2
    array-length v12, v0

    const/4 v13, 0x1

    sub-int/2addr v12, v13

    aget-object v0, v0, v12

    invoke-static {v9, v0}, Lcom/github/catvod/spider/XYQHiker;->selectElements(Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;Ljava/lang/String;)Lcom/github/catvod/spider/xbpqxyq/xyq/ำ;

    move-result-object v9

    move-object v0, v11

    move-object v13, v0

    const/4 v12, 0x0

    .line 87
    :goto_5be
    invoke-virtual {v9}, Ljava/util/ArrayList;->size()I

    move-result v14
    :try_end_5c2
    .catch Ljava/lang/Exception; {:try_start_56d .. :try_end_5c2} :catch_93c

    if-ge v12, v14, :cond_92e

    .line 88
    :try_start_5c4
    invoke-virtual {v9, v12}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v14

    check-cast v14, Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;

    .line 89
    invoke-direct {v1, v6}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v15

    .line 90
    invoke-virtual {v15, v2}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v21

    if-eqz v21, :cond_5ff

    .line 91
    invoke-virtual {v15, v2}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v15

    move-object/from16 v21, v0

    const/16 v19, 0x0

    .line 92
    aget-object v0, v15, v19

    invoke-static {v0, v14}, Lcom/github/catvod/spider/XYQHiker;->getTrueElement(Ljava/lang/String;Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;)Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;

    move-result-object v0

    move-object/from16 v22, v6

    const/4 v14, 0x1

    .line 93
    :goto_5e5
    array-length v6, v15

    const/16 v23, 0x1

    add-int/lit8 v6, v6, -0x1

    if-ge v14, v6, :cond_5f5

    .line 94
    aget-object v6, v15, v14

    invoke-static {v6, v0}, Lcom/github/catvod/spider/XYQHiker;->getTrueElement(Ljava/lang/String;Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;)Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;

    move-result-object v0

    add-int/lit8 v14, v14, 0x1

    goto :goto_5e5

    .line 95
    :cond_5f5
    array-length v6, v15

    const/4 v14, 0x1

    sub-int/2addr v6, v14

    aget-object v6, v15, v6

    invoke-static {v0, v6}, Lcom/github/catvod/spider/XYQHiker;->selectElements(Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;Ljava/lang/String;)Lcom/github/catvod/spider/xbpqxyq/xyq/ำ;

    move-result-object v0

    goto :goto_607

    :cond_5ff
    move-object/from16 v21, v0

    move-object/from16 v22, v6

    .line 96
    invoke-static {v14, v15}, Lcom/github/catvod/spider/XYQHiker;->selectElements(Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;Ljava/lang/String;)Lcom/github/catvod/spider/xbpqxyq/xyq/ำ;

    move-result-object v0

    :goto_607
    move-object v6, v0

    move-object v14, v13

    const/4 v13, 0x0

    .line 97
    :goto_60a
    invoke-virtual {v6}, Ljava/util/ArrayList;->size()I

    move-result v0

    if-ge v13, v0, :cond_8d5

    .line 98
    invoke-virtual {v6, v13}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    move-object v15, v0

    check-cast v15, Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;

    move-object/from16 v23, v6

    move-object/from16 v6, v20

    .line 99
    invoke-direct {v1, v6}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 100
    invoke-virtual {v0}, Ljava/lang/String;->isEmpty()Z

    move-result v20

    if-eqz v20, :cond_62b

    if-ne v5, v3, :cond_62b

    .line 101
    invoke-direct {v1, v7}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    :cond_62b
    if-eqz v5, :cond_63b

    .line 102
    invoke-static {v15, v0}, Lcom/github/catvod/spider/XYQHiker;->getTextByRule(Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    move-object/from16 v20, v6

    move-object/from16 v32, v7

    move-object/from16 v33, v9

    move-object/from16 v7, v18

    move-object v6, v0

    goto :goto_665

    :cond_63b
    move-object/from16 v20, v6

    .line 103
    invoke-virtual {v15}, Lcom/github/catvod/spider/xbpqxyq/xyq/ւ;->ދ()Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v0, v2}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v25

    move-object/from16 v32, v7

    move-object/from16 v33, v9

    const/4 v7, 0x0

    aget-object v9, v25, v7

    invoke-virtual {v0, v2}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v0

    const/16 v19, 0x1

    aget-object v0, v0, v19

    invoke-static {v6, v9, v0}, Lcom/github/catvod/spider/xbpqxyq/xyq/ވ;->އ(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/util/ArrayList;

    move-result-object v0

    invoke-virtual {v0, v7}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    invoke-virtual {v1, v0}, Lcom/github/catvod/spider/XYQHiker;->މ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    move-object v6, v0

    move-object/from16 v7, v18

    .line 104
    :goto_665
    invoke-direct {v1, v7}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 105
    invoke-virtual {v0}, Ljava/lang/String;->isEmpty()Z

    move-result v9

    if-eqz v9, :cond_678

    if-ne v5, v3, :cond_678

    move-object/from16 v9, v35

    .line 106
    invoke-direct {v1, v9}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    goto :goto_67a

    :cond_678
    move-object/from16 v9, v35

    .line 107
    :goto_67a
    invoke-virtual {v0}, Ljava/lang/String;->isEmpty()Z

    move-result v18
    :try_end_67e
    .catch Ljava/lang/Exception; {:try_start_5c4 .. :try_end_67e} :catch_907

    if-nez v18, :cond_74d

    move-object/from16 v18, v7

    :try_start_682
    const-string v7, "1A362721"

    invoke-static {v7}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    .line 108
    invoke-virtual {v0, v7}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v7

    if-eqz v7, :cond_697

    move-object v7, v0

    move-object/from16 v35, v9

    move-object/from16 v36, v14

    move-object/from16 v14, v34

    goto/16 :goto_724

    :cond_697
    if-eqz v5, :cond_6a7

    .line 109
    invoke-static {v15, v0}, Lcom/github/catvod/spider/XYQHiker;->getTextByRule(Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v0

    move-object v7, v0

    move-object/from16 v35, v9

    move-object/from16 v36, v14

    goto :goto_6c9

    .line 110
    :cond_6a7
    invoke-virtual {v15}, Lcom/github/catvod/spider/xbpqxyq/xyq/ւ;->ދ()Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v0, v2}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v25
    :try_end_6af
    .catch Ljava/lang/Exception; {:try_start_682 .. :try_end_6af} :catch_740

    move-object/from16 v35, v9

    move-object/from16 v36, v14

    const/4 v9, 0x0

    :try_start_6b4
    aget-object v14, v25, v9

    invoke-virtual {v0, v2}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v0

    const/16 v19, 0x1

    aget-object v0, v0, v19

    invoke-static {v7, v14, v0}, Lcom/github/catvod/spider/xbpqxyq/xyq/ވ;->އ(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/util/ArrayList;

    move-result-object v0

    invoke-virtual {v0, v9}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;
    :try_end_6c8
    .catch Ljava/lang/Exception; {:try_start_6b4 .. :try_end_6c8} :catch_73e

    move-object v7, v0

    :goto_6c9
    :try_start_6c9
    const-string v0, "07303F79"

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 111
    invoke-virtual {v7, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0
    :try_end_6d3
    .catch Ljava/lang/Exception; {:try_start_6c9 .. :try_end_6d3} :catch_738

    if-eqz v0, :cond_71d

    :try_start_6d5
    const-string v0, "2E642224353049"

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 112
    invoke-virtual {v7, v0, v11}, Ljava/lang/String;->replaceAll(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const-string v9, "07303F0D72"

    invoke-static {v9}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v0, v9}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v0

    .line 113
    array-length v9, v0

    const/4 v14, 0x1

    if-le v9, v14, :cond_71d

    aget-object v9, v0, v14
    :try_end_6ef
    .catch Ljava/lang/Exception; {:try_start_6d5 .. :try_end_6ef} :catch_715

    move-object/from16 v14, v34

    :try_start_6f1
    invoke-virtual {v9, v14}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v9

    if-eqz v9, :cond_71f

    const/4 v9, 0x1

    .line 114
    aget-object v0, v0, v9

    const-string v9, "2E6B"

    invoke-static {v9}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v0, v9}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v0

    const/4 v9, 0x0

    aget-object v0, v0, v9

    const-string v9, "2965710C"

    invoke-static {v9}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v0, v9, v11}, Ljava/lang/String;->replaceAll(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0
    :try_end_711
    .catch Ljava/lang/Exception; {:try_start_6f1 .. :try_end_711} :catch_713

    move-object v7, v0

    goto :goto_71f

    :catch_713
    move-exception v0

    goto :goto_718

    :catch_715
    move-exception v0

    move-object/from16 v14, v34

    :goto_718
    move-object/from16 v21, v7

    move/from16 v9, v28

    goto :goto_749

    :cond_71d
    move-object/from16 v14, v34

    .line 115
    :cond_71f
    :goto_71f
    :try_start_71f
    invoke-static {v8, v7}, Lcom/github/catvod/spider/xbpqxyq/xyq/ވ;->Ԫ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0
    :try_end_723
    .catch Ljava/lang/Exception; {:try_start_71f .. :try_end_723} :catch_734

    move-object v7, v0

    :goto_724
    if-eqz v28, :cond_731

    move/from16 v9, v28

    .line 116
    :try_start_728
    invoke-virtual {v1, v7, v8, v9}, Lcom/github/catvod/spider/XYQHiker;->ԯ(Ljava/lang/String;Ljava/lang/String;Z)Ljava/lang/String;

    move-result-object v7
    :try_end_72c
    .catch Ljava/lang/Exception; {:try_start_728 .. :try_end_72c} :catch_72d

    goto :goto_759

    :catch_72d
    move-exception v0

    :goto_72e
    move-object/from16 v21, v7

    goto :goto_749

    :cond_731
    move/from16 v9, v28

    goto :goto_759

    :catch_734
    move-exception v0

    move/from16 v9, v28

    goto :goto_72e

    :catch_738
    move-exception v0

    move/from16 v9, v28

    move-object/from16 v14, v34

    goto :goto_72e

    :catch_73e
    move-exception v0

    goto :goto_745

    :catch_740
    move-exception v0

    move-object/from16 v35, v9

    move-object/from16 v36, v14

    :goto_745
    move/from16 v9, v28

    move-object/from16 v14, v34

    .line 117
    :goto_749
    :try_start_749
    invoke-static {v0}, Lcom/github/catvod/crawler/SpiderDebug;->log(Ljava/lang/Throwable;)V

    goto :goto_757

    :cond_74d
    move-object/from16 v18, v7

    move-object/from16 v35, v9

    move-object/from16 v36, v14

    move/from16 v9, v28

    move-object/from16 v14, v34

    :goto_757
    move-object/from16 v7, v21

    :goto_759
    move-object/from16 v37, v17

    move-object/from16 v17, v8

    move-object/from16 v8, v37

    .line 118
    invoke-direct {v1, v8}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 119
    invoke-virtual {v0}, Ljava/lang/String;->isEmpty()Z

    move-result v21

    if-eqz v21, :cond_774

    if-ne v5, v3, :cond_774

    move-object/from16 v25, v8

    move-object/from16 v8, v31

    .line 120
    invoke-direct {v1, v8}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    goto :goto_778

    :cond_774
    move-object/from16 v25, v8

    move-object/from16 v8, v31

    .line 121
    :goto_778
    invoke-virtual {v0}, Ljava/lang/String;->isEmpty()Z

    move-result v21
    :try_end_77c
    .catch Ljava/lang/Exception; {:try_start_749 .. :try_end_77c} :catch_907

    if-nez v21, :cond_7c5

    if-eqz v5, :cond_78f

    .line 122
    :try_start_780
    invoke-static {v15, v0}, Lcom/github/catvod/spider/XYQHiker;->getTextByRule(Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0
    :try_end_784
    .catch Ljava/lang/Exception; {:try_start_780 .. :try_end_784} :catch_78b

    move-object/from16 v31, v8

    move/from16 v28, v9

    move-object/from16 v34, v14

    goto :goto_7b6

    :catch_78b
    move-exception v0

    move-object/from16 v31, v8

    goto :goto_7bd

    :cond_78f
    move-object/from16 v31, v8

    .line 123
    :try_start_791
    invoke-virtual {v15}, Lcom/github/catvod/spider/xbpqxyq/xyq/ւ;->ދ()Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v0, v2}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v21
    :try_end_799
    .catch Ljava/lang/Exception; {:try_start_791 .. :try_end_799} :catch_7bc

    move/from16 v28, v9

    move-object/from16 v34, v14

    const/4 v9, 0x0

    :try_start_79e
    aget-object v14, v21, v9

    invoke-virtual {v0, v2}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v0

    const/16 v19, 0x1

    aget-object v0, v0, v19

    invoke-static {v8, v14, v0}, Lcom/github/catvod/spider/xbpqxyq/xyq/ވ;->އ(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/util/ArrayList;

    move-result-object v0

    invoke-virtual {v0, v9}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    invoke-virtual {v1, v0}, Lcom/github/catvod/spider/XYQHiker;->މ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0
    :try_end_7b6
    .catch Ljava/lang/Exception; {:try_start_79e .. :try_end_7b6} :catch_7ba

    :goto_7b6
    move-object v14, v0

    move-object/from16 v8, v16

    goto :goto_7cf

    :catch_7ba
    move-exception v0

    goto :goto_7c1

    :catch_7bc
    move-exception v0

    :goto_7bd
    move/from16 v28, v9

    move-object/from16 v34, v14

    .line 124
    :goto_7c1
    :try_start_7c1
    invoke-static {v0}, Lcom/github/catvod/crawler/SpiderDebug;->log(Ljava/lang/Throwable;)V

    goto :goto_7cb

    :cond_7c5
    move-object/from16 v31, v8

    move/from16 v28, v9

    move-object/from16 v34, v14

    :goto_7cb
    move-object/from16 v8, v16

    move-object/from16 v14, v36

    .line 125
    :goto_7cf
    invoke-direct {v1, v8}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 126
    invoke-virtual {v0}, Ljava/lang/String;->isEmpty()Z

    move-result v9

    if-eqz v9, :cond_7e2

    if-ne v5, v3, :cond_7e2

    move-object/from16 v9, v30

    .line 127
    invoke-direct {v1, v9}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0
    :try_end_7e1
    .catch Ljava/lang/Exception; {:try_start_7c1 .. :try_end_7e1} :catch_907

    goto :goto_7e4

    :cond_7e2
    move-object/from16 v9, v30

    :goto_7e4
    move/from16 v16, v3

    const-string v3, "2E19B5CAE5A2FFE069"

    invoke-static {v3}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    if-eqz v5, :cond_802

    .line 128
    :try_start_7ee
    invoke-virtual {v0, v3}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v3

    const/16 v19, 0x0

    aget-object v3, v3, v19

    invoke-static {v15, v3}, Lcom/github/catvod/spider/XYQHiker;->getTextByRule(Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    move/from16 v30, v5

    move-object/from16 v19, v8

    const/4 v5, 0x0

    const/16 v24, 0x1

    goto :goto_82f

    .line 129
    :cond_802
    invoke-virtual {v15}, Lcom/github/catvod/spider/xbpqxyq/xyq/ւ;->ދ()Ljava/lang/String;

    move-result-object v15

    invoke-virtual {v0, v3}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v21

    move/from16 v30, v5

    move-object/from16 v19, v8

    const/4 v5, 0x0

    aget-object v8, v21, v5

    invoke-virtual {v8, v2}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v8

    aget-object v8, v8, v5

    invoke-virtual {v0, v3}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v3

    aget-object v3, v3, v5

    invoke-virtual {v3, v2}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v3

    const/16 v24, 0x1

    aget-object v3, v3, v24

    invoke-static {v15, v8, v3}, Lcom/github/catvod/spider/xbpqxyq/xyq/ވ;->އ(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/util/ArrayList;

    move-result-object v3

    invoke-virtual {v3, v5}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/lang/String;

    :goto_82f
    const-string v8, "29A4C8EEBCC9D0"

    invoke-static {v8}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    .line 130
    invoke-virtual {v0, v8}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v8

    if-eqz v8, :cond_83f

    .line 131
    invoke-static {v3, v0}, Lcom/github/catvod/spider/xbpqxyq/xyq/ވ;->ރ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    .line 132
    :cond_83f
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v0, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const-string v8, "552B3D212F3055"

    invoke-static {v8}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    .line 133
    invoke-virtual {v0, v8}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v8

    if-eqz v8, :cond_867

    const-string v8, "552B3D212F3055"

    invoke-static {v8}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    .line 134
    invoke-virtual {v0, v8, v3}, Ljava/lang/String;->replaceAll(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 135
    :cond_867
    new-instance v3, Lorg/json/JSONObject;

    invoke-direct {v3}, Lorg/json/JSONObject;-><init>()V

    const-string v8, "042D370E3320"

    invoke-static {v8}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    .line 136
    new-instance v15, Ljava/lang/StringBuilder;

    invoke-direct {v15}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v15, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v5, "566677"

    invoke-static {v5}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v15, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v15, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v5, "566677"

    invoke-static {v5}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v15, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v15, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v15}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v3, v8, v0}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const-string v0, "042D370E34251F27"

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 137
    invoke-virtual {v3, v0, v6}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const-string v0, "042D370E2A2D11"

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 138
    invoke-virtual {v3, v0, v7}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const-string v0, "042D370E28211F23213A29"

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 139
    invoke-virtual {v3, v0, v14}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    :try_end_8b4
    .catch Ljava/lang/Exception; {:try_start_7ee .. :try_end_8b4} :catch_907

    move-object/from16 v5, v29

    .line 140
    :try_start_8b6
    invoke-virtual {v5, v3}, Lorg/json/JSONArray;->put(Ljava/lang/Object;)Lorg/json/JSONArray;
    :try_end_8b9
    .catch Ljava/lang/Exception; {:try_start_8b6 .. :try_end_8b9} :catch_8d3

    add-int/lit8 v13, v13, 0x1

    move-object/from16 v29, v5

    move-object/from16 v21, v7

    move/from16 v3, v16

    move-object/from16 v8, v17

    move-object/from16 v16, v19

    move-object/from16 v6, v23

    move-object/from16 v17, v25

    move/from16 v5, v30

    move-object/from16 v7, v32

    move-object/from16 v30, v9

    move-object/from16 v9, v33

    goto/16 :goto_60a

    :catch_8d3
    move-exception v0

    goto :goto_90a

    :cond_8d5
    move-object/from16 v32, v7

    move-object/from16 v33, v9

    move-object/from16 v36, v14

    move-object/from16 v19, v16

    move-object/from16 v25, v17

    move-object/from16 v9, v30

    const/16 v24, 0x1

    move/from16 v16, v3

    move/from16 v30, v5

    move-object/from16 v17, v8

    move-object/from16 v5, v29

    add-int/lit8 v12, v12, 0x1

    move-object/from16 v29, v5

    move/from16 v3, v16

    move-object/from16 v8, v17

    move-object/from16 v16, v19

    move-object/from16 v0, v21

    move-object/from16 v6, v22

    move-object/from16 v17, v25

    move/from16 v5, v30

    move-object/from16 v7, v32

    move-object/from16 v13, v36

    move-object/from16 v30, v9

    move-object/from16 v9, v33

    goto/16 :goto_5be

    :catch_907
    move-exception v0

    move-object/from16 v5, v29

    .line 141
    :goto_90a
    :try_start_90a
    invoke-static {v0}, Lcom/github/catvod/crawler/SpiderDebug;->log(Ljava/lang/Throwable;)V

    .line 142
    iget-boolean v2, v1, Lcom/github/catvod/spider/XYQHiker;->ވ:Z

    if-eqz v2, :cond_930

    .line 143
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "96FAE8B8FBF197CCD5B8DBC997CAC4B9FBEC97C5E9B8CEDD9DFEC9"

    invoke-static {v3}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/Exception;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lcom/github/catvod/spider/Init;->show(Ljava/lang/String;)V

    goto :goto_930

    :cond_92e
    move-object/from16 v5, v29

    :cond_930
    :goto_930
    move-object/from16 v2, v26

    move-object/from16 v3, v27

    .line 144
    invoke-virtual {v2, v3, v5}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 145
    :goto_937
    invoke-virtual {v2}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object v0
    :try_end_93b
    .catch Ljava/lang/Exception; {:try_start_90a .. :try_end_93b} :catch_93c

    return-object v0

    :catch_93c
    move-exception v0

    goto :goto_944

    :catch_93e
    move-exception v0

    move-object/from16 v11, v25

    goto :goto_944

    :catch_942
    move-exception v0

    move-object v11, v12

    .line 146
    :goto_944
    invoke-static {v0}, Lcom/github/catvod/crawler/SpiderDebug;->log(Ljava/lang/Throwable;)V

    .line 147
    iget-boolean v2, v1, Lcom/github/catvod/spider/XYQHiker;->ވ:Z

    if-eqz v2, :cond_967

    .line 148
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "96FAE8B8FBF197C7FBB4EBC497C5E9B8CEDD9DFEC9"

    invoke-static {v3}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/Exception;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lcom/github/catvod/spider/Init;->show(Ljava/lang/String;)V

    :cond_967
    return-object v11
.end method

.method public init(Landroid/content/Context;Ljava/lang/String;)V
    .registers 7

    .line 1
    invoke-super {p0, p1, p2}, Lcom/github/catvod/crawler/Spider;->init(Landroid/content/Context;Ljava/lang/String;)V

    .line 2
    iput-object p2, p0, Lcom/github/catvod/spider/XYQHiker;->ޅ:Ljava/lang/String;

    .line 3
    new-instance p2, Lcom/github/catvod/spider/XYQPushAgent;

    invoke-direct {p2}, Lcom/github/catvod/spider/XYQPushAgent;-><init>()V

    iput-object p2, p0, Lcom/github/catvod/spider/XYQHiker;->֏:Lcom/github/catvod/spider/XYQPushAgent;

    .line 4
    new-instance p2, Ljava/lang/StringBuilder;

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-static {}, Lcom/github/catvod/spider/Init;->context()Landroid/app/Application;

    move-result-object v0

    invoke-virtual {v0}, Landroid/app/Application;->getPackageName()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v0, "2D3221343C2100273D323F37"

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    const/4 v0, 0x0

    invoke-virtual {p1, p2, v0}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object p2

    sput-object p2, Lcom/github/catvod/spider/XYQHiker;->Ϳ:Landroid/content/SharedPreferences;

    const-string v0, "2237313D3327202735233F371A163C3A3F2A"

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const-string v1, ""

    .line 5
    invoke-interface {p2, v0, v1}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p2

    .line 6
    invoke-virtual {p2}, Ljava/lang/String;->isEmpty()Z

    move-result v0

    if-eqz v0, :cond_74

    .line 7
    :try_start_42
    invoke-static {}, Lcom/github/catvod/spider/XYQProxy;->localProxyUrl()Ljava/lang/String;

    move-result-object v0

    const-string v2, "5D32213E223D"

    invoke-static {v2}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    const-string v3, "5D243A3D3F6B2A1B02050C061D3A7C30362D062D3834346A063A27"

    invoke-static {v3}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v0, v2, v3}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x0

    .line 8
    invoke-static {v0, v2}, Lcom/github/catvod/spider/xbpqxyq/xyq/ތ;->֏(Ljava/lang/String;Ljava/util/Map;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v0

    .line 9
    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v2

    const/16 v3, 0x20

    if-ne v2, v3, :cond_74

    invoke-virtual {v0}, Ljava/lang/String;->isEmpty()Z

    move-result v1
    :try_end_6b
    .catch Ljava/lang/Exception; {:try_start_42 .. :try_end_6b} :catch_6f

    if-nez v1, :cond_74

    move-object v1, v0

    goto :goto_75

    :catch_6f
    move-exception p2

    .line 10
    invoke-static {p2}, Lcom/github/catvod/crawler/SpiderDebug;->log(Ljava/lang/Throwable;)V

    goto :goto_75

    :cond_74
    move-object v1, p2

    .line 11
    :goto_75
    iget-object p2, p0, Lcom/github/catvod/spider/XYQHiker;->֏:Lcom/github/catvod/spider/XYQPushAgent;

    invoke-virtual {p2, p1, v1}, Lcom/github/catvod/spider/XYQPushAgent;->init(Landroid/content/Context;Ljava/lang/String;)V

    return-void
.end method

.method public isVideoFormat(Ljava/lang/String;)Z
    .registers 8

    .line 1
    invoke-virtual {p0}, Lcom/github/catvod/spider/XYQHiker;->Ԯ()V

    const-string v0, "94CBD8B4D0EC97D5D6B7D4E69AE5D5B8F8D59BD1EDB7D4E197C7E0B8CEEA9AEDDE"

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 2
    invoke-direct {p0, v0}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/String;->isEmpty()Z

    move-result v1

    if-nez v1, :cond_14

    goto :goto_1a

    :cond_14
    const-string v0, "242B373435021D303E302E"

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    :goto_1a
    const-string v1, "94CBD8B4D0EC97D5D6B7D4E69AE5D5B8F8D59BD1EDB7D4E19AFDD4B7E1E09AEDDE"

    invoke-static {v1}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    .line 3
    invoke-direct {p0, v1}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/String;->isEmpty()Z

    move-result v2

    if-nez v2, :cond_2b

    goto :goto_31

    :cond_2b
    const-string v1, "242B373435021B2E273428"

    invoke-static {v1}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    :goto_31
    const-string v2, "5C2F602462675C2F2365796A142E25722C2D16273C7E2E2B01617D3C2A77516C3E653B"

    invoke-static {v2}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    .line 4
    invoke-direct {p0, v0, v2}, Lcom/github/catvod/spider/XYQHiker;->ރ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object v0

    const-string v2, "51"

    invoke-static {v2}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v0

    const-string v3, "4F2A27252A675C2A273C36"

    invoke-static {v3}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    .line 5
    invoke-direct {p0, v1, v3}, Lcom/github/catvod/spider/XYQHiker;->ރ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1, v2}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v1

    .line 6
    invoke-virtual {p1}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object p1

    const-string v2, "4F2A27252A"

    invoke-static {v2}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    .line 7
    invoke-virtual {p1, v2}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v2

    const/4 v3, 0x0

    if-nez v2, :cond_78

    const-string v2, "5C2A273C36"

    invoke-static {v2}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {p1, v2}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v2

    if-eqz v2, :cond_7f

    :cond_78
    invoke-static {p1}, Lcom/github/catvod/spider/XYQHiker;->checkstring(Ljava/lang/String;)Z

    move-result v2

    if-nez v2, :cond_7f

    return v3

    .line 8
    :cond_7f
    array-length v2, v0

    const/4 v4, 0x0

    :goto_81
    if-ge v4, v2, :cond_a6

    aget-object v5, v0, v4

    .line 9
    invoke-virtual {p1, v5}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v5

    if-eqz v5, :cond_a3

    .line 10
    array-length v0, v1

    const/4 v2, 0x0

    :goto_8d
    if-ge v2, v0, :cond_a1

    aget-object v4, v1, v2

    .line 11
    invoke-virtual {p1, v4}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v4

    if-eqz v4, :cond_9e

    invoke-static {p1}, Lcom/github/catvod/spider/XYQHiker;->checkstring(Ljava/lang/String;)Z

    move-result v4

    if-nez v4, :cond_9e

    return v3

    :cond_9e
    add-int/lit8 v2, v2, 0x1

    goto :goto_8d

    :cond_a1
    const/4 p1, 0x1

    return p1

    :cond_a3
    add-int/lit8 v4, v4, 0x1

    goto :goto_81

    :cond_a6
    return v3
.end method

.method public manualVideoCheck()Z
    .registers 4

    .line 1
    invoke-virtual {p0}, Lcom/github/catvod/spider/XYQHiker;->Ԯ()V

    const-string v0, "94DAFCB4CAE297FED3B4CAEB94CBD8B4D0EC97D5D6B7D4E6"

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 2
    invoke-direct {p0, v0}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/String;->isEmpty()Z

    move-result v1

    if-nez v1, :cond_14

    goto :goto_1a

    :cond_14
    const-string v0, "3F233D243B28212C3A373C2100"

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 3
    :goto_1a
    invoke-direct {p0, v0}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const-string v2, "43"

    invoke-static {v2}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_3d

    invoke-direct {p0, v0}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const-string v1, "94DAFC"

    invoke-static {v1}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_3b

    goto :goto_3d

    :cond_3b
    const/4 v0, 0x0

    return v0

    :cond_3d
    :goto_3d
    const/4 v0, 0x1

    return v0
.end method

.method public playerContent(Ljava/lang/String;Ljava/lang/String;Ljava/util/List;)Ljava/lang/String;
    .registers 36
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;)",
            "Ljava/lang/String;"
        }
    .end annotation

    move-object/from16 v1, p0

    move-object/from16 v2, p1

    move-object/from16 v3, p2

    const-string v4, "9AEDE4B7EBC697E6E7B4D5C694D7E3"

    invoke-static {v4}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    const-string v5, "97CAD5B7C4D43F23300136250B2721"

    invoke-static {v5}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    const-string v6, "95FFC2B8FBF195FEC5B6FAC594E2EFB4E6CB"

    invoke-static {v6}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    const-string v7, "43"

    invoke-static {v7}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    const-string v8, ""

    :try_start_20
    const-string v9, "332E3AB9E7E895E2D2"

    invoke-static {v9}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    .line 1
    invoke-virtual {v2, v9}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v9

    if-nez v9, :cond_cd9

    const-string v9, "3D32363FBFCAEDA5C7EA"

    invoke-static {v9}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v2, v9}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v9

    if-nez v9, :cond_cd9

    const-string v9, "3D32363FB2F9DEA5F3D0"

    invoke-static {v9}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v2, v9}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v9

    if-eqz v9, :cond_46

    goto/16 :goto_cd9

    .line 2
    :cond_46
    invoke-virtual/range {p0 .. p0}, Lcom/github/catvod/spider/XYQHiker;->Ԯ()V

    .line 3
    invoke-direct {v1, v6}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/String;->isEmpty()Z

    move-result v2

    if-nez v2, :cond_54

    goto :goto_5a

    :cond_54
    const-string v6, "312D373834232D243C23372506"

    invoke-static {v6}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    .line 4
    :goto_5a
    invoke-direct {v1, v5}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/String;->isEmpty()Z

    move-result v2

    if-nez v2, :cond_65

    goto :goto_6b

    :cond_65
    const-string v5, "332C323D05091321033D3B3D1730"

    invoke-static {v5}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    :goto_6b
    const-string v2, "2716157C62"

    invoke-static {v2}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    .line 5
    invoke-direct {v1, v6, v2}, Lcom/github/catvod/spider/XYQHiker;->ރ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    iput-object v2, v1, Lcom/github/catvod/spider/XYQHiker;->ހ:Ljava/lang/String;

    .line 6
    new-instance v2, Lorg/json/JSONObject;

    invoke-direct {v2}, Lorg/json/JSONObject;-><init>()V

    .line 7
    invoke-direct {v1, v4}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/String;->isEmpty()Z

    move-result v6

    if-nez v6, :cond_87

    goto :goto_8d

    :cond_87
    const-string v4, "3A2732353F3601"

    invoke-static {v4}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    .line 8
    :goto_8d
    invoke-direct {v1, v4, v8}, Lcom/github/catvod/spider/XYQHiker;->ރ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v4

    const-string v6, "56"

    invoke-static {v6}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    .line 9
    invoke-virtual {v4, v6}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v6
    :try_end_9f
    .catch Ljava/lang/Exception; {:try_start_20 .. :try_end_9f} :catch_ce6

    const-string v9, "95D6E6B9DED5"

    invoke-static {v9}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    const-string v10, "22010C041B"

    invoke-static {v10}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    const-string v11, "51"

    invoke-static {v11}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v11

    const-string v12, "40"

    invoke-static {v12}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v12

    if-eqz v6, :cond_1e5

    .line 10
    :try_start_b9
    invoke-virtual {v4, v11}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v6

    const/4 v15, 0x0

    .line 11
    :goto_be
    array-length v13, v6
    :try_end_bf
    .catch Ljava/lang/Exception; {:try_start_b9 .. :try_end_bf} :catch_1e0

    const-string v14, "00273534282100"

    invoke-static {v14}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v14

    if-ge v15, v13, :cond_18b

    .line 12
    :try_start_c7
    aget-object v13, v6, v15

    move-object/from16 v16, v6

    const-string v6, "2E66"

    invoke-static {v6}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v13, v6}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v6

    move-object/from16 v17, v11

    const/4 v13, 0x0

    .line 13
    aget-object v11, v6, v13

    const/4 v13, 0x1

    .line 14
    aget-object v6, v6, v13

    .line 15
    invoke-virtual {v6, v10}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v13

    if-nez v13, :cond_13d

    invoke-virtual {v6, v9}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v13

    if-eqz v13, :cond_ea

    goto :goto_13d

    :cond_ea
    const-string v13, "3F0D111816012D1712"

    invoke-static {v13}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v13

    .line 16
    invoke-virtual {v6, v13}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v13

    if-nez v13, :cond_13a

    const-string v13, "94CBD8B7C6FE"

    invoke-static {v13}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v13

    invoke-virtual {v6, v13}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v13

    if-eqz v13, :cond_103

    goto :goto_13a

    :cond_103
    const-string v13, "3B0D000E0F05"

    invoke-static {v13}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v13

    .line 17
    invoke-virtual {v6, v13}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v13

    if-nez v13, :cond_137

    const-string v13, "9AC9EAB7C4D894CBD8B7C6FE"

    invoke-static {v13}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v13

    invoke-virtual {v6, v13}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v13

    if-eqz v13, :cond_11c

    goto :goto_137

    :cond_11c
    const-string v13, "3F03100E0F05"

    invoke-static {v13}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v13

    .line 18
    invoke-virtual {v6, v13}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v13

    if-nez v13, :cond_134

    const-string v13, "9AC9EAB7C4D895D6E6B9DED5"

    invoke-static {v13}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v13

    invoke-virtual {v6, v13}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v13

    if-eqz v13, :cond_13f

    .line 19
    :cond_134
    sget-object v6, Lcom/github/catvod/spider/XYQHiker;->ԭ:Ljava/lang/String;

    goto :goto_13f

    .line 20
    :cond_137
    :goto_137
    sget-object v6, Lcom/github/catvod/spider/XYQHiker;->Ԭ:Ljava/lang/String;

    goto :goto_13f

    .line 21
    :cond_13a
    :goto_13a
    sget-object v6, Lcom/github/catvod/spider/XYQHiker;->ԫ:Ljava/lang/String;

    goto :goto_13f

    .line 22
    :cond_13d
    :goto_13d
    sget-object v6, Lcom/github/catvod/spider/XYQHiker;->Ԫ:Ljava/lang/String;

    .line 23
    :cond_13f
    :goto_13f
    invoke-virtual {v11, v14}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v13

    if-eqz v13, :cond_152

    const-string v13, "25273107332105"

    invoke-static {v13}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v13

    invoke-virtual {v6, v13}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v13

    if-eqz v13, :cond_152

    move-object v6, v3

    .line 24
    :cond_152
    iget-object v13, v1, Lcom/github/catvod/spider/XYQHiker;->ؠ:Ljava/lang/String;

    invoke-virtual {v13}, Ljava/lang/String;->isEmpty()Z

    move-result v13

    if-nez v13, :cond_180

    const-string v13, "112D3C3A3321"

    invoke-static {v13}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v13

    .line 25
    invoke-virtual {v11, v13}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v13

    if-eqz v13, :cond_180

    .line 26
    new-instance v13, Ljava/lang/StringBuilder;

    invoke-direct {v13}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v13, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v6, "49"

    invoke-static {v6}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v13, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v6, v1, Lcom/github/catvod/spider/XYQHiker;->ؠ:Ljava/lang/String;

    invoke-virtual {v13, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v13}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    .line 27
    :cond_180
    invoke-virtual {v2, v11, v6}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    add-int/lit8 v15, v15, 0x1

    move-object/from16 v6, v16

    move-object/from16 v11, v17

    goto/16 :goto_be

    :cond_18b
    move-object/from16 v17, v11

    .line 28
    invoke-virtual {v4}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v6, v14}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v6

    if-nez v6, :cond_1aa

    invoke-direct {v1, v5}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v6, v12}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_1aa

    const-string v6, "20273534282100"

    invoke-static {v6}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    .line 29
    invoke-virtual {v2, v6, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 30
    :cond_1aa
    iget-object v6, v1, Lcom/github/catvod/spider/XYQHiker;->ؠ:Ljava/lang/String;

    invoke-virtual {v6}, Ljava/lang/String;->isEmpty()Z

    move-result v6

    if-nez v6, :cond_28e

    .line 31
    iget-object v6, v1, Lcom/github/catvod/spider/XYQHiker;->ؠ:Ljava/lang/String;

    invoke-virtual {v6}, Ljava/lang/String;->length()I

    move-result v6

    const/4 v9, 0x1

    if-le v6, v9, :cond_28e

    const-string v6, "312D3C3A332156"

    invoke-static {v6}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v4, v6}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v6

    if-nez v6, :cond_28e

    const-string v6, "112D3C3A332156"

    invoke-static {v6}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v4, v6}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v4

    if-nez v4, :cond_28e

    const-string v4, "312D3C3A3321"

    invoke-static {v4}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    .line 32
    iget-object v6, v1, Lcom/github/catvod/spider/XYQHiker;->ؠ:Ljava/lang/String;

    invoke-virtual {v2, v4, v6}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    :try_end_1de
    .catch Ljava/lang/Exception; {:try_start_c7 .. :try_end_1de} :catch_1e0

    goto/16 :goto_28e

    :catch_1e0
    move-exception v0

    move-object v2, v0

    move-object v3, v8

    goto/16 :goto_ce9

    :cond_1e5
    move-object/from16 v17, v11

    .line 33
    :try_start_1e7
    invoke-virtual {v4}, Ljava/lang/String;->isEmpty()Z

    move-result v6
    :try_end_1eb
    .catch Ljava/lang/Exception; {:try_start_1e7 .. :try_end_1eb} :catch_ce6

    if-eqz v6, :cond_1f4

    :try_start_1ed
    const-string v4, "1D293B252E345D717D60686A4373"

    invoke-static {v4}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4
    :try_end_1f3
    .catch Ljava/lang/Exception; {:try_start_1ed .. :try_end_1f3} :catch_1e0

    goto :goto_256

    .line 34
    :cond_1f4
    :try_start_1f4
    invoke-virtual {v4, v10}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v6
    :try_end_1f8
    .catch Ljava/lang/Exception; {:try_start_1f4 .. :try_end_1f8} :catch_ce6

    if-nez v6, :cond_254

    :try_start_1fa
    invoke-virtual {v4, v9}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_201

    goto :goto_254

    :cond_201
    const-string v6, "3F0D111816012D1712"

    invoke-static {v6}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    .line 35
    invoke-virtual {v4, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v6

    if-nez v6, :cond_251

    const-string v6, "94CBD8B7C6FE"

    invoke-static {v6}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v4, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_21a

    goto :goto_251

    :cond_21a
    const-string v6, "3B0D000E0F05"

    invoke-static {v6}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    .line 36
    invoke-virtual {v4, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v6

    if-nez v6, :cond_24e

    const-string v6, "9AC9EAB7C4D894CBD8B7C6FE"

    invoke-static {v6}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v4, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_233

    goto :goto_24e

    :cond_233
    const-string v6, "3F03100E0F05"

    invoke-static {v6}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    .line 37
    invoke-virtual {v4, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v6

    if-nez v6, :cond_24b

    const-string v6, "9AC9EAB7C4D895D6E6B9DED5"

    invoke-static {v6}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v4, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_256

    .line 38
    :cond_24b
    sget-object v4, Lcom/github/catvod/spider/XYQHiker;->ԭ:Ljava/lang/String;

    goto :goto_256

    .line 39
    :cond_24e
    :goto_24e
    sget-object v4, Lcom/github/catvod/spider/XYQHiker;->Ԭ:Ljava/lang/String;

    goto :goto_256

    .line 40
    :cond_251
    :goto_251
    sget-object v4, Lcom/github/catvod/spider/XYQHiker;->ԫ:Ljava/lang/String;
    :try_end_253
    .catch Ljava/lang/Exception; {:try_start_1fa .. :try_end_253} :catch_1e0

    goto :goto_256

    .line 41
    :cond_254
    :goto_254
    :try_start_254
    sget-object v4, Lcom/github/catvod/spider/XYQHiker;->Ԫ:Ljava/lang/String;

    .line 42
    :cond_256
    :goto_256
    iget-object v6, v1, Lcom/github/catvod/spider/XYQHiker;->ؠ:Ljava/lang/String;

    invoke-virtual {v6}, Ljava/lang/String;->isEmpty()Z

    move-result v6
    :try_end_25c
    .catch Ljava/lang/Exception; {:try_start_254 .. :try_end_25c} :catch_ce6

    if-nez v6, :cond_272

    .line 43
    :try_start_25e
    iget-object v6, v1, Lcom/github/catvod/spider/XYQHiker;->ؠ:Ljava/lang/String;

    invoke-virtual {v6}, Ljava/lang/String;->length()I

    move-result v6

    const/4 v9, 0x1

    if-le v6, v9, :cond_272

    const-string v6, "312D3C3A3321"

    invoke-static {v6}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    .line 44
    iget-object v9, v1, Lcom/github/catvod/spider/XYQHiker;->ؠ:Ljava/lang/String;

    invoke-virtual {v2, v6, v9}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    :try_end_272
    .catch Ljava/lang/Exception; {:try_start_25e .. :try_end_272} :catch_1e0

    .line 45
    :cond_272
    :try_start_272
    invoke-direct {v1, v5}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v6, v12}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v6
    :try_end_27a
    .catch Ljava/lang/Exception; {:try_start_272 .. :try_end_27a} :catch_ce6

    if-eqz v6, :cond_285

    :try_start_27c
    const-string v6, "20273534282100"

    invoke-static {v6}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    .line 46
    invoke-virtual {v2, v6, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    :try_end_285
    .catch Ljava/lang/Exception; {:try_start_27c .. :try_end_285} :catch_1e0

    :cond_285
    :try_start_285
    const-string v6, "27313623770515273D25"

    invoke-static {v6}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    .line 47
    invoke-virtual {v2, v6, v4}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    :cond_28e
    :goto_28e
    const-string v4, "9BD1EDB7D4E194DAFCB4CAE295D9E7B7D4E194D0FEB7CEFA"

    invoke-static {v4}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    .line 48
    invoke-direct {v1, v4}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/String;->isEmpty()Z

    move-result v4
    :try_end_29c
    .catch Ljava/lang/Exception; {:try_start_285 .. :try_end_29c} :catch_ce6

    if-nez v4, :cond_2a5

    :try_start_29e
    const-string v4, "9BD1EDB7D4E194DAFCB4CAE295D9E7B7D4E194D0FEB7CEFA"

    invoke-static {v4}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4
    :try_end_2a4
    .catch Ljava/lang/Exception; {:try_start_29e .. :try_end_2a4} :catch_1e0

    goto :goto_2ab

    :cond_2a5
    :try_start_2a5
    const-string v4, "142D21323F1B022E3228"

    invoke-static {v4}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    :goto_2ab
    const-string v6, "95D9E7B7D4E194D0FEB7CEFA9BD1EDB7D4E197C8F3B4D3C995FED3"

    invoke-static {v6}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    .line 49
    invoke-direct {v1, v6}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/String;->isEmpty()Z

    move-result v6
    :try_end_2b9
    .catch Ljava/lang/Exception; {:try_start_2a5 .. :try_end_2b9} :catch_ce6

    if-nez v6, :cond_2c2

    :try_start_2bb
    const-string v6, "95D9E7B7D4E194D0FEB7CEFA9BD1EDB7D4E197C8F3B4D3C995FED3"

    invoke-static {v6}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6
    :try_end_2c1
    .catch Ljava/lang/Exception; {:try_start_2bb .. :try_end_2c1} :catch_1e0

    goto :goto_2c8

    :cond_2c2
    :try_start_2c2
    const-string v6, "022E322805340027353822"

    invoke-static {v6}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    :goto_2c8
    const-string v9, "95D9E7B7D4E194D0FEB7CEFA9BD1EDB7D4E197C8F3B4CACA95FED3"

    invoke-static {v9}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    .line 50
    invoke-direct {v1, v9}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v9}, Ljava/lang/String;->isEmpty()Z

    move-result v9
    :try_end_2d6
    .catch Ljava/lang/Exception; {:try_start_2c2 .. :try_end_2d6} :catch_ce6

    if-nez v9, :cond_2df

    :try_start_2d8
    const-string v9, "95D9E7B7D4E194D0FEB7CEFA9BD1EDB7D4E197C8F3B4CACA95FED3"

    invoke-static {v9}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9
    :try_end_2de
    .catch Ljava/lang/Exception; {:try_start_2d8 .. :try_end_2de} :catch_1e0

    goto :goto_2e5

    :cond_2df
    :try_start_2df
    const-string v9, "022E322805370724353822"

    invoke-static {v9}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    :goto_2e5
    const-string v10, "95D9E7B7D4E194D0FEB7CEFA95D9E7B8C9FA9AE5D5B8F8D59AEDE4B7EBC697E6E7"

    invoke-static {v10}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    .line 51
    invoke-direct {v1, v10}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v10}, Ljava/lang/String;->isEmpty()Z

    move-result v10
    :try_end_2f3
    .catch Ljava/lang/Exception; {:try_start_2df .. :try_end_2f3} :catch_ce6

    if-nez v10, :cond_2fc

    :try_start_2f5
    const-string v10, "95D9E7B7D4E194D0FEB7CEFA95D9E7B8C9FA9AE5D5B8F8D59AEDE4B7EBC697E6E7"

    invoke-static {v10}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10
    :try_end_2fb
    .catch Ljava/lang/Exception; {:try_start_2f5 .. :try_end_2fb} :catch_1e0

    goto :goto_302

    :cond_2fc
    :try_start_2fc
    const-string v10, "022E3228052C1723373428"

    invoke-static {v10}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    .line 52
    :goto_302
    new-instance v11, Lorg/json/JSONObject;

    invoke-direct {v11}, Lorg/json/JSONObject;-><init>()V

    .line 53
    invoke-direct {v1, v4}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v13

    invoke-virtual {v13, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v13
    :try_end_30f
    .catch Ljava/lang/Exception; {:try_start_2fc .. :try_end_30f} :catch_ce6

    if-nez v13, :cond_31e

    :try_start_311
    invoke-direct {v1, v4}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v4, v12}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4
    :try_end_319
    .catch Ljava/lang/Exception; {:try_start_311 .. :try_end_319} :catch_1e0

    if-eqz v4, :cond_31c

    goto :goto_31e

    :cond_31c
    const/4 v4, 0x0

    goto :goto_31f

    :cond_31e
    :goto_31e
    const/4 v4, 0x1

    :goto_31f
    const-string v13, "022E32280F361E"

    invoke-static {v13}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v13

    const-string v14, "1A2732353F36"

    invoke-static {v14}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v14

    const-string v15, "07303F"

    invoke-static {v15}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v15

    move-object/from16 v16, v12

    const-string v12, "022321223F"

    invoke-static {v12}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v12

    if-eqz v4, :cond_459

    .line 54
    :try_start_33b
    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    invoke-direct {v1, v6, v8}, Lcom/github/catvod/spider/XYQHiker;->ރ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-direct {v1, v9, v8}, Lcom/github/catvod/spider/XYQHiker;->ރ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    .line 55
    invoke-direct {v1, v10}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/String;->isEmpty()Z

    move-result v4

    if-nez v4, :cond_3bf

    .line 56
    iget-object v2, v1, Lcom/github/catvod/spider/XYQHiker;->ކ:Lorg/json/JSONObject;

    invoke-virtual {v2, v10}, Lorg/json/JSONObject;->optJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v2

    if-eqz v2, :cond_36f

    .line 57
    invoke-virtual {v2}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v11, v14, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    goto :goto_3c6

    .line 58
    :cond_36f
    invoke-direct {v1, v10}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    move-object/from16 v4, v17

    invoke-virtual {v2, v4}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v2

    .line 59
    new-instance v4, Lorg/json/JSONObject;

    invoke-direct {v4}, Lorg/json/JSONObject;-><init>()V

    .line 60
    array-length v5, v2

    const/4 v6, 0x0

    :goto_380
    if-ge v6, v5, :cond_3b7

    aget-object v9, v2, v6

    const-string v10, "2E66"

    invoke-static {v10}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    .line 61
    invoke-virtual {v9, v10}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v9

    move-object/from16 p2, v2

    const/4 v10, 0x0

    .line 62
    aget-object v2, v9, v10

    new-instance v10, Ljava/lang/StringBuilder;

    invoke-direct {v10}, Ljava/lang/StringBuilder;-><init>()V

    move/from16 v16, v5

    const-string v5, "52"

    invoke-static {v5}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v10, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x1

    aget-object v9, v9, v5

    invoke-virtual {v10, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v10}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v2, v5}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    add-int/lit8 v6, v6, 0x1

    move-object/from16 v2, p2

    move/from16 v5, v16

    goto :goto_380

    .line 63
    :cond_3b7
    invoke-virtual {v4}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v11, v14, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    goto :goto_3c6

    .line 64
    :cond_3bf
    invoke-virtual {v2}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v11, v14, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    :goto_3c6
    const-string v2, "042B237F3C22083B"

    invoke-static {v2}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    .line 65
    invoke-virtual {v3, v2}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v2
    :try_end_3d0
    .catch Ljava/lang/Exception; {:try_start_33b .. :try_end_3d0} :catch_1e0

    const-string v4, "512B20073320172D6E2528311761"

    invoke-static {v4}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    if-nez v2, :cond_3fc

    :try_start_3d8
    const-string v2, "042B237F363E"

    invoke-static {v2}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v3, v2}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v2

    if-nez v2, :cond_3fc

    const-string v2, "1A267D3D20"

    invoke-static {v2}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v3, v2}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v2

    if-nez v2, :cond_3fc

    const-string v2, "01373C3F333E0B"

    invoke-static {v2}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v3, v2}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v2

    if-eqz v2, :cond_410

    :cond_3fc
    const-string v2, "5D313B3028215D"

    invoke-static {v2}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v3, v2}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v2

    if-eqz v2, :cond_410

    .line 66
    invoke-virtual {v3, v4, v8}, Ljava/lang/String;->replaceAll(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Lcom/github/catvod/spider/xbpqxyq/xyq/ވ;->ކ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    .line 67
    :cond_410
    invoke-virtual {v3, v4}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v2

    if-nez v2, :cond_440

    invoke-static {v3}, Lcom/github/catvod/spider/xbpqxyq/xyq/ކ;->ԫ(Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_41d

    goto :goto_440

    .line 68
    :cond_41d
    invoke-static {v3}, Lcom/github/catvod/spider/xbpqxyq/xyq/ކ;->Ԭ(Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_438

    const/4 v2, 0x1

    .line 69
    invoke-virtual {v11, v12, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    const-string v2, "183A"

    invoke-static {v2}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    .line 70
    invoke-virtual {v11, v2, v7}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 71
    invoke-virtual {v11, v15, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 72
    invoke-virtual {v11}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object v2

    return-object v2

    :cond_438
    const/4 v2, 0x1

    .line 73
    invoke-virtual {v11, v12, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    .line 74
    invoke-virtual {v11, v13, v8}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    goto :goto_451

    .line 75
    :cond_440
    :goto_440
    invoke-virtual {v3, v4}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v2

    if-eqz v2, :cond_44a

    .line 76
    invoke-virtual {v3, v4, v8}, Ljava/lang/String;->replaceAll(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    :cond_44a
    const/4 v2, 0x0

    .line 77
    invoke-virtual {v11, v12, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    .line 78
    invoke-virtual {v11, v13, v8}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 79
    :goto_451
    invoke-virtual {v11, v15, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 80
    invoke-virtual {v11}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object v2
    :try_end_458
    .catch Ljava/lang/Exception; {:try_start_3d8 .. :try_end_458} :catch_1e0

    return-object v2

    .line 81
    :cond_459
    :try_start_459
    invoke-direct {v1, v5}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v6, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v6
    :try_end_461
    .catch Ljava/lang/Exception; {:try_start_459 .. :try_end_461} :catch_ce6

    if-nez v6, :cond_482

    :try_start_463
    invoke-direct {v1, v5}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    move-object/from16 v9, v16

    invoke-virtual {v6, v9}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v6

    if-nez v6, :cond_484

    invoke-direct {v1, v5}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    const-string v10, "94DAFC"

    invoke-static {v10}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v6, v10}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v6
    :try_end_47d
    .catch Ljava/lang/Exception; {:try_start_463 .. :try_end_47d} :catch_1e0

    if-eqz v6, :cond_480

    goto :goto_484

    :cond_480
    const/4 v6, 0x0

    goto :goto_485

    :cond_482
    move-object/from16 v9, v16

    :cond_484
    :goto_484
    const/4 v6, 0x1

    :goto_485
    if-eqz v6, :cond_7c4

    if-nez v4, :cond_7c4

    .line 82
    :try_start_489
    iget-object v10, v1, Lcom/github/catvod/spider/XYQHiker;->ހ:Ljava/lang/String;
    :try_end_48b
    .catch Ljava/lang/Exception; {:try_start_489 .. :try_end_48b} :catch_76f

    move-object/from16 v17, v9

    :try_start_48d
    invoke-virtual {v1, v3}, Lcom/github/catvod/spider/XYQHiker;->ހ(Ljava/lang/String;)Ljava/util/HashMap;

    move-result-object v9

    invoke-virtual {v1, v3, v10, v9}, Lcom/github/catvod/spider/XYQHiker;->Ԭ(Ljava/lang/String;Ljava/lang/String;Ljava/util/Map;)Ljava/lang/String;

    move-result-object v9

    const-string v10, "94E1D3B7EFCF96FAFE"

    invoke-static {v10}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    .line 83
    invoke-virtual {v9, v10}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v10
    :try_end_49f
    .catch Ljava/lang/Exception; {:try_start_48d .. :try_end_49f} :catch_76b

    move-object/from16 v18, v5

    const-string v5, "012A3C26"

    invoke-static {v5}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    if-eqz v10, :cond_4b9

    :try_start_4a9
    const-string v10, "103624303C"

    invoke-static {v10}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v9, v10}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v10

    if-eqz v10, :cond_4b9

    .line 84
    invoke-direct {v1, v3, v9, v5}, Lcom/github/catvod/spider/XYQHiker;->އ(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    :cond_4b9
    const-string v10, "5D2A26303E2B1C250C"

    invoke-static {v10}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    .line 85
    invoke-virtual {v9, v10}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v10

    if-nez v10, :cond_4d1

    const-string v10, "5D30363F302D2D"

    invoke-static {v10}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v9, v10}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v10

    if-eqz v10, :cond_4d5

    .line 86
    :cond_4d1
    invoke-direct {v1, v3, v9, v5}, Lcom/github/catvod/spider/XYQHiker;->ކ(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    :cond_4d5
    const-string v10, "9AFCC0B4DFE19BE8DFB9F5C595E2D2"

    invoke-static {v10}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    .line 87
    invoke-virtual {v9, v10}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v10
    :try_end_4df
    .catch Ljava/lang/Exception; {:try_start_4a9 .. :try_end_4df} :catch_769

    if-eqz v10, :cond_505

    :try_start_4e1
    invoke-static {v9}, Lcom/github/catvod/spider/XYQHiker;->checkveriry(Ljava/lang/String;)Z

    move-result v10

    if-eqz v10, :cond_505

    .line 88
    invoke-static {v9}, Lcom/github/catvod/spider/XYQHiker;->vertype(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9
    :try_end_4eb
    .catch Ljava/lang/Exception; {:try_start_4e1 .. :try_end_4eb} :catch_4f3

    const/4 v10, 0x0

    :try_start_4ec
    invoke-direct {v1, v3, v10, v5, v9}, Lcom/github/catvod/spider/XYQHiker;->ވ(Ljava/lang/String;Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9
    :try_end_4f0
    .catch Ljava/lang/Exception; {:try_start_4ec .. :try_end_4f0} :catch_4f1

    goto :goto_506

    :catch_4f1
    move-exception v0

    goto :goto_4f5

    :catch_4f3
    move-exception v0

    const/4 v10, 0x0

    :goto_4f5
    move-object v9, v0

    move-object v5, v10

    move-object/from16 v20, v5

    move-object/from16 v23, v20

    move-object/from16 v24, v23

    move-object/from16 v25, v24

    move-object/from16 v26, v25

    move-object/from16 v27, v26

    goto/16 :goto_783

    :cond_505
    const/4 v10, 0x0

    .line 89
    :goto_506
    :try_start_506
    invoke-static {v9}, Lcom/github/catvod/spider/xbpqxyq/xyq/ٱ;->Ϳ(Ljava/lang/String;)Lcom/github/catvod/spider/xbpqxyq/xyq/ǐ;

    move-result-object v5

    const-string v9, "1A2732357C62062B273D3F62541636292E"

    invoke-static {v9}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    .line 90
    invoke-static {v5, v9}, Lcom/github/catvod/spider/XYQHiker;->getTextByRule(Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    const-string v10, "5F"

    invoke-static {v10}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v9, v10}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v9

    const/4 v10, 0x0

    aget-object v9, v9, v10

    const-string v9, "012121382A30"

    invoke-static {v9}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    .line 91
    invoke-virtual {v5, v9}, Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;->ࢳ(Ljava/lang/String;)Lcom/github/catvod/spider/xbpqxyq/xyq/ำ;

    move-result-object v5

    const/4 v9, 0x0

    .line 92
    :goto_52c
    invoke-virtual {v5}, Ljava/util/ArrayList;->size()I

    move-result v10

    if-ge v9, v10, :cond_69b

    .line 93
    invoke-virtual {v5, v9}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v10

    check-cast v10, Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;

    invoke-virtual {v10}, Lcom/github/catvod/spider/xbpqxyq/xyq/ĺ;->ࢣ()Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v10}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v10

    move-object/from16 v19, v5

    const-string v5, "042321712A28133B362305"

    invoke-static {v5}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    .line 94
    invoke-virtual {v10, v5}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v5

    if-eqz v5, :cond_695

    const/16 v5, 0x7b

    .line 95
    invoke-virtual {v10, v5}, Ljava/lang/String;->indexOf(I)I

    move-result v5

    const/16 v9, 0x7d

    .line 96
    invoke-virtual {v10, v9}, Ljava/lang/String;->lastIndexOf(I)I

    move-result v9

    const/16 v19, 0x1

    add-int/lit8 v9, v9, 0x1

    .line 97
    invoke-virtual {v10, v5, v9}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v5

    .line 98
    new-instance v9, Lorg/json/JSONObject;

    invoke-direct {v9, v5}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    .line 99
    invoke-virtual {v9, v15}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    const-string v10, "14303C3C"

    invoke-static {v10}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    .line 100
    invoke-virtual {v9, v10}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10
    :try_end_575
    .catch Ljava/lang/Exception; {:try_start_506 .. :try_end_575} :catch_769

    move-object/from16 v19, v10

    :try_start_577
    const-string v10, "1E2B3D3A052A173A27"

    invoke-static {v10}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    .line 101
    invoke-virtual {v9, v10}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    move-object/from16 v20, v10

    const-string v10, "19272A"

    invoke-static {v10}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    .line 102
    invoke-virtual {v9, v10}, Lorg/json/JSONObject;->has(Ljava/lang/String;)Z

    move-result v10

    move/from16 v21, v10

    const-string v10, "062F"

    invoke-static {v10}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    .line 103
    invoke-virtual {v9, v10}, Lorg/json/JSONObject;->has(Ljava/lang/String;)Z

    move-result v10

    move/from16 v22, v10

    const-string v10, "1B26"

    invoke-static {v10}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    .line 104
    invoke-virtual {v9, v10}, Lorg/json/JSONObject;->has(Ljava/lang/String;)Z

    move-result v10

    if-eqz v10, :cond_5b8

    const-string v10, "1B26"

    invoke-static {v10}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    .line 105
    invoke-virtual {v9, v10}, Lorg/json/JSONObject;->getInt(Ljava/lang/String;)I

    move-result v10

    invoke-static {v10}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v10
    :try_end_5b5
    .catch Ljava/lang/Exception; {:try_start_577 .. :try_end_5b5} :catch_68e

    move-object/from16 v23, v10

    goto :goto_5ba

    :cond_5b8
    const/16 v23, 0x0

    :goto_5ba
    :try_start_5ba
    const-string v10, "042D370E2A2D111D27392F2910"

    invoke-static {v10}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    .line 106
    invoke-virtual {v9, v10}, Lorg/json/JSONObject;->has(Ljava/lang/String;)Z

    move-result v10

    if-eqz v10, :cond_5d3

    const-string v10, "042D370E2A2D111D27392F2910"

    invoke-static {v10}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    .line 107
    invoke-virtual {v9, v10}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10
    :try_end_5d0
    .catch Ljava/lang/Exception; {:try_start_5ba .. :try_end_5d0} :catch_685

    move-object/from16 v24, v10

    goto :goto_5d5

    :cond_5d3
    const/16 v24, 0x0

    :goto_5d5
    :try_start_5d5
    const-string v10, "042D370E2E2D062E36"

    invoke-static {v10}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    .line 108
    invoke-virtual {v9, v10}, Lorg/json/JSONObject;->has(Ljava/lang/String;)Z

    move-result v10

    if-eqz v10, :cond_615

    const-string v10, "042D370E2E2D062E360E34251F27"

    invoke-static {v10}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v9, v10}, Lorg/json/JSONObject;->has(Ljava/lang/String;)Z

    move-result v10

    if-eqz v10, :cond_615

    const-string v10, "042D370E2E2D062E36"

    invoke-static {v10}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    .line 109
    invoke-virtual {v9, v10}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10
    :try_end_5f7
    .catch Ljava/lang/Exception; {:try_start_5d5 .. :try_end_5f7} :catch_67c

    move-object/from16 v25, v10

    :try_start_5f9
    const-string v10, "042D370E2E2D062E360E34251F27"

    invoke-static {v10}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    .line 110
    invoke-virtual {v9, v10}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10
    :try_end_603
    .catch Ljava/lang/Exception; {:try_start_5f9 .. :try_end_603} :catch_608

    move-object/from16 v26, v25

    move-object/from16 v25, v10

    goto :goto_619

    :catch_608
    move-exception v0

    move-object v9, v0

    move-object/from16 v10, v19

    move-object/from16 v26, v25

    const/4 v5, 0x0

    const/16 v20, 0x0

    const/16 v25, 0x0

    goto/16 :goto_781

    :cond_615
    const/16 v25, 0x0

    const/16 v26, 0x0

    :goto_619
    :try_start_619
    const-string v10, "1C2B37"

    invoke-static {v10}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    .line 111
    invoke-virtual {v9, v10}, Lorg/json/JSONObject;->has(Ljava/lang/String;)Z

    move-result v10

    if-eqz v10, :cond_636

    const-string v10, "1C2B37"

    invoke-static {v10}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    .line 112
    invoke-virtual {v9, v10}, Lorg/json/JSONObject;->getInt(Ljava/lang/String;)I

    move-result v10

    invoke-static {v10}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v10
    :try_end_633
    .catch Ljava/lang/Exception; {:try_start_619 .. :try_end_633} :catch_673

    move-object/from16 v27, v10

    goto :goto_638

    :cond_636
    const/16 v27, 0x0

    :goto_638
    :try_start_638
    const-string v10, "172C3023233406"

    invoke-static {v10}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    .line 113
    invoke-virtual {v9, v10}, Lorg/json/JSONObject;->has(Ljava/lang/String;)Z

    move-result v10

    if-eqz v10, :cond_667

    const-string v10, "172C3023233406"

    invoke-static {v10}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    .line 114
    invoke-virtual {v9, v10}, Lorg/json/JSONObject;->getInt(Ljava/lang/String;)I

    move-result v9

    const/4 v10, 0x1

    if-ne v9, v10, :cond_656

    .line 115
    invoke-static {v5}, Ljava/net/URLDecoder;->decode(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    goto :goto_667

    :cond_656
    const/4 v10, 0x2

    if-ne v9, v10, :cond_667

    .line 116
    new-instance v9, Ljava/lang/String;

    const/4 v10, 0x0

    invoke-static {v5, v10}, Landroid/util/Base64;->decode(Ljava/lang/String;I)[B

    move-result-object v5

    invoke-direct {v9, v5}, Ljava/lang/String;-><init>([B)V

    .line 117
    invoke-static {v9}, Ljava/net/URLDecoder;->decode(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5
    :try_end_667
    .catch Ljava/lang/Exception; {:try_start_638 .. :try_end_667} :catch_66a

    :cond_667
    :goto_667
    move-object/from16 v10, v19

    goto :goto_6ad

    :catch_66a
    move-exception v0

    move-object v9, v0

    move-object/from16 v10, v19

    const/4 v5, 0x0

    const/16 v20, 0x0

    goto/16 :goto_783

    :catch_673
    move-exception v0

    move-object v9, v0

    move-object/from16 v10, v19

    const/4 v5, 0x0

    const/16 v20, 0x0

    goto/16 :goto_781

    :catch_67c
    move-exception v0

    move-object v9, v0

    move-object/from16 v10, v19

    const/4 v5, 0x0

    const/16 v20, 0x0

    goto/16 :goto_77d

    :catch_685
    move-exception v0

    move-object v9, v0

    move-object/from16 v10, v19

    const/4 v5, 0x0

    const/16 v20, 0x0

    goto/16 :goto_77b

    :catch_68e
    move-exception v0

    move-object v9, v0

    move-object/from16 v10, v19

    const/4 v5, 0x0

    goto/16 :goto_777

    :cond_695
    add-int/lit8 v9, v9, 0x1

    move-object/from16 v5, v19

    goto/16 :goto_52c

    :cond_69b
    const/4 v5, 0x0

    const/4 v10, 0x0

    const/16 v20, 0x0

    const/16 v21, 0x0

    const/16 v22, 0x0

    const/16 v23, 0x0

    const/16 v24, 0x0

    const/16 v25, 0x0

    const/16 v26, 0x0

    const/16 v27, 0x0

    :goto_6ad
    :try_start_6ad
    const-string v9, "042B237F3C22083B"

    invoke-static {v9}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    .line 118
    invoke-virtual {v5, v9}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v9
    :try_end_6b7
    .catch Ljava/lang/Exception; {:try_start_6ad .. :try_end_6b7} :catch_764

    if-nez v9, :cond_6e1

    :try_start_6b9
    const-string v9, "042B237F363E"

    invoke-static {v9}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v5, v9}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v9

    if-nez v9, :cond_6e1

    const-string v9, "1A267D3D20"

    invoke-static {v9}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v5, v9}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v9

    if-nez v9, :cond_6e1

    const-string v9, "01373C3F333E0B"

    invoke-static {v9}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v5, v9}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v9
    :try_end_6db
    .catch Ljava/lang/Exception; {:try_start_6b9 .. :try_end_6db} :catch_6de

    if-eqz v9, :cond_6f1

    goto :goto_6e1

    :catch_6de
    move-exception v0

    goto/16 :goto_767

    :cond_6e1
    :goto_6e1
    :try_start_6e1
    const-string v9, "5D313B3028215D"

    invoke-static {v9}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v5, v9}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v9
    :try_end_6eb
    .catch Ljava/lang/Exception; {:try_start_6e1 .. :try_end_6eb} :catch_764

    if-eqz v9, :cond_6f1

    .line 119
    :try_start_6ed
    invoke-static {v5}, Lcom/github/catvod/spider/xbpqxyq/xyq/ވ;->ކ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5
    :try_end_6f1
    .catch Ljava/lang/Exception; {:try_start_6ed .. :try_end_6f1} :catch_6de

    .line 120
    :cond_6f1
    :try_start_6f1
    iget-boolean v9, v1, Lcom/github/catvod/spider/XYQHiker;->ވ:Z

    if-eqz v9, :cond_710

    .line 121
    new-instance v9, Ljava/lang/StringBuilder;

    invoke-direct {v9}, Ljava/lang/StringBuilder;-><init>()V
    :try_end_6fa
    .catch Ljava/lang/Exception; {:try_start_6f1 .. :try_end_6fa} :catch_764

    move-object/from16 v19, v10

    :try_start_6fc
    const-string v10, "9AE5D5B8F8D59BD1EDB7D4E19DFEC9"

    invoke-static {v10}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v9, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v9, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v9}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v9

    invoke-static {v9}, Lcom/github/catvod/spider/Init;->show(Ljava/lang/String;)V

    goto :goto_712

    :cond_710
    move-object/from16 v19, v10

    :goto_712
    if-nez v22, :cond_72d

    if-eqz v21, :cond_717

    goto :goto_72d

    :cond_717
    move-object/from16 v22, v2

    move-object/from16 v21, v14

    move-object/from16 v10, v19

    move-object/from16 v9, v20

    move-object/from16 v14, v25

    move-object/from16 v2, v26

    move-object/from16 v28, v27

    move-object/from16 v19, v8

    move-object/from16 v20, v13

    move-object/from16 v13, v24

    goto/16 :goto_7da

    .line 122
    :cond_72d
    :goto_72d
    invoke-static {v5}, Lcom/github/catvod/spider/xbpqxyq/xyq/ކ;->ԫ(Ljava/lang/String;)Z

    move-result v9

    if-eqz v9, :cond_749

    const/4 v9, 0x0

    .line 123
    invoke-virtual {v11, v12, v9}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    .line 124
    invoke-virtual {v11, v13, v8}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 125
    invoke-virtual {v11, v15, v5}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 126
    invoke-virtual {v2}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v11, v14, v9}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 127
    invoke-virtual {v11}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object v2

    return-object v2

    .line 128
    :cond_749
    invoke-virtual {v2}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v11, v14, v9}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v9, 0x1

    .line 129
    invoke-virtual {v11, v12, v9}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    .line 130
    invoke-virtual {v11, v13, v8}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 131
    invoke-virtual {v11, v15, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 132
    invoke-virtual {v11}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object v2
    :try_end_75e
    .catch Ljava/lang/Exception; {:try_start_6fc .. :try_end_75e} :catch_75f

    return-object v2

    :catch_75f
    move-exception v0

    move-object v9, v0

    move-object/from16 v10, v19

    goto :goto_783

    :catch_764
    move-exception v0

    move-object/from16 v19, v10

    :goto_767
    move-object v9, v0

    goto :goto_783

    :catch_769
    move-exception v0

    goto :goto_774

    :catch_76b
    move-exception v0

    move-object/from16 v18, v5

    goto :goto_774

    :catch_76f
    move-exception v0

    move-object/from16 v18, v5

    move-object/from16 v17, v9

    :goto_774
    move-object v9, v0

    const/4 v5, 0x0

    const/4 v10, 0x0

    :goto_777
    const/16 v20, 0x0

    const/16 v23, 0x0

    :goto_77b
    const/16 v24, 0x0

    :goto_77d
    const/16 v25, 0x0

    const/16 v26, 0x0

    :goto_781
    const/16 v27, 0x0

    .line 133
    :goto_783
    :try_start_783
    invoke-static {v9}, Lcom/github/catvod/crawler/SpiderDebug;->log(Ljava/lang/Throwable;)V

    move-object/from16 v19, v5

    .line 134
    iget-boolean v5, v1, Lcom/github/catvod/spider/XYQHiker;->ވ:Z

    if-eqz v5, :cond_7ab

    .line 135
    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    move-object/from16 v21, v10

    const-string v10, "97CAD5B7C4D4042321712A28133B20B8D9EC97CAD5B4DDFE9BD6CABEE6DE"

    invoke-static {v10}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v5, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v9}, Ljava/lang/Exception;->toString()Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v5, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-static {v5}, Lcom/github/catvod/spider/Init;->show(Ljava/lang/String;)V
    :try_end_7aa
    .catch Ljava/lang/Exception; {:try_start_783 .. :try_end_7aa} :catch_1e0

    goto :goto_7ad

    :cond_7ab
    move-object/from16 v21, v10

    :goto_7ad
    move-object/from16 v22, v2

    move-object/from16 v5, v19

    move-object/from16 v9, v20

    move-object/from16 v10, v21

    move-object/from16 v2, v26

    move-object/from16 v28, v27

    move-object/from16 v19, v8

    move-object/from16 v20, v13

    move-object/from16 v21, v14

    move-object/from16 v13, v24

    move-object/from16 v14, v25

    goto :goto_7da

    :cond_7c4
    move-object/from16 v18, v5

    move-object/from16 v17, v9

    move-object/from16 v22, v2

    move-object/from16 v19, v8

    move-object/from16 v20, v13

    move-object/from16 v21, v14

    const/4 v2, 0x0

    const/4 v5, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x0

    const/4 v13, 0x0

    const/4 v14, 0x0

    const/16 v23, 0x0

    const/16 v28, 0x0

    :goto_7da
    const-string v8, "542C3A3567"

    invoke-static {v8}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    move-object/from16 v24, v13

    const-string v13, "5428263C2A79"

    invoke-static {v13}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v13

    move-object/from16 v25, v14

    const-string v14, "542C36292E79"

    invoke-static {v14}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v14

    if-eqz v6, :cond_a0e

    if-nez v4, :cond_a0e

    .line 136
    :try_start_7f4
    new-instance v4, Ljava/text/SimpleDateFormat;

    const-string v6, "0B3B2A2817091626"

    invoke-static {v6}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    invoke-direct {v4, v6}, Ljava/text/SimpleDateFormat;-><init>(Ljava/lang/String;)V

    new-instance v6, Ljava/util/Date;

    invoke-direct {v6}, Ljava/util/Date;-><init>()V

    invoke-virtual {v4, v6}, Ljava/text/SimpleDateFormat;->format(Ljava/util/Date;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/String;->toString()Ljava/lang/String;

    move-result-object v4

    .line 137
    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V
    :try_end_811
    .catch Ljava/lang/Exception; {:try_start_7f4 .. :try_end_811} :catch_9da

    move-object/from16 v26, v2

    :try_start_813
    const-string v2, "5D3127302E2D116D392275341E232A3428271D2C35383D6A18316C2567"

    invoke-static {v2}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v6, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v6, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v3, v2}, Lcom/github/catvod/spider/xbpqxyq/xyq/ވ;->Ԫ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    .line 138
    iget-object v4, v1, Lcom/github/catvod/spider/XYQHiker;->ހ:Ljava/lang/String;

    invoke-virtual {v1, v3}, Lcom/github/catvod/spider/XYQHiker;->ހ(Ljava/lang/String;)Ljava/util/HashMap;

    move-result-object v6

    invoke-virtual {v1, v2, v4, v6}, Lcom/github/catvod/spider/XYQHiker;->Ԭ(Ljava/lang/String;Ljava/lang/String;Ljava/util/Map;)Ljava/lang/String;

    move-result-object v2

    .line 139
    iget-object v4, v1, Lcom/github/catvod/spider/XYQHiker;->ބ:Ljava/lang/String;

    invoke-static {v4}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    move-result-object v4

    invoke-virtual {v4, v2}, Ljava/util/regex/Pattern;->matcher(Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;

    move-result-object v2

    .line 140
    invoke-virtual {v2}, Ljava/util/regex/Matcher;->find()Z

    move-result v4

    if-eqz v4, :cond_84c

    .line 141
    new-instance v4, Lorg/json/JSONObject;

    const/4 v6, 0x1

    invoke-virtual {v2, v6}, Ljava/util/regex/Matcher;->group(I)Ljava/lang/String;

    move-result-object v2

    invoke-direct {v4, v2}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    goto :goto_84d

    :cond_84c
    const/4 v4, 0x0

    :goto_84d
    if-eqz v4, :cond_a10

    .line 142
    invoke-virtual {v4, v10}, Lorg/json/JSONObject;->has(Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_a10

    .line 143
    invoke-virtual {v4, v10}, Lorg/json/JSONObject;->getJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v2

    const-string v4, "0231"

    invoke-static {v4}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    .line 144
    invoke-virtual {v2, v4}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v4, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_8ba

    .line 145
    invoke-virtual {v2, v12}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/String;->isEmpty()Z

    move-result v4

    if-eqz v4, :cond_876

    move-object/from16 v2, v19

    goto :goto_87a

    :cond_876
    invoke-virtual {v2, v12}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2
    :try_end_87a
    .catch Ljava/lang/Exception; {:try_start_813 .. :try_end_87a} :catch_9d8

    .line 146
    :goto_87a
    :try_start_87a
    invoke-virtual {v2}, Ljava/lang/String;->isEmpty()Z

    move-result v4

    if-nez v4, :cond_8a8

    const-string v4, "5D3127302E2D116D233D3B3D17307C213B3601277D3B29"

    invoke-static {v4}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    .line 147
    invoke-static {v3, v4}, Lcom/github/catvod/spider/xbpqxyq/xyq/ވ;->Ԫ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    .line 148
    iget-object v6, v1, Lcom/github/catvod/spider/XYQHiker;->ހ:Ljava/lang/String;
    :try_end_88c
    .catch Ljava/lang/Exception; {:try_start_87a .. :try_end_88c} :catch_8b4

    move-object/from16 v16, v2

    :try_start_88e
    invoke-virtual {v1, v3}, Lcom/github/catvod/spider/XYQHiker;->ހ(Ljava/lang/String;)Ljava/util/HashMap;

    move-result-object v2

    invoke-virtual {v1, v4, v6, v2}, Lcom/github/catvod/spider/XYQHiker;->Ԭ(Ljava/lang/String;Ljava/lang/String;Ljava/util/Map;)Ljava/lang/String;

    move-result-object v2

    .line 149
    invoke-virtual {v2, v14}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v2
    :try_end_89a
    .catch Ljava/lang/Exception; {:try_start_88e .. :try_end_89a} :catch_8a6

    move/from16 v31, v2

    move-object/from16 v2, v16

    const/16 v27, 0x0

    const/16 v29, 0x0

    const/16 v30, 0x0

    goto/16 :goto_9c1

    :catch_8a6
    move-exception v0

    goto :goto_8b7

    :cond_8a8
    move-object/from16 v16, v2

    const/16 v27, 0x0

    const/16 v29, 0x0

    const/16 v30, 0x0

    const/16 v31, 0x0

    goto/16 :goto_9c1

    :catch_8b4
    move-exception v0

    move-object/from16 v16, v2

    :goto_8b7
    move-object v2, v0

    goto/16 :goto_9e0

    .line 150
    :cond_8ba
    :try_start_8ba
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, "5D3127302E2D116D233D3B3D17307C"

    invoke-static {v4}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v4, "5C2820"

    invoke-static {v4}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v3, v2}, Lcom/github/catvod/spider/xbpqxyq/xyq/ވ;->Ԫ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    .line 151
    iget-object v4, v1, Lcom/github/catvod/spider/XYQHiker;->ހ:Ljava/lang/String;

    invoke-virtual {v1, v3}, Lcom/github/catvod/spider/XYQHiker;->ހ(Ljava/lang/String;)Ljava/util/HashMap;

    move-result-object v6

    invoke-virtual {v1, v2, v4, v6}, Lcom/github/catvod/spider/XYQHiker;->Ԭ(Ljava/lang/String;Ljava/lang/String;Ljava/util/Map;)Ljava/lang/String;

    move-result-object v2

    .line 152
    invoke-virtual {v2, v13}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v4
    :try_end_8ea
    .catch Ljava/lang/Exception; {:try_start_8ba .. :try_end_8ea} :catch_993

    .line 153
    :try_start_8ea
    invoke-virtual {v2, v14}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v6
    :try_end_8ee
    .catch Ljava/lang/Exception; {:try_start_8ea .. :try_end_8ee} :catch_98e

    move/from16 v27, v4

    :try_start_8f0
    const-string v4, "54363A2536214F"

    invoke-static {v4}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    .line 154
    invoke-virtual {v2, v4}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v4
    :try_end_8fa
    .catch Ljava/lang/Exception; {:try_start_8f0 .. :try_end_8fa} :catch_985

    if-eqz v4, :cond_910

    :try_start_8fc
    const-string v4, "1A373E3367"

    invoke-static {v4}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v2, v4}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v4
    :try_end_906
    .catch Ljava/lang/Exception; {:try_start_8fc .. :try_end_906} :catch_90b

    if-eqz v4, :cond_910

    const/16 v29, 0x1

    goto :goto_912

    :catch_90b
    move-exception v0

    move-object v2, v0

    move/from16 v31, v6

    goto :goto_989

    :cond_910
    const/16 v29, 0x0

    :goto_912
    :try_start_912
    const-string v4, "162D302437211C367D2533301E277D222A281B36"

    invoke-static {v4}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    .line 155
    invoke-virtual {v2, v4}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    .line 156
    invoke-virtual {v2, v8}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v4
    :try_end_91f
    .catch Ljava/lang/Exception; {:try_start_912 .. :try_end_91f} :catch_980

    move/from16 v30, v4

    :try_start_921
    const-string v4, "0130306C782C063623"

    invoke-static {v4}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    .line 157
    invoke-virtual {v2, v4}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v4

    if-eqz v4, :cond_953

    const-string v4, "0130306C78"

    invoke-static {v4}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4
    :try_end_933
    .catch Ljava/lang/Exception; {:try_start_921 .. :try_end_933} :catch_97b

    move/from16 v31, v6

    :try_start_935
    const-string v6, "50"

    invoke-static {v6}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    .line 158
    invoke-static {v2, v4, v6}, Lcom/github/catvod/spider/xbpqxyq/xyq/ވ;->އ(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/util/ArrayList;

    move-result-object v2

    const/4 v4, 0x0

    invoke-virtual {v2, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/String;

    const-string v6, "55"

    invoke-static {v6}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v2, v6}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v2

    aget-object v2, v2, v4

    goto :goto_9c1

    :cond_953
    move/from16 v31, v6

    const-string v4, "0130306C786359"

    invoke-static {v4}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    .line 159
    invoke-virtual {v2, v4}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v4

    if-eqz v4, :cond_9c0

    const-string v4, "5965"

    invoke-static {v4}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    const-string v6, "5569"

    invoke-static {v6}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    .line 160
    invoke-static {v2, v4, v6}, Lcom/github/catvod/spider/xbpqxyq/xyq/ވ;->އ(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/util/ArrayList;

    move-result-object v2

    const/4 v4, 0x0

    invoke-virtual {v2, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/String;
    :try_end_978
    .catch Ljava/lang/Exception; {:try_start_935 .. :try_end_978} :catch_979

    goto :goto_9c1

    :catch_979
    move-exception v0

    goto :goto_97e

    :catch_97b
    move-exception v0

    move/from16 v31, v6

    :goto_97e
    move-object v2, v0

    goto :goto_99d

    :catch_980
    move-exception v0

    move/from16 v31, v6

    move-object v2, v0

    goto :goto_98b

    :catch_985
    move-exception v0

    move/from16 v31, v6

    move-object v2, v0

    :goto_989
    const/16 v29, 0x0

    :goto_98b
    const/16 v30, 0x0

    goto :goto_99d

    :catch_98e
    move-exception v0

    move/from16 v27, v4

    move-object v2, v0

    goto :goto_997

    :catch_993
    move-exception v0

    move-object v2, v0

    const/16 v27, 0x0

    :goto_997
    const/16 v29, 0x0

    const/16 v30, 0x0

    const/16 v31, 0x0

    .line 161
    :goto_99d
    :try_start_99d
    invoke-static {v2}, Lcom/github/catvod/crawler/SpiderDebug;->log(Ljava/lang/Throwable;)V

    .line 162
    iget-boolean v4, v1, Lcom/github/catvod/spider/XYQHiker;->ވ:Z

    if-eqz v4, :cond_9c0

    .line 163
    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const-string v6, "97CAD5B7C4D4022E32283F365D24213E37221E23347F303794D4D4B5E1F297C5E9B8CEDD9DFEC9"

    invoke-static {v6}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v4, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/Exception;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Lcom/github/catvod/spider/Init;->show(Ljava/lang/String;)V
    :try_end_9c0
    .catch Ljava/lang/Exception; {:try_start_99d .. :try_end_9c0} :catch_9d3

    :cond_9c0
    const/4 v2, 0x0

    :goto_9c1
    if-eqz v2, :cond_a19

    .line 164
    :try_start_9c3
    invoke-virtual {v2}, Ljava/lang/String;->isEmpty()Z

    move-result v4

    if-nez v4, :cond_a19

    .line 165
    invoke-static {v3, v2}, Lcom/github/catvod/spider/xbpqxyq/xyq/ވ;->Ԫ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2
    :try_end_9cd
    .catch Ljava/lang/Exception; {:try_start_9c3 .. :try_end_9cd} :catch_9ce

    goto :goto_a19

    :catch_9ce
    move-exception v0

    move-object/from16 v16, v2

    move-object v2, v0

    goto :goto_9e8

    :catch_9d3
    move-exception v0

    move-object v2, v0

    const/16 v16, 0x0

    goto :goto_9e8

    :catch_9d8
    move-exception v0

    goto :goto_9dd

    :catch_9da
    move-exception v0

    move-object/from16 v26, v2

    :goto_9dd
    move-object v2, v0

    const/16 v16, 0x0

    :goto_9e0
    const/16 v27, 0x0

    const/16 v29, 0x0

    const/16 v30, 0x0

    const/16 v31, 0x0

    .line 166
    :goto_9e8
    :try_start_9e8
    invoke-static {v2}, Lcom/github/catvod/crawler/SpiderDebug;->log(Ljava/lang/Throwable;)V

    .line 167
    iget-boolean v4, v1, Lcom/github/catvod/spider/XYQHiker;->ވ:Z

    if-eqz v4, :cond_a0b

    .line 168
    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const-string v6, "97CAD5B7C4D4022E32283F36112D3D37332397CEE9B4C5DB97C5E9B8CEDD9DFEC9"

    invoke-static {v6}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v4, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/Exception;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Lcom/github/catvod/spider/Init;->show(Ljava/lang/String;)V
    :try_end_a0b
    .catch Ljava/lang/Exception; {:try_start_9e8 .. :try_end_a0b} :catch_a52

    :cond_a0b
    move-object/from16 v2, v16

    goto :goto_a19

    :cond_a0e
    move-object/from16 v26, v2

    :cond_a10
    const/4 v2, 0x0

    const/16 v27, 0x0

    const/16 v29, 0x0

    const/16 v30, 0x0

    const/16 v31, 0x0

    :cond_a19
    :goto_a19
    if-eqz v5, :cond_cbc

    .line 169
    :try_start_a1b
    invoke-static {v5}, Lcom/github/catvod/spider/xbpqxyq/xyq/ކ;->Ԭ(Ljava/lang/String;)Z

    move-result v4
    :try_end_a1f
    .catch Ljava/lang/Exception; {:try_start_a1b .. :try_end_a1f} :catch_cb8

    if-eqz v4, :cond_a58

    move-object/from16 v4, v18

    :try_start_a23
    invoke-direct {v1, v4}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v6, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v6

    if-nez v6, :cond_a3d

    invoke-direct {v1, v4}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    const-string v3, "94DAFC"

    invoke-static {v3}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v6, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_a5a

    :cond_a3d
    const/4 v2, 0x1

    .line 170
    invoke-virtual {v11, v12, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    const-string v2, "183A"

    invoke-static {v2}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    .line 171
    invoke-virtual {v11, v2, v7}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 172
    invoke-virtual {v11, v15, v5}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 173
    invoke-virtual {v11}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object v2
    :try_end_a51
    .catch Ljava/lang/Exception; {:try_start_a23 .. :try_end_a51} :catch_a52

    return-object v2

    :catch_a52
    move-exception v0

    move-object v2, v0

    move-object/from16 v3, v19

    goto/16 :goto_ce9

    :cond_a58
    move-object/from16 v4, v18

    .line 174
    :cond_a5a
    :try_start_a5a
    invoke-static {v5}, Lcom/github/catvod/spider/xbpqxyq/xyq/ކ;->ԫ(Ljava/lang/String;)Z

    move-result v3

    if-nez v3, :cond_bb3

    const-string v3, "5D382B2B301B"

    invoke-static {v3}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v5, v3}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v3

    if-eqz v3, :cond_a6e

    goto/16 :goto_bb3

    :cond_a6e
    if-eqz v2, :cond_ba9

    .line 175
    invoke-direct {v1, v4}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    move-object/from16 v4, v17

    invoke-virtual {v3, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3
    :try_end_a7a
    .catch Ljava/lang/Exception; {:try_start_a5a .. :try_end_a7a} :catch_cb8

    if-eqz v3, :cond_ba9

    if-nez v9, :cond_a8f

    .line 176
    :try_start_a7e
    invoke-virtual {v9}, Ljava/lang/String;->isEmpty()Z

    move-result v3

    if-nez v3, :cond_b4a

    goto :goto_a8f

    :catch_a85
    move-exception v0

    move-object v2, v0

    move-object/from16 v3, v19

    move-object/from16 v6, v20

    move-object/from16 v4, v21

    goto/16 :goto_b85

    :cond_a8f
    :goto_a8f
    if-eqz v29, :cond_ae4

    .line 177
    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v4, "54363A2536214F"

    invoke-static {v4}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-object/from16 v4, v26

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v4, "59"

    invoke-static {v4}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-object/from16 v4, v25

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v4, "54363B2437264F"

    invoke-static {v4}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-object/from16 v4, v24

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v4, "542B376C"

    invoke-static {v4}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-object/from16 v4, v23

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-object/from16 v6, v28

    invoke-virtual {v3, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    goto :goto_b4a

    :cond_ae4
    move-object/from16 v4, v23

    move-object/from16 v6, v28

    if-eqz v27, :cond_afd

    .line 178
    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    goto :goto_b4a

    :cond_afd
    if-eqz v30, :cond_b30

    .line 179
    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v5, "542B376C"

    invoke-static {v5}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v4, "5424213E3779"

    invoke-static {v4}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5
    :try_end_b2f
    .catch Ljava/lang/Exception; {:try_start_a7e .. :try_end_b2f} :catch_a85

    goto :goto_b4a

    .line 180
    :cond_b30
    :try_start_b30
    invoke-virtual {v5, v14}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v3
    :try_end_b34
    .catch Ljava/lang/Exception; {:try_start_b30 .. :try_end_b34} :catch_b7d

    if-nez v3, :cond_b4a

    if-eqz v31, :cond_b4a

    .line 181
    :try_start_b38
    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5
    :try_end_b4a
    .catch Ljava/lang/Exception; {:try_start_b38 .. :try_end_b4a} :catch_a85

    .line 182
    :cond_b4a
    :goto_b4a
    :try_start_b4a
    invoke-virtual/range {v22 .. v22}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object v3
    :try_end_b4e
    .catch Ljava/lang/Exception; {:try_start_b4a .. :try_end_b4e} :catch_b7d

    move-object/from16 v4, v21

    :try_start_b50
    invoke-virtual {v11, v4, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v3, 0x1

    .line 183
    invoke-virtual {v11, v12, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;
    :try_end_b57
    .catch Ljava/lang/Exception; {:try_start_b50 .. :try_end_b57} :catch_b77

    move-object/from16 v3, v19

    move-object/from16 v6, v20

    .line 184
    :try_start_b5b
    invoke-virtual {v11, v6, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 185
    new-instance v7, Ljava/lang/StringBuilder;

    invoke-direct {v7}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v7, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v7, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v11, v15, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 186
    invoke-virtual {v11}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object v2
    :try_end_b74
    .catch Ljava/lang/Exception; {:try_start_b5b .. :try_end_b74} :catch_b75

    return-object v2

    :catch_b75
    move-exception v0

    goto :goto_b84

    :catch_b77
    move-exception v0

    move-object/from16 v3, v19

    move-object/from16 v6, v20

    goto :goto_b84

    :catch_b7d
    move-exception v0

    move-object/from16 v3, v19

    move-object/from16 v6, v20

    move-object/from16 v4, v21

    :goto_b84
    move-object v2, v0

    .line 187
    :goto_b85
    :try_start_b85
    invoke-static {v2}, Lcom/github/catvod/crawler/SpiderDebug;->log(Ljava/lang/Throwable;)V

    .line 188
    iget-boolean v5, v1, Lcom/github/catvod/spider/XYQHiker;->ވ:Z

    if-eqz v5, :cond_baf

    .line 189
    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    const-string v7, "3F2330B4D2C294DCC363BCD6DFA4C7EFBFC8C8A7CCCEBFC3C8ABC7C8B5F8E8"

    invoke-static {v7}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v5, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/Exception;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v5, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Lcom/github/catvod/spider/Init;->show(Ljava/lang/String;)V
    :try_end_ba8
    .catch Ljava/lang/Exception; {:try_start_b85 .. :try_end_ba8} :catch_ce4

    goto :goto_baf

    :cond_ba9
    move-object/from16 v3, v19

    move-object/from16 v6, v20

    move-object/from16 v4, v21

    :cond_baf
    :goto_baf
    move-object/from16 v7, p2

    goto/16 :goto_cc3

    :cond_bb3
    :goto_bb3
    move-object/from16 v3, v19

    move-object/from16 v6, v20

    move-object/from16 v4, v21

    :try_start_bb9
    const-string v2, "5D382B2B301B"

    invoke-static {v2}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    .line 190
    invoke-virtual {v5, v2}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v2

    if-eqz v2, :cond_c76

    .line 191
    iget-object v2, v1, Lcom/github/catvod/spider/XYQHiker;->ހ:Ljava/lang/String;
    :try_end_bc7
    .catch Ljava/lang/Exception; {:try_start_bb9 .. :try_end_bc7} :catch_c90

    move-object/from16 v7, p2

    :try_start_bc9
    invoke-virtual {v1, v7}, Lcom/github/catvod/spider/XYQHiker;->ހ(Ljava/lang/String;)Ljava/util/HashMap;

    move-result-object v8

    invoke-virtual {v1, v5, v2, v8}, Lcom/github/catvod/spider/XYQHiker;->Ԭ(Ljava/lang/String;Ljava/lang/String;Ljava/util/Map;)Ljava/lang/String;

    move-result-object v2

    const-string v5, "042321712F361E626E717D"

    invoke-static {v5}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    const-string v8, "55"

    invoke-static {v8}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    .line 192
    invoke-static {v2, v5, v8}, Lcom/github/catvod/spider/xbpqxyq/xyq/ވ;->އ(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/util/ArrayList;

    move-result-object v2

    const/4 v5, 0x0

    invoke-virtual {v2, v5}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/String;

    .line 193
    new-instance v5, Ljava/lang/StringBuffer;

    invoke-direct {v5, v2}, Ljava/lang/StringBuffer;-><init>(Ljava/lang/String;)V

    invoke-virtual {v5}, Ljava/lang/StringBuffer;->reverse()Ljava/lang/StringBuffer;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/String;->toCharArray()[C

    move-result-object v2

    move-object v8, v3

    const/4 v5, 0x0

    .line 194
    :goto_bfb
    array-length v9, v2

    if-ge v5, v9, :cond_c26

    .line 195
    new-instance v9, Ljava/lang/StringBuilder;

    invoke-direct {v9}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v9, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v8, "2E376361"

    invoke-static {v8}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v9, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    aget-char v8, v2, v5

    invoke-virtual {v9, v8}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    add-int/lit8 v8, v5, 0x1

    aget-char v8, v2, v8

    invoke-static {v8}, Ljava/lang/Character;->toString(C)Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v9, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v9}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v8

    add-int/lit8 v5, v5, 0x2

    goto :goto_bfb

    .line 196
    :cond_c26
    invoke-static {v8}, Lcom/github/catvod/spider/xbpqxyq/xyq/ވ;->ވ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/String;->length()I

    move-result v2
    :try_end_c2e
    .catch Ljava/lang/Exception; {:try_start_bc9 .. :try_end_c2e} :catch_c8e

    add-int/lit8 v2, v2, -0x6

    int-to-double v9, v2

    const-wide/high16 v13, 0x4000000000000000L  # 2.0

    invoke-static {v9, v10}, Ljava/lang/Double;->isNaN(D)Z

    div-double/2addr v9, v13

    :try_start_c37
    invoke-static {v9, v10}, Ljava/lang/Math;->ceil(D)D

    move-result-wide v9

    double-to-int v2, v9

    .line 197
    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    invoke-static {v8}, Lcom/github/catvod/spider/xbpqxyq/xyq/ވ;->ވ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    add-int/lit8 v10, v2, -0x1

    const/4 v13, 0x0

    invoke-virtual {v9, v13, v10}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v5, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static {v8}, Lcom/github/catvod/spider/xbpqxyq/xyq/ވ;->ވ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    add-int/lit8 v2, v2, 0x6

    invoke-virtual {v8, v2}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v5, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const/4 v5, 0x0

    .line 198
    invoke-virtual {v11, v12, v5}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    .line 199
    invoke-virtual {v11, v6, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 200
    invoke-virtual {v11, v15, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 201
    invoke-virtual/range {v22 .. v22}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v11, v4, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 202
    invoke-virtual {v11}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object v2

    return-object v2

    :cond_c76
    move-object/from16 v7, p2

    const/4 v2, 0x0

    .line 203
    invoke-virtual {v11, v12, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    .line 204
    invoke-virtual {v11, v6, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 205
    invoke-virtual {v11, v15, v5}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 206
    invoke-virtual/range {v22 .. v22}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v11, v4, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 207
    invoke-virtual {v11}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object v2
    :try_end_c8d
    .catch Ljava/lang/Exception; {:try_start_c37 .. :try_end_c8d} :catch_c8e

    return-object v2

    :catch_c8e
    move-exception v0

    goto :goto_c93

    :catch_c90
    move-exception v0

    move-object/from16 v7, p2

    :goto_c93
    move-object v2, v0

    .line 208
    :try_start_c94
    invoke-static {v2}, Lcom/github/catvod/crawler/SpiderDebug;->log(Ljava/lang/Throwable;)V

    .line 209
    iget-boolean v5, v1, Lcom/github/catvod/spider/XYQHiker;->ވ:Z

    if-eqz v5, :cond_cc3

    .line 210
    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    const-string v8, "95D9E7B8C9FA9AE5D5B8F8D596FADD2B223E18ABD0F9BFCCF4A7D4EBB3D0EBADEFCB"

    invoke-static {v8}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v5, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/Exception;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v5, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Lcom/github/catvod/spider/Init;->show(Ljava/lang/String;)V

    goto :goto_cc3

    :catch_cb8
    move-exception v0

    move-object/from16 v3, v19

    goto :goto_ce8

    :cond_cbc
    move-object v7, v3

    move-object/from16 v3, v19

    move-object/from16 v6, v20

    move-object/from16 v4, v21

    .line 211
    :cond_cc3
    :goto_cc3
    invoke-virtual/range {v22 .. v22}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v11, v4, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v2, 0x1

    .line 212
    invoke-virtual {v11, v12, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    .line 213
    invoke-virtual {v11, v6, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 214
    invoke-virtual {v11, v15, v7}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 215
    invoke-virtual {v11}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object v2

    return-object v2

    :cond_cd9
    :goto_cd9
    move-object v7, v3

    move-object v3, v8

    .line 216
    iget-object v4, v1, Lcom/github/catvod/spider/XYQHiker;->֏:Lcom/github/catvod/spider/XYQPushAgent;

    move-object/from16 v5, p3

    invoke-virtual {v4, v2, v7, v5}, Lcom/github/catvod/spider/XYQPushAgent;->playerContent(Ljava/lang/String;Ljava/lang/String;Ljava/util/List;)Ljava/lang/String;

    move-result-object v2
    :try_end_ce3
    .catch Ljava/lang/Exception; {:try_start_c94 .. :try_end_ce3} :catch_ce4

    return-object v2

    :catch_ce4
    move-exception v0

    goto :goto_ce8

    :catch_ce6
    move-exception v0

    move-object v3, v8

    :goto_ce8
    move-object v2, v0

    .line 217
    :goto_ce9
    invoke-static {v2}, Lcom/github/catvod/crawler/SpiderDebug;->log(Ljava/lang/Throwable;)V

    .line 218
    iget-boolean v4, v1, Lcom/github/catvod/spider/XYQHiker;->ވ:Z

    if-eqz v4, :cond_d0c

    .line 219
    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const-string v5, "94D0FEB7CEFA95F3E8B4DFEC97F3D3B4D6FE97DDCCB4DDFE9BD6CABEE6DE"

    invoke-static {v5}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/Exception;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Lcom/github/catvod/spider/Init;->show(Ljava/lang/String;)V

    :cond_d0c
    return-object v3
.end method

.method public searchContent(Ljava/lang/String;Z)Ljava/lang/String;
    .registers 3

    const-string p2, "43"

    invoke-static {p2}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p2

    .line 1
    invoke-direct {p0, p1, p2}, Lcom/github/catvod/spider/XYQHiker;->ފ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    return-object p1
.end method

.method public searchContent(Ljava/lang/String;ZLjava/lang/String;)Ljava/lang/String;
    .registers 4

    .line 2
    invoke-direct {p0, p1, p3}, Lcom/github/catvod/spider/XYQHiker;->ފ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    return-object p1
.end method

.method protected Ϳ(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/util/Map;)Ljava/lang/String;
    .registers 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;)",
            "Ljava/lang/String;"
        }
    .end annotation

    .line 1
    :try_start_0
    invoke-static {p1}, Lcom/github/catvod/crawler/SpiderDebug;->log(Ljava/lang/String;)V

    .line 2
    new-instance v0, Lcom/github/catvod/spider/XYQHiker$3;

    invoke-direct {v0, p0}, Lcom/github/catvod/spider/XYQHiker$3;-><init>(Lcom/github/catvod/spider/XYQHiker;)V

    .line 3
    invoke-static {}, Lcom/github/catvod/spider/xbpqxyq/xyq/ތ;->ԩ()Lokhttp3/OkHttpClient;

    move-result-object v1

    invoke-static {v1, p1, p2, p4, v0}, Lcom/github/catvod/spider/xbpqxyq/xyq/ތ;->Ԯ(Lokhttp3/OkHttpClient;Ljava/lang/String;Ljava/lang/String;Ljava/util/Map;Lcom/github/catvod/spider/xbpqxyq/xyq/ފ;)V

    .line 4
    invoke-virtual {v0}, Lcom/github/catvod/spider/xbpqxyq/xyq/ފ;->getResult()Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lokhttp3/Response;

    invoke-virtual {p1}, Lokhttp3/Response;->body()Lokhttp3/ResponseBody;

    move-result-object p1

    invoke-virtual {p1}, Lokhttp3/ResponseBody;->bytes()[B

    move-result-object p1

    .line 5
    new-instance p2, Ljava/lang/String;

    invoke-direct {p2, p1, p3}, Ljava/lang/String;-><init>([BLjava/lang/String;)V

    const-string p1, "7F3E59"

    invoke-static {p1}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const-string p3, ""

    .line 6
    invoke-virtual {p2, p1, p3}, Ljava/lang/String;->replaceAll(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1
    :try_end_2e
    .catchall {:try_start_0 .. :try_end_2e} :catchall_2f

    return-object p1

    :catchall_2f
    move-exception p1

    .line 7
    invoke-virtual {p1}, Ljava/lang/Throwable;->printStackTrace()V

    const/4 p1, 0x0

    return-object p1
.end method

.method protected Ԭ(Ljava/lang/String;Ljava/lang/String;Ljava/util/Map;)Ljava/lang/String;
    .registers 8
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;)",
            "Ljava/lang/String;"
        }
    .end annotation

    const-string v0, "112E323F606B5D"

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v1, 0x0

    .line 1
    :try_start_7
    invoke-static {p1}, Lcom/github/catvod/crawler/SpiderDebug;->log(Ljava/lang/String;)V

    .line 2
    new-instance v2, Lcom/github/catvod/spider/XYQHiker$1;

    invoke-direct {v2, p0}, Lcom/github/catvod/spider/XYQHiker$1;-><init>(Lcom/github/catvod/spider/XYQHiker;)V

    .line 3
    invoke-virtual {p1, v0}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v3

    if-eqz v3, :cond_32

    .line 4
    invoke-static {}, Lcom/github/catvod/spider/XYQProxy;->localProxyUrl()Ljava/lang/String;

    move-result-object p2

    const-string p3, "5D32213E223D"

    invoke-static {p3}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p3

    const-string v2, "5D243A3D3F6B"

    invoke-static {v2}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {p2, p3, v2}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object p2

    invoke-virtual {p1, v0, p2}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object p1

    .line 5
    invoke-static {p1, v1}, Lcom/github/catvod/spider/xbpqxyq/xyq/ތ;->֏(Ljava/lang/String;Ljava/util/Map;)Ljava/lang/String;

    move-result-object p1

    return-object p1

    .line 6
    :cond_32
    invoke-static {}, Lcom/github/catvod/spider/xbpqxyq/xyq/ތ;->ԩ()Lokhttp3/OkHttpClient;

    move-result-object v0

    invoke-static {v0, p1, v1, p3, v2}, Lcom/github/catvod/spider/xbpqxyq/xyq/ތ;->Ԫ(Lokhttp3/OkHttpClient;Ljava/lang/String;Ljava/util/Map;Ljava/util/Map;Lcom/github/catvod/spider/xbpqxyq/xyq/ފ;)V

    .line 7
    invoke-virtual {v2}, Lcom/github/catvod/spider/xbpqxyq/xyq/ފ;->getResult()Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lokhttp3/Response;

    invoke-virtual {p1}, Lokhttp3/Response;->body()Lokhttp3/ResponseBody;

    move-result-object p1

    invoke-virtual {p1}, Lokhttp3/ResponseBody;->bytes()[B

    move-result-object p1

    .line 8
    new-instance p3, Ljava/lang/String;

    invoke-direct {p3, p1, p2}, Ljava/lang/String;-><init>([BLjava/lang/String;)V

    const-string p1, "7F3E59"

    invoke-static {p1}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const-string p2, ""

    .line 9
    invoke-virtual {p3, p1, p2}, Ljava/lang/String;->replaceAll(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1
    :try_end_58
    .catchall {:try_start_7 .. :try_end_58} :catchall_59

    return-object p1

    :catchall_59
    move-exception p1

    .line 10
    invoke-virtual {p1}, Ljava/lang/Throwable;->printStackTrace()V

    return-object v1
.end method

.method protected ԭ(Ljava/lang/String;Ljava/util/Map;Ljava/lang/String;Ljava/util/Map;)Ljava/lang/String;
    .registers 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;",
            "Ljava/lang/String;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;)",
            "Ljava/lang/String;"
        }
    .end annotation

    .line 1
    :try_start_0
    invoke-static {p1}, Lcom/github/catvod/crawler/SpiderDebug;->log(Ljava/lang/String;)V

    .line 2
    new-instance v0, Lcom/github/catvod/spider/XYQHiker$2;

    invoke-direct {v0, p0}, Lcom/github/catvod/spider/XYQHiker$2;-><init>(Lcom/github/catvod/spider/XYQHiker;)V

    .line 3
    invoke-static {}, Lcom/github/catvod/spider/xbpqxyq/xyq/ތ;->ԩ()Lokhttp3/OkHttpClient;

    move-result-object v1

    invoke-static {v1, p1, p2, p4, v0}, Lcom/github/catvod/spider/xbpqxyq/xyq/ތ;->ԭ(Lokhttp3/OkHttpClient;Ljava/lang/String;Ljava/util/Map;Ljava/util/Map;Lcom/github/catvod/spider/xbpqxyq/xyq/ފ;)V

    .line 4
    invoke-virtual {v0}, Lcom/github/catvod/spider/xbpqxyq/xyq/ފ;->getResult()Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lokhttp3/Response;

    invoke-virtual {p1}, Lokhttp3/Response;->body()Lokhttp3/ResponseBody;

    move-result-object p1

    invoke-virtual {p1}, Lokhttp3/ResponseBody;->bytes()[B

    move-result-object p1

    .line 5
    new-instance p2, Ljava/lang/String;

    invoke-direct {p2, p1, p3}, Ljava/lang/String;-><init>([BLjava/lang/String;)V

    const-string p1, "7F3E59"

    invoke-static {p1}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const-string p3, ""

    .line 6
    invoke-virtual {p2, p1, p3}, Ljava/lang/String;->replaceAll(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1
    :try_end_2e
    .catchall {:try_start_0 .. :try_end_2e} :catchall_2f

    return-object p1

    :catchall_2f
    move-exception p1

    .line 7
    invoke-virtual {p1}, Ljava/lang/Throwable;->printStackTrace()V

    const/4 p1, 0x0

    return-object p1
.end method

.method protected Ԯ()V
    .registers 5

    const-string v0, "42"

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const-string v1, "360711041D"

    invoke-static {v1}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    .line 1
    iget-object v2, p0, Lcom/github/catvod/spider/XYQHiker;->ކ:Lorg/json/JSONObject;

    if-nez v2, :cond_70

    .line 2
    iget-object v2, p0, Lcom/github/catvod/spider/XYQHiker;->ޅ:Ljava/lang/String;

    if-eqz v2, :cond_70

    :try_start_14
    const-string v3, "1A362721"

    invoke-static {v3}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    .line 3
    invoke-virtual {v2, v3}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_2f

    .line 4
    iget-object v2, p0, Lcom/github/catvod/spider/XYQHiker;->ޅ:Ljava/lang/String;

    const/4 v3, 0x0

    invoke-static {v2, v3}, Lcom/github/catvod/spider/xbpqxyq/xyq/ތ;->֏(Ljava/lang/String;Ljava/util/Map;)Ljava/lang/String;

    move-result-object v2

    .line 5
    new-instance v3, Lorg/json/JSONObject;

    invoke-direct {v3, v2}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    iput-object v3, p0, Lcom/github/catvod/spider/XYQHiker;->ކ:Lorg/json/JSONObject;

    goto :goto_38

    .line 6
    :cond_2f
    new-instance v2, Lorg/json/JSONObject;

    iget-object v3, p0, Lcom/github/catvod/spider/XYQHiker;->ޅ:Ljava/lang/String;

    invoke-direct {v2, v3}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    iput-object v2, p0, Lcom/github/catvod/spider/XYQHiker;->ކ:Lorg/json/JSONObject;

    :goto_38
    const-string v2, "3D01010E1B143B"

    invoke-static {v2}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    const-string v3, "1A362721297E5D6D37353E201D21217C77281B2C36303D2106367D233F341E6C303E752B11307C336C705D3636292E"

    invoke-static {v3}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    .line 7
    invoke-direct {p0, v2, v3}, Lcom/github/catvod/spider/XYQHiker;->ރ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    iput-object v2, p0, Lcom/github/catvod/spider/XYQHiker;->އ:Ljava/lang/String;

    .line 8
    invoke-direct {p0, v1, v0}, Lcom/github/catvod/spider/XYQHiker;->ރ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    const-string v3, "94DAFC"

    invoke-static {v3}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_6d

    invoke-direct {p0, v1, v0}, Lcom/github/catvod/spider/XYQHiker;->ރ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const-string v1, "43"

    invoke-static {v1}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_6b

    goto :goto_6d

    :cond_6b
    const/4 v0, 0x0

    goto :goto_6e

    :cond_6d
    :goto_6d
    const/4 v0, 0x1

    :goto_6e
    iput-boolean v0, p0, Lcom/github/catvod/spider/XYQHiker;->ވ:Z
    :try_end_70
    .catch Lorg/json/JSONException; {:try_start_14 .. :try_end_70} :catch_70

    :catch_70
    :cond_70
    return-void
.end method

.method protected ԯ(Ljava/lang/String;Ljava/lang/String;Z)Ljava/lang/String;
    .registers 5

    .line 1
    :try_start_0
    iget-object p3, p0, Lcom/github/catvod/spider/XYQHiker;->ރ:Lorg/json/JSONObject;

    const-string v0, "00273534282100"

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p3, v0, p2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 2
    new-instance p2, Ljava/lang/StringBuilder;

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p3, "320A36303E2100316E"

    invoke-static {p3}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p3

    invoke-virtual {p2, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object p3, p0, Lcom/github/catvod/spider/XYQHiker;->ރ:Lorg/json/JSONObject;

    invoke-virtual {p3}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object p3

    invoke-virtual {p2, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1
    :try_end_29
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_29} :catch_2a

    return-object p1

    :catch_2a
    move-exception p2

    .line 3
    invoke-static {p2}, Lcom/github/catvod/crawler/SpiderDebug;->log(Ljava/lang/Throwable;)V

    return-object p1
.end method

.method protected ހ(Ljava/lang/String;)Ljava/util/HashMap;
    .registers 24
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            ")",
            "Ljava/util/HashMap<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    move-object/from16 v0, p0

    .line 1
    new-instance v1, Ljava/util/HashMap;

    invoke-direct {v1}, Ljava/util/HashMap;-><init>()V

    const-string v2, "9AEDE4B7EBC697E6E7B4D5C694D7E3"

    invoke-static {v2}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    .line 2
    invoke-direct {v0, v2}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/String;->isEmpty()Z

    move-result v3

    if-nez v3, :cond_18

    goto :goto_1e

    :cond_18
    const-string v2, "3A2732353F3601"

    invoke-static {v2}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    :goto_1e
    const-string v3, ""

    .line 3
    invoke-direct {v0, v2, v3}, Lcom/github/catvod/spider/XYQHiker;->ރ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v2

    const-string v4, "56"

    invoke-static {v4}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    .line 4
    invoke-virtual {v2, v4}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v4

    const-string v5, "9AC9EAB7C4D895D6E6B9DED5"

    invoke-static {v5}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    const-string v6, "3F03100E0F05"

    invoke-static {v6}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    const-string v7, "9AC9EAB7C4D894CBD8B7C6FE"

    invoke-static {v7}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    const-string v8, "3B0D000E0F05"

    invoke-static {v8}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    const-string v9, "312D3C3A3321"

    invoke-static {v9}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    const-string v10, "94CBD8B7C6FE"

    invoke-static {v10}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    const-string v11, "3F0D111816012D1712"

    invoke-static {v11}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v11

    const-string v12, "95D6E6B9DED5"

    invoke-static {v12}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v12

    const-string v13, "22010C041B"

    invoke-static {v13}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v13

    const-string v14, "07313623772515273D25"

    invoke-static {v14}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v14

    const-string v15, "49"

    invoke-static {v15}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v15

    move-object/from16 p1, v3

    if-eqz v4, :cond_1fe

    const-string v4, "51"

    invoke-static {v4}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    .line 5
    invoke-virtual {v2, v4}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v4

    const/16 v16, 0x0

    move-object/from16 v18, v9

    const/4 v3, 0x0

    .line 6
    :goto_87
    array-length v9, v4

    if-ge v3, v9, :cond_185

    .line 7
    aget-object v9, v4, v3

    move-object/from16 v19, v4

    const-string v4, "2E66"

    invoke-static {v4}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v9, v4}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v4

    .line 8
    aget-object v9, v4, v16

    const/16 v17, 0x1

    .line 9
    aget-object v4, v4, v17

    .line 10
    invoke-virtual {v4, v13}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v20

    if-nez v20, :cond_da

    invoke-virtual {v4, v12}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v20

    if-eqz v20, :cond_ab

    goto :goto_da

    .line 11
    :cond_ab
    invoke-virtual {v4, v11}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v20

    if-nez v20, :cond_d7

    invoke-virtual {v4, v10}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v20

    if-eqz v20, :cond_b8

    goto :goto_d7

    .line 12
    :cond_b8
    invoke-virtual {v4, v8}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v20

    if-nez v20, :cond_d4

    invoke-virtual {v4, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v20

    if-eqz v20, :cond_c5

    goto :goto_d4

    .line 13
    :cond_c5
    invoke-virtual {v4, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v20

    if-nez v20, :cond_d1

    invoke-virtual {v4, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v20

    if-eqz v20, :cond_dc

    .line 14
    :cond_d1
    sget-object v4, Lcom/github/catvod/spider/XYQHiker;->ԭ:Ljava/lang/String;

    goto :goto_dc

    .line 15
    :cond_d4
    :goto_d4
    sget-object v4, Lcom/github/catvod/spider/XYQHiker;->Ԭ:Ljava/lang/String;

    goto :goto_dc

    .line 16
    :cond_d7
    :goto_d7
    sget-object v4, Lcom/github/catvod/spider/XYQHiker;->ԫ:Ljava/lang/String;

    goto :goto_dc

    .line 17
    :cond_da
    :goto_da
    sget-object v4, Lcom/github/catvod/spider/XYQHiker;->Ԫ:Ljava/lang/String;

    :cond_dc
    :goto_dc
    move-object/from16 v20, v5

    .line 18
    iget-object v5, v0, Lcom/github/catvod/spider/XYQHiker;->ؠ:Ljava/lang/String;

    invoke-virtual {v5}, Ljava/lang/String;->isEmpty()Z

    move-result v5

    if-eqz v5, :cond_ee

    iget-object v5, v0, Lcom/github/catvod/spider/XYQHiker;->ށ:Ljava/lang/String;

    invoke-virtual {v5}, Ljava/lang/String;->isEmpty()Z

    move-result v5

    if-nez v5, :cond_149

    :cond_ee
    const-string v5, "112D3C3A3321"

    invoke-static {v5}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    .line 19
    invoke-virtual {v9, v5}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v5

    if-eqz v5, :cond_149

    .line 20
    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v5, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v4, v0, Lcom/github/catvod/spider/XYQHiker;->ؠ:Ljava/lang/String;

    invoke-virtual {v4}, Ljava/lang/String;->isEmpty()Z

    move-result v4

    if-nez v4, :cond_11e

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v4, v15}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-object/from16 v21, v6

    iget-object v6, v0, Lcom/github/catvod/spider/XYQHiker;->ؠ:Ljava/lang/String;

    invoke-virtual {v4, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    goto :goto_122

    :cond_11e
    move-object/from16 v21, v6

    move-object/from16 v4, p1

    :goto_122
    invoke-virtual {v5, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v4, v0, Lcom/github/catvod/spider/XYQHiker;->ށ:Ljava/lang/String;

    invoke-virtual {v4}, Ljava/lang/String;->isEmpty()Z

    move-result v4

    if-nez v4, :cond_13f

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v4, v15}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v6, v0, Lcom/github/catvod/spider/XYQHiker;->ށ:Ljava/lang/String;

    invoke-virtual {v4, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    goto :goto_141

    :cond_13f
    move-object/from16 v4, p1

    :goto_141
    invoke-virtual {v5, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    goto :goto_14b

    :cond_149
    move-object/from16 v21, v6

    .line 21
    :goto_14b
    invoke-virtual {v9, v14}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v5

    if-eqz v5, :cond_156

    .line 22
    iget-object v5, v0, Lcom/github/catvod/spider/XYQHiker;->ރ:Lorg/json/JSONObject;

    invoke-virtual {v5, v14, v4}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    :cond_156
    const-string v5, "00273534282100"

    invoke-static {v5}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    .line 23
    invoke-virtual {v9, v5}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v5

    const-string v6, "25273107332105"

    invoke-static {v6}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    if-nez v5, :cond_172

    invoke-virtual {v4, v6}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v5

    if-nez v5, :cond_172

    .line 24
    invoke-virtual {v1, v9, v4}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_17b

    .line 25
    :cond_172
    invoke-virtual {v4, v6}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v5

    if-nez v5, :cond_17b

    .line 26
    invoke-virtual {v1, v9, v4}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_17b
    :goto_17b
    add-int/lit8 v3, v3, 0x1

    move-object/from16 v4, v19

    move-object/from16 v5, v20

    move-object/from16 v6, v21

    goto/16 :goto_87

    .line 27
    :cond_185
    iget-object v3, v0, Lcom/github/catvod/spider/XYQHiker;->ؠ:Ljava/lang/String;

    invoke-virtual {v3}, Ljava/lang/String;->isEmpty()Z

    move-result v3

    if-eqz v3, :cond_195

    iget-object v3, v0, Lcom/github/catvod/spider/XYQHiker;->ށ:Ljava/lang/String;

    invoke-virtual {v3}, Ljava/lang/String;->isEmpty()Z

    move-result v3

    if-nez v3, :cond_2bc

    .line 28
    :cond_195
    iget-object v3, v0, Lcom/github/catvod/spider/XYQHiker;->ؠ:Ljava/lang/String;

    invoke-virtual {v3}, Ljava/lang/String;->length()I

    move-result v3

    const/4 v4, 0x1

    if-gt v3, v4, :cond_1a6

    iget-object v3, v0, Lcom/github/catvod/spider/XYQHiker;->ށ:Ljava/lang/String;

    invoke-virtual {v3}, Ljava/lang/String;->length()I

    move-result v3

    if-le v3, v4, :cond_2bc

    :cond_1a6
    const-string v3, "312D3C3A332156"

    invoke-static {v3}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v3

    if-nez v3, :cond_2bc

    const-string v3, "112D3C3A332156"

    invoke-static {v3}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v2

    if-nez v2, :cond_2bc

    .line 29
    iget-object v2, v0, Lcom/github/catvod/spider/XYQHiker;->ؠ:Ljava/lang/String;

    invoke-virtual {v2}, Ljava/lang/String;->isEmpty()Z

    move-result v2

    if-nez v2, :cond_1cb

    iget-object v2, v0, Lcom/github/catvod/spider/XYQHiker;->ށ:Ljava/lang/String;

    :goto_1c8
    move-object/from16 v3, v18

    goto :goto_1f9

    :cond_1cb
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v3, v0, Lcom/github/catvod/spider/XYQHiker;->ؠ:Ljava/lang/String;

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v3, v0, Lcom/github/catvod/spider/XYQHiker;->ށ:Ljava/lang/String;

    invoke-virtual {v3}, Ljava/lang/String;->isEmpty()Z

    move-result v3

    if-nez v3, :cond_1ef

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v3, v15}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v4, v0, Lcom/github/catvod/spider/XYQHiker;->ށ:Ljava/lang/String;

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    goto :goto_1f1

    :cond_1ef
    iget-object v3, v0, Lcom/github/catvod/spider/XYQHiker;->ށ:Ljava/lang/String;

    :goto_1f1
    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    goto :goto_1c8

    :goto_1f9
    invoke-virtual {v1, v3, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    goto/16 :goto_2bc

    :cond_1fe
    move-object/from16 v20, v5

    move-object/from16 v21, v6

    move-object v3, v9

    .line 30
    invoke-virtual {v2}, Ljava/lang/String;->isEmpty()Z

    move-result v4

    if-eqz v4, :cond_210

    const-string v2, "1D293B252E345D717D60686A4373"

    invoke-static {v2}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    goto :goto_252

    .line 31
    :cond_210
    invoke-virtual {v2, v13}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-nez v4, :cond_250

    invoke-virtual {v2, v12}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_21d

    goto :goto_250

    .line 32
    :cond_21d
    invoke-virtual {v2, v11}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-nez v4, :cond_24d

    invoke-virtual {v2, v10}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_22a

    goto :goto_24d

    .line 33
    :cond_22a
    invoke-virtual {v2, v8}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-nez v4, :cond_24a

    invoke-virtual {v2, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_237

    goto :goto_24a

    :cond_237
    move-object/from16 v4, v21

    .line 34
    invoke-virtual {v2, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-nez v4, :cond_247

    move-object/from16 v4, v20

    invoke-virtual {v2, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_252

    .line 35
    :cond_247
    sget-object v2, Lcom/github/catvod/spider/XYQHiker;->ԭ:Ljava/lang/String;

    goto :goto_252

    .line 36
    :cond_24a
    :goto_24a
    sget-object v2, Lcom/github/catvod/spider/XYQHiker;->Ԭ:Ljava/lang/String;

    goto :goto_252

    .line 37
    :cond_24d
    :goto_24d
    sget-object v2, Lcom/github/catvod/spider/XYQHiker;->ԫ:Ljava/lang/String;

    goto :goto_252

    .line 38
    :cond_250
    :goto_250
    sget-object v2, Lcom/github/catvod/spider/XYQHiker;->Ԫ:Ljava/lang/String;

    .line 39
    :cond_252
    :goto_252
    iget-object v4, v0, Lcom/github/catvod/spider/XYQHiker;->ؠ:Ljava/lang/String;

    invoke-virtual {v4}, Ljava/lang/String;->isEmpty()Z

    move-result v4

    if-eqz v4, :cond_262

    iget-object v4, v0, Lcom/github/catvod/spider/XYQHiker;->ށ:Ljava/lang/String;

    invoke-virtual {v4}, Ljava/lang/String;->isEmpty()Z

    move-result v4

    if-nez v4, :cond_2ae

    .line 40
    :cond_262
    iget-object v4, v0, Lcom/github/catvod/spider/XYQHiker;->ؠ:Ljava/lang/String;

    invoke-virtual {v4}, Ljava/lang/String;->length()I

    move-result v4

    const/4 v5, 0x1

    if-gt v4, v5, :cond_273

    iget-object v4, v0, Lcom/github/catvod/spider/XYQHiker;->ށ:Ljava/lang/String;

    invoke-virtual {v4}, Ljava/lang/String;->length()I

    move-result v4

    if-le v4, v5, :cond_2ae

    .line 41
    :cond_273
    iget-object v4, v0, Lcom/github/catvod/spider/XYQHiker;->ؠ:Ljava/lang/String;

    invoke-virtual {v4}, Ljava/lang/String;->isEmpty()Z

    move-result v4

    if-nez v4, :cond_27e

    iget-object v4, v0, Lcom/github/catvod/spider/XYQHiker;->ށ:Ljava/lang/String;

    goto :goto_2ab

    :cond_27e
    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v5, v0, Lcom/github/catvod/spider/XYQHiker;->ؠ:Ljava/lang/String;

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v5, v0, Lcom/github/catvod/spider/XYQHiker;->ށ:Ljava/lang/String;

    invoke-virtual {v5}, Ljava/lang/String;->isEmpty()Z

    move-result v5

    if-nez v5, :cond_2a2

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v5, v15}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v6, v0, Lcom/github/catvod/spider/XYQHiker;->ށ:Ljava/lang/String;

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    goto :goto_2a4

    :cond_2a2
    iget-object v5, v0, Lcom/github/catvod/spider/XYQHiker;->ށ:Ljava/lang/String;

    :goto_2a4
    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    :goto_2ab
    invoke-virtual {v1, v3, v4}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_2ae
    const-string v3, "27313623770515273D25"

    invoke-static {v3}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    .line 42
    invoke-virtual {v1, v3, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 43
    iget-object v3, v0, Lcom/github/catvod/spider/XYQHiker;->ރ:Lorg/json/JSONObject;

    invoke-virtual {v3, v14, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    :cond_2bc
    :goto_2bc
    return-object v1
.end method

.method protected ބ(Ljava/lang/String;)Ljava/util/HashMap;
    .registers 24
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            ")",
            "Ljava/util/HashMap<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    move-object/from16 v0, p0

    .line 1
    new-instance v1, Ljava/util/HashMap;

    invoke-direct {v1}, Ljava/util/HashMap;-><init>()V

    const-string v2, "94D2CFB6EEE69AEDE4B7EBC697E6E7B4D5C694D7E3"

    invoke-static {v2}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    .line 2
    invoke-direct {v0, v2}, Lcom/github/catvod/spider/XYQHiker;->ނ(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/String;->isEmpty()Z

    move-result v3

    if-nez v3, :cond_18

    goto :goto_1e

    :cond_18
    const-string v2, "210A36303E210031"

    invoke-static {v2}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    :goto_1e
    const-string v3, ""

    .line 3
    invoke-direct {v0, v2, v3}, Lcom/github/catvod/spider/XYQHiker;->ރ(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v2

    const-string v4, "56"

    invoke-static {v4}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    .line 4
    invoke-virtual {v2, v4}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v4

    const-string v5, "9AC9EAB7C4D895D6E6B9DED5"

    invoke-static {v5}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    const-string v6, "3F03100E0F05"

    invoke-static {v6}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    const-string v7, "9AC9EAB7C4D894CBD8B7C6FE"

    invoke-static {v7}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    const-string v8, "3B0D000E0F05"

    invoke-static {v8}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    const-string v9, "312D3C3A3321"

    invoke-static {v9}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    const-string v10, "94CBD8B7C6FE"

    invoke-static {v10}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    const-string v11, "3F0D111816012D1712"

    invoke-static {v11}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v11

    const-string v12, "95D6E6B9DED5"

    invoke-static {v12}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v12

    const-string v13, "22010C041B"

    invoke-static {v13}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v13

    const-string v14, "07313623772515273D25"

    invoke-static {v14}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v14

    const-string v15, "49"

    invoke-static {v15}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v15

    move-object/from16 v16, v3

    if-eqz v4, :cond_1fd

    const-string v4, "51"

    invoke-static {v4}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    .line 5
    invoke-virtual {v2, v4}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v4

    const/16 v17, 0x0

    move-object/from16 v19, v9

    const/4 v3, 0x0

    .line 6
    :goto_87
    array-length v9, v4

    if-ge v3, v9, :cond_185

    .line 7
    aget-object v9, v4, v3

    move-object/from16 p1, v4

    const-string v4, "2E66"

    invoke-static {v4}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v9, v4}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v4

    .line 8
    aget-object v9, v4, v17

    const/16 v18, 0x1

    .line 9
    aget-object v4, v4, v18

    .line 10
    invoke-virtual {v4, v13}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v20

    if-nez v20, :cond_da

    invoke-virtual {v4, v12}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v20

    if-eqz v20, :cond_ab

    goto :goto_da

    .line 11
    :cond_ab
    invoke-virtual {v4, v11}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v20

    if-nez v20, :cond_d7

    invoke-virtual {v4, v10}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v20

    if-eqz v20, :cond_b8

    goto :goto_d7

    .line 12
    :cond_b8
    invoke-virtual {v4, v8}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v20

    if-nez v20, :cond_d4

    invoke-virtual {v4, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v20

    if-eqz v20, :cond_c5

    goto :goto_d4

    .line 13
    :cond_c5
    invoke-virtual {v4, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v20

    if-nez v20, :cond_d1

    invoke-virtual {v4, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v20

    if-eqz v20, :cond_dc

    .line 14
    :cond_d1
    sget-object v4, Lcom/github/catvod/spider/XYQHiker;->ԭ:Ljava/lang/String;

    goto :goto_dc

    .line 15
    :cond_d4
    :goto_d4
    sget-object v4, Lcom/github/catvod/spider/XYQHiker;->Ԭ:Ljava/lang/String;

    goto :goto_dc

    .line 16
    :cond_d7
    :goto_d7
    sget-object v4, Lcom/github/catvod/spider/XYQHiker;->ԫ:Ljava/lang/String;

    goto :goto_dc

    .line 17
    :cond_da
    :goto_da
    sget-object v4, Lcom/github/catvod/spider/XYQHiker;->Ԫ:Ljava/lang/String;

    :cond_dc
    :goto_dc
    move-object/from16 v20, v5

    .line 18
    iget-object v5, v0, Lcom/github/catvod/spider/XYQHiker;->ؠ:Ljava/lang/String;

    invoke-virtual {v5}, Ljava/lang/String;->isEmpty()Z

    move-result v5

    if-eqz v5, :cond_ee

    iget-object v5, v0, Lcom/github/catvod/spider/XYQHiker;->ނ:Ljava/lang/String;

    invoke-virtual {v5}, Ljava/lang/String;->isEmpty()Z

    move-result v5

    if-nez v5, :cond_149

    :cond_ee
    const-string v5, "112D3C3A3321"

    invoke-static {v5}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    .line 19
    invoke-virtual {v9, v5}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v5

    if-eqz v5, :cond_149

    .line 20
    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v5, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v4, v0, Lcom/github/catvod/spider/XYQHiker;->ؠ:Ljava/lang/String;

    invoke-virtual {v4}, Ljava/lang/String;->isEmpty()Z

    move-result v4

    if-nez v4, :cond_11e

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v4, v15}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-object/from16 v21, v6

    iget-object v6, v0, Lcom/github/catvod/spider/XYQHiker;->ؠ:Ljava/lang/String;

    invoke-virtual {v4, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    goto :goto_122

    :cond_11e
    move-object/from16 v21, v6

    move-object/from16 v4, v16

    :goto_122
    invoke-virtual {v5, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v4, v0, Lcom/github/catvod/spider/XYQHiker;->ނ:Ljava/lang/String;

    invoke-virtual {v4}, Ljava/lang/String;->isEmpty()Z

    move-result v4

    if-nez v4, :cond_13f

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v4, v15}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v6, v0, Lcom/github/catvod/spider/XYQHiker;->ނ:Ljava/lang/String;

    invoke-virtual {v4, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    goto :goto_141

    :cond_13f
    move-object/from16 v4, v16

    :goto_141
    invoke-virtual {v5, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    goto :goto_14b

    :cond_149
    move-object/from16 v21, v6

    .line 21
    :goto_14b
    invoke-virtual {v9, v14}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v5

    if-eqz v5, :cond_156

    .line 22
    iget-object v5, v0, Lcom/github/catvod/spider/XYQHiker;->ރ:Lorg/json/JSONObject;

    invoke-virtual {v5, v14, v4}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    :cond_156
    const-string v5, "00273534282100"

    invoke-static {v5}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    .line 23
    invoke-virtual {v9, v5}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v5

    const-string v6, "25273107332105"

    invoke-static {v6}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    if-nez v5, :cond_172

    invoke-virtual {v4, v6}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v5

    if-nez v5, :cond_172

    .line 24
    invoke-virtual {v1, v9, v4}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_17b

    .line 25
    :cond_172
    invoke-virtual {v4, v6}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v5

    if-nez v5, :cond_17b

    .line 26
    invoke-virtual {v1, v9, v4}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_17b
    :goto_17b
    add-int/lit8 v3, v3, 0x1

    move-object/from16 v4, p1

    move-object/from16 v5, v20

    move-object/from16 v6, v21

    goto/16 :goto_87

    .line 27
    :cond_185
    iget-object v3, v0, Lcom/github/catvod/spider/XYQHiker;->ؠ:Ljava/lang/String;

    invoke-virtual {v3}, Ljava/lang/String;->isEmpty()Z

    move-result v3

    if-eqz v3, :cond_195

    iget-object v3, v0, Lcom/github/catvod/spider/XYQHiker;->ނ:Ljava/lang/String;

    invoke-virtual {v3}, Ljava/lang/String;->isEmpty()Z

    move-result v3

    if-nez v3, :cond_2b9

    .line 28
    :cond_195
    iget-object v3, v0, Lcom/github/catvod/spider/XYQHiker;->ؠ:Ljava/lang/String;

    invoke-virtual {v3}, Ljava/lang/String;->length()I

    move-result v3

    const/4 v4, 0x1

    if-gt v3, v4, :cond_1a6

    iget-object v3, v0, Lcom/github/catvod/spider/XYQHiker;->ނ:Ljava/lang/String;

    invoke-virtual {v3}, Ljava/lang/String;->length()I

    move-result v3

    if-le v3, v4, :cond_2b9

    :cond_1a6
    const-string v3, "312D3C3A332156"

    invoke-static {v3}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v3

    if-nez v3, :cond_2b9

    const-string v3, "112D3C3A332156"

    invoke-static {v3}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v2

    if-nez v2, :cond_2b9

    .line 29
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v3, v0, Lcom/github/catvod/spider/XYQHiker;->ؠ:Ljava/lang/String;

    invoke-virtual {v3}, Ljava/lang/String;->isEmpty()Z

    move-result v3

    if-nez v3, :cond_1ce

    iget-object v3, v0, Lcom/github/catvod/spider/XYQHiker;->ނ:Ljava/lang/String;

    goto :goto_1d0

    :cond_1ce
    iget-object v3, v0, Lcom/github/catvod/spider/XYQHiker;->ؠ:Ljava/lang/String;

    :goto_1d0
    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v3, v0, Lcom/github/catvod/spider/XYQHiker;->ނ:Ljava/lang/String;

    invoke-virtual {v3}, Ljava/lang/String;->isEmpty()Z

    move-result v3

    if-nez v3, :cond_1ed

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v3, v15}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v4, v0, Lcom/github/catvod/spider/XYQHiker;->ނ:Ljava/lang/String;

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    goto :goto_1ef

    :cond_1ed
    iget-object v3, v0, Lcom/github/catvod/spider/XYQHiker;->ނ:Ljava/lang/String;

    :goto_1ef
    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    move-object/from16 v3, v19

    invoke-virtual {v1, v3, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    goto/16 :goto_2b9

    :cond_1fd
    move-object/from16 v20, v5

    move-object/from16 v21, v6

    move-object v3, v9

    .line 30
    invoke-virtual {v2}, Ljava/lang/String;->isEmpty()Z

    move-result v4

    if-eqz v4, :cond_20d

    .line 31
    invoke-virtual/range {p0 .. p1}, Lcom/github/catvod/spider/XYQHiker;->ހ(Ljava/lang/String;)Ljava/util/HashMap;

    move-result-object v1

    return-object v1

    .line 32
    :cond_20d
    invoke-virtual {v2, v13}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-nez v4, :cond_24d

    invoke-virtual {v2, v12}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_21a

    goto :goto_24d

    .line 33
    :cond_21a
    invoke-virtual {v2, v11}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-nez v4, :cond_24a

    invoke-virtual {v2, v10}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_227

    goto :goto_24a

    .line 34
    :cond_227
    invoke-virtual {v2, v8}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-nez v4, :cond_247

    invoke-virtual {v2, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_234

    goto :goto_247

    :cond_234
    move-object/from16 v4, v21

    .line 35
    invoke-virtual {v2, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-nez v4, :cond_244

    move-object/from16 v4, v20

    invoke-virtual {v2, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_24f

    .line 36
    :cond_244
    sget-object v2, Lcom/github/catvod/spider/XYQHiker;->ԭ:Ljava/lang/String;

    goto :goto_24f

    .line 37
    :cond_247
    :goto_247
    sget-object v2, Lcom/github/catvod/spider/XYQHiker;->Ԭ:Ljava/lang/String;

    goto :goto_24f

    .line 38
    :cond_24a
    :goto_24a
    sget-object v2, Lcom/github/catvod/spider/XYQHiker;->ԫ:Ljava/lang/String;

    goto :goto_24f

    .line 39
    :cond_24d
    :goto_24d
    sget-object v2, Lcom/github/catvod/spider/XYQHiker;->Ԫ:Ljava/lang/String;

    .line 40
    :cond_24f
    :goto_24f
    iget-object v4, v0, Lcom/github/catvod/spider/XYQHiker;->ؠ:Ljava/lang/String;

    invoke-virtual {v4}, Ljava/lang/String;->isEmpty()Z

    move-result v4

    if-eqz v4, :cond_25f

    iget-object v4, v0, Lcom/github/catvod/spider/XYQHiker;->ނ:Ljava/lang/String;

    invoke-virtual {v4}, Ljava/lang/String;->isEmpty()Z

    move-result v4

    if-nez v4, :cond_2ab

    .line 41
    :cond_25f
    iget-object v4, v0, Lcom/github/catvod/spider/XYQHiker;->ؠ:Ljava/lang/String;

    invoke-virtual {v4}, Ljava/lang/String;->length()I

    move-result v4

    const/4 v5, 0x1

    if-gt v4, v5, :cond_270

    iget-object v4, v0, Lcom/github/catvod/spider/XYQHiker;->ނ:Ljava/lang/String;

    invoke-virtual {v4}, Ljava/lang/String;->length()I

    move-result v4

    if-le v4, v5, :cond_2ab

    .line 42
    :cond_270
    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v5, v0, Lcom/github/catvod/spider/XYQHiker;->ؠ:Ljava/lang/String;

    invoke-virtual {v5}, Ljava/lang/String;->isEmpty()Z

    move-result v5

    if-nez v5, :cond_280

    iget-object v5, v0, Lcom/github/catvod/spider/XYQHiker;->ނ:Ljava/lang/String;

    goto :goto_282

    :cond_280
    iget-object v5, v0, Lcom/github/catvod/spider/XYQHiker;->ؠ:Ljava/lang/String;

    :goto_282
    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v5, v0, Lcom/github/catvod/spider/XYQHiker;->ނ:Ljava/lang/String;

    invoke-virtual {v5}, Ljava/lang/String;->isEmpty()Z

    move-result v5

    if-nez v5, :cond_29f

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v5, v15}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v6, v0, Lcom/github/catvod/spider/XYQHiker;->ނ:Ljava/lang/String;

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    goto :goto_2a1

    :cond_29f
    iget-object v5, v0, Lcom/github/catvod/spider/XYQHiker;->ނ:Ljava/lang/String;

    :goto_2a1
    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v1, v3, v4}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_2ab
    const-string v3, "27313623770515273D25"

    invoke-static {v3}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    .line 43
    invoke-virtual {v1, v3, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 44
    iget-object v3, v0, Lcom/github/catvod/spider/XYQHiker;->ރ:Lorg/json/JSONObject;

    invoke-virtual {v3, v14, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    :cond_2b9
    :goto_2b9
    return-object v1
.end method

.method މ(Ljava/lang/String;)Ljava/lang/String;
    .registers 4

    const-string v0, "2E643D33293449"

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const-string v1, "52"

    invoke-static {v1}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    .line 1
    invoke-virtual {p1, v0, v1}, Ljava/lang/String;->replaceAll(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const-string v0, "2E640830773E336F090C21755E73632C61"

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const-string v1, ""

    invoke-virtual {p1, v0, v1}, Ljava/lang/String;->replaceAll(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const-string v0, "4E190D6F076E4C"

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0, v1}, Ljava/lang/String;->replaceAll(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const-string v0, "296A7C6F73782F"

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0, v1}, Ljava/lang/String;->replaceAll(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const-string v0, "2E3128637639"

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xyq/KUx;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0, v1}, Ljava/lang/String;->replaceAll(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    return-object p1
.end method
