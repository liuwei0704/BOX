.class public Lcom/github/catvod/spider/XBPQAli;
.super Lcom/github/catvod/crawler/Spider;
.source "SourceFile"


# static fields
.field public static final a:Ljava/util/regex/Pattern;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    const-string v0, "000F324B12391E01300B17271E0E204B103A1A57364A5B0E2957184E5A7D581E2A09173005576D3E2D7A2A536C4C4C"

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    move-result-object v0

    sput-object v0, Lcom/github/catvod/spider/XBPQAli;->a:Ljava/util/regex/Pattern;

    return-void
.end method

.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, Lcom/github/catvod/crawler/Spider;-><init>()V

    return-void
.end method

.method public static proxy(Ljava/util/Map;)[Ljava/lang/Object;
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;)[",
            "Ljava/lang/Object;"
        }
    .end annotation

    const-string v0, "03013500"

    invoke-static {v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-interface {p0, v0}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    const-string v1, "040D27"

    invoke-static {v1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_21

    invoke-static {}, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;->o()Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;

    move-result-object v0

    invoke-virtual {v0, p0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;->H(Ljava/util/Map;)[Ljava/lang/Object;

    move-result-object p0

    return-object p0

    :cond_21
    const-string p0, "03172E001D"

    invoke-static {p0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    invoke-virtual {v0, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p0

    if-eqz p0, :cond_36

    invoke-static {}, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;->o()Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;

    move-result-object p0

    invoke-virtual {p0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;->w()[Ljava/lang/Object;

    move-result-object p0

    return-object p0

    :cond_36
    const/4 p0, 0x0

    return-object p0
.end method


# virtual methods
.method public detailContent(Ljava/util/List;)Ljava/lang/String;
    .registers 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;)",
            "Ljava/lang/String;"
        }
    .end annotation

    const-string v0, ""

    const/4 v1, 0x0

    :try_start_3
    invoke-interface {p1, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/lang/String;

    invoke-virtual {p1}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object p1

    const-string v1, "000F324B12391E08240B5D361815"

    invoke-static {v1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const-string v2, "000F324B12391E01300B17271E0E204B103A1A"

    invoke-static {v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {p1, v1, v2}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object p1

    sget-object v1, Lcom/github/catvod/spider/XBPQAli;->a:Ljava/util/regex/Pattern;

    invoke-virtual {v1, p1}, Ljava/util/regex/Pattern;->matcher(Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;

    move-result-object v1

    invoke-virtual {v1}, Ljava/util/regex/Matcher;->find()Z

    move-result v2

    if-nez v2, :cond_2a

    return-object v0

    :cond_2a
    const/4 v2, 0x1

    invoke-virtual {v1, v2}, Ljava/util/regex/Matcher;->group(I)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1}, Ljava/util/regex/Matcher;->groupCount()I

    move-result v3

    const/4 v4, 0x3

    if-ne v3, v4, :cond_3b

    invoke-virtual {v1, v4}, Ljava/util/regex/Matcher;->group(I)Ljava/lang/String;

    move-result-object v1

    goto :goto_3c

    :cond_3b
    move-object v1, v0

    :goto_3c
    invoke-static {}, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;->o()Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;

    move-result-object v3

    invoke-virtual {v3, v2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;->K(Ljava/lang/String;)V

    invoke-static {}, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;->o()Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;

    move-result-object v2

    invoke-virtual {v2, p1, v1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;->z(Ljava/lang/String;Ljava/lang/String;)Lcom/github/catvod/spider/xbpqxyq/xbpq/c/g;

    move-result-object p1

    invoke-static {p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/c/d;->e(Lcom/github/catvod/spider/xbpqxyq/xbpq/c/g;)Ljava/lang/String;

    move-result-object p1
    :try_end_4f
    .catch Ljava/lang/Exception; {:try_start_3 .. :try_end_4f} :catch_50

    return-object p1

    :catch_50
    return-object v0
.end method

.method public init(Landroid/content/Context;Ljava/lang/String;)V
    .registers 3

    invoke-static {}, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;->o()Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;

    move-result-object p1

    invoke-virtual {p1, p2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;->J(Ljava/lang/String;)V

    return-void
.end method

.method public playerContent(Ljava/lang/String;Ljava/lang/String;Ljava/util/List;)Ljava/lang/String;
    .registers 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;)",
            "Ljava/lang/String;"
        }
    .end annotation

    :try_start_0
    const-string p3, "2B53"

    invoke-static {p3}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p3

    invoke-virtual {p2, p3}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object p2

    const-string p3, "499DCBFA94C1CC44"

    invoke-static {p3}, Lcom/github/catvod/spider/xbpqxyq/xbpq/HaB;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p3

    invoke-virtual {p1, p3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p3

    if-eqz p3, :cond_3f

    invoke-static {}, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;->o()Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1
    new-instance p3, Lcom/github/catvod/spider/xbpqxyq/xbpq/c/d;

    invoke-direct {p3}, Lcom/github/catvod/spider/xbpqxyq/xbpq/c/d;-><init>()V

    const/4 v0, 0x0

    .line 2
    aget-object v0, p2, v0

    invoke-virtual {p1, v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;->p(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p3, v0}, Lcom/github/catvod/spider/xbpqxyq/xbpq/c/d;->i(Ljava/lang/String;)Lcom/github/catvod/spider/xbpqxyq/xbpq/c/d;

    invoke-virtual {p1, p2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;->v([Ljava/lang/String;)Ljava/util/List;

    move-result-object p2

    invoke-virtual {p3, p2}, Lcom/github/catvod/spider/xbpqxyq/xbpq/c/d;->h(Ljava/util/List;)Lcom/github/catvod/spider/xbpqxyq/xbpq/c/d;

    invoke-virtual {p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;->q()Ljava/util/HashMap;

    move-result-object p1

    invoke-virtual {p3, p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/c/d;->a(Ljava/util/Map;)Lcom/github/catvod/spider/xbpqxyq/xbpq/c/d;

    .line 3
    invoke-virtual {p3}, Lcom/github/catvod/spider/xbpqxyq/xbpq/c/d;->toString()Ljava/lang/String;

    move-result-object p1

    goto :goto_47

    .line 4
    :cond_3f
    invoke-static {}, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;->o()Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;

    move-result-object p3

    invoke-virtual {p3, p2, p1}, Lcom/github/catvod/spider/xbpqxyq/xbpq/b/p;->F([Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1
    :try_end_47
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_47} :catch_48

    :goto_47
    return-object p1

    :catch_48
    const-string p1, ""

    return-object p1
.end method
